#!/usr/bin/env python3
"""Private real JSONL/loopback gated-provider regression. No shared harness changes."""
import argparse,datetime,hashlib,json,os,queue,signal,subprocess,threading,time,traceback
from pathlib import Path
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
p=argparse.ArgumentParser();p.add_argument('--binary',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();binary=a.binary.resolve();root=a.out.resolve();root.mkdir(parents=True,exist_ok=False)
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
start=time.monotonic();result={'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'binary':str(binary),'binary_sha256':sha(binary),'checks':{},'observations':[]};requests=[];gates=[];gate_lock=threading.Lock();host=None;threads=[];raw=[];err=[];incoming=queue.Queue();commands=[]
def record(name,ok,detail=None):result['checks'][name]=bool(ok);result['observations'].append({'name':name,'passed':bool(ok),'detail':detail})
class Server(ThreadingHTTPServer):daemon_threads=False;block_on_close=True
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def do_POST(self):
  self.connection.settimeout(4)
  body=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
  with gate_lock:
   ix=len(requests);assert ix<3,'unexpected provider request';event=threading.Event();gates.append(event);requests.append({'path':self.path,'body':body,'received_elapsed':time.monotonic()-start,'completed':False})
  self.send_response(200);self.send_header('Content-Type','text/event-stream');self.end_headers()
  def emit(delta=None,finish=None):
   v={'id':f'busy-diff-{ix}','model':body['model'],'choices':[{'index':0,'delta':delta or {},'finish_reason':finish}]};self.wfile.write(('data: '+json.dumps(v)+'\n\n').encode());self.wfile.flush()
  try:
   emit({'role':'assistant'});emit({'content':f'BUSY_GATE_{ix} '})
   requests[ix]['gate_released']=event.wait(18)
   emit({'content':f'DONE_GATE_{ix}'});emit(finish='stop');self.wfile.write(b'data: [DONE]\n\n');self.wfile.flush();requests[ix]['completed']=True
  except (BrokenPipeError,ConnectionResetError,OSError) as e:requests[ix]['peer_close']=type(e).__name__
server=Server(('127.0.0.1',0),Handler);st=threading.Thread(target=lambda:server.serve_forever(poll_interval=.05),name='fixture-http');st.start()
env={k:v for k,v in os.environ.items() if not k.startswith(('ZENPI_','OPENAI_'))};env.update(ZENPI_HOME=str(root/'fixture'),NO_PROXY='127.0.0.1,localhost',no_proxy='127.0.0.1,localhost')
result['HOME_preserved']=env.get('HOME')==os.environ.get('HOME');result['CODEX_HOME_preserved']=env.get('CODEX_HOME')==os.environ.get('CODEX_HOME')
try:
 A=root/'A';B=root/'B';cfg=root/'fixture';sessions=root/'sessions'
 for d in [A,B,cfg,sessions]:d.mkdir()
 git_env=env.copy();git_env.update(GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL='/dev/null')
 for project,name in [(A,'A'),(B,'B')]:
  def git(args):
   argv=['git','-c','core.hooksPath=/dev/null',*args];r=subprocess.run(argv,cwd=project,env=git_env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10);commands.append({'argv':argv,'cwd':str(project),'exit':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode()});assert r.returncode==0
  git(['init','--quiet']);(project/'selected.txt').write_text('base '+name+'\n');git(['add','selected.txt']);git(['-c','user.name=Local Fixture','-c','user.email=fixture@invalid.test','commit','--quiet','-m','fixture baseline']);(project/'selected.txt').write_text('UNIQUE_DIFF_'+name+'\n')
 (B/'escape-link').symlink_to(A/'selected.txt')
 result['fixture_identity']={n:{'cwd':str(d),'file_inode':(d/'selected.txt').stat().st_ino,'git_inode':(d/'.git').stat().st_ino,'sha256':sha(d/'selected.txt')} for n,d in [('A',A),('B',B)]};assert result['fixture_identity']['A']['file_inode']!=result['fixture_identity']['B']['file_inode']
 (cfg/'config.toml').write_text(f'backend="openai"\nprovider="openai"\nmodel="gpt-4.1"\nbase_url="http://127.0.0.1:{server.server_port}/v1"\nwire_api="chat"\nrequires_openai_auth=false\nmax_retries=0\n')
 (cfg/'auth.json').write_text(json.dumps({'OPENAI_API_KEY':'busy-diff-local-fixture'}));(cfg/'auth.json').chmod(0o600)
 argv=[str(binary),'--mode','headless','--session',str(sessions/'initial.jsonl')];result['host_argv']=argv;result['host_cwd']=str(A)
 host=subprocess.Popen(argv,cwd=A,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,bufsize=1,start_new_session=True)
 result['pid']=host.pid
 def readout():
  for line in host.stdout:
   raw.append(line)
   try:incoming.put(json.loads(line))
   except Exception:incoming.put({'invalid_json':line})
  incoming.put(None)
 def readerr():
  for line in host.stderr:err.append(line)
 for fn in [readout,readerr]:
  t=threading.Thread(target=fn);t.start();threads.append(t)
 records=[];sent=[]
 def send(v):
  sent.append({'elapsed':time.monotonic()-start,'request':v});host.stdin.write(json.dumps(v)+'\n');host.stdin.flush()
 def wait(pred,timeout=7):
  deadline=time.monotonic()+timeout
  while time.monotonic()<deadline:
   v=incoming.get(timeout=max(.01,deadline-time.monotonic()));assert v is not None,'early EOF';records.append(v)
   if pred(v):return v
  raise TimeoutError('wire deadline')
 def response(id):return wait(lambda v:v.get('type')=='response' and v.get('id')==id)
 def call(id,kind,**kw):send(dict(schema_version=2,type=kind,id=id,**kw));return response(id)
 def project(request_id,**kw):return call(request_id,'project',project=kw)
 def busy(ix,context):
  prompt='busy-'+str(ix);send(dict(schema_version=2,type='prompt',id=prompt,project_id=context['project_id'],text='Keep provider open for fixture '+str(ix)))
  event=wait(lambda v:v.get('event',{}).get('delta')==f'BUSY_GATE_{ix} ')
  assert event['project']==context,event
  status=call('status-'+str(ix),'status');assert status['data'].get('busy') is True,status
  record('busy_provider_'+str(ix),len(gates)==ix+1 and not gates[ix].is_set() and not requests[ix]['completed'],status)
  return prompt
 def checkdiff(id,context,which,ix):
  t=time.monotonic();v=call(id,'command',text='/diff selected.txt',project_id=context['project_id']);text=v.get('data',{}).get('diff','');gated=not gates[ix].is_set() and not requests[ix]['completed'];terminal=any(x.get('type')=='response' and x.get('id')=='busy-'+str(ix) for x in records)
  record(id,v.get('success') is True and v.get('project')==context and 'UNIQUE_DIFF_'+which in text and 'UNIQUE_DIFF_'+('A' if which=='B' else 'B') not in text and gated and not terminal,{'response':v,'gated':gated,'provider_terminal_seen':terminal,'elapsed':time.monotonic()-t,'expected_cwd':context['cwd']})
  return v
 ca=project('initial',action='list')['project'];assert ca['cwd']==str(A)
 cb=project('open-B',action='open',cwd=str(B))['project'];assert cb['cwd']==str(B)
 prompt=busy(0,cb);checkdiff('B-before-new',cb,'B',0)
 for id,path in [('deny-parent','../A/selected.txt'),('deny-link','escape-link')]:
  v=call(id,'command',text='/diff '+path);record(id,v['success'] is False,v)
 gates[0].set();v=response(prompt);assert v['success'],v
 new=call('new-B','command',text='/new');assert new['success'],new;newcb=new['project'];assert newcb['project_id']==cb['project_id'] and newcb['session_id']!=cb['session_id'];record('new_session_identity',True,new)
 prompt=busy(1,newcb);replay=checkdiff('B-after-new',newcb,'B',1)
 nowa=project('back-A',action='select',id=ca['project_id'])['project'];assert nowa==ca
 checkdiff('A-while-B-busy',ca,'A',1)
 replayed=call('B-after-new','command',text='/diff selected.txt',project_id=newcb['project_id']);record('replay_B_bound_while_A_selected',replayed==replay,replayed)
 nowb=project('back-B',action='select',id=newcb['project_id'])['project'];assert nowb==newcb
 checkdiff('B-after-switch-back',newcb,'B',1)
 mismatch=call('foreign-guard','command',text='/diff selected.txt',project_id=ca['project_id']);record('project_guard',mismatch.get('code')=='project_mismatch',mismatch)
 gates[1].set();v=response(prompt);record('late_B_terminal_identity',v['success'] and v['project']==newcb,v)
 # Cancellation remains possible while the local diff completed and provider is held.
 prompt=busy(2,newcb);checkdiff('B-before-cancel',newcb,'B',2)
 cancelled=call('cancel-B','cancel',target_id=prompt);record('cancel_admitted_while_busy',cancelled.get('success') is True and cancelled['project']==newcb,cancelled)
 gates[2].set();v=response(prompt);record('cancel_terminal_identity',v['project']==newcb and v.get('code')=='backend_cancelled',v)
 shut=call('stop','shutdown');record('shutdown',shut['success'],shut);host.stdin.close();result['host_exit']=host.wait(timeout=8);assert result['host_exit']==0
 dump(root/'sent.json',sent);dump(root/'records.json',records)
except Exception:
 result['exception']=traceback.format_exc()
finally:
 for gate in gates:gate.set()
 if host:
  if host.poll() is None:
   result['forced_cleanup']=True
   try:os.killpg(host.pid,signal.SIGTERM);host.wait(timeout=3)
   except subprocess.TimeoutExpired:os.killpg(host.pid,signal.SIGKILL);host.wait(timeout=3)
  result['host_reaped']=host.poll() is not None
  for t in threads:t.join(timeout=3)
  result['reader_threads_joined']=all(not t.is_alive() for t in threads)
 server.shutdown();server.server_close();st.join(timeout=3);result['server_thread_joined']=not st.is_alive()
 result['elapsed_seconds']=time.monotonic()-start;result['ended_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();result['status']='passed' if result['checks'] and all(result['checks'].values()) and 'exception' not in result and result.get('host_reaped') and result.get('reader_threads_joined') and result['server_thread_joined'] else 'failed'
 if 'sent' in globals():dump(root/'sent.json',sent)
 if 'records' in globals():dump(root/'records.json',records)
 (root/'stdout.jsonl').write_text(''.join(raw));(root/'stderr.log').write_text(''.join(err));dump(root/'http.json',requests);dump(root/'git-commands.json',commands);dump(root/'result.json',result)
 print(json.dumps(result,ensure_ascii=False))
raise SystemExit(0 if result['status']=='passed' else 1)
