# ZS1-084 — src/headless.rs 全文件理解（3.1.20）

本报告只接受本文件的理解责任，未修改产品或主工作区状态。基线为 312227 bytes / 7989 lines / SHA-256 `1c3b14bda2533e82e498372f0d570cf899833a06e41fd6cd70b8cf7cc385b478`；当前为 365555 bytes / 9229 lines / `958837ad933fea4e55c3ac966f0c8d605dd03674a696e2ef0595b54aca628ef9`。需求 3.1.20 digest `8d525b351d066ce9b0487a485337647d47233275782e4f4d154423a623fe1645`，捕获时 blueprint snapshot `d13f344a5974c5ef00ba247b166235aa02a331ec59b807c368c207c3d8007af3`。`previous-current-headless.rs` 是同次 current 的冗余副本，绝不是历史阅读凭证。未找到本地/主目录 .ops 与 Docs/learn 范围内的既有084完整报告，本次新建 canonical；没有可追加的旧报告前缀。

**阅读与证据。** 两个源文件都超过256KiB，实际连续分块读至EOF：baseline 1–7989（20块），current 1–8800（22个400行块）及8801–9229（1块）。随后完整阅读2558行 unified diff（4块）。`evidence/read-binding.json` 的原始片段、行范围、字节偏移、SHA可重组两个完整源文件；不是用哈希相同、检索结果或函数名代替阅读。`delta-map.json` 覆盖所有equal/insert/delete/replace区间，当前7758行与基线匹配、1471行新增或替换；基线153个函数/25个类型与别名，当前174个函数/26个类型与别名，含嵌套计数字节writer、const fn及全部测试。末尾索引逐项列出声明起点，语义按下列责任区段解释。外部依赖只接受列明的界面片段，不替代其owner验收。

**职责与调用边界（current 1–788）。** 本模块把同步或异步JSONL接到Agent、持久session与本地域对象；不自行实现provider、操作系统进程监管或工具沙箱。`run_stdio`借用Agent使用同步`run_headless`；`run_stdio_owned`与`run_async_streams`拥有Agent并走异步project pool。`HeadlessError`分别包裹IO、编码、Agent、Session和View错误。`read_frame`逐段消费至LF，超长只保留limit+1大小但消费整个帧，最终无LF的非空帧有效，空EOF是结束；UTF8非法与解析失败返回typed invalid响应，空白行跳过，CRLF由parser支持。IO失败不等同于命令无副作用。

**协议与重放。** `parse_line`属于protocol：原始帧再serde解码保留重复字段拒绝，project/input_queue/tree/output有严格的专用envelope检查；一般StdioRequest未统一deny_unknown_fields，不能宣称所有命令所有未知字段都拒绝。缺省schema按v1；响应`for_version`只保留支持的v2或v1；异步event独立版本。headless先计算`into_command()`的Result，再进入`admit`分支，之后才处理Result；注释的“validate before cache”不能当成错误已在admit前返回。特别runtime intent指纹为了跨wire版本重放会规整schema，不宜从注释推导任意unsupported version都不能命中旧缓存。request指纹去ID、规整command/slash、text/message等语义；request ID是传输幂等键，不是权限或项目身份凭证。

**ReplayState / ReconnectEntry（131–532）。** WAL恢复Owner、Reserved、Released、Terminal、Event和Acknowledged等记录；未得到持久终态的reservation恢复为unknown，拒绝隐式重做，要求显式检查副作用后换ID。completed指纹墓碑防止terminal窗口淘汰后重复执行：expired与unknown/conflict/ledger_full不同；inflight即便payload改变也返回InFlightSame拒绝并发，不覆盖原指纹。events按4096项/16MiB、terminal按256项/16MiB有界，ID ledger另有16384界限。WAL先写再内存更新与stdout；stdout失败可能发生在持久完成之后。sequence使用saturating_add，极限处没有独立耗尽错误。owner_epoch采用checked增长；它不代表所有工具子进程都已回收。

`project_response`只给v2 response附项目，优先request_projects再emission_project。当前open从已持久的session_new_transition恢复new终态，记录内version/project用于构造receipt。`reset_for_session`保留全部inflight及原project，transition ID优先再按ID排序向新WAL预留；与基线仅保留切换ID不同。冲突时不替换活动ReplayState，但新WAL先前已写入的reservation不能因此推定回滚。旧session已完成ID不整体迁入新命名空间；同journal早退，序列floor维持全进程单调。本进程只有一个ReplayState，项目切换没有给每个项目创建独立传输WAL；应把project归属与session replay命名空间分开理解。

**事件缓冲与投影（790–1082、3880–4269、8803–8897）。** AsyncWork持request/project/version、事件Arc及started_turn_id；每流4096项/1MiB，用serde计数writer计算序列化字节，丢弃含明确数量和字节。provider与agent分别统计。admission最高优先，当前ToolCall/ToolResult也优先于普通progress；admission可挤出tool，tool不能挤出admission或其他tool，超大或全优先饱和仍可能丢失，不能承诺永不丢terminal。`take_admission`读到最后一个admission marker，保留其前置事件的顺序；drain当前在mailbox锁内再取turn ID，修复先取None后收到事件的关联竞态。快照脱离锁后才写stdout，因此慢消费者不持事件锁，但仍会阻塞host读取消消息。不同job的HashMap遍历没有全局时间排序保证。

provider、agent、approval和runtime生命周期都有request/turn/project和WAL sequence；provider view失败可嵌view_error继续，agent/approval view失败可令host返回错误。live tool sink遇mutex poison的`if let Ok`静默丢弃，与其它mailbox路径typed error不同。工具progress新增canonical block；ToolCall/Result投影running/succeeded/failed，provider tool_call_done仅表示queued。block.redacted不等于整条原始event被redact：原始provider/agent数据仍在envelope中。传输投影不是脱敏安全边界，不能以block安全证明所有raw字段安全。

**路径、资源和域数据读取（1084–1457、2380–2473）。** 新增owner_workspace与_at接口，以Agent attachment root或session header cwd定位当前项目；兼容的无_at公共wrapper仍用process cwd。相对路径拒绝空白、控制字符、超4096、absolute、parent和逐component symlink，再canonical containment。校验后另一次File::open仍有TOCTOU窗口，不是descriptor级no-follow保证。Blueprint读取64KiB上限先于domain_store envelope识别，所以较大的合法domain store无法通过此route；与domain store自身16MiB上限不同。read_domain_json同样64KiB、UTF8、typed serde，再validate/write。domain_store_for_agent明确busy与readonly/mutable；serialized_domain_store以512KiB预算逐记录/摘要降级，不是无界整库echo。resource collect、snapshot序列化由resources owner负责；本报告不宣称加载extension/运行skill是只读资源列举。

**会话与生命周期（1460–2100、2309–2379）。** list_session_summaries/session_list_view来自配置的session目录；search有按owner parent的_in版本。open_session_path与resume_last有with_commit回调，异步由ProjectOwnerPool先commit checkpoint，再更换Agent；公共wrapper缺省空回调是嵌入者责任。existing path拒绝final symlink和非普通文件，允许absolute/祖先alias；SessionStore实际open策略是下层责任。lifecycle涵盖list/search/agents/inspect、fork/export/import/migrate/archive/unarchive/delete、retire mailbox、queue和gc：活跃owner是变更约束，catalog中的live-owner不明不能凭路径推出alive。`same_path`比较两个canonicalize().ok()，双失败时None==None是真，源验证缩小了通常路径，但错误不能当成路径相等证明。maintenance和lifecycle receipt可能在写完文件后因redact/512KiB输出检查失败；不宣称全流程原子。GC需confirm、Idle、时间与数量界限并排除active，64KiB receipt约束发生在删除之后。路径展示的redact_session_path以process cwd/文件名退化，不是完整敏感信息清除。

**恢复与回放（1866–1989、2101–2308、8500–8598）。** recovery仅Idle，unknown tool与generic operation marker各自需一致的持久决定；resolve不自动重试已知不确定副作用。resume_session_view回放session journal，限制128记录/128KiB、事件8KiB、turn text4KiB、warnings32，投影后才append marker；recovered operation汇总没有同等本地数量截断。checkpoint cursor明确session_journal；transport replay另有outbound_events、owner_epoch、窗口边界。ack验证session匹配和cursor不超journal后只单调提高ack，不把工具执行变成已成功。checkpoint replay按limit与128KiB预算，超大首条可跳过并显式gap；这是原始journal记录投影，不要与摘要式resume混淆。`Resume from_sequence`先发event后发summary且release而不cache，以便重复请求重发suffix；其直接write_response没有project注入。

**Blueprint、Goal、Learn（2474–3645）。** `/plan id :: steps`创建1–32步的external-owner placeholder，单步4KiB且单行，zenpi_started=false；不是执行计划中的外部开发。persist_blueprint/goal/learn先typed validate再写store，再读summary/append事件，跨文件和response不是同一事务。GoalOwnerAction支持show/list/status、transition/set-status、run/resume/cancel/create；ID字符受界限，run steps1–32，普通目标 prose明确unowned。默认零预算Goal的run只转Running；非默认调用本地deterministic执行；run_blueprint_next要求Idle、明确/唯一版本、唯一关联Goal。handoff却取首个关联Goal，是选择一致性缺口。`create_goal_from_blueprint`先精确version查询再or_else唯一版本：显式请求不存在版本会悄悄回退（2636起），应明确version时失败。local receipt完成不代表外部任务完成，sync_goal_status_after_execution只把Queued转Running，不推Done。

goal_status_response先readonly检查再mutable重读，避免missing读副作用；transition_goal成功后Cancelled再另写execution cancellation，第二步失败可留下Goal已Cancelled。此处只取消receipt状态，不发runtime cancel、不kill/reap进程。允许用户显式领域状态转换和外部验收自动Done是不同操作，不能把任一Done字段当成验收证明。transition_goal_status、persist_*_path等TUI公共adapter复用上述所有限制。

Learn evidence只存reference与事件，hash/大小receipt返回给调用者；文件逐8KiB读、上限16MiB，目录记录0B无hash。id存在检查晚于hash读取。resume Learn是checkpoint数据，不启动worker。LearnResultManifest导入验证schema/ID/source/target/success/evidence等声明，但没有主机重新验artifact或执行validator；返回accepted/external_succeeded不能赋予Blueprint master验收含义。已有external:SHA引用会在checkpoint/source/target重查之前快速重放，且Learn put可持久化引用；这是声明/证据边界问题，不是本轮已运行的攻击复现。读取后再开mutable store无同一checkpoint的CAS；manifest路径会回显absolute。应统一声明导入与可信验收语义，不能仅复制Blueprint文案声称已解决Learn。

**外部准备、导入、验收（3293–3493）。** 当前Blueprint import用ToolContext.read_attachment有界读取一次并parse_external_candidate，ExecutionStore.import_external_candidate保存候选；基线直接fs::read后再按路径import，无初次读取上限且响应称accepted/executed。现在响应accepted=false/request_accepted=true、master_accepted从store已有证据计算、external_work_executed=false；slash_execution_response允许request_accepted=true不被误判unsupported。`external_evidence_action`校验Idle、workspace、目标Blueprint/claim digest、既有handoff及Goal，再调用Agent external_evidence_control。core界面还检查operation reconciliation、恢复既有worker budget账本，prepare/accept交给ExecutionStore；此路径不是provider prompt，也不是headless再次实现工具审批。所有item最新receipt均master accepted后才转GoalDone，跨execution/domain两次提交仍可能失败在后半段。bound引用仅证明调用关系，不替代domain_execution治理/validator/lease全面验收。

**异步owner与取消（3646–3880、4272–5104）。** 每AsyncRequest捕获owner Arc与expected_session，在worker获取Agent锁后拒绝旧session请求；NewSession/ToolOutput/Tree/ResourceControl与Standard/UserShell/Reissue均串到同一个BackgroundRunner。新建占位TurnInputRequest只用来构造buffer后替换variant，不实际提交空prompt。standard submit_with_cancel在准入前支持取消，publishes turn ID/admission后才provider；reissue保留superseded turn。mark_completed使late cancel不把已完成副作用误记取消；CandidateRetained也保持原错误。stdin线程channel32有界但JoinHandle未保存，Read可无限阻塞，不能称所有线程已join。

主循环每轮从pool拿active，保持各project input/approval访问句柄，try_lock刷新context/heartbeat；忙时保留已缓存协调器，跨所有project drain审批。切换选择不会把后台请求改绑新owner。stopping时EOF cancel_all待审批但继续正常drain；显式shutdown emergency_cancel，等待250ms host grace后尝试关闭runner，QueueFull重试并继续drain，不是整个函数250ms期限。runtime Closed后才发pending shutdown success closing/drained；Rejected QueueFull release允许重试，Closed缓存拒绝，unknown job事件忽略以容忍cancel完成竞态。Completed在写terminal前按admission/provider/live/drop顺序排空；NewSession先接受已commit的context然后reset replay，后者失败明确提示已经创建、需reconnect恢复receipt。

**关闭的真实边界。** 已读runtime 369–441及443–555：BackgroundRunner宽限期过后可以detach不合作job、产生Cancelled与Closed，只join runtime worker；“shutdown_and_join”不保证job/OS子进程全回收。headless随后使用root_owner.lock与pool各owner.lock；detached job仍持Agent mutex时，此处可继续无限等待。主循环也在同步stdout上阻塞，无法承诺取消时限。这是host需要修复的生命周期限制：关闭receipt应区分requested、worker_closed、job_terminated/reaped，且cleanup不能重新无界等不合作owner。没有运行不合作进程或故障注入。

**异步命令面（5105–6423）。** project Open/Select/List/Close真正交给pool；Close按目标project拒绝jobs/steers/input tickets，成功response属于操作后active项目。入站project_id与selected不同拒绝；请求ID replay在此guard之前，缓存响应保留历史project并不执行当前请求。ToolOutput与Tree要求全host无jobs/inputs/steers，Tree List轻量try_lock，mutation后台可取消。InputQueue空闲直接Agent执行，忙时InputPort ticket，host最多32、port最多32；ticket receipt不是model job，本轮bounded依赖确认drop cancel只取消未服务ticket，set_scope会给待处理ticket发过期错误，service才写journal。不能用普通Cancel target_id取消ticket。普通resume/open guards缺少pending_inputs检查但每轮及runtime事件前都drain，core scope会过期，故记录为需针对时序验证的边界，而不声称已证明丢票漏洞。

resource候选动态命令、reload、compact与external verification进后台；无法识别的动态名由Agent准入拒绝，不能从Slash的旧注释推导永不送provider。external evidence另需全host idle。/new按当前project过滤三类待处理工作，可以与其他project已排队工作共存，pool的NewSessionPlan捕获checkpoint compare-replace proposal，执行前核对旧session/path，持久transition与checkpoint后才发布替换结果。普通resume/open全局jobs/steers gate较保守，with_commit防checkpoint拒绝后先丢旧Agent。多project审批从对应coordinator接收，显式取消外project目标拒绝；/cancel只选当前project最小prompt/steer jobID，不包括user_shell/resource/new，应使用typed cancel target。steer等原turn ID可见才FIFO cancel+reissue，队列满保留pending并限本轮attempt次数，无turn ID时仍保持Steer不降格新prompt。

**同步和slash共享调度（6632–8497）。** execute_headless_slash是领域/配置/会话等dispatch hub；sync handle_command另外覆盖tool_output/tree/input_queue，但Project与/new要求owned async host，typed cancel/approve在sync不可用，slash approval有共享Agent adapter。yolo/approval仅在拿到owner时修改configured policy，不能把mode变更理解为越过worker gate；models改用Agent项目profile，doctor/layout/pane仍配置global上下文；history1–128、内容4KiB；clear只清显示且durable_session=true；普通Goal/Learn执行与Blueprint open明确unsupported。runtime Compete/Loop持久意图借runtime_source单独指纹，与本机启动外部工作不同。compact共享core compaction，不保证只是deterministic剪裁。

`/diff`直接走slash_actions::diff_value_for_agent；忙时execute_headless_slash(None)仍执行，该helper退回process cwd。选择B且B忙、进程cwd为A时会读A差异，尽管response归属B——这是明确静态项目隔离缺口，应把已捕获project.cwd传给diff_value_at而非缺owner回退。`git_diff_process`虽然literal pathspec、禁ext-diff/textconv、限64KiB并kill超量child，读stdout及wait无deadline；它还同步占host循环，不能套用后台resource取消保证。审批preview不同：core准备preview、在approval request携preview/source hash，headless只投影并路由回复；它不重算preview，不把UI看过的diff当审批凭证，真正ExecuteApproved由下层负责。

同步typed UserShell成功分支（8315附近）直接write_cached_response，未像slash UserShell成功分支那样write_events；run_headless也无每命令兜底drain。因此该请求产生的AgentEvent可能滞留、之后由别的请求排出，或直到关闭丢失。这个基线已有问题不能被“所有终态之前都有事件”概括掩盖。shutdown同步agent.close之后直接响应，也不构成所有close事件已发的证明。

**mailbox与输出（8599–8897）。** send仅查当前session同目录唯一recipient，sender身份来自owner而非wire，enqueue不执行；receive最多64。claim用live owner和30s lease，complete查sender session后finish_live_mailbox_with_reply，reply与execution_started=false明确。send拒绝重复recipient，complete的sender查找却取首个匹配，唯一性由下层catalog保证与否不能由这段推出。最后match中Claim/Complete分支在前面已返回，实际余下是Acknowledge。write_cached_response先project投影、移除request_projects，再remember_terminal/WAL，stdout失败后可重放。直接write_response没有project注入：除不带合法ID的parse错误外，runtime Rejected QueueFull（4995–5003）与Resume summary等也丢v2 project；这是可定位响应一致性问题，应统一必要的project投影再release。

**测试源与限制。** 本轮读了全部11个current内嵌测试、7个baseline内嵌测试；新增三项验证reset保留pending身份、跨重启unknown、target冲突不替换source reservation，新增一项验证admission可挤出满tool lifecycle buffer；原七项验证canonical tool blocks、超大provider丢弃、byte budget/reset、admission accounting、count/byte满窗口和交错marker顺序。测试源码不等同于执行结果，更不涵盖所有多project关闭竞态。

另外完整阅读并冻结 `tests/headless_event_budget.rs`227行与`tests/headless_project_workspace.rs`583行：前者以GateWriter阻塞输出、provider继续flood，断言精确丢弃字节和drop先于terminal；后者12项测试正文覆盖project幂等/重启、busy切换归属和审批、invalid/cancel/foreign请求不改selection、checkpoint stale/corrupt/symlink、TUI与JSONL共同owner、严格schema/重复字段、selected tree mutation、容量与权限失败、resources/resume边界、resume重启、checkpoint失败保留persona再成功重试。Unix/权限/时序fixture有环境前提。本轮不运行这些测试；headless_protocol、headless_domain_owner、session_new等仅发现文件名，没有冒充其完整阅读或通过结果。其它owner的历史runtime receipts不作为084 current的新通过证据。

**具体修复优先序与后续验证。** 先修busy `/diff`项目root和同步阻塞取消边界，接着明确shutdown真实终止/回收状态与非合作owner锁回收。再统一直接response的v2 project、修sync UserShell成功事件drain、修显式Blueprint版本回退。Learn声明导入应保留候选语义并在独立验收边界核实artifact，而不是扩大accepted含义。resume/input ticket、WAL跨项目迁移部分写入、各种跨store取消/Done中途失败需要后续有授权的定向测试。本报告没有把静态问题写成已复现漏洞，也未自动修产品来覆盖其它owner的工作。

**本轮验收交付。** canonical新文件与candidate/rollback两份单文件patch，临时Git仓库实际apply/check、重复apply拒绝、reverse与无关sentinel不变；gfile复算source/chunks/索引/diff/引用/报告，G-stage按主blueprint只读运行，缺ZS1-084.master.json仍是未master验收。最终ready manifest覆盖全部payload，便携verify在包外输出新receipt。旧87个ready包13292个regular files及145个tracked文件做before/after字节保全；主src/headless.rs与主canonical缺失状态在freeze时再检查。本轮Cargo、Node、PTY、HTTP、网络与产品/测试执行均为0；仅Python/Git离线证据检查。准确exit、时间与log SHA见commands，不预填运行时间或伪造通过。

## 全部声明定位索引


### baseline


types_and_aliases（起点，正文解释按责任段落查阅）

- L80 `struct TerminalRecord {`
- L86 `enum RequestIdAdmission {`
- L98 `enum ReconnectEntry {`
- L124 `struct ReplayReport {`
- L132 `struct ReplayState {`
- L467 `pub enum HeadlessError {`
- L657 `enum Frame {`
- L741 `struct AsyncWork {`
- L752 `enum AsyncProcessResult {`
- L761 `struct BufferedEvent<T> {`
- L767 `struct DroppedEvents {`
- L786 `struct AsyncEventBuffer {`
- L811 `struct ByteCounter(usize);`
- L980 `struct PendingSteer {`
- L2752 `struct LearnResultManifest {`
- L3531 `enum AsyncTurn {`
- L3540 `struct AsyncRequest {`
- L3546 `type ProviderEventQueue = Arc<Mutex<AsyncEventBuffer>>;`
- L3547 `type StartedTurn = Arc<Mutex<Option<String>>>;`
- L3548 `type AsyncRequestParts = (AsyncRequest, ProviderEventQueue, StartedTurn);`
- L3598 `enum EventMailboxStream {`
- L3937 `enum ReaderMessage {`
- L5639 `enum SlashExecution {`
- L5695 `struct SlashDispatchError {`
- L5706 `enum GoalOwnerAction {`

functions（起点，正文解释按责任段落查阅）

- L153 `fn open(session: &SessionStore) -> Result<Self, HeadlessError> {`
- L191 `fn persist(&mut self, entry: ReconnectEntry) -> Result<(), HeadlessError> {`
- L200 `fn close(&mut self) -> Result<(), HeadlessError> {`
- L208 `fn remember_event(&mut self, sequence: u64, line: String) -> Result<(), HeadlessError> {`
- L217 `fn cache_event(&mut self, sequence: u64, line: String) {`
- L236 `fn replay_from<W: Write>(`
- L266 `fn admit(`
- L315 `fn cached_line(&self, request_id: &str) -> Option<&str> {`
- L321 `fn release(&mut self, request_id: Option<&str>) -> Result<(), HeadlessError> {`
- L336 `fn reset_for_session(`
- L370 `fn remember_terminal(&mut self, request_id: String, line: String) -> Result<(), HeadlessError> {`
- L386 `fn cache_terminal(&mut self, request_id: String, line: String) {`
- L426 `fn request_fingerprint(request: &StdioRequest) -> Result<String, HeadlessError> {`
- L448 `fn is_runtime_intent_request(request: &StdioRequest) -> bool {`
- L453 `fn replay_terminal_line(line: &str, version: u16) -> Result<String, HeadlessError> {`
- L483 `pub fn run_headless<R: BufRead, W: Write>(`
- L666 `fn read_frame<R: BufRead>(input: &mut R, frame: &mut Vec<u8>) -> io::Result<Frame> {`
- L713 `pub fn run_stdio(agent: &mut Agent) -> Result<(), HeadlessError> {`
- L724 `pub fn run_stdio_owned(agent: Agent) -> Result<(), HeadlessError> {`
- L733 `pub fn run_async_streams<R: io::Read + Send + 'static, W: Write>(`
- L773 `fn record(&mut self, bytes: usize) {`
- L780 `fn is_empty(self) -> bool {`
- L797 `fn event_mailbox_headless_error() -> HeadlessError {`
- L801 `fn event_mailbox_agent_error() -> AgentError {`
- L805 `fn event_mailbox_backend_error() -> crate::backend::BackendError {`
- L809 `fn serialized_event_len<T: serde::Serialize>(event: &T) -> usize {`
- L814 `fn write(&mut self, bytes: &[u8]) -> io::Result<usize> {`
- L819 `fn flush(&mut self) -> io::Result<()> {`
- L831 `fn is_admission_event(event: &AgentEvent) -> bool {`
- L838 `fn buffered_admission_prefix_len(events: &[BufferedEvent<AgentEvent>]) -> Option<usize> {`
- L849 `fn admission_prefix_len(events: &[AgentEvent]) -> Option<usize> {`
- L857 `fn push_provider(&mut self, event: ProviderEvent) {`
- L873 `fn push_agent(&mut self, event: AgentEvent) {`
- L934 `fn take_provider(&mut self) -> (Vec<ProviderEvent>, DroppedEvents) {`
- L944 `fn take_agent(&mut self) -> (Vec<AgentEvent>, DroppedEvents) {`
- L962 `fn take_admission(&mut self) -> Vec<AgentEvent> {`
- L990 `fn enqueue_pending_steer<W: Write>(`
- L1016 `pub fn collect_resource_snapshot(`
- L1035 `fn resolve_workspace_path(raw: &str) -> Result<PathBuf, String> {`
- L1085 `fn domain_store_for_agent(`
- L1110 `fn serialized_store_summary(store: &DomainStore) -> Result<serde_json::Value, SlashDispatchError> {`
- L1130 `fn serialized_domain_store(store: &DomainStore) -> Result<serde_json::Value, SlashDispatchError> {`
- L1192 `pub fn serialized_resource_snapshot(`
- L1205 `fn append_bounded_domain_records<T: serde::Serialize>(`
- L1244 `fn read_bounded_blueprint_bytes(path: &Path) -> Result<Vec<u8>, SlashDispatchError> {`
- L1293 `fn decode_blueprint_bytes(bytes: &[u8]) -> Result<crate::domains::Blueprint, SlashDispatchError> {`
- L1304 `fn first_json_kind(bytes: &[u8]) -> Option<String> {`
- L1318 `fn validate_blueprint_target(path: &str) -> Result<serde_json::Value, SlashDispatchError> {`
- L1351 `pub fn domain_store_view(agent: Option<&Agent>) -> Result<serde_json::Value, String> {`
- L1358 `pub fn blueprint_validation_view(path: &str) -> Result<serde_json::Value, String> {`
- L1366 `pub fn list_session_summaries() -> Result<Vec<SessionSummary>, String> {`
- L1373 `pub fn session_list_view() -> Result<serde_json::Value, String> {`
- L1389 `pub fn session_search_view(query: &str) -> Result<serde_json::Value, String> {`
- L1396 `pub fn session_search_view_in(`
- L1421 `pub fn open_session_path(agent: &mut Agent, raw_path: &str) -> Result<serde_json::Value, String> {`
- L1442 `pub fn session_maintenance_view(`
- L1509 `pub fn session_lifecycle_view(`
- L1696 `fn serialized_catalog_entry(entry: &crate::session::SessionCatalogEntry) -> serde_json::Value {`
- L1705 `fn same_path(left: &Path, right: &Path) -> bool {`
- L1709 `fn session_action_name(action: &crate::slash::SessionAction) -> &'static str {`
- L1734 `pub fn resume_last_session_view(agent: &mut Agent) -> Result<serde_json::Value, String> {`
- L1756 `pub fn recovery_view(`
- L1822 `pub fn mailbox_slash_view(`
- L1880 `pub fn session_gc_view(`
- L1891 `pub fn session_gc_view_at(`
- L1948 `fn validate_clean_session_source(source: &SessionStore, operation: &str) -> Result<(), String> {`
- L1961 `fn validate_session_destination_path(raw_path: &str) -> Result<PathBuf, String> {`
- L1991 `pub fn resume_session_view(`
- L2123 `fn project_session_record(record: &crate::session::SessionRecord) -> serde_json::Value {`
- L2180 `pub fn compact_context_view(agent: &mut Agent) -> Result<serde_json::Value, String> {`
- L2199 `fn serialized_session_summary(summary: &SessionSummary) -> serde_json::Value {`
- L2214 `fn serialized_agent_snapshot(agent: &Agent) -> Result<serde_json::Value, serde_json::Error> {`
- L2220 `fn redact_session_path(raw: &str) -> String {`
- L2240 `fn validate_existing_session_path(raw_path: &str) -> Result<PathBuf, String> {`
- L2270 `fn read_domain_json<T: DeserializeOwned>(`
- L2324 `fn persist_blueprint_from_path(`
- L2362 `fn create_blueprint_from_plan(`
- L2436 `pub fn create_blueprint_from_plan_for_tui(`
- L2443 `pub fn blueprint_handoffs_view(agent: &Agent) -> Result<serde_json::Value, String> {`
- L2482 `fn persist_goal_from_path(`
- L2520 `fn create_goal_from_blueprint(`
- L2583 `pub fn create_goal_from_blueprint_for_tui(`
- L2591 `fn persist_learn_from_path(`
- L2634 `fn add_learn_evidence_from_ref(`
- L2715 `fn resume_learn_view(`
- L2761 `fn import_learn_manifest(`
- L2907 `pub fn import_learn_manifest_for_tui(`
- L2919 `pub fn run_blueprint_next(agent: &mut Agent, target: &str) -> Result<serde_json::Value, String> {`
- L3060 `pub fn run_goal_steps_for_tui(`
- L3090 `fn run_goal_steps(`
- L3103 `pub fn handoff_blueprint_next(`
- L3173 `pub fn import_blueprint_manifest(`
- L3249 `fn sync_goal_status_after_execution(`
- L3280 `fn validate_domain_id(value: &str, field: &'static str) -> Result<(), SlashDispatchError> {`
- L3296 `fn learn_evidence_receipt(`
- L3372 `pub fn persist_blueprint_path(agent: &mut Agent, path: &str) -> Result<serde_json::Value, String> {`
- L3377 `pub fn persist_goal_path(agent: &mut Agent, path: &str) -> Result<serde_json::Value, String> {`
- L3382 `pub fn persist_learn_path(agent: &mut Agent, path: &str) -> Result<serde_json::Value, String> {`
- L3389 `pub fn add_learn_evidence(`
- L3399 `pub fn resume_learn(agent: &Agent, id: &str) -> Result<serde_json::Value, String> {`
- L3403 `fn request_in_flight(`
- L3417 `fn cancel_pending_steers_for_job<W: Write>(`
- L3447 `fn cancel_pending_steer_by_id<W: Write>(`
- L3476 `fn runtime_error_details(reason: crate::runtime::SubmitError) -> (&'static str, &'static str) {`
- L3489 `fn write_runtime_rejection<W: Write>(`
- L3513 `fn write_retryable_response<W: Write>(`
- L3522 `fn write_cached_versioned_response<W: Write>(`
- L3551 `fn new(request: TurnInputRequest) -> AsyncRequestParts {`
- L3565 `fn reissue(message: String, superseded_turn_id: String) -> AsyncRequestParts {`
- L3582 `fn user_shell(input: String) -> AsyncRequestParts {`
- L3604 `const fn name(self) -> &'static str {`
- L3611 `const fn max_events(self) -> usize {`
- L3618 `const fn max_bytes(self) -> usize {`
- L3626 `fn write_dropped_event<W: Write>(`
- L3656 `fn drain_provider_events<W: Write>(`
- L3738 `fn drain_approval_events<W: Write>(`
- L3809 `fn drain_provider_events_for_job<W: Write>(`
- L3880 `fn provider_event_block(event: &crate::backend::ProviderEvent) -> Option<serde_json::Value> {`
- L3915 `fn write_runtime_lifecycle_event<W: Write>(`
- L3945 `fn run_async_stdio<R: io::Read + Send + 'static, W: Write>(`
- L4311 `fn handle_runtime_event<W: Write>(`
- L4556 `fn process_async_line<W, F>(`
- L5440 `fn promote_pending_steers<W, F>(`
- L5650 `fn slash_execution_response(`
- L5683 `fn unsupported_session_maintenance_parse_error(error: &crate::slash::SlashError) -> Option<String> {`
- L5728 `fn parse_goal_owner_action(`
- L5870 `fn headless_layout_action(`
- L5911 `fn headless_pane_action(`
- L6001 `fn map_goal_store_error(`
- L6029 `fn goal_status_response(`
- L6104 `pub fn transition_goal_status(`
- L6115 `pub fn respond_to_slash_approval(`
- L6151 `fn execute_headless_slash(`
- L6907 `fn slash_runtime_fingerprint(`
- L6928 `fn bound_slash_text(value: &str, max_bytes: usize) -> String {`
- L6939 `fn handle_command<W: Write>(`
- L7397 `pub fn inspect_checkpoint(agent: &Agent) -> crate::protocol::CheckpointInspection {`
- L7409 `fn checkpoint_response(`
- L7496 `fn mailbox_response(`
- L7509 `fn execute_mailbox(`
- L7651 `fn admission_error(`
- L7674 `fn write_response<W: Write>(output: &mut W, response: StdioResponse) -> Result<(), HeadlessError> {`
- L7681 `fn write_cached_response<W: Write>(`
- L7696 `fn write_events<W: Write>(`
- L7712 `fn write_buffered_events<W: Write>(`
- L7752 `fn agent_event_block(event: &AgentEvent) -> Option<serde_json::Value> {`
- L7790 `fn agent_lifecycle_events_project_to_canonical_blocks() {`
- L7809 `fn oversized_provider_event_is_counted_but_never_retained() {`
- L7835 `fn provider_byte_budget_and_take_reset_all_accounting() {`
- L7868 `fn agent_admission_drain_and_oversize_drop_keep_exact_bytes() {`
- L7906 `fn admission_marker_survives_full_count_mailbox() {`
- L7930 `fn admission_marker_survives_full_byte_mailbox() {`
- L7968 `fn interleaved_admission_markers_are_drained_before_provider_events() {`

### current


types_and_aliases（起点，正文解释按责任段落查阅）

- L81 `struct TerminalRecord {`
- L87 `enum RequestIdAdmission {`
- L99 `enum ReconnectEntry {`
- L125 `struct ReplayReport {`
- L133 `struct ReplayState {`
- L517 `pub enum HeadlessError {`
- L707 `enum Frame {`
- L791 `struct AsyncWork {`
- L803 `enum AsyncProcessResult {`
- L814 `struct BufferedEvent<T> {`
- L820 `struct DroppedEvents {`
- L839 `struct AsyncEventBuffer {`
- L864 `struct ByteCounter(usize);`
- L1046 `struct PendingSteer {`
- L2871 `struct LearnResultManifest {`
- L3778 `enum AsyncTurn {`
- L3791 `struct AsyncRequest {`
- L3799 `type ProviderEventQueue = Arc<Mutex<AsyncEventBuffer>>;`
- L3800 `type StartedTurn = Arc<Mutex<Option<String>>>;`
- L3801 `type AsyncRequestParts = (AsyncRequest, ProviderEventQueue, StartedTurn);`
- L3880 `enum EventMailboxStream {`
- L4264 `enum ReaderMessage {`
- L5060 `struct PendingInputResponse {`
- L6627 `enum SlashExecution {`
- L6685 `struct SlashDispatchError {`
- L6696 `enum GoalOwnerAction {`

functions（起点，正文解释按责任段落查阅）

- L156 `fn project_response(&self, mut response: StdioResponse) -> StdioResponse {`
- L166 `fn open(session: &SessionStore) -> Result<Self, HeadlessError> {`
- L198 `fn open_unseeded(session: &SessionStore) -> Result<Self, HeadlessError> {`
- L236 `fn persist(&mut self, entry: ReconnectEntry) -> Result<(), HeadlessError> {`
- L245 `fn close(&mut self) -> Result<(), HeadlessError> {`
- L253 `fn remember_event(&mut self, sequence: u64, line: String) -> Result<(), HeadlessError> {`
- L262 `fn cache_event(&mut self, sequence: u64, line: String) {`
- L281 `fn replay_from<W: Write>(`
- L311 `fn admit(`
- L360 `fn cached_line(&self, request_id: &str) -> Option<&str> {`
- L366 `fn release(&mut self, request_id: Option<&str>) -> Result<(), HeadlessError> {`
- L384 `fn reset_for_session(`
- L420 `fn remember_terminal(&mut self, request_id: String, line: String) -> Result<(), HeadlessError> {`
- L436 `fn cache_terminal(&mut self, request_id: String, line: String) {`
- L476 `fn request_fingerprint(request: &StdioRequest) -> Result<String, HeadlessError> {`
- L498 `fn is_runtime_intent_request(request: &StdioRequest) -> bool {`
- L503 `fn replay_terminal_line(line: &str, version: u16) -> Result<String, HeadlessError> {`
- L533 `pub fn run_headless<R: BufRead, W: Write>(`
- L716 `fn read_frame<R: BufRead>(input: &mut R, frame: &mut Vec<u8>) -> io::Result<Frame> {`
- L763 `pub fn run_stdio(agent: &mut Agent) -> Result<(), HeadlessError> {`
- L774 `pub fn run_stdio_owned(agent: Agent) -> Result<(), HeadlessError> {`
- L783 `pub fn run_async_streams<R: io::Read + Send + 'static, W: Write>(`
- L826 `fn record(&mut self, bytes: usize) {`
- L833 `fn is_empty(self) -> bool {`
- L850 `fn event_mailbox_headless_error() -> HeadlessError {`
- L854 `fn event_mailbox_agent_error() -> AgentError {`
- L858 `fn event_mailbox_backend_error() -> crate::backend::BackendError {`
- L862 `fn serialized_event_len<T: serde::Serialize>(event: &T) -> usize {`
- L867 `fn write(&mut self, bytes: &[u8]) -> io::Result<usize> {`
- L872 `fn flush(&mut self) -> io::Result<()> {`
- L884 `fn is_admission_event(event: &AgentEvent) -> bool {`
- L891 `fn is_priority_agent_event(event: &AgentEvent) -> bool {`
- L899 `fn buffered_admission_prefix_len(events: &[BufferedEvent<AgentEvent>]) -> Option<usize> {`
- L910 `fn admission_prefix_len(events: &[AgentEvent]) -> Option<usize> {`
- L918 `fn push_provider(&mut self, event: ProviderEvent) {`
- L934 `fn push_agent(&mut self, event: AgentEvent) {`
- L1000 `fn take_provider(&mut self) -> (Vec<ProviderEvent>, DroppedEvents) {`
- L1010 `fn take_agent(&mut self) -> (Vec<AgentEvent>, DroppedEvents) {`
- L1028 `fn take_admission(&mut self) -> Vec<AgentEvent> {`
- L1058 `fn enqueue_pending_steer<W: Write>(`
- L1084 `pub fn collect_resource_snapshot(`
- L1090 `pub fn collect_resource_snapshot_at(`
- L1103 `fn owner_workspace(agent: Option<&Agent>) -> Result<PathBuf, SlashDispatchError> {`
- L1119 `fn resolve_workspace_path_at(raw: &str, workspace: &Path) -> Result<PathBuf, String> {`
- L1168 `fn domain_store_for_agent(`
- L1193 `fn serialized_store_summary(store: &DomainStore) -> Result<serde_json::Value, SlashDispatchError> {`
- L1213 `fn serialized_domain_store(store: &DomainStore) -> Result<serde_json::Value, SlashDispatchError> {`
- L1275 `pub fn serialized_resource_snapshot(`
- L1288 `fn append_bounded_domain_records<T: serde::Serialize>(`
- L1327 `fn read_bounded_blueprint_bytes(path: &Path) -> Result<Vec<u8>, SlashDispatchError> {`
- L1376 `fn decode_blueprint_bytes(bytes: &[u8]) -> Result<crate::domains::Blueprint, SlashDispatchError> {`
- L1387 `fn first_json_kind(bytes: &[u8]) -> Option<String> {`
- L1401 `fn validate_blueprint_target(`
- L1438 `pub fn domain_store_view(agent: Option<&Agent>) -> Result<serde_json::Value, String> {`
- L1445 `pub fn blueprint_validation_view(path: &str) -> Result<serde_json::Value, String> {`
- L1449 `pub fn blueprint_validation_view_at(`
- L1460 `pub fn list_session_summaries() -> Result<Vec<SessionSummary>, String> {`
- L1467 `pub fn session_list_view() -> Result<serde_json::Value, String> {`
- L1483 `pub fn session_search_view(query: &str) -> Result<serde_json::Value, String> {`
- L1490 `pub fn session_search_view_in(`
- L1515 `pub fn open_session_path(agent: &mut Agent, raw_path: &str) -> Result<serde_json::Value, String> {`
- L1519 `pub(crate) fn open_session_path_with_commit(`
- L1544 `pub fn session_maintenance_view(`
- L1611 `pub fn session_lifecycle_view(`
- L1798 `fn serialized_catalog_entry(entry: &crate::session::SessionCatalogEntry) -> serde_json::Value {`
- L1807 `fn same_path(left: &Path, right: &Path) -> bool {`
- L1811 `fn session_action_name(action: &crate::slash::SessionAction) -> &'static str {`
- L1837 `pub fn resume_last_session_view(agent: &mut Agent) -> Result<serde_json::Value, String> {`
- L1841 `pub(crate) fn resume_last_session_view_with_commit(`
- L1866 `pub fn recovery_view(`
- L1932 `pub fn mailbox_slash_view(`
- L1990 `pub fn session_gc_view(`
- L2001 `pub fn session_gc_view_at(`
- L2058 `fn validate_clean_session_source(source: &SessionStore, operation: &str) -> Result<(), String> {`
- L2071 `fn validate_session_destination_path(raw_path: &str) -> Result<PathBuf, String> {`
- L2101 `pub fn resume_session_view(`
- L2233 `fn project_session_record(record: &crate::session::SessionRecord) -> serde_json::Value {`
- L2290 `pub fn compact_context_view(agent: &mut Agent) -> Result<serde_json::Value, String> {`
- L2309 `fn serialized_session_summary(summary: &SessionSummary) -> serde_json::Value {`
- L2324 `fn serialized_agent_snapshot(agent: &Agent) -> Result<serde_json::Value, serde_json::Error> {`
- L2330 `fn redact_session_path(raw: &str) -> String {`
- L2350 `fn validate_existing_session_path(raw_path: &str) -> Result<PathBuf, String> {`
- L2380 `fn read_domain_json<T: DeserializeOwned>(`
- L2434 `fn persist_blueprint_from_path(`
- L2474 `fn create_blueprint_from_plan(`
- L2548 `pub fn create_blueprint_from_plan_for_tui(`
- L2555 `pub fn blueprint_handoffs_view(agent: &Agent) -> Result<serde_json::Value, String> {`
- L2596 `fn persist_goal_from_path(`
- L2636 `fn create_goal_from_blueprint(`
- L2699 `pub fn create_goal_from_blueprint_for_tui(`
- L2707 `fn persist_learn_from_path(`
- L2752 `fn add_learn_evidence_from_ref(`
- L2834 `fn resume_learn_view(`
- L2880 `fn import_learn_manifest(`
- L3029 `pub fn import_learn_manifest_for_tui(`
- L3041 `pub fn run_blueprint_next(agent: &mut Agent, target: &str) -> Result<serde_json::Value, String> {`
- L3182 `pub fn run_goal_steps_for_tui(`
- L3212 `fn run_goal_steps(`
- L3225 `pub fn handoff_blueprint_next(`
- L3293 `pub fn external_evidence_action(`
- L3384 `pub fn external_evidence_input(`
- L3409 `pub fn import_blueprint_manifest(`
- L3494 `fn sync_goal_status_after_execution(`
- L3523 `fn validate_domain_id(value: &str, field: &'static str) -> Result<(), SlashDispatchError> {`
- L3539 `fn learn_evidence_receipt(`
- L3615 `pub fn persist_blueprint_path(agent: &mut Agent, path: &str) -> Result<serde_json::Value, String> {`
- L3620 `pub fn persist_goal_path(agent: &mut Agent, path: &str) -> Result<serde_json::Value, String> {`
- L3625 `pub fn persist_learn_path(agent: &mut Agent, path: &str) -> Result<serde_json::Value, String> {`
- L3632 `pub fn add_learn_evidence(`
- L3642 `pub fn resume_learn(agent: &Agent, id: &str) -> Result<serde_json::Value, String> {`
- L3646 `fn request_in_flight(`
- L3660 `fn cancel_pending_steers_for_job<W: Write>(`
- L3691 `fn cancel_pending_steer_by_id<W: Write>(`
- L3721 `fn runtime_error_details(reason: crate::runtime::SubmitError) -> (&'static str, &'static str) {`
- L3734 `fn write_runtime_rejection<W: Write>(`
- L3759 `fn write_retryable_response<W: Write>(`
- L3769 `fn write_cached_versioned_response<W: Write>(`
- L3804 `fn with_owner(mut self, owner: &Arc<Mutex<Agent>>, project: &ProjectContext) -> Self {`
- L3810 `fn new(request: TurnInputRequest) -> AsyncRequestParts {`
- L3826 `fn reissue(message: String, superseded_turn_id: String) -> AsyncRequestParts {`
- L3845 `fn tool_output(request: crate::protocol::OutputRequest) -> AsyncRequestParts {`
- L3850 `fn tree(request: crate::protocol::TreeRequest) -> AsyncRequestParts {`
- L3856 `fn resource_control(input: String) -> AsyncRequestParts {`
- L3862 `fn user_shell(input: String) -> AsyncRequestParts {`
- L3886 `const fn name(self) -> &'static str {`
- L3893 `const fn max_events(self) -> usize {`
- L3900 `const fn max_bytes(self) -> usize {`
- L3908 `fn write_dropped_event<W: Write>(`
- L3939 `fn drain_provider_events<W: Write>(`
- L4043 `fn drain_approval_events<W: Write>(`
- L4117 `fn drain_provider_events_for_job<W: Write>(`
- L4205 `fn provider_event_block(event: &crate::backend::ProviderEvent) -> Option<serde_json::Value> {`
- L4240 `fn write_runtime_lifecycle_event<W: Write>(`
- L4272 `fn run_async_stdio<R: io::Read + Send + 'static, W: Write>(`
- L4760 `fn handle_runtime_event<W: Write>(`
- L5025 `fn queue_slash_command(`
- L5066 `fn input_response(`
- L5075 `fn drain_input_responses<W: Write>(`
- L5105 `fn process_async_line<W, F>(`
- L6425 `fn promote_pending_steers<W, F>(`
- L6638 `fn slash_execution_response(`
- L6673 `fn unsupported_session_maintenance_parse_error(error: &crate::slash::SlashError) -> Option<String> {`
- L6718 `fn parse_goal_owner_action(`
- L6860 `fn headless_layout_action(`
- L6901 `fn headless_pane_action(`
- L6991 `fn map_goal_store_error(`
- L7019 `fn goal_status_response(`
- L7094 `pub fn transition_goal_status(`
- L7105 `pub fn respond_to_slash_approval(`
- L7141 `fn execute_headless_slash(`
- L7920 `fn slash_runtime_fingerprint(`
- L7941 `fn bound_slash_text(value: &str, max_bytes: usize) -> String {`
- L7952 `fn handle_command<W: Write>(`
- L8500 `pub fn inspect_checkpoint(agent: &Agent) -> crate::protocol::CheckpointInspection {`
- L8512 `fn checkpoint_response(`
- L8599 `fn mailbox_response(`
- L8612 `fn execute_mailbox(`
- L8754 `fn admission_error(`
- L8777 `fn write_response<W: Write>(output: &mut W, response: StdioResponse) -> Result<(), HeadlessError> {`
- L8784 `fn write_cached_response<W: Write>(`
- L8803 `fn write_events<W: Write>(`
- L8819 `fn write_buffered_events<W: Write>(`
- L8862 `fn agent_event_block(event: &AgentEvent) -> Option<serde_json::Value> {`
- L8904 `fn session_reset_preserves_pending_identity_and_durable_terminal_replay() {`
- L8965 `fn session_reset_keeps_unfinished_foreign_request_unknown_after_restart() {`
- L8985 `fn conflicting_target_does_not_replace_the_live_source_reservation() {`
- L9011 `fn admission_still_takes_priority_over_a_full_tool_lifecycle_mailbox() {`
- L9030 `fn agent_lifecycle_events_project_to_canonical_blocks() {`
- L9049 `fn oversized_provider_event_is_counted_but_never_retained() {`
- L9075 `fn provider_byte_budget_and_take_reset_all_accounting() {`
- L9108 `fn agent_admission_drain_and_oversize_drop_keep_exact_bytes() {`
- L9146 `fn admission_marker_survives_full_count_mailbox() {`
- L9170 `fn admission_marker_survives_full_byte_mailbox() {`
- L9208 `fn interleaved_admission_markers_are_drained_before_provider_events() {`
