from pathlib import Path
import os,stat,json,hashlib,shutil,datetime
W=Path(__file__).resolve().parent;P=W.parent/'stage132-busy-diff320-ready';M=Path('/Users/wangweiyang/GitHub/zenpi')
def info(p):
 assert stat.S_ISREG(p.lstat().st_mode),str(p);b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def inv(root):
 out={}
 for d,ds,fs in os.walk(root,followlinks=False):
  ds[:]=[n for n in ds if not Path(d,n).is_symlink()]
  for n in fs:
   p=Path(d,n)
   if stat.S_ISREG(p.lstat().st_mode):out[str(p.relative_to(root))]=info(p)
 return out
def cp(a,b):b.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(a,b)
def dump(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
assert not P.exists();before=json.loads((W/'preservation-before.json').read_text())
for root,files in before['ready'].items():assert inv(Path(root))==files,root
for path,row in before['tracked'].items():assert info(Path(path))==row,path
inputs=json.loads((W/'build-inputs.json').read_text());assert inv(W/'build-input')==inputs
assert info(M/'src/headless.rs')==inputs['src/headless.rs'];assert info(M/'src/slash_actions.rs')==inputs['src/slash_actions.rs']
drift=[rel for rel,row in inputs.items() if not (M/rel).is_file() or info(M/rel)!=row]
for name in ['before-release-02','matching-before-03']:
 r=json.loads((W/name/'result.json').read_text());assert r['status']=='failed' and 'exception' not in r
 assert [k for k,v in r['checks'].items() if not v]==['B-before-new','B-after-new','B-after-switch-back','B-before-cancel']
r=json.loads((W/'after-frozen-02/result.json').read_text());assert r['status']=='passed' and all(r['checks'].values());assert info(W/'binaries/zenpi-candidate')['sha256']==r['binary_sha256']
dump(W/'preservation-after.json',{'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'old_ready_packages':len(before['ready']),'old_ready_regular_files':sum(len(v) for v in before['ready'].values()),'tracked_regular_files':len(before['tracked']),'all_preserved':True,'main_headless_and_slash_actions_unchanged':True,'other_main_build_input_drift':drift,'candidate_product_files':['src/headless.rs'],'main_product_modified_by_worker':False})
cp(W/'candidate-build/src/headless.rs',P/'files/src/headless.rs')
for name in ['candidate.patch','rollback.patch','review.md','verify.py']:cp(W/name,P/name)
excluded={'cargo-target','before-cargo-target','candidate-build','integration-fixture-home'}
symlinks=[]
for d,ds,fs in os.walk(W,followlinks=False):
 rel=Path(d).relative_to(W)
 ds[:]=[n for n in ds if not (rel==Path('.') and n in excluded)]
 for n in ds+fs:
  f=Path(d,n)
  if f.is_symlink():symlinks.append({'path':str(f.relative_to(W)),'target':os.readlink(f)})
for rel,row in inv(W).items():
 if rel.split('/')[0] in excluded or rel in ['candidate.patch','rollback.patch','review.md','verify.py']:continue
 cp(W/rel,P/'evidence'/rel)
dump(P/'fixture-symlinks.json',{'method':'Symlinks are recorded as text and not recreated in portable evidence; original fixture directories remain untouched.','entries':symlinks})
for n in ['zenpi-candidate','zenpi-coordinator-before','zenpi-matching-before']:(P/'evidence/binaries'/n).chmod(0o755)
manifest={'scope':'ZS1-132 / ZS1-123 busy headless diff ownership increment only','master_acceptance':False,'candidate_files':['src/headless.rs'],'before':inputs['src/headless.rs'],'after':info(P/'files/src/headless.rs'),'build_inputs':len(inputs),'baseline_binary':info(P/'evidence/binaries/zenpi-coordinator-before'),'matching_before_binary':info(P/'evidence/binaries/zenpi-matching-before'),'candidate_binary':info(P/'evidence/binaries/zenpi-candidate'),'patches':{n:info(P/n) for n in ['candidate.patch','rollback.patch']},'files':[{'path':rel,**row} for rel,row in sorted(inv(P).items())],'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
dump(P/'manifest.json',manifest);print(json.dumps({'ready':str(P),'manifest':info(P/'manifest.json'),'payload_files':len(manifest['files']),'candidate':manifest['after'],'patches':manifest['patches'],'main_input_drift':drift}))
