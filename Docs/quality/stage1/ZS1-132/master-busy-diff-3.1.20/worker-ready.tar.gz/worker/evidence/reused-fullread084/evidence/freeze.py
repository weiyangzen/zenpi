from pathlib import Path
import datetime,hashlib,json,os,stat,shutil,sys
W=Path(__file__).resolve().parent;P=W.parent/'target084-current320-ready';M=Path('/Users/wangweiyang/GitHub/zenpi');R=W.parent.parent;REPORT='Docs/learn/stage1_pi_mono/targets/zenpi/files/src/headless.rs_learn.md';PATCHES=['candidate.patch','rollback.patch']
def info(p):
 assert stat.S_ISREG(p.lstat().st_mode);b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def inv(root):
 out={}
 for d,ds,fs in os.walk(root,followlinks=False):
  ds[:]=[n for n in ds if not Path(d,n).is_symlink()]
  for n in fs:
   p=Path(d,n)
   if stat.S_ISREG(p.lstat().st_mode):out[str(p.relative_to(root))]=info(p)
 return out
def dump(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def cp(a,b):b.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(a,b)
assert not P.exists();pres=json.loads((W/'preservation-before.json').read_text())
for p,expected in pres['ready'].items():assert inv(Path(p))==expected,p
for p,row in pres['tracked'].items():assert info(Path(p))==row,p
assert info(M/'src/headless.rs')==info(W/'current-headless.rs');assert not (M/REPORT).exists();assert (R/REPORT).read_bytes()==(W/'files'/REPORT).read_bytes()
for row in json.loads((W/'references-current.json').read_text()):assert info(Path(row['source_path']))=={k:row[k] for k in ['bytes','sha256']}
sys.path.insert(0,str(W/'validation-tools'));import validate_stage1_blueprint as gate
cp(M/'Docs/stage_1_v3_pi_mono_blueprint.md',W/'validation-tools/blueprint-after-gate.md');bp=gate.parse((W/'validation-tools/blueprint-after-gate.md').read_text());binding=json.loads((W/'current-binding.json').read_text());assert bp.requirement==binding['requirement_digest'];assert bp.files['ZS1-084'].sha256==binding['baseline']['sha256']
selector=gate.selector(M,bp,'Docs/stage_1_v3_pi_mono_blueprint.md');cp(M/gate.SELECTOR,W/'validation-tools/active_requirement-after-gate.json');assert json.loads((W/'validation-tools/active_requirement-after-gate.json').read_text())==selector
dump(W/'preservation-after.json',{'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'old_ready_packages':len(pres['ready']),'old_ready_regular_files':sum(len(x) for x in pres['ready'].values()),'tracked_regular_files':len(pres['tracked']),'all_byte_identical':True,'main_headless_byte_identical':True,'current_references_byte_identical':True,'main_report_absent':True,'product_modified':False,'state_modified':False,'blueprint_after_gate_snapshot':bp.snapshot,'blueprint_initial_snapshot':binding['snapshot_sha256'],'blueprint_same_requirement_digest':True})
stage=json.loads((W/'commands/gstage-main.log').read_text());dump(W/'gate-disposition.json',{'item':'ZS1-084','gfile_exit':0,'patch_application_exit':0,'gstage_exit':1,'gstage_structural_ok':stage['structural']['ok'],'gstage_errors':stage['errors'],'master_acceptance':False,'product_runtime_executions':0,'snapshot_initial':binding['snapshot_sha256'],'snapshot_observed_after_gate':bp.snapshot,'requirement_digest':bp.requirement})
cp(W/'files'/REPORT,P/'files'/REPORT)
for n in PATCHES+['verify.py']:cp(W/n,P/n)
for rel in inv(W):
 if rel.split('/')[0] in ['tmp','files'] or rel in PATCHES+['verify.py']:continue
 cp(W/rel,P/'evidence'/rel)
manifest={'item':'ZS1-084','version':'3.1.20','owner':'C','requirement_digest':binding['requirement_digest'],'snapshot_sha256':binding['snapshot_sha256'],'report_path':REPORT,'report':info(P/'files'/REPORT),'prefix':binding['prefix'],'baseline':binding['baseline'],'current':binding['current'],'same_capture_alias':binding['previous-current'],'prior_complete_read_reused':False,'new_full_source_read_claim':True,'current_unchanged_lines':7758,'current_changed_or_added_lines':1471,'product_modified':False,'state_modified':False,'product_runtime_executions':0,'master_acceptance':False,'patches':{n:info(P/n) for n in PATCHES},'files':[{'path':rel,**row} for rel,row in sorted(inv(P).items())],'frozen_at':datetime.datetime.now(datetime.timezone.utc).isoformat()};dump(P/'manifest.json',manifest);print(json.dumps({'ready':str(P),'manifest':info(P/'manifest.json'),'report':manifest['report'],'files':len(manifest['files'])+1,'patches':manifest['patches'],'snapshot_after_gate':bp.snapshot}))
