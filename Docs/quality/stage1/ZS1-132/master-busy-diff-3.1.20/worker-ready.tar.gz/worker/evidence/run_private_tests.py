from pathlib import Path
import os,subprocess,json
w=Path(__file__).resolve().parent;home=w/'integration-fixture-home';home.mkdir(exist_ok=False)
env={k:v for k,v in os.environ.items() if not k.startswith(('ZENPI_','OPENAI_'))};env['ZENPI_HOME']=str(home);env['PYTHONDONTWRITEBYTECODE']='1'
assert env.get('HOME')==os.environ.get('HOME') and env.get('CODEX_HOME')==os.environ.get('CODEX_HOME')
argv=['cargo','+stable-aarch64-apple-darwin','test','--offline','--locked','-j','2','--release','--test','headless_project_workspace','--target-dir','../cargo-target','--','--test-threads=1'];print(json.dumps({'argv':argv,'fixture_ZENPI_HOME':str(home),'HOME_preserved':True,'CODEX_HOME_preserved':True}),flush=True)
p=subprocess.run(argv,cwd=w/'candidate-build',env=env);raise SystemExit(p.returncode)
