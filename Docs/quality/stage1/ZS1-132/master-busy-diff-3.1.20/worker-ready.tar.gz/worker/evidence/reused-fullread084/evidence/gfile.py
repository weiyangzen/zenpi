from pathlib import Path
import hashlib,json,sys,re,difflib
REPORT='Docs/learn/stage1_pi_mono/targets/zenpi/files/src/headless.rs_learn.md'
def info(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def read(p):return json.loads(p.read_text())
def check(root,files):
 sys.path.insert(0,str(root/'validation-tools'));import validate_stage1_blueprint as gate
 binding=read(root/'current-binding.json');bp=gate.parse((root/'validation-tools/blueprint.md').read_text());assert bp.requirement==binding['requirement_digest'] and bp.snapshot==binding['snapshot_sha256'];assert bp.files['ZS1-084'].artifact==REPORT and bp.files['ZS1-084'].sha256==binding['baseline']['sha256']
 rb=read(root/'read-binding.json');idx=read(root/'declaration-index.json');sources={}
 def chunks(data,rows,full=False):
  ls=data.splitlines(keepends=True)
  for c in rows:
   p=root/c['path'];assert info(p)=={k:c[k] for k in ['bytes','sha256']};assert p.read_bytes()==data[c['byte_start']:c['byte_end']]==b''.join(ls[c['line_start']-1:c['line_end']]);assert c['byte_start']==len(b''.join(ls[:c['line_start']-1])) and c['byte_end']==len(b''.join(ls[:c['line_end']]))
  if full:gate.check_ranges([[c['byte_start'],c['byte_end']] for c in rows],len(data));assert b''.join((root/c['path']).read_bytes() for c in rows)==data
 for label,total,nfunctions,ntypes,ntests,nchunks in [('baseline',7989,153,25,7,20),('current',9229,174,26,11,23)]:
  p=root/(label+'-headless.rs');assert info(p)=={k:binding[label][k] for k in ['bytes','sha256']};data=p.read_bytes();sources[label]=data;assert len(data.splitlines())==binding[label]['lines']==total;chunks(data,rb['full_reads'][label],True);assert len(rb['full_reads'][label])==nchunks
  lines=data.decode().splitlines();functions=[{'line':i,'signature':l.strip()} for i,l in enumerate(lines,1) if re.match(r'^\s*(?:pub(?:\([^)]*\))?\s+)?(?:const\s+)?fn\s',l)];types=[{'line':i,'signature':l.strip()} for i,l in enumerate(lines,1) if re.match(r'^\s*(?:pub(?:\([^)]*\))?\s+)?(?:struct|enum|type)\s',l)];assert idx[label]=={'functions':functions,'types_and_aliases':types,'inline_test_markers':ntests};assert len(functions)==nfunctions and len(types)==ntypes and data.count(b'#[test]')==ntests
 assert (root/'previous-current-headless.rs').read_bytes()==sources['current'];assert not (root/'previous-current-to-current.diff').read_bytes()
 a=sources['baseline'].decode().splitlines(keepends=True);b=sources['current'].decode().splitlines(keepends=True);diff=''.join(difflib.unified_diff(a,b,fromfile='baseline',tofile='current')).encode();assert (root/'baseline-to-current.diff').read_bytes()==diff;chunks(diff,rb['diff_reads'],True)
 delta=read(root/'delta-map.json');ops=[{'tag':t,'baseline_lines_half_open_zero_based':[x,y],'current_lines_half_open_zero_based':[z,q]} for t,x,y,z,q in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes()];assert delta['opcodes']==ops;assert delta['unified_hunks']==[l for l in diff.decode().splitlines() if l.startswith('@@')];assert delta['unchanged_current_lines']==7758 and delta['changed_or_added_current_lines']==1471
 assert info(root/'before-report.md')==binding['prefix'] and binding['prefix']['bytes']==0
 report=(files/REPORT).read_text();assert report.startswith((root/'report-body.md').read_text());gate.artifact(files,{'path':REPORT,**info(files/REPORT)})
 for label,x in idx.items():
  for rows in [x['functions'],x['types_and_aliases']]:
   for row in rows:assert '- L'+str(row['line'])+' `'+row['signature'].replace('`','')+'`' in report
 refs=read(root/'references-current.json')
 for row in refs:
  p=root/row['artifact'];assert info(p)=={k:row[k] for k in ['bytes','sha256']};chunks(p.read_bytes(),row['chunks'],row['full_read'])
  if row['full_read']:assert p.read_text().count('#[test]')==row['test_markers']
 return {'status':'passed','item':'ZS1-084','baseline_lines':7989,'current_lines':9229,'source_full_chunks':43,'diff_hunks':len(delta['unified_hunks']),'diff_full_chunks':4,'baseline_functions':153,'current_functions':174,'current_types_and_aliases':26,'inline_test_bodies_read':11,'additional_test_files_fully_read':2,'test_source_markers':sum(r['test_markers'] for r in refs if r['full_read']),'product_runtime_executions':0,'semantic_acceptance':False}
if __name__=='__main__':
 root=Path(__file__).resolve().parent;print(json.dumps(check(root,root/'files')))
