from pathlib import Path
import difflib,json
W=Path(__file__).resolve().parent;R=W.parent.parent;REPORT='Docs/learn/stage1_pi_mono/targets/zenpi/files/src/headless.rs_learn.md'
index=json.loads((W/'declaration-index.json').read_text());text=(W/'report-body.md').read_text()+'\n## 全部声明定位索引\n\n'
for label,x in index.items():
 text+='\n### '+label+'\n\n'
 for key in ['types_and_aliases','functions']:
  text+='\n'+key+'（起点，正文解释按责任段落查阅）\n\n'
  for row in x[key]:text+='- L'+str(row['line'])+' `'+row['signature'].replace('`','')+'`\n'
p=W/'files'/REPORT;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
assert not (R/REPORT).exists();(R/REPORT).parent.mkdir(parents=True,exist_ok=True);(R/REPORT).write_text(text)
for name,a,b in [('candidate.patch','',text),('rollback.patch',text,'')]:
 (W/name).write_text('diff --git a/'+REPORT+' b/'+REPORT+'\n'+('new file mode 100644\n' if not a else 'deleted file mode 100644\n')+''.join(difflib.unified_diff(a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile='a/'+REPORT if a else '/dev/null',tofile='b/'+REPORT if b else '/dev/null')))
print('report',p.stat().st_size,'lines',len(text.splitlines()))
