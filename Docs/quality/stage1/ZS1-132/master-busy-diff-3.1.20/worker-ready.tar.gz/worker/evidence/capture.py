from pathlib import Path
import os,stat,json,hashlib,shutil,subprocess,datetime
R=Path.cwd();M=Path('/Users/wangweiyang/GitHub/zenpi');W=R/'.ops/stage132-busy-diff320';W.mkdir(exist_ok=False)
def info(p):
 assert stat.S_ISREG(p.lstat().st_mode),str(p);b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def inv(p):
 out={}
 for d,ds,fs in os.walk(p,followlinks=False):
  ds[:]=[n for n in ds if not Path(d,n).is_symlink()]
  for n in fs:
   f=Path(d,n)
   if stat.S_ISREG(f.lstat().st_mode):out[str(f.relative_to(p))]=info(f)
 return out
def dump(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
roots=sorted(p for p in (R/'.ops').glob('*-ready') if p.is_dir())+[R/'.ops/stage125-render-review320/ready',R/'.ops/stage126-independent320/ready',R/'.ops/stage126-independent320/ready-final']
tracked={str(R/x.decode()):info(R/x.decode()) for x in subprocess.check_output(['git','ls-files','-z']).split(b'\0') if x and (R/x.decode()).is_file()}
dump(W/'preservation-before.json',{'ready':{str(p):inv(p) for p in roots},'tracked':tracked})
for h,rel in [('958837ad933fea4e55c3ac966f0c8d605dd03674a696e2ef0595b54aca628ef9','src/headless.rs'),('e8635a418ccd613ef0587695ee9318d05e679be202494c0f04eb04651c12184e','src/slash_actions.rs'),('e9ba9476f7699d715ad3b0b5fe4a07aeee9f280508d3cb495d59cfa94fff6449','.ops/stage1_execution/release-diff-20260912/zenpi')]:assert info(M/rel)['sha256']==h,rel
S=W/'build-input';S.mkdir()
for n in ['src','tests','tools','vendor']:
 for rel in inv(M/n):
  p=S/n/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(M/n/rel,p)
for n in ['Cargo.toml','Cargo.lock','README.md','build.rs','rust-toolchain.toml']:
 if (M/n).exists():shutil.copyfile(M/n,S/n)
if (M/'.cargo').is_dir():
 for rel in inv(M/'.cargo'):
  p=S/'.cargo'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(M/'.cargo'/rel,p)
dump(W/'build-inputs.json',inv(S))
old=R/'.ops/target084-current320-ready';shutil.copytree(old,W/'reused-fullread084');manifest=json.loads((old/'manifest.json').read_text());assert inv(old)==inv(W/'reused-fullread084')
assert (S/'src/headless.rs').read_bytes()==(old/'evidence/current-headless.rs').read_bytes();rb=json.loads((old/'evidence/read-binding.json').read_text());assert b''.join((old/'evidence'/c['path']).read_bytes() for c in rb['full_reads']['current'])==(S/'src/headless.rs').read_bytes()
dump(W/'capture.json',{'captured_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'main':str(M),'build_input_inventory':'build-inputs.json','headless':info(S/'src/headless.rs'),'slash_actions':info(S/'src/slash_actions.rs'),'baseline_binary':{'path':str(M/'.ops/stage1_execution/release-diff-20260912/zenpi'),**info(M/'.ops/stage1_execution/release-diff-20260912/zenpi')},'complete_read_reuse':{'package':str(old),'manifest':info(old/'manifest.json'),'current_chunks':23,'both_snapshots_chunks':43,'all_bytes_reassembled':True},'old_ready_count':len(roots),'old_ready_files':sum(len(v) for v in json.loads((W/'preservation-before.json').read_text())['ready'].values())})
shutil.copyfile(Path(__file__),W/'capture.py');print(json.dumps(json.loads((W/'capture.json').read_text())))
