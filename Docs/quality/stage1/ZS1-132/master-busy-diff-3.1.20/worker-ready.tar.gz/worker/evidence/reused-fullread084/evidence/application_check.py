from pathlib import Path
import datetime, json, subprocess, tempfile

REPORT = 'Docs/learn/stage1_pi_mono/targets/zenpi/files/src/headless.rs_learn.md'

def check(root, files, before_path, scratch_parent=None):
    root = root.resolve()
    after = (files/REPORT).read_bytes()
    before = before_path.read_bytes()
    results = []
    for mode,forward,reverse,initial in [
        ('absent','candidate.patch','rollback.patch',None),
    ]:
        commands = []
        started = datetime.datetime.now(datetime.timezone.utc).isoformat()
        with tempfile.TemporaryDirectory(prefix='headless-report-check-',dir=scratch_parent) as name:
            scratch = Path(name)
            def run(argv,code=0):
                result = subprocess.run(argv,cwd=scratch,capture_output=True,timeout=20)
                commands.append({'argv':argv,'cwd':str(scratch),'exit_code':result.returncode,
                    'expected_exit_code':code,'stdout':result.stdout.decode(errors='replace'),
                    'stderr':result.stderr.decode(errors='replace')})
                assert result.returncode == code,commands[-1]
            run(['git','-c','init.defaultBranch=review','init','--quiet'])
            sentinel = b'headless report sentinel\x00\xff\n'
            (scratch/'sentinel.bin').write_bytes(sentinel)
            path = scratch/REPORT
            if initial is not None:
                path.parent.mkdir(parents=True)
                path.write_bytes(initial)
            run(['git','apply','--check',str(root/forward)])
            run(['git','apply',str(root/forward)])
            assert path.read_bytes() == after
            run(['git','apply','--check',str(root/forward)],1)
            run(['git','apply','--reverse','--check',str(root/forward)])
            run(['git','apply','--check',str(root/reverse)])
            run(['git','apply',str(root/reverse)])
            assert (not path.exists()) if initial is None else path.read_bytes() == initial
            assert (scratch/'sentinel.bin').read_bytes() == sentinel
            ordinary = sorted(p.relative_to(scratch).as_posix() for p in scratch.rglob('*')
                              if p.is_file() and '.git' not in p.relative_to(scratch).parts)
            assert ordinary == sorted(['sentinel.bin'] + ([] if initial is None else [REPORT]))
        results.append({'mode':mode,'started_at':started,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
                        'commands':commands,'after_bytes_verified':True,'exact_initial_restored':True,
                        'duplicate_apply_rejected':True,'sentinel_unchanged':True})
    return {'status':'passed','modes':results,'product_runtime_executions':0}

if __name__ == '__main__':
    root = Path(__file__).resolve().parent
    (root/'tmp').mkdir(exist_ok=True)
    result = check(root,root/'files',root/'before-report.md',root/'tmp')
    (root/'application-verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))
