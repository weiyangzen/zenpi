from pathlib import Path
import datetime,hashlib,json,os,stat,subprocess,shutil,difflib,sys
R=Path.cwd();W=R/'.ops/target084-current320';M=Path('/Users/wangweiyang/GitHub/zenpi');W.mkdir(exist_ok=False)
def info(p):
 assert stat.S_ISREG(p.lstat().st_mode);b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def inv(root):
 out={}
 for d,ds,fs in os.walk(root,followlinks=False):
  ds[:]=[n for n in ds if not Path(d,n).is_symlink()]
  for n in fs:
   p=Path(d,n)
   if stat.S_ISREG(p.lstat().st_mode):out[str(p.relative_to(root))]=info(p)
 return out
def dump(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def cp(a,b):b.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(a,b)
roots=sorted(p for p in (R/'.ops').glob('*-ready') if p.is_dir())+[R/'.ops/stage125-render-review320/ready',R/'.ops/stage126-independent320/ready',R/'.ops/stage126-independent320/ready-final']
tracked={str(R/x.decode()):info(R/x.decode()) for x in subprocess.check_output(['git','ls-files','-z']).split(b'\0') if x and (R/x.decode()).is_file()};dump(W/'preservation-before.json',{'ready':{str(p):inv(p) for p in roots},'tracked':tracked})
dump(W/'reused-inventory.json',{})
report='Docs/learn/stage1_pi_mono/targets/zenpi/files/src/headless.rs_learn.md';assert not (R/report).exists() and not (M/report).exists();(W/'before-report.md').write_bytes(b'')
binding={'item':'ZS1-084','version':'3.1.20','captured_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'report_path':report,'prefix':info(W/'before-report.md'),'main_report_absent':True,'product_runtime_executions':0,'prior_complete_report_reused':False,'new_full_source_read_claim':True}
for label,p,h in [('baseline',R/'.ops/host-original/src/headless.rs','1c3b14bda2533e82e498372f0d570cf899833a06e41fd6cd70b8cf7cc385b478'),('previous-current',M/'src/headless.rs','958837ad933fea4e55c3ac966f0c8d605dd03674a696e2ef0595b54aca628ef9'),('current',M/'src/headless.rs','958837ad933fea4e55c3ac966f0c8d605dd03674a696e2ef0595b54aca628ef9')]:
 assert info(p)['sha256']==h;cp(p,W/(label+'-headless.rs'));binding[label]={'origin':str(p),**info(p),'lines':len(p.read_bytes().splitlines())}
assert (W/'previous-current-headless.rs').read_bytes()==(W/'current-headless.rs').read_bytes()
for label in ['baseline','previous-current']:(W/(label+'-to-current.diff')).write_text(''.join(difflib.unified_diff((W/(label+'-headless.rs')).read_text().splitlines(keepends=True),(W/'current-headless.rs').read_text().splitlines(keepends=True),fromfile=label,tofile='current')))
for n in ['validate_stage1_blueprint.py','validate_blueprint.py']:cp(M/'tools'/n,W/'validation-tools'/n)
cp(M/'Docs/stage_1_v3_pi_mono_blueprint.md',W/'validation-tools/blueprint.md');sys.path.insert(0,str(W/'validation-tools'));import validate_stage1_blueprint as gate
bp=gate.parse((W/'validation-tools/blueprint.md').read_text());binding['snapshot_sha256']=bp.snapshot;binding['requirement_digest']=bp.requirement;assert bp.requirement=='8d525b351d066ce9b0487a485337647d47233275782e4f4d154423a623fe1645';assert bp.files['ZS1-084'].sha256==binding['baseline']['sha256'];dump(W/'current-binding.json',binding);cp(Path(__file__),W/'capture.py');print(json.dumps(binding));print('preservation',len(roots),sum(len(inv(p)) for p in roots),len(tracked))
