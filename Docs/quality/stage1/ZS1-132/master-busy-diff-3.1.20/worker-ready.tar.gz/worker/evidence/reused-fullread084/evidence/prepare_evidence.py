from pathlib import Path
import hashlib,json,re,shutil,stat,difflib
W=Path(__file__).resolve().parent;M=Path('/Users/wangweiyang/GitHub/zenpi')
def info(p):
 assert stat.S_ISREG(p.lstat().st_mode);b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def dump(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
def chunks(p,ranges,prefix):
 b=p.read_bytes();ls=b.splitlines(keepends=True);out=[]
 for s,e in ranges:
  assert 1<=s<=e<=len(ls);q=W/'reads'/f'{prefix}-{s:04}-{e:04}.txt';q.parent.mkdir(exist_ok=True);q.write_bytes(b''.join(ls[s-1:e]));out.append({'path':str(q.relative_to(W)),'line_start':s,'line_end':e,'byte_start':len(b''.join(ls[:s-1])),'byte_end':len(b''.join(ls[:e])),**info(q)})
 return out
reads={};index={}
for label,total in [('baseline',7989),('current',9229)]:
 p=W/(label+'-headless.rs');ls=p.read_text().splitlines();assert len(ls)==total
 ranges=[(s,min(s+399,total)) for s in range(1,8801 if label=='current' else total+1,400)]
 if label=='current':ranges.append((8801,9229))
 reads[label]=chunks(p,ranges,label+'-full')
 index[label]={'functions':[{'line':i,'signature':l.strip()} for i,l in enumerate(ls,1) if re.match(r'^\s*(?:pub(?:\([^)]*\))?\s+)?(?:const\s+)?fn\s',l)],'types_and_aliases':[{'line':i,'signature':l.strip()} for i,l in enumerate(ls,1) if re.match(r'^\s*(?:pub(?:\([^)]*\))?\s+)?(?:struct|enum|type)\s',l)],'inline_test_markers':p.read_text().count('#[test]')}
base=(W/'baseline-headless.rs').read_text().splitlines(keepends=True);cur=(W/'current-headless.rs').read_text().splitlines(keepends=True)
ops=[{'tag':t,'baseline_lines_half_open_zero_based':[a,b],'current_lines_half_open_zero_based':[c,d]} for t,a,b,c,d in difflib.SequenceMatcher(None,base,cur,autojunk=False).get_opcodes()]
dump(W/'delta-map.json',{'opcodes':ops,'unified_hunks':[l for l in (W/'baseline-to-current.diff').read_text().splitlines() if l.startswith('@@')],'unchanged_current_lines':sum(x['current_lines_half_open_zero_based'][1]-x['current_lines_half_open_zero_based'][0] for x in ops if x['tag']=='equal'),'changed_or_added_current_lines':sum(x['current_lines_half_open_zero_based'][1]-x['current_lines_half_open_zero_based'][0] for x in ops if x['tag']!='equal')})
dump(W/'read-binding.json',{'full_reads':reads,'diff_reads':chunks(W/'baseline-to-current.diff',[(1,640),(641,1280),(1281,1920),(1921,2558)],'baseline-current-diff'),'method':'Fresh consecutive complete baseline and current readings through EOF, plus every unified diff line. Raw chunks generated after the actual source reads; no historical full-read evidence reused.','new_full_source_read_claim':True,'prior_complete_read_reused':False,'same_capture_alias':'previous-current-headless.rs is a redundant capture of current, not a prior reviewed snapshot.'})
dump(W/'declaration-index.json',index)
refs=[]
for rel,ranges,full in [('tests/headless_event_budget.rs',[(1,227)],True),('tests/headless_project_workspace.rs',[(1,300),(301,583)],True),('src/protocol.rs',[(145,330),(795,1002)],False),('src/runtime.rs',[(369,441),(443,555),(640,695)],False),('src/input_queue.rs',[(660,809)],False),('src/project_workspace.rs',[(302,554)],False),('src/core.rs',[(2505,2702),(4295,4415)],False),('src/slash_actions.rs',[(1,176),(202,295),(820,873),(903,968)],False)]:
 p=M/rel;q=W/'references'/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q);refs.append({'source_path':str(p),'relative_source':rel,'artifact':str(q.relative_to(W)),**info(q),'lines':len(q.read_bytes().splitlines()),'full_read':full,'chunks':chunks(q,ranges,rel.replace('/','__')),'test_markers':q.read_text().count('#[test]') if full else None})
dump(W/'references-current.json',refs)
dump(W/'discovery-notes.json',{'failures':[{'action':'initial guessed canonical report read','result':'FileNotFoundError and sed missing; no preexisting report claimed'},{'action':'exact filename search local/main .ops and Docs/learn','result':'exit 1 no prior084 report/package found in this scope'},{'action':'read guessed prepare.py template','result':'exit 1 missing; actual prepare_evidence.py found and read afterward'}],'navigation_truncations':['initial broad manifest filename navigation','broad headless blueprint reference search','combined dependency declaration navigation 6517 tokens with5500 budget; used only navigation, exact dependency ranges independently read'],'full_source_or_diff_output_truncated':False,'runtime_tests_run':False})
print(json.dumps({'read_chunks':{k:len(v) for k,v in reads.items()},'declarations':{k:{n:(len(v) if isinstance(v,list) else v) for n,v in x.items()} for k,x in index.items()},'delta':json.loads((W/'delta-map.json').read_text())['changed_or_added_current_lines']}))
