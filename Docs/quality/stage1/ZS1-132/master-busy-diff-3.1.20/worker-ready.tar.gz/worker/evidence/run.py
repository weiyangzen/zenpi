import argparse,datetime,hashlib,json,os,signal,subprocess,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--name',required=True);p.add_argument('--cwd',type=Path,required=True);p.add_argument('--timeout',type=int,default=600);p.add_argument('argv',nargs=argparse.REMAINDER);a=p.parse_args();w=Path(__file__).resolve().parent;out=w/'commands';out.mkdir(exist_ok=True);log=out/(a.name+'.log');receipt=out/(a.name+'.json');assert not log.exists() and not receipt.exists();env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1';start=time.monotonic();r={'argv':a.argv,'cwd':str(a.cwd.resolve()),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'HOME_preserved':env.get('HOME')==os.environ.get('HOME'),'CODEX_HOME_preserved':env.get('CODEX_HOME')==os.environ.get('CODEX_HOME'),'timeout_seconds':a.timeout}
with log.open('wb') as f:
 proc=subprocess.Popen(a.argv,cwd=a.cwd,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);r['pid']=proc.pid
 try:code=proc.wait(timeout=a.timeout)
 except subprocess.TimeoutExpired:
  r['timed_out']=True;os.killpg(proc.pid,signal.SIGTERM)
  try:proc.wait(timeout=3)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=3)
  code=124
r.update(exit_code=code,process_reaped=proc.poll() is not None,ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-start,log=log.name,bytes=log.stat().st_size,sha256=hashlib.sha256(log.read_bytes()).hexdigest());receipt.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));raise SystemExit(code)
