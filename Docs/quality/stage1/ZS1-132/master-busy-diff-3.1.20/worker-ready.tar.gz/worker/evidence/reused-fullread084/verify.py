from pathlib import Path
import argparse,importlib.util,json,os,stat,hashlib
P=Path(__file__).resolve().parent;E=P/'evidence'
def info(path):
 assert stat.S_ISREG(path.lstat().st_mode),str(path)
 b=path.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def read(path):return json.loads(path.read_text())
def inventory(root):
 out={}
 for d,ds,fs in os.walk(root,followlinks=False):
  for n in ds:assert not Path(d,n).is_symlink()
  for n in fs:out[str(Path(d,n).relative_to(root))]=info(Path(d,n))
 return out
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
parser=argparse.ArgumentParser();parser.add_argument('--receipt',type=Path);args=parser.parse_args()
if args.receipt:assert not args.receipt.resolve().is_relative_to(P)
manifest=read(P/'manifest.json');expected={}
for row in manifest['files']:
 rel=Path(row['path']);assert not rel.is_absolute() and '..' not in rel.parts and row['path'] not in expected;expected[row['path']]={k:row[k] for k in ['bytes','sha256']}
actual=inventory(P);actual.pop('manifest.json');assert actual==expected
for name,binding in read(E/'reused-inventory.json').items():
 root=E/'reused'/name;assert inventory(root)==binding['files'];assert info(root/'manifest.json')['sha256']==binding['manifest_sha256'];old=read(root/'manifest.json');assert info(root/'candidate.patch')=={'bytes':old['patch_bytes'],'sha256':old['patch_sha256']};assert info(root/'run_candidate_probe.py')['sha256']==old['runner_sha256']
 for row in old['files']:
  assert info(root/'files'/row['path'])=={k:row[k] for k in ['bytes','sha256']}
  assert info(root/'base'/row['path'])=={'bytes':row['base_bytes'],'sha256':row['base_sha256']}
  patch=root/'patches'/(row['path'].replace('/','__')+'.patch');assert info(patch)['sha256']==row['patch_sha256']
gfile=module('headless_gfile',E/'gfile.py');gresult=gfile.check(E,P/'files');assert info(P/'files'/gfile.REPORT)==manifest['report']
for name,code in [('gfile',0),('patch-application',0),('gstage-main',1)]:
 r=read(E/'commands'/(name+'.json'));assert r['exit_code']==code;assert r['HOME_preserved'] and r['CODEX_HOME_preserved'];assert info(E/'commands'/(name+'.log'))=={k:r[k] for k in ['bytes','sha256']}
stage=read(E/'commands/gstage-main.log');assert stage['structural']['ok'] and not stage['ok'];assert any('ZS1-084.master.json' in s for s in stage['errors'])
preserved=read(E/'preservation-after.json');assert preserved['all_byte_identical'] and preserved['main_headless_byte_identical'] and preserved['main_report_absent'];assert preserved['old_ready_packages']==87 and preserved['old_ready_regular_files']==13292 and preserved['tracked_regular_files']==145
before=read(E/'preservation-before.json');assert len(before['ready'])==87 and sum(len(x) for x in before['ready'].values())==13292 and len(before['tracked'])==145
selector=read(E/'validation-tools/active_requirement-after-gate.json');after_bp=read(E/'gate-disposition.json');assert selector['active'] and selector['requirement_digest']==manifest['requirement_digest'] and selector['snapshot_sha256']==after_bp['snapshot_observed_after_gate'];assert selector['baseline_files']['ZS1-084']['sha256']==manifest['baseline']['sha256']
app=module('headless_application',E/'application_check.py');result={'status':'passed','item':'ZS1-084','files':len(manifest['files']),'gfile':gresult,'application':app.check(P,P/'files',E/'before-report.md'),'product_runtime_executions':0,'master_acceptance':False,'preservation_scope':'Captured inventory and before/after evidence; portable verifier does not claim a new external main check'}
if args.receipt:args.receipt.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
