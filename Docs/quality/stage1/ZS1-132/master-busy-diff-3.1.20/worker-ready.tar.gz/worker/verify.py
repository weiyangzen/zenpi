from pathlib import Path
import argparse,hashlib,json,os,stat,subprocess,tempfile,difflib
P=Path(__file__).resolve().parent;E=P/'evidence'
def info(p):
 assert stat.S_ISREG(p.lstat().st_mode),str(p);b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def read(p):return json.loads(p.read_text())
def inv(root):
 out={}
 for d,ds,fs in os.walk(root,followlinks=False):
  for n in ds:assert not Path(d,n).is_symlink()
  for n in fs:out[str(Path(d,n).relative_to(root))]=info(Path(d,n))
 return out
p=argparse.ArgumentParser();p.add_argument('--receipt',type=Path);args=p.parse_args()
if args.receipt:assert not args.receipt.resolve().is_relative_to(P)
m=read(P/'manifest.json');expected={r['path']:{k:r[k] for k in ['bytes','sha256']} for r in m['files']};assert len(expected)==len(m['files']);actual=inv(P);actual.pop('manifest.json');assert actual==expected
base=read(E/'build-inputs.json');assert inv(E/'build-input')==base and len(base)==224;before=(E/'build-input/src/headless.rs').read_bytes();after=(P/'files/src/headless.rs').read_bytes();assert info(E/'build-input/src/headless.rs')==m['before'] and info(P/'files/src/headless.rs')==m['after'];assert sorted(inv(P/'files'))==['src/headless.rs']
old=E/'reused-fullread084';om=read(old/'manifest.json');oa=inv(old);oa.pop('manifest.json');assert oa=={r['path']:{k:r[k] for k in ['bytes','sha256']} for r in om['files']};oldsrc=old/'evidence/current-headless.rs';assert oldsrc.read_bytes()==before
rb=read(old/'evidence/read-binding.json');joined=[]
for row in rb['full_reads']['current']:
 f=old/'evidence'/row['path'];assert info(f)=={k:row[k] for k in ['bytes','sha256']};assert f.read_bytes()==before[row['byte_start']:row['byte_end']];joined.append(f.read_bytes())
assert len(joined)==23 and b''.join(joined)==before
cb=read(E/'candidate-read-binding.json');al=before.splitlines(keepends=True);bl=after.splitlines(keepends=True);ops=[{'tag':t,'before':[x,y],'after':[z,q]} for t,x,y,z,q in difflib.SequenceMatcher(None,al,bl,autojunk=False).get_opcodes()];assert ops==cb['opcodes'];d=cb['delta_read'];assert (E/d['path']).read_bytes()==b''.join(bl[d['lines'][0]-1:d['lines'][1]])
for op in ops:
 if op['tag']!='equal':assert op['after'][0]>=d['lines'][0]-1 and op['after'][1]<=d['lines'][1]
assert (E/'build-input/tests/headless_project_workspace.rs').read_bytes()==(old/'evidence/references/tests/headless_project_workspace.rs').read_bytes()
for name,code in [('candidate-build',101),('candidate-native-build',0),('native-toolchain',0),('project-integration-tests',0),('after-release',0),('after-frozen-binary',0),('matching-input-before-build',0),('matching-input-before-probe',1)]:
 r=read(E/'commands'/f'{name}.json');assert r['exit_code']==code and r['process_reaped'] and r['HOME_preserved'] and r['CODEX_HOME_preserved'];assert info(E/'commands'/r['log'])=={k:r[k] for k in ['bytes','sha256']}
assert '12 passed; 0 failed' in (E/'commands/project-integration-tests.log').read_text()
failed=['B-before-new','B-after-new','B-after-switch-back','B-before-cancel']
for name,binary in [('before-release-02','zenpi-coordinator-before'),('matching-before-03','zenpi-matching-before'),('after-frozen-02','zenpi-candidate')]:
 r=read(E/name/'result.json');assert 'exception' not in r and r['host_exit']==0 and r['host_reaped'] and r['reader_threads_joined'] and r['server_thread_joined'];assert r['HOME_preserved'] and r['CODEX_HOME_preserved'];assert info(E/'binaries'/binary)['sha256']==r['binary_sha256'];assert [k for k,v in r['checks'].items() if not v]==([] if name=='after-frozen-02' else failed)
 assert r['fixture_identity']['A']['file_inode']!=r['fixture_identity']['B']['file_inode'] and r['fixture_identity']['A']['git_inode']!=r['fixture_identity']['B']['git_inode']
 for item in r['observations']:
  if item['name'] in failed:
   v=item['detail'];assert v['gated'] and not v['provider_terminal_seen'];assert v['response']['project']['cwd']==v['expected_cwd'];assert ('UNIQUE_DIFF_B' if name=='after-frozen-02' else 'UNIQUE_DIFF_A') in v['response']['data']['diff']
 assert len(read(E/name/'http.json'))==3
pres=read(E/'preservation-after.json');assert pres['all_preserved'] and pres['main_headless_and_slash_actions_unchanged'] and pres['old_ready_packages']==88 and pres['old_ready_regular_files']==13405 and pres['tracked_regular_files']==145
results=[]
with tempfile.TemporaryDirectory(prefix='busy-diff-portable-') as name:
 r=Path(name);(r/'src').mkdir();(r/'src/headless.rs').write_bytes(before);(r/'sentinel').write_bytes(b'unrelated\x00\xff')
 for argv,code in [(['git','init','--quiet'],0),(['git','apply','--check',str(P/'candidate.patch')],0),(['git','apply',str(P/'candidate.patch')],0),(['git','apply','--check',str(P/'candidate.patch')],1),(['git','apply','--reverse','--check',str(P/'candidate.patch')],0),(['git','apply','--check',str(P/'rollback.patch')],0),(['git','apply',str(P/'rollback.patch')],0)]:
  p=subprocess.run(argv,cwd=r,capture_output=True,timeout=15);results.append({'argv':argv,'exit':p.returncode,'expected_exit':code,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()});assert p.returncode==code,results[-1]
  if argv==['git','apply',str(P/'candidate.patch')]:assert (r/'src/headless.rs').read_bytes()==after
 assert (r/'src/headless.rs').read_bytes()==before and (r/'sentinel').read_bytes()==b'unrelated\x00\xff'
result={'status':'passed','payload_files':len(expected),'build_inputs':len(base),'candidate_files':['src/headless.rs'],'preserved_old_ready':88,'actual_patch_replay':results,'build_and_runtime_evidence':'historical actual receipts and binary hashes verified; no Cargo/provider/test rerun by portable verifier','master_acceptance':False}
if args.receipt:args.receipt.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
