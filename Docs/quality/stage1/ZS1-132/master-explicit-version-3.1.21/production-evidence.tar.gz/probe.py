from pathlib import Path
import argparse,datetime,hashlib,json,os,queue,signal,subprocess,threading,time,traceback
p=argparse.ArgumentParser();p.add_argument('--binary',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.binary=a.binary.resolve();w=a.out.resolve();w.mkdir();home=w/'home';home.mkdir();workspace=w/'workspace';workspace.mkdir();checks={};responses={};snapshots={};sent=[];wire=[];q=queue.Queue();proc=None

def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=True,indent=2)+'\n')
def sha(b):return hashlib.sha256(b).hexdigest()
def domains():
 f=home/'domains.jsonl';return f.read_bytes() if f.exists() else b''
def check(k,v):checks[k]=bool(v)
def request(id,text=None,kind='command'):
 obj={'type':kind,'id':id}
 if text is not None:obj['text']=text
 sent.append(obj);proc.stdin.write(json.dumps(obj)+'\n');proc.stdin.flush();deadline=time.monotonic()+7
 while True:
  line=q.get(timeout=max(0.01,deadline-time.monotonic()))
  if line is None:raise RuntimeError('unexpected EOF')
  row=json.loads(line)
  if row.get('id')==id and row.get('type')=='response':responses[id]=row;return row

def blueprint(id,version):
 unsigned={'id':id,'version':version,'items':[{'id':'inspect','depends_on':[],'estimated_loc':1}]}
 return {**unsigned,'digest':sha(json.dumps(unsigned,separators=(',',':'),ensure_ascii=False).encode())}
result={'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'binary_sha256':sha(a.binary.read_bytes()),'HOME_preserved':True,'CODEX_HOME_preserved':True,'provider_commands_sent':False,'shell_commands_sent':False}
try:
 env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',ZENPI_HOME=str(home),ZENPI_DOMAIN_STORE=str(home/'domains.jsonl'),ZENPI_API_KEY='local-unused-fixture-key',ZENPI_BASE_URL='http://127.0.0.1:9/v1',ZENPI_MODEL='local-unused-fixture-model')
 argv=[str(a.binary),'--headless','--session',str(home/'session.jsonl'),'--backend','openai','--model','local-unused-fixture-model'];result['argv']=argv
 err=(w/'stderr.log').open('wb');proc=subprocess.Popen(argv,cwd=workspace,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True,start_new_session=True)
 def reader():
  for line in proc.stdout:wire.append(line);q.put(line)
  q.put(None)
 thread=threading.Thread(target=reader);thread.start()
 def reads(prefix):
  before=domains();(w/(prefix+'-domain-before.jsonl')).write_bytes(before)
  for i,text in enumerate(['/blueprint show','/blueprint status','/blueprint validate','/goal list']):
   r=request(prefix+str(i),text);check(prefix+'-read-'+str(i),r.get('success') is True)
  after=domains();(w/(prefix+'-domain-after.jsonl')).write_bytes(after);snapshots[prefix]={'before_sha256':sha(before),'after_sha256':sha(after),'bytes_before':len(before),'bytes_after':len(after)};check(prefix+'-domain-unchanged',before==after)
 reads('empty')
 for i,(bid,v) in enumerate([('single','1'),('multi','1'),('multi','2'),('label','release-beta'),('boundary','v'*64),('atsign','x@y')]):
  name='seed-'+str(i)+'.json';bp=blueprint(bid,v);dump(workspace/name,bp);r=request('seed-'+str(i),'/blueprint put '+name);check('seed-'+str(i),r.get('success') is True and r['data']['blueprint']==bp)
 reads('seeded')
 cases=[('exact','single@1','1',None),('missing','single@2',None,'blueprint_not_found'),('bare-unique','single','1',None),('bare-multi','multi',None,'blueprint_not_found'),('multi-exact','multi@2','2',None),('multi-missing','multi@3',None,'blueprint_not_found'),('unknown','unknown@1',None,'blueprint_not_found'),('empty-version','single@',None,'goal_invalid_blueprint'),('overbound','single@'+'v'*65,None,'goal_invalid_blueprint'),('control','single@bad\u0001',None,'command_error'),('whitespace','single@bad version',None,'goal_create_usage'),('label','label@release-beta','release-beta',None),('boundary','boundary@'+'v'*64,'v'*64,None),('atsign','atsign@x@y','x@y',None),('atsign-missing','single@x@y',None,'blueprint_not_found')]
 expected_goals=[]
 for name,target,version,code in cases:
  before=domains();(w/(name+'-domain-before.jsonl')).write_bytes(before);r=request(name,'/goal create g-'+name+' '+target);after=domains();(w/(name+'-domain-after.jsonl')).write_bytes(after);snapshots[name]={'before_sha256':sha(before),'after_sha256':sha(after)}
  if version:
   expected_goals.append('g-'+name);g=r.get('data',{}).get('goal',{});check(name+'-exact-link',r.get('success') is True and g.get('blueprint_version')==version and g.get('blueprint_id')==target.split('@')[0] and g.get('status')=='queued' and r['data'].get('zenpi_started') is False);check(name+'-durable-create',before!=after)
  else:check(name+'-rejected',r.get('success') is False and r.get('code')==code);check(name+'-no-domain-mutation',before==after)
 reads('final')
 r=request('final-goals','/goal list');gs=r.get('data',{}).get('goals',[]);check('only-expected-goals',sorted(g['id'] for g in gs)==sorted(expected_goals))
 request('shutdown',kind='shutdown');proc.stdin.close();result['exit_code']=proc.wait(timeout=7);thread.join(timeout=3);err.close();check('exit-zero',result['exit_code']==0)
 journal=(home/'session.jsonl').read_text();check('no-execution-files',not any('execution' in f.name or 'handoff' in f.name for f in home.rglob('*') if f.is_file()));check('no-provider-or-tool-events',not any(x in journal for x in ['"role":"user"','"role":"assistant"','"tool_call"','"tool_started"','"provider_started"','"operation_started"']))
except Exception as e:result['exception']=traceback.format_exc()
finally:
 if proc is not None and proc.poll() is None:
  os.killpg(proc.pid,signal.SIGTERM)
  try:proc.wait(timeout=3)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=3)
 if proc:result['exit_code']=proc.returncode
 (w/'stdout.jsonl').write_text(''.join(wire));dump(w/'sent.json',sent);dump(w/'responses.json',responses);dump(w/'domain-snapshots.json',snapshots);result.update(checks=checks,status='passed' if all(checks.values()) and 'exception' not in result else 'failed',ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat());dump(w/'result.json',result);print(json.dumps(result));raise SystemExit(0 if result['status']=='passed' else 1)
