"""Local read/hash/JSON/patch audit for054 only; does not change global gates."""
from pathlib import Path
import csv
import difflib
import hashlib
import json
import sys
import tarfile

root=Path(sys.argv[1]).resolve()
master=Path('/Users/wangweiyang/GitHub/zenpi')
upstream=Path('/Users/wangweiyang/GitHub/pi-mono')
worker=Path('/Users/wangweiyang/.codex/worktrees/2267/zenpi')
checks=[]
def load(p): return json.loads(p.read_text())
def identity(p):
    b=p.read_bytes(); return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def matches(p,row): return identity(p)=={k:row[k] for k in ('bytes','sha256')}
def check(name,condition,detail=None): checks.append({'name':name,'passed':bool(condition),'detail':detail})
def rowfile(name):
    with (root/'authority/Docs/learn/stage1_pi_mono'/name).open() as f: return list(csv.DictReader(f,delimiter='\t'))
capture=load(root/'capture.json'); old=root/'historical054'; om=load(old/'manifest.json')
check('historical054 manifest identity',matches(old/'manifest.json',capture['old_manifest']))
check('59 historical payloads and exact60-file set',len(om['files'])==59 and all(matches(old/r['path'],r)for r in om['files']) and {str(p.relative_to(old))for p in old.rglob('*')if p.is_file()}=={'manifest.json'}|{r['path']for r in om['files']})
source=load(old/'source-inventory.json')
check('27 historical source copies and live identities',len(source)==27 and all(matches(old/'source'/r['path'],r)and matches(upstream/r['path'],r)for r in source))
inventory=load(root/'direct-inventory.json'); directory=upstream/'packages/agent/src/harness'
check('12 direct files and7 direct directories',sum(r['kind']=='file'for r in inventory)==12 and sum(r['kind']=='directory'for r in inventory)==7 and {p.name for p in directory.iterdir()}=={r['name']for r in inventory} and all(not p.is_symlink() for p in directory.iterdir()))
check('all direct file identities current',all(matches(root/'current-source'/r['path'],r)and matches(upstream/r['path'],r)for r in inventory if r['kind']=='file'))
for row in inventory:
    if row['kind']=='directory':
        p=upstream/row['path']; actual=[{'name':q.name,'kind':'directory'if q.is_dir()else'file',**(identity(q)if q.is_file()else{})}for q in sorted(p.iterdir())]
        check('physical next-level inventory '+row['name'],actual==row['direct_inventory'])
file_rows=[r for r in rowfile('source_manifest.tsv')if str(Path(r['source_path']).parent)=='packages/agent/src/harness']
folder_rows=rowfile('folder_learn_index.tsv'); byid={r['item_id']:r for r in folder_rows}
check('no frozen direct files and exactly050051 children',not file_rows and byid['ZS1-054']['depends']=='ZS1-050,ZS1-051' and {r['item_id']for r in folder_rows if str(Path(r['folder_path']).parent)=='packages/agent/src/harness'}=={'ZS1-050','ZS1-051'} and all(byid[i]['status']=='[x]'for i in ['ZS1-050','ZS1-051']))
for item,count in [('050',9),('051',20),('013',20)]:
    dep=root/f'dependency{item}'; receipt=load(dep/'receipt.json')
    check('accepted receipt'+item,matches(dep/'receipt.json',capture['dependencies'][item]['receipt'])and matches(master/f'Docs/learn/stage1_pi_mono/receipts/ZS1-{item}.master.json',capture['dependencies'][item]['receipt'])and receipt['complete']and receipt['manual_review']['decision']=='accepted'and receipt['role']=='master')
    check('artifact identities'+item,len(receipt['artifacts'])==count and all(matches(dep/r['path'],r)and matches(master/r['path'],r)for r in receipt['artifacts']))
check('child leaf closure',load(root/'dependency050/receipt.json')['children']==['ZS1-012']and load(root/'dependency051/receipt.json')['children']==['ZS1-013'])
archive=next((root/'dependency050').rglob('worker-ready.tar.gz'))
with tarfile.open(archive)as tar:
    prior012=json.loads(tar.extractfile('dependency012/receipt.json').read())
    check('012 full-read chain exact via050 archive',prior012==load(master/'Docs/learn/stage1_pi_mono/receipts/ZS1-012.master.json')and prior012['read_ranges']==[[0,27410]]and prior012['source_hash']==identity(root/'current-source/packages/agent/src/harness/compaction/compaction.ts')['sha256'])
    targets=load(root/'target-context-inventory.json')
    check('three target context identities reused from accepted050',all(tar.extractfile('current-context/zenpi/'+r['path']).read()==(root/'target-context'/r['path']).read_bytes()and matches(master/r['path'],r)for r in targets))
    canon=root/'dependency050/Docs/learn/stage1_pi_mono/packages/agent/src/harness/compaction/current_folder_learn.md'
    review=root/'dependency050/Docs/quality/stage1/ZS1-050/master-review-3.1.21/review.md'
    check('050 canonical exact previous report plus master appendix',canon.read_bytes()==tar.extractfile('files/Docs/learn/stage1_pi_mono/packages/agent/src/harness/compaction/current_folder_learn.md').read()+b'\n\n'+review.read_bytes())
context=load(root/'context-source-inventory.json')
check('12 necessary upstream context identities current',len(context)==12 and all(matches(root/'current-source'/r['path'],r)and matches(upstream/r['path'],r)for r in context))
for row in load(old/'context-only-read/receipt.json'):
    path=upstream/row['path'];start,end=row['read_range'];expected=''.join(f'{i}: {line}'for i,line in enumerate(path.read_text().splitlines(True),1)if start<=i<=end)
    saved=old/'context-only-read'/(path.name+'.excerpt.txt')
    check('historical context excerpt '+path.name,identity(path)['sha256']==row['sha256']and saved.read_text()==expected)
initial=(old/'initial-fixture-failure/directory.test.ts').read_text();corrected=(old/'directory.test.ts').read_text()
check('only fixture representation assertion changed',initial.replace('expect(JSON.stringify(llm))','expect((llm[0].content as any)[0].text)')==corrected and initial.count('expect(JSON.stringify(llm))')==1)
patch=''.join(difflib.unified_diff(initial.splitlines(True),corrected.splitlines(True),fromfile='initial/directory.test.ts',tofile='corrected/directory.test.ts'))
check('saved fixture patch exact',(root/'historical-fixture-correction.patch').read_text()==patch)
i=load(old/'initial-fixture-failure/test-results.json');f=load(old/'test-results.json')
check('initial3pass1fail and corrected4pass',i['numPassedTests']==3 and i['numFailedTests']==1 and f['numPassedTests']==4 and f['numFailedTests']==f['numPendingTests']==f['numTodoTests']==0 and load(old/'validation.json')['exit_code']==0)
failed=[r for r in i['testResults'][0]['assertionResults']if r['status']=='failed']
check('initial failure onlyD05403',len(failed)==1 and failed[0]['fullName'].startswith('D054-03')and 'AssertionError' in failed[0]['failureMessages'][0])
obs=load(old/'observations.json');priorobs=load(old/'initial-fixture-failure/observations.json')
check('initial observation subset equals final',len(priorobs)==3 and [r['case']for r in priorobs]==['D054-01','D054-02','D054-04']and all(r==next(x for x in obs if x['case']==r['case'])for r in priorobs))
check('four actual boundary observations',len(obs)==4 and obs[0]['projectorCalls']==1 and obs[0]['prompts']and 'CUSTOM_PENDING'not in '\n'.join(obs[0]['prompts'])and 'FAILED_ASSISTANT'in '\n'.join(obs[1]['prompts'])and obs[2]['events']==['start:first','end:first','start:second','end:second']and obs[2]['ignoredAbortCanComplete']and obs[3]['calls']==['first'])
before=load(root/'authority/Docs/execution/active_requirement.json');after=load(root/'authority-final/Docs/execution/active_requirement.json');live=load(master/'Docs/execution/active_requirement.json')
check('requirement baseline version binding unchanged',all(before[k]==after[k]==live[k]for k in ['requirement_digest','baseline_snapshot_sha256','blueprint_version','run_id'])and after['blueprint_version']=='3.1.21')
def item(text,n):return next(l for l in text.splitlines()if f'**ZS1-{n}**'in l)
oldbp=(root/'authority/Docs/stage_1_v3_pi_mono_blueprint.md').read_text();lastbp=(root/'authority-final/Docs/stage_1_v3_pi_mono_blueprint.md').read_text();livebp=(master/'Docs/stage_1_v3_pi_mono_blueprint.md').read_text()
check('050051054057061 scoped records unchanged',all(item(oldbp,n)==item(lastbp,n)==item(livebp,n)for n in ['050','051','054','057','061'])and item(livebp,'054').startswith('- [ ]'))
protected=load(root/'old-ready-inventory.json')
check('4737 older ready files unchanged',len(protected)==capture['protected_old_files']==4737 and all(matches(Path(p)if Path(p).is_absolute()else worker/p,row)for p,row in protected.items()))
candidate='Docs/learn/stage1_pi_mono/packages/agent/src/harness/current_folder_learn.md'
check('only054 candidate and old report verbatim',[str(p.relative_to(root/'files'))for p in (root/'files').rglob('*')if p.is_file()]==[candidate]and(root/'files'/candidate).read_bytes().endswith((old/'current_folder_learn.md').read_bytes()))
if(root/'manifest.json').exists():
    manifest=load(root/'manifest.json')
    check('ready payload identities',all(matches(root/r['path'],r)for r in manifest['files']))
    check('ready exact artifact set',{str(p.relative_to(root))for p in root.rglob('*')if p.is_file()}=={'manifest.json'}|{r['path']for r in manifest['files']})
result={'schema_version':'zs1-054-offline-review/v1','root':str(root),'passed':all(r['passed']for r in checks),'checks':checks,'candidate':identity(root/'files'/candidate),'runtime_executions_this_round':0,'scope_note':'Local054 consistency audit only. Unrelated global checkbox/Gantt drift does not fail this directory; relevant item records, leaf chains and actual source/context identities remain checked. Global G-STAGE policy unchanged.','authority_observation':{'captured_snapshot':before['snapshot_sha256'],'final_captured_snapshot':after['snapshot_sha256'],'live_snapshot_at_audit':live['snapshot_sha256']}}
print(json.dumps(result,indent=2));sys.exit(0 if result['passed']else 1)
