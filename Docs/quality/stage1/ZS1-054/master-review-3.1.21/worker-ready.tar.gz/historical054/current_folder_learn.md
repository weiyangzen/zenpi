# ZS1-054 — packages/agent/src/harness

Provisional [_], authority3.1.17 / 4b4bbb809fc660d55186317e9e12cfdccc7f3a2ba4567dc94b93d96858584f1a. The frozen direct children are compaction050 and session051; there is no in-scope direct file.051 is accepted (controller receipt/report preserved);050 is provisional. No parent acceptance follows.

directory-scope.json enumerates every real direct file and subdirectory. agent-harness.ts, config/context/events/hooks/messages/prompt-templates/result/skills/system-prompt/telemetry/types and env/execution/runtime/tools/utils remain context-only. The directory is not represented as only its two frozen children.

## Actual connections and ownership

050 prepares/generates summaries from caller-selected raw entries.051 selects the latest compaction and projects its summary/tail plus later entries into AgentMessage values. The context-only messages.ts then converts summary/custom/bash roles into provider-compatible user messages. Context and AbortSignal are passed across these calls, but each callback owns its cooperative cancellation.

The AgentHarness facade forwards construction to runtime/harness.ts. Its structural runtime adapter (context-only, captured source excerpt) calls compactWithRequest with durable preparation, wraps the summary request in before_request/before_payload hooks, publishes nested request intent/outcome, and uses the active gate signal for model admission. Thus the host supplies persistence and cancellation ownership that neither050 nor051 implements alone. This review reads that connection but does not claim to execute or accept the runtime directory.

Four new tests execute unchanged source across the two frozen child boundaries and immediate context helpers:

- D054-01: custom-entry projector output appears in ordinary provider context, but prepareCompaction consumes raw entries without that projector. CUSTOM_PENDING does not reach its summary prompt. Projectors are not implicitly applied twice or carried into preparation.
- D054-02: session projection suppresses error assistant messages, while raw compaction preparation can still include their text in a summary request. The FAILED_ASSISTANT marker demonstrates the difference rather than claiming uniform filtering.
- D054-03: the latest checkpoint excludes older custom entries. Gated asynchronous projectors run in source order with the same Context, followed by later input. Real AbortController cancellation is visible, but an ignoring projector still completes and the next projector runs. Actual messages.ts conversion wraps the summary in provider text; failed retained assistants stay filtered.
- D054-04: a throwing projector rejects the whole projection promise and prevents later projector calls, without changing the input ancestry.

Four passed, zero failed/skipped/todo, real Vitest4.1.9 / Node24.19.0. The initial run had one assertion representation error (searching actual newlines inside JSON-escaped text); exact source/logs are retained. Checking the actual converted text field instead produced four passes without modifying upstream behavior.

## Boundaries and target mapping

050's five tests and012's historical37 are referenced, not repeated or summed here.051's accepted report and3.1.17 rebind are preserved separately. New ancestry/model/projector fixtures are explicit; no real model, queue admission, durable journal, OS restart or production harness execution is claimed. Cancellation/exception paths above are actual calls, not hash-based inference.050 already records JSON projection recovery; it is not relabeled as persistence.

A useful cross-file invariant for Zenpi is that summary preparation and live provider projection must agree about eligible history and custom pending state, or record their deliberate difference. Preserve complete turns, unresolved operations, typed file facts and failure status explicitly. context.rs/session.rs own validated checkpoint/tail restoration; core.rs/backend/cancel ownership controls publication and subsequent use. Tests of summary text alone cannot prove those host guarantees.

The closure is012→050 and013→051, then054→057→061. No frozen child is skipped or double accepted; other real children remain outside the frozen subset. Because050 is not master accepted,054 remains provisional even though its four behavioral checks pass.

