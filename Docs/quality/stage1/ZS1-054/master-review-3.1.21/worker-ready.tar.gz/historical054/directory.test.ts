import {it,expect,afterAll} from 'vitest';
import {writeFileSync} from 'node:fs';
import {buildSessionContext} from './source/packages/agent/src/harness/session/context.ts';
import {prepareCompaction,compactWithRequest} from './source/packages/agent/src/harness/compaction/compaction.ts';
import {convertToLlm} from './source/packages/agent/src/harness/messages.ts';
import {BACKGROUND_CONTEXT as bg,withAbortSignal} from './source/packages/agent/src/harness/context.ts';
import {getOrThrow} from './source/packages/agent/src/harness/types.ts';
const records:any[]=[];
const usage={input:2,output:3,cacheRead:0,cacheWrite:0,totalTokens:5,cost:{input:0,output:0,cacheRead:0,cacheWrite:0,total:0}};
const model:any={id:'fixture',provider:'fixture',api:'fixture',reasoning:false,maxTokens:1000,contextWindow:5000};
const user=(s:string):any=>({role:'user',content:[{type:'text',text:s}],timestamp:1});
const answer=(s:string,reason='stop'):any=>({role:'assistant',content:[{type:'text',text:s}],usage,api:'fixture',provider:'fixture',model:'fixture',stopReason:reason,timestamp:2});
const entry=(message:any,i:number):any=>({type:'message',id:'m'+i,parentId:i?'m'+(i-1):null,seq:i,timestamp:i,message});
const custom=(id:string):any=>({type:'custom',customType:'note',id,parentId:null,seq:0,timestamp:0});
const settings={enabled:true,reserveTokens:100,keepRecentTokens:1};
afterAll(()=>writeFileSync(process.env.DIR_OBSERVATIONS!,JSON.stringify(records,null,2)+'\n'));
it('D054-01 projected custom entry is absent from raw compaction input and prompt',async()=>{
 const path=[entry(user('task'),0),custom('custom'),entry(answer('done'),2),entry(user('next'),3),entry(answer('tail'),4)];
 const before=JSON.stringify(path);let projectorCalls=0;
 const projected=await buildSessionContext(path,{entryProjectors:{note:async()=>{projectorCalls++;return [user('CUSTOM_PENDING')];}}},bg);
 expect(JSON.stringify(convertToLlm(projected))).toContain('CUSTOM_PENDING');
 const p=getOrThrow(prepareCompaction(path,settings))!;const prompts:string[]=[];
 await compactWithRequest(p,{model},async(ctx:any)=>{prompts.push(ctx.messages[0].content[0].text);return answer('fixture summary');},bg);
 expect(projectorCalls).toBe(1);expect(prompts.join('\n')).not.toContain('CUSTOM_PENDING');expect(JSON.stringify(path)).toBe(before);
 records.push({case:'D054-01',projected,prompts,projectorCalls,customProjectionNotPassedToCompaction:true});
});
it('D054-02 failed assistants are filtered from context but can still reach raw compaction prompts',async()=>{
 const path=[entry(user('old task'),0),entry(answer('FAILED_ASSISTANT','error'),1),entry(user('new task'),2),entry(answer('tail'),3)];
 const projected=await buildSessionContext(path,undefined,bg);expect(JSON.stringify(projected)).not.toContain('FAILED_ASSISTANT');
 const p=getOrThrow(prepareCompaction(path,settings))!;const prompts:string[]=[];
 await compactWithRequest(p,{model},async(ctx:any)=>{prompts.push(ctx.messages[0].content[0].text);return answer('summary');},bg);
 expect(prompts.join('\n')).toContain('FAILED_ASSISTANT');
 records.push({case:'D054-02',projected,prompts,rawCompactionAndContextProjectionHaveDifferentFilters:true});
});
it('D054-03 latest checkpoint gates ordered asynchronous projectors and preserves caller cancellation context',async()=>{
 const abort=new AbortController();const ctx=withAbortSignal(abort.signal,bg);
 const cp:any={type:'compaction',id:'cp',parentId:null,seq:2,timestamp:2,summary:'SUMMARY_PENDING',tokensBefore:10,retainedTail:[user('tail'),answer('bad','aborted')]};
 const path=[custom('before'),cp,custom('first'),custom('second'),entry(user('after'),5)];const before=JSON.stringify(path);
 const events:string[]=[];let release!:()=>void;const gate=new Promise<void>(r=>release=r);let entered!:()=>void;const start=new Promise<void>(r=>entered=r);
 const running=buildSessionContext(path,{entryProjectors:{note:async(e:any,c:any)=>{expect(c).toBe(ctx);events.push('start:'+e.id);if(e.id==='first'){entered();await gate;}events.push('end:'+e.id);return [user('projected:'+e.id)];}}},ctx);
 await start;expect(events).toEqual(['start:first']);abort.abort();release();const out=await running;
 expect(events).toEqual(['start:first','end:first','start:second','end:second']);expect(JSON.stringify(out)).not.toContain('before');
 expect(out.map((m:any)=>m.role)).toEqual(['compactionSummary','user','user','user','user']);
 const llm=convertToLlm(out);expect((llm[0].content as any)[0].text).toContain('<summary>\nSUMMARY_PENDING\n</summary>');
 expect(ctx.abortSignal.aborted).toBe(true);expect(JSON.stringify(path)).toBe(before);
 records.push({case:'D054-03',events,out,llm,ignoredAbortCanComplete:true,olderCustomWasNotProjected:true});
});
it('D054-04 projector rejection stops later projection and leaves source path unchanged',async()=>{
 const path=[custom('first'),custom('second')];const before=JSON.stringify(path);const calls:string[]=[];const error=new Error('PROJECTOR_FAILED');
 await expect(buildSessionContext(path,{entryProjectors:{note:async(e:any)=>{calls.push(e.id);throw error;}}},bg)).rejects.toBe(error);
 expect(calls).toEqual(['first']);expect(JSON.stringify(path)).toBe(before);records.push({case:'D054-04',calls,rejectionPropagated:true,sourceUnchanged:true});
});

