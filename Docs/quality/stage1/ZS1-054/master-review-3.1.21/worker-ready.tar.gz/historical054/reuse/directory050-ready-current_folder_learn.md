# ZS1-050 — packages/agent/src/harness/compaction

Provisional worker synthesis, status [_]. Authority 3.1.17 / 4b4bbb809fc660d55186317e9e12cfdccc7f3a2ba4567dc94b93d96858584f1a. Dependency012 is still unaccepted in the captured master ledger. G-DIR acceptance remains pending.

The frozen subset has one direct file, compaction.ts (012), and no child directories. Real siblings branch-summarization.ts and utils.ts are context-only. Their execution does not accept extra obligations. Immediate inventory, source hashes, dependency state and reused file-packet identities accompany this report. The earlier directory draft is preserved as prior-folder-report.md. Its “immutable” preparation wording is corrected: nested message/settings references are shared.

## Calls and data ownership

Caller-selected ancestry enters prepareCompaction. The latest checkpoint supplies previous summary, retained messages and typed file details. Virtual retained entries plus later ancestry become history, split prefix and retained tail. Token estimation uses session projection; ancestry selection/validation belongs to the caller.

compaction.ts and branch-summarization.ts share utils.ts serialization, file sets, sorted lists and tags. Branch summarization also calls compaction's token estimate and request-option helpers. File sets describe assistant tool-call intent, including a failed write; they do not establish a successful write. Serialization drops result IDs/error status and truncates result text.

D050-01 executes branch preparation → shared utilities → branch summary → compaction preparation/generation → session projection. A scripted branch summary and its file tags reach the compaction prompt, but branch_summary.details do not populate compaction's typed readFiles/modifiedFiles in this fixture. They remain empty although the prompt contains shared.ts. In contrast, prior compaction details carry forward in D050-02. Prompt text and typed metadata are separate channels.

The caller owns the summary callback. History and prefix requests run sequentially; successful usage is combined and a result is returned for a host to commit. Error/aborted responses prevent that result, while callback throws escape both wrappers. D050-03/04/05 compare input and projected context before/after these failures. These functions publish no partial journal entry themselves; this is not proof of a host transaction.

Session projection selects the latest compaction, emits its summary and eligible tail, and adds later entries. D050-02 round-trips fixture entries through JSON and verifies ordered summary/tail/later input, suppression of older ancestry and error/aborted/deferred assistants, and carried typed file lists. This tests representation and projection, not upstream storage or an independent-process restart.

## Executable evidence

Five new tests passed, zero failed/skipped/todo, using real pinned Vitest4.1.9 and Node24.19.0. Source closure, command/results, prompt observations, source verification and dependency lock are frozen. Models return scripted messages; no provider network or model fidelity is claimed. Context, AbortSignal, algorithms and projections execute unchanged upstream code.

The first run passed three cases and failed two because the supplemental fixture reversed withAbortSignal arguments. Its exact source/logs remain under initial-fixture-failure. Only the fixture was corrected to the actual signal-first signature; all five then passed. No source or assertions were weakened.

The complete012 review and its37 actual-source tests are reused by reference, not rerun or added to five. Shared utility/branch-summary implementations, session projection and Context signatures were checked at their actual call boundaries.

Cancellation is cooperative: the actual signal and aborted response path are exercised.012 separately proves a callback ignoring abort may still succeed. Queue admission, tool execution, durable commit, power-loss recovery and lifecycle locking are not owned here; they are N/A rather than counted as passed.

## Target and closure

Zenpi context.rs/session.rs own checkpoint validation/projection and journaling; core.rs and its backend/budget/cancel owner invoke production summaries. Target full-turn cuts, pending-work/file retention, strict summary/provenance checks and commit-before-publication remain stronger obligations. Prior103/104/074 product evidence is separate and was not rerun.

The subset path is compaction050 → harness054 → agent/src057 → agent061. No direct child directory is skipped inside050, and context-only siblings add no accepted count. Master acceptance of012 and independent050 review are still required.

