"""New offline read-only checker. No subprocess, network, writes or historical execution."""
from pathlib import Path
import json,hashlib,csv,io
R=Path(__file__).resolve().parent
def read(p):return (R/p).read_bytes()
def js(p):return json.loads(read(p))
def sha(b):return hashlib.sha256(b).hexdigest()
def check(p,x):
 b=read(p);assert len(b)==x['bytes'] and sha(b)==x['sha256'],p
m=js('manifest.json');expected={x['path'] for x in m['files']};assert expected=={p.relative_to(R).as_posix() for p in R.rglob('*') if p.is_file()}-{'manifest.json'}
for x in m['files']:check(x['path'],x)
s=js('scope.json');c=js('capture.json');d=js('dependency-state.json');assert s['item']=='ZS1-401' and not s['accepted'] and not s['dependency_accepted'] and not d['accepted'] and not d['receipt_exists']
assert s['in_scope_direct_files']==[] and s['in_scope_direct_child_directories']==['ZS1-400'] and s['context_only_direct_files']==['unix.rs','windows.rs']
assert s['new_product_executions']==s['old_scripts_executed']==0 and not s['G_STAGE_executed'] and not s['master_receipt_created']
inv=js('physical-inventory.json');assert [x['name'] for x in inv]==['unix','unix.rs','windows.rs'] and all(not x['symlink'] for x in inv)
assert inv[0]['kind']=='directory' and [x['name'] for x in inv[0]['direct_children']]==['mio.rs','tty.rs']
for x in inv[0]['direct_children']:assert x['kind']=='file' and not x['symlink'];check('prior400/physical/'+x['name'],x)
for x in inv[1:]:assert x['kind']=='file';check('physical/'+x['name'],x)
assert read('physical/unix.rs')==read('prior400/context/vendor/crossterm/src/event/source/unix.rs')
assert read('physical/windows.rs')==read('fresh-context/vendor/crossterm/src/event/source/windows.rs')
assert sha(read('prior400/manifest.json'))==d['ready_manifest_sha256']=='805ac1beeab2d643a549a411574985d57db0757fd0a1be1dbef075390125e61d'
old=js('prior400/manifest.json');assert len(old['files'])==326
for x in old['files']:check('prior400/'+x['path'],x)
fresh=js('fresh-context-read.json');reuse=js('reused-context-read.json');assert len(fresh)==5 and len(reuse)==15
for rows,prefix in [(fresh,'fresh-context/'),(reuse,'prior400/context/')]:
 for x in rows:
  check(prefix+x['path'],x);assert x['start']==0 and x['end']==x['bytes'] and x['line_start']==1 and x['line_end']==len(read(prefix+x['path']).splitlines())
priorrows={x['path']:x for x in js('prior400/context-read.json')}
for x in reuse:
 for k in ['bytes','sha256','start','end','line_start','line_end']:assert x[k]==priorrows[x['path']][k]
prefix='prior400/prior099/';assert read('prior400/physical/mio.rs')==read(prefix+'sources/current-mio.rs');end=0
for x in js(prefix+'current-read-chain.json'):
 b=read(prefix+'sources/current-mio.rs')[x['start']:x['end']];assert end==x['start'] and sha(b)==x['sha256']
 if 'old_path' in x:assert read(prefix+x['old_path'])[x['old_start']:x['old_end']]==b
 end=x['end']
assert end==25801
child099=js('prior400/accepted099/Docs/learn/stage1_pi_mono/receipts/ZS1-099.master.json');assert child099['complete'] and child099['manual_review']['decision']=='accepted'
for x in child099['artifacts']:check('prior400/accepted099/'+x['path'],x)
for f,x in c['authority'].items():check('authority/'+f,x)
blue=read('authority/Docs/stage_1_v3_pi_mono_blueprint.md');assert b'- [ ] **ZS1-400**' in blue and b'- [ ] **ZS1-401**' in blue
selector=js('authority/Docs/execution/active_requirement.json');assert selector['snapshot_sha256']==sha(blue)==c['selector_snapshot_sha256']
for k in ['requirement_digest','baseline_snapshot_sha256']:assert selector[k]==s[k]==js('prior400/scope.json')[k]
assert not js('initial-authority.json')['files'][d['receipt_path']]['exists']
frows=list(csv.DictReader(io.StringIO(read('authority/Docs/learn/stage1_pi_mono/targets/zenpi/file_learn_index.tsv').decode()),delimiter='\t'))
drows=list(csv.DictReader(io.StringIO(read('authority/Docs/learn/stage1_pi_mono/targets/zenpi/folder_learn_index.tsv').decode()),delimiter='\t'))
assert [x for x in frows if Path(x['source_path']).parent.as_posix()==s['folder']]==[]
assert [x['item_id'] for x in drows if Path(x['folder_path']).parent.as_posix()==s['folder']]==['ZS1-400']
for item,dep in [('ZS1-400','ZS1-099'),('ZS1-401','ZS1-400')]:
 x=next(x for x in drows if x['item_id']==item);assert x['status']=='[ ]' and x['depends']==dep
pub=js('master132/manifest.json');selection=js('master132/selected-artifacts.json')['artifacts']
for f,x in selection.items():assert x==pub['artifacts'][f];check('master132/'+f,x)
v=js('master132/master-verification.json');assert v['top_level_rust_tests']==68 and not v['complete']
drift=js('related-identity-drift.json');assert drift['current']==c['related_identities']
for f,x in c['related_identities'].items():
 assert drift['published132'][f]==v['current_inputs'][f]
 if f!='src/headless.rs':assert x==v['current_inputs'][f]
check('master132/release-hosts/zenpi-release',v['production_release']);binarysha=v['production_release']['sha256'];assert binarysha=='6891df5d13a373eff656f8c99a5b5367f9ddb4e502f159d0d925162ec6bccbc4'
b=js('master132/release-hosts/budget.json');assert b['ok'] and len(b['gates'])==8 and all(b['gates'].values()) and b['cold_start']['binary_sha256']==binarysha and b['cold_start']['elapsed_ms']['sample_count']==3
p=js('master132/release-hosts/project-plus.json');k=js('master132/release-hosts/kill-yank.json');assert p['binary_sha256']==k['binary_sha256']==binarysha and p['status']=='passed' and len(p['assertions'])==12 and k['passed'] and len(k['checks'])==29 and k['request_count']==4 and k['tui_processes']==3
for f in ['root-tests','root-clippy','root-fmt','release-hosts/budget','release-hosts/project-plus','release-hosts/kill-yank']:
 run=js('master132/'+f+'.run.json');assert run['exit_code']==0 and run['reaped'] and not run['timed_out']
 if f+'.log' in selection:check('master132/'+f+'.log',run['log'])
formal=s['owned_paths'][0];b=read(formal);lines=b.splitlines(keepends=True);patch=f'diff --git a/{formal} b/{formal}\nnew file mode 100644\n--- /dev/null\n+++ b/{formal}\n@@ -0,0 +1,{len(lines)} @@\n'.encode()+b''.join(b'+'+l for l in lines);assert read('report.patch')==patch and len(patch)<262144
print(json.dumps(dict(ok=True,item='ZS1-401',payloads=len(expected),physical_direct_files=2,physical_direct_directories=1,in_scope_direct_files=0,dependency400_accepted=False,fresh_complete_context_files=5,exact_reused_complete_context_files=15,report_only_patch=True,new_product_executions=0,old_scripts_executed=0,G_STAGE_executed=False,semantic_acceptance=False)))
