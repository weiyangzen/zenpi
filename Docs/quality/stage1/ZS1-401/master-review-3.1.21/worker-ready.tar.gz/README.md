# ZS1-401 独立目录候选

唯一正式报告：Docs/learn/stage1_pi_mono/targets/zenpi/vendor/crossterm/src/event/source/current_folder_learn.md。物理两个直属文件、一个子目录；冻结直接文件为0、唯一子目录依赖400。封包时400尚未接受/receipt缺失，因此401为待依赖及主控语义审阅候选，accepted=false。

5份context完整新读，15份已读context逐字复用，mio复用已接受099完整655行链；prior400完整旧包原样保留。Windows/use-dev-tty只作接线上下文。新master132公开证据选集绑定31ea+41321e/6891，不倒改旧400时点。

report.patch仅新增401报告。verify.py是新只读离线验证器，不执行旧代码/产品/Cargo/runtime/PTY/budget/G-STAGE。外置运行回执位于相邻stage1-worker/target401-directory-3.1.21。完成后停止。
