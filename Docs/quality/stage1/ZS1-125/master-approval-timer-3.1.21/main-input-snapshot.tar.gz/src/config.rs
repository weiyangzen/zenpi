//! Persistent configuration and credential discovery for zenpi.
//!
//! The command line keeps its normal precedence rule explicit and boring:
//! command-line overrides win over environment variables, which win over
//! `~/.zenpi/config.toml`, which win over built-in defaults.  Credentials are
//! never written to the TOML file.  They live in `~/.zenpi/auth.json` (mode
//! `0600` on Unix) and are only imported from the user's Codex auth file when
//! `pair_from_codex` is requested.

use std::{
    collections::BTreeMap,
    env,
    fs::{self, File, OpenOptions},
    io::{self, Read, Write},
    path::{Path, PathBuf},
    process,
    time::{SystemTime, UNIX_EPOCH},
};

use serde::{Deserialize, Serialize};
use serde_json::Value;
use thiserror::Error;

#[cfg(unix)]
use std::os::unix::fs::OpenOptionsExt;

use crate::layout::{
    LayoutError, LayoutModel, LayoutPreferences, MAX_LAYOUT_PREFERENCES_BYTES, TabId,
};
use crate::security::{SecretHandle, SecretRevocation};

/// The directory name created below the user's home directory.
pub const ZENPI_DIR: &str = ".zenpi";
pub const CONFIG_FILE: &str = "config.toml";
pub const AUTH_FILE: &str = "auth.json";
pub const SESSIONS_DIR: &str = "sessions";
pub const SKILLS_DIR: &str = "skills";
pub const EXTENSIONS_DIR: &str = "extensions";
/// User-owned BentoBox state is kept separate from provider configuration and
/// credentials. This lets a corrupt layout fail closed without making a
/// working profile unusable.
pub const LAYOUT_FILE: &str = "layout.json";
pub const OPENAI_API_KEY: &str = "OPENAI_API_KEY";

/// A named provider profile. The legacy flat fields in [`ConfigFile`] remain
/// readable as the implicit `default` profile, while new writes can use this
/// explicit shape without putting credentials in TOML.
#[derive(Debug, Clone, Default, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct ProviderProfile {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub backend: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub provider: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub model: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub base_url: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub wire_api: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub auth_env: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub model_reasoning_effort: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub model_verbosity: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub timeout_seconds: Option<u64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub max_retries: Option<u32>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub requires_openai_auth: Option<bool>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub supports_websockets: Option<bool>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub model_overrides: Vec<crate::providers::registry::ModelOverride>,
}

impl ProviderProfile {
    fn from_flat(config: &ConfigFile) -> Self {
        Self {
            backend: config.backend.clone(),
            provider: config.provider.clone(),
            model: config.model.clone(),
            base_url: config.base_url.clone(),
            wire_api: config.wire_api.clone(),
            auth_env: config.auth_env.clone(),
            model_reasoning_effort: config.model_reasoning_effort.clone(),
            model_verbosity: config.model_verbosity.clone(),
            timeout_seconds: config.timeout_seconds,
            max_retries: config.max_retries,
            requires_openai_auth: config.requires_openai_auth,
            supports_websockets: config.supports_websockets,
            model_overrides: config.model_overrides.clone(),
        }
    }

    fn into_flat(self) -> ConfigFile {
        ConfigFile {
            backend: self.backend,
            provider: self.provider,
            model: self.model,
            base_url: self.base_url,
            wire_api: self.wire_api,
            auth_env: self.auth_env,
            model_reasoning_effort: self.model_reasoning_effort,
            model_verbosity: self.model_verbosity,
            timeout_seconds: self.timeout_seconds,
            max_retries: self.max_retries,
            requires_openai_auth: self.requires_openai_auth,
            supports_websockets: self.supports_websockets,
            model_overrides: self.model_overrides,
            default_profile: None,
            profiles: BTreeMap::new(),
        }
    }

    fn validate(&self) -> Result<(), ConfigError> {
        self.clone().into_flat().validate_flat()
    }
}

/// Paths for the zenpi configuration and auth files.  Tests can construct
/// this with `for_home`; normal callers should use `discover`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ConfigPaths {
    pub root: PathBuf,
    pub config: PathBuf,
    pub auth: PathBuf,
    pub sessions: PathBuf,
    pub skills: PathBuf,
    pub extensions: PathBuf,
}

impl ConfigPaths {
    pub fn for_home(home: impl AsRef<Path>) -> Self {
        let root = home.as_ref().join(ZENPI_DIR);
        Self {
            config: root.join(CONFIG_FILE),
            auth: root.join(AUTH_FILE),
            sessions: root.join(SESSIONS_DIR),
            skills: root.join(SKILLS_DIR),
            extensions: root.join(EXTENSIONS_DIR),
            root,
        }
    }

    pub fn discover() -> Result<Self, ConfigError> {
        if let Some(root) = env::var_os("ZENPI_HOME") {
            let root = PathBuf::from(root);
            return Ok(Self {
                config: root.join(CONFIG_FILE),
                auth: root.join(AUTH_FILE),
                sessions: root.join(SESSIONS_DIR),
                skills: root.join(SKILLS_DIR),
                extensions: root.join(EXTENSIONS_DIR),
                root,
            });
        }
        Ok(Self::for_home(home_dir()?))
    }

    /// Path of the bounded, non-secret BentoBox preference snapshot. It is a
    /// method rather than another public struct field so existing callers that
    /// construct `ConfigPaths` literals remain source-compatible.
    pub fn layout_path(&self) -> PathBuf {
        self.root.join(LAYOUT_FILE)
    }

    /// Short alias used by hosts that treat paths as named resources.
    pub fn layout(&self) -> PathBuf {
        self.layout_path()
    }

    /// Non-secret checkpoint for the Wave-style project tab strip.
    pub fn project_tabs_path(&self) -> PathBuf {
        self.root.join("project-tabs.json")
    }

    /// Create the directory with owner-only permissions and tighten an
    /// existing directory before any credential file is read or written.
    pub fn ensure_root(&self) -> Result<(), ConfigError> {
        reject_symlink(&self.root)?;
        if !self.root.exists() {
            #[cfg(unix)]
            {
                use std::os::unix::fs::DirBuilderExt;
                fs::DirBuilder::new()
                    .mode(0o700)
                    .recursive(true)
                    .create(&self.root)?;
            }
            #[cfg(not(unix))]
            fs::create_dir_all(&self.root)?;
        }
        let metadata = fs::metadata(&self.root)?;
        if !metadata.is_dir() {
            return Err(ConfigError::NotDirectory(self.root.clone()));
        }
        restrict_permissions(&self.root, 0o700)?;
        for directory in [&self.sessions, &self.skills, &self.extensions] {
            reject_symlink(directory)?;
            if !directory.exists() {
                #[cfg(unix)]
                {
                    use std::os::unix::fs::DirBuilderExt;
                    fs::DirBuilder::new().mode(0o700).create(directory)?;
                }
                #[cfg(not(unix))]
                fs::create_dir(directory)?;
            }
            if !fs::metadata(directory)?.is_dir() {
                return Err(ConfigError::NotDirectory(directory.to_path_buf()));
            }
            restrict_permissions(directory, 0o700)?;
        }
        Ok(())
    }
}

/// The non-secret TOML representation.  `api_key` is deliberately absent:
/// putting a key in config.toml makes accidental logging and source control
/// leaks much too easy.
#[derive(Debug, Clone, Default, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct ConfigFile {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub default_profile: Option<String>,
    #[serde(default, skip_serializing_if = "BTreeMap::is_empty")]
    pub profiles: BTreeMap<String, ProviderProfile>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub backend: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub provider: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub model: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub base_url: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub wire_api: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub auth_env: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub model_reasoning_effort: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub model_verbosity: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub timeout_seconds: Option<u64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub max_retries: Option<u32>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub requires_openai_auth: Option<bool>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub supports_websockets: Option<bool>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub model_overrides: Vec<crate::providers::registry::ModelOverride>,
}

impl ConfigFile {
    pub fn validate(&self) -> Result<(), ConfigError> {
        self.validate_flat()?;
        validate_optional("default_profile", self.default_profile.as_deref(), 128)?;
        for (name, profile) in &self.profiles {
            validate_profile_name(name)?;
            profile.validate()?;
        }
        if let Some(selected) = &self.default_profile
            && !self.profiles.contains_key(selected)
        {
            return Err(ConfigError::Invalid(format!(
                "default_profile `{selected}` does not exist"
            )));
        }
        Ok(())
    }

    fn validate_flat(&self) -> Result<(), ConfigError> {
        crate::providers::registry::ModelRegistry::with_overrides(&self.model_overrides)
            .map_err(|error| ConfigError::Invalid(error.to_string()))?;
        validate_optional("backend", self.backend.as_deref(), 64)?;
        validate_optional("provider", self.provider.as_deref(), 128)?;
        validate_optional("model", self.model.as_deref(), 256)?;
        validate_optional("base_url", self.base_url.as_deref(), 2048)?;
        validate_optional("wire_api", self.wire_api.as_deref(), 64)?;
        validate_optional("auth_env", self.auth_env.as_deref(), 128)?;
        validate_optional(
            "model_reasoning_effort",
            self.model_reasoning_effort.as_deref(),
            64,
        )?;
        validate_optional("model_verbosity", self.model_verbosity.as_deref(), 64)?;
        if self
            .timeout_seconds
            .is_some_and(|seconds| !(1..=3600).contains(&seconds))
        {
            return Err(ConfigError::Invalid(
                "timeout_seconds must be between 1 and 3600".into(),
            ));
        }
        if self.max_retries.is_some_and(|retries| retries > 10) {
            return Err(ConfigError::Invalid(
                "max_retries must be at most 10".into(),
            ));
        }
        if self
            .backend
            .as_deref()
            .is_some_and(|backend| !matches!(backend, "echo" | "openai" | "anthropic" | "google"))
        {
            return Err(ConfigError::Invalid(
                "backend must be `echo`, `openai`, `anthropic` or `google`".into(),
            ));
        }
        if let Some(base_url) = self.base_url.as_deref()
            && (!base_url.starts_with("http://") && !base_url.starts_with("https://")
                || base_url.contains(['?', '#'])
                || base_url.chars().any(char::is_whitespace))
        {
            return Err(ConfigError::Invalid(
                "base_url must be an http or https URL without query or fragment".into(),
            ));
        }
        Ok(())
    }

    pub fn selected_profile(
        &self,
        requested: Option<&str>,
    ) -> Result<(Option<String>, Self), ConfigError> {
        let selected = requested.or(self.default_profile.as_deref());
        let Some(name) = selected else {
            let mut flat = self.clone();
            flat.default_profile = None;
            flat.profiles.clear();
            return Ok((None, flat));
        };
        validate_profile_name(name)?;
        let profile = self.profiles.get(name).ok_or_else(|| {
            ConfigError::Invalid(format!("provider profile `{name}` does not exist"))
        })?;
        Ok((Some(name.to_owned()), profile.clone().into_flat()))
    }
}

/// JSON auth storage is intentionally a map so pairing preserves credentials
/// for other providers/tools.  Only `OPENAI_API_KEY` is interpreted by zenpi.
#[derive(Clone, Default, Serialize, Deserialize, PartialEq, Eq)]
#[serde(transparent)]
pub struct AuthFile(pub BTreeMap<String, Value>);

impl std::fmt::Debug for AuthFile {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let keys: Vec<&str> = self.0.keys().map(String::as_str).collect();
        formatter
            .debug_struct("AuthFile")
            .field("keys", &keys)
            .field("openai_api_key_present", &self.openai_api_key().is_some())
            .finish()
    }
}

impl AuthFile {
    pub fn openai_api_key(&self) -> Option<&str> {
        self.0.get(OPENAI_API_KEY).and_then(Value::as_str)
    }

    pub fn set_openai_api_key(&mut self, key: impl Into<String>) -> Result<(), ConfigError> {
        let key = key.into();
        validate_api_key(&key)?;
        self.0.insert(OPENAI_API_KEY.to_owned(), Value::String(key));
        Ok(())
    }

    pub fn remove_openai_api_key(&mut self) -> bool {
        self.0.remove(OPENAI_API_KEY).is_some()
    }

    pub fn api_key_for_profile(&self, profile: Option<&str>) -> Option<&str> {
        match profile {
            Some(name) => self
                .0
                .get("profiles")
                .and_then(Value::as_object)
                .and_then(|profiles| profiles.get(name))
                .and_then(Value::as_object)
                .and_then(|profile| {
                    profile
                        .get("api_key")
                        .or_else(|| profile.get(OPENAI_API_KEY))
                })
                .and_then(Value::as_str),
            None => self.openai_api_key(),
        }
    }

    pub fn set_profile_api_key(
        &mut self,
        profile: &str,
        key: impl Into<String>,
    ) -> Result<(), ConfigError> {
        validate_profile_name(profile)?;
        let key = key.into();
        validate_api_key(&key)?;
        let profiles = self
            .0
            .entry("profiles".into())
            .or_insert_with(|| Value::Object(serde_json::Map::new()))
            .as_object_mut()
            .ok_or_else(|| ConfigError::Invalid("auth profiles must be an object".into()))?;
        let profile_value = profiles
            .entry(profile.to_owned())
            .or_insert_with(|| Value::Object(serde_json::Map::new()));
        let fields = profile_value
            .as_object_mut()
            .ok_or_else(|| ConfigError::Invalid("auth profile must be an object".into()))?;
        fields.insert("api_key".into(), Value::String(key));
        Ok(())
    }

    pub fn remove_profile_api_key(&mut self, profile: &str) -> Result<bool, ConfigError> {
        validate_profile_name(profile)?;
        let Some(profiles) = self.0.get_mut("profiles").and_then(Value::as_object_mut) else {
            return Ok(false);
        };
        let Some(fields) = profiles.get_mut(profile).and_then(Value::as_object_mut) else {
            return Ok(false);
        };
        let changed = fields.remove("api_key").is_some() | fields.remove(OPENAI_API_KEY).is_some();
        if fields.is_empty() {
            profiles.remove(profile);
        }
        if profiles.is_empty() {
            self.0.remove("profiles");
        }
        Ok(changed)
    }
}

/// Explicit command-line overrides.  `None` means no override, not an empty
/// value.  The CLI parser can fill this directly without reading secrets.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct ConfigOverrides {
    pub profile: Option<String>,
    pub backend: Option<String>,
    pub provider: Option<String>,
    pub model: Option<String>,
    pub base_url: Option<String>,
    pub wire_api: Option<String>,
    pub api_key: Option<String>,
    pub model_reasoning_effort: Option<String>,
    pub model_verbosity: Option<String>,
    pub timeout_seconds: Option<u64>,
    pub max_retries: Option<u32>,
}

/// Where the selected credential came from.  This enum is safe to display.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum CredentialSource {
    CommandLine,
    Environment,
    AuthFile,
    None,
}

/// Fully resolved runtime configuration.  The API key is private in logs via
/// the custom Debug implementation, but remains available to backend setup.
#[derive(Clone, PartialEq, Eq)]
pub struct EffectiveConfig {
    pub profile: Option<String>,
    pub backend: String,
    pub provider: Option<String>,
    pub model: Option<String>,
    pub base_url: Option<String>,
    pub wire_api: Option<String>,
    pub api_key: Option<String>,
    pub credential_source: CredentialSource,
    pub model_reasoning_effort: Option<String>,
    pub model_verbosity: Option<String>,
    pub timeout_seconds: Option<u64>,
    pub max_retries: Option<u32>,
    pub requires_openai_auth: bool,
    pub supports_websockets: bool,
    pub model_overrides: Vec<crate::providers::registry::ModelOverride>,
}

impl EffectiveConfig {
    /// Issue an opaque credential capability for a single Blueprint policy.
    /// The API key remains private to configuration/backend setup and is never
    /// serialized as part of the handle or policy evidence.
    pub fn issue_secret_handle(
        &self,
        policy_digest: impl Into<String>,
    ) -> Result<Option<(SecretHandle, SecretRevocation)>, ConfigError> {
        let Some(key) = self.api_key.as_deref() else {
            return Ok(None);
        };
        SecretHandle::new(key, policy_digest.into())
            .map(Some)
            .map_err(|error| ConfigError::Invalid(error.to_string()))
    }
}

impl std::fmt::Debug for EffectiveConfig {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter
            .debug_struct("EffectiveConfig")
            .field("profile", &self.profile)
            .field("backend", &self.backend)
            .field("provider", &self.provider)
            .field("model", &self.model)
            .field("base_url", &self.base_url)
            .field("wire_api", &self.wire_api)
            .field("api_key", &self.api_key.as_ref().map(|_| "<redacted>"))
            .field("credential_source", &self.credential_source)
            .field("model_reasoning_effort", &self.model_reasoning_effort)
            .field("model_verbosity", &self.model_verbosity)
            .field("timeout_seconds", &self.timeout_seconds)
            .field("max_retries", &self.max_retries)
            .field("requires_openai_auth", &self.requires_openai_auth)
            .field("supports_websockets", &self.supports_websockets)
            .finish()
    }
}

/// Resolve CLI > environment > config > defaults.  This map-based function
/// keeps precedence deterministic and testable without mutating process-wide
/// environment variables.
pub fn resolve(
    overrides: &ConfigOverrides,
    config: &ConfigFile,
    auth: &AuthFile,
    environment: &BTreeMap<String, String>,
) -> Result<EffectiveConfig, ConfigError> {
    config.validate()?;
    let requested_profile = overrides
        .profile
        .as_deref()
        .or_else(|| environment.get("ZENPI_PROFILE").map(String::as_str));
    let (profile, selected) = config.selected_profile(requested_profile)?;
    let config = &selected;
    let backend = choose(
        overrides.backend.as_deref(),
        environment.get("ZENPI_BACKEND").map(String::as_str),
        config.backend.as_deref(),
        "openai",
    );
    let provider = choose_optional(
        overrides.provider.as_deref(),
        environment.get("ZENPI_PROVIDER").map(String::as_str),
        config.provider.as_deref(),
    );
    let wire_api = choose_optional(
        overrides.wire_api.as_deref(),
        environment.get("ZENPI_WIRE_API").map(String::as_str),
        config.wire_api.as_deref(),
    );
    let anthropic = backend == "anthropic"
        || wire_api
            .as_deref()
            .is_some_and(|v| matches!(v, "anthropic_messages" | "anthropic-messages"));
    let google = backend == "google"
        || wire_api
            .as_deref()
            .is_some_and(|v| matches!(v, "google_generative_ai" | "google-generative-ai"));
    let native = anthropic || google;
    let provider = provider.or_else(|| {
        if anthropic {
            Some("anthropic".into())
        } else if google {
            Some("google".into())
        } else {
            None
        }
    });
    let model = choose_optional(
        overrides.model.as_deref(),
        environment
            .get("ZENPI_MODEL")
            .or_else(|| {
                environment.get(if google {
                    "GEMINI_MODEL"
                } else if anthropic {
                    "ANTHROPIC_MODEL"
                } else {
                    "OPENAI_MODEL"
                })
            })
            .map(String::as_str),
        config.model.as_deref(),
    );
    let base_url = choose_optional(
        overrides.base_url.as_deref(),
        environment
            .get("ZENPI_BASE_URL")
            .or_else(|| {
                environment.get(if google {
                    "GEMINI_BASE_URL"
                } else if anthropic {
                    "ANTHROPIC_BASE_URL"
                } else {
                    "OPENAI_BASE_URL"
                })
            })
            .map(String::as_str),
        config.base_url.as_deref(),
    )
    .or_else(|| google.then(|| "https://generativelanguage.googleapis.com/v1beta".into()));
    let model_reasoning_effort = choose_optional(
        overrides.model_reasoning_effort.as_deref(),
        environment
            .get("ZENPI_MODEL_REASONING_EFFORT")
            .map(String::as_str),
        config.model_reasoning_effort.as_deref(),
    );
    let model_verbosity = choose_optional(
        overrides.model_verbosity.as_deref(),
        environment.get("ZENPI_MODEL_VERBOSITY").map(String::as_str),
        config.model_verbosity.as_deref(),
    );
    let timeout_seconds = overrides
        .timeout_seconds
        .or_else(|| {
            environment
                .get("ZENPI_TIMEOUT_SECONDS")
                .and_then(|value| value.parse().ok())
        })
        .or(config.timeout_seconds);
    let max_retries = overrides
        .max_retries
        .or_else(|| {
            environment
                .get("ZENPI_MAX_RETRIES")
                .and_then(|value| value.parse().ok())
        })
        .or(config.max_retries);
    let requires_openai_auth = config.requires_openai_auth.unwrap_or(true);
    let supports_websockets = config.supports_websockets.unwrap_or(false);
    let (api_key, credential_source) = if let Some(key) = overrides.api_key.clone() {
        (Some(key), CredentialSource::CommandLine)
    } else if let Some(key) = environment
        .get("ZENPI_API_KEY")
        .or_else(|| {
            environment.get(if google {
                "GEMINI_API_KEY"
            } else if anthropic {
                "ANTHROPIC_API_KEY"
            } else {
                "OPENAI_API_KEY"
            })
        })
        .or_else(|| {
            config
                .auth_env
                .as_deref()
                .and_then(|name| environment.get(name))
        })
    {
        (Some(key.clone()), CredentialSource::Environment)
    } else {
        (
            if native && profile.is_none() {
                None
            } else {
                auth.api_key_for_profile(profile.as_deref())
                    .map(str::to_owned)
            },
            if (!native || profile.is_some())
                && auth.api_key_for_profile(profile.as_deref()).is_some()
            {
                CredentialSource::AuthFile
            } else {
                CredentialSource::None
            },
        )
    };
    if let Some(key) = &api_key
        && (key.trim().is_empty() || key.chars().any(char::is_control))
    {
        return Err(ConfigError::Invalid("API key is invalid".into()));
    }
    if let Some(key) = &api_key {
        crate::security::register_secret_value(key);
    }
    Ok(EffectiveConfig {
        profile,
        backend,
        provider,
        model,
        base_url,
        wire_api,
        api_key,
        credential_source,
        model_reasoning_effort,
        model_verbosity,
        timeout_seconds,
        max_retries,
        requires_openai_auth,
        supports_websockets,
        model_overrides: config.model_overrides.clone(),
    })
}

/// Resolve the files in the default `~/.zenpi` directory using the current
/// process environment.
pub fn resolve_default(overrides: &ConfigOverrides) -> Result<EffectiveConfig, ConfigError> {
    resolve_workspace(overrides, None)
}

/// Read a bounded project overlay over user settings without changing process
/// environment or files. Validation follows merging so project selection can
/// refer to an inherited profile. Unknown TOML fields remain errors.
pub fn load_workspace_config(
    paths: &ConfigPaths,
    workspace: Option<&Path>,
) -> Result<ConfigFile, ConfigError> {
    let mut config = load_config(paths)?;
    if let Some(workspace) = workspace {
        let path = workspace.join(ZENPI_DIR).join(CONFIG_FILE);
        if path.try_exists()? {
            let mut options = OpenOptions::new();
            options.read(true);
            #[cfg(unix)]
            options.custom_flags(libc::O_NOFOLLOW);
            let file = options.open(&path)?;
            if !file.metadata()?.is_file() {
                return Err(ConfigError::Invalid(
                    "project config must be a regular file".into(),
                ));
            }
            let mut text = String::new();
            file.take(262145).read_to_string(&mut text)?;
            if text.len() > 262144 {
                return Err(ConfigError::Invalid(
                    "project config exceeds 256 KiB".into(),
                ));
            }
            let project: ConfigFile = toml::from_str(&text)?;
            let mut merged =
                serde_json::to_value(&config).map_err(|e| ConfigError::Invalid(e.to_string()))?;
            let overlay =
                serde_json::to_value(project).map_err(|e| ConfigError::Invalid(e.to_string()))?;
            for (key, value) in overlay.as_object().expect("config object") {
                if !value.is_null() && !value.as_object().is_some_and(|map| map.is_empty()) {
                    if key == "profiles" {
                        // Profiles inherit by name, then by explicitly present field.
                        // An empty table is an overlay with no changes, not deletion.
                        if merged["profiles"].is_null() {
                            merged["profiles"] = serde_json::json!({});
                        }
                        for (name, fields) in value.as_object().expect("profiles object") {
                            if merged["profiles"][name].is_null() {
                                merged["profiles"][name] = fields.clone();
                            } else {
                                for (field, setting) in fields.as_object().expect("profile object")
                                {
                                    merged["profiles"][name][field] = setting.clone();
                                }
                            }
                        }
                    } else {
                        merged[key] = value.clone();
                    }
                }
            }
            config =
                serde_json::from_value(merged).map_err(|e| ConfigError::Invalid(e.to_string()))?;
        }
    }
    config.validate()?;
    Ok(config)
}

/// Resolve user defaults plus <workspace>/.zenpi/config.toml, then environment
/// and CLI overrides. Auth always remains in the user credential store.
/// A malformed project config fails preparation before any owner is switched.
pub fn resolve_workspace(
    overrides: &ConfigOverrides,
    workspace: Option<&Path>,
) -> Result<EffectiveConfig, ConfigError> {
    let paths = ConfigPaths::discover()?;
    let mut config = load_workspace_config(&paths, workspace)?;
    let mut auth = load_auth(&paths)?;
    // A fresh zenpi install should work with the provider the user already
    // configured for Codex. This fallback is read-only; `config import-codex`
    // remains the explicit persistence command.
    let environment_profile = env::var("ZENPI_PROFILE").ok();
    let requested_profile = overrides
        .profile
        .as_deref()
        .or(environment_profile.as_deref());
    let environment = text_environment();
    let initial = resolve(overrides, &config, &auth, &environment)?;
    if initial.backend == "openai"
        && !initial.wire_api.as_deref().is_some_and(|v| {
            matches!(
                v,
                "anthropic_messages"
                    | "anthropic-messages"
                    | "google_generative_ai"
                    | "google-generative-ai"
            )
        })
        && (initial.base_url.is_none()
            || initial.model.is_none()
            || (initial.requires_openai_auth && initial.api_key.is_none()))
        && let Ok(import) = import_codex_from_root(codex_root()?)
    {
        if config.provider.is_none() {
            config.provider = import.config.provider;
        }
        if config.model.is_none() {
            config.model = import.config.model;
        }
        if config.base_url.is_none() {
            config.base_url = import.config.base_url;
        }
        if config.wire_api.is_none() {
            config.wire_api = import.config.wire_api;
        }
        if config.model_reasoning_effort.is_none() {
            config.model_reasoning_effort = import.config.model_reasoning_effort;
        }
        if config.model_verbosity.is_none() {
            config.model_verbosity = import.config.model_verbosity;
        }
        if config.backend.is_none() {
            config.backend = import.config.backend;
        }
        if config.requires_openai_auth.is_none() {
            config.requires_openai_auth = import.config.requires_openai_auth;
        }
        if config.supports_websockets.is_none() {
            config.supports_websockets = import.config.supports_websockets;
        }
        if auth
            .api_key_for_profile(requested_profile.or(config.default_profile.as_deref()))
            .is_none()
            && let Some(key) = import.api_key
        {
            auth.set_openai_api_key(key)?;
        }
    }
    resolve(overrides, &config, &auth, &environment)
}

/// Result of importing Codex settings.  The key is retained for writing but
/// is deliberately absent from Debug output and status/reporting values.
#[derive(Clone, PartialEq, Eq)]
pub struct CodexImport {
    pub config: ConfigFile,
    pub api_key: Option<String>,
    pub source_config: PathBuf,
    pub source_auth: PathBuf,
}

impl std::fmt::Debug for CodexImport {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter
            .debug_struct("CodexImport")
            .field("config", &self.config)
            .field("api_key", &self.api_key.as_ref().map(|_| "<redacted>"))
            .field("source_config", &self.source_config)
            .field("source_auth", &self.source_auth)
            .finish()
    }
}

/// Read the provider/model/endpoint from `~/.codex/config.toml` and the
/// `OPENAI_API_KEY` credential from `~/.codex/auth.json` without printing it.
pub fn import_codex_from_home(home: impl AsRef<Path>) -> Result<CodexImport, ConfigError> {
    import_codex_from_root(home.as_ref().join(".codex"))
}

fn import_codex_from_root(codex_root: impl AsRef<Path>) -> Result<CodexImport, ConfigError> {
    let codex_root = codex_root.as_ref();
    let source_config = codex_root.join(CONFIG_FILE);
    let source_auth = codex_root.join(AUTH_FILE);
    reject_symlink(&source_config)?;
    reject_symlink(&source_auth)?;
    let config_text = fs::read_to_string(&source_config).map_err(|error| {
        if error.kind() == io::ErrorKind::NotFound {
            ConfigError::MissingCodex(source_config.clone())
        } else {
            ConfigError::Io(error)
        }
    })?;
    let root: toml::Value = toml::from_str(&config_text)?;
    let provider_name = root
        .get("model_provider")
        .and_then(toml::Value::as_str)
        .map(str::to_owned);
    let provider_table = root
        .get("model_providers")
        .and_then(toml::Value::as_table)
        .and_then(|providers| {
            provider_name
                .as_deref()
                .and_then(|name| providers.get(name))
                .or_else(|| providers.get("OpenAI"))
                .or_else(|| providers.values().next())
        })
        .and_then(toml::Value::as_table);
    let model = root
        .get("model")
        .and_then(toml::Value::as_str)
        .map(str::to_owned);
    let base_url = provider_table
        .and_then(|table| table.get("base_url"))
        .and_then(toml::Value::as_str)
        .map(str::to_owned);
    let wire_api = provider_table
        .and_then(|table| table.get("wire_api"))
        .and_then(toml::Value::as_str)
        .map(str::to_owned);
    let model_reasoning_effort = root
        .get("model_reasoning_effort")
        .and_then(toml::Value::as_str)
        .map(str::to_owned);
    let model_verbosity = root
        .get("model_verbosity")
        .and_then(toml::Value::as_str)
        .map(str::to_owned);
    let timeout_seconds = root
        .get("request_timeout_seconds")
        .or_else(|| root.get("timeout_seconds"))
        .and_then(toml::Value::as_integer)
        .and_then(|value| u64::try_from(value).ok());
    let max_retries = root
        .get("max_retries")
        .and_then(toml::Value::as_integer)
        .and_then(|value| u32::try_from(value).ok());
    let requires_openai_auth = provider_table
        .and_then(|table| table.get("requires_openai_auth"))
        .and_then(toml::Value::as_bool);
    let supports_websockets = provider_table
        .and_then(|table| table.get("supports_websockets"))
        .and_then(toml::Value::as_bool);
    let provider = provider_name.or_else(|| {
        provider_table
            .and_then(|table| table.get("name"))
            .and_then(toml::Value::as_str)
            .map(str::to_owned)
    });
    let config = ConfigFile {
        default_profile: None,
        profiles: BTreeMap::new(),
        backend: Some("openai".into()),
        provider,
        model,
        base_url,
        wire_api,
        auth_env: Some(OPENAI_API_KEY.into()),
        model_reasoning_effort,
        model_verbosity,
        timeout_seconds,
        max_retries,
        requires_openai_auth,
        supports_websockets,
        model_overrides: Vec::new(),
    };
    config.validate()?;
    let api_key = match fs::read_to_string(&source_auth) {
        Ok(auth_text) => {
            let value: Value = serde_json::from_str(&auth_text)?;
            find_api_key(&value, config.provider.as_deref())
                .filter(|key| !key.trim().is_empty())
                .map(str::to_owned)
        }
        Err(error) if error.kind() == io::ErrorKind::NotFound => None,
        Err(error) => return Err(ConfigError::Io(error)),
    };
    Ok(CodexImport {
        config,
        api_key,
        source_config,
        source_auth,
    })
}

/// Pair zenpi with Codex.  Existing non-secret settings and unrelated auth
/// keys are preserved; repeated calls are byte-idempotent and report
/// `changed == false` after the first successful import.
pub fn pair_from_codex(paths: &ConfigPaths) -> Result<PairReport, ConfigError> {
    let home = paths
        .root
        .parent()
        .ok_or_else(|| ConfigError::Invalid("zenpi root has no home parent".into()))?;
    pair_from_codex_with_source(paths, home)
}

/// Command-facing Codex pairing helper.  It intentionally performs the
/// import (rather than merely parsing Codex files), so `zenpi config
/// import-codex` is useful on a fresh machine and safe to repeat.
pub fn import_codex() -> Result<ConfigSummary, ConfigError> {
    let paths = ConfigPaths::discover()?;
    let pair = pair_from_codex_with_root(&paths, codex_root()?)?;
    let status = status(&paths)?;
    Ok(ConfigSummary {
        operation: "import-codex".into(),
        changed: Some(pair.changed),
        status,
    })
}

/// Import Codex into an explicit profile and make that profile active. This
/// is the preferred new-file representation; the legacy flat import remains
/// available so existing installations are not rewritten unexpectedly.
pub fn import_codex_profile(profile: &str) -> Result<ConfigSummary, ConfigError> {
    validate_profile_name(profile)?;
    let paths = ConfigPaths::discover()?;
    let import = import_codex_from_root(codex_root()?)?;
    paths.ensure_root()?;
    let mut config = load_config(&paths)?;
    config.profiles.insert(
        profile.to_owned(),
        ProviderProfile::from_flat(&import.config),
    );
    config.default_profile = Some(profile.to_owned());
    config.validate()?;
    let mut auth = load_auth(&paths)?;
    if let Some(key) = import.api_key {
        auth.set_profile_api_key(profile, key)?;
    }
    let config_changed = save_config(&paths, &config)?;
    let auth_changed = save_auth(&paths, &auth)?;
    let mut summary = doctor_for_profile(&paths, Some(profile))?;
    summary.operation = "import-codex".into();
    summary.changed = Some(config_changed || auth_changed);
    Ok(summary)
}

fn pair_from_codex_with_source(
    paths: &ConfigPaths,
    codex_home: impl AsRef<Path>,
) -> Result<PairReport, ConfigError> {
    pair_from_codex_with_root(paths, codex_home.as_ref().join(".codex"))
}

fn pair_from_codex_with_root(
    paths: &ConfigPaths,
    codex_root: impl AsRef<Path>,
) -> Result<PairReport, ConfigError> {
    let import = import_codex_from_root(codex_root)?;
    paths.ensure_root()?;
    let mut config = load_config(paths)?;
    // Import only fields actually present in Codex.  A partial Codex profile
    // must not erase a hand-edited zenpi setting.
    if import.config.backend.is_some() {
        config.backend = import.config.backend;
    }
    if import.config.provider.is_some() {
        config.provider = import.config.provider;
    }
    if import.config.model.is_some() {
        config.model = import.config.model;
    }
    if import.config.base_url.is_some() {
        config.base_url = import.config.base_url;
    }
    if import.config.wire_api.is_some() {
        config.wire_api = import.config.wire_api;
    }
    if import.config.auth_env.is_some() {
        config.auth_env = import.config.auth_env;
    }
    if import.config.model_reasoning_effort.is_some() {
        config.model_reasoning_effort = import.config.model_reasoning_effort;
    }
    if import.config.model_verbosity.is_some() {
        config.model_verbosity = import.config.model_verbosity;
    }
    if import.config.timeout_seconds.is_some() {
        config.timeout_seconds = import.config.timeout_seconds;
    }
    if import.config.max_retries.is_some() {
        config.max_retries = import.config.max_retries;
    }
    if import.config.requires_openai_auth.is_some() {
        config.requires_openai_auth = import.config.requires_openai_auth;
    }
    if import.config.supports_websockets.is_some() {
        config.supports_websockets = import.config.supports_websockets;
    }
    config.validate()?;
    let mut auth = load_auth(paths)?;
    let key_imported = if let Some(key) = import.api_key {
        let changed = auth.openai_api_key() != Some(key.as_str());
        auth.set_openai_api_key(key)?;
        changed
    } else {
        false
    };
    let config_changed = write_config_if_changed(paths, &config)?;
    let auth_changed = write_auth_if_changed(paths, &auth)?;
    let backend = config.backend.clone().unwrap_or_else(|| "openai".into());
    Ok(PairReport {
        changed: config_changed || auth_changed,
        config_changed,
        auth_changed,
        key_imported,
        backend,
        provider: config.provider,
        model: config.model,
        base_url: config.base_url,
        wire_api: config.wire_api,
    })
}

/// Command-facing, non-mutating diagnostics.  The returned summary contains
/// only provider metadata and credential presence/source, never a key.
pub fn doctor() -> Result<ConfigSummary, ConfigError> {
    let paths = ConfigPaths::discover()?;
    doctor_for_profile(&paths, None)
}

pub fn doctor_for_profile(
    paths: &ConfigPaths,
    profile: Option<&str>,
) -> Result<ConfigSummary, ConfigError> {
    Ok(ConfigSummary {
        operation: "doctor".into(),
        changed: None,
        status: status_for_profile(paths, profile)?,
    })
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ProfileSummary {
    pub name: String,
    pub active: bool,
    pub provider: Option<String>,
    pub model: Option<String>,
    pub base_url: Option<String>,
    pub wire_api: Option<String>,
    pub api_key_present: bool,
}

pub fn list_profiles(paths: &ConfigPaths) -> Result<Vec<ProfileSummary>, ConfigError> {
    let config = load_config(paths)?;
    let auth = load_auth(paths)?;
    let mut profiles = Vec::with_capacity(config.profiles.len());
    for (name, profile) in &config.profiles {
        profiles.push(ProfileSummary {
            name: name.clone(),
            active: config.default_profile.as_deref() == Some(name),
            provider: profile.provider.clone(),
            model: profile.model.clone(),
            base_url: profile.base_url.as_deref().map(redacted_endpoint),
            wire_api: profile.wire_api.clone(),
            api_key_present: auth.api_key_for_profile(Some(name)).is_some(),
        });
    }
    Ok(profiles)
}

pub fn use_profile(paths: &ConfigPaths, profile: &str) -> Result<bool, ConfigError> {
    validate_profile_name(profile)?;
    let mut config = load_config(paths)?;
    if !config.profiles.contains_key(profile) {
        return Err(ConfigError::Invalid(format!(
            "provider profile `{profile}` does not exist"
        )));
    }
    config.default_profile = Some(profile.to_owned());
    save_config(paths, &config)
}

/// Remove only credentials owned by zenpi. Codex config/auth files are never
/// opened for writing by this path.
pub fn revoke(paths: &ConfigPaths, profile: Option<&str>) -> Result<bool, ConfigError> {
    let mut auth = load_auth(paths)?;
    let changed = match profile {
        Some(profile) => auth.remove_profile_api_key(profile)?,
        None => auth.remove_openai_api_key(),
    };
    if changed {
        save_auth(paths, &auth)?;
    }
    Ok(changed)
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ConfigSummary {
    pub operation: String,
    pub changed: Option<bool>,
    pub status: ConfigStatus,
}

impl ConfigSummary {
    /// Human-readable and secret-free output for command-line use.  URLs are
    /// intentionally retained because endpoint configuration is actionable;
    /// API credentials are represented only by presence/source.
    pub fn display(&self) -> String {
        let changed = self
            .changed
            .map_or_else(String::new, |value| format!(" changed={value}"));
        format!(
            "zenpi {operation}:{changed} profile={profile} backend={backend} provider={provider} model={model} base_url={base_url} wire_api={wire_api} api_key={key}",
            operation = self.operation,
            changed = changed,
            profile = self.status.profile.as_deref().unwrap_or("default"),
            backend = self.status.backend,
            provider = self.status.provider.as_deref().unwrap_or("-"),
            model = self.status.model.as_deref().unwrap_or("-"),
            base_url = self
                .status
                .base_url
                .as_deref()
                .map(redacted_endpoint)
                .as_deref()
                .unwrap_or("-"),
            wire_api = self.status.wire_api.as_deref().unwrap_or("-"),
            key = if self.status.api_key_present {
                match self.status.api_key_source {
                    CredentialSource::CommandLine => "present(command_line)",
                    CredentialSource::Environment => "present(environment)",
                    CredentialSource::AuthFile => "present(auth_file)",
                    CredentialSource::None => "present",
                }
            } else {
                "missing"
            },
        )
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct PairReport {
    pub changed: bool,
    pub config_changed: bool,
    pub auth_changed: bool,
    pub key_imported: bool,
    pub backend: String,
    pub provider: Option<String>,
    pub model: Option<String>,
    pub base_url: Option<String>,
    pub wire_api: Option<String>,
}

/// Redacted status data suitable for a `zenpi status` command.  It never
/// carries the key itself.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ConfigStatus {
    pub profile: Option<String>,
    pub config_exists: bool,
    pub auth_exists: bool,
    pub backend: String,
    pub provider: Option<String>,
    pub model: Option<String>,
    pub base_url: Option<String>,
    pub wire_api: Option<String>,
    pub api_key_present: bool,
    pub api_key_source: CredentialSource,
    pub requires_openai_auth: bool,
    pub supports_websockets: bool,
}

impl ConfigStatus {
    /// Whether this configuration has the minimum fields needed to start the
    /// selected provider. This is deliberately local-only: it does not claim
    /// that the endpoint is reachable or that the credential has quota.
    pub fn is_ready(&self) -> bool {
        (!self.requires_openai_auth || self.api_key_present)
            && self.base_url.is_some()
            && self.model.is_some()
    }
}

/// A secret-free entry in the model picker exposed by the interactive hosts.
/// Profiles are listed rather than credentials, so `/models` remains useful
/// even when a provider is not currently reachable.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ModelCatalogEntry {
    pub profile: Option<String>,
    pub active: bool,
    pub provider: Option<String>,
    pub model: Option<String>,
    pub backend: String,
    pub configured: bool,
    pub metadata: Option<crate::providers::registry::ModelDescriptor>,
}

/// Return the bounded, redacted model/profile catalogue used by `/models`.
/// This is deliberately read-only and never contacts a provider. A legacy
/// flat config is represented by one `default` entry; named profiles remain
/// independently selectable in the output.
pub fn model_catalog(profile: Option<&str>) -> Result<Vec<ModelCatalogEntry>, ConfigError> {
    model_catalog_in_workspace(profile, None)
}

pub fn model_catalog_in_workspace(
    profile: Option<&str>,
    workspace: Option<&Path>,
) -> Result<Vec<ModelCatalogEntry>, ConfigError> {
    let paths = ConfigPaths::discover()?;
    let config = load_workspace_config(&paths, workspace)?;
    let metadata = |provider: Option<&str>,
                    id: Option<&str>,
                    overrides: &[crate::providers::registry::ModelOverride]| {
        let registry = crate::providers::registry::ModelRegistry::with_overrides(overrides)
            .map_err(|error| ConfigError::Invalid(error.to_string()))?;
        id.map(|id| registry.resolve(provider.unwrap_or("openai"), id))
            .transpose()
            .map_err(|error| ConfigError::Invalid(error.to_string()))
    };
    if config.profiles.is_empty() {
        let resolved = resolve_workspace(
            &ConfigOverrides {
                profile: profile.map(str::to_owned),
                ..ConfigOverrides::default()
            },
            workspace,
        )?;
        let configured = resolved.model.is_some()
            && resolved.base_url.is_some()
            && (!resolved.requires_openai_auth || resolved.api_key.is_some());
        let descriptor = metadata(
            resolved.provider.as_deref(),
            resolved.model.as_deref(),
            &resolved.model_overrides,
        )?;
        return Ok(vec![ModelCatalogEntry {
            profile: resolved.profile,
            active: true,
            provider: resolved.provider,
            model: resolved.model,
            backend: resolved.backend,
            configured,
            metadata: descriptor,
        }]);
    }
    let active = profile
        .map(str::to_owned)
        .or_else(|| env::var("ZENPI_PROFILE").ok())
        .or_else(|| config.default_profile.clone());
    let auth = load_auth(&paths)?;
    config
        .profiles
        .iter()
        .map(|(name, profile_config)| {
            let api_key_present = auth.api_key_for_profile(Some(name)).is_some();
            let backend = profile_config
                .backend
                .clone()
                .unwrap_or_else(|| "openai".into());
            let provider = profile_config.provider.clone().or_else(|| {
                if backend == "google"
                    || profile_config.wire_api.as_deref().is_some_and(|v| {
                        matches!(v, "google_generative_ai" | "google-generative-ai")
                    })
                {
                    return Some("google".into());
                }
                (backend == "anthropic"
                    || profile_config
                        .wire_api
                        .as_deref()
                        .is_some_and(|v| matches!(v, "anthropic_messages" | "anthropic-messages")))
                .then(|| "anthropic".into())
            });
            let configured = profile_config.model.is_some()
                && profile_config.base_url.is_some()
                && (!profile_config.requires_openai_auth.unwrap_or(true) || api_key_present);
            Ok(ModelCatalogEntry {
                profile: Some(name.clone()),
                active: active.as_deref() == Some(name.as_str()),
                provider: provider.clone(),
                model: profile_config.model.clone(),
                backend,
                configured,
                metadata: metadata(
                    provider.as_deref(),
                    profile_config.model.as_deref(),
                    &profile_config.model_overrides,
                )?,
            })
        })
        .collect()
}

/// Build the structured `/doctor` response. Endpoint values are reduced to
/// scheme plus host by `status_for_profile`; credentials are represented only
/// by presence/source. The checks are intentionally deterministic and local.
pub fn doctor_value(profile: Option<&str>) -> Result<Value, ConfigError> {
    let paths = ConfigPaths::discover()?;
    let status = status_for_profile(&paths, profile)?;
    let ready = status.is_ready();
    let mut checks = BTreeMap::new();
    checks.insert("config_file".to_owned(), status.config_exists);
    checks.insert(
        "auth".to_owned(),
        !status.requires_openai_auth || status.api_key_present,
    );
    checks.insert("endpoint".to_owned(), status.base_url.is_some());
    checks.insert("model".to_owned(), status.model.is_some());
    Ok(serde_json::json!({
        "command": "doctor",
        "route": "local",
        "accepted": true,
        "ready": ready,
        "profile": status.profile,
        "backend": status.backend,
        "provider": status.provider,
        "model": status.model,
        "base_url": status.base_url.as_deref().map(redacted_endpoint),
        "wire_api": status.wire_api,
        "api_key_present": status.api_key_present,
        "api_key_source": status.api_key_source,
        "requires_openai_auth": status.requires_openai_auth,
        "supports_websockets": status.supports_websockets,
        "checks": checks,
    }))
}

pub fn status(paths: &ConfigPaths) -> Result<ConfigStatus, ConfigError> {
    status_for_profile(paths, None)
}

pub fn status_for_profile(
    paths: &ConfigPaths,
    profile: Option<&str>,
) -> Result<ConfigStatus, ConfigError> {
    let config_exists = paths.config.exists();
    let auth_exists = paths.auth.exists();
    // Use the same read-only Codex fallback as runtime resolution for the
    // process-wide profile.  Explicit test/custom paths remain isolated and
    // report only the files represented by that path.
    let resolved = if ConfigPaths::discover().ok().as_ref() == Some(paths) {
        resolve_default(&ConfigOverrides {
            profile: profile.map(str::to_owned),
            ..ConfigOverrides::default()
        })?
    } else {
        let config = load_config(paths)?;
        let auth = load_auth(paths)?;
        let environment = text_environment();
        resolve(
            &ConfigOverrides {
                profile: profile.map(str::to_owned),
                ..ConfigOverrides::default()
            },
            &config,
            &auth,
            &environment,
        )?
    };
    Ok(ConfigStatus {
        profile: resolved.profile,
        config_exists,
        auth_exists,
        backend: resolved.backend,
        provider: resolved.provider,
        model: resolved.model,
        base_url: resolved.base_url,
        wire_api: resolved.wire_api,
        api_key_present: resolved.api_key.is_some(),
        api_key_source: resolved.credential_source,
        requires_openai_auth: resolved.requires_openai_auth,
        supports_websockets: resolved.supports_websockets,
    })
}

/// Load the user-owned BentoBox preference document. A missing file is an
/// empty preference set (all tabs use their built-in presets); an existing
/// malformed, oversized, stale, or symlinked file is an error and is never
/// rewritten as a side effect.
pub fn load_layout_preferences(paths: &ConfigPaths) -> Result<LayoutPreferences, ConfigError> {
    let path = paths.layout_path();
    match fs::symlink_metadata(&path) {
        Err(error) if error.kind() == io::ErrorKind::NotFound => {
            return Ok(LayoutPreferences::default());
        }
        Err(error) => return Err(error.into()),
        Ok(_) => {}
    }
    secure_regular_file(&path)?;
    let bytes = read_layout_bytes(&path)?;
    LayoutPreferences::from_json_bytes(&bytes).map_err(ConfigError::from)
}

/// Migrate a legacy single-`LayoutModel` document in place. The operation is
/// explicit so a read-only status or startup path never rewrites user files;
/// parsing and validation complete before the atomic replacement begins.
pub fn migrate_layout_preferences(paths: &ConfigPaths) -> Result<bool, ConfigError> {
    let path = paths.layout_path();
    match fs::symlink_metadata(&path) {
        Err(error) if error.kind() == io::ErrorKind::NotFound => return Ok(false),
        Err(error) => return Err(error.into()),
        Ok(_) => {}
    }
    secure_regular_file(&path)?;
    let bytes = read_layout_bytes(&path)?;
    let (preferences, migrated) =
        LayoutPreferences::from_json_bytes_with_migration(&bytes).map_err(ConfigError::from)?;
    if !migrated {
        return Ok(false);
    }
    save_layout_preferences(paths, &preferences)
}

/// Atomically save a validated BentoBox preference document. Serialization and
/// validation happen before any filesystem mutation, while the common config
/// writer preserves the previous valid snapshot if a write or rename fails.
pub fn save_layout_preferences(
    paths: &ConfigPaths,
    preferences: &LayoutPreferences,
) -> Result<bool, ConfigError> {
    let bytes = preferences.to_json_bytes().map_err(ConfigError::from)?;
    paths.ensure_root()?;
    atomic_write_if_changed(&paths.layout_path(), &bytes)
}

/// Resolve one profile/tab to a layout model, falling back to the tab preset
/// when no customization has been saved.
pub fn load_layout(
    paths: &ConfigPaths,
    profile: Option<&str>,
    tab: TabId,
) -> Result<LayoutModel, ConfigError> {
    load_layout_preferences(paths).and_then(|preferences| {
        preferences
            .model_for(profile, tab)
            .map_err(ConfigError::from)
    })
}

/// Persist only user-owned state for one profile/tab. Capabilities remain a
/// host concern and are intentionally not serialized.
pub fn save_layout(
    paths: &ConfigPaths,
    profile: Option<&str>,
    model: &LayoutModel,
) -> Result<bool, ConfigError> {
    let mut preferences = load_layout_preferences(paths)?;
    let changed = preferences
        .set_model(profile, model)
        .map_err(ConfigError::from)?;
    if !changed {
        return Ok(false);
    }
    save_layout_preferences(paths, &preferences)
}

/// Reset one profile/tab to its built-in preset. Reset is idempotent and does
/// not create a preference file when no customization exists.
pub fn reset_layout(
    paths: &ConfigPaths,
    profile: Option<&str>,
    tab: TabId,
) -> Result<bool, ConfigError> {
    let mut preferences = load_layout_preferences(paths)?;
    let changed = preferences
        .reset_tab(profile, tab)
        .map_err(ConfigError::from)?;
    if !changed {
        return Ok(false);
    }
    save_layout_preferences(paths, &preferences)
}

/// Reset every saved tab for one profile. This is useful for a profile-level
/// `/layout reset` command while retaining other profiles' preferences.
pub fn reset_layout_profile(
    paths: &ConfigPaths,
    profile: Option<&str>,
) -> Result<bool, ConfigError> {
    let mut preferences = load_layout_preferences(paths)?;
    let changed = preferences
        .reset_profile(profile)
        .map_err(ConfigError::from)?;
    if !changed {
        return Ok(false);
    }
    save_layout_preferences(paths, &preferences)
}

fn read_layout_bytes(path: &Path) -> Result<Vec<u8>, ConfigError> {
    let mut options = OpenOptions::new();
    options.read(true);
    #[cfg(unix)]
    options.custom_flags(libc::O_NOFOLLOW);
    let mut file = options.open(path)?;
    let mut bytes = Vec::new();
    // Read one byte beyond the limit so an oversized file is rejected without
    // allocating the complete hostile payload.
    Read::by_ref(&mut file)
        .take((MAX_LAYOUT_PREFERENCES_BYTES as u64).saturating_add(1))
        .read_to_end(&mut bytes)?;
    if bytes.len() > MAX_LAYOUT_PREFERENCES_BYTES {
        return Err(LayoutError::Json(format!(
            "layout preferences exceed {} bytes",
            MAX_LAYOUT_PREFERENCES_BYTES
        ))
        .into());
    }
    Ok(bytes)
}

/// Return a path inside the configured zenpi root. Reject absolute paths and
/// parent traversal so session/skill/extension commands cannot escape it.
pub fn scoped_path(
    paths: &ConfigPaths,
    relative: impl AsRef<Path>,
) -> Result<PathBuf, ConfigError> {
    let relative = relative.as_ref();
    if relative.is_absolute()
        || relative
            .components()
            .any(|component| matches!(component, std::path::Component::ParentDir))
    {
        return Err(ConfigError::Invalid(
            "path must stay inside ~/.zenpi".into(),
        ));
    }
    Ok(paths.root.join(relative))
}

pub fn load_config(paths: &ConfigPaths) -> Result<ConfigFile, ConfigError> {
    match fs::symlink_metadata(&paths.config) {
        Err(error) if error.kind() == io::ErrorKind::NotFound => {
            return Ok(ConfigFile::default());
        }
        Err(error) => return Err(error.into()),
        Ok(_) => {}
    }
    secure_regular_file(&paths.config)?;
    let text = fs::read_to_string(&paths.config)?;
    let config: ConfigFile = toml::from_str(&text)?;
    config.validate()?;
    Ok(config)
}

pub fn load_auth(paths: &ConfigPaths) -> Result<AuthFile, ConfigError> {
    match fs::symlink_metadata(&paths.auth) {
        Err(error) if error.kind() == io::ErrorKind::NotFound => {
            return Ok(AuthFile::default());
        }
        Err(error) => return Err(error.into()),
        Ok(_) => {}
    }
    secure_regular_file(&paths.auth)?;
    let text = fs::read_to_string(&paths.auth)?;
    let auth: AuthFile = serde_json::from_str(&text)?;
    if let Some(key) = auth.openai_api_key()
        && (key.trim().is_empty() || key.chars().any(char::is_control))
    {
        return Err(ConfigError::Invalid("OPENAI_API_KEY is invalid".into()));
    }
    if let Some(key) = auth.openai_api_key() {
        crate::security::register_secret_value(key);
    }
    Ok(auth)
}

pub fn save_config(paths: &ConfigPaths, config: &ConfigFile) -> Result<bool, ConfigError> {
    config.validate()?;
    paths.ensure_root()?;
    let text = toml::to_string_pretty(config)?;
    atomic_write_if_changed(&paths.config, text.as_bytes())
}

pub fn save_auth(paths: &ConfigPaths, auth: &AuthFile) -> Result<bool, ConfigError> {
    if let Some(key) = auth.openai_api_key()
        && (key.trim().is_empty() || key.chars().any(char::is_control))
    {
        return Err(ConfigError::Invalid("OPENAI_API_KEY is invalid".into()));
    }
    paths.ensure_root()?;
    let text = serde_json::to_string_pretty(auth)? + "\n";
    atomic_write_if_changed(&paths.auth, text.as_bytes())
}

fn write_config_if_changed(paths: &ConfigPaths, config: &ConfigFile) -> Result<bool, ConfigError> {
    config.validate()?;
    paths.ensure_root()?;
    let text = toml::to_string_pretty(config)?;
    atomic_write_if_changed(&paths.config, text.as_bytes())
}

fn write_auth_if_changed(paths: &ConfigPaths, auth: &AuthFile) -> Result<bool, ConfigError> {
    if let Some(key) = auth.openai_api_key()
        && (key.trim().is_empty() || key.chars().any(char::is_control))
    {
        return Err(ConfigError::Invalid("OPENAI_API_KEY is invalid".into()));
    }
    paths.ensure_root()?;
    let text = serde_json::to_string_pretty(auth)? + "\n";
    atomic_write_if_changed(&paths.auth, text.as_bytes())
}

#[derive(Debug, Error)]
pub enum ConfigError {
    #[error("home directory is unavailable")]
    HomeUnavailable,
    #[error("configuration path is not a directory: {0}")]
    NotDirectory(PathBuf),
    #[error("refusing to use symlink configuration path: {0}")]
    Symlink(PathBuf),
    #[error("Codex configuration is missing: {0}")]
    MissingCodex(PathBuf),
    #[error("invalid configuration: {0}")]
    Invalid(String),
    #[error("configuration I/O: {0}")]
    Io(#[from] io::Error),
    #[error("configuration TOML: {0}")]
    Toml(#[from] toml::de::Error),
    #[error("configuration TOML serialization: {0}")]
    TomlSerialize(#[from] toml::ser::Error),
    #[error("configuration JSON: {0}")]
    Json(#[from] serde_json::Error),
    #[error("layout preferences: {0}")]
    Layout(#[from] LayoutError),
}

fn choose<'a>(
    cli: Option<&'a str>,
    env: Option<&'a str>,
    file: Option<&'a str>,
    default: &'a str,
) -> String {
    cli.or(env).or(file).unwrap_or(default).to_owned()
}

/// Accept the direct Codex key field and the common nested/profile variants,
/// while intentionally ignoring unrelated token fields.  Only string values
/// under an exact key name are eligible for import.
fn find_api_key<'a>(value: &'a Value, provider: Option<&str>) -> Option<&'a str> {
    let object = value.as_object()?;
    if let Some(candidate) = object.get(OPENAI_API_KEY).and_then(Value::as_str) {
        return Some(candidate);
    }
    // Accept only explicit, provider-scoped credential maps. Recursing through
    // arbitrary extension data could import an unrelated API key or OAuth
    // access token as the model credential.
    let profiles = object
        .get("profiles")
        .or_else(|| object.get("providers"))
        .and_then(Value::as_object)?;
    provider
        .and_then(|name| {
            profiles
                .get(name)
                .or_else(|| profiles.get(&name.to_ascii_lowercase()))
        })
        .or_else(|| profiles.get("OpenAI"))
        .or_else(|| profiles.get("openai"))
        .and_then(Value::as_object)
        .and_then(|profile| {
            profile
                .get("api_key")
                .or_else(|| profile.get(OPENAI_API_KEY))
                .and_then(Value::as_str)
        })
}

fn redacted_endpoint(endpoint: &str) -> String {
    let Some(scheme_end) = endpoint.find("://") else {
        return endpoint.to_owned();
    };
    let authority_start = scheme_end + 3;
    let authority_end = endpoint[authority_start..]
        .find(['/', '?', '#'])
        .map_or(endpoint.len(), |offset| authority_start + offset);
    let authority = &endpoint[authority_start..authority_end];
    let host = authority
        .rsplit_once('@')
        .map_or(authority, |(_, host)| host);
    format!("{}://{}", &endpoint[..scheme_end], host)
}

fn choose_optional(cli: Option<&str>, env: Option<&str>, file: Option<&str>) -> Option<String> {
    cli.or(env).or(file).map(str::to_owned)
}

fn validate_optional(name: &str, value: Option<&str>, max: usize) -> Result<(), ConfigError> {
    if let Some(value) = value
        && (value.trim().is_empty() || value.len() > max || value.chars().any(char::is_control))
    {
        return Err(ConfigError::Invalid(format!("{name} is invalid")));
    }
    Ok(())
}

fn validate_profile_name(name: &str) -> Result<(), ConfigError> {
    if name.is_empty()
        || name.len() > 128
        || name
            .chars()
            .any(|character| !(character.is_ascii_alphanumeric() || matches!(character, '_' | '-')))
    {
        return Err(ConfigError::Invalid(
            "profile name must use 1-128 ASCII letters, digits, `_`, or `-`".into(),
        ));
    }
    Ok(())
}

fn validate_api_key(key: &str) -> Result<(), ConfigError> {
    if key.trim().is_empty() || key.chars().any(char::is_control) || key.len() > 16 * 1024 {
        return Err(ConfigError::Invalid(
            "API key must be non-empty, bounded, and contain no control characters".into(),
        ));
    }
    Ok(())
}

fn home_dir() -> Result<PathBuf, ConfigError> {
    #[cfg(windows)]
    let variable = "USERPROFILE";
    #[cfg(not(windows))]
    let variable = "HOME";
    env::var_os(variable)
        .map(PathBuf::from)
        .ok_or(ConfigError::HomeUnavailable)
}

fn codex_root() -> Result<PathBuf, ConfigError> {
    if let Some(root) = env::var_os("CODEX_HOME") {
        return Ok(PathBuf::from(root));
    }
    Ok(home_dir()?.join(".codex"))
}

fn reject_symlink(path: &Path) -> Result<(), ConfigError> {
    match fs::symlink_metadata(path) {
        Ok(metadata) => {
            if metadata.file_type().is_symlink() {
                Err(ConfigError::Symlink(path.to_owned()))
            } else {
                Ok(())
            }
        }
        Err(error) if error.kind() == io::ErrorKind::NotFound => Ok(()),
        Err(error) => Err(error.into()),
    }
}

fn secure_regular_file(path: &Path) -> Result<(), ConfigError> {
    reject_symlink(path)?;
    let metadata = fs::metadata(path)?;
    if !metadata.is_file() {
        return Err(ConfigError::NotDirectory(path.to_owned()));
    }
    restrict_permissions(path, 0o600)
}

fn restrict_permissions(path: &Path, mode: u32) -> Result<(), ConfigError> {
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        let mut permissions = fs::metadata(path)?.permissions();
        permissions.set_mode(mode);
        fs::set_permissions(path, permissions)?;
    }
    let _ = (path, mode);
    Ok(())
}

pub(crate) fn atomic_write_if_changed(path: &Path, bytes: &[u8]) -> Result<bool, ConfigError> {
    match fs::symlink_metadata(path) {
        Ok(_) => {
            secure_regular_file(path)?;
            if fs::read(path)? == bytes {
                return Ok(false);
            }
        }
        Err(error) if error.kind() == io::ErrorKind::NotFound => {}
        Err(error) => return Err(error.into()),
    }
    let parent = path
        .parent()
        .ok_or_else(|| ConfigError::Invalid("configuration path has no parent".into()))?;
    let file_name = path
        .file_name()
        .and_then(|name| name.to_str())
        .ok_or_else(|| ConfigError::Invalid("configuration filename is invalid".into()))?;
    let temp = parent.join(format!(".{file_name}.tmp-{}-{}", process::id(), now_ms()));
    reject_symlink(&temp)?;
    let mut options = OpenOptions::new();
    options.write(true).create_new(true);
    #[cfg(unix)]
    {
        use std::os::unix::fs::OpenOptionsExt;
        options.mode(0o600);
    }
    let mut file: File = options.open(&temp)?;
    if let Err(error) = file.write_all(bytes).and_then(|_| file.sync_all()) {
        let _ = fs::remove_file(&temp);
        return Err(error.into());
    }
    drop(file);
    if let Err(error) = fs::rename(&temp, path) {
        let _ = fs::remove_file(&temp);
        return Err(error.into());
    }
    restrict_permissions(path, 0o600)?;
    Ok(true)
}

fn now_ms() -> u128 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_millis()
}

/// A user-selected interactive editor, separate from provider configuration.
/// Deliberately has no Debug implementation: argv/environment may be private.
#[derive(Clone)]
pub struct EditorCommand {
    pub source: &'static str,
    pub argv: Vec<String>,
    pub environment: BTreeMap<std::ffi::OsString, std::ffi::OsString>,
    pub timeout: std::time::Duration,
}

/// The complete allowlist for the explicitly requested local editor process.
const EDITOR_ENVIRONMENT: &[&str] = &[
    "PATH",
    "HOME",
    "USER",
    "LOGNAME",
    "SHELL",
    "TERM",
    "COLORTERM",
    "LANG",
    "TMPDIR",
    "TERMINFO",
    "TERMINFO_DIRS",
    "DISPLAY",
    "WAYLAND_DISPLAY",
    "XDG_RUNTIME_DIR",
    "XDG_CONFIG_HOME",
    "XDG_DATA_HOME",
    "XDG_CACHE_HOME",
    "XDG_STATE_HOME",
    "XDG_CONFIG_DIRS",
    "XDG_DATA_DIRS",
    "LC_ALL",
    "LC_CTYPE",
    "LC_NUMERIC",
    "LC_TIME",
    "LC_COLLATE",
    "LC_MONETARY",
    "LC_MESSAGES",
    "LC_PAPER",
    "LC_NAME",
    "LC_ADDRESS",
    "LC_TELEPHONE",
    "LC_MEASUREMENT",
    "LC_IDENTIFICATION",
];

/// Resolve only the startup environment, never a workspace/provider setting.
/// Error strings describe the boundary without echoing user command arguments.
pub fn resolve_editor_command(
    environment: &BTreeMap<std::ffi::OsString, std::ffi::OsString>,
) -> Result<EditorCommand, String> {
    use std::ffi::OsStr;
    let (source, raw) = environment
        .get(OsStr::new("VISUAL"))
        .map(|value| ("VISUAL", value))
        .or_else(|| environment.get(OsStr::new("EDITOR")).map(|v| ("EDITOR", v)))
        .ok_or("External editor unavailable: set VISUAL or EDITOR before starting Zenpi")?;
    let raw = raw.to_str().ok_or("Editor command must be UTF-8")?;
    if raw.len() > 4096 || raw.chars().any(|c| c.is_control() && c != '\t') {
        return Err("Editor command exceeds 4096 bytes or contains a forbidden control".into());
    }
    let argv = parse_editor_argv(raw)?;
    let timeout = match environment.get(OsStr::new("ZENPI_EDITOR_TIMEOUT_SECONDS")) {
        None => 1800,
        Some(value) => {
            let value = value
                .to_str()
                .ok_or("Editor timeout must be UTF-8 decimal seconds")?;
            if value.is_empty() || value.len() > 20 || !value.bytes().all(|b| b.is_ascii_digit()) {
                return Err("Editor timeout must be an integer from 1 to 7200 seconds".into());
            }
            value
                .parse::<u64>()
                .ok()
                .filter(|n| (1..=7200).contains(n))
                .ok_or("Editor timeout must be an integer from 1 to 7200 seconds")?
        }
    };
    let mut child_environment = BTreeMap::new();
    let mut total = 0usize;
    for key in EDITOR_ENVIRONMENT {
        if let Some(value) = environment.get(OsStr::new(key)) {
            let bytes = value.as_encoded_bytes();
            total += key.len() + bytes.len() + 2;
            if bytes.len() > 4096 || bytes.contains(&0) || total > 64 * 1024 {
                return Err(
                    "Editor environment exceeds its private allowlist budget or contains NUL"
                        .into(),
                );
            }
            child_environment.insert((*key).into(), value.clone());
        }
    }
    Ok(EditorCommand {
        source,
        argv,
        environment: child_environment,
        timeout: std::time::Duration::from_secs(timeout),
    })
}

fn parse_editor_argv(raw: &str) -> Result<Vec<String>, String> {
    let mut chars = raw.chars().peekable();
    let mut args = Vec::new();
    let mut argument = String::new();
    let mut quote = None;
    let mut started = false;
    let finish = |argument: &mut String, args: &mut Vec<String>| -> Result<(), String> {
        if argument.len() > 2048 || args.len() >= 32 {
            return Err("Editor command exceeds 32 arguments or 2048 bytes per argument".into());
        }
        args.push(std::mem::take(argument));
        Ok(())
    };
    while let Some(ch) = chars.next() {
        match (quote, ch) {
            (Some('\''), '\'') | (Some('"'), '"') => quote = None,
            (Some('\''), _) => argument.push(ch),
            (Some('"'), '\\') => match chars.peek() {
                Some('"' | '\\' | '$' | '`') => argument.push(chars.next().unwrap()),
                _ => argument.push('\\'),
            },
            (Some(_), _) => argument.push(ch),
            (None, '\'' | '"') => {
                quote = Some(ch);
                started = true;
            }
            (None, '\\') => {
                argument.push(chars.next().ok_or("Editor command has a trailing escape")?);
                started = true;
            }
            (None, ' ' | '\t') => {
                if started {
                    finish(&mut argument, &mut args)?;
                    started = false;
                }
            }
            (None, _) => {
                argument.push(ch);
                started = true;
            }
        }
    }
    if quote.is_some() {
        return Err("Editor command has an unterminated quote".into());
    }
    if started {
        finish(&mut argument, &mut args)?;
    }
    if args.first().is_none_or(String::is_empty) {
        return Err("Editor command is empty".into());
    }
    Ok(args)
}

// Provider resolution consumes textual variables only. An unrelated non-UTF8
// VISUAL/EDITOR must reach the separate OsString editor validator, not panic
// while an earlier provider configuration snapshot iterates the environment.
fn text_environment() -> BTreeMap<String, String> {
    text_environment_values(env::vars_os())
}

fn text_environment_values(
    values: impl IntoIterator<Item = (std::ffi::OsString, std::ffi::OsString)>,
) -> BTreeMap<String, String> {
    values
        .into_iter()
        .filter_map(|(key, value)| Some((key.into_string().ok()?, value.into_string().ok()?)))
        .collect()
}

#[cfg(all(test, unix))]
mod environment_snapshot_tests {
    use super::*;
    use std::{ffi::OsString, os::unix::ffi::OsStringExt};

    #[test]
    fn valid_text_values_are_unchanged_and_editor_bytes_reach_separate_validator() {
        let original: BTreeMap<OsString, OsString> = [
            ("OPENAI_API_KEY".into(), "fixture token  ".into()),
            ("ZENPI_MODEL".into(), "unicode-界".into()),
            ("EDITOR".into(), "fallback --wait".into()),
            ("VISUAL".into(), OsString::from_vec(vec![0xff])),
            (
                OsString::from_vec(vec![0xfe]),
                "unrelated invalid key".into(),
            ),
        ]
        .into_iter()
        .collect();
        assert_eq!(
            text_environment_values(original.clone()),
            BTreeMap::from([
                ("OPENAI_API_KEY".into(), "fixture token  ".into()),
                ("ZENPI_MODEL".into(), "unicode-界".into()),
                ("EDITOR".into(), "fallback --wait".into()),
            ])
        );
        assert!(resolve_editor_command(&original).is_err());
        assert_eq!(
            original.get(std::ffi::OsStr::new("VISUAL")).unwrap(),
            &OsString::from_vec(vec![0xff])
        );
    }
}
