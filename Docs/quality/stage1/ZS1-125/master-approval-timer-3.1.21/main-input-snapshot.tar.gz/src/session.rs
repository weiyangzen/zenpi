//! Append-only JSONL session persistence.
//!
//! The session file is intentionally boring: a header followed by independent
//! records.  A process can recover all complete records after a crash, ignore a
//! malformed trailing line, and append again without rewriting the transcript.

use std::{
    collections::{BTreeMap, BTreeSet},
    fs::{self, File, OpenOptions},
    io::{self, Read, Seek, SeekFrom, Write},
    path::{Path, PathBuf},
    sync::{Mutex, OnceLock},
    time::{SystemTime, UNIX_EPOCH},
};

#[cfg(unix)]
use std::os::unix::fs::OpenOptionsExt;

use serde::{Deserialize, Serialize};
use serde_json::{Value, json};
use thiserror::Error;

use crate::{
    b3::{Handoff, HandoffRecord, RuntimeIntent, unix_ms_to_rfc3339},
    core::Turn,
};

pub const SESSION_VERSION: u32 = 1;
pub const MAX_SESSION_RECORD_BYTES: usize = 1024 * 1024;
/// Maximum journal bytes recovered into one process at startup. This is large
/// enough for long interactive histories while keeping untrusted paths from
/// causing an unbounded allocation before JSON validation begins.
pub const MAX_SESSION_BYTES: usize = 256 * 1024 * 1024;

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct SessionHeader {
    pub version: u32,
    pub session_id: String,
    pub created_at_ms: u64,
    pub cwd: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct RecoveryWarning {
    pub line: usize,
    pub reason: String,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum OperationKind {
    Provider,
    Tool,
    Compaction,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum OperationOutcome {
    Succeeded,
    Failed,
    Cancelled,
    Interrupted,
    UnknownOutcome,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct InterruptedOperation {
    pub operation_id: String,
    pub kind: OperationKind,
    pub turn_id: String,
    pub retry_requires_confirmation: bool,
}

/// Durable recovery projection for an operation marker.  A marker is written
/// before dispatch and therefore an absent terminal record is never treated as
/// success.  The projection is deliberately separate from
/// [`InterruptedOperation`] so existing embedders can keep constructing the
/// compact legacy type while recovery owners gain idempotency metadata.
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum OperationRecoveryState {
    Interrupted,
    UnknownOutcome,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct OperationRecovery {
    pub operation_id: String,
    pub kind: OperationKind,
    pub turn_id: String,
    pub retry_requires_confirmation: bool,
    pub idempotency_key: String,
    pub state: OperationRecoveryState,
}

#[derive(Debug, Error)]
pub enum SessionError {
    #[error("session path is empty")]
    EmptyPath,
    #[error("session path points to a directory: {0}")]
    Directory(PathBuf),
    #[error("session path is a symbolic link: {0}")]
    Symlink(PathBuf),
    #[error("session exceeds the {max} byte startup limit (found {actual} bytes)")]
    LimitExceeded { max: usize, actual: u64 },
    #[error("session I/O: {0}")]
    Io(#[from] io::Error),
    #[error("session JSON: {0}")]
    Json(#[from] serde_json::Error),
    #[error("session record is invalid: {0}")]
    InvalidRecord(String),
    #[error("new session candidate retained: {0}")]
    CandidateRetained(String),
}

#[derive(Debug, Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
enum DecodedRecord {
    #[serde(alias = "header")]
    Session {
        version: u32,
        session_id: String,
        created_at_ms: u64,
        cwd: String,
    },
    Turn {
        turn: Turn,
    },
    Handoff {
        handoff: Handoff,
    },
    HandoffRecord {
        handoff: HandoffRecord,
    },
    RuntimeIntent {
        intent: Box<RuntimeIntent>,
    },
    Event {
        event: Value,
    },
}

/// A recoverable session and its in-memory projection.
#[derive(Debug)]
pub struct SessionStore {
    path: PathBuf,
    header: SessionHeader,
    turns: Vec<Turn>,
    handoffs: Vec<Handoff>,
    handoff_records: Vec<HandoffRecord>,
    runtime_intents: Vec<RuntimeIntent>,
    events: usize,
    event_values: Vec<Value>,
    records: Vec<SessionRecord>,
    warnings: Vec<RecoveryWarning>,
    needs_separator: bool,
    next_seq: u64,
    observed_bytes: u64,
    tree: Option<crate::session_tree::SessionTree>,
}

/// An unpublished journal is written through its exclusively created file,
/// never by reopening a path that another process may have replaced.
pub(crate) struct NewSessionFile {
    path: PathBuf,
    file: File,
    retained: bool,
}

#[cfg(windows)]
fn windows_file_identity(file: &File) -> io::Result<(u32, u32, u32)> {
    use std::os::windows::io::AsRawHandle;
    // BY_HANDLE_FILE_INFORMATION consists of thirteen DWORDs, including the
    // three FILETIMEs. File index and volume identify the opened object.
    #[repr(C)]
    struct Information {
        words: [u32; 13],
    }
    #[link(name = "kernel32")]
    unsafe extern "system" {
        fn GetFileInformationByHandle(handle: *mut std::ffi::c_void, info: *mut Information)
        -> i32;
    }
    let mut information = Information { words: [0; 13] };
    // SAFETY: File owns a live Windows handle and Information has the Win32
    // structure's layout and size; the call writes only that structure.
    if unsafe { GetFileInformationByHandle(file.as_raw_handle(), &mut information) } == 0 {
        return Err(io::Error::last_os_error());
    }
    Ok((
        information.words[7],
        information.words[11],
        information.words[12],
    ))
}

impl NewSessionFile {
    pub(crate) fn verify(&self) -> Result<(), SessionError> {
        let actual = fs::symlink_metadata(&self.path)?;
        #[cfg(unix)]
        let owned = self.file.metadata()?;
        #[cfg(unix)]
        let same = {
            use std::os::unix::fs::MetadataExt;
            actual.dev() == owned.dev() && actual.ino() == owned.ino()
        };
        #[cfg(windows)]
        let same = {
            use std::os::windows::fs::OpenOptionsExt;
            let current = OpenOptions::new()
                .read(true)
                .custom_flags(0x00200000)
                .open(&self.path)?;
            windows_file_identity(&current)? == windows_file_identity(&self.file)?
        };
        #[cfg(not(any(unix, windows)))]
        let same = false;
        if !actual.is_file() || actual.file_type().is_symlink() || !same {
            return Err(SessionError::InvalidRecord(format!(
                "new session candidate was replaced; retained path {}",
                self.path.display()
            )));
        }
        Ok(())
    }

    pub(crate) fn append_event(
        &self,
        session: &mut SessionStore,
        event: Value,
    ) -> Result<(), SessionError> {
        self.verify()?;
        let _lock = AppendLock::new(&self.file)?;
        session.append_json_to_file(&json!({"kind": "event", "event": event}), &self.file)?;
        session.events += 1;
        session.event_values.push(event);
        Ok(())
    }

    pub(crate) fn retain(&mut self) {
        self.retained = true;
    }

    pub(crate) fn cleanup(&mut self) -> Result<(), SessionError> {
        if self.retained {
            return Ok(());
        }
        self.retained = true;
        match fs::symlink_metadata(&self.path) {
            Err(error) if error.kind() == io::ErrorKind::NotFound => return Ok(()),
            Err(error) => {
                return Err(SessionError::CandidateRetained(format!(
                    "new session cleanup failed; retained {}: {error}",
                    self.path.display()
                )));
            }
            Ok(_) => {}
        }
        self.verify().map_err(|error| {
            SessionError::CandidateRetained(format!("{}: {error}", self.path.display()))
        })?;
        fs::remove_file(&self.path).map_err(|error| {
            SessionError::CandidateRetained(format!(
                "new session cleanup failed; retained {}: {error}",
                self.path.display()
            ))
        })
    }
}

impl Drop for NewSessionFile {
    fn drop(&mut self) {
        if let Err(error) = self.cleanup() {
            eprintln!("zenpi: {error}");
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct SessionSummary {
    pub path: String,
    pub session_id: String,
    pub created_at_ms: u64,
    pub turn_count: usize,
    pub handoff_count: usize,
    pub handoff_record_count: usize,
    pub runtime_intent_count: usize,
    pub event_count: usize,
    pub recovery_warnings: usize,
    pub next_seq: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct SessionSearchHit {
    pub summary: SessionSummary,
    pub matches: usize,
    pub snippets: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct SessionInspection {
    pub summary: SessionSummary,
    pub turns: Vec<Turn>,
    pub events: Vec<Value>,
    pub recovery_warnings: Vec<RecoveryWarning>,
}

/// One validated journal record with its durable sequence number.
///
/// The in-memory turn/event projections above intentionally hide the envelope
/// metadata.  Resume/recovery owners need that metadata to page through the
/// append-only journal without reparsing the file (and without accidentally
/// following a symlink), so the validated envelope is retained separately.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct SessionRecord {
    pub sequence: u64,
    pub kind: String,
    pub value: Value,
}

impl SessionStore {
    /// Create a distinct, empty journal in the already validated current
    /// session directory. Existing files (including links) are never opened.
    pub(crate) fn create_fresh(
        parent: &Path,
        cwd: &Path,
        name_digest: &str,
        cancelled: &dyn Fn() -> bool,
    ) -> Result<(Self, NewSessionFile), SessionError> {
        let parent = parent.canonicalize()?;
        let cwd = cwd.canonicalize()?;
        if !parent.is_dir()
            || !cwd.is_dir()
            || cwd.to_str().is_none()
            || name_digest.len() != 64
            || !name_digest.bytes().all(|ch| ch.is_ascii_hexdigit())
        {
            return Err(SessionError::InvalidRecord(
                "invalid new session directory or identity".into(),
            ));
        }
        for attempt in 0..16 {
            if cancelled() {
                return Err(SessionError::InvalidRecord(
                    "new session creation cancelled".into(),
                ));
            }
            let path = parent.join(format!("new-{name_digest}-{attempt}.jsonl"));
            let mut options = OpenOptions::new();
            options.read(true).append(true).create_new(true);
            #[cfg(unix)]
            options
                .mode(0o600)
                .custom_flags(libc::O_NOFOLLOW | libc::O_NONBLOCK);
            let file = match options.open(&path) {
                Ok(file) => file,
                Err(error) if error.kind() == io::ErrorKind::AlreadyExists => continue,
                Err(error) => return Err(error.into()),
            };
            let mut guard = NewSessionFile {
                path: path.clone(),
                file,
                retained: false,
            };
            let mut store = Self {
                path,
                header: SessionHeader {
                    version: SESSION_VERSION,
                    session_id: generate_id("session"),
                    created_at_ms: now_ms(),
                    cwd: cwd.display().to_string(),
                },
                turns: Vec::new(),
                handoffs: Vec::new(),
                handoff_records: Vec::new(),
                runtime_intents: Vec::new(),
                events: 0,
                event_values: Vec::new(),
                records: Vec::new(),
                warnings: Vec::new(),
                needs_separator: false,
                next_seq: 0,
                observed_bytes: 0,
                tree: None,
            };
            let header = store.header.clone();
            let result = store.append_json_to_file(&json!({"kind":"session", "version":header.version,
                "session_id":header.session_id, "created_at_ms":header.created_at_ms, "cwd":header.cwd}), &guard.file)
                .and_then(|_| guard.verify());
            if let Err(error) = result {
                return match guard.cleanup() {
                    Ok(()) => Err(error),
                    Err(cleanup) => Err(SessionError::CandidateRetained(format!(
                        "{error}; {cleanup}"
                    ))),
                };
            }
            return Ok((store, guard));
        }
        Err(SessionError::InvalidRecord(
            "new session name collision limit reached".into(),
        ))
    }

    /// Open or create a session at `path` and recover all valid records.
    pub fn open(path: impl AsRef<Path>) -> Result<Self, SessionError> {
        Self::open_with_options(path, true, None)
    }

    /// Open an existing session without creating, chmodding, or appending to
    /// it. Read-only hosts such as `session list` and `session inspect` use
    /// this path so observation cannot mutate a journal as a side effect.
    pub fn open_existing(path: impl AsRef<Path>) -> Result<Self, SessionError> {
        let path = path.as_ref();
        let metadata = session_path_metadata(path)?;
        if !metadata.is_some_and(|metadata| metadata.is_file()) {
            return Err(SessionError::InvalidRecord(
                "inspection source is not an existing session file".into(),
            ));
        }
        Self::open_with_options(path, false, None)
    }

    /// Open an existing, structurally valid journal for continued writes.
    /// Unlike [`Self::open`], this never creates a header for an empty,
    /// malformed, or unrelated regular file. Session-switch owners use this
    /// boundary so probing a user path cannot mutate it into a zenpi journal.
    pub fn open_existing_writable(path: impl AsRef<Path>) -> Result<Self, SessionError> {
        let path = path.as_ref();
        let inspected = Self::open_existing(path)?;
        let valid_header = inspected
            .records
            .first()
            .is_some_and(|record| record.kind == "session" && record.sequence == 0);
        if !valid_header || !inspected.warnings.is_empty() {
            return Err(SessionError::InvalidRecord(
                "resume source is not a clean zenpi session journal".into(),
            ));
        }
        Self::open_with_options(path, true, None)
    }

    /// Reconcile duplicate startup audits from a competing host after a
    /// rejected new-session proposal. Keep this session's owner and input
    /// port: the only admissible tail repeats its current extension selection.
    pub(crate) fn refresh_extension_audit_tail(&mut self) -> Result<(), SessionError> {
        let metadata = session_path_metadata(&self.path)?
            .ok_or_else(|| SessionError::InvalidRecord("session journal disappeared".into()))?;
        if metadata.len() == self.observed_bytes {
            return Ok(());
        }
        let current = Self::open_existing(&self.path)?;
        let selected = self
            .event_values
            .iter()
            .rev()
            .find(|event| event["type"] == "extensions_selected");
        let prefix_matches =
            current.header == self.header
                && current.records.len() >= self.records.len()
                && current.records.iter().zip(&self.records).all(|(a, b)| {
                    a.sequence == b.sequence && a.kind == b.kind && a.value == b.value
                });
        let tail = current
            .records
            .get(self.records.len()..)
            .unwrap_or_default();
        if !prefix_matches
            || !current.warnings.is_empty()
            || tail.is_empty()
            || tail.len() > 64
            || !tail.iter().all(|record| {
                record.kind == "event"
                    && selected.is_some_and(|event| &record.value["event"] == event)
            })
        {
            return Err(SessionError::InvalidRecord(
                "session changed beyond repeated extension startup audits; reopen the journal"
                    .into(),
            ));
        }
        *self = current;
        Ok(())
    }

    /// Open a project journal with an explicit canonical workspace. Existing
    /// journals must already belong to that workspace; inspection is read-only.
    pub fn open_in_workspace(
        path: impl AsRef<Path>,
        cwd: impl AsRef<Path>,
    ) -> Result<Self, SessionError> {
        let cwd = cwd.as_ref().canonicalize()?;
        if !cwd.is_dir() || cwd.to_str().is_none() {
            return Err(SessionError::InvalidRecord(
                "workspace must be a UTF-8 directory".into(),
            ));
        }
        if session_path_metadata(path.as_ref())?.is_some() {
            let inspected = Self::open_existing(path.as_ref())?;
            if Path::new(&inspected.header.cwd).canonicalize()? != cwd {
                return Err(SessionError::InvalidRecord(
                    "session belongs to a different workspace".into(),
                ));
            }
            return Self::open_existing_writable(path);
        }
        Self::open_with_options(path, true, Some(&cwd))
    }

    fn open_with_options(
        path: impl AsRef<Path>,
        writable: bool,
        workspace: Option<&Path>,
    ) -> Result<Self, SessionError> {
        let path = path.as_ref().to_path_buf();
        if path.as_os_str().is_empty() {
            return Err(SessionError::EmptyPath);
        }
        let existing = session_path_metadata(&path)?;
        if existing.as_ref().is_some_and(|metadata| metadata.is_dir()) {
            return Err(SessionError::Directory(path));
        }
        if writable
            && let Some(parent) = path
                .parent()
                .filter(|parent| !parent.as_os_str().is_empty())
        {
            fs::create_dir_all(parent)?;
        }

        // Re-check immediately before opening the file. The first metadata
        // probe prevents a normal symlink from being chmodded; this second
        // probe closes the common replacement race, while O_NOFOLLOW in
        // `read_session_bytes` handles the final open atomically on Unix.
        let _ = session_path_metadata(&path)?;
        let bytes = match read_session_bytes(&path) {
            Ok(bytes) => bytes,
            Err(ReadSessionError::Io(error)) if error.kind() == io::ErrorKind::NotFound => {
                Vec::new()
            }
            Err(ReadSessionError::Io(error)) => return Err(error.into()),
            Err(ReadSessionError::LimitExceeded { actual }) => {
                return Err(SessionError::LimitExceeded {
                    max: MAX_SESSION_BYTES,
                    actual,
                });
            }
        };
        if writable && existing.is_some() {
            restrict_session_permissions(&path)?;
        }
        let observed_bytes = bytes.len() as u64;
        let had_content = !bytes.is_empty();
        let needs_separator = had_content && !bytes.ends_with(b"\n");
        let mut header: Option<SessionHeader> = None;
        let mut turns = Vec::new();
        let mut handoffs = Vec::new();
        let mut handoff_records = Vec::new();
        let mut runtime_intents = Vec::new();
        let mut events = 0;
        let mut event_values = Vec::new();
        let mut records = Vec::new();
        let mut warnings = Vec::new();
        let mut next_seq = 0_u64;
        let mut last_seq = None;

        for (index, raw_line) in bytes.split(|byte| *byte == b'\n').enumerate() {
            let line_number = index + 1;
            let line = raw_line.strip_suffix(b"\r").unwrap_or(raw_line);
            if line.iter().all(u8::is_ascii_whitespace) {
                continue;
            }
            let value = match serde_json::from_slice::<Value>(line) {
                Ok(value) => value,
                Err(error) => {
                    warnings.push(RecoveryWarning {
                        line: line_number,
                        reason: format!("ignored malformed record: {error}"),
                    });
                    continue;
                }
            };
            if let Some(version) = value.get("schema_version").and_then(Value::as_u64)
                && version != u64::from(SESSION_VERSION)
            {
                warnings.push(RecoveryWarning {
                    line: line_number,
                    reason: "ignored unsupported session schema".into(),
                });
                continue;
            }
            if let Some(expected) = header.as_ref().map(|item| item.session_id.as_str())
                && value
                    .get("session_id")
                    .and_then(Value::as_str)
                    .is_some_and(|actual| actual != expected)
            {
                warnings.push(RecoveryWarning {
                    line: line_number,
                    reason: "ignored record from another session".into(),
                });
                continue;
            }
            let sequence = value.get("seq").and_then(Value::as_u64);
            if let Some(sequence) = sequence
                && last_seq.is_some_and(|last| sequence <= last)
            {
                warnings.push(RecoveryWarning {
                    line: line_number,
                    reason: "ignored non-monotonic sequence".into(),
                });
                continue;
            }
            let raw_value = value.clone();
            let record = match serde_json::from_value::<DecodedRecord>(value) {
                Ok(record) => record,
                Err(error) => {
                    warnings.push(RecoveryWarning {
                        line: line_number,
                        reason: format!("ignored malformed record: {error}"),
                    });
                    continue;
                }
            };
            if header.is_none() && !matches!(&record, DecodedRecord::Session { .. }) {
                warnings.push(RecoveryWarning {
                    line: line_number,
                    reason: "ignored record before session header".into(),
                });
                continue;
            }
            let record_sequence = sequence.unwrap_or(next_seq);
            let Some(following_sequence) = record_sequence.checked_add(1) else {
                warnings.push(RecoveryWarning {
                    line: line_number,
                    reason: "ignored record with exhausted sequence".into(),
                });
                continue;
            };
            let accepted = match record {
                DecodedRecord::Session {
                    version,
                    session_id,
                    created_at_ms,
                    cwd,
                } => {
                    if version != SESSION_VERSION {
                        warnings.push(RecoveryWarning {
                            line: line_number,
                            reason: "ignored unsupported session version".into(),
                        });
                        false
                    } else if header.is_some() {
                        warnings.push(RecoveryWarning {
                            line: line_number,
                            reason: "ignored duplicate session header".into(),
                        });
                        false
                    } else {
                        header = Some(SessionHeader {
                            version,
                            session_id,
                            created_at_ms,
                            cwd,
                        });
                        true
                    }
                }
                DecodedRecord::Turn { turn } => match turn.validate() {
                    Ok(()) => {
                        turns.push(turn);
                        true
                    }
                    Err(error) => {
                        warnings.push(RecoveryWarning {
                            line: line_number,
                            reason: format!("ignored invalid turn: {error}"),
                        });
                        false
                    }
                },
                DecodedRecord::Handoff { handoff } => {
                    if handoff.validate().is_err() {
                        warnings.push(RecoveryWarning {
                            line: line_number,
                            reason: "ignored invalid handoff".into(),
                        });
                        false
                    } else {
                        handoffs.push(handoff);
                        true
                    }
                }
                DecodedRecord::HandoffRecord { handoff } => {
                    if handoff.validate().is_err()
                        || header
                            .as_ref()
                            .is_some_and(|item| item.session_id != handoff.session_id)
                    {
                        warnings.push(RecoveryWarning {
                            line: line_number,
                            reason: "ignored invalid handoff record".into(),
                        });
                        false
                    } else {
                        handoff_records.push(handoff);
                        true
                    }
                }
                DecodedRecord::RuntimeIntent { intent } => {
                    let intent = *intent;
                    if intent.validate().is_err()
                        || header
                            .as_ref()
                            .is_some_and(|item| item.session_id != intent.session_id)
                    {
                        warnings.push(RecoveryWarning {
                            line: line_number,
                            reason: "ignored invalid runtime intent".into(),
                        });
                        false
                    } else {
                        runtime_intents.push(intent);
                        true
                    }
                }
                DecodedRecord::Event { event } => {
                    event_values.push(event);
                    events += 1;
                    true
                }
            };
            if accepted {
                last_seq = Some(record_sequence);
                next_seq = following_sequence;
                let kind = raw_value
                    .get("kind")
                    .and_then(Value::as_str)
                    .unwrap_or("unknown")
                    .to_owned();
                records.push(SessionRecord {
                    sequence: record_sequence,
                    kind,
                    value: raw_value,
                });
            }
        }

        let needs_header = header.is_none();
        let mut store = Self {
            path,
            header: header.unwrap_or_else(|| SessionHeader {
                version: SESSION_VERSION,
                session_id: generate_id("session"),
                created_at_ms: now_ms(),
                cwd: workspace
                    .map(Path::to_path_buf)
                    .unwrap_or_else(|| {
                        std::env::current_dir().unwrap_or_else(|_| PathBuf::from("."))
                    })
                    .display()
                    .to_string(),
            }),
            turns,
            handoffs,
            handoff_records,
            runtime_intents,
            events,
            event_values,
            records,
            warnings,
            needs_separator,
            next_seq,
            observed_bytes,
            tree: None,
        };
        if writable && (!had_content || needs_header) {
            // A header is the only record whose absence changes the meaning of
            // subsequent records.  Append one, preserving all existing bytes.
            let header = store.header.clone();
            store.append_json(&json!({
                "kind": "session",
                "version": header.version,
                "session_id": header.session_id,
                "created_at_ms": header.created_at_ms,
                "cwd": header.cwd,
            }))?;
        }
        if store.records.iter().any(|record| {
            record.value.get("tree_entry").is_some()
                || record.value["event"]["type"] == "session_tree"
        }) {
            store.tree = Some(crate::session_tree::SessionTree::recover(
                store.session_id(),
                &store.records,
                Default::default(),
                &|| false,
            )?);
        }
        Ok(store)
    }

    pub fn default_path() -> PathBuf {
        if let Ok(path) = std::env::var("ZENPI_SESSION")
            && !path.trim().is_empty()
        {
            return PathBuf::from(path);
        }
        let base = std::env::var_os("HOME")
            .map(PathBuf::from)
            .unwrap_or_else(|| PathBuf::from("."));
        base.join(".zenpi").join("session.jsonl")
    }

    pub fn path(&self) -> &Path {
        &self.path
    }

    pub fn header(&self) -> &SessionHeader {
        &self.header
    }

    pub fn session_id(&self) -> &str {
        &self.header.session_id
    }

    pub fn turns(&self) -> &[Turn] {
        &self.turns
    }

    pub fn handoffs(&self) -> &[Handoff] {
        &self.handoffs
    }

    pub fn recovery_warnings(&self) -> &[RecoveryWarning] {
        &self.warnings
    }

    pub fn summary(&self) -> SessionSummary {
        SessionSummary {
            path: self.path.display().to_string(),
            session_id: self.header.session_id.clone(),
            created_at_ms: self.header.created_at_ms,
            turn_count: self.turns.len(),
            handoff_count: self.handoffs.len() + self.handoff_records.len(),
            handoff_record_count: self.handoff_records.len(),
            runtime_intent_count: self.runtime_intents.len(),
            event_count: self.events,
            recovery_warnings: self.warnings.len(),
            next_seq: self.next_seq,
        }
    }

    /// Persist and then retain a turn.  If the write fails, the in-memory
    /// projection is unchanged.
    pub fn append_turn(&mut self, turn: Turn) -> Result<(), SessionError> {
        turn.validate()
            .map_err(|error| SessionError::InvalidRecord(error.to_string()))?;
        if let Some(existing) = self.turns.iter().find(|existing| existing.id == turn.id) {
            if existing == &turn {
                return Ok(());
            }
            return Err(SessionError::InvalidRecord(
                "turn ID conflicts with its durable content".into(),
            ));
        }
        let entry = self
            .tree
            .as_ref()
            .map(|tree| tree.plan_turn(&turn, self.next_seq))
            .transpose()?;
        let mut record = json!({ "kind": "turn", "turn": &turn });
        if let Some(entry) = &entry {
            record["tree_entry"] = serde_json::to_value(entry)?;
        }
        self.append_json(&record)?;
        self.turns.push(turn);
        if let Some(entry) = entry {
            self.tree
                .as_mut()
                .expect("tree was prepared")
                .commit_turn(entry);
        }
        Ok(())
    }

    /// Read a bounded entry graph without writing migration or selection events.
    pub fn tree_snapshot(
        &self,
        cancelled: &dyn Fn() -> bool,
    ) -> Result<crate::session_tree::SessionTree, SessionError> {
        if cancelled() {
            return Err(SessionError::InvalidRecord(
                "tree operation cancelled".into(),
            ));
        }
        match &self.tree {
            Some(tree) => Ok(tree.clone()),
            None => crate::session_tree::SessionTree::recover(
                self.session_id(),
                &self.records,
                Default::default(),
                cancelled,
            ),
        }
    }

    pub fn active_tree_leaf(&self) -> Option<&str> {
        self.tree.as_ref().and_then(|tree| tree.active_leaf())
    }

    pub fn tree_enabled(&self) -> bool {
        self.tree.is_some()
    }

    fn ensure_tree_writer_current(&self) -> Result<(), SessionError> {
        let metadata = session_path_metadata(&self.path)?
            .ok_or_else(|| SessionError::InvalidRecord("tree journal disappeared".into()))?;
        if metadata.len() != self.observed_bytes {
            return Err(SessionError::InvalidRecord(
                "session tree writer is stale; reopen the journal".into(),
            ));
        }
        Ok(())
    }

    /// Enable entry links by appending one source-bound migration marker. Old
    /// records stay byte-identical; their deterministic IDs form one chain.
    pub fn enable_tree(
        &mut self,
        limits: crate::session_tree::TreeLimits,
        cancelled: &dyn Fn() -> bool,
    ) -> Result<bool, SessionError> {
        if cancelled() {
            return Err(SessionError::InvalidRecord(
                "tree migration cancelled".into(),
            ));
        }
        self.ensure_tree_writer_current()?;
        if let Some(tree) = &self.tree {
            if tree.limits() != limits {
                return Err(SessionError::InvalidRecord(
                    "tree limits are already fixed for this session".into(),
                ));
            }
            return Ok(false);
        }
        let mut tree = crate::session_tree::SessionTree::recover(
            self.session_id(),
            &self.records,
            limits,
            cancelled,
        )?;
        let event = tree.migration(&self.records)?;
        if cancelled() {
            return Err(SessionError::InvalidRecord(
                "tree migration cancelled".into(),
            ));
        }
        self.append_owned_event(serde_json::to_value(&event)?)?;
        tree.commit_event(event);
        self.tree = Some(tree);
        Ok(true)
    }

    pub fn select_tree_leaf(
        &mut self,
        leaf: Option<&str>,
        cancelled: &dyn Fn() -> bool,
    ) -> Result<bool, SessionError> {
        if cancelled() {
            return Err(SessionError::InvalidRecord(
                "tree selection cancelled".into(),
            ));
        }
        self.ensure_tree_writer_current()?;
        let tree = self.tree.as_ref().ok_or_else(|| {
            SessionError::InvalidRecord("enable the session tree before navigation".into())
        })?;
        let event = tree.selection(leaf.map(str::to_owned))?;
        if tree.active_leaf() == leaf {
            return Ok(false);
        }
        if cancelled() {
            return Err(SessionError::InvalidRecord(
                "tree selection cancelled".into(),
            ));
        }
        self.append_owned_event(serde_json::to_value(&event)?)?;
        self.tree
            .as_mut()
            .expect("validated tree selection")
            .commit_event(event);
        Ok(true)
    }

    pub fn annotate_tree_entry(
        &mut self,
        entry_id: &str,
        annotation: crate::session_tree::TreeAnnotation,
        cancelled: &dyn Fn() -> bool,
    ) -> Result<bool, SessionError> {
        if cancelled() {
            return Err(SessionError::InvalidRecord(
                "tree annotation cancelled".into(),
            ));
        }
        self.ensure_tree_writer_current()?;
        let tree = self.tree.as_ref().ok_or_else(|| {
            SessionError::InvalidRecord("enable the session tree before annotation".into())
        })?;
        let event = tree.annotation_event(entry_id.into(), annotation.clone())?;
        if tree.annotation(entry_id) == annotation {
            return Ok(false);
        }
        if cancelled() {
            return Err(SessionError::InvalidRecord(
                "tree annotation cancelled".into(),
            ));
        }
        self.append_owned_event(serde_json::to_value(&event)?)?;
        self.tree
            .as_mut()
            .expect("validated tree annotation")
            .commit_event(event);
        Ok(true)
    }

    /// Only the selected path is projected. This never replays tool execution,
    /// transport ACKs or queued-input ownership from historical events.
    pub fn tree_ancestry_turns(
        &self,
        leaf: Option<&str>,
        cancelled: &dyn Fn() -> bool,
    ) -> Result<Vec<Turn>, SessionError> {
        let tree = self.tree_snapshot(cancelled)?;
        let path = tree.ancestry(leaf, cancelled)?;
        let turns: BTreeMap<_, _> = self
            .turns
            .iter()
            .map(|turn| (turn.id.as_str(), turn))
            .collect();
        path.iter()
            .map(|entry| {
                if cancelled() {
                    return Err(SessionError::InvalidRecord(
                        "tree projection cancelled".into(),
                    ));
                }
                turns
                    .get(entry.turn_id.as_str())
                    .map(|turn| (*turn).clone())
                    .ok_or_else(|| {
                        SessionError::InvalidRecord("tree entry lost its durable turn".into())
                    })
            })
            .collect()
    }

    /// Publish a fresh owner containing only the selected completed ancestry.
    /// The destination appears atomically and existing files are never replaced.
    pub fn fork_at_tree_leaf(
        &self,
        leaf: Option<&str>,
        destination: impl AsRef<Path>,
        cancelled: &dyn Fn() -> bool,
    ) -> Result<Self, SessionError> {
        require_clean_session(self)?;
        let tree = self.tree_snapshot(cancelled)?;
        let ancestry = tree.ancestry(leaf, cancelled)?;
        let turns = self.tree_ancestry_turns(leaf, cancelled)?;
        crate::session_tree::validate_fork_turns(&turns)?;
        let destination = destination.as_ref();
        reject_session_symlink(destination)?;
        if destination.exists() {
            return Err(SessionError::InvalidRecord(
                "fork destination already exists".into(),
            ));
        }
        let parent = destination
            .parent()
            .filter(|path| !path.as_os_str().is_empty())
            .unwrap_or_else(|| Path::new("."));
        if cancelled() {
            return Err(SessionError::InvalidRecord("tree fork cancelled".into()));
        }
        fs::create_dir_all(parent)?;
        let staging = parent.join(format!(".{}.jsonl", generate_id("tree-fork")));
        let mut options = OpenOptions::new();
        options.write(true).create_new(true);
        #[cfg(unix)]
        options.mode(0o600).custom_flags(libc::O_NOFOLLOW);
        options.open(&staging)?;
        let result = (|| {
            let mut fork =
                Self::open_with_options(&staging, true, Some(Path::new(&self.header.cwd)))?;
            fork.enable_tree(tree.limits(), cancelled)?;
            let mut replacements = BTreeMap::new();
            for (entry, turn) in ancestry.iter().zip(turns) {
                if cancelled() {
                    return Err(SessionError::InvalidRecord("tree fork cancelled".into()));
                }
                fork.append_turn(turn)?;
                replacements.insert(
                    entry.id.clone(),
                    fork.tree
                        .as_ref()
                        .and_then(|tree| tree.active_leaf())
                        .expect("fork appended an entry")
                        .to_owned(),
                );
            }
            for entry in &ancestry {
                let annotation = tree.annotation(&entry.id);
                if annotation != Default::default() {
                    fork.annotate_tree_entry(&replacements[&entry.id], annotation, cancelled)?;
                }
            }
            fork.append_event(json!({"type":"tree_fork_source", "source_session_id":self.session_id(), "source_leaf":leaf,
                "source_branch":leaf.and_then(|id| tree.entry(id)).map(|entry| &entry.branch_id),
                "source_turns":ancestry.len(), "source_record_sha256":crate::session_tree::records_digest(&self.records)?}))?;
            if cancelled() {
                return Err(SessionError::InvalidRecord("tree fork cancelled".into()));
            }
            // Same-directory hard_link is an atomic create-if-absent publication.
            // It cannot overwrite a destination that appeared after preflight.
            fs::hard_link(&staging, destination)?;
            fork.path = destination.to_path_buf();
            Ok(fork)
        })();
        let _ = fs::remove_file(&staging);
        result
    }

    pub fn append_handoff(&mut self, handoff: Handoff) -> Result<(), SessionError> {
        handoff
            .validate()
            .map_err(|error| SessionError::InvalidRecord(error.to_string()))?;
        self.append_json(&json!({ "kind": "handoff", "handoff": &handoff }))?;
        self.handoffs.push(handoff);
        Ok(())
    }

    /// Persist a signed b3 handoff record without converting it to the legacy
    /// session shape. Validation happens before any file write.
    pub fn append_handoff_record(&mut self, handoff: HandoffRecord) -> Result<(), SessionError> {
        handoff
            .validate()
            .map_err(|error| SessionError::InvalidRecord(error.to_string()))?;
        if handoff.session_id != self.session_id() {
            return Err(SessionError::InvalidRecord(
                "handoff session does not match journal".into(),
            ));
        }
        self.append_json(&json!({ "kind": "handoff_record", "handoff": &handoff }))?;
        self.handoff_records.push(handoff);
        Ok(())
    }

    pub fn handoff_records(&self) -> &[HandoffRecord] {
        &self.handoff_records
    }

    /// Return inert requests waiting for an external b3ehive runtime owner.
    pub fn runtime_intents(&self) -> &[RuntimeIntent] {
        &self.runtime_intents
    }

    /// Validate and durably append one external-runtime request. No scheduler,
    /// worker, process, or network call is started by this operation.
    pub fn append_runtime_intent(&mut self, intent: RuntimeIntent) -> Result<(), SessionError> {
        intent
            .validate()
            .map_err(|error| SessionError::InvalidRecord(error.to_string()))?;
        if intent.session_id != self.header.session_id {
            return Err(SessionError::InvalidRecord(
                "runtime intent session does not match journal".into(),
            ));
        }
        if let Some(source_request_id) = intent.source_request_id.as_deref()
            && let Some(existing) = self
                .runtime_intents
                .iter()
                .find(|existing| existing.source_request_id.as_deref() == Some(source_request_id))
        {
            if existing.request_fingerprint == intent.request_fingerprint {
                return Ok(());
            }
            return Err(SessionError::InvalidRecord(format!(
                "runtime request ID `{source_request_id}` conflicts with an existing intent"
            )));
        }
        self.append_json(&json!({ "kind": "runtime_intent", "intent": &intent }))?;
        self.runtime_intents.push(intent);
        Ok(())
    }

    /// Persist a normalized event.  Events are intentionally opaque to the
    /// session layer so extensions can add fields without migrations.
    pub fn append_event(&mut self, event: Value) -> Result<(), SessionError> {
        if event["type"] == "session_tree" {
            return Err(SessionError::InvalidRecord(
                "tree events require the typed session tree owner".into(),
            ));
        }
        self.append_owned_event(event)
    }

    fn append_owned_event(&mut self, event: Value) -> Result<(), SessionError> {
        self.append_json(&json!({ "kind": "event", "event": &event }))?;
        self.event_values.push(event);
        self.events += 1;
        Ok(())
    }

    pub fn events(&self) -> &[Value] {
        &self.event_values
    }

    /// Commit a validated semantic summary through this journal's sole writer.
    /// No legacy checkpoint is rewritten. Branch-aware projection is supplied
    /// by the branch owner when it is introduced; this entry handles the current
    /// linear journal and refuses a made-up branch identity.
    pub fn append_semantic_checkpoint(
        &mut self,
        checkpoint: &crate::context::SemanticCheckpoint,
        budget: crate::context::ContextBudget,
        cancelled: &dyn Fn() -> bool,
    ) -> Result<bool, SessionError> {
        self.append_semantic_checkpoint_for_operation(checkpoint, budget, cancelled, None)
    }

    /// The checkpoint and its operation correlation share one durable event.
    /// Recovery can recognize a committed summary even if the process exited
    /// before writing the separate operation-finished projection.
    pub fn append_semantic_checkpoint_for_operation(
        &mut self,
        checkpoint: &crate::context::SemanticCheckpoint,
        budget: crate::context::ContextBudget,
        cancelled: &dyn Fn() -> bool,
        operation: Option<&str>,
    ) -> Result<bool, SessionError> {
        if let Some(id) = operation {
            let markers = operation_markers(&self.event_values);
            let marker = markers
                .get(id)
                .ok_or_else(|| SessionError::InvalidRecord("missing summary operation".into()))?;
            if marker.operation.kind != OperationKind::Compaction || marker.outcome.is_some() {
                return Err(SessionError::InvalidRecord(
                    "invalid summary operation owner".into(),
                ));
            }
        }
        if cancelled() {
            return Err(SessionError::InvalidRecord("checkpoint cancelled".into()));
        }
        let source = self.selected_tree_turns(cancelled)?;
        let branch = self.selected_tree_branch();
        if checkpoint.source.branch_id != branch || checkpoint.source.records != source.len() {
            return Err(SessionError::InvalidRecord(
                "checkpoint source changed or branch is not selected".into(),
            ));
        }
        crate::context::restore_semantic_checkpoint(
            &source,
            checkpoint,
            self.session_id(),
            &branch,
            budget,
        )
        .map_err(|e| SessionError::InvalidRecord(e.to_string()))?;
        let mut value = json!({"type":"semantic_checkpoint", "checkpoint":checkpoint});
        if let Some(operation) = operation {
            value["operation_id"] = json!(operation);
        }
        if self.event_values.iter().any(|event| event == &value) {
            return Ok(false);
        }
        if cancelled() {
            return Err(SessionError::InvalidRecord("checkpoint cancelled".into()));
        }
        self.append_event(value)?;
        Ok(true)
    }

    /// The physical journal is immutable audit data; the selected path is a
    /// separate projection and never changes mailbox/reconnect sequence cursors.
    pub fn selected_tree_turns(
        &self,
        cancelled: &dyn Fn() -> bool,
    ) -> Result<Vec<Turn>, SessionError> {
        match &self.tree {
            Some(tree) => self.tree_ancestry_turns(tree.active_leaf(), cancelled),
            None => {
                if cancelled() {
                    return Err(SessionError::InvalidRecord(
                        "tree projection cancelled".into(),
                    ));
                }
                Ok(self.turns.clone())
            }
        }
    }
    pub fn selected_tree_branch(&self) -> String {
        self.tree
            .as_ref()
            .map_or("linear", |tree| tree.branch_id())
            .into()
    }
    pub fn latest_semantic_checkpoint(
        &self,
        budget: crate::context::ContextBudget,
    ) -> Result<Option<crate::context::SemanticCheckpoint>, SessionError> {
        self.semantic_checkpoint_at_tree_leaf(
            self.tree.as_ref().and_then(|tree| tree.active_leaf()),
            budget,
        )
    }
    /// Validate each candidate against its own source tip before considering it
    /// for this ancestry. Legitimate checkpoints of sibling/descendant paths are
    /// retained but never injected into the selected model context.
    pub fn semantic_checkpoint_at_tree_leaf(
        &self,
        leaf: Option<&str>,
        budget: crate::context::ContextBudget,
    ) -> Result<Option<crate::context::SemanticCheckpoint>, SessionError> {
        let (turns, branch) = if let Some(tree) = &self.tree {
            let path = self.tree_ancestry_turns(leaf, &|| false)?;
            let branch = leaf
                .and_then(|id| tree.entry(id))
                .map_or("linear", |entry| entry.branch_id.as_str());
            (path, branch)
        } else {
            (self.turns.clone(), "linear")
        };
        for event in self.event_values.iter().rev() {
            if event["type"] != "semantic_checkpoint" {
                continue;
            }
            let checkpoint: crate::context::SemanticCheckpoint =
                serde_json::from_value(event["checkpoint"].clone())
                    .map_err(|e| SessionError::InvalidRecord(e.to_string()))?;
            if let Some(tree) = &self.tree {
                let tip = tree
                    .entry_for_turn(&checkpoint.source.tip_id)
                    .ok_or_else(|| {
                        SessionError::InvalidRecord(
                            "checkpoint source tip is not in this session tree".into(),
                        )
                    })?;
                let source = self.tree_ancestry_turns(Some(&tip.id), &|| false)?;
                if source.len() != checkpoint.source.records {
                    return Err(SessionError::InvalidRecord(
                        "checkpoint source tip depth changed".into(),
                    ));
                }
                crate::context::restore_semantic_checkpoint(
                    &source,
                    &checkpoint,
                    self.session_id(),
                    &tip.branch_id,
                    crate::context::ContextBudget {
                        max_tokens: u64::MAX,
                        reserved_output_tokens: 0,
                    },
                )
                .map_err(|e| SessionError::InvalidRecord(e.to_string()))?;
                if checkpoint.source.branch_id != branch
                    || !turns.iter().any(|turn| turn.id == checkpoint.source.tip_id)
                {
                    continue;
                }
            }
            crate::context::restore_semantic_checkpoint(
                &turns,
                &checkpoint,
                self.session_id(),
                branch,
                budget,
            )
            .map_err(|e| SessionError::InvalidRecord(e.to_string()))?;
            return Ok(Some(checkpoint));
        }
        Ok(None)
    }

    /// Return the validated append-only envelopes in durable sequence order.
    /// Callers must still apply their own response/display byte budgets before
    /// serializing the values across a transport boundary.
    pub fn records(&self) -> &[SessionRecord] {
        &self.records
    }

    /// Sequence that will be assigned to the next appended journal record.
    pub fn next_sequence(&self) -> u64 {
        self.next_seq
    }

    /// Return operations that reached durable `started` state without a
    /// matching terminal marker. No operation is retried here: callers must
    /// make an explicit policy decision, which prevents crash recovery from
    /// repeating a side effect.
    pub fn interrupted_operations(&self) -> Vec<InterruptedOperation> {
        interrupted_operations(&self.event_values)
    }

    pub fn begin_operation(
        &mut self,
        operation: &InterruptedOperation,
    ) -> Result<(), SessionError> {
        self.begin_operation_with_key(operation, &operation.operation_id)
    }

    /// Persist the key used to identify this exact logical attempt. An
    /// explicit retry must use a new operation ID, even if a remote service
    /// supports reusing its own idempotency key. This API never dispatches it.
    pub fn begin_operation_with_key(
        &mut self,
        operation: &InterruptedOperation,
        idempotency_key: &str,
    ) -> Result<(), SessionError> {
        operation_id(&operation.operation_id)?;
        operation_id(&operation.turn_id)?;
        operation_id(idempotency_key)?;
        if let Some(existing) = operation_markers(&self.event_values).get(&operation.operation_id) {
            if existing.outcome.is_none()
                && existing.operation == *operation
                && existing.idempotency_key == idempotency_key
            {
                return Ok(());
            }
            return Err(SessionError::InvalidRecord(
                "operation ID conflicts with its durable marker or idempotency key".into(),
            ));
        }
        self.append_event(json!({
            "type": "operation_started",
            "operation_id": operation.operation_id,
            "operation_kind": operation.kind,
            "turn_id": operation.turn_id,
            "retry_requires_confirmation": operation.retry_requires_confirmation,
            "idempotency_key": idempotency_key,
        }))
    }

    pub fn finish_operation(
        &mut self,
        operation_id: &str,
        outcome: OperationOutcome,
    ) -> Result<(), SessionError> {
        self::operation_id(operation_id)?;
        if let Some(existing) = self.event_values.iter().rev().find(|event| {
            event["type"] == "operation_finished" && event["operation_id"] == operation_id
        }) {
            if existing["outcome"] == json!(outcome) {
                return Ok(());
            }
            return Err(SessionError::InvalidRecord(
                "operation terminal outcome conflicts with its durable record".into(),
            ));
        }
        self.append_event(json!({
            "type": "operation_finished",
            "operation_id": operation_id,
            "outcome": outcome,
        }))
    }

    /// Convert unfinished markers from a previous process into durable
    /// interrupted terminals. The returned list remains available to the host
    /// for an explicit retry/abandon decision.
    pub fn mark_interrupted_operations(
        &mut self,
    ) -> Result<Vec<InterruptedOperation>, SessionError> {
        let interrupted = self.interrupted_operations();
        for operation in &interrupted {
            let outcome = self
                .durable_operation_outcome(&operation.operation_id)
                .unwrap_or(OperationOutcome::Interrupted);
            self.finish_operation(&operation.operation_id, outcome)?;
        }
        Ok(interrupted)
    }

    /// Read-only recovery state remains visible after startup acknowledgement.
    /// Local terminal evidence can repair an orphan marker, but an interrupted
    /// provider/tool effect remains unknown until an explicit host decision.
    pub fn operation_recovery(&self) -> Vec<OperationRecovery> {
        operation_markers(&self.event_values)
            .into_values()
            .filter(|marker| {
                !marker.decided
                    && matches!(
                        marker.outcome,
                        None | Some(
                            OperationOutcome::Interrupted | OperationOutcome::UnknownOutcome
                        )
                    )
                    && self
                        .durable_operation_outcome(&marker.operation.operation_id)
                        .is_none()
            })
            .map(|marker| OperationRecovery {
                operation_id: marker.operation.operation_id,
                kind: marker.operation.kind,
                turn_id: marker.operation.turn_id,
                retry_requires_confirmation: true,
                idempotency_key: marker.idempotency_key,
                state: if marker.operation.kind == OperationKind::Compaction {
                    OperationRecoveryState::Interrupted
                } else {
                    OperationRecoveryState::UnknownOutcome
                },
            })
            .collect()
    }

    /// A durable result precedes its terminal marker. Recognize that narrow
    /// crash window without repeating the handler or inventing a result.
    pub fn durable_operation_outcome(&self, operation_id: &str) -> Option<OperationOutcome> {
        let outcome = self.event_values.iter().rev().find_map(|event| {
            (event["operation_id"] == operation_id)
                .then(|| match event["type"].as_str() {
                    Some("tool_execution_finished" | "provider_request_finished") => {
                        known_operation_outcome(&event["outcome"])
                    }
                    Some("context_compacted" | "semantic_checkpoint") => {
                        Some(OperationOutcome::Succeeded)
                    }
                    _ => None,
                })
                .flatten()
        });
        let outcome = outcome.or_else(|| {
            self.turns.iter().rev().find_map(|turn| {
                let metadata = turn.metadata.as_ref()?;
                if metadata["operation_id"] != operation_id {
                    return None;
                }
                known_operation_outcome(&metadata["outcome"])
            })
        });
        outcome.filter(|value| {
            !matches!(
                value,
                OperationOutcome::UnknownOutcome | OperationOutcome::Interrupted
            )
        })
    }

    /// Store one explicit decision exactly once. It authorizes no immediate
    /// dispatch; the host must submit a new operation for a requested retry.
    pub fn decide_operation_recovery(
        &mut self,
        operation_id: &str,
        decision: crate::core::ToolRecoveryDecision,
    ) -> Result<(), SessionError> {
        self::operation_id(operation_id)?;
        if let Some(existing) = self.events().iter().rev().find(|event| {
            event["type"] == "operation_recovery_decided" && event["operation_id"] == operation_id
        }) {
            if existing["decision"] == json!(decision) {
                return Ok(());
            }
            return Err(SessionError::InvalidRecord(
                "recovery decision conflicts with durable decision".into(),
            ));
        }
        let pending = self
            .operation_recovery()
            .into_iter()
            .find(|pending| pending.operation_id == operation_id)
            .ok_or_else(|| {
                SessionError::InvalidRecord("operation recovery is not pending".into())
            })?;
        self.append_event(json!({
            "type": "operation_recovery_decided", "operation_id": operation_id,
            "idempotency_key": pending.idempotency_key, "decision": decision,
            "execution_started": false, "retry_requires_new_operation": true,
            "implementation_complete": false,
        }))
    }

    pub fn latest_assistant(&self) -> Option<&Turn> {
        self.turns
            .iter()
            .rev()
            .find(|turn| turn.role == crate::core::TurnRole::Assistant)
    }

    /// Copy this journal to a new destination without mutating the source.
    /// The destination is opened and recovered first, so malformed or
    /// incompatible input cannot silently become an exported session.
    pub fn export_to(&self, destination: impl AsRef<Path>) -> Result<(), SessionError> {
        let destination = destination.as_ref();
        reject_session_symlink(destination)?;
        if destination == self.path {
            return Err(SessionError::InvalidRecord(
                "cannot export a session over itself".into(),
            ));
        }
        if destination.exists() {
            return Err(SessionError::InvalidRecord(
                "export destination already exists".into(),
            ));
        }
        if reconnect_path(&self.path).try_exists()? {
            return Err(SessionError::InvalidRecord(
                "cannot export a session with an active reconnect WAL; close the owner first"
                    .into(),
            ));
        }
        if let Some(parent) = destination.parent()
            && !parent.as_os_str().is_empty()
        {
            fs::create_dir_all(parent)?;
        }
        let inspected = Self::open_existing(&self.path)?;
        require_clean_session(&inspected)?;
        let bytes = read_session_bytes(&self.path).map_err(read_error)?;
        let mut options = OpenOptions::new();
        options.create_new(true).write(true);
        #[cfg(unix)]
        options.mode(0o600).custom_flags(libc::O_NOFOLLOW);
        let mut file = options.open(destination)?;
        if let Err(error) = file.write_all(&bytes).and_then(|()| file.sync_all()) {
            let _ = fs::remove_file(destination);
            return Err(error.into());
        }
        if file_sha256(&self.path)? != file_sha256(destination)? {
            let _ = fs::remove_file(destination);
            return Err(SessionError::InvalidRecord(
                "export digest does not match source".into(),
            ));
        }
        // A session journal and its addressed mailbox form one durable
        // lifecycle unit. Preserve the sidecar on export/import rather than
        // silently turning an offline queue into an empty recipient.
        if let Err(error) = copy_mailbox_sidecar(&self.path, destination) {
            let _ = fs::remove_file(destination);
            return Err(error);
        }
        Ok(())
    }

    /// Build a new session from this journal's immutable prefix. The source
    /// remains untouched and the destination receives a fresh session header.
    pub fn fork_to(&self, destination: impl AsRef<Path>) -> Result<Self, SessionError> {
        if let Some(tree) = &self.tree {
            return self.fork_at_tree_leaf(tree.active_leaf(), destination, &|| false);
        }
        let destination = destination.as_ref();
        reject_session_symlink(destination)?;
        if destination.exists() {
            return Err(SessionError::InvalidRecord(
                "fork destination already exists".into(),
            ));
        }
        require_clean_session(self)?;
        if let Some(parent) = destination
            .parent()
            .filter(|path| !path.as_os_str().is_empty())
        {
            fs::create_dir_all(parent)?;
        }
        let mut options = OpenOptions::new();
        options.write(true).create_new(true);
        #[cfg(unix)]
        options.mode(0o600).custom_flags(libc::O_NOFOLLOW);
        options.open(destination)?;
        let result = (|| {
            let mut fork = Self::open(destination)?;
            for record in &self.records {
                match record.kind.as_str() {
                    "turn" => {
                        fork.append_turn(serde_json::from_value(record.value["turn"].clone())?)?
                    }
                    "handoff" => fork
                        .append_handoff(serde_json::from_value(record.value["handoff"].clone())?)?,
                    "handoff_record" => {
                        let mut handoff: HandoffRecord =
                            serde_json::from_value(record.value["handoff"].clone())?;
                        handoff.session_id = fork.session_id().to_owned();
                        handoff.digest = handoff
                            .compute_digest()
                            .map_err(|error| SessionError::InvalidRecord(error.to_string()))?;
                        fork.append_handoff_record(handoff)?;
                    }
                    "event" => {
                        let mut event = record.value["event"].clone();
                        let kind = event["type"].as_str().unwrap_or_default();
                        // A fork copies history, never pending work or the original
                        // session's transport/lifecycle ownership and request ledger.
                        if kind.starts_with("operation_")
                            || kind.starts_with("session_lifecycle")
                            || kind.starts_with("mailbox_")
                            || kind.starts_with("reconnect_")
                            || kind.starts_with("protocol_")
                            || kind.starts_with("request_")
                        {
                            continue;
                        }
                        remap_session_identity(&mut event, self.session_id(), fork.session_id());
                        fork.append_event(event)?;
                    }
                    _ => {}
                }
            }
            Ok(fork)
        })();
        if result.is_err() {
            let _ = fs::remove_file(destination);
        }
        result
    }

    fn append_json(&mut self, value: &Value) -> Result<(), SessionError> {
        let (record, encoded, following_sequence) = self.encode_record(value)?;
        reject_session_symlink(&self.path)?;
        let mut options = OpenOptions::new();
        options.create(true).append(true);
        #[cfg(unix)]
        {
            options.mode(0o600);
            options.custom_flags(libc::O_NOFOLLOW);
        }
        let file = options.open(&self.path)?;
        let _append_lock = AppendLock::new(&file)?;
        let _transport = guard_transport_writer(&self.path)?;
        self.append_encoded(record, encoded, following_sequence, &file)
    }

    fn append_json_to_file(&mut self, value: &Value, file: &File) -> Result<(), SessionError> {
        let (record, encoded, following_sequence) = self.encode_record(value)?;
        self.append_encoded(record, encoded, following_sequence, file)
    }

    fn encode_record(&self, value: &Value) -> Result<(Value, Vec<u8>, u64), SessionError> {
        if !value.is_object() {
            return Err(SessionError::InvalidRecord(
                "session record must be an object".into(),
            ));
        }
        let sequence = self.next_seq;
        let following_sequence = sequence.checked_add(1).ok_or_else(|| {
            SessionError::InvalidRecord("session sequence space is exhausted".into())
        })?;
        let mut record = value.clone();
        if let Value::Object(fields) = &mut record {
            let now = now_ms();
            fields.insert("schema_version".into(), json!(SESSION_VERSION));
            fields.insert("session_id".into(), json!(self.header.session_id));
            fields.insert("seq".into(), json!(sequence));
            fields.insert("timestamp_ms".into(), json!(now));
            fields.insert("timestamp".into(), json!(unix_ms_to_rfc3339(now)));
        }
        let mut encoded = serde_json::to_vec(&record)?;
        if encoded.len() + 1 > MAX_SESSION_RECORD_BYTES {
            return Err(SessionError::InvalidRecord(format!(
                "record exceeds {MAX_SESSION_RECORD_BYTES} bytes"
            )));
        }
        encoded.push(b'\n');
        Ok((record, encoded, following_sequence))
    }

    fn append_encoded(
        &mut self,
        record: Value,
        encoded: Vec<u8>,
        following_sequence: u64,
        mut file: &File,
    ) -> Result<(), SessionError> {
        let sequence = self.next_seq;
        // A second writer must reopen its projection rather than append a
        // sequence computed from stale history. The append guard explicitly
        // unlocks on return; process death also releases the OS-owned lock.
        if file.metadata()?.len() != self.observed_bytes {
            return Err(SessionError::InvalidRecord(
                "session writer is stale; reopen the journal before retrying".into(),
            ));
        }
        if self.needs_separator {
            file.write_all(b"\n")?;
            self.needs_separator = false;
        }
        file.write_all(&encoded)?;
        file.flush()?;
        file.sync_data()?;
        self.observed_bytes = file.metadata()?.len();
        self.next_seq = following_sequence;
        let kind = record
            .get("kind")
            .and_then(Value::as_str)
            .unwrap_or("unknown")
            .to_owned();
        self.records.push(SessionRecord {
            sequence,
            kind,
            value: record,
        });
        Ok(())
    }
}

/// An append lock ends with this operation even if an unrelated concurrent
/// fork briefly inherited its open file description before exec closes it.
/// Closing only the parent's descriptor can otherwise leave the lock held.
struct AppendLock<'a>(&'a File);

impl<'a> AppendLock<'a> {
    fn new(file: &'a File) -> Result<Self, SessionError> {
        lock_exclusive(file)?;
        Ok(Self(file))
    }
}

impl Drop for AppendLock<'_> {
    fn drop(&mut self) {
        #[cfg(unix)]
        {
            use std::os::fd::AsRawFd;
            // SAFETY: the borrowed descriptor is valid until after this guard
            // is dropped, and this guard acquired its exclusive flock.
            unsafe { libc::flock(self.0.as_raw_fd(), libc::LOCK_UN) };
        }
    }
}

fn lock_exclusive(file: &File) -> Result<(), SessionError> {
    #[cfg(unix)]
    {
        use std::os::fd::AsRawFd;
        if unsafe { libc::flock(file.as_raw_fd(), libc::LOCK_EX | libc::LOCK_NB) } != 0 {
            return Err(io::Error::last_os_error().into());
        }
        Ok(())
    }
    #[cfg(not(unix))]
    {
        let _ = file;
        Err(SessionError::InvalidRecord(
            "cross-process session locking is unsupported on this platform".into(),
        ))
    }
}

/// Private transport WAL, separate from transcript sequence space. Holding
/// the file owns the session's headless transport until close/process death.
/// Reservations are committed before dispatch; outcomes before stdout.
#[derive(Debug)]
pub(crate) struct ReconnectJournal {
    file: File,
    pub session_path: PathBuf,
    session_id: String,
    sequence: u64,
    bytes: u64,
}

fn local_transport_owners() -> &'static Mutex<BTreeSet<PathBuf>> {
    static OWNERS: OnceLock<Mutex<BTreeSet<PathBuf>>> = OnceLock::new();
    OWNERS.get_or_init(Mutex::default)
}

pub(crate) fn reconnect_path(session: &Path) -> PathBuf {
    let mut path = session.as_os_str().to_owned();
    path.push(".reconnect");
    PathBuf::from(path)
}

fn guard_transport_writer(path: &Path) -> Result<Option<File>, SessionError> {
    let path = fs::canonicalize(path)?;
    if local_transport_owners()
        .lock()
        .map_err(|_| io::Error::other("transport ownership lock poisoned"))?
        .contains(&path)
    {
        return Ok(None);
    }
    let mut options = OpenOptions::new();
    options.read(true).write(true);
    #[cfg(unix)]
    options.custom_flags(libc::O_NOFOLLOW);
    let file = match options.open(reconnect_path(&path)) {
        Ok(file) => file,
        Err(error) if error.kind() == io::ErrorKind::NotFound => return Ok(None),
        Err(error) => return Err(error.into()),
    };
    lock_exclusive(&file)?;
    Ok(Some(file))
}

impl Drop for ReconnectJournal {
    fn drop(&mut self) {
        if let Ok(mut owners) = local_transport_owners().lock() {
            owners.remove(&self.session_path);
        }
    }
}

impl ReconnectJournal {
    const MAX_BYTES: u64 = 128 * 1024 * 1024;

    pub fn open(session: &SessionStore) -> Result<(Self, Vec<Value>), SessionError> {
        let session_path = fs::canonicalize(session.path())?;
        // Match the session append lock order, including startup recovery.
        // A second process cannot mark a live owner's operation interrupted.
        let session_guard = File::open(&session_path)?;
        lock_exclusive(&session_guard)?;
        let path = reconnect_path(&session_path);
        reject_session_symlink(&path)?;
        let mut options = OpenOptions::new();
        options.read(true).write(true).create(true);
        #[cfg(unix)]
        options.mode(0o600).custom_flags(libc::O_NOFOLLOW);
        let mut file = options.open(path)?;
        if !file.metadata()?.is_file() {
            return Err(SessionError::InvalidRecord(
                "reconnect WAL is not a file".into(),
            ));
        }
        #[cfg(unix)]
        {
            use std::os::unix::fs::MetadataExt;
            let metadata = file.metadata()?;
            if metadata.mode() & 0o077 != 0 || metadata.uid() != unsafe { libc::geteuid() } {
                return Err(SessionError::InvalidRecord(
                    "reconnect WAL must be private and owned by the current user".into(),
                ));
            }
        }
        lock_exclusive(&file)?;
        let mut bytes = Vec::new();
        (&mut file)
            .take(Self::MAX_BYTES + 1)
            .read_to_end(&mut bytes)?;
        if bytes.len() as u64 > Self::MAX_BYTES {
            return Err(SessionError::LimitExceeded {
                max: Self::MAX_BYTES as usize,
                actual: bytes.len() as u64,
            });
        }
        let valid_len = bytes
            .iter()
            .rposition(|byte| *byte == b'\n')
            .map_or(0, |pos| pos + 1);
        let mut records = Vec::new();
        let mut sequence = 0;
        for line in bytes[..valid_len]
            .split(|byte| *byte == b'\n')
            .filter(|line| !line.is_empty())
        {
            let record: Value = serde_json::from_slice(line)?;
            if record["schema_version"] != 1
                || record["session_id"] != session.session_id()
                || record["sequence"] != sequence
                || !record["event"].is_object()
            {
                return Err(SessionError::InvalidRecord(
                    "invalid reconnect WAL identity or sequence".into(),
                ));
            }
            let payload = serde_json::to_vec(&record["event"])?;
            if record["sha256"] != reconnect_digest(&payload) {
                return Err(SessionError::InvalidRecord(
                    "reconnect WAL checksum mismatch".into(),
                ));
            }
            records.push(record["event"].clone());
            sequence += 1;
        }
        // Only a torn final append is recoverable. A missing terminal after
        // a durable reservation remains unknown, never an implicit retry.
        if valid_len < bytes.len() {
            file.set_len(valid_len as u64)?;
            file.sync_data()?;
        }
        file.seek(SeekFrom::End(0))?;
        local_transport_owners()
            .lock()
            .map_err(|_| io::Error::other("transport ownership lock poisoned"))?
            .insert(session_path.clone());
        Ok((
            Self {
                file,
                session_path,
                session_id: session.session_id().into(),
                sequence,
                bytes: valid_len as u64,
            },
            records,
        ))
    }

    pub fn append(&mut self, event: Value) -> Result<(), SessionError> {
        let digest = reconnect_digest(&serde_json::to_vec(&event)?);
        let mut bytes = serde_json::to_vec(&json!({
            "schema_version": 1, "session_id": self.session_id,
            "sequence": self.sequence, "event": event, "sha256": digest,
        }))?;
        bytes.push(b'\n');
        if bytes.len() > MAX_SESSION_RECORD_BYTES
            || self.bytes + bytes.len() as u64 > Self::MAX_BYTES
        {
            return Err(SessionError::InvalidRecord(
                "reconnect WAL capacity exhausted; refusing untracked execution".into(),
            ));
        }
        self.file.write_all(&bytes)?;
        self.file.sync_data()?;
        self.bytes += bytes.len() as u64;
        self.sequence += 1;
        Ok(())
    }
}

fn reconnect_digest(bytes: &[u8]) -> String {
    use sha2::{Digest, Sha256};
    format!("{:x}", Sha256::digest(bytes))
}

fn interrupted_operations(events: &[Value]) -> Vec<InterruptedOperation> {
    let mut active = BTreeMap::<String, InterruptedOperation>::new();
    for event in events {
        match event.get("type").and_then(Value::as_str) {
            Some("operation_started") => {
                let Some(operation_id) = event.get("operation_id").and_then(Value::as_str) else {
                    continue;
                };
                let Some(turn_id) = event.get("turn_id").and_then(Value::as_str) else {
                    continue;
                };
                let Some(kind) = event
                    .get("operation_kind")
                    .cloned()
                    .and_then(|value| serde_json::from_value(value).ok())
                else {
                    continue;
                };
                active.insert(
                    operation_id.to_owned(),
                    InterruptedOperation {
                        operation_id: operation_id.to_owned(),
                        kind,
                        turn_id: turn_id.to_owned(),
                        retry_requires_confirmation: event
                            .get("retry_requires_confirmation")
                            .and_then(Value::as_bool)
                            .unwrap_or(true),
                    },
                );
            }
            Some("operation_finished") => {
                if let Some(operation_id) = event.get("operation_id").and_then(Value::as_str) {
                    active.remove(operation_id);
                }
            }
            _ => {}
        }
    }
    active.into_values().collect()
}

#[derive(Debug, Clone)]
struct OperationMarker {
    operation: InterruptedOperation,
    idempotency_key: String,
    outcome: Option<OperationOutcome>,
    decided: bool,
}

fn operation_id(value: &str) -> Result<(), SessionError> {
    if value.trim().is_empty() || value.len() > 256 || value.chars().any(char::is_control) {
        return Err(SessionError::InvalidRecord(
            "operation ID or idempotency key is empty, too large, or contains control characters"
                .into(),
        ));
    }
    Ok(())
}

fn known_operation_outcome(value: &Value) -> Option<OperationOutcome> {
    match value.as_str()? {
        "succeeded" => Some(OperationOutcome::Succeeded),
        "failed" => Some(OperationOutcome::Failed),
        "cancelled" => Some(OperationOutcome::Cancelled),
        "interrupted" => Some(OperationOutcome::Interrupted),
        "unknown_outcome" => Some(OperationOutcome::UnknownOutcome),
        _ => None,
    }
}

fn operation_markers(events: &[Value]) -> BTreeMap<String, OperationMarker> {
    let mut markers = BTreeMap::new();
    for event in events {
        match event.get("type").and_then(Value::as_str) {
            Some("operation_started") => {
                let (Some(operation_id), Some(turn_id), Some(kind)) = (
                    event.get("operation_id").and_then(Value::as_str),
                    event.get("turn_id").and_then(Value::as_str),
                    event
                        .get("operation_kind")
                        .cloned()
                        .and_then(|v| serde_json::from_value(v).ok()),
                ) else {
                    continue;
                };
                let operation = InterruptedOperation {
                    operation_id: operation_id.to_owned(),
                    kind,
                    turn_id: turn_id.to_owned(),
                    retry_requires_confirmation: event
                        .get("retry_requires_confirmation")
                        .and_then(Value::as_bool)
                        .unwrap_or(true),
                };
                let idempotency_key = event
                    .get("idempotency_key")
                    .and_then(Value::as_str)
                    .unwrap_or(operation_id)
                    .to_owned();
                markers
                    .entry(operation_id.to_owned())
                    .or_insert(OperationMarker {
                        operation,
                        idempotency_key,
                        outcome: None,
                        decided: false,
                    });
            }
            Some(
                "operation_finished" | "tool_execution_finished" | "provider_request_finished",
            ) => {
                if let Some(operation_id) = event.get("operation_id").and_then(Value::as_str)
                    && let Some(marker) = markers.get_mut(operation_id)
                {
                    marker.outcome = known_operation_outcome(&event["outcome"]);
                }
            }
            Some("operation_recovery_decided" | "tool_recovery_decided") => {
                if let Some(operation_id) = event.get("operation_id").and_then(Value::as_str)
                    && let Some(marker) = markers.get_mut(operation_id)
                {
                    marker.decided = true;
                }
            }
            _ => {}
        }
    }
    markers
}

#[cfg(unix)]
fn restrict_session_permissions(path: &Path) -> io::Result<()> {
    crate::security::restrict_private_file(path)
}

#[cfg(not(unix))]
fn restrict_session_permissions(_path: &Path) -> io::Result<()> {
    Ok(())
}

/// Inspect the final session path without following a symbolic link. A
/// missing path is represented by `None` so callers can create a new journal;
/// an existing link is always rejected before any read, chmod, or append.
fn session_path_metadata(path: &Path) -> Result<Option<fs::Metadata>, SessionError> {
    match fs::symlink_metadata(path) {
        Ok(metadata) if metadata.file_type().is_symlink() => {
            Err(SessionError::Symlink(path.to_owned()))
        }
        Ok(metadata) => Ok(Some(metadata)),
        Err(error) if error.kind() == io::ErrorKind::NotFound => Ok(None),
        Err(error) => Err(error.into()),
    }
}

fn reject_session_symlink(path: &Path) -> Result<(), SessionError> {
    match fs::symlink_metadata(path) {
        Ok(metadata) if metadata.file_type().is_symlink() => {
            Err(SessionError::Symlink(path.to_owned()))
        }
        Ok(_) => Ok(()),
        Err(error) if error.kind() == io::ErrorKind::NotFound => Ok(()),
        Err(error) => Err(error.into()),
    }
}

enum ReadSessionError {
    Io(io::Error),
    LimitExceeded { actual: u64 },
}

fn read_session_bytes(path: &Path) -> Result<Vec<u8>, ReadSessionError> {
    let mut options = OpenOptions::new();
    options.read(true);
    #[cfg(unix)]
    options.custom_flags(libc::O_NOFOLLOW);
    let file = options.open(path).map_err(ReadSessionError::Io)?;
    let metadata = file.metadata().map_err(ReadSessionError::Io)?;
    if metadata.len() > MAX_SESSION_BYTES as u64 {
        return Err(ReadSessionError::LimitExceeded {
            actual: metadata.len(),
        });
    }
    // Do not reserve the entire journal size up front. Near the 256 MiB
    // admission cap this otherwise creates a large instantaneous allocation
    // before the bounded reader has established that the input is usable.
    let initial_capacity = metadata.len().min(8 * 1024 * 1024) as usize;
    let mut bytes = Vec::with_capacity(initial_capacity);
    file.take((MAX_SESSION_BYTES as u64).saturating_add(1))
        .read_to_end(&mut bytes)
        .map_err(ReadSessionError::Io)?;
    if bytes.len() > MAX_SESSION_BYTES {
        return Err(ReadSessionError::LimitExceeded {
            actual: bytes.len() as u64,
        });
    }
    Ok(bytes)
}

fn now_ms() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_millis()
        .min(u128::from(u64::MAX)) as u64
}

fn generate_id(prefix: &str) -> String {
    static SEQUENCE: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
    format!(
        "{prefix}-{}-{}-{}",
        now_ms(),
        std::process::id(),
        SEQUENCE.fetch_add(1, std::sync::atomic::Ordering::Relaxed)
    )
}

/// Exposed for callers that need a clock-compatible session timestamp.
pub fn unix_time_ms() -> u64 {
    now_ms()
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct GarbageCollectionPolicy {
    pub retain_newest: usize,
    pub older_than_ms: u64,
}

/// Upper bound for one GC directory scan. Refusing a larger directory is
/// safer than retaining an unbounded candidate list or partially deleting it.
pub const MAX_GC_CANDIDATES: usize = 4_096;
/// Keep owner receipts small enough for both the TUI transcript and JSONL
/// replay cache. The collector refuses to delete more than this many files in
/// one invocation so every deletion can be reported exactly.
pub const MAX_GC_REMOVALS: usize = 128;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct GarbageCollectionReport {
    pub removed: Vec<PathBuf>,
    pub inspected: usize,
    pub skipped_unowned: usize,
}

pub fn list_sessions(directory: impl AsRef<Path>) -> Result<Vec<SessionSummary>, SessionError> {
    let directory = directory.as_ref();
    let metadata = match fs::symlink_metadata(directory) {
        Ok(metadata) if metadata.file_type().is_symlink() => {
            return Err(SessionError::Symlink(directory.to_owned()));
        }
        Ok(metadata) => metadata,
        Err(error) if error.kind() == io::ErrorKind::NotFound => return Ok(Vec::new()),
        Err(error) => return Err(error.into()),
    };
    if !metadata.is_dir() {
        return Err(SessionError::Directory(directory.to_owned()));
    }
    let mut paths = Vec::new();
    for (index, entry) in fs::read_dir(directory)?.enumerate() {
        if index >= MAX_GC_CANDIDATES {
            return Err(SessionError::InvalidRecord(
                "session directory entry limit exceeded".into(),
            ));
        }
        let path = entry?.path();
        // A workspace-local domain store may live beside its session journal.
        // It is JSONL too, but it is not a session and opening it through
        // `SessionStore` would append a session header and corrupt the store.
        if path.file_name().and_then(|name| name.to_str())
            != Some(crate::domain_store::DOMAIN_STORE_FILE_NAME)
            && path.extension().and_then(|value| value.to_str()) == Some("jsonl")
        {
            paths.push(path);
        }
    }
    paths.sort();
    paths
        .into_iter()
        .map(|path| inspect_session(path).map(|inspection| inspection.summary))
        .collect()
}

/// Search bounded user/assistant turn text without exposing arbitrary event
/// payloads. Results are projections only and never mutate session journals.
pub fn search_sessions(
    directory: impl AsRef<Path>,
    query: &str,
    limit: usize,
) -> Result<Vec<SessionSearchHit>, SessionError> {
    if query.trim().is_empty() || query.len() > 256 || limit == 0 || limit > 128 {
        return Err(SessionError::InvalidRecord(
            "session search query or limit is invalid".into(),
        ));
    }
    let needle = query.to_lowercase();
    let mut hits = Vec::new();
    for summary in list_sessions(directory)? {
        let store = SessionStore::open_existing(&summary.path)?;
        let mut matches = 0;
        let mut snippets = Vec::new();
        for turn in store.turns() {
            if turn.content.to_lowercase().contains(&needle) {
                matches += 1;
                if snippets.len() < 4 {
                    let text: String = turn.content.chars().take(240).collect();
                    let text = crate::security::redact_text(&text, &[]);
                    snippets.push(text);
                }
            }
        }
        if matches > 0 {
            hits.push(SessionSearchHit {
                summary,
                matches,
                snippets,
            });
            if hits.len() >= limit {
                break;
            }
        }
    }
    Ok(hits)
}

/// List sessions in a configured directory and include an optional legacy
/// default journal. Older zenpi releases wrote `~/.zenpi/session.jsonl` while
/// the session browser scans `~/.zenpi/sessions/`; keeping the fallback here
/// makes both layouts discoverable without moving or rewriting either file.
pub fn list_sessions_with_fallback(
    directory: impl AsRef<Path>,
    fallback: impl AsRef<Path>,
) -> Result<Vec<SessionSummary>, SessionError> {
    let fallback = fallback.as_ref();
    let mut sessions = list_sessions(directory)?;
    match fs::symlink_metadata(fallback) {
        Ok(metadata) if metadata.file_type().is_symlink() => {
            return Err(SessionError::Symlink(fallback.to_owned()));
        }
        Ok(metadata) if metadata.is_file() => {
            let summary = inspect_session(fallback)?.summary;
            let duplicate = sessions.iter().any(|item| {
                Path::new(&item.path)
                    .canonicalize()
                    .ok()
                    .zip(fallback.canonicalize().ok())
                    .is_some_and(|(left, right)| left == right)
            });
            if !duplicate {
                sessions.push(summary);
            }
        }
        Ok(_) => {
            return Err(SessionError::InvalidRecord(
                "session fallback is not a regular file".into(),
            ));
        }
        Err(error) if error.kind() == io::ErrorKind::NotFound => {}
        Err(error) => return Err(error.into()),
    }
    sessions.sort_by(|left, right| left.path.cmp(&right.path));
    Ok(sessions)
}

/// Open an existing journal for inspection. Unlike `SessionStore::open`, this
/// rejects a missing source, preventing a typo in a read-only CLI command from
/// creating an empty session.
pub fn inspect_session(path: impl AsRef<Path>) -> Result<SessionInspection, SessionError> {
    let path = path.as_ref();
    let metadata = session_path_metadata(path)?;
    if !metadata.is_some_and(|metadata| metadata.is_file()) {
        return Err(SessionError::InvalidRecord(
            "inspection source is not an existing session file".into(),
        ));
    }
    let store = SessionStore::open_existing(path)?;
    Ok(SessionInspection {
        summary: store.summary(),
        turns: store.turns,
        events: store.event_values,
        recovery_warnings: store.warnings,
    })
}

pub fn import_session(
    source: impl AsRef<Path>,
    destination: impl AsRef<Path>,
) -> Result<SessionStore, SessionError> {
    if !source.as_ref().is_file() {
        return Err(SessionError::InvalidRecord(
            "import source is not an existing session file".into(),
        ));
    }
    let source = SessionStore::open_existing(source)?;
    source.export_to(&destination)?;
    let imported = match SessionStore::open(destination.as_ref()) {
        Ok(imported) => imported,
        Err(error) => {
            let _ = fs::remove_file(destination.as_ref());
            return Err(error);
        }
    };
    if imported.session_id() != source.session_id()
        || imported.summary().next_seq != source.summary().next_seq
    {
        let _ = fs::remove_file(destination.as_ref());
        return Err(SessionError::InvalidRecord(
            "imported journal identity or sequence differs from source".into(),
        ));
    }
    Ok(imported)
}

fn file_sha256(path: &Path) -> Result<String, SessionError> {
    use sha2::{Digest, Sha256};

    let bytes = fs::read(path)?;
    Ok(format!("{:x}", Sha256::digest(bytes)))
}

pub fn garbage_collect_sessions(
    directory: impl AsRef<Path>,
    policy: GarbageCollectionPolicy,
    now_ms: u64,
) -> Result<Vec<PathBuf>, SessionError> {
    let active = SessionStore::default_path();
    garbage_collect_sessions_with_active(directory, policy, Some(&active), now_ms)
        .map(|report| report.removed)
}

/// Garbage collect only clean, zenpi-owned session journals.
///
/// `active_session` is checked by path and (where available) file identity;
/// an active journal is never removed. The scan is fail-closed for symlinks,
/// unexpected file types, candidate-count overflow, and a removal set larger
/// than the bounded receipt can describe. Domain snapshots are skipped rather
/// than treated as sessions. No source is opened writable and no parent path
/// is followed through a final symlink.
pub fn garbage_collect_sessions_with_active(
    directory: impl AsRef<Path>,
    policy: GarbageCollectionPolicy,
    active_session: Option<&Path>,
    now_ms: u64,
) -> Result<GarbageCollectionReport, SessionError> {
    if policy.retain_newest == 0 && policy.older_than_ms == 0 {
        return Err(SessionError::InvalidRecord(
            "garbage collection requires an explicit retention policy".into(),
        ));
    }
    let directory = directory.as_ref();
    let directory_metadata = match fs::symlink_metadata(directory) {
        Ok(metadata) => metadata,
        Err(error) if error.kind() == io::ErrorKind::NotFound => {
            return Ok(GarbageCollectionReport {
                removed: Vec::new(),
                inspected: 0,
                skipped_unowned: 0,
            });
        }
        Err(error) => return Err(error.into()),
    };
    if directory_metadata.file_type().is_symlink() {
        return Err(SessionError::Symlink(directory.to_owned()));
    }
    if !directory_metadata.is_dir() {
        return Err(SessionError::Directory(directory.to_owned()));
    }
    let mut candidates = Vec::new();
    let mut skipped_unowned = 0_usize;
    for entry in fs::read_dir(directory)? {
        let path = entry?.path();
        // Inspect every directory entry before filtering by suffix. A
        // symlink with a non-JSONL name is still an alias in the managed
        // directory and must fail closed rather than being silently ignored.
        let metadata = fs::symlink_metadata(&path)?;
        if metadata.file_type().is_symlink() {
            return Err(SessionError::Symlink(path));
        }
        // Domain snapshots use JSONL too, but are not sessions. Never let a
        // retention command remove the store that owns Blueprint/Goal/Learn
        // records.
        if path.file_name().and_then(|name| name.to_str())
            == Some(crate::domain_store::DOMAIN_STORE_FILE_NAME)
            || path.extension().and_then(|value| value.to_str()) != Some("jsonl")
        {
            continue;
        }
        // Fail closed for aliases and unexpected node types. In particular,
        // do not follow a symlink while selecting an item for deletion.
        if !metadata.is_file() {
            return Err(SessionError::InvalidRecord(
                "garbage collection candidate is not a regular file".into(),
            ));
        }
        // A `.jsonl` suffix is not ownership proof. Only a clean journal with
        // a valid session header may be selected; malformed or unrelated
        // files remain untouched and are counted in the bounded receipt.
        let owned = clean_owned_session(&path)?;
        if !owned {
            skipped_unowned = skipped_unowned.saturating_add(1);
            continue;
        }
        if active_session.is_some_and(|active| same_file_or_path(&path, active)) {
            return Err(SessionError::InvalidRecord(
                "garbage collection cannot remove the active session".into(),
            ));
        }
        let modified = metadata
            .modified()?
            .duration_since(UNIX_EPOCH)
            .map_err(|_| {
                SessionError::InvalidRecord(
                    "garbage collection candidate has an invalid mtime".into(),
                )
            })?;
        candidates.push((path, modified.as_millis().min(u128::from(u64::MAX)) as u64));
        if candidates.len() > MAX_GC_CANDIDATES {
            return Err(SessionError::InvalidRecord(format!(
                "garbage collection candidate limit exceeded ({MAX_GC_CANDIDATES})"
            )));
        }
    }
    candidates.sort_by(|left, right| right.1.cmp(&left.1).then_with(|| left.0.cmp(&right.0)));
    let mut selected = Vec::new();
    for (index, (path, modified)) in candidates.iter().enumerate() {
        if index < policy.retain_newest || now_ms.saturating_sub(*modified) < policy.older_than_ms {
            continue;
        }
        selected.push(path.clone());
    }
    if selected.len() > MAX_GC_REMOVALS {
        return Err(SessionError::InvalidRecord(format!(
            "garbage collection removal limit exceeded ({MAX_GC_REMOVALS})"
        )));
    }
    // Recheck every selected path immediately before mutation. This closes
    // the common replacement race where a valid journal is swapped for a
    // symlink or unrelated JSONL file after the initial directory scan.
    for path in &selected {
        let metadata = fs::symlink_metadata(path)?;
        if metadata.file_type().is_symlink() {
            return Err(SessionError::Symlink(path.clone()));
        }
        if !metadata.is_file() || !clean_owned_session(path)? {
            return Err(SessionError::InvalidRecord(
                "garbage collection candidate changed before removal".into(),
            ));
        }
        if active_session.is_some_and(|active| same_file_or_path(path, active)) {
            return Err(SessionError::InvalidRecord(
                "garbage collection cannot remove the active session".into(),
            ));
        }
        if mailbox_path(path)?.try_exists()? {
            return Err(SessionError::InvalidRecord(
                "garbage collection cannot orphan a durable session mailbox".into(),
            ));
        }
        // Match explicit delete/export: the WAL is durable reconnect state,
        // even when its owner is closed or its contents need recovery. Refuse
        // the entire selection before any unlink instead of orphaning it.
        if reconnect_path(path).try_exists()? {
            return Err(SessionError::InvalidRecord(
                "garbage collection cannot remove a session with a reconnect WAL".into(),
            ));
        }
    }
    for path in selected.iter() {
        fs::remove_file(path)?;
    }
    Ok(GarbageCollectionReport {
        removed: selected,
        inspected: candidates.len(),
        skipped_unowned,
    })
}

fn same_file_or_path(left: &Path, right: &Path) -> bool {
    if left == right {
        return true;
    }
    #[cfg(unix)]
    {
        use std::os::unix::fs::MetadataExt;
        if let (Ok(left), Ok(right)) = (fs::metadata(left), fs::metadata(right))
            && left.dev() == right.dev()
            && left.ino() == right.ino()
        {
            return true;
        }
    }
    left.canonicalize().ok() == right.canonicalize().ok()
}

fn clean_owned_session(path: &Path) -> Result<bool, SessionError> {
    match SessionStore::open_existing(path) {
        Ok(store) => Ok(store.records().first().is_some_and(|record| {
            record.kind == "session" && record.sequence == 0 && store.recovery_warnings().is_empty()
        })),
        Err(SessionError::Symlink(path)) => Err(SessionError::Symlink(path)),
        Err(_) => Ok(false),
    }
}

fn require_clean_session(store: &SessionStore) -> Result<(), SessionError> {
    if store
        .records
        .first()
        .is_none_or(|record| record.kind != "session" || record.sequence != 0)
        || !store.warnings.is_empty()
    {
        return Err(SessionError::InvalidRecord(
            "operation requires a clean session journal".into(),
        ));
    }
    Ok(())
}

fn read_error(error: ReadSessionError) -> SessionError {
    match error {
        ReadSessionError::Io(error) => error.into(),
        ReadSessionError::LimitExceeded { actual } => SessionError::LimitExceeded {
            max: MAX_SESSION_BYTES,
            actual,
        },
    }
}

fn remap_session_identity(value: &mut Value, source: &str, destination: &str) {
    match value {
        Value::Object(fields) => {
            for (key, value) in fields {
                if (key == "session_id" || key.ends_with("_session_id"))
                    && value.as_str() == Some(source)
                {
                    *value = json!(destination);
                } else {
                    remap_session_identity(value, source, destination);
                }
            }
        }
        Value::Array(values) => values
            .iter_mut()
            .for_each(|value| remap_session_identity(value, source, destination)),
        _ => {}
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct SessionCatalogEntry {
    pub summary: SessionSummary,
    pub archived: bool,
    pub last_activity_ms: u64,
}

impl SessionStore {
    pub fn is_archived(&self) -> bool {
        self.events()
            .iter()
            .rev()
            .find(|event| event["type"] == "session_lifecycle")
            .is_some_and(|event| event["archived"] == true)
    }

    pub fn catalog_entry(&self) -> SessionCatalogEntry {
        SessionCatalogEntry {
            summary: self.summary(),
            archived: self.is_archived(),
            last_activity_ms: self
                .records
                .iter()
                .filter_map(|record| record.value["timestamp_ms"].as_u64())
                .max()
                .unwrap_or(self.header.created_at_ms),
        }
    }

    pub fn set_archived(&mut self, archived: bool) -> Result<(), SessionError> {
        require_clean_session(self)?;
        if self.is_archived() != archived {
            self.append_event(json!({"type": "session_lifecycle", "archived": archived}))?;
        }
        Ok(())
    }
}

/// A local catalog, not a claim that these sessions have running agents.
pub fn session_catalog(
    directory: impl AsRef<Path>,
    include_archived: bool,
) -> Result<Vec<SessionCatalogEntry>, SessionError> {
    let mut entries = Vec::new();
    for summary in list_sessions(directory)? {
        if entries.len() >= MAX_GC_CANDIDATES {
            return Err(SessionError::InvalidRecord(
                "session catalog limit exceeded".into(),
            ));
        }
        let store = SessionStore::open_existing(summary.path)?;
        require_clean_session(&store)?;
        if include_archived || !store.is_archived() {
            entries.push(store.catalog_entry());
        }
    }
    entries.sort_by(|left, right| {
        right
            .last_activity_ms
            .cmp(&left.last_activity_ms)
            .then_with(|| left.summary.path.cmp(&right.summary.path))
    });
    Ok(entries)
}

pub fn resume_last_session(directory: impl AsRef<Path>) -> Result<SessionStore, SessionError> {
    let latest = session_catalog(directory, false)?
        .into_iter()
        .next()
        .ok_or_else(|| SessionError::InvalidRecord("no unarchived session to resume".into()))?;
    SessionStore::open_existing_writable(latest.summary.path)
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(tag = "action", rename_all = "snake_case")]
pub enum SessionLifecycleRequest {
    List {
        directory: PathBuf,
        #[serde(default)]
        include_archived: bool,
    },
    Agents {
        directory: PathBuf,
    },
    Inspect {
        path: PathBuf,
    },
    ResumeLast {
        directory: PathBuf,
    },
    Fork {
        source: PathBuf,
        destination: PathBuf,
    },
    Export {
        source: PathBuf,
        destination: PathBuf,
    },
    Import {
        source: PathBuf,
        destination: PathBuf,
    },
    /// Migration writes a verified copy in the current schema, preserving
    /// identity and source. Removing the source is a separate confirmed delete.
    Migrate {
        source: PathBuf,
        destination: PathBuf,
    },
    Archive {
        path: PathBuf,
    },
    Unarchive {
        path: PathBuf,
    },
    Delete {
        path: PathBuf,
        #[serde(default)]
        confirmed: bool,
    },
    /// Explicitly retire a durable mailbox before deleting its session.
    /// Retention never removes a queue implicitly.
    RetireMailbox {
        path: PathBuf,
        #[serde(default)]
        confirmed: bool,
    },
    Queue {
        source: PathBuf,
        recipient: PathBuf,
        request_id: String,
        payload: Value,
        ttl_ms: u64,
    },
    Gc {
        directory: PathBuf,
        retain_newest: usize,
        older_than_ms: u64,
        #[serde(default)]
        confirmed: bool,
    },
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum SessionLifecycleReceipt {
    Catalog {
        sessions: Vec<SessionCatalogEntry>,
    },
    Inspection {
        inspection: SessionInspection,
    },
    Session {
        session: SessionCatalogEntry,
    },
    Deleted {
        path: PathBuf,
    },
    Queued {
        message: MailboxMessage,
    },
    GarbageCollected {
        removed: Vec<PathBuf>,
        inspected: usize,
        skipped_unowned: usize,
    },
}

pub fn execute_session_lifecycle(
    request: SessionLifecycleRequest,
    active_session: Option<&Path>,
    now_ms: u64,
) -> Result<SessionLifecycleReceipt, SessionError> {
    use SessionLifecycleReceipt as Receipt;
    use SessionLifecycleRequest as Request;
    let session = match request {
        Request::List {
            directory,
            include_archived,
        } => {
            return Ok(Receipt::Catalog {
                sessions: session_catalog(directory, include_archived)?,
            });
        }
        Request::Agents { directory } => {
            return Ok(Receipt::Catalog {
                sessions: session_catalog(directory, false)?,
            });
        }
        Request::Inspect { path } => {
            return Ok(Receipt::Inspection {
                inspection: inspect_session(path)?,
            });
        }
        Request::ResumeLast { directory } => resume_last_session(directory)?,
        Request::Fork {
            source,
            destination,
        } => SessionStore::open_existing(source)?.fork_to(destination)?,
        Request::Export {
            source,
            destination,
        } => {
            SessionStore::open_existing(source)?.export_to(&destination)?;
            SessionStore::open_existing(destination)?
        }
        Request::Import {
            source,
            destination,
        }
        | Request::Migrate {
            source,
            destination,
        } => import_session(source, destination)?,
        Request::Archive { path } => {
            return Ok(Receipt::Session {
                session: set_session_archived(path, true, active_session)?,
            });
        }
        Request::Unarchive { path } => {
            return Ok(Receipt::Session {
                session: set_session_archived(path, false, active_session)?,
            });
        }
        Request::Delete { path, confirmed } => {
            if !confirmed {
                return Err(SessionError::InvalidRecord(
                    "delete requires explicit confirmation".into(),
                ));
            }
            reject_active_session(&path, active_session)?;
            let store = SessionStore::open_existing(&path)?;
            require_clean_session(&store)?;
            // Refuse to orphan durable communication. Archive is available
            // until a separate mailbox retention decision has been made.
            if mailbox_path(&path)?.exists() {
                return Err(SessionError::InvalidRecord(
                    "delete requires retaining or removing the session mailbox first".into(),
                ));
            }
            if reconnect_path(&path).try_exists()? {
                return Err(SessionError::InvalidRecord(
                    "delete requires closing the reconnect owner first".into(),
                ));
            }
            fs::remove_file(&path)?;
            return Ok(Receipt::Deleted { path });
        }
        Request::RetireMailbox { path, confirmed } => {
            retire_session_mailbox(&path, active_session, confirmed)?;
            // The session itself remains intact; return its catalog entry so
            // hosts can refresh their lifecycle projection after retirement.
            return Ok(Receipt::Session {
                session: SessionStore::open_existing(path)?.catalog_entry(),
            });
        }
        Request::Queue {
            source,
            recipient,
            request_id,
            payload,
            ttl_ms,
        } => {
            let sender = SessionStore::open_existing(source)?;
            let mailbox = SessionMailbox::open(recipient)?;
            return Ok(Receipt::Queued {
                message: mailbox.enqueue(&sender, &request_id, payload, ttl_ms, now_ms)?,
            });
        }
        Request::Gc {
            directory,
            retain_newest,
            older_than_ms,
            confirmed,
        } => {
            if !confirmed {
                return Err(SessionError::InvalidRecord(
                    "GC requires explicit confirmation".into(),
                ));
            }
            let report = garbage_collect_sessions_with_active(
                directory,
                GarbageCollectionPolicy {
                    retain_newest,
                    older_than_ms,
                },
                active_session,
                now_ms,
            )?;
            return Ok(Receipt::GarbageCollected {
                removed: report.removed,
                inspected: report.inspected,
                skipped_unowned: report.skipped_unowned,
            });
        }
    };
    Ok(Receipt::Session {
        session: session.catalog_entry(),
    })
}

fn reject_active_session(path: &Path, active: Option<&Path>) -> Result<(), SessionError> {
    if active.is_some_and(|active| same_file_or_path(path, active)) {
        return Err(SessionError::InvalidRecord(
            "operation cannot modify the active session lifecycle".into(),
        ));
    }
    Ok(())
}

pub fn set_session_archived(
    path: impl AsRef<Path>,
    archived: bool,
    active: Option<&Path>,
) -> Result<SessionCatalogEntry, SessionError> {
    let path = path.as_ref();
    if archived {
        reject_active_session(path, active)?;
    }
    let mut session = SessionStore::open_existing_writable(path)?;
    session.set_archived(archived)?;
    Ok(session.catalog_entry())
}

pub const MAX_MAILBOX_PAYLOAD_BYTES: usize = 64 * 1024;
pub const MAX_MAILBOX_BYTES: usize = 8 * 1024 * 1024;
pub const MAX_MAILBOX_MESSAGES: usize = 256;
pub const MAX_MAILBOX_TTL_MS: u64 = 7 * 24 * 60 * 60 * 1000;

/// Remove a recipient mailbox only as an explicit, confirmed lifecycle
/// action. The active recipient is rejected so an owner cannot race an
/// in-flight delivery by deleting its queue. Callers should archive a session
/// first when they need to retain the queue for later inspection.
pub fn retire_session_mailbox(
    session_path: impl AsRef<Path>,
    active_session: Option<&Path>,
    confirmed: bool,
) -> Result<bool, SessionError> {
    let session_path = session_path.as_ref();
    if !confirmed {
        return Err(SessionError::InvalidRecord(
            "mailbox retirement requires explicit confirmation".into(),
        ));
    }
    reject_active_session(session_path, active_session)?;
    let mut store = SessionStore::open_existing_writable(session_path)?;
    require_clean_session(&store)?;
    if let Some(active) = active_session
        && SessionStore::open_existing(active)?.session_id() == store.session_id()
    {
        return Err(SessionError::InvalidRecord(
            "mailbox retirement cannot modify an alias of the active session".into(),
        ));
    }
    let already_retired = store
        .events()
        .iter()
        .any(|event| event["type"] == "mailbox_retired");
    let sidecar = mailbox_path(session_path)?;
    match fs::symlink_metadata(&sidecar) {
        Ok(metadata) if metadata.file_type().is_symlink() => {
            return Err(SessionError::Symlink(sidecar));
        }
        Ok(metadata) if !metadata.is_file() => {
            return Err(SessionError::InvalidRecord(
                "mailbox sidecar is not a regular file".into(),
            ));
        }
        Err(error) if error.kind() == io::ErrorKind::NotFound => return Ok(false),
        Err(error) => return Err(error.into()),
        Ok(_) => {}
    }
    // Validate the complete journal while holding its inode lock. A torn or
    // malformed queue must be repaired/inspected, never discarded by a
    // retention command accidentally.
    let mailbox = SessionMailbox::open(session_path)?;
    let mut lock = mailbox.locked_inner(false, false)?;
    mailbox.recover(&mut lock.file)?;
    // Persist the retirement before unlinking. New or already-open senders
    // recheck it under the mailbox lock, so an old handle cannot recreate an
    // empty queue and repeat effects after the deduplication journal is gone.
    if !already_retired {
        store.append_event(json!({"type": "mailbox_retired"}))?;
    }
    fs::remove_file(&sidecar)?;
    Ok(true)
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum MailboxStatus {
    Queued,
    Acknowledged,
    Claimed,
    Succeeded,
    Failed,
    Expired,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct MailboxMessage {
    pub sender_session_id: String,
    pub recipient_session_id: String,
    pub request_id: String,
    pub digest: String,
    pub payload: Value,
    pub created_at_ms: u64,
    pub expires_at_ms: u64,
    /// The first delivery sequence, stable across ACK and result updates.
    pub sequence: u64,
    pub status: MailboxStatus,
    pub claim_token: Option<String>,
    pub result: Option<Value>,
}

impl MailboxMessage {
    fn digest(&self) -> Result<String, SessionError> {
        use sha2::{Digest, Sha256};
        let unsigned = json!({"sender": self.sender_session_id, "recipient": self.recipient_session_id,
            "request_id": self.request_id, "payload": self.payload, "created_at_ms": self.created_at_ms,
            "expires_at_ms": self.expires_at_ms, "sequence": self.sequence});
        Ok(format!(
            "{:x}",
            Sha256::digest(serde_json::to_vec(&unsigned)?)
        ))
    }

    fn validate(&self, recipient: &str) -> Result<(), SessionError> {
        mailbox_id(&self.sender_session_id)?;
        mailbox_id(&self.recipient_session_id)?;
        mailbox_id(&self.request_id)?;
        validate_mailbox_payload(&self.payload)?;
        if let Some(result) = &self.result {
            validate_mailbox_payload(result)?;
        }
        if let Some(token) = &self.claim_token {
            mailbox_id(token)?;
        }
        if self.recipient_session_id != recipient
            || self.sequence == 0
            || self.expires_at_ms <= self.created_at_ms
            || self.expires_at_ms - self.created_at_ms > MAX_MAILBOX_TTL_MS
            || self.digest != self.digest()?
        {
            return Err(SessionError::InvalidRecord(
                "invalid mailbox identity, TTL, sequence, or digest".into(),
            ));
        }
        let valid_state = match self.status {
            MailboxStatus::Queued | MailboxStatus::Acknowledged => {
                self.claim_token.is_none() && self.result.is_none()
            }
            MailboxStatus::Claimed => self.claim_token.is_some() && self.result.is_none(),
            MailboxStatus::Succeeded | MailboxStatus::Failed => {
                self.claim_token.is_some() && self.result.is_some()
            }
            MailboxStatus::Expired => false, // Expiration is a clock-derived view, not a new execution receipt.
        };
        if !valid_state {
            return Err(SessionError::InvalidRecord("invalid mailbox state".into()));
        }
        Ok(())
    }

    fn at_time(mut self, now: u64) -> Self {
        if now >= self.expires_at_ms
            && !matches!(
                self.status,
                MailboxStatus::Succeeded | MailboxStatus::Failed
            )
        {
            self.status = MailboxStatus::Expired;
        }
        self
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(tag = "action", rename_all = "snake_case")]
pub enum MailboxAction {
    Acknowledge,
    Claim { token: String },
    Complete { token: String, result: Value },
    Fail { token: String, error: Value },
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct MailboxPage {
    pub messages: Vec<MailboxMessage>,
    /// Pass this value as `after_sequence` to read the following page.
    pub next_sequence: Option<u64>,
}

/// Host-owned liveness registry for live session recipients. This is an
/// in-process admission boundary only: it never starts a scheduler and does
/// not infer liveness from journal filenames.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct LiveSessionOwner {
    pub session_id: String,
    pub owner_epoch: u64,
    pub workspace: String,
    pub last_seen_ms: u64,
}

#[derive(Debug, Default)]
pub struct LiveSessionRegistry {
    owners: BTreeMap<String, LiveSessionOwner>,
}

impl LiveSessionRegistry {
    pub const MAX_OWNERS: usize = 128;

    pub fn register(
        &mut self,
        session_id: impl Into<String>,
        owner_epoch: u64,
        workspace: impl Into<String>,
        now_ms: u64,
    ) -> Result<(), SessionError> {
        let session_id = session_id.into();
        let workspace = workspace.into();
        mailbox_id(&session_id)?;
        if owner_epoch == 0 || workspace.is_empty() || workspace.len() > 4096 {
            return Err(SessionError::InvalidRecord(
                "invalid live owner identity".into(),
            ));
        }
        if !self.owners.contains_key(&session_id) && self.owners.len() >= Self::MAX_OWNERS {
            return Err(SessionError::InvalidRecord(
                "live owner registry is full".into(),
            ));
        }
        self.owners.insert(
            session_id.clone(),
            LiveSessionOwner {
                session_id,
                owner_epoch,
                workspace,
                last_seen_ms: now_ms,
            },
        );
        Ok(())
    }

    pub fn heartbeat(&mut self, session_id: &str, owner_epoch: u64, now_ms: u64) -> bool {
        let Some(owner) = self.owners.get_mut(session_id) else {
            return false;
        };
        if owner.owner_epoch != owner_epoch {
            return false;
        }
        owner.last_seen_ms = now_ms;
        true
    }

    pub fn unregister(&mut self, session_id: &str, owner_epoch: u64) -> bool {
        self.owners
            .get(session_id)
            .is_some_and(|owner| owner.owner_epoch == owner_epoch)
            && self.owners.remove(session_id).is_some()
    }

    pub fn active(
        &mut self,
        session_id: &str,
        workspace: &str,
        now_ms: u64,
        ttl_ms: u64,
    ) -> Option<&LiveSessionOwner> {
        self.owners
            .retain(|_, owner| now_ms.saturating_sub(owner.last_seen_ms) <= ttl_ms);
        self.owners
            .get(session_id)
            .filter(|owner| owner.workspace == workspace)
    }

    pub fn owners(&self) -> impl Iterator<Item = &LiveSessionOwner> {
        self.owners.values()
    }

    /// Claim the oldest queued mailbox request for a live owner. Dispatch is
    /// explicit: this helper performs one claim and never starts a worker.
    pub fn claim_next(
        &mut self,
        recipient: &SessionStore,
        workspace: &str,
        now_ms: u64,
        ttl_ms: u64,
    ) -> Result<Option<MailboxMessage>, SessionError> {
        let Some(owner) = self.active(recipient.session_id(), workspace, now_ms, ttl_ms) else {
            return Ok(None);
        };
        let mailbox = SessionMailbox::open(recipient.path())?;
        let mut after_sequence = 0;
        // Pages are bounded by both count and bytes. Do not stop merely because
        // the first page contains only expired, claimed or terminal messages.
        // Retain one page at a time and never exceed the mailbox's capacity.
        for _ in 0..MAX_MAILBOX_MESSAGES {
            let page = mailbox.list(recipient, after_sequence, 64, now_ms)?;
            if let Some(message) = page.messages.into_iter().find(|message| {
                matches!(
                    message.status,
                    MailboxStatus::Queued | MailboxStatus::Acknowledged
                )
            }) {
                let token = format!("owner-{}-{}", owner.owner_epoch, &message.digest[..16]);
                return mailbox
                    .update(
                        recipient,
                        &message.sender_session_id,
                        &message.request_id,
                        MailboxAction::Claim { token },
                        now_ms,
                    )
                    .map(Some);
            }
            match page.next_sequence {
                Some(next) if next > after_sequence => after_sequence = next,
                None => return Ok(None),
                Some(_) => {
                    return Err(SessionError::InvalidRecord(
                        "mailbox pagination did not advance".into(),
                    ));
                }
            }
        }
        Err(SessionError::InvalidRecord(
            "mailbox scan exceeds message capacity".into(),
        ))
    }

    pub fn claim_message(
        &mut self,
        recipient: &SessionStore,
        workspace: &str,
        digest: &str,
        now_ms: u64,
        ttl_ms: u64,
    ) -> Result<MailboxMessage, SessionError> {
        let Some(owner_epoch) = self
            .active(recipient.session_id(), workspace, now_ms, ttl_ms)
            .map(|owner| owner.owner_epoch)
        else {
            return Err(SessionError::InvalidRecord(
                "live recipient owner is offline or expired".into(),
            ));
        };
        let mailbox = SessionMailbox::open(recipient.path())?;
        let message = mailbox.find_message(recipient, digest, now_ms)?;
        let token = format!("owner-{owner_epoch}-{}", &message.digest[..16]);
        mailbox.update(
            recipient,
            &message.sender_session_id,
            &message.request_id,
            MailboxAction::Claim { token },
            now_ms,
        )
    }

    /// Finish a request previously claimed by the current live owner. The
    /// owner epoch is bound into the claim token, so a restarted recipient
    /// cannot complete work admitted by an older process.
    #[allow(clippy::too_many_arguments)]
    pub fn finish_claim(
        &mut self,
        recipient: &SessionStore,
        workspace: &str,
        digest: &str,
        result: Value,
        succeeded: bool,
        now_ms: u64,
        ttl_ms: u64,
    ) -> Result<MailboxMessage, SessionError> {
        let Some(owner_epoch) = self
            .active(recipient.session_id(), workspace, now_ms, ttl_ms)
            .map(|owner| owner.owner_epoch)
        else {
            return Err(SessionError::InvalidRecord(
                "live recipient owner is offline or expired".into(),
            ));
        };
        let mailbox = SessionMailbox::open(recipient.path())?;
        let message = mailbox.find_message(recipient, digest, now_ms)?;
        let token = message.claim_token.clone().ok_or_else(|| {
            SessionError::InvalidRecord("mailbox request is not claimed by a live owner".into())
        })?;
        let prefix = format!("owner-{owner_epoch}-");
        if !token.starts_with(&prefix) {
            return Err(SessionError::InvalidRecord(
                "mailbox claim belongs to a different owner epoch".into(),
            ));
        }
        let action = if succeeded {
            MailboxAction::Complete { token, result }
        } else {
            MailboxAction::Fail {
                token,
                error: result,
            }
        };
        mailbox.update(
            recipient,
            &message.sender_session_id,
            &message.request_id,
            action,
            now_ms,
        )
    }

    /// Complete a live request and enqueue a correlated result in the
    /// original sender's mailbox. The two journals are independently locked;
    /// a delivery error is returned after the recipient transition so callers
    /// can surface the durable completion and retry delivery explicitly.
    #[allow(clippy::too_many_arguments)]
    pub fn finish_claim_with_reply(
        &mut self,
        recipient: &SessionStore,
        sender: &SessionStore,
        workspace: &str,
        digest: &str,
        result: Value,
        succeeded: bool,
        now_ms: u64,
        ttl_ms: u64,
    ) -> Result<(MailboxMessage, MailboxMessage), SessionError> {
        if recipient.header().cwd != sender.header().cwd {
            return Err(SessionError::InvalidRecord(
                "mailbox reply requires a shared workspace".into(),
            ));
        }
        let existing = {
            let mailbox = SessionMailbox::open(recipient.path())?;
            mailbox.find_message(recipient, digest, now_ms)?
        };
        // Bind both the caller's handle and the current reply destination to
        // the immutable original sender before completing the recipient claim.
        let reply_mailbox = SessionMailbox::open(sender.path())?;
        if existing.sender_session_id != sender.session_id()
            || reply_mailbox.recipient_session_id != existing.sender_session_id
        {
            return Err(SessionError::InvalidRecord(
                "mailbox reply must address the original sender".into(),
            ));
        }
        let completed = if matches!(
            existing.status,
            MailboxStatus::Succeeded | MailboxStatus::Failed
        ) {
            let expected_success = existing.status == MailboxStatus::Succeeded;
            if expected_success != succeeded || existing.result.as_ref() != Some(&result) {
                return Err(SessionError::InvalidRecord(
                    "completed mailbox result conflicts with retry".into(),
                ));
            }
            existing
        } else {
            self.finish_claim(
                recipient,
                workspace,
                digest,
                result.clone(),
                succeeded,
                now_ms,
                ttl_ms,
            )?
        };
        let reply_id = format!("reply-{digest}");
        let reply = reply_mailbox.enqueue(
            recipient,
            &reply_id,
            json!({
                "in_reply_to": digest,
                "succeeded": succeeded,
                "result": result,
            }),
            ttl_ms.max(1),
            now_ms,
        )?;
        Ok((completed, reply))
    }
}

#[derive(Debug, Serialize, Deserialize)]
struct MailboxRecord {
    schema_version: u32,
    sequence: u64,
    message: MailboxMessage,
}

/// Private, local, addressed communication with no provider call or daemon.
/// Every mutation takes the same inode lock, reloads the bounded journal, and
/// appends one synced transition. A claimed message is never retried implicitly.
#[derive(Debug)]
pub struct SessionMailbox {
    path: PathBuf,
    recipient_path: PathBuf,
    recipient_session_id: String,
    workspace: PathBuf,
}

impl SessionMailbox {
    pub fn open(recipient_path: impl AsRef<Path>) -> Result<Self, SessionError> {
        let recipient_path = recipient_path.as_ref();
        let recipient = SessionStore::open_existing(recipient_path)?;
        require_clean_session(&recipient)?;
        Ok(Self {
            path: mailbox_path(recipient_path)?,
            recipient_path: recipient_path.to_owned(),
            recipient_session_id: recipient.session_id().to_owned(),
            workspace: fs::canonicalize(&recipient.header.cwd)?,
        })
    }

    pub fn path(&self) -> &Path {
        &self.path
    }

    fn check_access(&self, actor: &SessionStore, recipient_only: bool) -> Result<(), SessionError> {
        let expected_actor = actor.session_id();
        let actor = SessionStore::open_existing(actor.path())?;
        let recipient = SessionStore::open_existing(&self.recipient_path)?;
        require_clean_session(&actor)?;
        require_clean_session(&recipient)?;
        if actor.session_id() != expected_actor
            || recipient.session_id() != self.recipient_session_id
            || fs::canonicalize(&recipient.header.cwd)? != self.workspace
            || fs::canonicalize(&actor.header.cwd)? != self.workspace
            || (recipient_only && actor.session_id() != self.recipient_session_id)
        {
            return Err(SessionError::InvalidRecord(
                "mailbox access requires the addressed session in the same workspace".into(),
            ));
        }
        Ok(())
    }

    /// Address a message by its immutable digest, avoiding ambiguity when
    /// multiple senders choose the same request ID.
    pub fn find_message(
        &self,
        recipient: &SessionStore,
        digest: &str,
        now: u64,
    ) -> Result<MailboxMessage, SessionError> {
        self.check_access(recipient, true)?;
        if digest.len() != 64 || !digest.bytes().all(|byte| byte.is_ascii_hexdigit()) {
            return Err(SessionError::InvalidRecord(
                "mailbox message ID must be an envelope digest".into(),
            ));
        }
        let mut journal = self.locked(false)?;
        let (messages, _) = self.recover(&mut journal.file)?;
        messages
            .into_iter()
            .find(|message| message.digest == digest)
            .map(|message| message.at_time(now))
            .ok_or_else(|| SessionError::InvalidRecord("mailbox message does not exist".into()))
    }

    pub fn enqueue(
        &self,
        sender: &SessionStore,
        request_id: &str,
        payload: Value,
        ttl_ms: u64,
        now: u64,
    ) -> Result<MailboxMessage, SessionError> {
        self.check_access(sender, false)?;
        mailbox_id(request_id)?;
        validate_mailbox_payload(&payload)?;
        if ttl_ms == 0 || ttl_ms > MAX_MAILBOX_TTL_MS {
            return Err(SessionError::InvalidRecord(
                "mailbox TTL must be positive and at most seven days".into(),
            ));
        }
        if SessionStore::open_existing(&self.recipient_path)?.is_archived() {
            return Err(SessionError::InvalidRecord(
                "cannot queue work for an archived session".into(),
            ));
        }
        let mut journal = self.locked(true)?;
        let (messages, next_sequence) = self.recover(&mut journal.file)?;
        if let Some(existing) = messages.iter().find(|message| {
            message.sender_session_id == sender.session_id() && message.request_id == request_id
        }) {
            if existing.payload != payload
                || existing.expires_at_ms - existing.created_at_ms != ttl_ms
            {
                return Err(SessionError::InvalidRecord(
                    "mailbox request ID conflicts with its durable payload or TTL".into(),
                ));
            }
            return Ok(existing.clone().at_time(now));
        }
        if messages.len() >= MAX_MAILBOX_MESSAGES {
            return Err(SessionError::InvalidRecord(
                "mailbox message limit exceeded".into(),
            ));
        }
        let mut message = MailboxMessage {
            sender_session_id: sender.session_id().into(),
            recipient_session_id: self.recipient_session_id.clone(),
            request_id: request_id.into(),
            digest: String::new(),
            payload,
            created_at_ms: now,
            expires_at_ms: now
                .checked_add(ttl_ms)
                .ok_or_else(|| SessionError::InvalidRecord("mailbox expiry overflow".into()))?,
            sequence: next_sequence,
            status: MailboxStatus::Queued,
            claim_token: None,
            result: None,
        };
        message.digest = message.digest()?;
        self.append(&mut journal.file, next_sequence, &message)?;
        Ok(message)
    }

    pub fn list(
        &self,
        recipient: &SessionStore,
        after_sequence: u64,
        limit: usize,
        now: u64,
    ) -> Result<MailboxPage, SessionError> {
        self.check_access(recipient, true)?;
        if limit == 0 || limit > 64 {
            return Err(SessionError::InvalidRecord(
                "mailbox page limit must be 1..=64".into(),
            ));
        }
        if !self.path.try_exists()? {
            return Ok(MailboxPage {
                messages: Vec::new(),
                next_sequence: None,
            });
        }
        let mut journal = self.locked(false)?;
        let (messages, _) = self.recover(&mut journal.file)?;
        let mut page = Vec::new();
        let mut bytes = 0;
        let mut next_sequence = None;
        for message in messages
            .into_iter()
            .filter(|message| message.sequence > after_sequence)
        {
            let message = message.at_time(now);
            let size = serde_json::to_vec(&message)?.len();
            if page.len() >= limit || bytes + size > 256 * 1024 {
                next_sequence = page.last().map(|message: &MailboxMessage| message.sequence);
                break;
            }
            bytes += size;
            page.push(message);
        }
        Ok(MailboxPage {
            messages: page,
            next_sequence,
        })
    }

    pub fn update(
        &self,
        recipient: &SessionStore,
        sender_session_id: &str,
        request_id: &str,
        action: MailboxAction,
        now: u64,
    ) -> Result<MailboxMessage, SessionError> {
        self.check_access(recipient, true)?;
        mailbox_id(sender_session_id)?;
        mailbox_id(request_id)?;
        let mut journal = self.locked(false)?;
        let (messages, next_sequence) = self.recover(&mut journal.file)?;
        let existing = messages
            .iter()
            .find(|message| {
                message.sender_session_id == sender_session_id && message.request_id == request_id
            })
            .ok_or_else(|| SessionError::InvalidRecord("mailbox request not found".into()))?;
        let mut updated = existing.clone();
        match action {
            MailboxAction::Acknowledge => updated.status = MailboxStatus::Acknowledged,
            MailboxAction::Claim { token } => {
                mailbox_id(&token)?;
                updated.status = MailboxStatus::Claimed;
                updated.claim_token = Some(token);
            }
            MailboxAction::Complete { token, result } => {
                mailbox_id(&token)?;
                validate_mailbox_payload(&result)?;
                updated.status = MailboxStatus::Succeeded;
                updated.claim_token = Some(token);
                updated.result = Some(result);
            }
            MailboxAction::Fail { token, error } => {
                mailbox_id(&token)?;
                validate_mailbox_payload(&error)?;
                updated.status = MailboxStatus::Failed;
                updated.claim_token = Some(token);
                updated.result = Some(error);
            }
        }
        if updated == *existing {
            return Ok(existing.clone().at_time(now));
        }
        if existing.clone().at_time(now).status == MailboxStatus::Expired {
            return Err(SessionError::InvalidRecord(
                "expired mailbox request cannot be executed or implicitly retried".into(),
            ));
        }
        validate_mailbox_transition(existing, &updated)?;
        self.append(&mut journal.file, next_sequence, &updated)?;
        Ok(updated)
    }

    fn locked(&self, create: bool) -> Result<MailboxLock, SessionError> {
        self.locked_inner(create, true)
    }

    fn locked_inner(
        &self,
        create: bool,
        require_active: bool,
    ) -> Result<MailboxLock, SessionError> {
        if require_active {
            self.check_not_retired()?;
        }
        reject_session_symlink(&self.path)?;
        let mut options = OpenOptions::new();
        options.read(true).write(true).create(create);
        #[cfg(unix)]
        options.mode(0o600).custom_flags(libc::O_NOFOLLOW);
        let file = options.open(&self.path)?;
        if !file.metadata()?.is_file() {
            return Err(SessionError::InvalidRecord(
                "mailbox is not a regular file".into(),
            ));
        }
        #[cfg(unix)]
        {
            use std::os::{fd::AsRawFd, unix::fs::MetadataExt};
            let metadata = file.metadata()?;
            if metadata.mode() & 0o077 != 0 || metadata.uid() != unsafe { libc::geteuid() } {
                return Err(SessionError::InvalidRecord(
                    "mailbox must be private and owned by the current user".into(),
                ));
            }
            // Nonblocking locks keep the headless and TUI owners responsive.
            if unsafe { libc::flock(file.as_raw_fd(), libc::LOCK_EX | libc::LOCK_NB) } != 0 {
                return Err(io::Error::last_os_error().into());
            }
            if require_active {
                self.check_not_retired()?;
            }
            Ok(MailboxLock { file })
        }
        #[cfg(not(unix))]
        {
            let _ = file;
            Err(SessionError::InvalidRecord(
                "mailbox locking is unsupported on this platform".into(),
            ))
        }
    }

    fn check_not_retired(&self) -> Result<(), SessionError> {
        let recipient = SessionStore::open_existing(&self.recipient_path)?;
        if recipient.session_id() != self.recipient_session_id
            || recipient
                .events()
                .iter()
                .any(|event| event["type"] == "mailbox_retired")
        {
            return Err(SessionError::InvalidRecord(
                "mailbox recipient changed or was explicitly retired".into(),
            ));
        }
        Ok(())
    }

    fn recover(&self, file: &mut File) -> Result<(Vec<MailboxMessage>, u64), SessionError> {
        if file.metadata()?.len() > MAX_MAILBOX_BYTES as u64 {
            return Err(SessionError::LimitExceeded {
                max: MAX_MAILBOX_BYTES,
                actual: file.metadata()?.len(),
            });
        }
        file.seek(SeekFrom::Start(0))?;
        let mut bytes = Vec::new();
        file.take(MAX_MAILBOX_BYTES as u64 + 1)
            .read_to_end(&mut bytes)?;
        if bytes.len() > MAX_MAILBOX_BYTES {
            return Err(SessionError::LimitExceeded {
                max: MAX_MAILBOX_BYTES,
                actual: bytes.len() as u64,
            });
        }
        if !bytes.is_empty() && !bytes.ends_with(b"\n") {
            return Err(SessionError::InvalidRecord(
                "mailbox has an interrupted append; explicit repair required".into(),
            ));
        }
        let mut messages: Vec<MailboxMessage> = Vec::new();
        let mut next = 1;
        for line in bytes
            .split(|byte| *byte == b'\n')
            .filter(|line| !line.is_empty())
        {
            if line.len() > MAX_SESSION_RECORD_BYTES {
                return Err(SessionError::InvalidRecord(
                    "mailbox record limit exceeded".into(),
                ));
            }
            let record: MailboxRecord = serde_json::from_slice(line)?;
            if record.schema_version != 1 || record.sequence != next {
                return Err(SessionError::InvalidRecord(
                    "mailbox schema or sequence gap".into(),
                ));
            }
            record.message.validate(&self.recipient_session_id)?;
            if let Some(existing) = messages.iter_mut().find(|message| {
                message.sender_session_id == record.message.sender_session_id
                    && message.request_id == record.message.request_id
            }) {
                validate_mailbox_transition(existing, &record.message)?;
                *existing = record.message;
            } else {
                if messages.len() >= MAX_MAILBOX_MESSAGES
                    || record.message.status != MailboxStatus::Queued
                    || record.message.sequence != next
                {
                    return Err(SessionError::InvalidRecord(
                        "mailbox must start with a bounded queued envelope".into(),
                    ));
                }
                messages.push(record.message);
            }
            next += 1;
        }
        Ok((messages, next))
    }

    fn append(
        &self,
        file: &mut File,
        sequence: u64,
        message: &MailboxMessage,
    ) -> Result<(), SessionError> {
        message.validate(&self.recipient_session_id)?;
        let mut encoded = serde_json::to_vec(&MailboxRecord {
            schema_version: 1,
            sequence,
            message: message.clone(),
        })?;
        encoded.push(b'\n');
        if file.metadata()?.len() + encoded.len() as u64 > MAX_MAILBOX_BYTES as u64 {
            return Err(SessionError::InvalidRecord(
                "mailbox byte limit exceeded".into(),
            ));
        }
        file.seek(SeekFrom::End(0))?;
        file.write_all(&encoded)?;
        file.sync_all()?;
        Ok(())
    }
}

struct MailboxLock {
    file: File,
}
impl Drop for MailboxLock {
    fn drop(&mut self) {
        #[cfg(unix)]
        {
            use std::os::fd::AsRawFd;
            unsafe {
                libc::flock(self.file.as_raw_fd(), libc::LOCK_UN);
            }
        }
    }
}

fn mailbox_path(session_path: &Path) -> Result<PathBuf, SessionError> {
    let name = session_path.file_name().ok_or(SessionError::EmptyPath)?;
    let mut name = name.to_os_string();
    name.push(".mailbox");
    Ok(session_path.with_file_name(name))
}

/// Copy a mailbox sidecar without following aliases and with create-new
/// semantics. The source is fully recovered before any bytes are copied, so a
/// failed export cannot create a destination that merely looks deliverable.
fn copy_mailbox_sidecar(
    source_session: &Path,
    destination_session: &Path,
) -> Result<(), SessionError> {
    let source_mailbox = mailbox_path(source_session)?;
    let destination_mailbox = mailbox_path(destination_session)?;
    let metadata = match fs::symlink_metadata(&source_mailbox) {
        Ok(metadata) if metadata.file_type().is_symlink() => {
            return Err(SessionError::Symlink(source_mailbox));
        }
        Ok(metadata) if !metadata.is_file() => {
            return Err(SessionError::InvalidRecord(
                "mailbox sidecar is not a regular file".into(),
            ));
        }
        Ok(metadata) => metadata,
        Err(error) if error.kind() == io::ErrorKind::NotFound => return Ok(()),
        Err(error) => return Err(error.into()),
    };
    if metadata.len() > MAX_MAILBOX_BYTES as u64 {
        return Err(SessionError::LimitExceeded {
            max: MAX_MAILBOX_BYTES,
            actual: metadata.len(),
        });
    }
    let source = SessionMailbox::open(source_session)?;
    let mut source_lock = source.locked(false)?;
    source.recover(&mut source_lock.file)?;

    reject_session_symlink(&destination_mailbox)?;
    let mut options = OpenOptions::new();
    options.create_new(true).write(true);
    #[cfg(unix)]
    options.mode(0o600).custom_flags(libc::O_NOFOLLOW);
    source_lock.file.seek(SeekFrom::Start(0))?;
    let mut bytes = Vec::new();
    (&mut source_lock.file)
        .take(MAX_MAILBOX_BYTES as u64 + 1)
        .read_to_end(&mut bytes)?;
    if bytes.len() > MAX_MAILBOX_BYTES {
        return Err(SessionError::LimitExceeded {
            max: MAX_MAILBOX_BYTES,
            actual: bytes.len() as u64,
        });
    }
    let mut destination = options.open(&destination_mailbox)?;
    if let Err(error) = destination
        .write_all(&bytes)
        .and_then(|()| destination.sync_all())
    {
        let _ = fs::remove_file(&destination_mailbox);
        return Err(error.into());
    }
    use sha2::{Digest, Sha256};
    if format!("{:x}", Sha256::digest(&bytes)) != file_sha256(&destination_mailbox)? {
        let _ = fs::remove_file(&destination_mailbox);
        return Err(SessionError::InvalidRecord(
            "mailbox export digest does not match source".into(),
        ));
    }
    Ok(())
}

fn mailbox_id(id: &str) -> Result<(), SessionError> {
    if id.is_empty()
        || id.len() > 256
        || !id
            .bytes()
            .all(|byte| byte.is_ascii_alphanumeric() || b"._:@-".contains(&byte))
    {
        return Err(SessionError::InvalidRecord(
            "invalid mailbox identifier".into(),
        ));
    }
    Ok(())
}

fn validate_mailbox_payload(payload: &Value) -> Result<(), SessionError> {
    if serde_json::to_vec(payload)?.len() > MAX_MAILBOX_PAYLOAD_BYTES {
        return Err(SessionError::InvalidRecord(
            "mailbox payload exceeds 64 KiB".into(),
        ));
    }
    if crate::security::redact_json(payload, &[]) != *payload {
        return Err(SessionError::InvalidRecord(
            "mailbox payload contains a credential or secret".into(),
        ));
    }
    Ok(())
}

fn validate_mailbox_transition(
    previous: &MailboxMessage,
    next: &MailboxMessage,
) -> Result<(), SessionError> {
    use MailboxStatus as Status;
    let valid = matches!(
        (previous.status, next.status),
        (Status::Queued, Status::Acknowledged | Status::Claimed)
            | (Status::Acknowledged, Status::Claimed)
            | (Status::Claimed, Status::Succeeded | Status::Failed)
    );
    if !valid
        || previous.digest != next.digest
        || (previous.claim_token.is_some() && previous.claim_token != next.claim_token)
    {
        return Err(SessionError::InvalidRecord(
            "mailbox transition conflicts with its durable claim or envelope".into(),
        ));
    }
    Ok(())
}

#[cfg(test)]
mod new_session_audit_recovery_tests {
    use super::*;

    #[test]
    fn duplicate_startup_audit_allows_next_append_without_rewriting_history() {
        let root = tempfile::tempdir().unwrap();
        let path = root.path().join("session.jsonl");
        let mut owner = SessionStore::open_in_workspace(&path, root.path()).unwrap();
        let selected = json!({"type":"extensions_selected","generation":2,"tools":[]});
        owner.append_event(selected.clone()).unwrap();
        let identity = owner.session_id().to_owned();
        let mut other = SessionStore::open_existing_writable(&path).unwrap();
        other.append_event(selected).unwrap();
        let original = fs::read(&path).unwrap();
        owner.refresh_extension_audit_tail().unwrap();
        assert_eq!(owner.session_id(), identity);
        assert_eq!(fs::read(&path).unwrap(), original);
        owner
            .append_event(json!({"type":"next_owned_audit"}))
            .unwrap();
        assert!(fs::read(&path).unwrap().starts_with(&original));
        let read = SessionStore::open_existing(&path).unwrap();
        assert!(read.warnings.is_empty());
        assert_eq!(read.events().last().unwrap()["type"], "next_owned_audit");
    }

    #[test]
    fn semantic_external_changes_require_explicit_recovery_and_preserve_owner() {
        for foreign in [
            json!({"type":"model_selected","model":"different"}),
            json!({"type":"approval_decision","decision":"allow"}),
            json!({"type":"extensions_selected","generation":2,"tools":["new_tool"]}),
        ] {
            let root = tempfile::tempdir().unwrap();
            let path = root.path().join("session.jsonl");
            let mut owner = SessionStore::open_in_workspace(&path, root.path()).unwrap();
            owner
                .append_event(json!({"type":"extensions_selected","generation":2,"tools":[]}))
                .unwrap();
            let records = owner.records().to_vec();
            let mut other = SessionStore::open_existing_writable(&path).unwrap();
            other.append_event(foreign).unwrap();
            let original = fs::read(&path).unwrap();
            assert!(owner.refresh_extension_audit_tail().is_err());
            assert_eq!(owner.records(), records);
            assert_eq!(fs::read(&path).unwrap(), original);
        }
    }

    #[test]
    fn malformed_tail_cannot_become_an_appendable_projection() {
        use std::io::Write;
        let root = tempfile::tempdir().unwrap();
        let path = root.path().join("session.jsonl");
        let mut owner = SessionStore::open_in_workspace(&path, root.path()).unwrap();
        owner
            .append_event(json!({"type":"extensions_selected","generation":2,"tools":[]}))
            .unwrap();
        let records = owner.records().to_vec();
        OpenOptions::new()
            .append(true)
            .open(&path)
            .unwrap()
            .write_all(b"{broken\n")
            .unwrap();
        let original = fs::read(&path).unwrap();
        assert!(owner.refresh_extension_audit_tail().is_err());
        assert_eq!(owner.records(), records);
        assert_eq!(fs::read(&path).unwrap(), original);
    }
}

#[cfg(all(test, unix))]
mod append_lock_tests {
    use super::*;

    #[test]
    fn forked_child_cannot_extend_a_finished_append_lock() {
        let dir = tempfile::tempdir().unwrap();
        let mut session = SessionStore::open(dir.path().join("session.jsonl")).unwrap();
        let file = OpenOptions::new()
            .append(true)
            .open(session.path())
            .unwrap();
        let guard = AppendLock::new(&file).unwrap();
        let mut pipe = [0; 2];
        // The post-fork child uses only async-signal-safe libc operations.
        assert_eq!(unsafe { libc::pipe(pipe.as_mut_ptr()) }, 0);
        let pid = unsafe { libc::fork() };
        assert!(pid >= 0);
        if pid == 0 {
            unsafe {
                libc::close(pipe[1]);
                let mut byte = 0u8;
                libc::read(pipe[0], (&mut byte as *mut u8).cast(), 1);
                libc::_exit(0);
            }
        }
        unsafe { libc::close(pipe[0]) };
        drop(guard);
        drop(file);
        // The child is still alive with the inherited descriptor. A new append
        // must succeed now, rather than waiting for that child's exit/exec.
        let result = session.append_event(json!({"type":"after_fork"}));
        let mut status = 0;
        unsafe {
            libc::write(pipe[1], (&1u8 as *const u8).cast(), 1);
            libc::close(pipe[1]);
            libc::waitpid(pid, &mut status, 0);
        }
        assert!(result.is_ok(), "{result:?}");
        assert_eq!(status, 0);
        assert_eq!(session.events().last().unwrap()["type"], "after_fork");
    }
}

#[cfg(all(test, unix))]
mod session_reliability_tests {
    use super::*;

    fn bytes(path: &Path) -> Option<Vec<u8>> {
        match fs::read(path) {
            Ok(value) => Some(value),
            Err(error) if error.kind() == io::ErrorKind::NotFound => None,
            Err(error) => panic!("{}: {error}", path.display()),
        }
    }

    fn owner(recipient: &SessionStore) -> LiveSessionRegistry {
        let mut registry = LiveSessionRegistry::default();
        registry
            .register(recipient.session_id(), 1, "workspace", 10)
            .unwrap();
        registry
    }

    #[test]
    fn sender_reply_rejects_wrong_session_before_completion_and_survives_restart() {
        for succeeded in [true, false] {
            let dir = tempfile::tempdir().unwrap();
            let sender = SessionStore::open(dir.path().join("sender.jsonl")).unwrap();
            let recipient = SessionStore::open(dir.path().join("recipient.jsonl")).unwrap();
            let wrong = SessionStore::open(dir.path().join("wrong.jsonl")).unwrap();
            let mailbox = SessionMailbox::open(recipient.path()).unwrap();
            let queued = mailbox
                .enqueue(&sender, "request", json!({"work":true}), 1000, 10)
                .unwrap();
            let mut registry = owner(&recipient);
            let claimed = registry
                .claim_message(&recipient, "workspace", &queued.digest, 11, 100)
                .unwrap();
            assert_eq!(claimed.status, MailboxStatus::Claimed);
            let before = bytes(mailbox.path());
            let result = json!({"answer":42});
            assert!(
                registry
                    .finish_claim_with_reply(
                        &recipient,
                        &wrong,
                        "workspace",
                        &queued.digest,
                        result.clone(),
                        succeeded,
                        12,
                        100
                    )
                    .is_err()
            );
            assert_eq!(bytes(mailbox.path()), before);
            assert!(bytes(&mailbox_path(wrong.path()).unwrap()).is_none());
            assert!(bytes(&mailbox_path(sender.path()).unwrap()).is_none());
            assert_eq!(
                mailbox
                    .find_message(&recipient, &queued.digest, 12)
                    .unwrap(),
                claimed
            );
            let (completed, reply) = registry
                .finish_claim_with_reply(
                    &recipient,
                    &sender,
                    "workspace",
                    &queued.digest,
                    result.clone(),
                    succeeded,
                    12,
                    100,
                )
                .unwrap();
            assert_eq!(
                completed.status,
                if succeeded {
                    MailboxStatus::Succeeded
                } else {
                    MailboxStatus::Failed
                }
            );
            assert_eq!(reply.recipient_session_id, sender.session_id());
            let completed_bytes = bytes(mailbox.path());
            let reply_bytes = bytes(&mailbox_path(sender.path()).unwrap());
            let repeated = registry
                .finish_claim_with_reply(
                    &recipient,
                    &sender,
                    "workspace",
                    &queued.digest,
                    result.clone(),
                    succeeded,
                    13,
                    100,
                )
                .unwrap();
            assert_eq!(repeated, (completed, reply));
            assert!(
                registry
                    .finish_claim_with_reply(
                        &recipient,
                        &wrong,
                        "workspace",
                        &queued.digest,
                        result.clone(),
                        succeeded,
                        13,
                        100
                    )
                    .is_err()
            );
            assert!(
                registry
                    .finish_claim_with_reply(
                        &recipient,
                        &sender,
                        "workspace",
                        &queued.digest,
                        json!({"answer":43}),
                        succeeded,
                        13,
                        100
                    )
                    .is_err()
            );
            assert_eq!(bytes(mailbox.path()), completed_bytes);
            assert_eq!(bytes(&mailbox_path(sender.path()).unwrap()), reply_bytes);
            let output = std::process::Command::new(std::env::current_exe().unwrap())
                .args([
                    "--exact",
                    "session::session_reliability_tests::sender_reply_restart_child",
                    "--ignored",
                    "--nocapture",
                ])
                .env("ZENPI_TEST_SESSION_ROOT", dir.path())
                .env("ZENPI_TEST_MESSAGE_DIGEST", &queued.digest)
                .env(
                    "ZENPI_TEST_REPLY_SUCCEEDED",
                    if succeeded { "true" } else { "false" },
                )
                .output()
                .unwrap();
            println!(
                "restart success={succeeded}: {}{}",
                String::from_utf8_lossy(&output.stdout),
                String::from_utf8_lossy(&output.stderr)
            );
            assert!(output.status.success());
            assert_eq!(bytes(mailbox.path()), completed_bytes);
            assert_eq!(bytes(&mailbox_path(sender.path()).unwrap()), reply_bytes);
            assert!(bytes(&mailbox_path(wrong.path()).unwrap()).is_none());
        }
    }

    #[test]
    #[ignore = "independent process for persisted reply retry"]
    fn sender_reply_restart_child() {
        let root = PathBuf::from(std::env::var_os("ZENPI_TEST_SESSION_ROOT").unwrap());
        let digest = std::env::var("ZENPI_TEST_MESSAGE_DIGEST").unwrap();
        let succeeded = std::env::var("ZENPI_TEST_REPLY_SUCCEEDED").unwrap() == "true";
        let sender = SessionStore::open_existing(root.join("sender.jsonl")).unwrap();
        let recipient = SessionStore::open_existing(root.join("recipient.jsonl")).unwrap();
        let wrong = SessionStore::open_existing(root.join("wrong.jsonl")).unwrap();
        let mut registry = LiveSessionRegistry::default();
        assert!(
            registry
                .finish_claim_with_reply(
                    &recipient,
                    &wrong,
                    "workspace",
                    &digest,
                    json!({"answer":42}),
                    succeeded,
                    14,
                    100
                )
                .is_err()
        );
        let (completed, reply) = registry
            .finish_claim_with_reply(
                &recipient,
                &sender,
                "workspace",
                &digest,
                json!({"answer":42}),
                succeeded,
                14,
                100,
            )
            .unwrap();
        assert_eq!(completed.sender_session_id, sender.session_id());
        assert_eq!(reply.recipient_session_id, sender.session_id());
        assert_eq!(
            SessionMailbox::open(sender.path())
                .unwrap()
                .list(&sender, 0, 64, 14)
                .unwrap()
                .messages
                .len(),
            1
        );
    }

    #[test]
    fn sender_reply_rejects_replaced_sender_path_before_completion() {
        let dir = tempfile::tempdir().unwrap();
        let sender = SessionStore::open(dir.path().join("sender.jsonl")).unwrap();
        let recipient = SessionStore::open(dir.path().join("recipient.jsonl")).unwrap();
        let mailbox = SessionMailbox::open(recipient.path()).unwrap();
        let queued = mailbox
            .enqueue(&sender, "request", json!({"work":true}), 1000, 10)
            .unwrap();
        let mut registry = owner(&recipient);
        registry
            .claim_message(&recipient, "workspace", &queued.digest, 11, 100)
            .unwrap();
        let before = bytes(mailbox.path());
        fs::rename(sender.path(), dir.path().join("saved-sender.jsonl")).unwrap();
        let replacement = SessionStore::open(sender.path()).unwrap();
        assert_ne!(replacement.session_id(), sender.session_id());
        assert!(
            registry
                .finish_claim_with_reply(
                    &recipient,
                    &sender,
                    "workspace",
                    &queued.digest,
                    json!({"answer":42}),
                    true,
                    12,
                    100
                )
                .is_err()
        );
        assert_eq!(bytes(mailbox.path()), before);
        assert!(bytes(&mailbox_path(sender.path()).unwrap()).is_none());
    }

    #[test]
    fn paging_claim_next_reaches_65th_and_never_reclaims_terminal_or_claimed_messages() {
        let dir = tempfile::tempdir().unwrap();
        let sender = SessionStore::open(dir.path().join("sender.jsonl")).unwrap();
        let recipient = SessionStore::open(dir.path().join("recipient.jsonl")).unwrap();
        let mailbox = SessionMailbox::open(recipient.path()).unwrap();
        for index in 0..64 {
            let id = format!("earlier-{index}");
            mailbox
                .enqueue(
                    &sender,
                    &id,
                    json!({"index":index}),
                    if index % 4 == 0 { 1 } else { 1000 },
                    10,
                )
                .unwrap();
            if index % 4 != 0 {
                mailbox
                    .update(
                        &recipient,
                        sender.session_id(),
                        &id,
                        MailboxAction::Claim {
                            token: "previous-owner".into(),
                        },
                        10,
                    )
                    .unwrap();
            }
            if index % 4 >= 2 {
                let action = if index % 4 == 2 {
                    MailboxAction::Complete {
                        token: "previous-owner".into(),
                        result: json!({"done":true}),
                    }
                } else {
                    MailboxAction::Fail {
                        token: "previous-owner".into(),
                        error: json!({"failed":true}),
                    }
                };
                mailbox
                    .update(&recipient, sender.session_id(), &id, action, 10)
                    .unwrap();
            }
        }
        let next = mailbox
            .enqueue(&sender, "next", json!({"next":true}), 1000, 10)
            .unwrap();
        let ack = mailbox
            .enqueue(&sender, "ack", json!({"ack":true}), 1000, 10)
            .unwrap();
        mailbox
            .update(
                &recipient,
                sender.session_id(),
                "ack",
                MailboxAction::Acknowledge,
                10,
            )
            .unwrap();
        let earlier = mailbox.list(&recipient, 0, 64, 20).unwrap();
        assert_eq!(earlier.messages.len(), 64);
        assert!(earlier.next_sequence.is_some());
        let before = bytes(mailbox.path());
        let mut registry = owner(&recipient);
        assert!(
            registry
                .claim_next(&recipient, "wrong-workspace", 20, 100)
                .unwrap()
                .is_none()
        );
        assert_eq!(bytes(mailbox.path()), before);
        assert!(
            registry
                .claim_next(&recipient, "workspace", 111, 100)
                .unwrap()
                .is_none()
        );
        assert_eq!(bytes(mailbox.path()), before);
        registry = owner(&recipient);
        let claimed = registry
            .claim_next(&recipient, "workspace", 20, 100)
            .unwrap()
            .expect("eligible 65th message must be found");
        assert_eq!(claimed.digest, next.digest);
        assert_eq!(claimed.status, MailboxStatus::Claimed);
        assert_eq!(
            registry
                .claim_next(&recipient, "workspace", 21, 100)
                .unwrap()
                .unwrap()
                .digest,
            ack.digest
        );
        assert!(
            registry
                .claim_next(&recipient, "workspace", 22, 100)
                .unwrap()
                .is_none()
        );
        assert_eq!(
            mailbox.list(&recipient, 0, 64, 22).unwrap().messages,
            earlier.messages
        );
        let complete = bytes(mailbox.path());
        let output = std::process::Command::new(std::env::current_exe().unwrap())
            .args([
                "--exact",
                "session::session_reliability_tests::paging_restart_child",
                "--ignored",
                "--nocapture",
            ])
            .env("ZENPI_TEST_SESSION_ROOT", dir.path())
            .output()
            .unwrap();
        println!(
            "paging restart: {}{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
        assert!(output.status.success());
        assert_eq!(bytes(mailbox.path()), complete);
    }

    #[test]
    #[ignore = "independent process verifying claimed work is not re-admitted"]
    fn paging_restart_child() {
        let root = PathBuf::from(std::env::var_os("ZENPI_TEST_SESSION_ROOT").unwrap());
        let recipient = SessionStore::open_existing(root.join("recipient.jsonl")).unwrap();
        let mut registry = LiveSessionRegistry::default();
        registry
            .register(recipient.session_id(), 2, "workspace", 22)
            .unwrap();
        assert!(
            registry
                .claim_next(&recipient, "workspace", 23, 100)
                .unwrap()
                .is_none()
        );
    }

    #[test]
    fn paging_claim_next_honors_byte_pages_and_existing_capacity() {
        for (count, payload_bytes) in [(6, 60_000), (MAX_MAILBOX_MESSAGES, 1)] {
            let dir = tempfile::tempdir().unwrap();
            let sender = SessionStore::open(dir.path().join("sender.jsonl")).unwrap();
            let recipient = SessionStore::open(dir.path().join("recipient.jsonl")).unwrap();
            let mailbox = SessionMailbox::open(recipient.path()).unwrap();
            let mut last = None;
            for index in 0..count {
                last = Some(
                    mailbox
                        .enqueue(
                            &sender,
                            &format!("message-{index}"),
                            json!({"text":"x".repeat(payload_bytes)}),
                            if index + 1 == count { 1000 } else { 1 },
                            10,
                        )
                        .unwrap(),
                );
            }
            let page = mailbox.list(&recipient, 0, 64, 20).unwrap();
            assert!(page.next_sequence.is_some());
            if payload_bytes > 1 {
                assert!(page.messages.len() < 64 && page.messages.len() < count);
            }
            let mut registry = owner(&recipient);
            let actual = registry
                .claim_next(&recipient, "workspace", 20, 100)
                .unwrap()
                .expect("eligible message beyond first bounded page");
            assert_eq!(actual.digest, last.unwrap().digest);
            if count == MAX_MAILBOX_MESSAGES {
                assert!(
                    mailbox
                        .enqueue(&sender, "overflow", json!({}), 1000, 20)
                        .is_err()
                );
            }
            let after = bytes(mailbox.path());
            assert!(
                registry
                    .claim_next(&recipient, "workspace", 21, 100)
                    .unwrap()
                    .is_none()
            );
            assert_eq!(bytes(mailbox.path()), after);
        }
    }

    fn collect_all(directory: &Path) -> Result<GarbageCollectionReport, SessionError> {
        garbage_collect_sessions_with_active(
            directory,
            GarbageCollectionPolicy {
                retain_newest: 0,
                older_than_ms: 1,
            },
            None,
            u64::MAX,
        )
    }

    struct ReconnectOwnerChild(Option<std::process::Child>);
    impl Drop for ReconnectOwnerChild {
        fn drop(&mut self) {
            if let Some(child) = &mut self.0 {
                let _ = child.kill();
                let _ = child.wait();
            }
        }
    }

    #[test]
    #[ignore = "independent live reconnect WAL owner held during the parent GC attempt"]
    fn gc_live_owner_child() {
        let root = PathBuf::from(std::env::var_os("ZENPI_TEST_SESSION_ROOT").unwrap());
        let store = SessionStore::open_existing(root.join("owned.jsonl")).unwrap();
        let (mut wal, prior) = ReconnectJournal::open(&store).unwrap();
        assert!(prior.is_empty());
        wal.append(json!({"type":"request_reserved","request_id":"live-request"}))
            .unwrap();
        fs::write(root.join("owner-ready"), b"locked").unwrap();
        let mut release = [0u8; 1];
        std::io::stdin().read_exact(&mut release).unwrap();
        wal.append(json!({"type":"owner_still_writable"})).unwrap();
    }

    #[test]
    fn gc_reconnect_blocks_an_actual_independent_live_owner_and_preserves_restart_evidence() {
        let dir = tempfile::tempdir().unwrap();
        let store = SessionStore::open(dir.path().join("owned.jsonl")).unwrap();
        let other = SessionStore::open(dir.path().join("other.jsonl")).unwrap();
        let mut child = ReconnectOwnerChild(Some(
            std::process::Command::new(std::env::current_exe().unwrap())
                .args([
                    "--exact",
                    "session::session_reliability_tests::gc_live_owner_child",
                    "--ignored",
                    "--nocapture",
                ])
                .env("ZENPI_TEST_SESSION_ROOT", dir.path())
                .stdin(std::process::Stdio::piped())
                .stdout(std::process::Stdio::piped())
                .stderr(std::process::Stdio::piped())
                .spawn()
                .unwrap(),
        ));
        let deadline = std::time::Instant::now() + std::time::Duration::from_secs(5);
        while !dir.path().join("owner-ready").exists() {
            assert!(child.0.as_mut().unwrap().try_wait().unwrap().is_none());
            assert!(
                std::time::Instant::now() < deadline,
                "live owner readiness timed out"
            );
            std::thread::sleep(std::time::Duration::from_millis(5));
        }
        assert!(child.0.as_mut().unwrap().try_wait().unwrap().is_none());
        // An actual ReconnectJournal in another process owns the OS lock.
        assert!(ReconnectJournal::open(&store).is_err());
        let journal_before = bytes(store.path());
        let other_before = bytes(other.path());
        let wal_path = reconnect_path(store.path());
        let wal_before = bytes(&wal_path);
        let result = collect_all(dir.path());
        let no_mutation = bytes(store.path()) == journal_before
            && bytes(other.path()) == other_before
            && bytes(&wal_path) == wal_before;
        child
            .0
            .as_mut()
            .unwrap()
            .stdin
            .take()
            .unwrap()
            .write_all(b"x")
            .unwrap();
        let output = child.0.take().unwrap().wait_with_output().unwrap();
        println!(
            "live WAL owner: {}{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
        assert!(output.status.success());
        assert!(
            result.is_err(),
            "GC must reject an existing live reconnect WAL"
        );
        assert!(
            no_mutation,
            "all selected journals and the WAL must remain byte-identical during rejection"
        );
        let reopened = SessionStore::open_existing(store.path()).unwrap();
        let (wal, events) = ReconnectJournal::open(&reopened).unwrap();
        assert_eq!(events.len(), 2);
        assert_eq!(events[1]["type"], "owner_still_writable");
        drop(wal);
        let saved = bytes(&wal_path);
        assert!(
            collect_all(dir.path()).is_err(),
            "closed WAL also retains reconnect evidence"
        );
        assert_eq!(bytes(store.path()), journal_before);
        assert_eq!(bytes(other.path()), other_before);
        assert_eq!(bytes(&wal_path), saved);
    }

    #[test]
    fn gc_reconnect_preserves_closed_empty_torn_malformed_and_nonfile_states() {
        use std::os::unix::fs::PermissionsExt;
        let mut failures = Vec::new();
        for state in ["closed", "empty", "torn", "malformed", "directory"] {
            let dir = tempfile::tempdir().unwrap();
            let export_dir = tempfile::tempdir().unwrap();
            let store = SessionStore::open(dir.path().join("owned.jsonl")).unwrap();
            let other = SessionStore::open(dir.path().join("other.jsonl")).unwrap();
            let wal_path = reconnect_path(store.path());
            match state {
                "closed" => {
                    let (mut wal, _) = ReconnectJournal::open(&store).unwrap();
                    wal.append(json!({"type":"reserved"})).unwrap();
                    drop(wal);
                }
                "empty" => fs::write(&wal_path, b"").unwrap(),
                "torn" => fs::write(&wal_path, b"{unfinished").unwrap(),
                "malformed" => fs::write(&wal_path, b"{invalid}\n").unwrap(),
                "directory" => fs::create_dir(&wal_path).unwrap(),
                _ => unreachable!(),
            }
            if state != "directory" {
                fs::set_permissions(&wal_path, fs::Permissions::from_mode(0o600)).unwrap();
            }
            if state == "malformed" {
                assert!(ReconnectJournal::open(&store).is_err());
            }
            let journal_before = bytes(store.path());
            let other_before = bytes(other.path());
            let wal_before = if state == "directory" {
                None
            } else {
                bytes(&wal_path)
            };
            assert!(
                store
                    .export_to(export_dir.path().join("export.jsonl"))
                    .is_err()
            );
            assert!(
                execute_session_lifecycle(
                    SessionLifecycleRequest::Delete {
                        path: store.path().to_owned(),
                        confirmed: true
                    },
                    None,
                    u64::MAX
                )
                .is_err()
            );
            let result = collect_all(dir.path());
            let wal_unchanged = if state == "directory" {
                wal_path.is_dir() && fs::read_dir(&wal_path).unwrap().count() == 0
            } else {
                bytes(&wal_path) == wal_before
            };
            let preserved = bytes(store.path()) == journal_before
                && bytes(other.path()) == other_before
                && wal_unchanged;
            println!(
                "reconnect state={state}: gc_rejected={} unchanged={preserved}",
                result.is_err()
            );
            if result.is_ok() || !preserved {
                failures.push(state);
            }
        }
        assert!(
            failures.is_empty(),
            "unprotected reconnect states: {failures:?}"
        );
    }

    #[test]
    fn gc_without_reconnect_still_removes_only_inactive_owned_sessions() {
        let dir = tempfile::tempdir().unwrap();
        let store = SessionStore::open(dir.path().join("owned.jsonl")).unwrap();
        let foreign = dir.path().join("foreign.jsonl");
        fs::write(&foreign, b"foreign data\n").unwrap();
        assert!(
            garbage_collect_sessions_with_active(
                dir.path(),
                GarbageCollectionPolicy {
                    retain_newest: 0,
                    older_than_ms: 1
                },
                Some(store.path()),
                u64::MAX
            )
            .is_err()
        );
        assert!(store.path().exists());
        let report = collect_all(dir.path()).unwrap();
        assert_eq!(report.removed, vec![store.path().to_owned()]);
        assert!(!store.path().exists());
        assert_eq!(fs::read(&foreign).unwrap(), b"foreign data\n");
    }
}
