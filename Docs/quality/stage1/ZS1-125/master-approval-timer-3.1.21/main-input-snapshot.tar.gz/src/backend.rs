//! Backend boundary for zenpi.
//!
//! The core deliberately knows nothing about HTTP, model SDKs, or streaming
//! transports.  A backend receives an immutable view of the session and
//! returns one normalized completion.  This keeps the headless and TUI modes
//! behaviorally identical and makes a deterministic backend useful in tests.

use std::{
    env,
    str::FromStr,
    sync::Mutex,
    time::{Duration, Instant},
};

use serde::{Deserialize, Serialize};
use serde_json::{Value, json};
use thiserror::Error;

use crate::core::{Turn, TurnRole};
use crate::security::{SecretError, SecretHandle};
use crate::tools::{ToolCall, ToolDefinition};

mod chat_stream;
mod transport;

/// Keep provider responses bounded even when an endpoint omits a content
/// length.  The core applies the smaller per-turn text limit afterwards.
pub const MAX_RESPONSE_BYTES: usize = 4 * 1024 * 1024;
pub const MAX_ATTACHMENTS_PER_TURN: usize = 8;
pub const MAX_ATTACHMENT_BYTES: usize = 10 * 1024 * 1024;
pub const MAX_TOTAL_ATTACHMENT_BYTES: usize = 20 * 1024 * 1024;
/// Maximum time a blocking Responses body read may hide a cancellation
/// request. `ureq` has no external abort handle, so the synchronous adapter
/// uses short receive-body slices and resumes after ordinary slice expiry.
const CANCEL_POLL_INTERVAL: Duration = Duration::from_millis(100);

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum AttachmentKind {
    Image,
    File,
}

/// A user-visible attachment reference. Exactly one source is accepted. A
/// workspace source is persisted as a relative path and materialized only for
/// the current bounded provider request; bytes never enter the journal.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct InputAttachment {
    pub kind: AttachmentKind,
    pub mime_type: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub path: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub url: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub file_id: Option<String>,
}

impl InputAttachment {
    pub fn validate(&self) -> Result<(), BackendError> {
        if self.mime_type.trim().is_empty()
            || self.mime_type.len() > 255
            || !self.mime_type.contains('/')
            || self.mime_type.chars().any(char::is_control)
        {
            return Err(BackendError::Configuration(
                "attachment MIME type is invalid".into(),
            ));
        }
        if self.kind == AttachmentKind::Image && !self.mime_type.starts_with("image/") {
            return Err(BackendError::Configuration(
                "image attachment requires an image/* MIME type".into(),
            ));
        }
        let source_count = usize::from(self.path.is_some())
            + usize::from(self.url.is_some())
            + usize::from(self.file_id.is_some());
        if source_count != 1 {
            return Err(BackendError::Configuration(
                "attachment requires exactly one of path, url, or file_id".into(),
            ));
        }
        if let Some(path) = &self.path
            && (path.trim().is_empty() || path.len() > 4096 || path.contains('\0'))
        {
            return Err(BackendError::Configuration(
                "attachment path is invalid".into(),
            ));
        }
        if let Some(url) = &self.url
            && (self.kind != AttachmentKind::Image
                || url.len() > 2048
                || !url.starts_with("https://")
                || url.chars().any(char::is_whitespace))
        {
            return Err(BackendError::Configuration(
                "remote attachments must be HTTPS image URLs".into(),
            ));
        }
        if let Some(file_id) = &self.file_id
            && (file_id.trim().is_empty()
                || file_id.len() > 512
                || file_id.chars().any(char::is_control))
        {
            return Err(BackendError::Configuration(
                "provider file ID is invalid".into(),
            ));
        }
        Ok(())
    }
}

#[derive(Debug, Clone)]
pub struct RequestAttachment {
    pub turn_id: String,
    pub input: InputAttachment,
    pub filename: Option<String>,
    pub data: Option<Vec<u8>>,
    pub size_bytes: Option<u64>,
    pub sha256: Option<String>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct ProviderCapabilities {
    pub text: bool,
    pub images: bool,
    pub files: bool,
    pub tools: bool,
    pub structured_output: bool,
    pub streaming: bool,
    pub reasoning: bool,
}

impl ProviderCapabilities {
    pub const fn for_wire_api(wire_api: OpenAiWireApi) -> Self {
        match wire_api {
            OpenAiWireApi::AnthropicMessages => crate::providers::anthropic::CAPABILITIES,
            OpenAiWireApi::GoogleGenerativeAi => crate::providers::google::CAPABILITIES,
            OpenAiWireApi::Responses => Self {
                text: true,
                images: true,
                files: true,
                tools: true,
                structured_output: true,
                streaming: true,
                reasoning: true,
            },
            OpenAiWireApi::ChatCompletions => Self {
                text: true,
                images: true,
                files: false,
                tools: true,
                structured_output: true,
                streaming: true,
                reasoning: false,
            },
        }
    }
}

#[derive(Debug, Default)]
struct CircuitState {
    consecutive_failures: u32,
    open_until: Option<Instant>,
}

/// A normalized request independent of the provider protocol.
#[derive(Debug)]
pub struct CompletionRequest<'a> {
    pub turn_id: &'a str,
    pub turns: &'a [Turn],
    pub model: Option<&'a str>,
    /// Tools advertised for this turn. Providers must not infer or invent
    /// capabilities that are absent from this bounded list.
    pub tools: &'a [ToolDefinition],
    pub instructions: Option<&'a str>,
    pub metadata: Option<&'a Value>,
    pub attachments: &'a [RequestAttachment],
    pub response_format: Option<&'a Value>,
    pub max_output_tokens: Option<u64>,
}

impl<'a> CompletionRequest<'a> {
    pub fn new(
        turn_id: &'a str,
        turns: &'a [Turn],
        model: Option<&'a str>,
        tools: &'a [ToolDefinition],
    ) -> Self {
        Self {
            turn_id,
            turns,
            model,
            tools,
            instructions: None,
            metadata: None,
            attachments: &[],
            response_format: None,
            max_output_tokens: None,
        }
    }

    pub fn with_instructions(mut self, instructions: Option<&'a str>) -> Self {
        self.instructions = instructions;
        self
    }

    pub fn with_max_output_tokens(mut self, tokens: u64) -> Self {
        self.max_output_tokens = Some(tokens);
        self
    }

    pub fn with_response_format(mut self, format: Option<&'a Value>) -> Self {
        self.response_format = format;
        self
    }

    pub fn with_metadata(mut self, metadata: Option<&'a Value>) -> Self {
        self.metadata = metadata;
        self
    }

    pub fn with_attachments(mut self, attachments: &'a [RequestAttachment]) -> Self {
        self.attachments = attachments;
        self
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum ProviderEvent {
    ResponseCreated {
        response_id: Option<String>,
        model: Option<String>,
    },
    TextDelta {
        delta: String,
    },
    ReasoningDelta {
        delta: String,
    },
    TextDone {
        text: String,
    },
    Refusal {
        text: String,
    },
    ToolCallDelta {
        call_id: Option<String>,
        name: Option<String>,
        arguments_delta: String,
    },
    ToolCallDone {
        call: ToolCall,
    },
    Usage {
        usage: Usage,
    },
    Warning {
        message: String,
    },
    Completed {
        response_id: Option<String>,
        model: Option<String>,
    },
    Failed {
        message: String,
    },
}

impl ProviderEvent {
    pub fn kind(&self) -> &'static str {
        match self {
            Self::ResponseCreated { .. } => "response_created",
            Self::TextDelta { .. } => "text_delta",
            Self::ReasoningDelta { .. } => "reasoning_delta",
            Self::TextDone { .. } => "text_done",
            Self::Refusal { .. } => "refusal",
            Self::ToolCallDelta { .. } => "tool_call_delta",
            Self::ToolCallDone { .. } => "tool_call_done",
            Self::Usage { .. } => "usage",
            Self::Warning { .. } => "warning",
            Self::Completed { .. } => "completed",
            Self::Failed { .. } => "failed",
        }
    }
}

/// Optional usage information returned by a provider.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct Usage {
    pub input_tokens: u64,
    pub output_tokens: u64,
    pub total_tokens: u64,
}

/// Provider-independent completion result.
#[derive(Debug, Default, PartialEq)]
pub struct Completion {
    pub content: String,
    pub usage: Option<Usage>,
    pub model: Option<String>,
    pub tool_calls: Vec<ToolCall>,
    pub response_id: Option<String>,
    pub refusal: Option<String>,
    pub annotations: Vec<Value>,
}

impl Completion {
    pub fn text(content: impl Into<String>) -> Self {
        Self {
            content: content.into(),
            usage: None,
            model: None,
            tool_calls: Vec::new(),
            response_id: None,
            refusal: None,
            annotations: Vec::new(),
        }
    }
}

/// Errors at the provider boundary.  They are surfaced as typed headless
/// responses rather than panics or silent fallback to another model.
#[derive(Debug, Error)]
pub enum BackendError {
    #[error("backend configuration: {0}")]
    Configuration(String),
    #[error("backend transport: {0}")]
    Transport(String),
    #[error("backend HTTP status: {status}")]
    HttpStatus {
        status: u16,
        /// Provider-directed retry delay. The value is bounded while parsing
        /// so an endpoint cannot stall the runtime indefinitely.
        retry_after_ms: Option<u64>,
    },
    #[error("backend circuit is open for another {retry_after_ms} ms")]
    CircuitOpen { retry_after_ms: u64 },
    #[error("backend returned an invalid response: {0}")]
    InvalidResponse(String),
    #[error("backend returned an empty completion")]
    EmptyResponse,
    #[error("backend request was cancelled")]
    Cancelled,
    #[error("backend request was superseded by a steer")]
    Steered,
}

impl BackendError {
    /// Stable classification for hosts that need to decide whether a failed
    /// turn may be retried without parsing display text.
    pub const fn is_retryable(&self) -> bool {
        match self {
            Self::Transport(_) => true,
            Self::HttpStatus { status, .. } => {
                *status == 408
                    || *status == 409
                    || *status == 425
                    || *status == 429
                    || (*status >= 500 && *status <= 599)
            }
            Self::Configuration(_)
            | Self::CircuitOpen { .. }
            | Self::InvalidResponse(_)
            | Self::EmptyResponse
            | Self::Cancelled
            | Self::Steered => false,
        }
    }

    pub const fn code(&self) -> &'static str {
        match self {
            Self::Configuration(_) => "backend_configuration",
            Self::Transport(_) => "backend_transport",
            Self::HttpStatus { .. } => "backend_http_status",
            Self::CircuitOpen { .. } => "backend_circuit_open",
            Self::InvalidResponse(_) => "backend_invalid_response",
            Self::EmptyResponse => "backend_empty_response",
            Self::Cancelled => "backend_cancelled",
            Self::Steered => "backend_steered",
        }
    }
}

/// Synchronous provider contract.  A synchronous boundary is intentional:
/// the default binary stays tiny and callers that need concurrency can run
/// independent agents in their own processes.
pub trait Backend: Send + Sync {
    fn complete(&self, request: CompletionRequest<'_>) -> Result<Completion, BackendError>;

    fn complete_with_control(
        &self,
        request: CompletionRequest<'_>,
        cancelled: &dyn Fn() -> bool,
        sink: &mut dyn FnMut(ProviderEvent) -> Result<(), BackendError>,
    ) -> Result<Completion, BackendError> {
        if cancelled() {
            return Err(BackendError::Cancelled);
        }
        let completion = self.complete(request)?;
        if cancelled() {
            return Err(BackendError::Cancelled);
        }
        if !completion.content.is_empty() {
            sink(ProviderEvent::TextDelta {
                delta: completion.content.clone(),
            })?;
        }
        sink(ProviderEvent::Completed {
            response_id: completion.response_id.clone(),
            model: completion.model.clone(),
        })?;
        Ok(completion)
    }

    fn name(&self) -> &str {
        "backend"
    }

    /// Return the configured model when the backend has one. Hosts use this
    /// for status snapshots without downcasting a provider implementation.
    fn model(&self) -> Option<&str> {
        None
    }

    /// None explicitly means this low-level backend is not registry-bound.
    fn model_descriptor(
        &self,
        _model: Option<&str>,
    ) -> Result<Option<crate::providers::registry::ModelDescriptor>, BackendError> {
        Ok(None)
    }

    fn model_catalog(&self) -> Vec<crate::providers::registry::ModelDescriptor> {
        Vec::new()
    }

    fn model_capabilities(
        &self,
        _model: Option<&str>,
    ) -> Result<Option<ProviderCapabilities>, BackendError> {
        Ok(None)
    }

    fn reasoning_effort(&self) -> Option<&str> {
        None
    }

    /// Validate without changing state. Hosts validate, persist the selection,
    /// then call the infallible commit hook below; failed journal writes leave
    /// the effective provider settings untouched.
    fn validate_reasoning_effort(
        &self,
        _model: Option<&str>,
        _effort: Option<&str>,
    ) -> Result<(), BackendError> {
        Err(BackendError::Configuration(
            "runtime reasoning settings require a registry-bound provider".into(),
        ))
    }

    /// Commit only a value accepted by validate_reasoning_effort. This must
    /// perform no I/O and cannot fail after the owner's durable event append.
    fn commit_reasoning_effort(&mut self, _effort: Option<String>) {}

    /// Reject unrepresentable opaque history before a durable model selection.
    fn validate_history_model(
        &self,
        _turns: &[Turn],
        model: Option<&str>,
    ) -> Result<(), BackendError> {
        self.validate_model(model)
    }

    fn validate_model(&self, model: Option<&str>) -> Result<(), BackendError> {
        if let Some(model) = model {
            crate::providers::registry::validate_identity("backend", model)
                .map_err(|error| BackendError::Configuration(error.to_string()))?;
        }
        Ok(())
    }
}

/// Deterministic backend used by default.  It returns the latest user text
/// unchanged, making protocol wiring testable without credentials or network.
#[derive(Debug, Clone, Copy, Default)]
pub struct EchoBackend;

impl Backend for EchoBackend {
    fn complete(&self, request: CompletionRequest<'_>) -> Result<Completion, BackendError> {
        let text = request
            .turns
            .iter()
            .rev()
            .find(|turn| turn.role == TurnRole::User)
            .map(|turn| turn.content.as_str())
            .ok_or_else(|| BackendError::InvalidResponse("request has no user turn".into()))?;
        Ok(Completion::text(text))
    }

    fn name(&self) -> &str {
        "echo"
    }
}

/// Wire protocol used by an OpenAI-compatible HTTP endpoint.
///
/// Chat Completions remains the default for backwards compatibility with
/// existing local proxies.  The Responses API is selected explicitly (or by
/// `ZENPI_WIRE_API=responses`) and is the protocol used by current Codex
/// configuration files.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub enum OpenAiWireApi {
    #[default]
    ChatCompletions,
    Responses,
    AnthropicMessages,
    GoogleGenerativeAi,
}

impl OpenAiWireApi {
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::ChatCompletions => "chat_completions",
            Self::Responses => "responses",
            Self::AnthropicMessages => "anthropic_messages",
            Self::GoogleGenerativeAi => "google_generative_ai",
        }
    }
}

impl FromStr for OpenAiWireApi {
    type Err = BackendError;

    fn from_str(value: &str) -> Result<Self, Self::Err> {
        match value.trim().to_ascii_lowercase().as_str() {
            "chat" | "chat_completions" | "chat-completions" | "chatcompletions" => {
                Ok(Self::ChatCompletions)
            }
            "responses" | "response" => Ok(Self::Responses),
            "anthropic_messages" | "anthropic-messages" => Ok(Self::AnthropicMessages),
            "google_generative_ai" | "google-generative-ai" => Ok(Self::GoogleGenerativeAi),
            other => Err(BackendError::Configuration(format!(
                "unsupported provider wire API {other:?}; use chat_completions, responses, anthropic_messages or google_generative_ai"
            ))),
        }
    }
}

/// A synchronous OpenAI-compatible HTTP backend.
///
/// Both wire APIs consume bounded server-sent event streams. Chat also accepts
/// a JSON response from compatible gateways that ignore streaming. Deltas fold into the same
/// normalized completion. `ureq` is blocking and connection pooling keeps
/// the steady-state process smaller than an async runtime.
pub struct OpenAiCompatibleBackend {
    client: ureq::Agent,
    endpoint: String,
    api_key: Option<String>,
    secret_handle: Option<SecretHandle>,
    secret_policy_digest: Option<String>,
    model: String,
    wire_api: OpenAiWireApi,
    reasoning_effort: Option<String>,
    verbosity: Option<String>,
    request_timeout: Duration,
    max_retries: u32,
    circuit_failure_threshold: u32,
    circuit_cooldown: Duration,
    circuit: Mutex<CircuitState>,
    registry: Option<(String, crate::providers::registry::ModelRegistry)>,
}

impl std::fmt::Debug for OpenAiCompatibleBackend {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter
            .debug_struct("OpenAiCompatibleBackend")
            .field("endpoint", &self.endpoint)
            .field("api_key", &self.api_key.as_ref().map(|_| "<redacted>"))
            .field("secret_handle", &self.secret_handle)
            .field("model", &self.model)
            .field("wire_api", &self.wire_api)
            .field("reasoning_effort", &self.reasoning_effort)
            .field("verbosity", &self.verbosity)
            .field("request_timeout", &self.request_timeout)
            .field("max_retries", &self.max_retries)
            .field("circuit_failure_threshold", &self.circuit_failure_threshold)
            .field("circuit_cooldown", &self.circuit_cooldown)
            .field("registry_bound", &self.registry.is_some())
            .field("capabilities", &self.capabilities())
            .finish()
    }
}

impl OpenAiCompatibleBackend {
    pub fn new(
        endpoint: impl Into<String>,
        api_key: Option<String>,
        model: impl Into<String>,
    ) -> Result<Self, BackendError> {
        Self::new_with_wire_api(endpoint, api_key, model, OpenAiWireApi::ChatCompletions)
    }

    pub fn new_with_wire_api(
        endpoint: impl Into<String>,
        api_key: Option<String>,
        model: impl Into<String>,
        wire_api: OpenAiWireApi,
    ) -> Result<Self, BackendError> {
        Self::new_with_settings(endpoint, api_key, model, wire_api, None, None)
    }

    pub fn new_with_settings(
        endpoint: impl Into<String>,
        api_key: Option<String>,
        model: impl Into<String>,
        wire_api: OpenAiWireApi,
        reasoning_effort: Option<String>,
        verbosity: Option<String>,
    ) -> Result<Self, BackendError> {
        Self::new_with_settings_and_timeout(
            endpoint,
            api_key,
            model,
            wire_api,
            reasoning_effort,
            verbosity,
            Duration::from_secs(120),
        )
    }

    pub fn new_with_settings_and_timeout(
        endpoint: impl Into<String>,
        api_key: Option<String>,
        model: impl Into<String>,
        wire_api: OpenAiWireApi,
        reasoning_effort: Option<String>,
        verbosity: Option<String>,
        timeout: Duration,
    ) -> Result<Self, BackendError> {
        let endpoint = normalize_endpoint(endpoint.into(), wire_api)?;
        let model = model.into();
        if model.trim().is_empty() || model.len() > 256 || model.chars().any(char::is_control) {
            return Err(BackendError::Configuration(
                "model must be non-empty and at most 256 bytes".into(),
            ));
        }
        if api_key
            .as_deref()
            .is_some_and(|key| key.trim().is_empty() || key.chars().any(char::is_control))
        {
            return Err(BackendError::Configuration(
                "API key must be non-empty and contain no control characters".into(),
            ));
        }
        if let Some(key) = api_key.as_deref() {
            crate::security::register_secret_value(key);
        }
        for (name, value) in [
            ("reasoning effort", reasoning_effort.as_deref()),
            ("verbosity", verbosity.as_deref()),
        ] {
            if value.is_some_and(|value| {
                value.trim().is_empty() || value.len() > 64 || value.chars().any(char::is_control)
            }) {
                return Err(BackendError::Configuration(format!(
                    "{name} must be non-empty, at most 64 bytes, and contain no control characters"
                )));
            }
        }
        if timeout.is_zero() || timeout > Duration::from_secs(3600) {
            return Err(BackendError::Configuration(
                "timeout must be between 1 second and 1 hour".into(),
            ));
        }
        let config = ureq::Agent::config_builder()
            .timeout_global(Some(timeout))
            // Status responses must remain inspectable so Retry-After can be
            // honored. They are converted to the typed error below before a
            // response body reaches any parser.
            .http_status_as_error(false)
            .build();
        Ok(Self {
            client: ureq::Agent::new_with_config(config),
            endpoint,
            api_key,
            secret_handle: None,
            secret_policy_digest: None,
            model,
            wire_api,
            reasoning_effort,
            verbosity,
            request_timeout: timeout,
            max_retries: 0,
            circuit_failure_threshold: 3,
            circuit_cooldown: Duration::from_secs(2),
            circuit: Mutex::new(CircuitState::default()),
            registry: None,
        })
    }

    /// Build a provider backend from an opaque, policy-bound credential. The
    /// handle is verified before admission and unwrapped only while adding the
    /// Authorization header to a host-owned request.
    pub fn new_with_secret_handle(
        endpoint: impl Into<String>,
        secret: SecretHandle,
        policy_digest: impl Into<String>,
        model: impl Into<String>,
    ) -> Result<Self, BackendError> {
        Self::new_with_secret_handle_and_settings(
            endpoint,
            secret,
            policy_digest,
            model,
            OpenAiWireApi::ChatCompletions,
            None,
            None,
        )
    }

    /// Settings-preserving variant for Responses streaming and provider
    /// reasoning/verbosity controls.
    pub fn new_with_secret_handle_and_settings(
        endpoint: impl Into<String>,
        secret: SecretHandle,
        policy_digest: impl Into<String>,
        model: impl Into<String>,
        wire_api: OpenAiWireApi,
        reasoning_effort: Option<String>,
        verbosity: Option<String>,
    ) -> Result<Self, BackendError> {
        let policy_digest = policy_digest.into();
        secret
            .verify_policy_digest(&policy_digest)
            .map_err(secret_error)?;
        let mut backend =
            Self::new_with_settings(endpoint, None, model, wire_api, reasoning_effort, verbosity)?;
        backend.secret_handle = Some(secret);
        backend.secret_policy_digest = Some(policy_digest);
        Ok(backend)
    }

    pub fn from_env() -> Result<Self, BackendError> {
        let endpoint = env::var("ZENPI_BASE_URL")
            .or_else(|_| env::var("OPENAI_BASE_URL"))
            .unwrap_or_else(|_| "https://api.openai.com/v1".into());
        let api_key = env::var("ZENPI_API_KEY")
            .or_else(|_| env::var("OPENAI_API_KEY"))
            .ok();
        let model = env::var("ZENPI_MODEL")
            .or_else(|_| env::var("OPENAI_MODEL"))
            .unwrap_or_else(|_| "gpt-4o-mini".into());
        let wire_api = match env::var("ZENPI_WIRE_API").or_else(|_| env::var("OPENAI_WIRE_API")) {
            Ok(value) => value.parse()?,
            Err(_) => OpenAiWireApi::default(),
        };
        Self::from_values_with_wire_api(endpoint, api_key, model, wire_api)
    }

    pub fn from_values_with_wire_api(
        endpoint: String,
        api_key: Option<String>,
        model: String,
        wire_api: OpenAiWireApi,
    ) -> Result<Self, BackendError> {
        let normalized_endpoint = normalize_endpoint(endpoint, wire_api)?;
        if is_openai_endpoint(&normalized_endpoint) && api_key.is_none() {
            return Err(BackendError::Configuration(
                "ZENPI_API_KEY or OPENAI_API_KEY is required for api.openai.com".into(),
            ));
        }
        Self::new_with_wire_api(normalized_endpoint, api_key, model, wire_api)
    }

    pub fn from_values_with_settings(
        endpoint: String,
        api_key: Option<String>,
        model: String,
        wire_api: OpenAiWireApi,
        reasoning_effort: Option<String>,
        verbosity: Option<String>,
    ) -> Result<Self, BackendError> {
        Self::from_values_with_settings_and_timeout(
            endpoint,
            api_key,
            model,
            wire_api,
            reasoning_effort,
            verbosity,
            Duration::from_secs(120),
        )
    }

    pub fn from_values_with_settings_and_timeout(
        endpoint: String,
        api_key: Option<String>,
        model: String,
        wire_api: OpenAiWireApi,
        reasoning_effort: Option<String>,
        verbosity: Option<String>,
        timeout: Duration,
    ) -> Result<Self, BackendError> {
        let normalized_endpoint = normalize_endpoint(endpoint, wire_api)?;
        if is_openai_endpoint(&normalized_endpoint) && api_key.is_none() {
            return Err(BackendError::Configuration(
                "ZENPI_API_KEY or OPENAI_API_KEY is required for api.openai.com".into(),
            ));
        }
        Self::new_with_settings_and_timeout(
            normalized_endpoint,
            api_key,
            model,
            wire_api,
            reasoning_effort,
            verbosity,
            timeout,
        )
    }

    pub fn endpoint(&self) -> &str {
        &self.endpoint
    }

    pub fn model(&self) -> &str {
        &self.model
    }

    pub const fn wire_api(&self) -> OpenAiWireApi {
        self.wire_api
    }

    /// Legacy constructors are wire-only. Production factories must call
    /// `with_model_registry`; their effective capabilities are model × wire.
    pub fn capabilities(&self) -> ProviderCapabilities {
        self.model_capabilities(None)
            .expect("registry binding validates the immutable model identity")
            .unwrap_or_else(|| ProviderCapabilities::for_wire_api(self.wire_api))
    }

    pub fn with_model_registry(
        mut self,
        provider: String,
        registry: crate::providers::registry::ModelRegistry,
    ) -> Result<Self, BackendError> {
        crate::providers::registry::validate_identity(&provider, &self.model)
            .map_err(|error| BackendError::Configuration(error.to_string()))?;
        self.registry = Some((provider, registry));
        self.validate_model(None)?;
        Ok(self)
    }

    pub fn with_max_retries(mut self, max_retries: u32) -> Result<Self, BackendError> {
        if max_retries > 10 {
            return Err(BackendError::Configuration(
                "max retries must be at most 10".into(),
            ));
        }
        self.max_retries = max_retries;
        Ok(self)
    }

    /// Configure the per-backend circuit breaker. This is public primarily so
    /// deterministic hosts and tests can choose a cooldown compatible with
    /// their wall-clock budget; production defaults remain conservative.
    pub fn with_circuit_breaker(
        mut self,
        failure_threshold: u32,
        cooldown: Duration,
    ) -> Result<Self, BackendError> {
        if failure_threshold == 0 || failure_threshold > 100 {
            return Err(BackendError::Configuration(
                "circuit failure threshold must be between 1 and 100".into(),
            ));
        }
        if cooldown.is_zero() || cooldown > Duration::from_secs(300) {
            return Err(BackendError::Configuration(
                "circuit cooldown must be between 1 millisecond and 5 minutes".into(),
            ));
        }
        self.circuit_failure_threshold = failure_threshold;
        self.circuit_cooldown = cooldown;
        Ok(self)
    }
}

fn normalize_endpoint(
    mut endpoint: String,
    wire_api: OpenAiWireApi,
) -> Result<String, BackendError> {
    if endpoint.trim().is_empty() || endpoint.len() > 2048 {
        return Err(BackendError::Configuration(
            "endpoint must be non-empty and at most 2048 bytes".into(),
        ));
    }
    if endpoint
        .chars()
        .any(|character| character.is_whitespace() || character.is_control())
        || !(endpoint.starts_with("http://") || endpoint.starts_with("https://"))
        || endpoint.contains(['?', '#'])
    {
        return Err(BackendError::Configuration(
            "endpoint must be an http or https URL without whitespace, query, or fragment".into(),
        ));
    }
    while endpoint.ends_with('/') {
        endpoint.pop();
    }
    if wire_api == OpenAiWireApi::GoogleGenerativeAi {
        if endpoint.contains("/models/") {
            return Err(BackendError::Configuration(
                "Gemini base URL must precede /models, without a model operation".into(),
            ));
        }
        if endpoint
            .strip_prefix("http://")
            .or_else(|| endpoint.strip_prefix("https://"))
            .is_some_and(|rest| !rest.contains('/'))
        {
            endpoint.push_str("/v1beta");
        }
        return Ok(endpoint);
    }
    let canonical_openai_host = is_openai_endpoint(&endpoint);
    let suffix = match wire_api {
        OpenAiWireApi::ChatCompletions => "/chat/completions",
        OpenAiWireApi::Responses => "/responses",
        OpenAiWireApi::AnthropicMessages => "/messages",
        OpenAiWireApi::GoogleGenerativeAi => unreachable!("handled above"),
    };
    if wire_api == OpenAiWireApi::AnthropicMessages && endpoint.ends_with("/messages") {
        return Ok(endpoint);
    }
    if endpoint.ends_with("/chat/completions") {
        endpoint.truncate(endpoint.len() - "/chat/completions".len());
    } else if endpoint.ends_with("/responses") {
        endpoint.truncate(endpoint.len() - "/responses".len());
    }
    while endpoint.ends_with('/') {
        endpoint.pop();
    }
    if endpoint.ends_with("/v1") {
        endpoint.push_str(suffix);
    } else if endpoint
        .strip_prefix("http://")
        .or_else(|| endpoint.strip_prefix("https://"))
        .is_some_and(|rest| !rest.contains('/'))
    {
        // OpenAI's canonical Responses endpoint lives under `/v1`, while
        // preserving the historical Chat Completions behavior for generic
        // OpenAI-compatible hosts that supplied an origin-only URL.
        if (matches!(wire_api, OpenAiWireApi::Responses) && canonical_openai_host)
            || wire_api == OpenAiWireApi::AnthropicMessages
        {
            endpoint.push_str("/v1");
        }
        endpoint.push_str(suffix);
    } else {
        endpoint.push_str(suffix);
    }
    Ok(endpoint)
}

fn is_openai_endpoint(endpoint: &str) -> bool {
    endpoint
        .strip_prefix("https://")
        .and_then(|rest| rest.split(['/', '?', '#']).next())
        == Some("api.openai.com")
}

impl OpenAiCompatibleBackend {
    fn complete_openai(
        &self,
        request: CompletionRequest<'_>,
        cancelled: &dyn Fn() -> bool,
        sink: &mut dyn FnMut(ProviderEvent) -> Result<(), BackendError>,
    ) -> Result<Completion, BackendError> {
        if cancelled() {
            return Err(BackendError::Cancelled);
        }
        let model = request.model.unwrap_or(&self.model);
        if model.trim().is_empty() || model.len() > 256 || model.chars().any(char::is_control) {
            return Err(BackendError::Configuration(
                "model must be non-empty and at most 256 bytes".into(),
            ));
        }
        self.validate_model(Some(model))?;
        let descriptor = self.model_descriptor(Some(model))?;
        let capabilities = self
            .model_capabilities(Some(model))?
            .unwrap_or_else(|| ProviderCapabilities::for_wire_api(self.wire_api));
        if !capabilities.text {
            return Err(BackendError::Configuration(
                "selected model does not support text".into(),
            ));
        }
        if !capabilities.tools
            && (!request.tools.is_empty()
                || request.turns.iter().any(|turn| {
                    turn.role == TurnRole::Tool
                        || turn
                            .metadata
                            .as_ref()
                            .is_some_and(|metadata| metadata.get("tool_calls").is_some())
                }))
        {
            return Err(BackendError::Configuration(
                "selected model does not support tools".into(),
            ));
        }
        for attachment in request.attachments {
            if (attachment.input.kind == AttachmentKind::Image && !capabilities.images)
                || (attachment.input.kind == AttachmentKind::File && !capabilities.files)
            {
                return Err(BackendError::Configuration(
                    "selected model or wire does not support attachment kind".into(),
                ));
            }
        }
        if let Some(format) = request.response_format {
            if !capabilities.structured_output {
                return Err(BackendError::Configuration(
                    "selected model does not support structured output".into(),
                ));
            }
            validate_response_format(format)?;
        }
        crate::providers::anthropic::validate_history_wire(request.turns, self.wire_api.as_str())?;
        if matches!(
            self.wire_api,
            OpenAiWireApi::AnthropicMessages | OpenAiWireApi::GoogleGenerativeAi
        ) && self.verbosity.is_some()
        {
            return Err(BackendError::Configuration(
                "Native provider verbosity is unsupported".into(),
            ));
        }
        let mut body = match self.wire_api {
            OpenAiWireApi::GoogleGenerativeAi => crate::providers::google::request_body(
                &request,
                model,
                self.reasoning_effort.as_deref(),
                self.registry
                    .as_ref()
                    .map(|(p, _)| p.as_str())
                    .unwrap_or("google"),
            )?,
            OpenAiWireApi::AnthropicMessages => crate::providers::anthropic::request_body(
                &request,
                model,
                self.reasoning_effort.as_deref(),
                self.registry
                    .as_ref()
                    .map(|(p, _)| p.as_str())
                    .unwrap_or("anthropic"),
            )?,
            OpenAiWireApi::ChatCompletions => {
                if request
                    .attachments
                    .iter()
                    .any(|attachment| attachment.input.kind == AttachmentKind::File)
                {
                    return Err(BackendError::Configuration(
                        "Chat Completions adapter does not support file attachments".into(),
                    ));
                }
                let provider = self
                    .registry
                    .as_ref()
                    .map(|(p, _)| p.as_str())
                    .unwrap_or("openai");
                let mut messages: Vec<Value> = request
                    .turns
                    .iter()
                    .map(|turn| chat_message(turn, provider, model))
                    .collect::<Result<_, _>>()?;
                let attachments = attachments_for_context(request.turns, request.attachments);
                apply_chat_attachments(&mut messages, &attachments)?;
                strip_internal_turn_ids(&mut messages);
                let mut body = json!({
                    "model": model,
                    "messages": messages,
                    "stream": true,
                    "stream_options": { "include_usage": true },
                });
                if !request.tools.is_empty() {
                    body["tools"] = Value::Array(
                        request
                            .tools
                            .iter()
                            .map(|tool| {
                                json!({
                                    "type": "function",
                                    "function": {
                                        "name": tool.name,
                                        "description": tool.description,
                                        "parameters": tool.input_schema,
                                    }
                                })
                            })
                            .collect(),
                    );
                    body["tool_choice"] = json!("auto");
                }
                if let Some(instructions) = request.instructions {
                    messages.insert(0, json!({"role":"system", "content": instructions}));
                    body["messages"] = Value::Array(messages);
                }
                if let Some(metadata) = request.metadata {
                    body["metadata"] = metadata.clone();
                }
                body
            }
            OpenAiWireApi::Responses => {
                let mut input: Vec<Value> = request
                    .turns
                    .iter()
                    .flat_map(responses_input_items)
                    .collect();
                let attachments = attachments_for_context(request.turns, request.attachments);
                apply_responses_attachments(&mut input, &attachments)?;
                strip_internal_turn_ids(&mut input);
                let mut body = json!({
                    "model": model,
                    "input": input,
                    "stream": true,
                    "store": false,
                });
                if let Some(effort) = &self.reasoning_effort {
                    body["reasoning"] = json!({"effort": effort});
                }
                if let Some(verbosity) = &self.verbosity {
                    body["text"] = json!({"verbosity": verbosity});
                }
                if !request.tools.is_empty() {
                    body["tools"] = Value::Array(
                        request
                            .tools
                            .iter()
                            .map(|tool| {
                                json!({
                                    "type": "function",
                                    "name": tool.name,
                                    "description": tool.description,
                                    "parameters": tool.input_schema,
                                })
                            })
                            .collect(),
                    );
                    body["tool_choice"] = json!("auto");
                }
                if let Some(instructions) = request.instructions {
                    body["instructions"] = json!(instructions);
                }
                if let Some(metadata) = request.metadata {
                    body["metadata"] = metadata.clone();
                }
                body
            }
        };
        if self.wire_api != OpenAiWireApi::GoogleGenerativeAi {
            body["stream"] = json!(capabilities.streaming);
        }
        if !capabilities.streaming {
            body.as_object_mut()
                .expect("request object")
                .remove("stream_options");
        }
        if descriptor.is_some() || request.max_output_tokens.is_some() {
            let limit = request
                .max_output_tokens
                .unwrap_or(crate::context::DEFAULT_RESERVED_OUTPUT_TOKENS)
                .min(
                    descriptor
                        .as_ref()
                        .map_or(u64::MAX, |model| model.max_output_tokens),
                );
            if limit == 0 {
                return Err(BackendError::Configuration(
                    "output token limit must be positive".into(),
                ));
            }
            if self.wire_api == OpenAiWireApi::GoogleGenerativeAi {
                body["generationConfig"]["maxOutputTokens"] = json!(limit);
            } else {
                body[if self.wire_api == OpenAiWireApi::Responses {
                    "max_output_tokens"
                } else if self.wire_api == OpenAiWireApi::AnthropicMessages {
                    "max_tokens"
                } else {
                    "max_completion_tokens"
                }] = json!(limit);
            }
        }
        if let Some(format) = request.response_format {
            if self.wire_api == OpenAiWireApi::Responses {
                let format = if format["type"] == "json_schema" {
                    let mut schema = format["json_schema"].clone();
                    schema["type"] = json!("json_schema");
                    schema
                } else {
                    format.clone()
                };
                if body.get("text").is_none() {
                    body["text"] = json!({});
                }
                body["text"]["format"] = format;
            } else {
                body["response_format"] = format.clone();
            }
        }
        let endpoint = if self.wire_api == OpenAiWireApi::GoogleGenerativeAi {
            crate::providers::google::endpoint(&self.endpoint, model, capabilities.streaming)?
        } else {
            self.endpoint.clone()
        };
        let (request_client, cancellation) = transport::client(self.client.config().clone());
        let mut request_builder = request_client
            .post(&endpoint)
            .header("content-type", "application/json")
            .header(
                "x-idempotency-key",
                idempotency_key(&endpoint, request.turn_id, &body)?,
            );
        if self.wire_api == OpenAiWireApi::AnthropicMessages {
            request_builder = request_builder.header("anthropic-version", "2023-06-01");
        }
        if let Some(secret) = &self.secret_handle {
            let digest = self.secret_policy_digest.as_deref().ok_or_else(|| {
                BackendError::Configuration("secret policy binding missing".into())
            })?;
            let header = secret
                .with_secret(digest, |key| {
                    if self.wire_api == OpenAiWireApi::GoogleGenerativeAi {
                        key.to_owned()
                    } else {
                        format!("Bearer {key}")
                    }
                })
                .map_err(secret_error)?;
            request_builder = request_builder.header(
                if self.wire_api == OpenAiWireApi::GoogleGenerativeAi {
                    "x-goog-api-key"
                } else {
                    "authorization"
                },
                header,
            );
        } else if let Some(key) = &self.api_key {
            request_builder = if self.wire_api == OpenAiWireApi::GoogleGenerativeAi {
                request_builder.header("x-goog-api-key", key)
            } else {
                request_builder.header("authorization", format!("Bearer {key}"))
            };
        }
        // Both adapters use short receive slices so host cancellation can be
        // observed while a provider is sending a slow body. The Chat JSON
        // reader below resumes the same response after a slice timeout; it
        // never opens a second request.
        if self.wire_api == OpenAiWireApi::Responses
            || self.wire_api == OpenAiWireApi::ChatCompletions
            || self.wire_api == OpenAiWireApi::AnthropicMessages
            || self.wire_api == OpenAiWireApi::GoogleGenerativeAi
        {
            request_builder = request_builder
                // A decompressor may not be resumable after an underlying
                // timeout. SSE is already text and benefits little from
                // compression, so keep cancellation polling on raw bytes.
                .header("accept-encoding", "identity")
                .config()
                .timeout_recv_body(Some(CANCEL_POLL_INTERVAL.min(self.request_timeout)))
                .build();
        }
        let mut response = transport::send_json(request_builder, &body, cancelled, cancellation)?;
        let status = response.status().as_u16();
        if status >= 400 {
            return Err(BackendError::HttpStatus {
                status,
                retry_after_ms: response
                    .headers()
                    .get("retry-after")
                    .and_then(|value| value.to_str().ok())
                    .and_then(parse_retry_after),
            });
        }
        if cancelled() {
            return Err(BackendError::Cancelled);
        }
        match self.wire_api {
            OpenAiWireApi::GoogleGenerativeAi => {
                let provider = self
                    .registry
                    .as_ref()
                    .map(|(p, _)| p.as_str())
                    .unwrap_or("google");
                let sse = response
                    .headers()
                    .get("content-type")
                    .and_then(|v| v.to_str().ok())
                    .is_some_and(|v| {
                        v.split(';')
                            .next()
                            .is_some_and(|m| m.trim().eq_ignore_ascii_case("text/event-stream"))
                    });
                crate::providers::google::read_response(
                    response.body_mut(),
                    sse,
                    provider,
                    model,
                    capabilities,
                    cancelled,
                    sink,
                )
            }
            OpenAiWireApi::AnthropicMessages => {
                let provider = self
                    .registry
                    .as_ref()
                    .map(|(p, _)| p.as_str())
                    .unwrap_or("anthropic");
                let sse = response
                    .headers()
                    .get("content-type")
                    .and_then(|v| v.to_str().ok())
                    .is_some_and(|v| {
                        v.split(';')
                            .next()
                            .is_some_and(|m| m.trim().eq_ignore_ascii_case("text/event-stream"))
                    });
                crate::providers::anthropic::read_response(
                    response.body_mut(),
                    sse,
                    provider,
                    model,
                    capabilities,
                    cancelled,
                    sink,
                )
            }
            OpenAiWireApi::ChatCompletions => {
                if response
                    .headers()
                    .get("content-type")
                    .and_then(|value| value.to_str().ok())
                    .is_some_and(|value| {
                        value.split(';').next().is_some_and(|mime| {
                            mime.trim().eq_ignore_ascii_case("text/event-stream")
                        })
                    })
                {
                    let provider = self
                        .registry
                        .as_ref()
                        .map(|(p, _)| p.as_str())
                        .unwrap_or("openai");
                    return chat_stream::read(
                        response.body_mut(),
                        provider,
                        model,
                        cancelled,
                        sink,
                    );
                }
                let payload = read_bounded_json_body(response.body_mut(), cancelled)?;
                let tool_calls = chat_stream::validate_json(&payload)?;
                let content = match extract_content(&payload) {
                    Ok(content) => content,
                    Err(BackendError::InvalidResponse(_))
                        if !tool_calls.is_empty()
                            && payload["choices"][0]["message"]
                                .get("content")
                                .is_none_or(Value::is_null) =>
                    {
                        String::new()
                    }
                    Err(error) => return Err(error),
                };
                if content.trim().is_empty() && tool_calls.is_empty() {
                    return Err(BackendError::EmptyResponse);
                }
                let mut completion = Completion {
                    content,
                    usage: payload.get("usage").and_then(parse_usage),
                    model: payload
                        .get("model")
                        .and_then(Value::as_str)
                        .map(str::to_owned),
                    tool_calls,
                    response_id: payload.get("id").and_then(Value::as_str).map(str::to_owned),
                    refusal: extract_chat_refusal(&payload),
                    annotations: extract_annotations(&payload),
                };
                let mut reasoning = chat_stream::Reasoning::default();
                let mut delta = reasoning.fold(&payload["choices"][0]["message"])?;
                let provider = self
                    .registry
                    .as_ref()
                    .map(|(p, _)| p.as_str())
                    .unwrap_or("openai");
                reasoning.annotate(provider, model, &mut completion.annotations)?;
                if let Some(reason) = payload["choices"][0]["finish_reason"].as_str() {
                    completion
                        .annotations
                        .push(json!({"type":"chat_finish_reason", "finish_reason":reason}));
                }
                emit_completion_events(&completion, &mut |event| {
                    if cancelled() {
                        return Err(BackendError::Cancelled);
                    }
                    if !matches!(event, ProviderEvent::ResponseCreated { .. })
                        && let Some(delta) = delta.take()
                    {
                        sink(ProviderEvent::ReasoningDelta { delta })?;
                        if cancelled() {
                            return Err(BackendError::Cancelled);
                        }
                    }
                    sink(event)
                })?;
                Ok(completion)
            }
            OpenAiWireApi::Responses => {
                if !capabilities.streaming {
                    let payload = read_bounded_json_body(response.body_mut(), cancelled)?;
                    validate_responses_terminal(&payload, true)?;
                    let completion = completion_from_responses_json(&payload)?;
                    emit_completion_events(&completion, sink)?;
                    Ok(completion)
                } else {
                    read_responses_stream(
                        response.body_mut(),
                        self.registry.is_some(),
                        cancelled,
                        sink,
                    )
                }
            }
        }
    }
}

impl Backend for OpenAiCompatibleBackend {
    fn model_descriptor(
        &self,
        model: Option<&str>,
    ) -> Result<Option<crate::providers::registry::ModelDescriptor>, BackendError> {
        self.registry
            .as_ref()
            .map(|(provider, registry)| registry.resolve(provider, model.unwrap_or(&self.model)))
            .transpose()
            .map_err(|error| BackendError::Configuration(error.to_string()))
    }

    fn model_catalog(&self) -> Vec<crate::providers::registry::ModelDescriptor> {
        self.registry
            .as_ref()
            .map(|(provider, registry)| registry.list(provider))
            .unwrap_or_default()
    }

    fn model_capabilities(
        &self,
        model: Option<&str>,
    ) -> Result<Option<ProviderCapabilities>, BackendError> {
        Ok(self.model_descriptor(model)?.map(|model| {
            model.effective_capabilities(ProviderCapabilities::for_wire_api(self.wire_api))
        }))
    }

    fn reasoning_effort(&self) -> Option<&str> {
        self.reasoning_effort.as_deref()
    }

    fn validate_reasoning_effort(
        &self,
        model: Option<&str>,
        effort: Option<&str>,
    ) -> Result<(), BackendError> {
        if self.wire_api == OpenAiWireApi::GoogleGenerativeAi {
            crate::providers::google::validate_effort(model.unwrap_or(&self.model), effort)?;
        }
        if self.wire_api == OpenAiWireApi::AnthropicMessages {
            crate::providers::anthropic::validate_effort(model.unwrap_or(&self.model), effort)?;
        }
        let model = self.model_descriptor(model)?.ok_or_else(|| {
            BackendError::Configuration(
                "runtime reasoning settings require a registry-bound provider".into(),
            )
        })?;
        model
            .validate_reasoning(ProviderCapabilities::for_wire_api(self.wire_api), effort)
            .map_err(|error| BackendError::Configuration(error.to_string()))
    }

    fn commit_reasoning_effort(&mut self, effort: Option<String>) {
        self.reasoning_effort = effort;
    }

    fn validate_history_model(
        &self,
        turns: &[Turn],
        model: Option<&str>,
    ) -> Result<(), BackendError> {
        let model = model.unwrap_or(&self.model);
        let provider =
            self.registry
                .as_ref()
                .map(|(p, _)| p.as_str())
                .unwrap_or(match self.wire_api {
                    OpenAiWireApi::AnthropicMessages => "anthropic",
                    OpenAiWireApi::GoogleGenerativeAi => "google",
                    _ => "openai",
                });
        for turn in turns {
            chat_stream::validate_history(turn, provider, model, self.wire_api.as_str())?;
            for a in turn
                .metadata
                .as_ref()
                .and_then(|m| m.get("annotations"))
                .and_then(Value::as_array)
                .into_iter()
                .flatten()
                .filter(|a| a["type"] == "native_history")
            {
                if a["wire"] != self.wire_api.as_str() || a["provider"] != provider {
                    return Err(BackendError::Configuration(
                        "native history provider/wire cannot represent selected model".into(),
                    ));
                }
                let opaque = a
                    .get("blocks")
                    .and_then(Value::as_array)
                    .is_some_and(|blocks| {
                        blocks.iter().any(|b| {
                            matches!(b["type"].as_str(), Some("thinking" | "redacted_thinking"))
                        })
                    })
                    || a.get("parts")
                        .and_then(Value::as_array)
                        .is_some_and(|parts| {
                            parts.iter().any(|p| {
                                p.get("thoughtSignature").is_some() || p["thought"] == true
                            })
                        });
                if opaque && a["model"] != model {
                    return Err(BackendError::Configuration(
                        "opaque signed history cannot move to another model".into(),
                    ));
                }
            }
        }
        Ok(())
    }

    fn validate_model(&self, model: Option<&str>) -> Result<(), BackendError> {
        crate::providers::registry::validate_identity("backend", model.unwrap_or(&self.model))
            .map_err(|error| BackendError::Configuration(error.to_string()))?;
        if self.wire_api == OpenAiWireApi::GoogleGenerativeAi {
            crate::providers::google::validate_effort(
                model.unwrap_or(&self.model),
                self.reasoning_effort.as_deref(),
            )?;
        }
        if self.wire_api == OpenAiWireApi::AnthropicMessages {
            crate::providers::anthropic::validate_effort(
                model.unwrap_or(&self.model),
                self.reasoning_effort.as_deref(),
            )?;
        }
        if let Some(model) = self.model_descriptor(model)? {
            model
                .validate_reasoning(
                    ProviderCapabilities::for_wire_api(self.wire_api),
                    self.reasoning_effort.as_deref(),
                )
                .map_err(|error| BackendError::Configuration(error.to_string()))?;
        }
        Ok(())
    }

    fn complete(&self, request: CompletionRequest<'_>) -> Result<Completion, BackendError> {
        self.complete_openai(request, &|| false, &mut |_| Ok(()))
    }

    fn complete_with_control(
        &self,
        request: CompletionRequest<'_>,
        cancelled: &dyn Fn() -> bool,
        sink: &mut dyn FnMut(ProviderEvent) -> Result<(), BackendError>,
    ) -> Result<Completion, BackendError> {
        {
            let mut circuit = self
                .circuit
                .lock()
                .map_err(|_| BackendError::Transport("provider circuit lock poisoned".into()))?;
            if let Some(until) = circuit.open_until
                && until > Instant::now()
            {
                let remaining = until.saturating_duration_since(Instant::now());
                return Err(BackendError::CircuitOpen {
                    retry_after_ms: duration_ms_ceil(remaining),
                });
            }
            circuit.open_until = None;
        }
        let model_tools = self
            .model_capabilities(request.model)?
            .map(|capabilities| capabilities.tools);
        let mut attempt = 0_u32;
        loop {
            let mut emitted = false;
            let result = self.complete_openai(
                CompletionRequest {
                    turn_id: request.turn_id,
                    turns: request.turns,
                    model: request.model,
                    tools: request.tools,
                    instructions: request.instructions,
                    metadata: request.metadata,
                    attachments: request.attachments,
                    response_format: request.response_format,
                    max_output_tokens: request.max_output_tokens,
                },
                cancelled,
                &mut |event| {
                    if model_tools == Some(false)
                        && matches!(
                            event,
                            ProviderEvent::ToolCallDelta { .. }
                                | ProviderEvent::ToolCallDone { .. }
                        )
                    {
                        return Err(BackendError::InvalidResponse(
                            "selected model returned an unsupported tool call".into(),
                        ));
                    }
                    emitted = true;
                    sink(event)
                },
            );
            let should_retry = result.as_ref().is_err_and(|error| {
                !emitted
                    && error.is_retryable()
                    && attempt < self.max_retries
                    && !request
                        .metadata
                        .is_some_and(|v| v["purpose"] == "semantic_compaction")
            });
            if !should_retry {
                let mut circuit = self.circuit.lock().map_err(|_| {
                    BackendError::Transport("provider circuit lock poisoned".into())
                })?;
                match &result {
                    Ok(_) => {
                        circuit.consecutive_failures = 0;
                        circuit.open_until = None;
                    }
                    Err(error) if error.is_retryable() => {
                        circuit.consecutive_failures =
                            circuit.consecutive_failures.saturating_add(1);
                        if circuit.consecutive_failures >= self.circuit_failure_threshold {
                            circuit.open_until = Some(Instant::now() + self.circuit_cooldown);
                        }
                    }
                    Err(_) => {}
                }
                return result;
            }
            attempt = attempt.saturating_add(1);
            sink(ProviderEvent::Warning {
                message: format!("provider request retry {attempt}/{}", self.max_retries),
            })?;
            // Capped exponential backoff. Polling the cancellation predicate
            // avoids making an interrupt wait for the whole sleep.
            let exponential = Duration::from_millis(
                100_u64.saturating_mul(1_u64 << attempt.saturating_sub(1).min(5)),
            );
            let retry_after = match &result {
                Err(BackendError::HttpStatus {
                    retry_after_ms: Some(milliseconds),
                    ..
                }) => Duration::from_millis(*milliseconds),
                _ => Duration::ZERO,
            };
            let delay = exponential.max(retry_after);
            let deadline = std::time::Instant::now() + delay;
            while std::time::Instant::now() < deadline {
                if cancelled() {
                    return Err(BackendError::Cancelled);
                }
                std::thread::sleep(Duration::from_millis(10));
            }
        }
    }

    fn name(&self) -> &str {
        if self.wire_api == OpenAiWireApi::GoogleGenerativeAi {
            return "google-generative-ai";
        }
        if self.wire_api == OpenAiWireApi::AnthropicMessages {
            return "anthropic-messages";
        }
        "openai-compatible"
    }

    fn model(&self) -> Option<&str> {
        Some(&self.model)
    }
}

fn idempotency_key(endpoint: &str, turn_id: &str, body: &Value) -> Result<String, BackendError> {
    use sha2::{Digest, Sha256};

    let payload = serde_json::to_vec(body).map_err(|_| {
        BackendError::Configuration("cannot encode provider request identity".into())
    })?;
    let mut digest = Sha256::new();
    // Retries of identical payloads share an identity; tool continuations in
    // the same outer turn do not. Length prefixes separate arbitrary inputs.
    digest.update(b"zenpi-provider-request-v2\0");
    digest.update((endpoint.len() as u64).to_be_bytes());
    digest.update(endpoint.as_bytes());
    digest.update((turn_id.len() as u64).to_be_bytes());
    digest.update(turn_id.as_bytes());
    digest.update(payload);
    Ok(format!("zenpi-{:x}", digest.finalize()))
}

const MAX_RETRY_AFTER: Duration = Duration::from_secs(60);

fn parse_retry_after(value: &str) -> Option<u64> {
    let delay = if let Ok(seconds) = value.trim().parse::<u64>() {
        Duration::from_secs(seconds)
    } else {
        let deadline = httpdate::parse_http_date(value.trim()).ok()?;
        deadline.duration_since(std::time::SystemTime::now()).ok()?
    }
    .min(MAX_RETRY_AFTER);
    Some(duration_ms_ceil(delay))
}

fn duration_ms_ceil(duration: Duration) -> u64 {
    u64::try_from(duration.as_millis())
        .unwrap_or(u64::MAX)
        .max(u64::from(!duration.is_zero()))
}

fn chat_message(turn: &Turn, provider: &str, model: &str) -> Result<Value, BackendError> {
    let role = match turn.role {
        TurnRole::System => "system",
        TurnRole::User => "user",
        TurnRole::Assistant => "assistant",
        TurnRole::Tool => "tool",
    };
    let mut message = json!({
        "role": role,
        "content": turn.content,
        "_zenpi_turn_id": turn.id,
    });
    if turn.role == TurnRole::Tool {
        if let Some(call_id) = turn
            .metadata
            .as_ref()
            .and_then(|metadata| metadata.get("tool_call_id"))
        {
            message["tool_call_id"] = call_id.clone();
        }
    } else if turn.role == TurnRole::Assistant
        && let Some(calls) = turn
            .metadata
            .as_ref()
            .and_then(|metadata| metadata.get("tool_calls"))
    {
        message["tool_calls"] = Value::Array(
            calls
                .as_array()
                .into_iter()
                .flatten()
                .map(|item| {
                    json!({
                        "type": "function",
                        "id": item.get("id"),
                        "function": {
                            "name": item.get("name"),
                            "arguments": item.get("arguments").map_or_else(|| "{}".into(), Value::to_string),
                        }
                    })
                })
                .collect(),
        );
    }
    chat_stream::replay(turn, provider, model, &mut message)?;
    Ok(message)
}

fn apply_chat_attachments(
    messages: &mut [Value],
    attachments: &[&RequestAttachment],
) -> Result<(), BackendError> {
    for attachment in attachments {
        attachment.input.validate()?;
        if attachment.input.kind != AttachmentKind::Image {
            return Err(BackendError::Configuration(
                "Chat Completions accepts image attachments only".into(),
            ));
        }
        let message = messages
            .iter_mut()
            .rev()
            .find(|message| {
                message.get("role").and_then(Value::as_str) == Some("user")
                    && attachment_turn_matches(message, &attachment.turn_id)
                    && message.get("content").is_some()
            })
            .ok_or_else(|| {
                BackendError::InvalidResponse("attachment has no corresponding user message".into())
            })?;
        let text = message
            .get("content")
            .and_then(Value::as_str)
            .unwrap_or_default()
            .to_owned();
        let content = message
            .get_mut("content")
            .ok_or_else(|| BackendError::InvalidResponse("message content missing".into()))?;
        let parts = if let Value::Array(parts) = content {
            parts
        } else {
            *content = Value::Array(vec![json!({"type":"text", "text": text})]);
            content.as_array_mut().ok_or_else(|| {
                BackendError::InvalidResponse("message content is not an array".into())
            })?
        };
        parts.push(json!({
            "type": "image_url",
            "image_url": { "url": attachment_source(attachment)? },
        }));
    }
    Ok(())
}

fn attachments_for_context<'a>(
    turns: &[Turn],
    attachments: &'a [RequestAttachment],
) -> Vec<&'a RequestAttachment> {
    attachments
        .iter()
        .filter(|attachment| turns.iter().any(|turn| turn.id == attachment.turn_id))
        .collect()
}

fn apply_responses_attachments(
    input: &mut [Value],
    attachments: &[&RequestAttachment],
) -> Result<(), BackendError> {
    for attachment in attachments {
        attachment.input.validate()?;
        let message = input
            .iter_mut()
            .rev()
            .find(|item| {
                item.get("role").and_then(Value::as_str) == Some("user")
                    && attachment_turn_matches(item, &attachment.turn_id)
                    && item.get("content").is_some()
            })
            .ok_or_else(|| {
                BackendError::InvalidResponse("attachment has no corresponding user message".into())
            })?;
        let text = message
            .get("content")
            .and_then(Value::as_str)
            .unwrap_or_default()
            .to_owned();
        let content = message
            .get_mut("content")
            .ok_or_else(|| BackendError::InvalidResponse("message content missing".into()))?;
        let parts = if let Value::Array(parts) = content {
            parts
        } else {
            *content = Value::Array(vec![json!({"type":"input_text", "text": text})]);
            content.as_array_mut().ok_or_else(|| {
                BackendError::InvalidResponse("message content is not an array".into())
            })?
        };
        match attachment.input.kind {
            AttachmentKind::Image => parts.push(json!({
                "type": "input_image",
                "image_url": attachment_source(attachment)?,
            })),
            AttachmentKind::File => {
                let mut part = json!({ "type": "input_file" });
                if let Some(file_id) = &attachment.input.file_id {
                    part["file_id"] = json!(file_id);
                } else if let Some(data) = &attachment.data {
                    part["file_data"] = json!(data_url(&attachment.input.mime_type, data));
                    if let Some(filename) = &attachment.filename {
                        part["filename"] = json!(filename);
                    }
                } else {
                    return Err(BackendError::Configuration(
                        "file attachment requires workspace bytes or provider file_id".into(),
                    ));
                }
                parts.push(part);
            }
        }
    }
    Ok(())
}

fn attachment_source(attachment: &RequestAttachment) -> Result<String, BackendError> {
    if let Some(url) = &attachment.input.url {
        return Ok(url.clone());
    }
    if let Some(data) = &attachment.data {
        return Ok(data_url(&attachment.input.mime_type, data));
    }
    if let Some(file_id) = &attachment.input.file_id {
        return Ok(file_id.clone());
    }
    Err(BackendError::Configuration(
        "attachment source was not materialized".into(),
    ))
}

fn data_url(mime_type: &str, bytes: &[u8]) -> String {
    use base64::Engine;

    format!(
        "data:{mime_type};base64,{}",
        base64::engine::general_purpose::STANDARD.encode(bytes)
    )
}

fn attachment_turn_matches(message: &Value, turn_id: &str) -> bool {
    message
        .get("_zenpi_turn_id")
        .and_then(Value::as_str)
        .is_none_or(|candidate| candidate == turn_id)
}

fn strip_internal_turn_ids(items: &mut [Value]) {
    for item in items {
        if let Some(object) = item.as_object_mut() {
            object.remove("_zenpi_turn_id");
        }
    }
}

fn responses_input_items(turn: &Turn) -> Vec<Value> {
    if turn.role == TurnRole::Tool {
        let call_id = turn
            .metadata
            .as_ref()
            .and_then(|metadata| metadata.get("tool_call_id"))
            .and_then(Value::as_str)
            .unwrap_or(&turn.id);
        return vec![json!({
            "type": "function_call_output",
            "call_id": call_id,
            "output": turn.content,
        })];
    }
    if turn.role == TurnRole::Assistant
        && let Some(calls) = turn
            .metadata
            .as_ref()
            .and_then(|metadata| metadata.get("tool_calls"))
            .and_then(Value::as_array)
    {
        return calls
            .iter()
            .filter_map(|item| {
                Some(json!({
                    "type": "function_call",
                    "call_id": item.get("id")?.as_str()?,
                    "name": item.get("name")?.as_str()?,
                    "arguments": item.get("arguments")?.to_string(),
                }))
            })
            .collect();
    }
    let role = match turn.role {
        TurnRole::System => "system",
        TurnRole::User => "user",
        TurnRole::Assistant => "assistant",
        TurnRole::Tool => unreachable!(),
    };
    vec![json!({
        "role": role,
        "content": turn.content,
        "_zenpi_turn_id": turn.id,
    })]
}

fn secret_error(error: SecretError) -> BackendError {
    BackendError::Configuration(error.to_string())
}

fn map_ureq_error(error: ureq::Error) -> BackendError {
    match error {
        ureq::Error::StatusCode(status) => BackendError::HttpStatus {
            status,
            retry_after_ms: None,
        },
        other => BackendError::Transport(other.to_string()),
    }
}

fn extract_content(payload: &Value) -> Result<String, BackendError> {
    let choice = payload
        .get("choices")
        .and_then(Value::as_array)
        .and_then(|choices| choices.first())
        .ok_or_else(|| BackendError::InvalidResponse("missing choices[0]".into()))?;
    let content = choice
        .get("message")
        .and_then(|message| message.get("content"))
        .or_else(|| choice.get("text"));
    match content {
        Some(Value::String(text)) => Ok(text.clone()),
        Some(Value::Array(parts)) => Ok(parts
            .iter()
            .filter_map(|part| part.get("text").and_then(Value::as_str))
            .collect::<Vec<_>>()
            .join("")),
        Some(other) => Err(BackendError::InvalidResponse(format!(
            "completion content must be a string or text parts, got {other}"
        ))),
        None => Err(BackendError::InvalidResponse(
            "missing completion content".into(),
        )),
    }
}

fn extract_chat_refusal(payload: &Value) -> Option<String> {
    payload
        .get("choices")
        .and_then(Value::as_array)
        .and_then(|choices| choices.first())
        .and_then(|choice| choice.get("message"))
        .and_then(|message| message.get("refusal"))
        .and_then(Value::as_str)
        .map(str::to_owned)
}

fn extract_responses_refusal(payload: &Value) -> Option<String> {
    if let Some(refusal) = payload.get("refusal").and_then(Value::as_str) {
        return Some(refusal.to_owned());
    }
    payload
        .get("output")
        .and_then(Value::as_array)
        .into_iter()
        .flatten()
        .filter(|item| item.get("type").and_then(Value::as_str) == Some("message"))
        .flat_map(|item| item.get("content").and_then(Value::as_array))
        .flatten()
        .find_map(|part| {
            if part.get("type").and_then(Value::as_str) == Some("refusal") {
                part.get("refusal")
                    .or_else(|| part.get("text"))
                    .and_then(Value::as_str)
                    .map(str::to_owned)
            } else {
                None
            }
        })
}

fn extract_annotations(payload: &Value) -> Vec<Value> {
    let mut annotations = Vec::new();
    if let Some(values) = payload.get("annotations").and_then(Value::as_array) {
        annotations.extend(values.iter().cloned());
    }
    if let Some(output) = payload.get("output").and_then(Value::as_array) {
        for item in output {
            if let Some(content) = item.get("content").and_then(Value::as_array) {
                for part in content {
                    if let Some(values) = part.get("annotations").and_then(Value::as_array) {
                        annotations.extend(values.iter().cloned());
                    }
                }
            }
        }
    }
    annotations
}

fn extract_responses_content(payload: &Value) -> Result<String, BackendError> {
    if let Some(text) = payload.get("output_text").and_then(Value::as_str) {
        return Ok(text.to_owned());
    }
    let output = payload
        .get("output")
        .and_then(Value::as_array)
        .ok_or_else(|| BackendError::InvalidResponse("missing output".into()))?;
    let mut text = String::new();
    for item in output {
        let Some(content) = item.get("content") else {
            continue;
        };
        match content {
            Value::String(value) => text.push_str(value),
            Value::Array(parts) => {
                for part in parts {
                    if let Some(value) = part.get("text").and_then(Value::as_str) {
                        text.push_str(value);
                    }
                }
            }
            other => {
                return Err(BackendError::InvalidResponse(format!(
                    "response content must be a string or text parts, got {other}"
                )));
            }
        }
    }
    if text.is_empty() {
        return Err(BackendError::InvalidResponse(
            "missing response output text".into(),
        ));
    }
    Ok(text)
}

fn read_responses_stream(
    body: &mut ureq::Body,
    strict_terminal: bool,
    cancelled: &dyn Fn() -> bool,
    sink: &mut dyn FnMut(ProviderEvent) -> Result<(), BackendError>,
) -> Result<Completion, BackendError> {
    use std::io::Read;

    let configured = body.with_config().limit(MAX_RESPONSE_BYTES as u64).reader();
    let mut reader = configured;
    // Some OpenAI-compatible proxies ignore `stream:true` and return a
    // regular Responses JSON object. Accept that shape as a compatibility
    // fallback while keeping the normal path event-aware.
    let mut content = String::new();
    let mut usage = None;
    let mut model = None;
    let mut saw_completed = false;
    let mut tool_calls = Vec::new();
    let mut response_id: Option<String> = None;
    let mut refusal: Option<String> = None;
    let mut annotations = Vec::new();
    let mut pending = Vec::new();
    let mut chunk = [0_u8; 16 * 1024];
    loop {
        if cancelled() {
            return Err(BackendError::Cancelled);
        }
        let read = match reader.read(&mut chunk) {
            Ok(0) => break,
            Ok(read) => read,
            Err(error) if is_recv_body_poll_timeout(&error) => {
                if cancelled() {
                    return Err(BackendError::Cancelled);
                }
                // This timeout is intentionally a cancellation poll, not a
                // provider failure. ureq retains the body handler and its
                // global deadline, so a later chunk can continue the same SSE
                // frame without opening a second request.
                continue;
            }
            Err(error) => return Err(BackendError::Transport(error.to_string())),
        };
        pending.extend_from_slice(&chunk[..read]);
        while let Some(newline) = pending.iter().position(|byte| *byte == b'\n') {
            let line = pending.drain(..=newline).collect::<Vec<_>>();
            process_responses_line(
                strict_terminal,
                &line,
                &mut content,
                &mut usage,
                &mut model,
                &mut saw_completed,
                &mut tool_calls,
                &mut response_id,
                &mut refusal,
                &mut annotations,
                sink,
            )?;
        }
    }
    if !pending.is_empty() {
        process_responses_line(
            strict_terminal,
            &pending,
            &mut content,
            &mut usage,
            &mut model,
            &mut saw_completed,
            &mut tool_calls,
            &mut response_id,
            &mut refusal,
            &mut annotations,
            sink,
        )?;
    }
    if cancelled() {
        return Err(BackendError::Cancelled);
    }
    if !saw_completed {
        return Err(BackendError::InvalidResponse(
            "Responses stream ended without response.completed".into(),
        ));
    }
    if content.trim().is_empty() {
        if !tool_calls.is_empty() {
            return Ok(Completion {
                content,
                usage,
                model,
                tool_calls,
                response_id,
                refusal,
                annotations,
            });
        }
        return Err(BackendError::EmptyResponse);
    }
    Ok(Completion {
        content,
        usage,
        model,
        tool_calls,
        response_id,
        refusal,
        annotations,
    })
}

pub(crate) fn read_bounded_json_body(
    body: &mut ureq::Body,
    cancelled: &dyn Fn() -> bool,
) -> Result<Value, BackendError> {
    use std::io::Read;
    let mut reader = body.with_config().limit(MAX_RESPONSE_BYTES as u64).reader();
    let mut bytes = Vec::new();
    let mut chunk = [0_u8; 16 * 1024];
    loop {
        if cancelled() {
            return Err(BackendError::Cancelled);
        }
        match reader.read(&mut chunk) {
            Ok(0) => break,
            Ok(read) => bytes.extend_from_slice(&chunk[..read]),
            Err(error) if is_recv_body_poll_timeout(&error) => continue,
            Err(error) => return Err(BackendError::Transport(error.to_string())),
        }
    }
    if cancelled() {
        return Err(BackendError::Cancelled);
    }
    serde_json::from_slice(&bytes)
        .map_err(|error| BackendError::InvalidResponse(format!("invalid JSON response: {error}")))
}

#[allow(clippy::too_many_arguments)]
fn process_responses_line(
    strict_terminal: bool,
    line: &[u8],
    content: &mut String,
    usage: &mut Option<Usage>,
    model: &mut Option<String>,
    saw_completed: &mut bool,
    tool_calls: &mut Vec<ToolCall>,
    response_id: &mut Option<String>,
    refusal: &mut Option<String>,
    annotations: &mut Vec<Value>,
    sink: &mut dyn FnMut(ProviderEvent) -> Result<(), BackendError>,
) -> Result<(), BackendError> {
    let line = std::str::from_utf8(line).map_err(|error| {
        BackendError::InvalidResponse(format!("Responses stream is not valid UTF-8: {error}"))
    })?;
    let clean_line =
        line.trim_matches(|character: char| character == '\0' || character.is_ascii_whitespace());
    if clean_line.starts_with('{') && !clean_line.contains("data:") {
        let payload: Value = serde_json::from_str(clean_line).map_err(|error| {
            BackendError::InvalidResponse(format!("invalid Responses JSON: {error}"))
        })?;
        validate_responses_terminal(&payload, strict_terminal)?;
        let completion = completion_from_responses_json(&payload)?;
        emit_completion_events(&completion, sink)?;
        *content = completion.content;
        *usage = completion.usage;
        *model = completion.model;
        *tool_calls = completion.tool_calls;
        *response_id = completion.response_id;
        *refusal = completion.refusal;
        *annotations = completion.annotations;
        *saw_completed = true;
        return Ok(());
    }
    let Some(data) = clean_line.strip_prefix("data:") else {
        return Ok(());
    };
    // Some compatible gateways pad SSE frames with NUL bytes between
    // events. They are transport padding, not part of the JSON payload.
    let data =
        data.trim_matches(|character: char| character == '\0' || character.is_ascii_whitespace());
    if data.is_empty() || data == "[DONE]" {
        return Ok(());
    }
    let event: Value = serde_json::from_str(data)
        .map_err(|error| BackendError::InvalidResponse(format!("invalid SSE event: {error}")))?;
    match event.get("type").and_then(Value::as_str) {
        Some("response.output_text.delta") => {
            if let Some(delta) = event.get("delta").and_then(Value::as_str) {
                content.push_str(delta);
                sink(ProviderEvent::TextDelta {
                    delta: delta.to_owned(),
                })?;
            }
        }
        Some("response.output_text.done") => {
            if let Some(value) = event.get("text").and_then(Value::as_str) {
                if content.is_empty() {
                    content.push_str(value);
                }
                sink(ProviderEvent::TextDone {
                    text: value.to_owned(),
                })?;
            }
        }
        Some("response.created") => {
            let response = event.get("response").unwrap_or(&event);
            *response_id = response
                .get("id")
                .and_then(Value::as_str)
                .map(str::to_owned);
            *model = response
                .get("model")
                .and_then(Value::as_str)
                .map(str::to_owned);
            sink(ProviderEvent::ResponseCreated {
                response_id: response_id.clone(),
                model: model.clone(),
            })?;
        }
        Some("response.output_item.done") => {
            if let Some(item) = event.get("item")
                && item.get("type").and_then(Value::as_str) == Some("function_call")
                && let Some(call) = parse_response_function_call(item)
            {
                push_unique_tool_call(tool_calls, call);
                if let Some(call) = tool_calls.last().cloned() {
                    sink(ProviderEvent::ToolCallDone { call })?;
                }
            }
        }
        Some("response.function_call_arguments.delta") => {
            sink(ProviderEvent::ToolCallDelta {
                call_id: event
                    .get("call_id")
                    .and_then(Value::as_str)
                    .map(str::to_owned),
                name: event.get("name").and_then(Value::as_str).map(str::to_owned),
                arguments_delta: event
                    .get("delta")
                    .and_then(Value::as_str)
                    .unwrap_or_default()
                    .to_owned(),
            })?;
        }
        Some("response.function_call_arguments.done") => {
            if let Some(call_id) = event.get("call_id").and_then(Value::as_str)
                && let Some(name) = event.get("name").and_then(Value::as_str)
            {
                let arguments = event
                    .get("arguments")
                    .and_then(Value::as_str)
                    .unwrap_or("{}");
                let call = parse_tool_call(call_id, name, arguments)?;
                push_unique_tool_call(tool_calls, call.clone());
                sink(ProviderEvent::ToolCallDone { call })?;
            }
        }
        Some("response.completed") => {
            let response = event.get("response").unwrap_or(&event);
            validate_responses_terminal(response, strict_terminal)?;
            *saw_completed = true;
            *usage = response.get("usage").and_then(parse_usage);
            *model = response
                .get("model")
                .and_then(Value::as_str)
                .map(str::to_owned);
            *response_id = response
                .get("id")
                .and_then(Value::as_str)
                .map(str::to_owned)
                .or_else(|| response_id.clone());
            *refusal = extract_responses_refusal(response);
            *annotations = extract_annotations(response);
            if let Some(usage_value) = response.get("usage")
                && let Some(parsed) = parse_usage(usage_value)
            {
                sink(ProviderEvent::Usage { usage: parsed })?;
            }
            sink(ProviderEvent::Completed {
                response_id: response_id.clone(),
                model: model.clone(),
            })?;
        }
        Some("response.refusal.delta") | Some("response.refusal.done") => {
            if let Some(value) = event
                .get("delta")
                .or_else(|| event.get("text"))
                .and_then(Value::as_str)
            {
                refusal.get_or_insert_with(String::new).push_str(value);
                sink(ProviderEvent::Refusal {
                    text: value.to_owned(),
                })?;
            }
        }
        Some("response.failed") | Some("error") => {
            let message = extract_responses_error(&event);
            let _ = sink(ProviderEvent::Failed {
                message: message.clone(),
            });
            return Err(BackendError::InvalidResponse(message));
        }
        _ => {}
    }
    Ok(())
}

pub(crate) fn is_recv_body_poll_timeout(error: &std::io::Error) -> bool {
    error
        .get_ref()
        .and_then(|source| source.downcast_ref::<ureq::Error>())
        .is_some_and(|error| matches!(error, ureq::Error::Timeout(ureq::Timeout::RecvBody)))
}

fn completion_from_responses_json(payload: &Value) -> Result<Completion, BackendError> {
    let tool_calls = extract_responses_tool_calls(payload)?;
    let content = extract_responses_content(payload).or_else(|error| {
        if tool_calls.is_empty() {
            Err(error)
        } else {
            Ok(String::new())
        }
    })?;
    if content.trim().is_empty() && tool_calls.is_empty() {
        return Err(BackendError::EmptyResponse);
    }
    Ok(Completion {
        content,
        usage: payload.get("usage").and_then(parse_usage),
        model: payload
            .get("model")
            .and_then(Value::as_str)
            .map(str::to_owned),
        tool_calls,
        response_id: payload.get("id").and_then(Value::as_str).map(str::to_owned),
        refusal: extract_responses_refusal(payload),
        annotations: extract_annotations(payload),
    })
}

fn emit_completion_events(
    completion: &Completion,
    sink: &mut dyn FnMut(ProviderEvent) -> Result<(), BackendError>,
) -> Result<(), BackendError> {
    if let Some(response_id) = completion.response_id.clone() {
        sink(ProviderEvent::ResponseCreated {
            response_id: Some(response_id),
            model: completion.model.clone(),
        })?;
    }
    if !completion.content.is_empty() {
        sink(ProviderEvent::TextDelta {
            delta: completion.content.clone(),
        })?;
        sink(ProviderEvent::TextDone {
            text: completion.content.clone(),
        })?;
    }
    if let Some(refusal) = completion.refusal.clone() {
        sink(ProviderEvent::Refusal { text: refusal })?;
    }
    for call in &completion.tool_calls {
        sink(ProviderEvent::ToolCallDone { call: call.clone() })?;
    }
    if let Some(usage) = completion.usage {
        sink(ProviderEvent::Usage { usage })?;
    }
    sink(ProviderEvent::Completed {
        response_id: completion.response_id.clone(),
        model: completion.model.clone(),
    })
}

fn push_unique_tool_call(calls: &mut Vec<ToolCall>, call: ToolCall) {
    if !calls.iter().any(|existing| existing.id == call.id) {
        calls.push(call);
    }
}

fn extract_responses_tool_calls(payload: &Value) -> Result<Vec<ToolCall>, BackendError> {
    let Some(output) = payload.get("output").and_then(Value::as_array) else {
        return Ok(Vec::new());
    };
    output
        .iter()
        .filter(|item| item.get("type").and_then(Value::as_str) == Some("function_call"))
        .map(parse_response_function_call)
        .collect::<Option<Vec<_>>>()
        .ok_or_else(|| BackendError::InvalidResponse("response function call is incomplete".into()))
}

fn parse_response_function_call(item: &Value) -> Option<ToolCall> {
    if item
        .get("status")
        .is_some_and(|status| status != "completed")
    {
        return None;
    }
    let id = item
        .get("call_id")
        .or_else(|| item.get("id"))
        .and_then(Value::as_str)?;
    let name = item.get("name").and_then(Value::as_str)?;
    let arguments = item
        .get("arguments")
        .and_then(Value::as_str)
        .unwrap_or("{}");
    parse_tool_call(id, name, arguments).ok()
}

fn parse_tool_call(id: &str, name: &str, arguments: &str) -> Result<ToolCall, BackendError> {
    let arguments = serde_json::from_str(arguments).map_err(|error| {
        BackendError::InvalidResponse(format!("invalid tool call arguments: {error}"))
    })?;
    Ok(ToolCall {
        id: id.to_owned(),
        name: name.to_owned(),
        arguments,
    })
}

fn extract_responses_error(event: &Value) -> String {
    let error = event.get("error").or_else(|| {
        event
            .get("response")
            .and_then(|response| response.get("error"))
    });
    match error {
        Some(Value::String(message)) => message.to_owned(),
        Some(Value::Object(error)) => error
            .get("message")
            .and_then(Value::as_str)
            .or_else(|| error.get("code").and_then(Value::as_str))
            .unwrap_or("Responses stream failed")
            .to_owned(),
        _ => "Responses stream failed".to_owned(),
    }
}

fn parse_usage(value: &Value) -> Option<Usage> {
    let input = value
        .get("prompt_tokens")
        .or_else(|| value.get("input_tokens"))
        .and_then(Value::as_u64)
        .unwrap_or(0);
    let output = value
        .get("completion_tokens")
        .or_else(|| value.get("output_tokens"))
        .and_then(Value::as_u64)
        .unwrap_or(0);
    let total = value
        .get("total_tokens")
        .and_then(Value::as_u64)
        .unwrap_or(input.saturating_add(output));
    Some(Usage {
        input_tokens: input,
        output_tokens: output,
        total_tokens: total,
    })
}

fn validate_response_format(format: &Value) -> Result<(), BackendError> {
    if serde_json::to_vec(format).map_or(true, |bytes| bytes.len() > 64 * 1024)
        || !format.is_object()
        || !matches!(format["type"].as_str(), Some("json_object" | "json_schema"))
        || (format["type"] == "json_schema"
            && (!format["json_schema"].is_object()
                || !format["json_schema"]["schema"].is_object()
                || !format["json_schema"]["name"]
                    .as_str()
                    .is_some_and(|name| !name.is_empty() && name.len() <= 64)))
    {
        return Err(BackendError::Configuration(
            "structured output format is invalid or too large".into(),
        ));
    }
    Ok(())
}

fn validate_responses_terminal(payload: &Value, strict: bool) -> Result<(), BackendError> {
    if payload
        .get("status")
        .is_some_and(|status| status != "completed")
        || (strict && payload["status"] != "completed")
        || payload
            .get("incomplete_details")
            .is_some_and(|details| !details.is_null())
    {
        return Err(BackendError::InvalidResponse(
            "Responses missing or incomplete terminal status".into(),
        ));
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::{OpenAiCompatibleBackend, OpenAiWireApi, extract_responses_content};
    use serde_json::json;

    #[test]
    fn openai_host_requires_credentials_after_endpoint_normalization() {
        let error = OpenAiCompatibleBackend::from_values_with_wire_api(
            "https://api.openai.com".into(),
            None,
            "gpt-4o-mini".into(),
            OpenAiWireApi::ChatCompletions,
        )
        .expect_err("the normalized OpenAI host must require an API key");
        assert!(error.to_string().contains("API_KEY"));

        let query_error = OpenAiCompatibleBackend::from_values_with_wire_api(
            "https://api.openai.com?tenant=default".into(),
            None,
            "gpt-4o-mini".into(),
            OpenAiWireApi::ChatCompletions,
        )
        .expect_err("query-bearing endpoints must be rejected before any request");
        assert!(query_error.to_string().contains("endpoint"));
    }

    #[test]
    fn responses_wire_api_normalizes_and_parses_names() {
        let backend = OpenAiCompatibleBackend::new_with_wire_api(
            "https://api.openai.com/v1",
            Some("secret".into()),
            "gpt-5",
            OpenAiWireApi::Responses,
        )
        .unwrap();
        assert_eq!(backend.endpoint(), "https://api.openai.com/v1/responses");
        assert_eq!(backend.wire_api(), OpenAiWireApi::Responses);
        assert_eq!(
            "responses".parse::<OpenAiWireApi>().unwrap(),
            OpenAiWireApi::Responses
        );
        assert!("wat".parse::<OpenAiWireApi>().is_err());

        let codex_proxy = OpenAiCompatibleBackend::new_with_wire_api(
            "http://192.168.50.168:18080",
            Some("secret".into()),
            "gpt-5",
            OpenAiWireApi::Responses,
        )
        .unwrap();
        assert_eq!(
            codex_proxy.endpoint(),
            "http://192.168.50.168:18080/responses"
        );

        let missing_key = OpenAiCompatibleBackend::from_values_with_wire_api(
            "https://api.openai.com".into(),
            None,
            "gpt-5".into(),
            OpenAiWireApi::Responses,
        )
        .expect_err("canonical OpenAI Responses host must require a key");
        assert!(missing_key.to_string().contains("API_KEY"));
    }

    #[test]
    fn responses_output_text_variants_are_extracted() {
        assert_eq!(
            extract_responses_content(&json!({"output_text":"top-level"})).unwrap(),
            "top-level"
        );
        assert_eq!(
            extract_responses_content(&json!({
                "output": [
                    {"type":"reasoning","summary":[]},
                    {"type":"message","content":[
                        {"type":"output_text","text":"first"},
                        {"type":"output_text","text":" second"}
                    ]}
                ]
            }))
            .unwrap(),
            "first second"
        );
    }
}
