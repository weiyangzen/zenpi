//! Host-owned raw tool output. Artifact IDs, never caller-supplied paths, are
//! resolved inside a private directory. Raw bytes stay separate from redacted,
//! bounded UTF-8 display snapshots. The host owns canonical event delivery.
#[path = "tool_output/redaction.rs"]
mod redaction;

use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::collections::{BTreeSet, VecDeque};
use std::fs::{self, File, OpenOptions};
use std::io::{Read, Seek, SeekFrom, Write};
use std::path::Path;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::{Arc, Mutex};
use thiserror::Error;

static NEXT_ARTIFACT: AtomicU64 = AtomicU64::new(1);
const MAX_METADATA_BYTES: usize = 16 * 1024;

// The marker belongs to the inode, so hardlink names and removal of the
// original name cannot turn host-only bytes into ordinary workspace content.
// It is a host boundary, not a sandbox against authorized shell/xattr edits.
#[cfg(any(target_os = "linux", target_os = "macos"))]
const PRIVATE_INODE_MARKER: &std::ffi::CStr = c"user.zenpi.private-output";

#[cfg(any(target_os = "linux", target_os = "macos"))]
fn mark_private_inode(file: &File) -> Result<(), OutputError> {
    use std::os::fd::AsRawFd;
    #[cfg(target_os = "linux")]
    let result = unsafe {
        libc::fsetxattr(
            file.as_raw_fd(),
            PRIVATE_INODE_MARKER.as_ptr(),
            b"1".as_ptr().cast(),
            1,
            0,
        )
    };
    #[cfg(target_os = "macos")]
    let result = unsafe {
        libc::fsetxattr(
            file.as_raw_fd(),
            PRIVATE_INODE_MARKER.as_ptr(),
            b"1".as_ptr().cast(),
            1,
            0,
            0,
        )
    };
    if result != 0 {
        return Err(std::io::Error::last_os_error().into());
    }
    Ok(())
}
#[cfg(all(unix, not(any(target_os = "linux", target_os = "macos"))))]
fn mark_private_inode(_: &File) -> Result<(), OutputError> {
    Err(OutputError::Unsupported)
}

/// Inspect the already opened inode, never a model-provided authority flag.
/// Only the platform's explicit missing-attribute error means unmarked.
pub(crate) fn private_output_inode(file: &File) -> std::io::Result<bool> {
    #[cfg(any(target_os = "linux", target_os = "macos"))]
    {
        use std::os::fd::AsRawFd;
        #[cfg(target_os = "linux")]
        let size = unsafe {
            libc::fgetxattr(
                file.as_raw_fd(),
                PRIVATE_INODE_MARKER.as_ptr(),
                std::ptr::null_mut(),
                0,
            )
        };
        #[cfg(target_os = "macos")]
        let size = unsafe {
            libc::fgetxattr(
                file.as_raw_fd(),
                PRIVATE_INODE_MARKER.as_ptr(),
                std::ptr::null_mut(),
                0,
                0,
                0,
            )
        };
        if size >= 0 {
            return Ok(true);
        }
        let error = std::io::Error::last_os_error();
        #[cfg(target_os = "linux")]
        let missing = libc::ENODATA;
        #[cfg(target_os = "macos")]
        let missing = libc::ENOATTR;
        if error.raw_os_error() == Some(missing) {
            Ok(false)
        } else {
            Err(error)
        }
    }
    // Private capture is already unsupported outside these platforms. Keep
    // ordinary workspace tools usable without claiming private-inode support.
    #[cfg(not(any(target_os = "linux", target_os = "macos")))]
    {
        let _ = file;
        Ok(false)
    }
}

pub(crate) fn private_output_path_inode(path: &Path) -> std::io::Result<bool> {
    #[cfg(any(target_os = "linux", target_os = "macos"))]
    {
        use std::os::unix::fs::OpenOptionsExt;
        let file = OpenOptions::new()
            .read(true)
            .custom_flags(libc::O_NONBLOCK | libc::O_CLOEXEC)
            .open(path)?;
        private_output_inode(&file)
    }
    #[cfg(not(any(target_os = "linux", target_os = "macos")))]
    {
        let _ = path;
        Ok(false)
    }
}

#[derive(Debug, Error)]
pub enum OutputError {
    #[error("invalid output artifact request: {0}")]
    Invalid(String),
    #[error("output artifact quota exhausted")]
    Quota,
    #[error("output artifact has expired")]
    Expired,
    #[error("output artifact is missing")]
    Missing,
    #[error("output artifact is unfinished or was interrupted")]
    Interrupted,
    #[error("output artifact integrity check failed")]
    Integrity,
    #[error("output artifact path or permissions are unsafe")]
    UnsafePath,
    #[error("output artifact directory is already owned by another store")]
    Busy,
    #[error("output read cancelled")]
    Cancelled,
    #[error("output capture is closed")]
    Closed,
    #[error("secure output artifacts are unsupported on this platform")]
    Unsupported,
    #[error("output artifact I/O: {0}")]
    Io(#[from] std::io::Error),
    #[error("output artifact metadata: {0}")]
    Json(#[from] serde_json::Error),
}

#[derive(Debug, Clone, Copy)]
pub struct OutputLimits {
    pub max_file_bytes: u64,
    /// Raw payload budget. Metadata has a separate hard bound of 16 KiB
    /// per entry and at most three directory entries per max_files.
    pub max_total_bytes: u64,
    pub max_files: usize,
    pub ttl_ms: u64,
    pub view_bytes: usize,
    pub read_bytes: usize,
    pub progress_capacity: usize,
}
/// Maximum additional raw and metadata bytes reserved before one command.
/// Both streams can temporarily have a raw, final metadata and rename file.
pub fn command_disk_reservation(limits: OutputLimits) -> u64 {
    2 * limits.max_file_bytes + 4 * MAX_METADATA_BYTES as u64
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct CaptureReport {
    pub artifacts: Vec<ArtifactRef>,
    pub errors: Vec<String>,
}

/// One lazy store for the selected journal. The path is derived from the
/// already-open session file, never from a model argument or display label.
#[derive(Default)]
pub struct SessionOutputStore {
    current: Option<(std::path::PathBuf, OutputArtifactStore)>,
}
impl SessionOutputStore {
    pub fn existing_store(
        &mut self,
        session_path: &Path,
        session_id: &str,
    ) -> Result<OutputArtifactStore, OutputError> {
        valid_identity(session_id)?;
        let journal = fs::canonicalize(session_path)?;
        let root = journal.with_file_name(format!(
            ".zenpi-output-{:x}",
            Sha256::digest(session_id.as_bytes())
        ));
        match fs::symlink_metadata(&root) {
            Ok(metadata) if metadata.is_dir() && !metadata.file_type().is_symlink() => {}
            Ok(_) => return Err(OutputError::UnsafePath),
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
                return Err(OutputError::Missing);
            }
            Err(error) => return Err(error.into()),
        }
        if self.current.as_ref().is_none_or(|(path, _)| *path != root) {
            self.current = None;
            self.current = Some((
                root.clone(),
                OutputArtifactStore::open(&root, OutputLimits::default())?,
            ));
        }
        Ok(self
            .current
            .as_ref()
            .expect("opened existing output store")
            .1
            .clone())
    }

    pub fn store(
        &mut self,
        session_path: &Path,
        session_id: &str,
        now_ms: u64,
    ) -> Result<OutputArtifactStore, OutputError> {
        valid_identity(session_id)?;
        let journal = fs::canonicalize(session_path)?;
        let root = journal.with_file_name(format!(
            ".zenpi-output-{:x}",
            Sha256::digest(session_id.as_bytes())
        ));
        if self.current.as_ref().is_none_or(|(path, _)| *path != root) {
            // Release the previous journal's lock before acquiring another.
            self.current = None;
            self.current = Some((
                root.clone(),
                OutputArtifactStore::open(&root, OutputLimits::default())?,
            ));
        }
        let store = self
            .current
            .as_ref()
            .expect("opened output store")
            .1
            .clone();
        store.cleanup_expired(now_ms)?;
        Ok(store)
    }
}
impl Default for OutputLimits {
    fn default() -> Self {
        Self {
            max_file_bytes: 8 * 1024 * 1024,
            max_total_bytes: 64 * 1024 * 1024,
            max_files: 128,
            ttl_ms: 24 * 60 * 60 * 1000,
            view_bytes: 64 * 1024,
            read_bytes: 64 * 1024,
            progress_capacity: 32,
        }
    }
}
impl OutputLimits {
    fn validate(self) -> Result<(), OutputError> {
        if self.max_file_bytes == 0
            || self.max_file_bytes > 64 * 1024 * 1024
            || self.max_total_bytes < self.max_file_bytes
            || self.max_total_bytes > 1024 * 1024 * 1024
            || self.max_files == 0
            || self.max_files > 4096
            || self.ttl_ms == 0
            || self.ttl_ms > 7 * 24 * 60 * 60 * 1000
            || !(4..=256 * 1024).contains(&self.view_bytes)
            || !(1..=256 * 1024).contains(&self.read_bytes)
            || !(1..=128).contains(&self.progress_capacity)
        {
            return Err(OutputError::Invalid("limits out of range".into()));
        }
        Ok(())
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum OutputStream {
    Stdout,
    Stderr,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ArtifactRef {
    pub version: u8,
    pub artifact_id: String,
    pub session_id: String,
    pub call_id: String,
    pub stream: OutputStream,
    pub created_at_ms: u64,
    pub expires_at_ms: u64,
    pub bytes_observed: u64,
    pub bytes_stored: u64,
    pub sha256: Option<String>,
    pub finalized: bool,
    /// True only after EOF, successful write/sync/readback hash verification,
    /// and a normally completed command (no timeout/cancellation).
    pub complete: bool,
    pub truncated: bool,
    pub failure: Option<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct OutputSnapshot {
    pub text: String,
    /// Raw stream offsets represented by the display before credential
    /// redaction. Invalid source UTF-8 uses replacements, flagged by lossy.
    pub display_start: u64,
    pub display_end: u64,
    pub bytes_observed: u64,
    pub truncated: bool,
    pub lossy: bool,
}
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct OutputProgress {
    pub call_id: String,
    pub stream: OutputStream,
    pub snapshot: OutputSnapshot,
    pub dropped_updates: u64,
}
impl OutputProgress {
    /// Reuse the existing canonical view event and typed call association.
    /// The host supplies the envelope sequence/turn ID and drains updates
    /// BEFORE emitting its ToolFinished terminal event.
    pub fn canonical_kind(&self) -> crate::view_model::ViewEventKind {
        let prefix = if self.dropped_updates > 0 {
            format!("[{} output updates dropped]\n", self.dropped_updates)
        } else {
            String::new()
        };
        let stream = match self.stream {
            OutputStream::Stdout => "stdout",
            OutputStream::Stderr => "stderr",
        };
        let mut output = format!(
            "[{stream}: {} bytes]\n{prefix}{}",
            self.snapshot.bytes_observed, self.snapshot.text
        );
        if output.len() > crate::view_model::MAX_VIEW_TEXT_BYTES {
            let mut end = crate::view_model::MAX_VIEW_TEXT_BYTES;
            while !output.is_char_boundary(end) {
                end -= 1;
            }
            output.truncate(end);
        }
        crate::view_model::ViewEventKind::Block {
            block: crate::view_model::ViewBlock::ToolStatus {
                call_id: self.call_id.clone(),
                name: "run_command".into(),
                status: crate::view_model::ToolStatus::Running,
                output: Some(output),
            },
        }
    }
}
#[derive(Debug, Default)]
struct ProgressState {
    queue: VecDeque<OutputProgress>,
    dropped: u64,
    closed: bool,
}
#[derive(Debug, Clone)]
pub struct OutputProgressQueue {
    state: Arc<Mutex<ProgressState>>,
    capacity: usize,
}
impl OutputProgressQueue {
    pub fn drain(&self) -> Vec<OutputProgress> {
        self.state.lock().unwrap().queue.drain(..).collect()
    }
    pub fn close(&self) {
        self.state.lock().unwrap().closed = true;
    }
    fn publish(&self, mut event: OutputProgress) {
        let mut state = self.state.lock().unwrap();
        if state.closed {
            return;
        }
        if state.queue.len() == self.capacity
            && let Some(old) = state.queue.pop_front()
        {
            state.dropped = state
                .dropped
                .saturating_add(old.dropped_updates)
                .saturating_add(1);
        }
        event.dropped_updates = std::mem::take(&mut state.dropped);
        state.queue.push_back(event);
    }
}

#[derive(Debug)]
struct PrivateDirectory {
    file: File,
}
impl Drop for PrivateDirectory {
    fn drop(&mut self) {
        // The final Arc releases the host lease explicitly. CLOEXEC closes a
        // tool child's inherited descriptor at exec, but a concurrent fork
        // can otherwise keep the flock alive briefly after this host closes.
        #[cfg(unix)]
        {
            use std::os::fd::AsRawFd;
            unsafe {
                libc::flock(self.file.as_raw_fd(), libc::LOCK_UN);
            }
        }
    }
}

impl PrivateDirectory {
    #[cfg(unix)]
    fn open(path: &Path) -> Result<Self, OutputError> {
        use std::os::unix::fs::{DirBuilderExt, MetadataExt, OpenOptionsExt};
        match fs::DirBuilder::new().mode(0o700).create(path) {
            Ok(()) => {}
            Err(e) if e.kind() == std::io::ErrorKind::AlreadyExists => {}
            Err(e) => return Err(e.into()),
        }
        let file = OpenOptions::new()
            .read(true)
            .custom_flags(libc::O_DIRECTORY | libc::O_NOFOLLOW | libc::O_CLOEXEC)
            .open(path)
            .map_err(|_| OutputError::UnsafePath)?;
        let meta = file.metadata()?;
        if meta.mode() & 0o777 != 0o700 || meta.uid() != unsafe { libc::geteuid() } {
            return Err(OutputError::UnsafePath);
        }
        use std::os::fd::AsRawFd;
        // The directory lock is held until every clone/writer is dropped.
        if unsafe { libc::flock(file.as_raw_fd(), libc::LOCK_EX | libc::LOCK_NB) } != 0 {
            return Err(OutputError::Busy);
        }
        Ok(Self { file })
    }
    #[cfg(not(unix))]
    fn open(_: &Path) -> Result<Self, OutputError> {
        Err(OutputError::Unsupported)
    }
    #[cfg(unix)]
    fn open_file(&self, name: &str, create: bool) -> Result<File, OutputError> {
        use std::os::fd::{AsRawFd, FromRawFd};
        use std::os::unix::fs::MetadataExt;
        let name = std::ffi::CString::new(name).map_err(|_| OutputError::UnsafePath)?;
        let flags = if create {
            libc::O_RDWR | libc::O_CREAT | libc::O_EXCL
        } else {
            libc::O_RDONLY
        };
        let fd = unsafe {
            libc::openat(
                self.file.as_raw_fd(),
                name.as_ptr(),
                flags | libc::O_NOFOLLOW | libc::O_CLOEXEC,
                0o600,
            )
        };
        if fd < 0 {
            let e = std::io::Error::last_os_error();
            return Err(if e.kind() == std::io::ErrorKind::NotFound {
                OutputError::Missing
            } else {
                OutputError::Io(e)
            });
        }
        let file = unsafe { File::from_raw_fd(fd) };
        let meta = file.metadata()?;
        if !meta.is_file()
            || meta.mode() & 0o777 != 0o600
            || meta.uid() != unsafe { libc::geteuid() }
        {
            return Err(OutputError::UnsafePath);
        }
        // Tag before writing payload or metadata. Existing trusted files are
        // tagged when opened; this is not a scan/migration of unopened stores.
        mark_private_inode(&file)?;
        if meta.nlink() != 1 {
            return Err(OutputError::UnsafePath);
        }
        Ok(file)
    }
    #[cfg(not(unix))]
    fn open_file(&self, _: &str, _: bool) -> Result<File, OutputError> {
        Err(OutputError::Unsupported)
    }
    #[cfg(unix)]
    fn names(&self) -> Result<Vec<String>, OutputError> {
        use std::os::fd::AsRawFd;
        // dup shares the directory stream offset; rewinddir resets each scan.
        let fd = unsafe { libc::dup(self.file.as_raw_fd()) };
        if fd < 0 {
            return Err(std::io::Error::last_os_error().into());
        }
        let dir = unsafe { libc::fdopendir(fd) };
        if dir.is_null() {
            unsafe { libc::close(fd) };
            return Err(std::io::Error::last_os_error().into());
        }
        struct Close(*mut libc::DIR);
        impl Drop for Close {
            fn drop(&mut self) {
                unsafe { libc::closedir(self.0) };
            }
        }
        let _close = Close(dir);
        unsafe { libc::rewinddir(dir) };
        let mut names = Vec::new();
        loop {
            let ent = unsafe { libc::readdir(dir) };
            if ent.is_null() {
                break;
            }
            let name = unsafe { std::ffi::CStr::from_ptr((*ent).d_name.as_ptr()) }
                .to_str()
                .map_err(|_| OutputError::UnsafePath)?;
            if name == "." || name == ".." {
                continue;
            }
            if names.len() >= 3 * 4096 {
                return Err(OutputError::Quota);
            }
            names.push(name.to_owned());
        }
        Ok(names)
    }
    #[cfg(not(unix))]
    fn names(&self) -> Result<Vec<String>, OutputError> {
        Err(OutputError::Unsupported)
    }
    #[cfg(unix)]
    fn unlink(&self, name: &str) -> Result<(), OutputError> {
        use std::os::fd::AsRawFd;
        let name = std::ffi::CString::new(name).map_err(|_| OutputError::UnsafePath)?;
        if unsafe { libc::unlinkat(self.file.as_raw_fd(), name.as_ptr(), 0) } != 0 {
            let e = std::io::Error::last_os_error();
            if e.kind() != std::io::ErrorKind::NotFound {
                return Err(e.into());
            }
        }
        Ok(())
    }
    #[cfg(not(unix))]
    fn unlink(&self, _: &str) -> Result<(), OutputError> {
        Err(OutputError::Unsupported)
    }
    /// Move the existing metadata inode into the recovery namespace. The
    /// caller holds the store lock and has checked both names and the raw inode.
    #[cfg(unix)]
    fn retire(&self, id: &str) -> Result<(), OutputError> {
        use std::os::fd::AsRawFd;
        let source = std::ffi::CString::new(format!("{id}.json")).unwrap();
        let destination = std::ffi::CString::new(format!("{id}.cleanup")).unwrap();
        if unsafe {
            libc::renameat(
                self.file.as_raw_fd(),
                source.as_ptr(),
                self.file.as_raw_fd(),
                destination.as_ptr(),
            )
        } != 0
        {
            return Err(std::io::Error::last_os_error().into());
        }
        // No payload is unlinked before the recovery record is durable.
        self.file.sync_all()?;
        Ok(())
    }
    #[cfg(not(unix))]
    fn retire(&self, _: &str) -> Result<(), OutputError> {
        Err(OutputError::Unsupported)
    }
    fn write_metadata(&self, reference: &ArtifactRef) -> Result<(), OutputError> {
        let encoded = serde_json::to_vec(reference)?;
        if encoded.len() > MAX_METADATA_BYTES {
            return Err(OutputError::Quota);
        }
        let temporary = format!(
            "{}.{}.tmp",
            reference.artifact_id,
            NEXT_ARTIFACT.fetch_add(1, Ordering::Relaxed)
        );
        let result = (|| {
            let mut file = self.open_file(&temporary, true)?;
            file.write_all(&encoded)?;
            file.sync_all()?;
            #[cfg(unix)]
            {
                use std::os::fd::AsRawFd;
                let src = std::ffi::CString::new(temporary.as_str()).unwrap();
                let dst =
                    std::ffi::CString::new(format!("{}.json", reference.artifact_id)).unwrap();
                if unsafe {
                    libc::renameat(
                        self.file.as_raw_fd(),
                        src.as_ptr(),
                        self.file.as_raw_fd(),
                        dst.as_ptr(),
                    )
                } != 0
                {
                    return Err(std::io::Error::last_os_error().into());
                }
            }
            self.file.sync_all()?;
            Ok(())
        })();
        if result.is_err() {
            let _ = self.unlink(&temporary);
        }
        result
    }
}

#[derive(Debug, Default)]
struct StoreState {
    used: u64,
    files: usize,
    active: BTreeSet<String>,
    blocked: bool,
}
#[derive(Debug, Clone)]
pub struct OutputArtifactStore {
    dir: Arc<PrivateDirectory>,
    state: Arc<Mutex<StoreState>>,
    limits: OutputLimits,
}
impl OutputArtifactStore {
    /// `root` is chosen by the host, with an existing trusted parent. The
    /// dedicated directory must be private and cannot be a symlink. All child
    /// operations use its open descriptor and single-component generated IDs.
    pub fn open(root: impl AsRef<Path>, limits: OutputLimits) -> Result<Self, OutputError> {
        limits.validate()?;
        let dir = Arc::new(PrivateDirectory::open(root.as_ref())?);
        let mut state = StoreState::default();
        let names = dir.names()?;
        if names.len() > limits.max_files.saturating_mul(3) {
            return Err(OutputError::Quota);
        }
        let raw_ids: BTreeSet<_> = names
            .iter()
            .filter_map(|name| name.strip_suffix(".raw"))
            .map(str::to_owned)
            .collect();
        for name in names {
            let file = dir.open_file(&name, false)?;
            let bytes = file.metadata()?.len();
            if name.ends_with(".raw") {
                state.used = state.used.checked_add(bytes).ok_or(OutputError::Quota)?;
                state.files += 1;
            } else if (name.ends_with(".json")
                || name.ends_with(".cleanup")
                || name.ends_with(".tmp"))
                && bytes <= MAX_METADATA_BYTES as u64
            {
                if name.ends_with(".tmp")
                    || name
                        .strip_suffix(".json")
                        .or_else(|| name.strip_suffix(".cleanup"))
                        .is_some_and(|id| !raw_ids.contains(id))
                {
                    state.files += 1;
                }
            } else {
                return Err(OutputError::UnsafePath);
            }
        }
        if state.used > limits.max_total_bytes || state.files > limits.max_files {
            return Err(OutputError::Quota);
        }
        Ok(Self {
            dir,
            state: Arc::new(Mutex::new(state)),
            limits,
        })
    }
    pub fn progress_queue(&self) -> OutputProgressQueue {
        OutputProgressQueue {
            state: Arc::new(Mutex::new(ProgressState::default())),
            capacity: self.limits.progress_capacity,
        }
    }
    pub fn begin(
        &self,
        session_id: &str,
        call_id: &str,
        stream: OutputStream,
        now_ms: u64,
        progress: OutputProgressQueue,
    ) -> Result<ArtifactWriter, OutputError> {
        valid_identity(session_id)?;
        valid_identity(call_id)?;
        let nonce = NEXT_ARTIFACT.fetch_add(1, Ordering::Relaxed);
        let id = format!(
            "{:x}",
            Sha256::digest(
                format!(
                    "zenpi-raw-v1:{session_id}:{call_id}:{stream:?}:{now_ms}:{}:{nonce}",
                    std::process::id()
                )
                .as_bytes()
            )
        );
        let reference = ArtifactRef {
            version: 1,
            artifact_id: id.clone(),
            session_id: session_id.into(),
            call_id: call_id.into(),
            stream,
            created_at_ms: now_ms,
            expires_at_ms: now_ms
                .checked_add(self.limits.ttl_ms)
                .ok_or(OutputError::Quota)?,
            bytes_observed: 0,
            bytes_stored: 0,
            sha256: None,
            finalized: false,
            complete: false,
            truncated: false,
            failure: None,
        };
        let mut state = self.state.lock().unwrap();
        if state.blocked {
            return Err(OutputError::Interrupted);
        }
        if state.files >= self.limits.max_files
            || state.used.saturating_add(self.limits.max_file_bytes) > self.limits.max_total_bytes
        {
            return Err(OutputError::Quota);
        }
        let file = match self.dir.open_file(&format!("{id}.raw"), true) {
            Ok(file) => file,
            Err(error) => {
                state.blocked = true;
                return Err(error);
            }
        };
        if let Err(e) = self.dir.write_metadata(&reference) {
            state.blocked = true;
            let _ = self.dir.unlink(&format!("{id}.raw"));
            return Err(e);
        }
        state.files += 1;
        state.used += self.limits.max_file_bytes;
        state.active.insert(id);
        Ok(ArtifactWriter {
            store: self.clone(),
            file: Some(file),
            reference,
            hasher: Sha256::new(),
            tail: VecDeque::new(),
            redactor: redaction::OutputRedactor::default(),
            progress,
            closed: false,
            terminal: None,
        })
    }
    fn metadata(&self, id: &str) -> Result<ArtifactRef, OutputError> {
        self.metadata_suffix(id, "json")
    }
    fn metadata_suffix(&self, id: &str, suffix: &str) -> Result<ArtifactRef, OutputError> {
        valid_id(id)?;
        let file = self.dir.open_file(&format!("{id}.{suffix}"), false)?;
        let mut bytes = Vec::new();
        file.take((MAX_METADATA_BYTES + 1) as u64)
            .read_to_end(&mut bytes)?;
        if bytes.len() > MAX_METADATA_BYTES {
            return Err(OutputError::Integrity);
        }
        let r: ArtifactRef = serde_json::from_slice(&bytes)?;
        if r.version != 1
            || r.artifact_id != id
            || r.bytes_stored > self.limits.max_file_bytes
            || r.bytes_stored > r.bytes_observed
            || r.expires_at_ms < r.created_at_ms
            || r.expires_at_ms - r.created_at_ms > 7 * 24 * 60 * 60 * 1000
            || r.complete
                && (!r.finalized
                    || r.failure.is_some()
                    || r.truncated
                    || r.bytes_observed != r.bytes_stored)
        {
            return Err(OutputError::Integrity);
        }
        valid_identity(&r.session_id)?;
        valid_identity(&r.call_id)?;
        Ok(r)
    }
    pub fn inspect(
        &self,
        reference: &ArtifactRef,
        now_ms: u64,
    ) -> Result<ArtifactRef, OutputError> {
        let actual = self.checked_reference(reference, now_ms)?;
        self.verify(&actual)?;
        Ok(actual)
    }

    fn checked_reference(
        &self,
        reference: &ArtifactRef,
        now_ms: u64,
    ) -> Result<ArtifactRef, OutputError> {
        valid_id(&reference.artifact_id)?;
        if now_ms >= reference.expires_at_ms {
            return Err(OutputError::Expired);
        }
        let actual = self.metadata(&reference.artifact_id)?;
        if !actual.finalized {
            return Err(OutputError::Interrupted);
        }
        if actual.session_id != reference.session_id
            || actual.call_id != reference.call_id
            || actual.stream != reference.stream
            || actual.created_at_ms != reference.created_at_ms
            || actual.expires_at_ms != reference.expires_at_ms
        {
            return Err(OutputError::Integrity);
        }
        Ok(actual)
    }
    fn verify(&self, reference: &ArtifactRef) -> Result<File, OutputError> {
        let mut file = self
            .dir
            .open_file(&format!("{}.raw", reference.artifact_id), false)?;
        if file.metadata()?.len() != reference.bytes_stored {
            return Err(OutputError::Integrity);
        }
        let mut hash = Sha256::new();
        let mut buffer = [0u8; 8192];
        let mut count = 0u64;
        loop {
            let n = file.read(&mut buffer)?;
            if n == 0 {
                break;
            }
            count += n as u64;
            if count > reference.bytes_stored {
                return Err(OutputError::Integrity);
            }
            hash.update(&buffer[..n]);
        }
        if reference.sha256.as_deref() != Some(format!("{:x}", hash.finalize()).as_str()) {
            return Err(OutputError::Integrity);
        }
        file.seek(SeekFrom::Start(0))?;
        Ok(file)
    }
    /// Host-only raw read. Transport adapters must apply the credential policy
    /// before sending bytes/text to a model or public renderer.
    pub fn read_range(
        &self,
        reference: &ArtifactRef,
        offset: u64,
        length: usize,
        now_ms: u64,
    ) -> Result<Vec<u8>, OutputError> {
        self.read_range_inner(reference, offset, length, now_ms, false, &|| false)
    }
    /// Credential-safe bytes in original raw coordinates. Masking scans from
    /// stream start before the requested range is cut, including credentials
    /// beginning in a previous chunk or before `offset`. The host must still
    /// authorize the reference against its current session/call ownership.
    pub fn read_redacted_range(
        &self,
        reference: &ArtifactRef,
        offset: u64,
        length: usize,
        now_ms: u64,
    ) -> Result<Vec<u8>, OutputError> {
        self.read_range_inner(reference, offset, length, now_ms, true, &|| false)
    }
    fn read_range_inner(
        &self,
        reference: &ArtifactRef,
        offset: u64,
        length: usize,
        now_ms: u64,
        redact: bool,
        cancelled: &dyn Fn() -> bool,
    ) -> Result<Vec<u8>, OutputError> {
        if length > self.limits.read_bytes {
            return Err(OutputError::Quota);
        }
        let actual = self.checked_reference(reference, now_ms)?;
        // Journal authority includes the complete terminal hash/length/status,
        // not just names. This check and the ensuing full hash pass protect the
        // very bytes returned by either reader from metadata/raw replacement.
        if &actual != reference {
            return Err(OutputError::Integrity);
        }

        if offset > actual.bytes_stored {
            return Err(OutputError::Invalid(
                "range starts after stored output".into(),
            ));
        }
        let mut file = self
            .dir
            .open_file(&format!("{}.raw", actual.artifact_id), false)?;
        if file.metadata()?.len() != actual.bytes_stored {
            return Err(OutputError::Integrity);
        }
        let mut hash = Sha256::new();
        let mut bytes = Vec::with_capacity(length);
        let mut buffer = [0u8; 8192];
        let mut position = 0u64;
        let mut display_position = 0u64;
        let mut redactor = redact.then(redaction::OutputRedactor::default);
        let range_end = offset
            .saturating_add(length as u64)
            .min(actual.bytes_stored);
        loop {
            // Even a tiny range authenticates the entire artifact. Keep that
            // scan cancellable between bounded read/redaction chunks.
            if cancelled() {
                return Err(OutputError::Cancelled);
            }
            let n = file.read(&mut buffer)?;
            if n == 0 {
                break;
            }
            let end = position + n as u64;
            if end > actual.bytes_stored {
                return Err(OutputError::Integrity);
            }
            hash.update(&buffer[..n]);
            if let Some(redactor) = &mut redactor {
                let safe = redactor.feed(&buffer[..n]);
                collect_range(&mut bytes, &mut display_position, offset, range_end, &safe);
            } else {
                collect_range(
                    &mut bytes,
                    &mut display_position,
                    offset,
                    range_end,
                    &buffer[..n],
                );
            }
            position = end;
        }
        if let Some(redactor) = &mut redactor {
            let safe = redactor.finish(actual.complete);
            collect_range(&mut bytes, &mut display_position, offset, range_end, &safe);
        }
        if display_position != position
            || position != actual.bytes_stored
            || actual.sha256.as_deref() != Some(format!("{:x}", hash.finalize()).as_str())
        {
            return Err(OutputError::Integrity);
        }
        Ok(bytes)
    }
    /// Explicit host session cleanup. Active writers are never deleted. Other
    /// session artifacts and unrecognized entries remain untouched.
    pub fn cleanup_call(&self, session_id: &str, call_id: &str) -> Result<usize, OutputError> {
        valid_identity(session_id)?;
        valid_identity(call_id)?;
        self.cleanup(|r| r.session_id == session_id && r.call_id == call_id)
    }

    pub fn cleanup_session(&self, session_id: &str) -> Result<usize, OutputError> {
        valid_identity(session_id)?;
        self.cleanup(|r| r.session_id == session_id)
    }
    pub fn cleanup_expired(&self, now_ms: u64) -> Result<usize, OutputError> {
        let removed = self.cleanup(|r| now_ms >= r.expires_at_ms)?;
        // A process can exit between raw creation and metadata rename. Only
        // generated orphan names older than TTL are eligible for cleanup.
        let mut state = self.state.lock().unwrap();
        let names: BTreeSet<_> = self.dir.names()?.into_iter().collect();
        let mut orphans = 0;
        for name in &names {
            let is_raw = name.ends_with(".raw");
            let Some(id) = name.split('.').next() else {
                continue;
            };
            if valid_id(id).is_err() || state.active.contains(id) {
                continue;
            }
            let temporary = name.strip_suffix(".tmp").is_some_and(|stem| {
                stem.strip_prefix(&format!("{id}.")).is_some_and(|counter| {
                    !counter.is_empty() && counter.bytes().all(|b| b.is_ascii_digit())
                })
            });
            let orphan = is_raw
                && !names.contains(&format!("{id}.json"))
                && !names.contains(&format!("{id}.cleanup"));
            if !temporary && !orphan {
                continue;
            }
            let metadata = self.dir.open_file(name, false)?.metadata()?;
            let modified = metadata
                .modified()?
                .duration_since(std::time::UNIX_EPOCH)
                .map_err(|_| OutputError::Integrity)?
                .as_millis();
            if modified.saturating_add(self.limits.ttl_ms as u128) > now_ms as u128 {
                continue;
            }
            self.dir.unlink(name)?;
            if is_raw {
                state.used = state.used.saturating_sub(metadata.len());
            }
            state.files = state.files.saturating_sub(1);
            orphans += 1;
        }
        self.dir.file.sync_all()?;
        Ok(removed + orphans)
    }
    pub(crate) fn retirement_ids(&self) -> Result<BTreeSet<String>, OutputError> {
        let _state = self.state.lock().unwrap();
        let mut ids = BTreeSet::new();
        for name in self.dir.names()? {
            if let Some(id) = name.strip_suffix(".cleanup") {
                valid_id(id)?;
                if ids.len() >= self.limits.max_files {
                    return Err(OutputError::Quota);
                }
                ids.insert(id.to_owned());
            }
        }
        Ok(ids)
    }
    /// Bound the durable intent to the currently selected artifact identities.
    /// Unacknowledged retirements require their original durable intent;
    /// a new intent must never adopt them as fresh successful deletions.
    pub fn cleanup_plan(
        &self,
        session_id: &str,
        call_id: Option<&str>,
    ) -> Result<Vec<ArtifactRef>, OutputError> {
        valid_identity(session_id)?;
        if let Some(call) = call_id {
            valid_identity(call)?;
        }
        let state = self.state.lock().unwrap();
        let names: BTreeSet<_> = self.dir.names()?.into_iter().collect();
        let mut plan = Vec::new();
        for name in &names {
            let (id, suffix) = if let Some(id) = name.strip_suffix(".cleanup") {
                (id, "cleanup")
            } else if let Some(id) = name.strip_suffix(".json") {
                (id, "json")
            } else {
                continue;
            };
            let reference = self.metadata_suffix(id, suffix)?;
            if reference.session_id != session_id
                || call_id.is_some_and(|call| reference.call_id != call)
                || state.active.contains(id)
            {
                continue;
            }
            if names.contains(&format!("{id}.json")) && names.contains(&format!("{id}.cleanup")) {
                return Err(OutputError::Integrity);
            }
            if suffix == "cleanup" {
                return Err(OutputError::Interrupted);
            }
            if plan.len() >= self.limits.max_files {
                return Err(OutputError::Quota);
            }
            plan.push(reference);
        }
        Ok(plan)
    }

    /// Replay the journal's exact durable intent. Each returned ID has a
    /// synced retirement record and no raw payload. Missing both names or a
    /// changed identity is an error, never an inferred successful deletion.
    pub fn cleanup_receipted(
        &self,
        session_id: &str,
        call_id: Option<&str>,
        plan: &[ArtifactRef],
    ) -> Result<Vec<String>, OutputError> {
        valid_identity(session_id)?;
        if let Some(call) = call_id {
            valid_identity(call)?;
        }
        if plan.len() > self.limits.max_files {
            return Err(OutputError::Quota);
        }
        let mut state = self.state.lock().unwrap();
        let names: BTreeSet<_> = self.dir.names()?.into_iter().collect();
        let mut removed = Vec::new();
        let mut seen = BTreeSet::new();
        for expected in plan {
            let id = &expected.artifact_id;
            valid_id(id)?;
            if expected.session_id != session_id
                || call_id.is_some_and(|call| expected.call_id != call)
                || !seen.insert(id)
            {
                return Err(OutputError::Integrity);
            }
            if state.active.contains(id) {
                return Err(OutputError::Busy);
            }
            let retired = names.contains(&format!("{id}.cleanup"));
            let live = names.contains(&format!("{id}.json"));
            if retired && live {
                return Err(OutputError::Integrity);
            }
            if !retired && !live {
                return Err(OutputError::Interrupted);
            }
            let reference = self.metadata_suffix(id, if retired { "cleanup" } else { "json" })?;
            if &reference != expected {
                return Err(OutputError::Integrity);
            }
            let size = match self.dir.open_file(&format!("{id}.raw"), false) {
                Ok(file) => {
                    // Finalized bytes must still be the intended payload.
                    // Interrupted writers have no final hash; preserve their
                    // actual-byte accounting and inode checks instead.
                    if reference.finalized {
                        self.verify(&reference)?;
                    }
                    file.metadata()?.len()
                }
                Err(OutputError::Missing) if retired => 0,
                Err(error) => return Err(error),
            };
            if !retired {
                self.dir.retire(id)?;
            }
            self.dir.file.sync_all()?;
            self.dir.unlink(&format!("{id}.raw"))?;
            state.used = state.used.saturating_sub(size);
            // The retirement record remains charged until receipt GC.
            self.dir.file.sync_all()?;
            removed.push(id.to_owned());
        }
        Ok(removed)
    }

    /// Garbage collect only retirement records already present in a durable
    /// session receipt. Failure leaves those records for the next retry.
    pub fn acknowledge_cleanup(
        &self,
        session_id: &str,
        receipted: &BTreeSet<String>,
    ) -> Result<(), OutputError> {
        valid_identity(session_id)?;
        let mut state = self.state.lock().unwrap();
        for name in self.dir.names()? {
            let Some(id) = name.strip_suffix(".cleanup") else {
                continue;
            };
            if !receipted.contains(id) {
                continue;
            }
            let reference = match self.metadata_suffix(id, "cleanup") {
                Ok(reference) => reference,
                Err(OutputError::Missing) => continue,
                Err(error) => return Err(error),
            };
            if reference.session_id != session_id || state.active.contains(id) {
                return Err(OutputError::Integrity);
            }
            // A receipt cannot authorize deleting a new/conflicting payload.
            for suffix in ["raw", "json"] {
                match self.dir.open_file(&format!("{id}.{suffix}"), false) {
                    Err(OutputError::Missing) => {}
                    Ok(_) => return Err(OutputError::Integrity),
                    Err(error) => return Err(error),
                }
            }
            self.dir.unlink(&format!("{id}.cleanup"))?;
            state.files = state.files.saturating_sub(1);
        }
        self.dir.file.sync_all()?;
        Ok(())
    }
    fn cleanup(&self, select: impl Fn(&ArtifactRef) -> bool) -> Result<usize, OutputError> {
        let mut state = self.state.lock().unwrap();
        let mut count = 0;
        for name in self.dir.names()? {
            let Some(id) = name.strip_suffix(".json") else {
                continue;
            };
            let r = self.metadata(id)?;
            if !select(&r) || state.active.contains(id) {
                continue;
            }
            // Include interrupted output's actual reserved-on-disk bytes.
            let size = match self.dir.open_file(&format!("{id}.raw"), false) {
                Ok(f) => f.metadata()?.len(),
                Err(OutputError::Missing) => 0,
                Err(e) => return Err(e),
            };
            self.dir.unlink(&format!("{id}.raw"))?;
            self.dir.unlink(&name)?;
            state.used = state.used.saturating_sub(size);
            state.files = state.files.saturating_sub(1);
            count += 1;
        }
        self.dir.file.sync_all()?;
        Ok(count)
    }
}
fn valid_identity(s: &str) -> Result<(), OutputError> {
    if s.is_empty()
        || s.len() > 128
        || !s
            .bytes()
            .all(|b| b.is_ascii_alphanumeric() || b == b'-' || b == b'_')
    {
        Err(OutputError::Invalid("invalid session/call identity".into()))
    } else {
        Ok(())
    }
}
fn valid_id(s: &str) -> Result<(), OutputError> {
    if s.len() != 64
        || !s
            .bytes()
            .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
    {
        Err(OutputError::UnsafePath)
    } else {
        Ok(())
    }
}

#[derive(Debug, Clone)]
struct CaptureTerminal {
    references: Arc<Mutex<Vec<ArtifactRef>>>,
    errors: Arc<Mutex<Vec<String>>>,
}

#[derive(Debug)]
pub struct ArtifactWriter {
    store: OutputArtifactStore,
    file: Option<File>,
    reference: ArtifactRef,
    hasher: Sha256,
    tail: VecDeque<u8>,
    redactor: redaction::OutputRedactor,
    progress: OutputProgressQueue,
    closed: bool,
    terminal: Option<CaptureTerminal>,
}
impl ArtifactWriter {
    pub fn reference(&self) -> &ArtifactRef {
        &self.reference
    }
    pub fn append(&mut self, bytes: &[u8]) -> Result<(), OutputError> {
        if self.closed {
            return Err(OutputError::Closed);
        }
        self.reference.bytes_observed = self
            .reference
            .bytes_observed
            .checked_add(bytes.len() as u64)
            .ok_or(OutputError::Quota)?;
        for chunk in bytes.chunks(4096) {
            let safe = self.redactor.feed(chunk);
            self.append_view(&safe);
        }
        let remaining = self
            .store
            .limits
            .max_file_bytes
            .saturating_sub(self.reference.bytes_stored);
        let admitted = remaining.min(bytes.len() as u64) as usize;
        let mut failure = None;
        if self.reference.failure.is_none() {
            let mut written = 0;
            while written < admitted {
                match self.file.as_mut().unwrap().write(&bytes[written..admitted]) {
                    Ok(0) => {
                        failure = Some(OutputError::Io(std::io::Error::new(
                            std::io::ErrorKind::WriteZero,
                            "raw output write returned zero",
                        )));
                        break;
                    }
                    Ok(n) => {
                        self.hasher.update(&bytes[written..written + n]);
                        written += n;
                        self.reference.bytes_stored += n as u64;
                    }
                    Err(e) if e.kind() == std::io::ErrorKind::Interrupted => {}
                    Err(e) => {
                        failure = Some(OutputError::Io(e));
                        break;
                    }
                }
            }
            if admitted < bytes.len() && failure.is_none() {
                failure = Some(OutputError::Quota);
            }
        }
        if let Some(error) = &failure {
            self.reference.failure = Some(error.to_string());
        }
        self.reference.truncated = self.reference.bytes_stored < self.reference.bytes_observed;
        self.progress.publish(OutputProgress {
            call_id: self.reference.call_id.clone(),
            stream: self.reference.stream,
            snapshot: self.snapshot(),
            dropped_updates: 0,
        });
        match failure {
            Some(e) => Err(e),
            None => Ok(()),
        }
    }
    fn append_view(&mut self, bytes: &[u8]) {
        let cap = self.store.limits.view_bytes + 4;
        if bytes.len() >= cap {
            self.tail.clear();
            self.tail.extend(&bytes[bytes.len() - cap..]);
        } else {
            self.tail.extend(bytes);
            while self.tail.len() > cap {
                self.tail.pop_front();
            }
        }
    }
    pub fn snapshot(&self) -> OutputSnapshot {
        let raw: Vec<_> = self.tail.iter().copied().collect();
        let mut start = raw.len().saturating_sub(self.store.limits.view_bytes);
        while start < raw.len() && (raw[start] & 0xc0) == 0x80 {
            start += 1;
        }
        let mut end = raw.len();
        if let Err(e) = std::str::from_utf8(&raw[start..end]) {
            if e.error_len().is_none() {
                end = start + e.valid_up_to();
            } else {
                // Keep earlier invalid bytes visible as replacements, but
                // withhold a split UTF-8 suffix until its next chunk arrives.
                for trim in 1..=3.min(end - start) {
                    let pos = end - trim;
                    if raw[pos] & 0xc0 != 0x80
                        && std::str::from_utf8(&raw[pos..end])
                            .is_err_and(|e| e.error_len().is_none())
                    {
                        end = pos;
                        break;
                    }
                }
            }
        }
        let text = String::from_utf8_lossy(&raw[start..end]);
        let lossy = matches!(text, std::borrow::Cow::Owned(_));
        let base = self.redactor.emitted() - raw.len() as u64;
        let mut text = text.into_owned();
        if text.len() > self.store.limits.view_bytes {
            let mut end = self.store.limits.view_bytes;
            while !text.is_char_boundary(end) {
                end -= 1;
            }
            text.truncate(end);
        }
        OutputSnapshot {
            text,
            display_start: base + start as u64,
            display_end: base + end as u64,
            bytes_observed: self.reference.bytes_observed,
            truncated: base + start as u64 > 0
                || base + (end as u64) < self.reference.bytes_observed,
            lossy,
        }
    }
    /// Finalize only after command cleanup/reap and pipe-reader join. False
    /// preserves and verifies the obtained prefix while explicitly incomplete.
    pub fn finish(&mut self, complete: bool) -> Result<ArtifactRef, OutputError> {
        if self.closed {
            return Err(OutputError::Closed);
        }
        let safe = self.redactor.finish(complete);
        self.append_view(&safe);
        self.progress.publish(OutputProgress {
            call_id: self.reference.call_id.clone(),
            stream: self.reference.stream,
            snapshot: self.snapshot(),
            dropped_updates: 0,
        });
        self.closed = true;
        let sync = self.file.as_ref().unwrap().sync_all();
        if let Err(e) = sync {
            self.reference.failure = Some(e.to_string());
        }
        self.reference.sha256 = Some(format!("{:x}", self.hasher.clone().finalize()));
        self.reference.finalized = true;
        self.reference.complete =
            complete && self.reference.failure.is_none() && !self.reference.truncated;
        if let Err(e) = self.store.verify(&self.reference) {
            self.reference.failure = Some(e.to_string());
            self.reference.complete = false;
        }
        let result = self.store.dir.write_metadata(&self.reference);
        if let Err(error) = &result {
            self.store.state.lock().unwrap().blocked = true;
            self.reference.complete = false;
            self.reference.failure = Some(error.to_string());
        }
        self.release_reservation();
        // Keep the terminal identity even when spawning, the second stream,
        // or metadata publication fails. Drop uses this same finalization path.
        if let Some(terminal) = self.terminal.take() {
            terminal
                .references
                .lock()
                .unwrap()
                .push(self.reference.clone());
            if let Some(error) = &self.reference.failure {
                terminal.errors.lock().unwrap().push(error.clone());
            }
        }
        result?;
        Ok(self.reference.clone())
    }
    fn release_reservation(&mut self) {
        let mut state = self.store.state.lock().unwrap();
        if state.active.remove(&self.reference.artifact_id) {
            state.used = state
                .used
                .saturating_sub(self.store.limits.max_file_bytes - self.reference.bytes_stored);
        }
        self.file.take();
    }
}
impl Drop for ArtifactWriter {
    fn drop(&mut self) {
        if !self.closed {
            let _ = self.finish(false);
        }
    }
}

/// One host-authorized command capture. It can be attached to a cloned
/// ToolContext for exactly one call; reusing it never opens a second command.
#[derive(Debug, Clone)]
pub struct CommandOutputCapture {
    store: OutputArtifactStore,
    session_id: String,
    call_id: String,
    now_ms: u64,
    progress: OutputProgressQueue,
    started: Arc<std::sync::atomic::AtomicBool>,
    finalized: Arc<Mutex<Vec<ArtifactRef>>>,
    errors: Arc<Mutex<Vec<String>>>,
}
impl CommandOutputCapture {
    pub fn new(
        store: OutputArtifactStore,
        session_id: &str,
        call_id: &str,
        now_ms: u64,
    ) -> Result<Self, OutputError> {
        valid_identity(session_id)?;
        valid_identity(call_id)?;
        let progress = store.progress_queue();
        Ok(Self {
            store,
            session_id: session_id.into(),
            call_id: call_id.into(),
            now_ms,
            progress,
            started: Arc::new(std::sync::atomic::AtomicBool::new(false)),
            finalized: Arc::new(Mutex::new(Vec::new())),
            errors: Arc::new(Mutex::new(Vec::new())),
        })
    }
    pub fn call_id(&self) -> &str {
        &self.call_id
    }
    pub fn progress(&self) -> OutputProgressQueue {
        self.progress.clone()
    }
    pub fn errors(&self) -> Vec<String> {
        self.errors.lock().unwrap().clone()
    }
    pub(crate) fn record_error(&self, error: String) {
        self.errors.lock().unwrap().push(error)
    }
    pub fn artifacts(&self) -> Vec<ArtifactRef> {
        self.finalized.lock().unwrap().clone()
    }
    pub fn report(&self) -> CaptureReport {
        CaptureReport {
            artifacts: self.artifacts(),
            errors: self.errors(),
        }
    }
    pub(crate) fn begin_streams(&self) -> Result<(ArtifactWriter, ArtifactWriter), OutputError> {
        if self.started.swap(true, Ordering::SeqCst) {
            return Err(OutputError::Closed);
        }
        let mut stdout = self.store.begin(
            &self.session_id,
            &self.call_id,
            OutputStream::Stdout,
            self.now_ms,
            self.progress.clone(),
        )?;
        stdout.terminal = Some(CaptureTerminal {
            references: self.finalized.clone(),
            errors: self.errors.clone(),
        });
        let mut stderr = self.store.begin(
            &self.session_id,
            &self.call_id,
            OutputStream::Stderr,
            self.now_ms,
            self.progress.clone(),
        )?;
        stderr.terminal = stdout.terminal.clone();
        Ok((stdout, stderr))
    }
    pub(crate) fn finish_stream(
        &self,
        writer: &mut ArtifactWriter,
        complete: bool,
    ) -> Result<(), OutputError> {
        writer.finish(complete).map(|_| ())
    }
    pub(crate) fn close(&self) {
        self.progress.close();
    }
}

#[cfg(all(test, unix))]
mod tests {
    use super::*;
    #[test]
    fn failed_metadata_publication_keeps_terminal_reference_and_error() {
        let root = tempfile::tempdir().unwrap();
        let path = root.path().join("raw");
        let store = OutputArtifactStore::open(&path, OutputLimits::default()).unwrap();
        let capture = CommandOutputCapture::new(store, "s", "c", 100).unwrap();
        let (mut stdout, stderr) = capture.begin_streams().unwrap();
        stdout.append(b"preserved").unwrap();
        let id = stdout.reference.artifact_id.clone();
        let metadata = path.join(format!("{id}.json"));
        fs::remove_file(&metadata).unwrap();
        fs::create_dir(&metadata).unwrap();
        assert!(capture.finish_stream(&mut stdout, true).is_err());
        let refs = capture.artifacts();
        assert_eq!(refs.len(), 1);
        assert_eq!(refs[0].artifact_id, id);
        assert!(refs[0].finalized && !refs[0].complete);
        assert_eq!(refs[0].bytes_stored, 9);
        assert!(refs[0].failure.is_some());
        assert!(!capture.errors().is_empty());
        drop(stdout);
        assert_eq!(capture.artifacts().len(), 1);
        drop(stderr);
        assert_eq!(capture.artifacts().len(), 2);
    }

    #[test]
    fn failed_spill_write_preserves_error_and_never_claims_complete() {
        let root = tempfile::tempdir().unwrap();
        let store =
            OutputArtifactStore::open(root.path().join("raw"), OutputLimits::default()).unwrap();
        let mut writer = store
            .begin("s", "c", OutputStream::Stdout, 100, store.progress_queue())
            .unwrap();
        // Exercise a real failed write syscall without filling the user's disk.
        writer.file = Some(
            store
                .dir
                .open_file(&format!("{}.raw", writer.reference.artifact_id), false)
                .unwrap(),
        );
        assert!(matches!(
            writer.append(b"cannot-write"),
            Err(OutputError::Io(_))
        ));
        let reference = writer.finish(true).unwrap();
        assert!(!reference.complete);
        assert!(reference.failure.is_some());
        assert_eq!(reference.bytes_stored, 0);
        assert_eq!(reference.bytes_observed, 12);
    }
}

fn collect_range(target: &mut Vec<u8>, position: &mut u64, start: u64, end: u64, bytes: &[u8]) {
    let next = position.saturating_add(bytes.len() as u64);
    let from = start.max(*position);
    let to = end.min(next);
    if from < to {
        target.extend_from_slice(&bytes[(from - *position) as usize..(to - *position) as usize]);
    }
    *position = next;
}

/// Public range requests contain identities and raw coordinates, never paths
/// or caller-supplied authority. The host resolves the reference from its journal.
pub const MAX_PUBLIC_OUTPUT_READ_BYTES: usize = 8 * 1024;
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct OutputReadRequest {
    pub artifact_id: String,
    pub call_id: String,
    pub offset: u64,
    pub length: usize,
}
impl OutputReadRequest {
    pub fn validate(&self) -> Result<(), OutputError> {
        valid_id(&self.artifact_id)?;
        valid_identity(&self.call_id)?;
        if self.length == 0 || self.length > MAX_PUBLIC_OUTPUT_READ_BYTES {
            return Err(OutputError::Invalid(
                "read length must be between 1 and 8192 raw bytes".into(),
            ));
        }
        self.offset
            .checked_add(self.length as u64)
            .ok_or_else(|| OutputError::Invalid("output range overflow".into()))?;
        Ok(())
    }
}
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct OutputReadReply {
    pub artifact_id: String,
    pub call_id: String,
    pub stream: OutputStream,
    pub raw_start: u64,
    pub raw_end: u64,
    pub bytes_stored: u64,
    pub bytes_observed: u64,
    pub eof: bool,
    pub text: String,
    pub lossy: bool,
    pub redacted: bool,
    pub complete: bool,
    pub truncated: bool,
    pub failure: Option<String>,
}

/// One sealed current-session reference supplied to a single model tool call.
#[derive(Debug, Clone)]
pub(crate) struct OutputReadAccess {
    store: OutputArtifactStore,
    reference: ArtifactRef,
}
impl OutputReadAccess {
    pub(crate) fn new(store: OutputArtifactStore, reference: ArtifactRef) -> Self {
        Self { store, reference }
    }
    pub(crate) fn read(
        &self,
        request: &OutputReadRequest,
        now_ms: u64,
        cancelled: &dyn Fn() -> bool,
    ) -> Result<OutputReadReply, OutputError> {
        request.validate()?;
        if cancelled() {
            return Err(OutputError::Cancelled);
        }
        if request.artifact_id != self.reference.artifact_id
            || request.call_id != self.reference.call_id
        {
            return Err(OutputError::Integrity);
        }
        let bytes = self.store.read_range_inner(
            &self.reference,
            request.offset,
            request.length,
            now_ms,
            true,
            cancelled,
        )?;
        if cancelled() {
            return Err(OutputError::Cancelled);
        }
        let lossy = std::str::from_utf8(&bytes).is_err();
        let raw_end = request.offset + bytes.len() as u64;
        Ok(OutputReadReply {
            artifact_id: self.reference.artifact_id.clone(),
            call_id: self.reference.call_id.clone(),
            stream: self.reference.stream,
            raw_start: request.offset,
            raw_end,
            bytes_stored: self.reference.bytes_stored,
            bytes_observed: self.reference.bytes_observed,
            eof: raw_end == self.reference.bytes_stored,
            text: String::from_utf8_lossy(&bytes).into_owned(),
            lossy,
            redacted: true,
            complete: self.reference.complete,
            truncated: self.reference.truncated,
            failure: self.reference.failure.clone(),
        })
    }
}

impl OutputError {
    pub fn code(&self) -> &'static str {
        match self {
            Self::Expired => "output_expired",
            Self::Missing => "output_missing",
            Self::Interrupted => "output_interrupted",
            Self::Integrity => "output_integrity",
            Self::UnsafePath => "output_unsafe_path",
            Self::Busy => "output_busy",
            Self::Quota => "output_quota",
            Self::Closed => "output_closed",
            Self::Cancelled => "output_cancelled",
            Self::Unsupported => "output_unsupported",
            Self::Io(_) => "output_io",
            Self::Json(_) => "output_metadata",
            Self::Invalid(_) => "output_invalid",
        }
    }
}

#[cfg(all(test, any(target_os = "linux", target_os = "macos")))]
mod private_inode_tests {
    #[test]
    fn marker_detection_error_is_not_unmarked() {
        let (socket, _other) = std::os::unix::net::UnixStream::pair().unwrap();
        let descriptor: std::os::fd::OwnedFd = socket.into();
        let file = std::fs::File::from(descriptor);
        assert!(super::private_output_inode(&file).is_err());
    }
}
