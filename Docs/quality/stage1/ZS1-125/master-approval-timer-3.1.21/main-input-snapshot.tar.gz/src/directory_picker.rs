//! Bounded terminal-native directory selection. Never creates a project.
use crossterm::event::{KeyCode, KeyEvent, KeyModifiers, MouseButton, MouseEvent, MouseEventKind};
use ratatui::{
    Frame,
    layout::{Position, Rect},
    text::Line,
    widgets::{Block, Borders, Clear, Paragraph},
};
use std::{
    fs,
    path::{Path, PathBuf},
};

#[derive(Debug, Clone)]
pub struct DirectoryPicker {
    cwd: PathBuf,
    input: String,
    entries: Vec<PathBuf>,
    selected: usize,
    error: String,
    area: Rect,
    offset: usize,
}
impl DirectoryPicker {
    pub fn new(base: &Path) -> Self {
        let mut picker = Self {
            cwd: base.to_path_buf(),
            input: base.display().to_string(),
            entries: Vec::new(),
            selected: 0,
            error: String::new(),
            area: Rect::default(),
            offset: 0,
        };
        picker.refresh();
        picker
    }
    pub fn input(&self) -> &str {
        &self.input
    }
    pub fn error(&self) -> &str {
        &self.error
    }
    fn refresh(&mut self) {
        self.entries.clear();
        self.selected = 0;
        self.offset = 0;
        self.error.clear();
        match fs::read_dir(&self.cwd) {
            Ok(entries) => {
                for entry in entries.take(2048) {
                    match entry {
                        Ok(entry)
                            if entry.path().is_dir()
                                && entry
                                    .path()
                                    .to_str()
                                    .is_some_and(|v| !v.chars().any(char::is_control)) =>
                        {
                            self.entries.push(entry.path())
                        }
                        Ok(_) => (),
                        Err(e) => self.error = e.to_string(),
                    }
                    if self.entries.len() == 512 {
                        self.error =
                            "Showing first 512 folders; type a path to open another.".into();
                        break;
                    }
                }
                self.entries.sort();
            }
            Err(e) => self.error = e.to_string(),
        }
    }
    pub fn paste(&mut self, text: &str) {
        let clean: String = text.chars().filter(|c| !c.is_control()).collect();
        if self.input.len() + clean.len() <= crate::project_workspace::MAX_PROJECT_PATH_BYTES {
            self.input.push_str(&clean);
        }
    }
    fn resolved(&self) -> Result<PathBuf, String> {
        let expanded = if self.input == "~" || self.input.starts_with("~/") {
            std::env::var_os("HOME")
                .map(PathBuf::from)
                .ok_or("Home directory unavailable")?
                .join(self.input.strip_prefix("~/").unwrap_or(""))
        } else {
            PathBuf::from(&self.input)
        };
        crate::project_workspace::normalize_directory(&expanded, &self.cwd)
            .map_err(|e| e.to_string())
    }
    fn confirm(&mut self) -> Option<Option<PathBuf>> {
        match self.resolved() {
            Ok(path) => match fs::read_dir(&path) {
                Ok(_) => Some(Some(path)),
                Err(e) => {
                    self.error = e.to_string();
                    None
                }
            },
            Err(e) => {
                self.error = e;
                None
            }
        }
    }
    fn enter(&mut self, path: PathBuf) {
        self.cwd = path;
        self.input = self.cwd.display().to_string();
        self.refresh();
    }
    /// Outer None means keep modal open; Some(None) means cancel.
    pub fn key(&mut self, key: KeyEvent) -> Option<Option<PathBuf>> {
        if key.modifiers.contains(KeyModifiers::CONTROL) {
            match key.code {
                KeyCode::Char('u') | KeyCode::Char('l') => {
                    self.input.clear();
                    return None;
                }
                KeyCode::Char('c') => return Some(None),
                _ => return None,
            }
        }
        match key.code {
            KeyCode::Esc => return Some(None),
            KeyCode::Enter => return self.confirm(),
            KeyCode::Backspace => {
                self.input.pop();
            }
            KeyCode::Char(c)
                if !c.is_control()
                    && self.input.len() + c.len_utf8()
                        <= crate::project_workspace::MAX_PROJECT_PATH_BYTES =>
            {
                self.input.push(c)
            }
            KeyCode::Up => {
                self.selected = self.selected.saturating_sub(1);
                if let Some(p) = self.entries.get(self.selected) {
                    self.input = p.display().to_string();
                }
            }
            KeyCode::Down => {
                self.selected = (self.selected + 1).min(self.entries.len().saturating_sub(1));
                if let Some(p) = self.entries.get(self.selected) {
                    self.input = p.display().to_string();
                }
            }
            KeyCode::Left => {
                if let Some(p) = self.cwd.parent() {
                    self.enter(p.to_path_buf());
                }
            }
            KeyCode::Right => {
                if let Some(p) = self.entries.get(self.selected) {
                    self.enter(p.clone());
                }
            }
            KeyCode::Tab => {
                if let Ok(path) = self.resolved() {
                    self.enter(path);
                } else {
                    let path = if Path::new(&self.input).is_absolute() {
                        PathBuf::from(&self.input)
                    } else {
                        self.cwd.join(&self.input)
                    };
                    if let (Some(parent), Some(prefix)) =
                        (path.parent(), path.file_name().and_then(|s| s.to_str()))
                    {
                        let matches: Vec<_> = fs::read_dir(parent)
                            .into_iter()
                            .flatten()
                            .take(2048)
                            .filter_map(Result::ok)
                            .filter(|e| {
                                e.path().is_dir()
                                    && e.file_name().to_string_lossy().starts_with(prefix)
                            })
                            .take(2)
                            .collect();
                        if matches.len() == 1 {
                            self.input = matches[0].path().display().to_string();
                        } else {
                            self.error =
                                "Type more of the folder name, or use arrows to browse.".into();
                        }
                    }
                }
            }
            _ => (),
        }
        None
    }
    pub fn mouse(&mut self, mouse: MouseEvent) -> Option<Option<PathBuf>> {
        if mouse.kind != MouseEventKind::Down(MouseButton::Left)
            || !self.area.contains(Position::new(mouse.column, mouse.row))
        {
            return None;
        }
        let row = mouse.row.saturating_sub(self.area.y);
        if row == self.area.height.saturating_sub(2) {
            let x = mouse.column.saturating_sub(self.area.x);
            if x < 14 {
                return self.confirm();
            }
            if x < 28 {
                return Some(None);
            }
            if let Some(parent) = self.cwd.parent() {
                self.enter(parent.to_path_buf());
            }
        } else if row >= 4 && row < self.area.height.saturating_sub(3) {
            let index = self.offset + usize::from(row - 4);
            if let Some(path) = self.entries.get(index) {
                self.enter(path.clone());
            }
        }
        None
    }
    pub fn render(&mut self, frame: &mut Frame<'_>) {
        let area = frame.area();
        let width = area.width.saturating_sub(4).min(100);
        let height = area.height.saturating_sub(2).min(24);
        self.area = Rect::new(
            area.x + (area.width - width) / 2,
            area.y + (area.height - height) / 2,
            width,
            height,
        );
        frame.render_widget(Clear, self.area);
        frame.render_widget(
            Block::default()
                .borders(Borders::ALL)
                .title(" Open project folder "),
            self.area,
        );
        if width < 8 || height < 8 {
            return;
        }
        let inner = Rect::new(self.area.x + 1, self.area.y + 1, width - 2, height - 2);
        frame.render_widget(
            Paragraph::new(format!("Path: {}", self.input)),
            Rect::new(inner.x, inner.y, inner.width, 1),
        );
        frame.render_widget(
            Paragraph::new("Type path | Tab browse/complete | arrows browse | Ctrl-U clear"),
            Rect::new(inner.x, inner.y + 1, inner.width, 1),
        );
        frame.render_widget(
            Paragraph::new(format!("In: {}", self.cwd.display())),
            Rect::new(inner.x, inner.y + 2, inner.width, 1),
        );
        let rows = usize::from(height - 7);
        if self.selected < self.offset {
            self.offset = self.selected;
        }
        if self.selected >= self.offset + rows {
            self.offset = self.selected.saturating_sub(rows - 1);
        }
        let lines: Vec<_> = self
            .entries
            .iter()
            .enumerate()
            .skip(self.offset)
            .take(rows)
            .map(|(i, p)| {
                Line::from(format!(
                    "{} {}/",
                    if i == self.selected { ">" } else { " " },
                    p.file_name().unwrap_or_default().to_string_lossy()
                ))
            })
            .collect();
        frame.render_widget(
            Paragraph::new(if lines.is_empty() {
                vec![Line::from("(No subfolders; Enter opens this folder)")]
            } else {
                lines
            }),
            Rect::new(inner.x, inner.y + 3, inner.width, height - 7),
        );
        frame.render_widget(
            Paragraph::new(self.error.as_str()),
            Rect::new(inner.x, self.area.bottom() - 3, inner.width, 1),
        );
        frame.render_widget(
            Paragraph::new("[Open Enter]  [Cancel Esc]  [Parent]"),
            Rect::new(inner.x, self.area.bottom() - 2, inner.width, 1),
        );
    }
}
