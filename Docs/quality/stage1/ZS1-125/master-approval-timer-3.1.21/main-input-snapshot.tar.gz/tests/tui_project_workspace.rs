use crossterm::event::{
    Event, KeyCode, KeyEvent, KeyModifiers, MouseButton, MouseEvent, MouseEventKind,
};
use ratatui::{Terminal, backend::TestBackend};
use std::{
    fs,
    path::Path,
    sync::{Arc, Mutex},
};
use tempfile::tempdir;
use zenpi::{
    core::Agent,
    session::SessionStore,
    tools::{SideEffectPolicy, ToolContext, ToolRegistry},
    tui::{MessageRole, ProjectIntent, ProjectRuntimeHost, ProjectTabMetadata, TuiState},
};

fn host(root: &Path) -> (TuiState, ProjectRuntimeHost) {
    let session = SessionStore::open_in_workspace(root.join("initial.jsonl"), root).unwrap();
    let mut agent = Agent::with_echo(session);
    agent.set_tools(
        ToolRegistry::with_all_builtins().unwrap(),
        ToolContext::new(root).unwrap(),
        SideEffectPolicy::all_builtins(),
    );
    let mut state = TuiState::default();
    state.set_active_project_metadata(ProjectTabMetadata::from_session(agent.session()));
    let host = ProjectRuntimeHost::new(&mut state, Arc::new(Mutex::new(agent))).unwrap();
    (state, host)
}
fn key(state: &mut TuiState, code: KeyCode, modifiers: KeyModifiers) {
    state.handle_key(KeyEvent::new(code, modifiers));
}

#[test]
fn asynchronous_transcript_mutations_schedule_checkpoints_without_keyboard_input() {
    use zenpi::tui::ToolRunStatus;
    let mut state = TuiState::default();
    let checkpoint = |state: &mut TuiState, marker: &str| {
        assert!(
            state.project_checkpoint_dirty(),
            "missing checkpoint for {marker}"
        );
        let value = state.project_checkpoint();
        assert!(value.to_string().contains(marker));
        let mut restored = TuiState::default();
        assert!(restored.restore_project_checkpoint(&value));
        assert!(restored.project_checkpoint().to_string().contains(marker));
        state.clear_project_checkpoint_dirty();
    };
    state.clear_project_checkpoint_dirty();
    state.push_message(MessageRole::System, "owner notice");
    checkpoint(&mut state, "owner notice");
    state.push_message_block(
        MessageRole::Tool,
        "block notice",
        zenpi::view_model::ViewBlock::Paragraph {
            text: "block payload".into(),
        },
    );
    checkpoint(&mut state, "block payload");
    state.append_stream(MessageRole::Assistant, "legacy first ");
    checkpoint(&mut state, "legacy first");
    state.append_stream(MessageRole::Assistant, "legacy second");
    checkpoint(&mut state, "legacy second");
    state.finish_stream(MessageRole::Assistant, "legacy final");
    checkpoint(&mut state, "legacy final");
    state.begin_stream_for_job(7);
    state.append_stream_for_job(7, MessageRole::Assistant, "first chunk ");
    checkpoint(&mut state, "first chunk");
    state.append_stream_for_job(7, MessageRole::Assistant, "second chunk");
    checkpoint(&mut state, "second chunk");
    state.append_reasoning_for_job(7, "first reasoning ");
    checkpoint(&mut state, "first reasoning");
    state.append_reasoning_for_job(7, "second reasoning");
    checkpoint(&mut state, "second reasoning");
    state.tool_call_started("call", "fixture_tool");
    checkpoint(&mut state, "fixture_tool");
    state.tool_call_finished("call", ToolRunStatus::Failed);
    checkpoint(&mut state, "failed");
    state.finish_stream_for_job(7, MessageRole::Assistant, "final answer");
    checkpoint(&mut state, "final answer");
    state.append_stream_for_job(6, MessageRole::Assistant, "stale");
    assert!(!state.project_checkpoint_dirty());
    assert!(state.open_project_tab("other"));
    state.clear_project_checkpoint_dirty();
    assert!(state.select_project_tab(0));
    state.push_message(MessageRole::System, "background result");
    assert!(state.select_project_tab(1));
    checkpoint(&mut state, "background result");
    assert!(
        !state
            .messages()
            .any(|m| m.text.contains("background result"))
    );
}

#[test]
fn display_only_ticks_do_not_schedule_project_writes_but_layout_changes_do() {
    let mut state = TuiState::default();
    state.clear_project_checkpoint_dirty();
    state.clear_layout_dirty();
    state.set_busy(true);
    state.tick();
    state.set_status("Working");
    assert!(!state.project_checkpoint_dirty());
    assert!(!state.layout_dirty());
    state.focus_next_workspace_pane();
    assert!(state.layout_dirty());
    state.clear_layout_dirty();
    state.set_workspace_pane_collapsed(zenpi::layout::PaneId::Resources, true);
    assert!(state.layout_dirty());
}

#[test]
fn topmost_plus_opens_picker_and_cancel_never_creates_a_tab_or_changes_draft() {
    let root = tempdir().unwrap();
    let (mut state, _host) = host(root.path());
    state.handle_event(Event::Paste("draft 未发送".into()));
    let before = state.project_checkpoint();
    let mut terminal = Terminal::new(TestBackend::new(100, 30)).unwrap();
    terminal
        .draw(|frame| state.render_bentobox(frame, "zenpi"))
        .unwrap();
    let row: String = (0..100)
        .map(|x| terminal.backend().buffer()[(x, 0)].symbol())
        .collect();
    assert!(row.contains("[+]"));
    state.handle_mouse(MouseEvent {
        kind: MouseEventKind::Down(MouseButton::Left),
        column: 98,
        row: 0,
        modifiers: KeyModifiers::NONE,
    });
    assert!(state.directory_picker_open());
    assert_eq!(state.project_tab_count(), 1);
    key(&mut state, KeyCode::Esc, KeyModifiers::NONE);
    assert!(!state.directory_picker_open());
    assert!(state.take_project_intent().is_none());
    assert_eq!(state.project_checkpoint(), before);
    assert_eq!(state.input(), "draft 未发送");
}

#[test]
fn picker_confirmation_and_real_tools_bind_two_equal_basename_directories() {
    let root = tempdir().unwrap();
    let first = root.path().join("one/工作 folder");
    let second = root.path().join("two/工作 folder");
    fs::create_dir_all(&first).unwrap();
    fs::create_dir_all(&second).unwrap();
    let (mut state, mut host) = host(root.path());
    let process_cwd = std::env::current_dir().unwrap();
    for (directory, content) in [(&first, "first"), (&second, "second")] {
        key(&mut state, KeyCode::Char('t'), KeyModifiers::CONTROL);
        assert!(state.directory_picker_open());
        key(&mut state, KeyCode::Char('u'), KeyModifiers::CONTROL);
        state.handle_event(Event::Paste(directory.display().to_string()));
        key(&mut state, KeyCode::Enter, KeyModifiers::NONE);
        let intent = state.take_project_intent().expect("confirmed path");
        host.apply(&mut state, intent).unwrap();
        let active = host.active(&state);
        let mut agent = active.lock().unwrap();
        assert_eq!(
            Path::new(&agent.session().header().cwd),
            directory.canonicalize().unwrap()
        );
        assert_eq!(
            agent.attachment_workspace_root().unwrap(),
            directory.canonicalize().unwrap()
        );
        agent.set_approval_policy(zenpi::approval::ApprovalPolicy {
            mode: zenpi::approval::ApprovalMode::Never,
            ..Default::default()
        });
        let result = agent
            .run_user_shell_with_cancel(&format!("!printf {content} > marker.txt"), || false)
            .unwrap();
        assert_eq!(result["exit_code"], 0);
        assert_eq!(
            fs::read_to_string(directory.join("marker.txt")).unwrap(),
            content
        );
    }
    assert_ne!(state.project_tabs()[1], state.project_tabs()[2]);
    assert_ne!(state.project_label(1), state.project_label(2));
    assert_eq!(
        fs::read_to_string(first.join("marker.txt")).unwrap(),
        "first"
    );
    host.apply(
        &mut state,
        ProjectIntent::Open(first.join("../工作 folder")),
    )
    .unwrap();
    assert_eq!(state.project_tab_count(), 3);
    assert_eq!(std::env::current_dir().unwrap(), process_cwd);
}

#[test]
fn invalid_project_config_is_rejected_before_creating_session_or_mutating_visible_owner() {
    let root = tempdir().unwrap();
    let invalid = root.path().join("invalid");
    fs::create_dir_all(invalid.join(".zenpi")).unwrap();
    fs::write(invalid.join(".zenpi/config.toml"), "model = [ broken").unwrap();
    let (mut state, mut host) = host(root.path());
    let before = state.project_checkpoint();
    let owner = host.active(&state);
    assert!(
        host.apply(&mut state, ProjectIntent::Open(invalid))
            .is_err()
    );
    assert_eq!(state.project_checkpoint(), before);
    assert!(Arc::ptr_eq(&owner, &host.active(&state)));
    assert!(!root.path().join("projects").exists());
}

#[test]
fn switching_while_original_owner_is_locked_preserves_drafts_layout_and_owner() {
    let root = tempdir().unwrap();
    let other = root.path().join("other");
    fs::create_dir(&other).unwrap();
    let (mut state, mut host) = host(root.path());
    state.handle_event(Event::Paste("draft one".into()));
    state.push_message(MessageRole::Assistant, "answer one");
    let initial = host.active(&state);
    let initial_layout = state.workspace_layout().clone();
    let running = initial.lock().unwrap();
    host.apply(&mut state, ProjectIntent::Open(other)).unwrap();
    assert_eq!(state.input(), "");
    assert!(!Arc::ptr_eq(&initial, &host.active(&state)));
    state.handle_event(Event::Paste("draft two".into()));
    host.apply(&mut state, ProjectIntent::Select(0)).unwrap();
    assert_eq!(state.input(), "draft one");
    assert_eq!(state.workspace_layout(), &initial_layout);
    assert!(Arc::ptr_eq(&initial, &host.active(&state)));
    drop(running);
    let inactive = state.project_tabs()[1].clone();
    host.apply(&mut state, ProjectIntent::Close(inactive))
        .unwrap();
    assert_eq!(state.input(), "draft one");
    assert!(state.messages().any(|m| m.text == "answer one"));
}

#[test]
fn restart_restores_selected_runtime_and_drafts_without_reusing_startup_owner() {
    let root = tempdir().unwrap();
    let other = root.path().join("other");
    fs::create_dir(&other).unwrap();
    let (mut state, mut host) = host(root.path());
    state.handle_event(Event::Paste("draft initial".into()));
    host.apply(&mut state, ProjectIntent::Open(other.clone()))
        .unwrap();
    state.handle_event(Event::Paste("draft other".into()));
    let saved = state.project_checkpoint();
    drop(host);
    let session =
        SessionStore::open_in_workspace(root.path().join("initial.jsonl"), root.path()).unwrap();
    let mut agent = Agent::with_echo(session);
    agent.set_attachment_workspace(ToolContext::new(root.path()).unwrap());
    let mut restored = TuiState::default();
    assert!(restored.restore_project_checkpoint(&saved));
    let mut host = ProjectRuntimeHost::new(&mut restored, Arc::new(Mutex::new(agent))).unwrap();
    assert_eq!(restored.input(), "draft other");
    assert_eq!(
        host.active(&restored)
            .lock()
            .unwrap()
            .attachment_workspace_root()
            .unwrap(),
        other.canonicalize().unwrap()
    );
    host.apply(&mut restored, ProjectIntent::Select(0)).unwrap();
    assert_eq!(restored.input(), "draft initial");
}

#[test]
fn session_workspace_mismatch_does_not_rewrite_existing_journal() {
    let root = tempdir().unwrap();
    let other = root.path().join("other");
    fs::create_dir(&other).unwrap();
    let path = root.path().join("journal.jsonl");
    SessionStore::open_in_workspace(&path, root.path()).unwrap();
    let before = fs::read(&path).unwrap();
    assert!(SessionStore::open_in_workspace(&path, &other).is_err());
    assert_eq!(fs::read(path).unwrap(), before);
}

#[cfg(unix)]
#[test]
fn shared_resume_checkpoint_failure_preserves_actual_owner_draft_layout_and_metadata() {
    use std::os::unix::fs::PermissionsExt;
    let root = tempdir().unwrap();
    let target = root.path().join("alternate.jsonl");
    let mut replacement =
        Agent::with_echo(SessionStore::open_in_workspace(&target, root.path()).unwrap());
    replacement.set_persona("ISTJ").unwrap();
    let target_id = replacement.session().session_id().to_owned();
    drop(replacement);
    let (mut state, mut host) = host(root.path());
    host.restore_shared_workspace(&mut state).unwrap();
    let owner = host.active(&state);
    owner.lock().unwrap().set_persona("ESFP").unwrap();
    let old_session = owner.lock().unwrap().session().session_id().to_owned();
    state.set_input("keep unsent draft 世界");
    state.push_message(MessageRole::Assistant, "keep old transcript");
    let before = state.project_checkpoint();
    let checkpoint = root.path().join("project-workspace.json");
    let saved = fs::read(&checkpoint).unwrap();
    fs::set_permissions(root.path(), fs::Permissions::from_mode(0o500)).unwrap();
    let result = host.resume_session(
        &mut state,
        &zenpi::slash::SessionAction::Open {
            path: target.display().to_string(),
        },
    );
    fs::set_permissions(root.path(), fs::Permissions::from_mode(0o700)).unwrap();
    assert!(result.is_err());
    assert_eq!(state.project_checkpoint(), before);
    assert_eq!(fs::read(&checkpoint).unwrap(), saved);
    assert!(Arc::ptr_eq(&owner, &host.active(&state)));
    assert_eq!(owner.lock().unwrap().session().session_id(), old_session);
    assert_eq!(owner.lock().unwrap().persona(), "ESFP");
    host.resume_session(
        &mut state,
        &zenpi::slash::SessionAction::Open {
            path: target.display().to_string(),
        },
    )
    .unwrap();
    assert_eq!(owner.lock().unwrap().session().session_id(), target_id);
    assert_eq!(owner.lock().unwrap().persona(), "ISTJ");
    assert_eq!(state.input(), "keep unsent draft 世界");
    assert_eq!(
        state
            .project_metadata(state.active_project())
            .unwrap()
            .session_path
            .as_deref(),
        target.canonicalize().unwrap().to_str()
    );
    let after = state.project_checkpoint();
    assert_eq!(
        before["project_state"][0]["layout"],
        after["project_state"][0]["layout"]
    );
    assert_ne!(fs::read(&checkpoint).unwrap(), saved);
}

#[test]
fn stale_resume_writer_and_busy_owner_leave_the_tui_checkpoint_unchanged() {
    let root = tempdir().unwrap();
    let target = root.path().join("alternate.jsonl");
    drop(SessionStore::open_in_workspace(&target, root.path()).unwrap());
    let (mut state, mut host) = host(root.path());
    host.restore_shared_workspace(&mut state).unwrap();
    state.set_input("retained draft");
    let before = state.project_checkpoint();
    let action = zenpi::slash::SessionAction::Open {
        path: target.display().to_string(),
    };
    state.set_busy(true);
    assert!(
        host.resume_session(&mut state, &action)
            .unwrap_err()
            .contains("busy")
    );
    state.set_busy(false);
    let owner = host.active(&state);
    let guard = owner.lock().unwrap();
    assert!(
        host.resume_session(&mut state, &action)
            .unwrap_err()
            .contains("busy")
    );
    drop(guard);
    assert_eq!(state.project_checkpoint(), before);
    let checkpoint = root.path().join("project-workspace.json");
    let mut changed = fs::read(&checkpoint).unwrap();
    changed.push(b'\n');
    fs::write(&checkpoint, &changed).unwrap();
    assert!(
        host.resume_session(&mut state, &action)
            .unwrap_err()
            .contains("another host")
    );
    assert_eq!(state.project_checkpoint(), before);
    assert_eq!(fs::read(checkpoint).unwrap(), changed);
}

#[test]
fn canonical_project_checkpoint_restores_session_projection_without_feature_tabs() {
    use zenpi::layout::{PaneId, TabId};
    let root = tempdir().unwrap();
    let (mut state, _host) = host(root.path());
    state.set_workspace_tab(TabId::Session);
    state.focus_workspace_pane(PaneId::SessionList);
    state.set_workspace_pane_collapsed(PaneId::ReplayControls, true);
    let saved = state.project_checkpoint();
    let mut restored = TuiState::default();
    assert!(restored.restore_project_checkpoint(&saved));
    assert_eq!(restored.project_tabs(), state.project_tabs());
    assert_eq!(restored.workspace_layout(), state.workspace_layout());
    let mut legacy = saved;
    legacy["schema_version"] = serde_json::json!(2);
    let mut restored = TuiState::default();
    assert!(restored.restore_project_checkpoint(&legacy));
    assert_eq!(restored.workspace_tab(), TabId::Project);
}
