#![cfg(unix)]
use serde_json::json;
use sha2::{Digest, Sha256};
use std::fs;
use std::sync::atomic::{AtomicBool, Ordering};
use std::time::{Duration, Instant};
use tempfile::tempdir;
use zenpi::tool_output::*;
use zenpi::tools::*;
fn limits() -> OutputLimits {
    OutputLimits {
        max_file_bytes: 1024 * 1024,
        max_total_bytes: 2 * 1024 * 1024,
        max_files: 8,
        ttl_ms: 10000,
        view_bytes: 64,
        read_bytes: 64 * 1024,
        progress_capacity: 2,
    }
}
fn digest(bytes: &[u8]) -> String {
    format!("{:x}", Sha256::digest(bytes))
}
fn read_all(store: &OutputArtifactStore, r: &ArtifactRef) -> Vec<u8> {
    let mut out = Vec::new();
    while out.len() < (r.bytes_stored as usize) {
        let part = store
            .read_range(r, out.len() as u64, 64 * 1024, 101)
            .unwrap();
        assert!(!part.is_empty());
        out.extend(part);
    }
    out
}
#[test]
fn preserves_exact_raw_bytes_with_split_utf8_and_bounded_display() {
    let root = tempdir().unwrap();
    let store = OutputArtifactStore::open(root.path().join("raw"), limits()).unwrap();
    let q = store.progress_queue();
    let mut writer = store
        .begin("session", "call", OutputStream::Stdout, 100, q.clone())
        .unwrap();
    writer.append(&[0xe4, 0xbd]).unwrap();
    assert_eq!(writer.snapshot().text, "");
    writer.append(&[0xa0]).unwrap();
    assert_eq!(writer.snapshot().text, "你");
    let rest = "世".repeat(100);
    writer.append(rest.as_bytes()).unwrap();
    let view = writer.snapshot();
    assert!(view.text.len() <= 64);
    assert!(!view.text.contains('\u{fffd}'));
    assert!(view.truncated);
    assert!(view.display_start > 0);
    assert_eq!(view.display_end, 303);
    let reference = writer.finish(true).unwrap();
    assert!(reference.complete);
    assert_eq!(reference.bytes_stored, 303);
    let raw = format!("你{rest}").into_bytes();
    assert_eq!(read_all(&store, &reference), raw);
    assert_eq!(reference.sha256, Some(digest(&raw)));
    assert!(matches!(writer.append(b"late"), Err(OutputError::Closed)));
    assert!(q.drain().iter().any(|p| p.dropped_updates > 0));
}
#[test]
fn per_file_quota_keeps_verified_prefix_and_never_claims_full_output() {
    let root = tempdir().unwrap();
    let mut l = limits();
    l.max_file_bytes = 8;
    l.max_total_bytes = 16;
    let store = OutputArtifactStore::open(root.path().join("raw"), l).unwrap();
    let mut writer = store
        .begin("s", "c", OutputStream::Stdout, 100, store.progress_queue())
        .unwrap();
    assert!(matches!(
        writer.append(b"0123456789"),
        Err(OutputError::Quota)
    ));
    writer.append(b"tail").unwrap();
    let r = writer.finish(true).unwrap();
    assert!(!r.complete);
    assert!(r.truncated);
    assert_eq!(r.bytes_stored, 8);
    assert_eq!(r.bytes_observed, 14);
    assert!(r.failure.is_some());
    assert_eq!(read_all(&store, &r), b"01234567");
    assert_eq!(r.sha256, Some(digest(b"01234567")));
}
#[test]
fn total_reservations_and_restart_account_for_bytes_on_disk() {
    let root = tempdir().unwrap();
    let path = root.path().join("raw");
    let mut l = limits();
    l.max_file_bytes = 8;
    l.max_total_bytes = 16;
    let reference;
    {
        let store = OutputArtifactStore::open(&path, l).unwrap();
        assert!(matches!(
            OutputArtifactStore::open(&path, l),
            Err(OutputError::Busy)
        ));
        let mut a = store
            .begin("s", "a", OutputStream::Stdout, 100, store.progress_queue())
            .unwrap();
        let mut b = store
            .begin("s", "b", OutputStream::Stdout, 100, store.progress_queue())
            .unwrap();
        assert!(matches!(
            store.begin("s", "c", OutputStream::Stdout, 100, store.progress_queue()),
            Err(OutputError::Quota)
        ));
        a.append(b"12345678").unwrap();
        reference = a.finish(true).unwrap();
        b.append(b"12345678").unwrap();
        b.finish(true).unwrap();
    }
    let store = OutputArtifactStore::open(&path, l).unwrap();
    assert_eq!(read_all(&store, &reference), b"12345678");
    assert!(matches!(
        store.begin("s", "c", OutputStream::Stdout, 101, store.progress_queue()),
        Err(OutputError::Quota)
    ));
    assert_eq!(store.cleanup_session("s").unwrap(), 2);
    assert!(
        store
            .begin("s", "c", OutputStream::Stdout, 102, store.progress_queue())
            .is_ok()
    );
}
#[test]
fn session_and_ttl_cleanup_preserve_other_sessions_and_active_writers() {
    let root = tempdir().unwrap();
    let mut l = limits();
    l.max_file_bytes = 8;
    l.max_total_bytes = 32;
    let store = OutputArtifactStore::open(root.path().join("raw"), l).unwrap();
    let mut a = store
        .begin(
            "a",
            "one",
            OutputStream::Stdout,
            100,
            store.progress_queue(),
        )
        .unwrap();
    a.append(b"a").unwrap();
    let ar = a.finish(true).unwrap();
    let mut b = store
        .begin(
            "b",
            "two",
            OutputStream::Stderr,
            200,
            store.progress_queue(),
        )
        .unwrap();
    b.append(b"b").unwrap();
    let br = b.finish(true).unwrap();
    let active = store
        .begin(
            "a",
            "live",
            OutputStream::Stdout,
            100,
            store.progress_queue(),
        )
        .unwrap();
    assert_eq!(store.cleanup_session("a").unwrap(), 1);
    assert!(matches!(store.inspect(&ar, 101), Err(OutputError::Missing)));
    assert_eq!(store.read_range(&br, 0, 1, 201).unwrap(), b"b");
    assert_eq!(store.cleanup_expired(10201).unwrap(), 1);
    assert!(matches!(
        store.inspect(&br, 10201),
        Err(OutputError::Expired)
    ));
    drop(active);
    assert_eq!(store.cleanup_session("a").unwrap(), 1);
}
#[test]
fn range_limits_metadata_identity_and_tampering_are_rejected() {
    let root = tempdir().unwrap();
    let path = root.path().join("raw");
    let store = OutputArtifactStore::open(&path, limits()).unwrap();
    let mut writer = store
        .begin("s", "c", OutputStream::Stdout, 100, store.progress_queue())
        .unwrap();
    writer.append(b"content").unwrap();
    let r = writer.finish(true).unwrap();
    assert!(matches!(
        store.read_range(&r, 0, 64 * 1024 + 1, 101),
        Err(OutputError::Quota)
    ));
    assert!(matches!(
        store.read_range(&r, 8, 1, 101),
        Err(OutputError::Invalid(_))
    ));
    let mut forged = r.clone();
    forged.artifact_id = "../../credentials".into();
    assert!(matches!(
        store.inspect(&forged, 101),
        Err(OutputError::UnsafePath)
    ));
    forged = r.clone();
    forged.call_id = "someone-else".into();
    assert!(matches!(
        store.inspect(&forged, 101),
        Err(OutputError::Integrity)
    ));
    fs::write(path.join(format!("{}.raw", r.artifact_id)), b"changed").unwrap();
    assert!(matches!(
        store.read_range(&r, 0, 7, 101),
        Err(OutputError::Integrity)
    ));
}
#[test]
fn private_permissions_and_symlink_or_hardlink_reads_cannot_escape() {
    use std::os::unix::fs::{PermissionsExt, symlink};
    let root = tempdir().unwrap();
    let outside = root.path().join("credential");
    fs::write(&outside, b"private").unwrap();
    let bad = root.path().join("linked-root");
    symlink(root.path(), &bad).unwrap();
    assert!(OutputArtifactStore::open(&bad, limits()).is_err());
    let path = root.path().join("raw");
    let store = OutputArtifactStore::open(&path, limits()).unwrap();
    assert_eq!(
        fs::metadata(&path).unwrap().permissions().mode() & 0o777,
        0o700
    );
    let mut writer = store
        .begin("s", "c", OutputStream::Stdout, 100, store.progress_queue())
        .unwrap();
    writer.append(b"private").unwrap();
    let r = writer.finish(true).unwrap();
    let raw = path.join(format!("{}.raw", r.artifact_id));
    assert_eq!(
        fs::metadata(&raw).unwrap().permissions().mode() & 0o777,
        0o600
    );
    fs::remove_file(&raw).unwrap();
    symlink(&outside, &raw).unwrap();
    assert!(store.read_range(&r, 0, 7, 101).is_err());
    fs::remove_file(&raw).unwrap();
    fs::hard_link(&outside, &raw).unwrap();
    assert!(matches!(
        store.read_range(&r, 0, 7, 101),
        Err(OutputError::UnsafePath)
    ));
}
#[test]
fn interrupted_drop_and_missing_file_are_distinct_from_empty_success() {
    let root = tempdir().unwrap();
    let path = root.path().join("raw");
    let r;
    {
        let store = OutputArtifactStore::open(&path, limits()).unwrap();
        let mut w = store
            .begin("s", "c", OutputStream::Stdout, 100, store.progress_queue())
            .unwrap();
        w.append(b"prefix").unwrap();
        r = w.reference().clone();
        assert!(matches!(
            store.inspect(&r, 101),
            Err(OutputError::Interrupted)
        ));
        // Drop records obtained bytes as explicitly incomplete, never success.
    }
    let store = OutputArtifactStore::open(&path, limits()).unwrap();
    let actual = store.inspect(&r, 101).unwrap();
    assert!(!actual.complete);
    assert_eq!(read_all(&store, &actual), b"prefix");
    fs::remove_file(path.join(format!("{}.raw", r.artifact_id))).unwrap();
    assert!(matches!(store.inspect(&r, 101), Err(OutputError::Missing)));
}
#[test]
fn actual_command_output_over_memory_cap_is_reconstructible_from_raw_artifacts() {
    let root = tempdir().unwrap();
    let store = OutputArtifactStore::open(root.path().join("raw"), limits()).unwrap();
    let capture = CommandOutputCapture::new(store.clone(), "s", "command", 100).unwrap();
    let context = ToolContext::new(root.path())
        .unwrap()
        .with_output_capture(capture.clone())
        .unwrap();
    let registry = ToolRegistry::with_all_builtins().unwrap();
    let result=registry.execute(&context,SideEffectPolicy::all_builtins(),ToolCall{id:"command".into(),name:"run_command".into(),arguments:json!({"command":"/usr/bin/yes x | /usr/bin/head -c 400000; printf stderr >&2","timeout_ms":5000})});
    let ToolResult::Success { output, .. } = result else {
        panic!("{result:?}")
    };
    assert_eq!(output["stdout_truncated"], true);
    assert!(output["stdout"].as_str().unwrap().len() <= MAX_COMMAND_OUTPUT_BYTES);
    let refs = capture.artifacts();
    assert_eq!(refs.len(), 2);
    assert!(refs.iter().all(|r| r.complete));
    let stdout = refs
        .iter()
        .find(|r| r.stream == OutputStream::Stdout)
        .unwrap();
    let raw = read_all(&store, stdout);
    assert_eq!(raw, b"x\n".repeat(200000));
    assert_eq!(stdout.sha256, Some(digest(&raw)));
    assert_eq!(
        read_all(
            &store,
            refs.iter()
                .find(|r| r.stream == OutputStream::Stderr)
                .unwrap()
        ),
        b"stderr"
    );
    assert!(
        capture
            .progress()
            .drain()
            .iter()
            .any(|p| p.dropped_updates > 0)
    );
}
#[test]
fn actual_command_updates_precede_terminal_and_reuse_canonical_event() {
    let root = tempdir().unwrap();
    let store = OutputArtifactStore::open(root.path().join("raw"), limits()).unwrap();
    let capture = CommandOutputCapture::new(store, "s", "command", 100).unwrap();
    let q = capture.progress();
    let context = ToolContext::new(root.path())
        .unwrap()
        .with_output_capture(capture.clone())
        .unwrap();
    let registry = ToolRegistry::with_all_builtins().unwrap();
    std::thread::scope(|scope| {
        let handle = scope.spawn(|| {
            registry.execute(
                &context,
                SideEffectPolicy::all_builtins(),
                ToolCall {
                    id: "command".into(),
                    name: "run_command".into(),
                    arguments: json!({"command":"printf first; /bin/sleep 0.3; printf last"}),
                },
            )
        });
        let began = Instant::now();
        let progress = loop {
            let p = q.drain();
            if !p.is_empty() {
                break p;
            }
            assert!(began.elapsed() < Duration::from_secs(3));
            std::thread::sleep(Duration::from_millis(1));
        };
        assert!(!handle.is_finished());
        assert!(progress.iter().any(|p| p.snapshot.text.contains("first")));
        assert!(matches!(
            progress[0].canonical_kind(),
            zenpi::view_model::ViewEventKind::Block { .. }
        ));
        assert!(handle.join().unwrap().is_success());
    });
    q.drain();
    std::thread::sleep(Duration::from_millis(10));
    assert!(q.drain().is_empty());
    assert_eq!(capture.artifacts().len(), 2);
}
#[test]
fn command_cancel_reaps_then_flushes_incomplete_prefix_and_stops_updates() {
    let root = tempdir().unwrap();
    let store = OutputArtifactStore::open(root.path().join("raw"), limits()).unwrap();
    let capture = CommandOutputCapture::new(store.clone(), "s", "command", 100).unwrap();
    let q = capture.progress();
    let context = ToolContext::new(root.path())
        .unwrap()
        .with_output_capture(capture.clone())
        .unwrap();
    let registry = ToolRegistry::with_all_builtins().unwrap();
    let stop = AtomicBool::new(false);
    let result = registry.execute_cancellable(
        &context,
        SideEffectPolicy::all_builtins(),
        ToolCall {
            id: "command".into(),
            name: "run_command".into(),
            arguments: json!({"command":"echo $$ > leader; printf prefix; /bin/sleep 20"}),
        },
        &|| {
            if !q.drain().is_empty() {
                stop.store(true, Ordering::SeqCst);
            }
            stop.load(Ordering::SeqCst)
        },
    );
    assert!(matches!(
        result,
        ToolResult::Error {
            error: ToolFailure {
                code: ToolErrorCode::Cancelled,
                ..
            },
            ..
        }
    ));
    let refs = capture.artifacts();
    assert_eq!(refs.len(), 2);
    assert!(refs.iter().all(|r| !r.complete && r.finalized));
    assert_eq!(
        read_all(
            &store,
            refs.iter()
                .find(|r| r.stream == OutputStream::Stdout)
                .unwrap()
        ),
        b"prefix"
    );
    let pid: i32 = fs::read_to_string(root.path().join("leader"))
        .unwrap()
        .trim()
        .parse()
        .unwrap();
    assert_eq!(unsafe { libc::kill(pid, 0) }, -1);
    q.drain();
    std::thread::sleep(Duration::from_millis(10));
    assert!(q.drain().is_empty());
}
#[test]
fn command_capture_binding_and_disk_quota_preflight_prevent_wrong_dispatch() {
    let root = tempdir().unwrap();
    let mut l = limits();
    l.max_total_bytes = l.max_file_bytes;
    let store = OutputArtifactStore::open(root.path().join("raw"), l).unwrap();
    let capture = CommandOutputCapture::new(store, "s", "right-id", 100).unwrap();
    let context = ToolContext::new(root.path())
        .unwrap()
        .with_output_capture(capture)
        .unwrap();
    let registry = ToolRegistry::with_all_builtins().unwrap();
    for id in ["wrong-id", "right-id"] {
        let result = registry.execute(
            &context,
            SideEffectPolicy::all_builtins(),
            ToolCall {
                id: id.into(),
                name: "run_command".into(),
                arguments: json!({"command":"touch should-not-exist"}),
            },
        );
        assert!(!result.is_success());
        assert!(!root.path().join("should-not-exist").exists());
    }
}
#[test]
fn spill_corruption_cannot_produce_a_complete_reference() {
    let root = tempdir().unwrap();
    let path = root.path().join("raw");
    let store = OutputArtifactStore::open(&path, limits()).unwrap();
    let mut writer = store
        .begin("s", "c", OutputStream::Stdout, 100, store.progress_queue())
        .unwrap();
    writer.append(b"original").unwrap();
    let raw = path.join(format!("{}.raw", writer.reference().artifact_id));
    fs::write(raw, b"tampered").unwrap();
    let result = writer.finish(true).unwrap();
    assert!(!result.complete);
    assert!(result.failure.is_some());
    assert!(matches!(
        store.inspect(&result, 101),
        Err(OutputError::Integrity)
    ));
}

#[test]
fn actual_process_exit_before_finalize_recovers_as_interrupted() {
    let root = tempdir().unwrap();
    let status = std::process::Command::new(std::env::current_exe().unwrap())
        .args(["--ignored", "--exact", "restart_writer_helper"])
        .env("ZENPI_OUTPUT_RESTART_ROOT", root.path())
        .status()
        .unwrap();
    assert!(status.success());
    let reference: ArtifactRef =
        serde_json::from_slice(&fs::read(root.path().join("reference.json")).unwrap()).unwrap();
    let store = OutputArtifactStore::open(root.path().join("raw"), limits()).unwrap();
    assert!(matches!(
        store.inspect(&reference, 101),
        Err(OutputError::Interrupted)
    ));
    assert_eq!(store.cleanup_session("restart-session").unwrap(), 1);
}
#[test]
#[ignore = "subprocess fixture: must exit without running writer Drop"]
fn restart_writer_helper() {
    let root = std::path::PathBuf::from(
        std::env::var_os("ZENPI_OUTPUT_RESTART_ROOT").expect("parent fixture root"),
    );
    let store = OutputArtifactStore::open(root.join("raw"), limits()).unwrap();
    let mut writer = store
        .begin(
            "restart-session",
            "call",
            OutputStream::Stdout,
            100,
            store.progress_queue(),
        )
        .unwrap();
    writer.append(b"written-before-exit").unwrap();
    fs::write(
        root.join("reference.json"),
        serde_json::to_vec(writer.reference()).unwrap(),
    )
    .unwrap();
    std::process::exit(0);
}

#[test]
fn batch_capture_is_scoped_per_call_and_keeps_following_calls_usable() {
    use zenpi::tool_runtime::*;
    let root = tempdir().unwrap();
    let mut budget = limits();
    budget.max_total_bytes = 4 * 1024 * 1024;
    let store = OutputArtifactStore::open(root.path().join("raw"), budget).unwrap();
    let context = ToolContext::new(root.path()).unwrap();
    let registry = ToolRegistry::with_all_builtins().unwrap();
    let calls = [
        ToolCall {
            id: "a".into(),
            name: "run_command".into(),
            arguments: json!({"command":"printf first"}),
        },
        ToolCall {
            id: "b".into(),
            name: "run_command".into(),
            arguments: json!({"command":"printf second"}),
        },
        ToolCall {
            id: "c".into(),
            name: "list_directory".into(),
            arguments: json!({}),
        },
    ];
    let mut captures = Vec::new();
    let outcome = execute_tool_batch(
        &registry,
        &context,
        SideEffectPolicy::all_builtins(),
        &calls,
        ToolBatchOptions {
            max_concurrency: 2,
            ..Default::default()
        },
        &|| false,
        &mut |call| {
            if call.name != "run_command" {
                return ToolBatchDecision::Execute;
            }
            let capture = CommandOutputCapture::new(store.clone(), "s", &call.id, 100).unwrap();
            captures.push(capture.clone());
            ToolBatchDecision::ExecuteWithCapture(capture)
        },
    )
    .unwrap();
    assert!(outcome.results.iter().all(ToolResult::is_success));
    for (index, capture) in captures.iter().enumerate() {
        let refs = capture.artifacts();
        assert!(
            refs.iter()
                .all(|r| r.call_id == calls[index].id && r.complete)
        );
        assert_eq!(
            read_all(
                &store,
                refs.iter()
                    .find(|r| r.stream == OutputStream::Stdout)
                    .unwrap()
            ),
            if index == 0 {
                b"first".to_vec()
            } else {
                b"second".to_vec()
            }
        );
    }
}

#[test]
fn expired_orphan_spill_files_are_cleaned_without_touching_live_writers() {
    use std::os::unix::fs::OpenOptionsExt;
    let root = tempdir().unwrap();
    let path = root.path().join("raw");
    drop(OutputArtifactStore::open(&path, limits()).unwrap());
    let id = "a".repeat(64);
    let orphan = path.join(format!("{id}.0.tmp"));
    let mut file = std::fs::OpenOptions::new()
        .create_new(true)
        .write(true)
        .mode(0o600)
        .open(&orphan)
        .unwrap();
    use std::io::Write;
    file.write_all(b"interrupted metadata").unwrap();
    drop(file);
    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap()
        .as_millis() as u64;
    let store = OutputArtifactStore::open(&path, limits()).unwrap();
    let _active = store
        .begin(
            "s",
            "live",
            OutputStream::Stdout,
            now,
            store.progress_queue(),
        )
        .unwrap();
    assert_eq!(store.cleanup_expired(now + 20000).unwrap(), 1);
    assert!(!orphan.exists());
}

#[test]
fn worker_gate_and_capture_cannot_be_composed_in_either_order() {
    let root = tempdir().unwrap();
    let store = OutputArtifactStore::open(root.path().join("raw"), limits()).unwrap();
    let capture = CommandOutputCapture::new(store, "s", "command", 100).unwrap();
    let context = ToolContext::new(root.path()).unwrap();
    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap()
        .as_millis() as u64;
    let policy = BlueprintPolicySpec {
        blueprint_digest: "a".repeat(64),
        goal_digest: "b".repeat(64),
        item_id: "ZS1-111".into(),
        allowed_tools: ["read_file".into()].into(),
        readable_paths: [".".into()].into(),
        writable_paths: Default::default(),
        denied_paths: Default::default(),
        protected_paths: Default::default(),
        allowed_commands: Default::default(),
        denied_commands: Default::default(),
        network_hosts: Default::default(),
        max_actions: 1,
        max_command_timeout_ms: 1000,
        max_command_output_bytes: 1024,
    };
    for capture_first in [false, true] {
        let (gate, _) = BlueprintGate::compile(
            &context,
            policy.clone(),
            BlueprintLease {
                lease_id: "lease".into(),
                issued_at_ms: now,
                expires_at_ms: now + 10000,
            },
            now,
        )
        .unwrap();
        let result = if capture_first {
            context
                .clone()
                .with_output_capture(capture.clone())
                .unwrap()
                .with_blueprint_gate(gate)
        } else {
            context
                .clone()
                .with_blueprint_gate(gate)
                .unwrap()
                .with_output_capture(capture.clone())
        };
        assert!(matches!(result, Err(ToolError::GateDenied { .. })));
    }
    assert!(capture.artifacts().is_empty());
}

#[test]
fn preflight_and_spawn_failures_keep_incomplete_artifact_references() {
    for fail_second_stream in [true, false] {
        let root = tempdir().unwrap();
        let workspace = root.path().join("workspace");
        fs::create_dir(&workspace).unwrap();
        let mut budget = limits();
        if fail_second_stream {
            budget.max_total_bytes = budget.max_file_bytes;
        }
        let store = OutputArtifactStore::open(root.path().join("raw"), budget).unwrap();
        let capture = CommandOutputCapture::new(store.clone(), "s", "call", 100).unwrap();
        let context = ToolContext::new(&workspace)
            .unwrap()
            .with_output_capture(capture.clone())
            .unwrap();
        if !fail_second_stream {
            fs::remove_dir(&workspace).unwrap();
        }
        let result = ToolRegistry::with_all_builtins().unwrap().execute(
            &context,
            SideEffectPolicy::all_builtins(),
            ToolCall {
                id: "call".into(),
                name: "run_command".into(),
                arguments: json!({"command":"printf unreachable"}),
            },
        );
        assert!(!result.is_success());
        let refs = capture.artifacts();
        assert_eq!(refs.len(), if fail_second_stream { 1 } else { 2 });
        for reference in refs {
            assert!(reference.finalized && !reference.complete);
            assert_eq!(reference.bytes_observed, 0);
            assert!(store.inspect(&reference, 101).is_ok());
        }
    }
}

fn output_host(root: &std::path::Path, workspace: &std::path::Path) -> zenpi::core::Agent {
    let session =
        zenpi::session::SessionStore::open_in_workspace(root.join("host.jsonl"), workspace)
            .unwrap();
    let mut agent = zenpi::core::Agent::with_echo(session);
    agent.set_tools(
        ToolRegistry::with_all_builtins().unwrap(),
        ToolContext::new(workspace).unwrap(),
        SideEffectPolicy::all_builtins(),
    );
    let mut policy = zenpi::approval::ApprovalPolicy::default();
    policy.remember("user_shell", zenpi::approval::ApprovalDecision::Allow);
    policy.remember("run_command", zenpi::approval::ApprovalDecision::Allow);
    agent.set_approval_policy(policy);
    agent
}

#[test]
fn host_user_shell_raw_capture_survives_restart_and_keeps_terminal_order() {
    let root = tempdir().unwrap();
    let mut agent = output_host(root.path(), root.path());
    let result = agent
        .run_user_shell_with_cancel(
            "!/usr/bin/yes x | /usr/bin/head -c 400000; printf real-stderr >&2",
            || false,
        )
        .unwrap();
    let refs: Vec<ArtifactRef> =
        serde_json::from_value(result["output_artifacts"].clone()).unwrap();
    assert_eq!(refs.len(), 2);
    assert!(refs.iter().all(|r| r.complete && r.finalized));
    assert!(result["stdout"].as_str().unwrap().len() < 400000);
    let path = agent.session().path().to_owned();
    let sid = agent.session().session_id().to_owned();
    let events = agent.session().events();
    let started = events
        .iter()
        .position(|e| e["type"] == "tool_execution_started")
        .unwrap();
    let capture = events
        .iter()
        .position(|e| e["type"] == "tool_output_captured")
        .unwrap();
    let finished = events
        .iter()
        .position(|e| e["type"] == "tool_execution_finished")
        .unwrap();
    assert!(started < capture && capture < finished);
    drop(agent);
    let reopened = zenpi::session::SessionStore::open_existing_writable(&path).unwrap();
    assert_eq!(
        reopened.events()[capture]["output_capture"]["artifacts"]
            .as_array()
            .unwrap()
            .len(),
        2
    );
    let mut output = SessionOutputStore::default();
    let store = output
        .store(&path, &sid, zenpi::session::unix_time_ms())
        .unwrap();
    let stdout = refs
        .iter()
        .find(|r| r.stream == OutputStream::Stdout)
        .unwrap();
    let mut raw = Vec::new();
    while (raw.len() as u64) < stdout.bytes_stored {
        raw.extend(
            store
                .read_range(
                    stdout,
                    raw.len() as u64,
                    64 * 1024,
                    zenpi::session::unix_time_ms(),
                )
                .unwrap(),
        );
    }
    assert_eq!(raw, b"x\n".repeat(200000));
    assert_eq!(stdout.sha256.as_deref(), Some(digest(&raw).as_str()));
}

#[test]
fn host_capture_disk_reservation_precedes_artifacts_and_shell_effects() {
    let root = tempdir().unwrap();
    let mut agent = output_host(root.path(), root.path());
    agent
        .set_resource_limits(zenpi::governance::ResourceLimits {
            max_disk_bytes: command_disk_reservation(OutputLimits::default()) - 1,
            ..Default::default()
        })
        .unwrap();
    let error = agent
        .run_user_shell_with_cancel("!printf forbidden > effect", || false)
        .unwrap_err();
    assert_eq!(error.code(), "resource_budget_exceeded");
    assert!(!root.path().join("effect").exists());
    assert!(!fs::read_dir(root.path()).unwrap().any(|e| {
        e.unwrap()
            .file_name()
            .to_string_lossy()
            .starts_with(".zenpi-output-")
    }));
    assert!(
        !agent
            .session()
            .events()
            .iter()
            .any(|e| e["type"] == "tool_output_captured")
    );
}

#[test]
fn host_spawn_failure_durably_retains_incomplete_stream_references() {
    let root = tempdir().unwrap();
    let workspace = root.path().join("workspace");
    fs::create_dir(&workspace).unwrap();
    let mut agent = output_host(root.path(), &workspace);
    fs::remove_dir(&workspace).unwrap();
    assert!(
        agent
            .run_user_shell_with_cancel("!printf never-started", || false)
            .is_err()
    );
    let event = agent
        .session()
        .events()
        .iter()
        .find(|e| e["type"] == "tool_output_captured")
        .unwrap();
    let refs: Vec<ArtifactRef> =
        serde_json::from_value(event["output_capture"]["artifacts"].clone()).unwrap();
    assert_eq!(refs.len(), 2);
    assert!(
        refs.iter()
            .all(|r| r.finalized && !r.complete && r.bytes_observed == 0)
    );
    assert!(
        agent
            .session()
            .events()
            .iter()
            .any(|e| e["type"] == "user_shell_error")
    );
}

#[test]
fn real_http_model_command_sends_capture_reference_in_next_request() {
    use serde_json::Value;
    use std::io::{Read, Write};
    let listener = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
    let url = format!("http://{}/v1", listener.local_addr().unwrap());
    let server = std::thread::spawn(move || {
        listener.set_nonblocking(true).unwrap();
        let mut requests = Vec::new();
        for index in 0..2 {
            let deadline = Instant::now() + Duration::from_secs(15);
            let mut stream = loop {
                match listener.accept() {
                    Ok((stream, _)) => break stream,
                    Err(e)
                        if e.kind() == std::io::ErrorKind::WouldBlock
                            && Instant::now() < deadline =>
                    {
                        std::thread::sleep(Duration::from_millis(2))
                    }
                    Err(e) => panic!("HTTP fixture accept: {e}"),
                }
            };
            // Accepted sockets inherit O_NONBLOCK on macOS; use the bounded
            // blocking request reader after the nonblocking accept loop.
            stream.set_nonblocking(false).unwrap();
            stream
                .set_read_timeout(Some(Duration::from_secs(5)))
                .unwrap();
            let mut bytes = Vec::new();
            let request = loop {
                let mut buffer = [0; 4096];
                let n = stream.read(&mut buffer).unwrap();
                assert_ne!(n, 0);
                bytes.extend_from_slice(&buffer[..n]);
                assert!(bytes.len() < 2 * 1024 * 1024);
                if let Some(end) = bytes.windows(4).position(|b| b == b"\r\n\r\n") {
                    let length: usize = std::str::from_utf8(&bytes[..end])
                        .unwrap()
                        .lines()
                        .find_map(|line| {
                            let (key, value) = line.split_once(':')?;
                            key.eq_ignore_ascii_case("content-length")
                                .then(|| value.trim().parse().unwrap())
                        })
                        .unwrap();
                    if bytes.len() >= end + 4 + length {
                        break serde_json::from_slice::<Value>(&bytes[end + 4..end + 4 + length])
                            .unwrap();
                    }
                }
            };
            requests.push(request);
            let delta = if index == 0 {
                json!({"tool_calls":[{"index":0,"id":"actual-output-call","type":"function","function":{"name":"run_command","arguments":"{\"command\":\"printf actual-model-output; while [ ! -f model-release ]; do sleep 0.01; done\"}"}}]})
            } else {
                json!({"content":"done"})
            };
            let body = format!(
                "data: {}\n\ndata: {}\n\ndata: [DONE]\n\n",
                json!({"id":"actual-output","model":"fixture","choices":[{"index":0,"delta":delta,"finish_reason":null}]}),
                json!({"id":"actual-output","model":"fixture","choices":[{"index":0,"delta":{},"finish_reason":if index == 0 {"tool_calls"} else {"stop"}}]})
            );
            write!(stream,"HTTP/1.1 200 OK\r\nContent-Type: text/event-stream\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{body}",body.len()).unwrap();
        }
        requests
    });
    let root = tempdir().unwrap();
    let backend = zenpi::backend::OpenAiCompatibleBackend::from_values_with_wire_api(
        url,
        Some("fixture-only".into()),
        "fixture".into(),
        zenpi::backend::OpenAiWireApi::ChatCompletions,
    )
    .unwrap();
    let session = zenpi::session::SessionStore::open_in_workspace(
        root.path().join("model.jsonl"),
        root.path(),
    )
    .unwrap();
    let mut agent = zenpi::core::Agent::new(session, Box::new(backend));
    agent.set_tools(
        ToolRegistry::with_all_builtins().unwrap(),
        ToolContext::new(root.path()).unwrap(),
        SideEffectPolicy::all_builtins(),
    );
    let mut policy = zenpi::approval::ApprovalPolicy::default();
    policy.remember("run_command", zenpi::approval::ApprovalDecision::Allow);
    agent.set_approval_policy(policy);
    let release = root.path().join("model-release");
    let live = std::sync::Arc::new(std::sync::Mutex::new(Vec::new()));
    let received = live.clone();
    let sink = std::sync::Arc::new(move |event: zenpi::core::AgentEvent| {
        if let zenpi::core::AgentEvent::ToolProgress { progress, .. } = &event
            && progress.snapshot.text.contains("actual-model-output")
        {
            fs::write(&release, b"model tool progress received").unwrap();
        }
        received.lock().unwrap().push(event);
    });
    let began = Instant::now();
    agent
        .with_live_tool_events(sink, |agent| {
            agent.process_with_cancel(
                zenpi::core::TurnInputRequest::new("execute the tool"),
                || began.elapsed() > Duration::from_secs(5),
            )
        })
        .unwrap();
    let live = live.lock().unwrap();
    assert!(matches!(
        live.first(),
        Some(zenpi::core::AgentEvent::ToolCall { .. })
    ));
    assert!(
        live.iter()
            .any(|event| matches!(event, zenpi::core::AgentEvent::ToolProgress { .. }))
    );
    assert!(matches!(
        live.last(),
        Some(zenpi::core::AgentEvent::ToolResult { success: true, .. })
    ));

    let requests = server.join().unwrap();
    let message = requests[1]["messages"]
        .as_array()
        .unwrap()
        .iter()
        .find(|m| m["role"] == "tool")
        .unwrap();
    let payload: Value = serde_json::from_str(message["content"].as_str().unwrap()).unwrap();
    let report: CaptureReport = serde_json::from_value(payload["output_capture"].clone()).unwrap();
    assert_eq!(report.artifacts.len(), 2);
    assert!(
        report
            .artifacts
            .iter()
            .all(|r| r.complete && r.call_id == "actual-output-call")
    );
    let stdout = report
        .artifacts
        .iter()
        .find(|r| r.stream == OutputStream::Stdout)
        .unwrap();
    assert_eq!(
        stdout.sha256.as_deref(),
        Some(digest(b"actual-model-output").as_str())
    );
    let saved = agent
        .history()
        .iter()
        .find(|t| t.role == zenpi::core::TurnRole::Tool)
        .unwrap();
    assert_eq!(
        saved.metadata.as_ref().unwrap()["output_capture"]["artifacts"]
            .as_array()
            .unwrap()
            .len(),
        2
    );
}

#[test]
fn host_close_releases_private_store_lock_without_deleting_history() {
    let root = tempdir().unwrap();
    let mut agent = output_host(root.path(), root.path());
    let result = agent
        .run_user_shell_with_cancel("!printf preserved-on-close", || false)
        .unwrap();
    let refs: Vec<ArtifactRef> =
        serde_json::from_value(result["output_artifacts"].clone()).unwrap();
    agent.try_close().unwrap();
    let mut reader = SessionOutputStore::default();
    let store = reader
        .store(
            agent.session().path(),
            agent.session().session_id(),
            zenpi::session::unix_time_ms(),
        )
        .unwrap();
    let stdout = refs
        .iter()
        .find(|r| r.stream == OutputStream::Stdout)
        .unwrap();
    assert_eq!(
        store
            .read_range(stdout, 0, 64, zenpi::session::unix_time_ms())
            .unwrap(),
        b"preserved-on-close"
    );
    assert_eq!(agent.phase(), zenpi::core::AgentPhase::Closed);
}

#[test]
fn streaming_credentials_are_masked_before_tail_cuts_and_raw_ranges_stay_exact() {
    let secret = "MASK-registered/secret,tail";
    let (_handle, _revoke) = zenpi::security::SecretHandle::new(secret, "a".repeat(64)).unwrap();
    let raw = format!("visible {secret}\nAPI_KEY=\"PRIVATEONE\nPRIVATETWO\\\"PRIVATETHREE\" after\nAuthorization: Bearer opaque\nhttps://user:pass@example.test/path done\n").into_bytes();
    for chunk in [1, 2, 3, 7, 31, 128] {
        let root = tempdir().unwrap();
        let store = OutputArtifactStore::open(root.path().join("raw"), limits()).unwrap();
        let mut writer = store
            .begin("s", "c", OutputStream::Stdout, 100, store.progress_queue())
            .unwrap();
        for part in raw.chunks(chunk) {
            writer.append(part).unwrap();
            let snapshot = writer.snapshot();
            for credential in [
                "MASK-",
                "PRIVATEONE",
                "PRIVATETWO",
                "PRIVATETHREE",
                "opaque",
                "user:pass",
            ] {
                assert!(
                    !snapshot.text.contains(credential),
                    "chunk={chunk} leaked {credential}: {}",
                    snapshot.text
                );
            }
            assert!(snapshot.text.len() <= limits().view_bytes);
            assert!(snapshot.display_end <= snapshot.bytes_observed);
        }
        let reference = writer.finish(true).unwrap();
        assert_eq!(read_all(&store, &reference), raw);
        assert_eq!(reference.sha256.as_deref(), Some(digest(&raw).as_str()));
        let safe = store
            .read_redacted_range(&reference, 0, raw.len(), 101)
            .unwrap();
        assert_eq!(safe.len(), raw.len());
        let text = String::from_utf8(safe.clone()).unwrap();
        assert!(
            text.contains("visible ")
                && text.contains(" after\n")
                && text.contains("example.test/path done")
        );
        for credential in [
            secret,
            "PRIVATEONE",
            "PRIVATETWO",
            "PRIVATETHREE",
            "opaque",
            "user:pass",
        ] {
            assert!(!text.contains(credential));
        }
        let start = 8;
        assert_eq!(&safe[start..start + secret.len()], vec![b'*'; secret.len()]);
        for offset in start..start + secret.len() {
            assert_eq!(
                store
                    .read_redacted_range(&reference, offset as u64, 1, 101)
                    .unwrap(),
                b"*"
            );
        }
    }
}

#[test]
fn overlapping_registered_values_and_credentials_crossing_syntax_boundaries_are_masked() {
    let (_a, _ra) = zenpi::security::SecretHandle::new("abcdef", "b".repeat(64)).unwrap();
    let (_b, _rb) = zenpi::security::SecretHandle::new("defghi", "b".repeat(64)).unwrap();
    let (_c, _rc) = zenpi::security::SecretHandle::new("host.test/path", "b".repeat(64)).unwrap();
    let root = tempdir().unwrap();
    let store = OutputArtifactStore::open(root.path().join("raw"), limits()).unwrap();
    let mut writer = store
        .begin("s", "c", OutputStream::Stdout, 100, store.progress_queue())
        .unwrap();
    let raw = b"abcdefghi https://host.test/path end";
    for part in raw.chunks(2) {
        writer.append(part).unwrap();
    }
    let reference = writer.finish(true).unwrap();
    let safe = store
        .read_redacted_range(&reference, 0, raw.len(), 101)
        .unwrap();
    assert_eq!(safe, b"********* https://************** end");
    assert_eq!(read_all(&store, &reference), raw);
}

#[test]
fn interrupted_credential_prefix_and_oversized_values_never_expose_a_tail() {
    let (_a, _ra) =
        zenpi::security::SecretHandle::new("registered-secret-long", "c".repeat(64)).unwrap();
    let root = tempdir().unwrap();
    let store = OutputArtifactStore::open(root.path().join("raw"), limits()).unwrap();
    let mut writer = store
        .begin("s", "c", OutputStream::Stdout, 100, store.progress_queue())
        .unwrap();
    writer.append(b"registered-secr").unwrap();
    assert_eq!(writer.snapshot().text, "");
    let reference = writer.finish(false).unwrap();
    assert!(writer.snapshot().text.bytes().all(|b| b == b'*'));
    assert_eq!(
        store.read_redacted_range(&reference, 3, 5, 101).unwrap(),
        b"*****"
    );
    let mut writer = store
        .begin("s", "d", OutputStream::Stdout, 100, store.progress_queue())
        .unwrap();
    writer.append(b"password=\"").unwrap();
    for _ in 0..128 {
        writer.append(&[b'x'; 4096]).unwrap();
    }
    assert!(writer.snapshot().text.bytes().all(|b| b == b'*'));
    writer.append(b"\" visible\n").unwrap();
    let reference = writer.finish(true).unwrap();
    assert!(writer.snapshot().text.ends_with(" visible\n"));
    assert_eq!(
        store
            .read_redacted_range(&reference, 8190, 20, 101)
            .unwrap(),
        vec![b'*'; 20]
    );
    let mut forged = reference.clone();
    forged.call_id = "other".into();
    assert!(matches!(
        store.read_redacted_range(&forged, 0, 1, 101),
        Err(OutputError::Integrity)
    ));
}

#[test]
fn live_host_output_precedes_shell_exit_and_sink_is_request_scoped() {
    use std::sync::{Arc, Mutex};
    use zenpi::core::AgentEvent;
    let root = tempdir().unwrap();
    let mut agent = output_host(root.path(), root.path());
    let events = Arc::new(Mutex::new(Vec::new()));
    let observed = events.clone();
    let release = root.path().join("release");
    let sink = Arc::new(move |event: AgentEvent| {
        if let AgentEvent::ToolProgress { progress, .. } = &event
            && progress.snapshot.text.contains("live-first")
        {
            fs::write(&release, b"host saw output before process exit").unwrap();
        }
        observed.lock().unwrap().push(event);
    });
    let started = Instant::now();
    let result = agent.with_live_tool_events(sink, |agent| {
        agent.run_user_shell_with_cancel(
            "!printf live-first; printf live-error >&2; while [ ! -f release ]; do sleep 0.01; done; printf live-last",
            || started.elapsed() > Duration::from_secs(5),
        )
    }).unwrap();
    assert!(result["stdout"].as_str().unwrap().contains("live-last"));
    let events = events.lock().unwrap().clone();
    assert!(matches!(events.first(), Some(AgentEvent::ToolCall { .. })));
    assert!(matches!(
        events.last(),
        Some(AgentEvent::ToolResult { success: true, .. })
    ));
    let progress: Vec<_> = events
        .iter()
        .filter_map(|event| match event {
            AgentEvent::ToolProgress { progress, .. } => Some(progress),
            _ => None,
        })
        .collect();
    assert!(
        progress
            .iter()
            .any(|p| p.stream == OutputStream::Stderr && p.snapshot.text.contains("live-error"))
    );
    assert!(
        progress
            .iter()
            .any(|p| p.snapshot.text.contains("live-last"))
    );
    assert!(agent.take_events().iter().all(|event| !matches!(
        event,
        AgentEvent::ToolCall { .. }
            | AgentEvent::ToolProgress { .. }
            | AgentEvent::ToolResult { .. }
    )));
    agent
        .run_user_shell_with_cancel("!printf next-request", || false)
        .unwrap();
    let deferred = agent.take_events();
    assert!(
        deferred
            .iter()
            .any(|event| matches!(event, AgentEvent::ToolCall { .. }))
    );
    assert!(
        deferred
            .iter()
            .any(|event| matches!(event, AgentEvent::ToolResult { .. }))
    );
}

#[test]
fn live_sink_is_restored_after_error_and_unwind() {
    use std::sync::Arc;
    let root = tempdir().unwrap();
    let mut agent = output_host(root.path(), root.path());
    let fired = Arc::new(AtomicBool::new(false));
    let flag = fired.clone();
    let sink: Arc<dyn Fn(zenpi::core::AgentEvent) + Send + Sync> = Arc::new(move |_| {
        flag.store(true, Ordering::SeqCst);
    });
    let error = agent.with_live_tool_events(sink.clone(), |agent| {
        agent.run_user_shell_with_cancel("not shell", || false)
    });
    assert!(error.is_err());
    let unwind = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        agent.with_live_tool_events(sink, |_| panic!("fixture unwind"));
    }));
    assert!(unwind.is_err());
    fired.store(false, Ordering::SeqCst);
    agent
        .run_user_shell_with_cancel("!printf after-unwind", || false)
        .unwrap();
    assert!(!fired.load(Ordering::SeqCst));
    assert!(
        agent
            .take_events()
            .iter()
            .any(|e| matches!(e, zenpi::core::AgentEvent::ToolResult { .. }))
    );
}

#[test]
fn async_jsonl_delivers_canonical_output_before_shell_exit() {
    use std::io::{BufRead, BufReader, Write};
    use std::os::unix::net::UnixStream;
    let root = tempdir().unwrap();
    let agent = output_host(root.path(), root.path());
    let (mut input, reader) = UnixStream::pair().unwrap();
    let (writer, output) = UnixStream::pair().unwrap();
    output
        .set_read_timeout(Some(Duration::from_secs(10)))
        .unwrap();
    let host =
        std::thread::spawn(move || zenpi::headless::run_async_streams(agent, reader, writer));
    writeln!(input, "{}", json!({"schema_version":2,"id":"live-shell","type":"user_shell",
        "text":"!printf jsonl-first; while [ ! -f jsonl-release ]; do sleep 0.01; done; printf jsonl-last"})).unwrap();
    let mut output = BufReader::new(output);
    let mut records = Vec::new();
    let mut saw_live = false;
    loop {
        let mut line = String::new();
        let read = output.read_line(&mut line);
        if read.as_ref().is_err() || matches!(read, Ok(0)) {
            // Release the child even when a regression prevents live delivery.
            fs::write(root.path().join("jsonl-release"), b"test cleanup").unwrap();
            drop(input);
            let _ = host.join();
            panic!("missing bounded JSONL progress/terminal: {read:?}; {records:?}");
        }
        let record: serde_json::Value = serde_json::from_str(&line).unwrap();
        if record["event"]["type"] == "tool_progress"
            && record["event"]["progress"]["snapshot"]["text"]
                .as_str()
                .is_some_and(|s| s.contains("jsonl-first"))
        {
            if !saw_live {
                assert!(
                    !record["event"]["progress"]["snapshot"]["text"]
                        .as_str()
                        .unwrap()
                        .contains("jsonl-last")
                );
            }
            assert_eq!(record["request_id"], "live-shell");
            assert_eq!(record["event"]["block"]["kind"], "tool_status");
            fs::write(root.path().join("jsonl-release"), b"wire received output").unwrap();
            saw_live = true;
        }
        let terminal = record["type"] == "response" && record["id"] == "live-shell";
        records.push(record);
        if terminal {
            break;
        }
    }
    assert!(saw_live, "progress must reach JSONL before shell can exit");
    assert!(
        records.last().unwrap()["data"]["stdout"]
            .as_str()
            .unwrap()
            .contains("jsonl-last")
    );
    let last_progress = records
        .iter()
        .rposition(|r| r["event"]["type"] == "tool_progress")
        .unwrap();
    let finished = records
        .iter()
        .position(|r| r["event"]["type"] == "tool_result")
        .unwrap();
    assert!(last_progress < finished);
    drop(input);
    host.join().unwrap().unwrap();
}

#[test]
fn final_store_drop_releases_lock_even_while_a_fork_child_retains_descriptor() {
    let root = tempdir().unwrap();
    let path = root.path().join("raw");
    let store = OutputArtifactStore::open(&path, limits()).unwrap();
    let mut pipe = [0; 2];
    assert_eq!(unsafe { libc::pipe(pipe.as_mut_ptr()) }, 0);
    let pid = unsafe { libc::fork() };
    assert!(pid >= 0);
    if pid == 0 {
        // Only async-signal-safe operations between fork and _exit. This
        // reproduces the descriptor inheritance window before a tool exec.
        unsafe {
            libc::close(pipe[1]);
            libc::alarm(5);
            let mut byte = 0u8;
            libc::read(pipe[0], (&mut byte as *mut u8).cast(), 1);
            libc::_exit(0);
        }
    }
    unsafe {
        libc::close(pipe[0]);
    }
    drop(store);
    let reopened = OutputArtifactStore::open(&path, limits());
    let mut status = 0;
    unsafe {
        libc::write(pipe[1], b"x".as_ptr().cast(), 1);
        libc::close(pipe[1]);
        libc::waitpid(pid, &mut status, 0);
    }
    assert_eq!(status, 0);
    assert!(
        reopened.is_ok(),
        "fork must not extend the host's store lease: {reopened:?}"
    );
}
/// Public model/host owner regression; root live-progress tests are independent.
mod public_owner {
    use super::*;
    use zenpi::core::Agent;
    use zenpi::protocol::{OutputAction, OutputRequest};
    use zenpi::session::SessionStore;
    fn request(r: &ArtifactRef, offset: u64, length: usize) -> OutputReadRequest {
        OutputReadRequest {
            artifact_id: r.artifact_id.clone(),
            call_id: r.call_id.clone(),
            offset,
            length,
        }
    }
    fn stdout(value: serde_json::Value) -> ArtifactRef {
        serde_json::from_value::<Vec<ArtifactRef>>(value["output_artifacts"].clone())
            .unwrap()
            .into_iter()
            .find(|r| r.stream == OutputStream::Stdout)
            .unwrap()
    }
    fn raw_dir(root: &std::path::Path, sid: &str) -> std::path::PathBuf {
        root.join(format!(".zenpi-output-{}", digest(sid.as_bytes())))
    }
    fn control(sid: &str, action: OutputAction) -> OutputRequest {
        OutputRequest {
            schema_version: 2,
            id: "output-control".into(),
            kind: "tool_output".into(),
            session_id: sid.into(),
            output: action,
        }
    }
    #[test]
    fn general_search_never_traverses_private_output_directories() {
        let root = tempdir().unwrap();
        let mut agent = output_host(root.path(), root.path());
        let reference = stdout(
            agent
                .run_user_shell_with_cancel("!printf RAW_OUTPUT_ONLY_NEEDLE", || false)
                .unwrap(),
        );
        assert!(
            raw_dir(root.path(), agent.session().session_id())
                .join(format!("{}.raw", reference.artifact_id))
                .exists()
        );
        fs::write(root.path().join("visible.txt"), "RAW_OUTPUT_ONLY_NEEDLE").unwrap();
        let registry = ToolRegistry::with_all_builtins().unwrap();
        let context = ToolContext::new(root.path()).unwrap();
        for (name, arguments) in [
            (
                "search_text",
                json!({"path":".","query":"RAW_OUTPUT_ONLY_NEEDLE"}),
            ),
            (
                "search_text",
                json!({"path":".","query":"RAW_OUTPUT_ONLY_NEEDLE","regex":true,"hidden":true,"ignore":false}),
            ),
            (
                "find",
                json!({"path":".","pattern":"*","hidden":true,"ignore":false}),
            ),
        ] {
            let result = registry.execute(
                &context,
                SideEffectPolicy::all_builtins(),
                ToolCall {
                    id: format!("boundary-{name}"),
                    name: name.into(),
                    arguments,
                },
            );
            let encoded = serde_json::to_string(&result).unwrap();
            assert!(matches!(result, ToolResult::Success { .. }), "{encoded}");
            assert!(encoded.contains("visible.txt"), "{encoded}");
            assert!(
                !encoded.contains(".zenpi-output-"),
                "private output traversed: {encoded}"
            );
        }
    }
    #[test]
    fn actual_shell_restart_public_read_and_explicit_cleanup() {
        let root = tempdir().unwrap();
        let mut agent = output_host(root.path(), root.path());
        let first=stdout(agent.run_user_shell_with_cancel("!printf 'api_key=private-output-token\n'; /usr/bin/yes x | /usr/bin/head -c 100000",||false).unwrap());
        let second = stdout(
            agent
                .run_user_shell_with_cancel("!printf keep-other-call", || false)
                .unwrap(),
        );
        let sid = agent.session().session_id().to_owned();
        let path = agent.session().path().to_owned();
        let result = agent
            .read_tool_output(request(&first, 8, 12), &|| false)
            .unwrap();
        assert_eq!(result.text, "************");
        assert_eq!((result.raw_start, result.raw_end), (8, 20));
        assert!(result.redacted && !result.eof);
        assert!(matches!(
            agent.read_tool_output(request(&first, 0, 8193), &|| false),
            Err(OutputError::Invalid(_))
        ));
        assert!(matches!(
            agent.read_tool_output(request(&first, 0, 8), &|| true),
            Err(OutputError::Cancelled)
        ));
        agent.try_close().unwrap();
        drop(agent);
        assert!(
            raw_dir(root.path(), &sid)
                .join(format!("{}.raw", first.artifact_id))
                .exists()
        );
        let session = SessionStore::open_existing_writable(&path).unwrap();
        let mut agent = Agent::with_echo(session);
        assert_eq!(
            agent
                .read_tool_output(request(&first, 8, 12), &|| false)
                .unwrap(),
            result
        );
        let denied = control(
            &sid,
            OutputAction::Cleanup {
                call_id: Some(first.call_id.clone()),
                confirm: false,
            },
        );
        assert!(agent.tool_output_control(denied, &|| false).is_err());
        assert_eq!(
            agent
                .tool_output_control(
                    control(
                        &sid,
                        OutputAction::Cleanup {
                            call_id: Some(first.call_id.clone()),
                            confirm: true
                        }
                    ),
                    &|| false
                )
                .unwrap()["removed"],
            2
        );
        assert!(matches!(
            agent.read_tool_output(request(&first, 0, 4), &|| false),
            Err(OutputError::Missing)
        ));
        assert_eq!(
            agent
                .read_tool_output(request(&second, 0, 20), &|| false)
                .unwrap()
                .text,
            "keep-other-call"
        );
        assert_eq!(agent.cleanup_tool_output(None).unwrap(), 2);
        assert_eq!(agent.cleanup_tool_output(None).unwrap(), 0);
        assert!(
            agent
                .session()
                .events()
                .iter()
                .any(|e| e["type"] == "tool_output_cleanup")
        );
    }
    #[test]
    fn model_cannot_supply_paths_authority_or_another_sessions_reference() {
        let root = tempdir().unwrap();
        let mut a = output_host(root.path(), root.path());
        let r = stdout(
            a.run_user_shell_with_cancel("!printf protected", || false)
                .unwrap(),
        );
        let mut forged = request(&r, 0, 9);
        forged.call_id = "foreign-call".into();
        assert!(matches!(
            a.read_tool_output(forged, &|| false),
            Err(OutputError::Integrity)
        ));
        let other = tempdir().unwrap();
        let mut b = output_host(other.path(), other.path());
        assert!(matches!(
            b.read_tool_output(request(&r, 0, 9), &|| false),
            Err(OutputError::Invalid(_))
        ));
        assert!(
            a.tool_output_control(
                control(
                    b.session().session_id(),
                    OutputAction::Cleanup {
                        call_id: None,
                        confirm: true
                    }
                ),
                &|| false
            )
            .is_err()
        );
        let mut json = serde_json::to_value(request(&r, 0, 9)).unwrap();
        json["path"] = json!("/tmp/forged.raw");
        assert!(serde_json::from_value::<OutputReadRequest>(json.clone()).is_err());
        let registry = ToolRegistry::with_all_builtins().unwrap();
        let context = ToolContext::new(root.path()).unwrap();
        let result = registry.execute(
            &context,
            SideEffectPolicy::all_builtins(),
            ToolCall {
                id: "read-only-test".into(),
                name: "read_tool_output".into(),
                arguments: serde_json::to_value(request(&r, 0, 9)).unwrap(),
            },
        );
        assert!(matches!(result, ToolResult::Error { .. }));
        let directory = raw_dir(root.path(), a.session().session_id());
        let raw = directory.join(format!("{}.raw", r.artifact_id));
        std::os::unix::fs::symlink(&raw, root.path().join("innocent.txt")).unwrap();
        for path in [
            raw.strip_prefix(root.path()).unwrap().to_str().unwrap(),
            "innocent.txt",
        ] {
            let result = registry.execute(
                &context,
                SideEffectPolicy::all_builtins(),
                ToolCall {
                    id: "bypass".into(),
                    name: "read_file".into(),
                    arguments: json!({"path":path}),
                },
            );
            assert!(matches!(
                result,
                ToolResult::Error {
                    error: ToolFailure {
                        code: ToolErrorCode::PathDenied,
                        ..
                    },
                    ..
                }
            ));
        }
    }
    #[test]
    fn journal_reference_pins_hash_even_if_metadata_and_bytes_are_replaced_together() {
        let root = tempdir().unwrap();
        let mut agent = output_host(root.path(), root.path());
        let r = stdout(
            agent
                .run_user_shell_with_cancel("!printf original", || false)
                .unwrap(),
        );
        let dir = raw_dir(root.path(), agent.session().session_id());
        fs::write(dir.join(format!("{}.raw", r.artifact_id)), b"modified").unwrap();
        let mut replacement = r.clone();
        replacement.sha256 = Some(digest(b"modified"));
        fs::write(
            dir.join(format!("{}.json", r.artifact_id)),
            serde_json::to_vec(&replacement).unwrap(),
        )
        .unwrap();
        assert!(matches!(
            agent.read_tool_output(request(&r, 0, 8), &|| false),
            Err(OutputError::Integrity)
        ));
    }
    fn journal_fixture(
        root: &std::path::Path,
        now: u64,
        dispatched: bool,
        bytes: &[u8],
    ) -> (Agent, ArtifactRef) {
        let mut session =
            SessionStore::open_in_workspace(root.join("fixture.jsonl"), root).unwrap();
        let mut output = SessionOutputStore::default();
        let store = output
            .store(session.path(), session.session_id(), now)
            .unwrap();
        let mut writer = store
            .begin(
                session.session_id(),
                "fixture-call",
                OutputStream::Stdout,
                now,
                store.progress_queue(),
            )
            .unwrap();
        writer.append(bytes).unwrap();
        let r = writer.finish(true).unwrap();
        if dispatched {
            session.append_event(json!({"type":"tool_execution_started","operation_id":"fixture-operation","turn_id":"fixture-turn","call_id":"fixture-call","tool":"run_command"})).unwrap();
        }
        session.append_event(json!({"type":"tool_output_captured","operation_id":"fixture-operation","turn_id":"fixture-turn","call_id":"fixture-call","output_capture":{"artifacts":[r],"errors":[]}})).unwrap();
        drop(writer);
        drop(store);
        drop(output);
        (Agent::with_echo(session), r)
    }
    #[test]
    fn expired_missing_uncorrelated_and_binary_ranges_are_visible_and_bounded() {
        let old = tempdir().unwrap();
        let (mut expired, r) = journal_fixture(old.path(), 100, true, b"expired");
        assert!(matches!(
            expired.read_tool_output(request(&r, 0, 7), &|| false),
            Err(OutputError::Expired)
        ));
        let bad = tempdir().unwrap();
        let (mut uncorrelated, r) = journal_fixture(
            bad.path(),
            zenpi::session::unix_time_ms(),
            false,
            b"untrusted",
        );
        assert!(matches!(
            uncorrelated.read_tool_output(request(&r, 0, 7), &|| false),
            Err(OutputError::Integrity)
        ));
        let bin = tempdir().unwrap();
        let (mut binary, r) = journal_fixture(
            bin.path(),
            zenpi::session::unix_time_ms(),
            true,
            &vec![0; 16384],
        );
        let read = binary
            .read_tool_output(request(&r, 0, 8192), &|| false)
            .unwrap();
        assert_eq!(read.text.len(), 8192);
        assert!(!read.lossy);
        assert!(serde_json::to_vec(&read).unwrap().len() < 65536);
        let file = raw_dir(bin.path(), binary.session().session_id())
            .join(format!("{}.raw", r.artifact_id));
        fs::remove_file(&file).unwrap();
        assert!(matches!(
            binary.read_tool_output(request(&r, 0, 1), &|| false),
            Err(OutputError::Missing)
        ));
        assert!(!file.exists());
        let broken = tempdir().unwrap();
        let (mut broken, r) = journal_fixture(
            broken.path(),
            zenpi::session::unix_time_ms(),
            true,
            b"\xff\x00ok",
        );
        let reply = broken
            .read_tool_output(request(&r, 0, 4), &|| false)
            .unwrap();
        assert!(reply.lossy);
        assert_eq!(reply.raw_end, 4);
    }
    #[test]
    fn tree_fork_copied_history_does_not_grant_source_output_authority() {
        let root = tempdir().unwrap();
        let mut agent = output_host(root.path(), root.path());
        let r = stdout(
            agent
                .run_user_shell_with_cancel("!printf source-only", || false)
                .unwrap(),
        );
        let tree = agent.session().tree_snapshot(&|| false).unwrap();
        let fork = agent
            .session()
            .fork_at_tree_leaf(tree.active_leaf(), root.path().join("fork.jsonl"), &|| {
                false
            })
            .unwrap();
        assert_ne!(fork.session_id(), agent.session().session_id());
        assert!(
            !fork
                .events()
                .iter()
                .any(|e| e["type"] == "tool_output_captured")
        );
        let mut fork = Agent::with_echo(fork);
        assert!(matches!(
            fork.read_tool_output(request(&r, 0, 11), &|| false),
            Err(OutputError::Invalid(_))
        ));
        assert_eq!(
            agent
                .read_tool_output(request(&r, 0, 11), &|| false)
                .unwrap()
                .text,
            "source-only"
        );
    }
    #[test]
    fn incomplete_prefix_keeps_status_and_absent_root_is_not_created() {
        let root = tempdir().unwrap();
        let mut agent = output_host(root.path(), root.path());
        let start = Instant::now();
        let observed = std::cell::Cell::new(None::<Instant>);
        let marker = root.path().join("prefix-ready");
        let value = agent
            .run_user_shell_with_cancel(
                "!printf 'saved-prefix\\n'; touch prefix-ready; sleep 10",
                || {
                    if marker.exists() && observed.get().is_none() {
                        observed.set(Some(Instant::now()));
                    }
                    observed
                        .get()
                        .is_some_and(|at| at.elapsed() > Duration::from_millis(100))
                        || start.elapsed() > Duration::from_secs(5)
                },
            )
            .unwrap();
        let r = stdout(value);
        assert!(!r.complete);
        assert!(r.finalized);
        let reply = agent
            .read_tool_output(request(&r, 0, 8192), &|| false)
            .unwrap();
        assert!(!reply.complete);
        assert_eq!(reply.text, "saved-prefix\n");
        assert!(reply.eof);
        let path = agent.session().path().to_owned();
        let dir = raw_dir(root.path(), agent.session().session_id());
        agent.try_close().unwrap();
        drop(agent);
        fs::remove_dir_all(&dir).unwrap();
        let mut restarted = Agent::with_echo(SessionStore::open_existing_writable(&path).unwrap());
        assert!(matches!(
            restarted.read_tool_output(request(&r, 0, 1), &|| false),
            Err(OutputError::Missing)
        ));
        assert!(!dir.exists());
    }
    #[test]
    fn typed_wire_and_shared_slash_enforce_bounds_and_explicit_cleanup() {
        let read = format!("/output read {} call 0 8192", "a".repeat(64));
        assert!(zenpi::slash::output_control(&read).unwrap().is_ok());
        for bad in [
            read.replace("8192", "8193"),
            read.replace("8192", "0"),
            "/output cleanup".into(),
            "/output cleanup call".into(),
        ] {
            assert!(zenpi::slash::output_control(&bad).unwrap().is_err());
        }
        assert!(
            zenpi::slash::output_control("/output cleanup call --yes")
                .unwrap()
                .is_ok()
        );
        let mut wire = serde_json::to_value(control(
            "session",
            OutputAction::Read {
                artifact_id: "a".repeat(64),
                call_id: "call".into(),
                offset: 0,
                length: 1,
            },
        ))
        .unwrap();
        assert!(zenpi::protocol::parse_line(&wire.to_string()).is_ok());
        wire["output"]["path"] = json!("/tmp/raw");
        assert!(zenpi::protocol::parse_line(&wire.to_string()).is_err());
    }
}

#[test]
fn public_model_reader_uses_real_http_reference_and_redacts_selected_raw_range() {
    use serde_json::Value;
    use std::io::{Read, Write};
    let listener = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
    let url = format!("http://{}/v1", listener.local_addr().unwrap());
    let server = std::thread::spawn(move || {
        listener.set_nonblocking(true).unwrap();
        let mut requests = Vec::new();
        for index in 0..4 {
            let deadline = Instant::now() + Duration::from_secs(15);
            let mut stream = loop {
                match listener.accept() {
                    Ok((stream, _)) => break stream,
                    Err(e)
                        if e.kind() == std::io::ErrorKind::WouldBlock
                            && Instant::now() < deadline =>
                    {
                        std::thread::sleep(Duration::from_millis(2))
                    }
                    Err(e) => panic!("HTTP fixture accept: {e}"),
                }
            };
            // Accepted sockets inherit O_NONBLOCK on macOS; use the bounded
            // blocking request reader after the nonblocking accept loop.
            stream.set_nonblocking(false).unwrap();
            stream
                .set_read_timeout(Some(Duration::from_secs(5)))
                .unwrap();
            let mut bytes = Vec::new();
            let request = loop {
                let mut buffer = [0; 4096];
                let n = stream.read(&mut buffer).unwrap();
                assert_ne!(n, 0);
                bytes.extend_from_slice(&buffer[..n]);
                assert!(bytes.len() < 2 * 1024 * 1024);
                if let Some(end) = bytes.windows(4).position(|b| b == b"\r\n\r\n") {
                    let length: usize = std::str::from_utf8(&bytes[..end])
                        .unwrap()
                        .lines()
                        .find_map(|line| {
                            let (key, value) = line.split_once(':')?;
                            key.eq_ignore_ascii_case("content-length")
                                .then(|| value.trim().parse().unwrap())
                        })
                        .unwrap();
                    if bytes.len() >= end + 4 + length {
                        break serde_json::from_slice::<Value>(&bytes[end + 4..end + 4 + length])
                            .unwrap();
                    }
                }
            };
            assert!(
                request["tools"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .any(|t| t["function"]["name"] == "read_tool_output")
            );
            requests.push(request);
            let delta = if index == 0 {
                json!({"tool_calls":[{"index":0,"id":"actual-output-call","type":"function","function":{"name":"run_command","arguments":"{\"command\":\"printf 'api_key=model-reader-private-token\\n'; /usr/bin/yes x | /usr/bin/head -c 100000\"}"}}]})
            } else if index == 1 || index == 2 {
                if index == 2 {
                    let last = requests[2]["messages"]
                        .as_array()
                        .unwrap()
                        .iter()
                        .rev()
                        .find(|m| m["role"] == "tool")
                        .unwrap();
                    let failure: Value =
                        serde_json::from_str(last["content"].as_str().unwrap()).unwrap();
                    assert_eq!(failure["status"], "error");
                    assert_eq!(failure["call_id"], "forged-read-call");
                }
                let message = requests[1]["messages"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .rev()
                    .find(|m| m["role"] == "tool")
                    .unwrap();
                let payload: Value =
                    serde_json::from_str(message["content"].as_str().unwrap()).unwrap();
                let report: CaptureReport =
                    serde_json::from_value(payload["output_capture"].clone()).unwrap();
                let r = report
                    .artifacts
                    .iter()
                    .find(|r| r.stream == OutputStream::Stdout)
                    .unwrap();
                assert!(r.bytes_stored > 65536);
                let mut args =
                    json!({"artifact_id":r.artifact_id,"call_id":r.call_id,"offset":8,"length":12});
                if index == 1 {
                    args["path"] = json!("/tmp/model-chosen.raw");
                }
                json!({"tool_calls":[{"index":0,"id":if index==1 {"forged-read-call"}else{"actual-read-call"},"type":"function","function":{"name":"read_tool_output","arguments":args.to_string()}}]})
            } else {
                let message = requests[3]["messages"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .rev()
                    .find(|m| m["role"] == "tool")
                    .unwrap();
                let payload: Value =
                    serde_json::from_str(message["content"].as_str().unwrap()).unwrap();
                assert_eq!(
                    payload["output"]["text"], "************",
                    "payload: {payload}"
                );
                assert_eq!(payload["output"]["raw_start"], 8);
                assert_eq!(payload["output"]["raw_end"], 20);
                assert_eq!(payload["output"]["redacted"], true);
                assert!(!message.to_string().contains("model-reader-private-token"));
                json!({"content":"done"})
            };
            let body = format!(
                "data: {}\n\ndata: {}\n\ndata: [DONE]\n\n",
                json!({"id":"actual-output","model":"fixture","choices":[{"index":0,"delta":delta,"finish_reason":null}]}),
                json!({"id":"actual-output","model":"fixture","choices":[{"index":0,"delta":{},"finish_reason":if index < 3 {"tool_calls"} else {"stop"}}]})
            );
            write!(stream,"HTTP/1.1 200 OK\r\nContent-Type: text/event-stream\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{body}",body.len()).unwrap();
        }
        requests
    });
    let root = tempdir().unwrap();
    let backend = zenpi::backend::OpenAiCompatibleBackend::from_values_with_wire_api(
        url,
        Some("fixture-only".into()),
        "fixture".into(),
        zenpi::backend::OpenAiWireApi::ChatCompletions,
    )
    .unwrap();
    let session = zenpi::session::SessionStore::open_in_workspace(
        root.path().join("model.jsonl"),
        root.path(),
    )
    .unwrap();
    let mut agent = zenpi::core::Agent::new(session, Box::new(backend));
    agent.set_tools(
        ToolRegistry::with_all_builtins().unwrap(),
        ToolContext::new(root.path()).unwrap(),
        SideEffectPolicy::all_builtins(),
    );
    let mut policy = zenpi::approval::ApprovalPolicy::default();
    policy.remember("run_command", zenpi::approval::ApprovalDecision::Allow);
    agent.set_approval_policy(policy);
    agent.process_sync("execute the tool").unwrap();
    let requests = server.join().unwrap();
    let message = requests[1]["messages"]
        .as_array()
        .unwrap()
        .iter()
        .find(|m| m["role"] == "tool")
        .unwrap();
    let payload: Value = serde_json::from_str(message["content"].as_str().unwrap()).unwrap();
    let report: CaptureReport = serde_json::from_value(payload["output_capture"].clone()).unwrap();
    assert_eq!(report.artifacts.len(), 2);
    assert!(
        report
            .artifacts
            .iter()
            .all(|r| r.complete && r.call_id == "actual-output-call")
    );
    let stdout = report
        .artifacts
        .iter()
        .find(|r| r.stream == OutputStream::Stdout)
        .unwrap();
    assert!(stdout.bytes_stored > 65536);
    let saved = agent
        .history()
        .iter()
        .find(|t| t.role == zenpi::core::TurnRole::Tool)
        .unwrap();
    assert_eq!(
        saved.metadata.as_ref().unwrap()["output_capture"]["artifacts"]
            .as_array()
            .unwrap()
            .len(),
        2
    );
}

mod output_alias {
    use serde_json::json;
    use std::{fs, path::Path};
    use tempfile::tempdir;
    use zenpi::{tool_output::*, tools::*};
    const PRIVATE: &str = "output-alias-private-canary";
    fn capture(root: &Path) -> std::path::PathBuf {
        let private = root.join(".zenpi-output-fixture");
        let store = OutputArtifactStore::open(&private, OutputLimits::default()).unwrap();
        let mut writer = store
            .begin(
                "session",
                PRIVATE,
                OutputStream::Stdout,
                100,
                store.progress_queue(),
            )
            .unwrap();
        writer.append(PRIVATE.as_bytes()).unwrap();
        let r = writer.finish(true).unwrap();
        let raw = private.join(format!("{}.raw", r.artifact_id));
        fs::hard_link(&raw, root.join("alias.txt")).unwrap();
        fs::hard_link(raw.with_extension("json"), root.join("metadata-alias.txt")).unwrap();
        raw
    }
    #[test]
    fn raw_hardlink_alias_cannot_read_attach_or_preview_write() {
        let root = tempdir().unwrap();
        capture(root.path());
        let context = ToolContext::new(root.path()).unwrap();
        for name in ["alias.txt", "metadata-alias.txt"] {
            assert!(matches!(
                ReadFileTool.invoke(&context, json!({"path":name}).as_object().unwrap()),
                Err(ToolError::PathDenied(_))
            ));
            assert!(context.read_attachment(name, 16384).is_err());
            assert!(
                WriteFileTool::preview(
                    &context,
                    json!({"path":name,"content":"replacement"})
                        .as_object()
                        .unwrap()
                )
                .is_err()
            );
            assert!(
                WriteFileTool
                    .invoke(
                        &context,
                        json!({"path":name,"content":"replacement"})
                            .as_object()
                            .unwrap()
                    )
                    .is_err()
            );
        }
    }

    #[test]
    fn raw_hardlink_alias_is_absent_from_literal_search() {
        let root = tempdir().unwrap();
        capture(root.path());
        let context = ToolContext::new(root.path()).unwrap();
        let result = SearchTextTool
            .invoke(
                &context,
                json!({"path":".","query":PRIVATE}).as_object().unwrap(),
            )
            .unwrap();
        assert!(
            result["matches"].as_array().unwrap().is_empty(),
            "private bytes escaped through literal search"
        );
    }
    #[test]
    fn raw_hardlink_alias_is_absent_from_regex_and_find_even_with_explicit_glob() {
        let root = tempdir().unwrap();
        capture(root.path());
        let context = ToolContext::new(root.path()).unwrap();
        let result=SearchTextTool.invoke(&context,json!({"query":PRIVATE,"regex":true,"glob":"*alias.txt","hidden":true,"ignore":false}).as_object().unwrap()).unwrap();
        assert!(
            result["matches"].as_array().unwrap().is_empty(),
            "private bytes escaped through regex search"
        );
        let result = FindFilesTool
            .invoke(
                &context,
                json!({"pattern":"*alias.txt","hidden":true,"ignore":false})
                    .as_object()
                    .unwrap(),
            )
            .unwrap();
        assert!(
            result["paths"].as_array().unwrap().is_empty(),
            "private alias escaped find"
        );
    }
    #[test]
    fn private_inode_stays_denied_after_original_unlink_and_independent_process_restart() {
        let root = tempdir().unwrap();
        let raw = capture(root.path());
        fs::remove_file(raw.with_extension("json")).unwrap();
        fs::remove_file(raw).unwrap();
        use std::os::unix::fs::MetadataExt;
        assert_eq!(
            fs::metadata(root.path().join("alias.txt")).unwrap().nlink(),
            1
        );
        let status = std::process::Command::new(std::env::current_exe().unwrap())
            .args(["--exact", "output_alias::alias_restart_helper", "--ignored"])
            .env("ZENPI_ALIAS_TEST_ROOT", root.path())
            .status()
            .unwrap();
        assert!(
            status.success(),
            "new process must reject private inode without any in-memory registry"
        );
    }
    #[test]
    #[ignore = "independent process fixture"]
    fn alias_restart_helper() {
        let context = ToolContext::new(std::env::var("ZENPI_ALIAS_TEST_ROOT").unwrap()).unwrap();
        for name in ["alias.txt", "metadata-alias.txt"] {
            assert!(matches!(
                ReadFileTool.invoke(&context, json!({"path":name}).as_object().unwrap()),
                Err(ToolError::PathDenied(_))
            ));
        }
    }

    #[test]
    fn ordinary_workspace_hardlinks_remain_readable_and_searchable() {
        let root = tempdir().unwrap();
        fs::write(root.path().join("ordinary.txt"), "ordinary-content").unwrap();
        fs::hard_link(
            root.path().join("ordinary.txt"),
            root.path().join("alias.txt"),
        )
        .unwrap();
        let context = ToolContext::new(root.path()).unwrap();
        assert!(
            WriteFileTool::preview(
                &context,
                json!({"path":"alias.txt","content":"ordinary-updated"})
                    .as_object()
                    .unwrap()
            )
            .is_ok()
        );
        assert_eq!(
            ReadFileTool
                .invoke(&context, json!({"path":"alias.txt"}).as_object().unwrap())
                .unwrap()["content"],
            "ordinary-content"
        );
        assert!(SearchTextTool.invoke(&context,json!({"query":"ordinary-content","regex":true,"glob":"*alias.txt","hidden":true,"ignore":false}).as_object().unwrap()).unwrap()["matches"].to_string().contains("ordinary-content"));
        assert!(
            FindFilesTool
                .invoke(
                    &context,
                    json!({"pattern":"*alias.txt","hidden":true,"ignore":false})
                        .as_object()
                        .unwrap()
                )
                .unwrap()["paths"]
                .to_string()
                .contains("alias.txt")
        );
    }
}

#[test]
fn cleanup_journal_failure_preserves_output_until_intent_is_durable() {
    let root = tempdir().unwrap();
    let mut agent = output_host(root.path(), root.path());
    let value = agent
        .run_user_shell_with_cancel("!printf cleanup-owned-fixture", || false)
        .unwrap();
    let refs: Vec<ArtifactRef> = serde_json::from_value(value["output_artifacts"].clone()).unwrap();
    let path = agent.session().path().to_path_buf();
    let backup = root.path().join("journal-backup");
    fs::rename(&path, &backup).unwrap();
    fs::create_dir(&path).unwrap();
    let error = agent.cleanup_tool_output(None).unwrap_err();
    fs::remove_dir(&path).unwrap();
    fs::rename(&backup, &path).unwrap();
    for r in &refs {
        assert!(
            agent
                .read_tool_output(
                    OutputReadRequest {
                        artifact_id: r.artifact_id.clone(),
                        call_id: r.call_id.clone(),
                        offset: 0,
                        length: 64
                    },
                    &|| false
                )
                .is_ok(),
            "failed intent must leave output readable; cleanup error: {error}"
        );
    }
    assert_eq!(agent.cleanup_tool_output(None).unwrap(), refs.len());
    assert_eq!(agent.cleanup_tool_output(None).unwrap(), 0);
}

#[test]
fn cleanup_retirements_keep_quota_until_receipted_and_do_not_expire_unknown_results() {
    let root = tempdir().unwrap();
    let path = root.path().join("raw");
    let mut bounded = limits();
    bounded.max_files = 1;
    let store = OutputArtifactStore::open(&path, bounded).unwrap();
    let mut writer = store
        .begin("s", "c", OutputStream::Stdout, 100, store.progress_queue())
        .unwrap();
    writer.append(b"retained").unwrap();
    assert!(
        store.cleanup_plan("s", None).unwrap().is_empty(),
        "active writer excluded"
    );
    let reference = writer.finish(true).unwrap();
    drop(writer);
    let plan = store.cleanup_plan("s", None).unwrap();
    let ids = store.cleanup_receipted("s", None, &plan).unwrap();
    assert_eq!(ids, vec![reference.artifact_id.clone()]);
    assert!(matches!(
        store.begin(
            "s",
            "next",
            OutputStream::Stdout,
            101,
            store.progress_queue()
        ),
        Err(OutputError::Quota)
    ));
    assert_eq!(store.cleanup_expired(u64::MAX).unwrap(), 0);
    assert!(
        path.join(format!("{}.cleanup", reference.artifact_id))
            .exists()
    );
    drop(store);
    let store = OutputArtifactStore::open(&path, bounded).unwrap();
    assert_eq!(store.cleanup_receipted("s", None, &plan).unwrap(), ids);
    store
        .acknowledge_cleanup("s", &ids.into_iter().collect())
        .unwrap();
    assert_eq!(fs::read_dir(&path).unwrap().count(), 0);
    assert!(
        store
            .begin(
                "s",
                "next",
                OutputStream::Stdout,
                102,
                store.progress_queue()
            )
            .is_ok()
    );
}

#[test]
fn cleanup_retirement_before_unlink_recovers_and_acked_records_are_not_counted_again() {
    let root = tempdir().unwrap();
    let path = root.path().join("raw");
    let store = OutputArtifactStore::open(&path, limits()).unwrap();
    let mut writer = store
        .begin("s", "c", OutputStream::Stdout, 100, store.progress_queue())
        .unwrap();
    writer.append(b"pre-unlink payload").unwrap();
    let reference = writer.finish(true).unwrap();
    drop(writer);
    let plan = store.cleanup_plan("s", Some("c")).unwrap();
    // Materialize the crash boundary after the durable rename but before
    // unlink. Actual production replay must delete and sync this raw payload.
    fs::rename(
        path.join(format!("{}.json", reference.artifact_id)),
        path.join(format!("{}.cleanup", reference.artifact_id)),
    )
    .unwrap();
    fs::File::open(&path).unwrap().sync_all().unwrap();
    drop(store);
    let store = OutputArtifactStore::open(&path, limits()).unwrap();
    assert!(
        matches!(store.cleanup_plan("s", None), Err(OutputError::Interrupted)),
        "an unanchored retirement cannot become a new intent"
    );
    assert!(matches!(
        store.cleanup_receipted("s", Some("other"), &plan),
        Err(OutputError::Integrity)
    ));
    let ids = store.cleanup_receipted("s", Some("c"), &plan).unwrap();
    assert!(!path.join(format!("{}.raw", reference.artifact_id)).exists());
    let receipt = ids.into_iter().collect();
    store.acknowledge_cleanup("s", &receipt).unwrap();
    store.acknowledge_cleanup("s", &receipt).unwrap();
    assert!(store.cleanup_plan("s", None).unwrap().is_empty());
}

#[test]
fn cleanup_retirements_preserve_private_inode_and_alias_checks() {
    use std::os::unix::fs::PermissionsExt;
    let root = tempdir().unwrap();
    let path = root.path().join("raw");
    let store = OutputArtifactStore::open(&path, limits()).unwrap();
    let mut writer = store
        .begin("s", "c", OutputStream::Stdout, 100, store.progress_queue())
        .unwrap();
    writer.append(b"private").unwrap();
    let reference = writer.finish(true).unwrap();
    drop(writer);
    let plan = store.cleanup_plan("s", None).unwrap();
    let raw = path.join(format!("{}.raw", reference.artifact_id));
    let alias = root.path().join("alias");
    fs::hard_link(&raw, &alias).unwrap();
    assert!(matches!(
        store.cleanup_receipted("s", None, &plan),
        Err(OutputError::UnsafePath)
    ));
    assert!(raw.exists());
    fs::remove_file(&alias).unwrap();
    let ids = store.cleanup_receipted("s", None, &plan).unwrap();
    let record = path.join(format!("{}.cleanup", reference.artifact_id));
    assert_eq!(
        fs::metadata(&record).unwrap().permissions().mode() & 0o777,
        0o600
    );
    fs::hard_link(&record, &alias).unwrap();
    assert!(matches!(
        store.cleanup_receipted("s", None, &plan),
        Err(OutputError::UnsafePath)
    ));
    assert!(matches!(
        store.acknowledge_cleanup("s", &ids.iter().cloned().collect()),
        Err(OutputError::UnsafePath)
    ));
    fs::remove_file(&alias).unwrap();
    fs::set_permissions(&record, fs::Permissions::from_mode(0o644)).unwrap();
    assert!(matches!(
        store.cleanup_receipted("s", None, &plan),
        Err(OutputError::UnsafePath)
    ));
    assert!(record.exists());
}

#[test]
fn actual_kernel_file_size_limit_preserves_partial_write_identity_on_restart() {
    let root = tempdir().unwrap();
    let status = std::process::Command::new(std::env::current_exe().unwrap())
        .args(["--exact", "kernel_file_size_limit_helper", "--nocapture"])
        .env("ZENPI_OUTPUT_FSIZE_ROOT", root.path())
        .status()
        .unwrap();
    assert!(status.success());
    let reference: ArtifactRef =
        serde_json::from_slice(&fs::read(root.path().join("reference.json")).unwrap()).unwrap();
    assert!(reference.finalized && !reference.complete && reference.truncated);
    assert_eq!(
        (reference.bytes_stored, reference.bytes_observed),
        (8192, 20480)
    );
    assert!(
        reference
            .failure
            .as_deref()
            .unwrap()
            .contains("File too large")
    );
    let store = OutputArtifactStore::open(root.path().join("raw"), limits()).unwrap();
    assert_eq!(store.inspect(&reference, 101).unwrap(), reference);
    let mut expected = vec![b'A'; 4096];
    expected.extend(vec![b'B'; 4096]);
    assert_eq!(
        store.read_range(&reference, 0, 8192, 101).unwrap(),
        expected
    );
    assert_eq!(reference.sha256, Some(digest(&expected)));
    println!(
        "actual EFBIG: observed=20480 stored=8192 complete=false restart prefix/hash/identity verified"
    );
}

#[test]
fn kernel_file_size_limit_helper() {
    let Some(root) = std::env::var_os("ZENPI_OUTPUT_FSIZE_ROOT") else {
        return;
    };
    let root = std::path::PathBuf::from(root);
    let store = OutputArtifactStore::open(root.join("raw"), limits()).unwrap();
    let mut writer = store
        .begin(
            "kernel-session",
            "kernel-call",
            OutputStream::Stdout,
            100,
            store.progress_queue(),
        )
        .unwrap();
    writer.append(&vec![b'A'; 4096]).unwrap();
    // Process-local OS limit: force a partial successful write followed by the
    // real kernel EFBIG path, without exhausting the user's filesystem.
    struct Restore(libc::rlimit, libc::sighandler_t);
    impl Drop for Restore {
        fn drop(&mut self) {
            unsafe {
                libc::setrlimit(libc::RLIMIT_FSIZE, &self.0);
                libc::signal(libc::SIGXFSZ, self.1);
            }
        }
    }
    let old = unsafe {
        let mut old: libc::rlimit = std::mem::zeroed();
        assert_eq!(libc::getrlimit(libc::RLIMIT_FSIZE, &mut old), 0);
        let handler = libc::signal(libc::SIGXFSZ, libc::SIG_IGN);
        assert_ne!(handler, libc::SIG_ERR);
        assert_eq!(
            libc::setrlimit(
                libc::RLIMIT_FSIZE,
                &libc::rlimit {
                    rlim_cur: 8192,
                    rlim_max: old.rlim_max
                }
            ),
            0
        );
        Restore(old, handler)
    };
    let failed = writer.append(&vec![b'B'; 16384]);
    drop(old);
    assert!(
        matches!(failed, Err(OutputError::Io(ref e)) if e.raw_os_error()==Some(libc::EFBIG)),
        "{failed:?}"
    );
    let reference = writer.finish(true).unwrap();
    fs::write(
        root.join("reference.json"),
        serde_json::to_vec(&reference).unwrap(),
    )
    .unwrap();
}

#[test]
fn actual_metadata_permission_denial_remains_interrupted_after_restart() {
    use std::os::unix::fs::PermissionsExt;
    assert_ne!(
        unsafe { libc::geteuid() },
        0,
        "EACCES fixture requires an unprivileged process"
    );
    let root = tempdir().unwrap();
    let path = root.path().join("raw");
    let store = OutputArtifactStore::open(&path, limits()).unwrap();
    let mut writer = store
        .begin(
            "permission-session",
            "permission-call",
            OutputStream::Stdout,
            100,
            store.progress_queue(),
        )
        .unwrap();
    writer.append(b"known-written-prefix").unwrap();
    struct Restore(std::path::PathBuf);
    impl Drop for Restore {
        fn drop(&mut self) {
            fs::set_permissions(&self.0, fs::Permissions::from_mode(0o700)).unwrap();
        }
    }
    let restore = Restore(path.clone());
    fs::set_permissions(&path, fs::Permissions::from_mode(0o500)).unwrap();
    let failed = writer.finish(true);
    drop(restore);
    assert!(
        matches!(failed, Err(OutputError::Io(ref e)) if e.raw_os_error()==Some(libc::EACCES)),
        "{failed:?}"
    );
    let reference = writer.reference().clone();
    assert!(reference.finalized && !reference.complete && reference.failure.is_some());
    assert_eq!(reference.bytes_stored, 20);
    assert!(matches!(
        store.begin(
            "permission-session",
            "later-call",
            OutputStream::Stderr,
            100,
            store.progress_queue()
        ),
        Err(OutputError::Interrupted)
    ));
    drop(writer);
    drop(store);
    let reopened = OutputArtifactStore::open(&path, limits()).unwrap();
    assert!(matches!(
        reopened.inspect(&reference, 101),
        Err(OutputError::Interrupted)
    ));
    assert_eq!(
        fs::read(path.join(format!("{}.raw", reference.artifact_id))).unwrap(),
        b"known-written-prefix"
    );
    println!(
        "actual EACCES: final metadata publication failed; complete=false; same owner blocked; reopened artifact interrupted with exact raw prefix"
    );
}

#[test]
fn actual_default_max_artifact_read_measures_in_scan_cancellation() {
    let root = tempdir().unwrap();
    let mut agent = output_host(root.path(), root.path());
    let result = agent
        .run_user_shell_with_cancel("!/usr/bin/yes x | /usr/bin/head -c 8388608", || false)
        .unwrap();
    let reference: ArtifactRef =
        serde_json::from_value::<Vec<ArtifactRef>>(result["output_artifacts"].clone())
            .unwrap()
            .into_iter()
            .find(|r| r.stream == OutputStream::Stdout)
            .unwrap();
    assert_eq!(
        reference.bytes_stored,
        OutputLimits::default().max_file_bytes
    );
    assert!(reference.complete);
    let request = OutputReadRequest {
        artifact_id: reference.artifact_id.clone(),
        call_id: reference.call_id.clone(),
        offset: 0,
        length: 8,
    };
    let cancelled = AtomicBool::new(false);
    let calls = std::sync::atomic::AtomicUsize::new(0);
    let (tx, rx) = std::sync::mpsc::channel();
    std::thread::scope(|scope| {
        let cancel_flag = &cancelled;
        let cancel = scope.spawn(move || {
            rx.recv_timeout(Duration::from_secs(5)).unwrap();
            std::thread::sleep(Duration::from_millis(1));
            cancel_flag.store(true, Ordering::SeqCst);
            Instant::now()
        });
        let started = Instant::now();
        let result = agent.read_tool_output(request, &|| {
            if calls.fetch_add(1, Ordering::SeqCst) == 1 {
                tx.send(()).unwrap();
            }
            cancelled.load(Ordering::SeqCst)
        });
        let ended = Instant::now();
        let cancelled_at = cancel.join().unwrap();
        assert!(matches!(result, Err(OutputError::Cancelled)), "{result:?}");
        println!(
            "default 8MiB artifact, requested 8B: read_ms={} cancellation_to_return_ms={} callback_checks={}",
            ended.duration_since(started).as_millis(),
            ended.saturating_duration_since(cancelled_at).as_millis(),
            calls.load(Ordering::SeqCst)
        );
        // Generous regression ceiling: a cancelled eight-byte request must
        // not keep scanning/redacting the entire default 8MiB artifact.
        assert!(
            ended.saturating_duration_since(cancelled_at) < Duration::from_secs(1),
            "cancel waited for full artifact scan"
        );
    });
    assert_eq!(
        agent
            .session()
            .events()
            .iter()
            .filter(|e| e["type"] == "tool_execution_started")
            .count(),
        1
    );
}
