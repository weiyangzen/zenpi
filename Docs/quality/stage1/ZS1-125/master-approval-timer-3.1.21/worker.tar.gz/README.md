# ZS1-125 审批等待计时修复候选（3.1.21）

仅完成本次审批计时有界修复，不宣称整个125或provider取消能力已验收。交付给主控独立审查、迁入与验收。只改新鲜main基线的 `src/tui.rs`、`tests/tui_transcript_ux.rs`；没有改主库、用户原worktree代码或任何既有ready包。

## 行为与归属

原计时器由`set_status`包含“Approval”暂停、其它文案恢复；真实`present_approval/retire_approval`不控制计时，`set_busy(true)`无条件起计。现在状态文字仅负责显示。统一计时同步依据busy、真实项目ApprovalView请求、当前job的canonical待批ID以及实际终态。隐藏审批、切换焦点、Alt-C无关提示、未知retire都不结束审批等待；多个审批仅最后有效retire/resolution后恢复累计时间。

真实协调器应答仍先验证project/turn/call/request与is_pending，再respond、retire；known real retire同时清除同ID canonical镜像。canonical resolution仅清canonical记录，不能越过仍存在的真实协调器请求。Pending状态的resolution和未知ID不能恢复计时。canonical事件入口统一拒绝非当前stream job，旧审批、旧取消或结束事件不能改变新job；原canonical展示测试补上显式begin job，以符合这个归属前提。

真实请求仍最多128条，canonical ID去重并最多128条，入库前使用原ViewEvent验证限制ID字节等。任一路第129项造成有界饱和标记，已保存请求清空仍保守暂停，直到取消获接纳、终态或替换现有job清除不确定等待；不会用无界set，也不把未展示请求算成已解决。代价是饱和时可能多暂停，本次不修改原审批队列容量或补回被原128上限省略的界面项。

TranscriptUx随原ProjectDraft存取，因此背景运行区间不会因切tab重启，暂停项目的累计时间与待批记录独立保存。新活动重置累计时间，现有job被替换时清旧请求。审批先于busy出现仍保持暂停。五处host取消/终态清审批调用统一清理入口。已获接纳的取消仅清等待，busy仍持续时收尾耗时继续计入；QueueFull/纯“Interrupt requested”文案不清等待。真正TurnCompleted/Failed/Cancelled/Closed及host set_busy(false)停止计时，迟到retire不会重启。计时状态不是跨进程持久化功能；不把取消请求提示当成provider已停止。

## 实际证据

- `before/src/tui.rs`为639010B / b15661a160a855ef974e82dfb40a63c8d0c5777623cd553d1d4cf2069d8b59a1。先只加6条测试，真实执行exit101：5失败、1对照通过。`before/tui-with-regression-tests.rs`保存当时完整源码，stdout/stderr完整保留。未保留该历史测试二进制hash，不冒充有它。
- 首轮修复原6条全部通过。最终定向14条全部通过：13条新timer单元测试与1条现有canonical展示测试。直接检查私有Instant/累计Duration，不sleep跨秒；真实Coordinator以注册后的channel握手同步，错误身份继续暂停，正确拒绝应答恢复计时。覆盖多项、重复、未知、Pending resolution、真实/canonical镜像、旧job、四种终态、取消接纳边界、项目切换和128/129上限。
- 六组完整TUI回归124条：approval_focus12、BentoBox16、command_palette17、composer51、project_workspace11、transcript_ux17。最后一组包含新增可见审批终态/旧job/新流回归。定向与大范围库运行有重叠，不累加为独立测试总数。
- owned rustfmt最终独立exit0。clippy `--lib --test tui_transcript_ux -- -D warnings`日志成功完成，无本仓库诊断；其单独exit未捕获，随后build的组合shell exit0，不伪造独立exit回执。原vendor/crossterm括号warning原样保留。native ARM debug build完成，运行过的50,802,744B Mach-O arm64 binary保存于bin/zenpi，SHA6307f4ca252401877ded582da28862e4576e97699141486dd8abd804fd89b7ab。
- 最终新PTY v4实际运行一次，12检查全通过，driver和zenpi均exit0。真实用户shell先等协调器审批，Esc隐藏后Alt-C使status变为“No assistant answer to copy”，1.3秒观察计时0→0、shell gate未被访问；Alt-A/y/Enter批准后，真实curl在本机HTTP gate等待时计时0→1；释放gate后完成，busy计时消失，正常quit和alternate screen恢复。该次仅1个GET /gate，0模型HTTP请求；journal含1条本地user_shell结果turn，不能把零turn_started/completed marker误说成无任何turn记录。raw与屏幕文本投影、journal、子进程/输出回执保留。投影是有限ANSI解析，不等同完整终端仿真或像素截图。

## 失败与范围限制（全部保留）

新增测试曾一次把canonical String参数误写为JSON Value，编译exit101；修正后13条新timer均过，但原canonical测试未begin job而失败，补上其前提后通过。`after-targeted`和`fix-targeted`日志保留；这些中间版本未分别保存完整二进制。

一次误带整个`--lib`的回归执行了本次之外的现有测试：150通过、1失败、5 ignored；无关`slash_actions::diff_cancel_tests::stalled_stdout_and_closed_stdout_child_are_cancelled_and_reaped`在pidfile刚出现但内容为空时ParseIntError，未进入取消/回收断言。未修改、重跑或将它归咎于本次计时改动。该次cargo在lib失败后没有继续集成测试；后续单独执行指定六组才取得124通过。没有运行117/131专用探针、真实FIFO/DTrace、release、预算或prewarm。

新PTY脚本先有3次失败，均保留，不宣称一次即过：v1启动识别等待不满足，未提交shell，cleanup遇进程组PermissionError导致最后raw/结果未落盘；保留源、stderr、run与当时journal，后续进程核对无残留。v2进入界面，但一段输入连Enter触发原paste保护，command留draft，审批未发生；保留raw/结果，清理超时记录不改写。v3修正独立Enter后，8条核心行为已通过、zenpi exit0，但脚本结束check多给参数导致driver exit1。v4仅修正该脚本参数及journal计数读取层级，产品代码与binary不变。各脚本只运行对应版本，没有执行任何旧任务runner；主控原component observer原样拷贝，未运行其run.py。主控观察为3反例失败、1对照通过，actual_pty=false、0模型请求，不能拿它当真实host边界。

HOME不变；所有Cargo均使用已安装stable-aarch64-apple-darwin、locked/offline与新独立125 target。仅新PTY用私有ZENPI_HOME和本机拒绝模型请求的服务。没有新增公共timer测试API或修改依赖。新增测试辅助函数限tui.rs私有测试模块；独立PTY脚本仅为证据生成，不进产品patch。

## 输入、迁入与冻结

initial-inputs.json绑定202个新鲜构建输入；project保存完整私有输入，scope-observation确认只上述两owned文件改变。composer仍52941B / 30d9b19bc250409bac1e4254b7237f11cf8de625913d55b669a044665e89d7c1。main期间独立整合123，因此tui.rs/palette发生已授权主控漂移；本候选仍基于原b156，未重抓覆盖123，补丁只含125增量。主控须按自己的完整123增量迁入，不能覆盖当前648110B/a19d…的tui文件。

authority与authority-final保留完整selector、blueprint和claims；3.1.21 requirement、baseline、run与blueprint身份一致，未把无关全树hash当门禁。reading-ranges记录实际相关阅读，chunk_manifest只是文件分块身份，不能冒充通读。既有123及所有旧ready/失败包保持原样。

冻结ready后仅运行一次新的纯Python portable，并把stdout/stderr/run元数据全部放包外。它只检查manifest、输入保护、patch、失败/成功证据、binary与authority绑定，不执行Cargo、PTY、旧runner或主控observer，不替代语义验收。冻结后不回写README。主控独立审查/迁入/测试后决定是否接受；回滚仅撤这两个文件的本次差异。交付后B停止。
