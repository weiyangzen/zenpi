"""Read-only portable verification; never execute the product, tests or observers."""
from pathlib import Path
import argparse,difflib,hashlib,json,sys
checks=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def check(name,ok):checks.append({'name':name,'ok':bool(ok)})
def verify(root):
 root=root.resolve()
 def raw(rel):
  p=(root/rel).resolve()
  if root not in p.parents:raise ValueError('path leaves packet')
  return p.read_bytes()
 def data(rel):return json.loads(raw(rel))
 m=data('manifest.json');payload=m['payload']
 actual=sorted(str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p!=root/'manifest.json')
 check('exact payload paths',actual==sorted(r['path'] for r in payload))
 check('payload count',len(payload)==m['payload_files'])
 check('payload bytes',sum(r['bytes'] for r in payload)==m['payload_bytes'])
 for r in payload:
  b=raw(r['path']);check('payload:'+r['path'],len(b)==r['bytes'] and sha(b)==r['sha256'])
 owned=['src/tui.rs','tests/tui_transcript_ux.rs']
 check('owned scope',m['owned_paths']==owned)
 inp=data('initial-inputs.json')['files']
 check('202 initial inputs',len(inp)==202)
 check('project exact paths',sorted(str(p.relative_to(root/'project')) for p in (root/'project').rglob('*') if p.is_file())==sorted(r['path'] for r in inp))
 for r in inp:
  b=raw(('before/' if r['path'] in owned else 'project/')+r['path'])
  check('protected original:'+r['path'],len(b)==r['bytes'] and sha(b)==r['sha256'])
 check('fresh 125 tui baseline',len(raw('before/src/tui.rs'))==639010 and sha(raw('before/src/tui.rs'))=='b15661a160a855ef974e82dfb40a63c8d0c5777623cd553d1d4cf2069d8b59a1')
 check('composer protected',len(raw('project/tests/tui_composer.rs'))==52941 and sha(raw('project/tests/tui_composer.rs'))=='30d9b19bc250409bac1e4254b7237f11cf8de625913d55b669a044665e89d7c1')
 obs=data('scope-observation.json')
 check('only two changed inputs',sorted(r['path'] for r in obs['changed_inputs'])==owned)
 check('main drift explicitly not gate',obs['main_hash_is_global_gate'] is False)
 patch=''
 for rel in owned:
  diff=''.join(difflib.unified_diff(raw('before/'+rel).decode().splitlines(True),raw('project/'+rel).decode().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
  check('per-file diff:'+rel,diff.encode()==raw(rel.replace('/','__')+'.diff'));patch+=diff
 check('complete exact patch',patch.encode()==raw('candidate.patch'))
 before=raw('logs/before.stdout').decode()
 check('real before 5 fail and 1 pass','1 passed; 5 failed' in before)
 check('before added test source retained',b'approval_timer_pending_request_pauses_without_status_text' in raw('before/tui-with-regression-tests.rs'))
 check('final targeted 14 pass','14 passed; 0 failed' in raw('logs/final-targeted.stdout').decode())
 regression=raw('logs/tui-regression.stdout').decode()
 for n in [12,16,17,51,11]:check('integration count:'+str(n),f'{n} passed; 0 failed' in regression)
 check('six integration binaries',regression.count('test result: ok.')==6 and regression.count('17 passed; 0 failed')==2)
 check('broad lib failure retained','150 passed; 1 failed; 5 ignored' in raw('logs/regression.stdout').decode())
 check('clippy completed with original vendor warning',b'Finished `dev`' in raw('logs/clippy.stderr') and b'vendor/crossterm' in raw('logs/clippy.stderr'))
 receipts=data('run-receipts.json')
 for r in receipts:
  for log in r['logs']:
   b=raw(log['path']);check('run log:'+log['path'],len(b)==log['bytes'] and sha(b)==log['sha256'])
 check('fmt receipt',any(r['name']=='final-fmt' and r['exit']==0 for r in receipts))
 check('clippy separate exit not invented',any(r['name']=='clippy' and r['exit'] is None for r in receipts))
 check('first failed PTY provenance',data('logs/pty.run.json')['exit']==1 and data('pty-attempt-1-failed/failure-note.json')['raw_retained'] is False)
 for v in [2,3]:check('PTY failed attempt retained:'+str(v),data(f'logs/pty-v{v}.run.json')['exit']==1)
 pty=data('pty-evidence-v4/result.json')
 check('new successful PTY',data('logs/pty-v4.run.json')['exit']==0 and pty['exit']==0 and pty['error'] is None and pty['actual_pty'])
 check('12 PTY checks',len(pty['checks'])==12 and all(c['ok'] for c in pty['checks']))
 check('zero model HTTP and one real shell gate',pty['model_requests']==0 and pty['gate_requests']==1)
 check('PTY exact tested binary',len(raw('bin/zenpi'))==pty['binary']['bytes'] and sha(raw('bin/zenpi'))==pty['binary']['sha256'])
 check('PTY raw alternate restore',b'\x1b[?1049l' in raw('pty-evidence-v4/terminal.raw'))
 check('journal local shell turn distinguished',data('pty-journal-observation.json')['v4_event_counts']['turn']==1)
 check('no remaining owned child',data('process-observation.json')['matching_owned_zenpi_processes']==[])
 for phase in ['authority','authority-final']:
  a=data(phase+'/Docs/execution/active_requirement.json')
  check(phase+': authority',a['active'] and a['blueprint_version']=='3.1.21' and a['requirement_digest']=='3456abcbbebbc4e0ab383c319851b0a6e71b19ee9b3c060a6e212f61a89c9d9d' and a['baseline_snapshot_sha256']=='92b06c4b1dcdca7614d226ce5f41205646a9e63967789d2b6ed4ee272d240884' and a['run_id']=='zenpi-stage1-20260911')
  check(phase+': blueprint hash',sha(raw(phase+'/Docs/stage_1_v3_pi_mono_blueprint.md'))==a['snapshot_sha256'])
 check('authority stable',data('authority-observation.json')['identities_equal'])
 for row in raw('chunk_manifest.tsv').decode().splitlines()[1:]:
  path,offset,size,digest=row.split('\t');b=raw(path)[int(offset):int(offset)+int(size)];check('chunk:'+path+':'+offset,len(b)==int(size) and sha(b)==digest)
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('root',type=Path);args=parser.parse_args()
 try:verify(args.root)
 except Exception as e:check('verifier exception:'+repr(e),False)
 result={'checks':checks,'passed':sum(c['ok'] for c in checks),'failed':sum(not c['ok'] for c in checks),'executes_product':False}
 print(json.dumps(result,indent=2));sys.exit(0 if result['failed']==0 else 1)
