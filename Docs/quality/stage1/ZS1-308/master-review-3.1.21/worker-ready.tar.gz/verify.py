"""ZS1-308 offline package and document checks; no historical or product execution."""
from pathlib import Path
import csv,datetime,difflib,hashlib,json,os,re,stat,subprocess,sys,tempfile
P=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent
E=P/'evidence';C=P/'files';checks=[]
def check(name,ok):
 assert ok,name
 checks.append(name)
def read(p):return json.loads(p.read_text())
def info(p):
 assert stat.S_ISREG(p.lstat().st_mode),str(p)
 b=p.read_bytes();return {'bytes':len(b),'lines':len(b.splitlines()),'sha256':hashlib.sha256(b).hexdigest()}
def meta(x):return {k:x[k] for k in ['bytes','sha256']}
def inv(p):
 out={}
 for d,ds,fs in os.walk(p,followlinks=False):
  ds[:]=[n for n in ds if not Path(d,n).is_symlink()]
  for n in fs:
   f=Path(d,n)
   if stat.S_ISREG(f.lstat().st_mode):out[str(f.relative_to(p))]=info(f)
 return out
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True).encode()).hexdigest()
start=datetime.datetime.now(datetime.timezone.utc).isoformat();actual=inv(P);actual.pop('manifest.json')
check('frozen exact inventory',actual=={x['path']:{k:x[k] for k in ['bytes','lines','sha256']} for x in read(P/'manifest.json')['files']});payload=len(actual)
cap=read(E/'capture.json')
for f in cap['files']:check('capture '+f['path'],info(E/f['path'])=={k:f[k] for k in ['bytes','lines','sha256']})
source=E/'capture/codex/codex-rs/tui/src/key_hint.rs';b=source.read_bytes();s=b.decode();lines=b.splitlines(keepends=True)
check('exact source',info(source)=={'bytes':3306,'lines':112,'sha256':'07f34aab630b2658560d2d4e73719481ec8638e33eb38401d7a23643689f13c8'})
ledger=read(E/'read-binding.json')
for r in ledger:
 src=E/r['source'];raw=src.read_bytes();ls=raw.splitlines(keepends=True);a,z=r['lines'];lo=sum(map(len,ls[:a-1]));hi=sum(map(len,ls[:z]));chunk=E/r['path']
 check('read source '+r['path'],len(raw)==r['source_bytes'] and hashlib.sha256(raw).hexdigest()==r['source_sha256'])
 check('read exact bytes '+r['path'],r['byte_range']==[lo,hi] and chunk.read_bytes()==raw[lo:hi] and meta(info(chunk))==meta(r) and len(raw[lo:hi])<=256*1024)
formal=[r for r in ledger if r['source']=='capture/codex/codex-rs/tui/src/key_hint.rs'];check('independent complete source read',len(formal)==1 and formal[0]['lines']==[1,112] and formal[0]['byte_range']==[0,3306])
functions=[{'name':m.group(1),'line':s[:m.start()].count('\n')+1} for m in re.finditer(r'^[ \t]*(?:pub(?:\(crate\))?\s+)?(?:const\s+)?fn (\w+)\(',s,re.M)]
check('14 exact textual definitions',functions==read(E/'function-inventory.json') and [x['name'] for x in functions]==['new','is_press','plain','alt','shift','ctrl','ctrl_alt','modifiers_to_string','from','from','key_hint_style','has_ctrl_or_alt','is_altgr','is_altgr'])
check('no test functions',not re.search(r'#\[(?:test|tokio::test)|mod tests',s))
check('platform branches',all(t in s for t in ['#[cfg(test)]','#[cfg(all(not(test), target_os = "macos"))]','#[cfg(all(not(test), not(target_os = "macos")))]','#[cfg(windows)]','#[cfg(not(windows))]']))
check('exact matcher literals',all(t in s for t in ['self.key == event.code','self.modifiers == event.modifiers','event.kind == KeyEventKind::Press || event.kind == KeyEventKind::Repeat']))
check('modifier display order',s.index('result.push_str(CTRL_PREFIX)')<s.index('result.push_str(SHIFT_PREFIX)')<s.index('result.push_str(ALT_PREFIX)'))
check('eight special names',len(re.findall(r'KeyCode::(?:Enter|Char\(\x27 \x27\)|Up|Down|Left|Right|PageUp|PageDown) =>',s))==8)
units=read(E/'source-units.json');previous=0
for u in units:
 a,z=u['lines'];lo=sum(map(len,lines[:a-1]));hi=sum(map(len,lines[:z]));check('unit '+u['name'],lo==previous and u['byte_range']==[lo,hi] and hashlib.sha256(b[lo:hi]).hexdigest()==u['sha256'] and bool(u['meaning']));previous=hi
check('15 units cover all bytes',len(units)==15 and previous==3306)
mat=read(E/'capability-matrix.json');check('12 ordered mappings',[m['id'] for m in mat]==['C%02d'%i for i in range(1,13)])
for m in mat:check('mapping '+m['id'],all(m[k] for k in ['source','context','behavior','limit','criterion']) and m['executed'] is False)
h=read(E/'history-comparison.json');H=E/'history/zs1-308-ready';Q=H/'Docs/quality/stage1/ZS1-308/worker-key-hint-review-3.1.20';rb=read(E/'report-binding.json');rel=rb['path']
for key,path in [('old_report',H/rel),('old_manifest',H/'manifest.json'),('old_source',Q/'source/key_hint.rs'),('old_read_log',Q/'read-log.json'),('original_report',Q/'history/original-worker-report.md')]:check(key,info(path)==h[key])
check('old source exact and zero delta',h['source_equal'] and not h['source_delta'] and b==(Q/'source/key_hint.rs').read_bytes())
oldlog=read(Q/'read-log.json');check('old full read chain',oldlog['formal_byte_chunks']==[[0,3306]] and oldlog['sequential_reads'][0]['sha256']==info(source)['sha256'])
check('old report completely reread',[r['lines'] for r in ledger if r['source']=='history/zs1-308-ready/'+rel]==[[1,64],[65,126],[127,183]])
external=read(E/'external-preservation-before.json')
for x in external:
 root=E/x['path'];a=inv(root);check('historical exact '+x['path'],a==x['files']);a.pop('manifest.json');m=read(root/'manifest.json');check('historical manifest '+x['path'],{k:meta(v) for k,v in a.items()}=={k:meta(v) for k,v in m['files'].items()})
oldcontexts=read(Q/'context-capture.json')
for d in h['contexts']:
 old=next(x for x in oldcontexts if x['path']==d['origin']);f=next(x for x in cap['files'] if x['origin']==d['origin']);raw=(E/f['path']).read_bytes()
 check('context identity '+d['origin'],d['before']=={'bytes':old['full_bytes'],'sha256':old['full_sha256']} and d['after']==meta(f) and d['full_file_same']==(old['full_sha256']==f['sha256']))
 check('context read bounds '+d['origin'],d['new_read_ranges']==[r['lines'] for r in ledger if r['source']==f['path']])
 for x in d['old_excerpts']:
  p=E/x['path'];chunk=p.read_bytes();offset=raw.find(chunk);check('old excerpt '+x['path'],info(p)==x['identity'] and x['found_exact']==(offset>=0) and x['current_bytes']==([offset,offset+len(chunk)] if offset>=0 else None))
selector=read(E/'capture/zenpi/Docs/execution/active_requirement.json')
check('capture authority binding',selector['active'] and selector['blueprint_version']=='3.1.21' and selector['requirement_digest']=='3456abcbbebbc4e0ab383c319851b0a6e71b19ee9b3c060a6e212f61a89c9d9d' and selector['snapshot_sha256']==info(E/'capture/zenpi/Docs/stage_1_v3_pi_mono_blueprint.md')['sha256'])
row=next(x for x in csv.DictReader((E/'capture/zenpi/Docs/learn/stage1_pi_mono/references/codex/source_manifest.tsv').open(),delimiter='\t') if x['item_id']=='ZS1-308')
check('source manifest binding',row['source_hash']==info(source)['sha256'] and int(row['source_bytes'])==3306 and row['target_artifact']==rel and row['mapping_mode']=='understand')
report=C/rel;text=report.read_text();check('single canonical report',inv(C)=={rel:{k:rb[k] for k in ['bytes','lines','sha256']}})
check('report scope',rb['functions_textual']==14 and rb['functions_cfg_selected']==13 and rb['units']==15 and rb['capabilities']==12 and rb['read_blocks']==len(ledger) and rb['context_tests_read']==6 and rb['product_changes'] is False)
check('zero product/source execution',all(rb[k]==0 for k in ['source_tests_present','source_tests_run','cargo_runs','pty_runs','http_runs']))
check('all mapping rows',all('|'+m['id']+' '+m['capability'] in text for m in mat))
check('portable evidence link targets',all((P/path.split('/reference308-keys321-ready/',1)[1]).exists() for path in re.findall(r'\]\((/[^)]+)\)',text) if '/reference308-keys321-ready/' in path))
check('exact forward',''.join(difflib.unified_diff([],text.splitlines(True),fromfile='/dev/null',tofile='b/'+rel))==(P/'candidate.patch').read_text())
check('exact rollback',''.join(difflib.unified_diff(text.splitlines(True),[],fromfile='a/'+rel,tofile='/dev/null'))==(P/'rollback.patch').read_text())
check('bounded patch',(P/'candidate.patch').stat().st_size<256*1024)
before=read(E/'preservation-before.json');after=read(E/'preservation-after.json')
check('old local preservation',after['all_preserved'] and after['ready']=={p:{'files':len(x),'inventory_sha256':digest(x)} for p,x in before['ready'].items()} and after['tracked_inventory_sha256']==digest(before['tracked']))
check('external preservation',after['external']=={x['origin']:{'files':len(x['files']),'inventory_sha256':digest(x['files'])} for x in external})
proof=[]
with tempfile.TemporaryDirectory(prefix='zs1-308-document-') as td:
 t=Path(td);(t/'unrelated').write_text('preserve unrelated content\n');subprocess.run(['git','init','-q',str(t)],check=True,capture_output=True)
 for args,expected in [(['--check',str(P/'candidate.patch')],0),([str(P/'candidate.patch')],0),(['--check',str(P/'candidate.patch')],1),(['--check',str(P/'rollback.patch')],0),([str(P/'rollback.patch')],0)]:
  r=subprocess.run(['git','apply',*args],cwd=t,capture_output=True,text=True);proof.append({'argv':['git','apply',*args],'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr});check('temporary git '+str(args),r.returncode==expected)
  if args==[str(P/'candidate.patch')]:check('applied exact report',(t/rel).read_bytes()==report.read_bytes())
 check('rollback restores unrelated only',{p:v for p,v in inv(t).items() if not p.startswith('.git/')}=={'unrelated':info(t/'unrelated')} and (t/'unrelated').read_text()=='preserve unrelated content\n')
print(json.dumps({'status':'passed','started_at':start,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'static_checks':len(checks),'payload_files':payload,'formal_files':1,'source':info(source),'report':info(report),'read_blocks':len(ledger),'functions_textual':14,'functions_cfg_selected':13,'units':15,'capabilities':12,'product_executions':0,'source_tests_run':0,'temporary_git':proof,'checks':checks},indent=2))
