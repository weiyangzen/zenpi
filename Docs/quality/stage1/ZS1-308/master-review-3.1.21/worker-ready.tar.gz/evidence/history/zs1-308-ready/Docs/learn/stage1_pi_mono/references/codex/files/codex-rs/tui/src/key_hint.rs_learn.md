# ZS1-308 — codex-rs/tui/src/key_hint.rs 逐文件复核

状态：worker candidate ready；master G-FILE 待独立接收。仅本文件，未修改蓝图、索引、完成标记或产品代码。

## 身份、阅读与所有权

冻结蓝图 3.1.20，requirement digest `8d525b351d066ce9b0487a485337647d47233275782e4f4d154423a623fe1645`。源仓库 `/Users/wangweiyang/GitHub/codex`，HEAD `b3b3d262787f4902a7449f17d793241a34d311ad`。正式源文件 `codex-rs/tui/src/key_hint.rs` 为3306B、112行，SHA256 `07f34aab630b2658560d2d4e73719481ec8638e33eb38401d7a23643689f13c8`。蓝图398/411行的身份和owned path一致；完整读取[0,3306)，先cat全文，再按1–112行顺序编号复读。没有未读正文、分页缺口或超过256KiB的分块；单块hash等于全文件hash。

正式源文件数1；源测试定义数0、源测试阅读数0、源测试实际执行数0。`#[cfg(test)]`只选择常量，不是测试函数。本文件没有内联或外部snapshot调用。正文有14个文本函数定义；其中`is_altgr`两份由互斥cfg选择，单个目标编译选中13个定义。`function-inventory.json`逐项记录行号，两个`from`和两个`is_altgr`分别保留，没有按名字误去重。

必要上下文只读取4个Codex调用文件的9段及当前Zenpi `src/tui.rs`的9段，共5文件18段，不将它们登记为额外完整文件。footer上下文中完整读了1个测试、1个assert_eq!，执行0；其余依赖和外部键盘实现未扩读。源功能、上下文推导、已有发布结果和建议实验在下文分开。

蓝图ZS1-308的标准owned report就是本路径。ZS1-353依赖本文件及其它直属文件/目录，须全部依赖接受后另做G-DIR；ZS1-125依赖本文件及309等，承担滚动/复制/终端恢复真实入口。阅读这个formatter不能代替125或353验收，308也不接管textarea、clipboard或审批实现。

## 全部定义与顺序语义

1. L1–16引入crossterm事件类型及ratatui样式/Span。CTRL_PREFIX恒为`ctrl + `，SHIFT_PREFIX恒为`shift + `。ALT_PREFIX在test配置总是`⌥ + `；非test macOS同样为`⌥ + `，非test非macOS为`alt + `。这是编译目标与测试cfg选择，不是运行时终端能力检测，也不证明Windows或Linux渲染成功。
2. L18–27 `KeyBinding`保存私有`key`和`modifiers`，派生Clone/Copy/Debug/Eq/PartialEq；`new`是const且原样保存两个字段，没有键码或修饰键归一化、配置查找或错误返回。
3. L29–33 `is_press`要求精确 key 与全部 modifiers，再要求kind为Press或Repeat。它不只检查“至少有Ctrl”，也不忽略额外Shift/Super；Release始终不通过。不读取event其它字段/state。同名按键的大小写、额外修饰位及调用者是否让Repeat进入，均会改变实际结果。
4. L36–54五个 const 构造器`plain`、`alt`、`shift`、`ctrl`、`ctrl_alt`统一调用new。对应NONE、ALT、SHIFT、CONTROL、CONTROL.union(ALT)，没有CtrlShift专用函数，但new可表达任意组合。ctrl_alt不做AltGr例外；AltGr只在后面的分类函数中处理。
5. L56–68 `modifiers_to_string`按contains CONTROL、SHIFT、ALT的固定顺序追加前缀，显示修饰键顺序固定。Super/Hyper/Meta等其它位不输出，也没有“不支持”标记；精确matcher仍保留这些位。因而两个不同binding可能具有相同提示文字，例如plain(a)与new(a,SUPER)。可见文本不能作为binding身份、授权依据或逆向解析输入。
6. L70–74 owned `From<KeyBinding>::from`借用binding后委托；L75–92 borrowed `From<&KeyBinding>::from`分离modifiers和key，生成拥有内容的`Span<'static>`，不保留对调用方binding的借用。两入口共用同一个格式化逻辑。
7. L79–89八个显式键名为Enter→enter、Char(' ')→space、Up/Down/Left/Right→↑/↓/←/→、PageUp→pgup、PageDown→pgdn。其它KeyCode通过其Display再`to_ascii_lowercase()`。这仅改变ASCII大写，不能宣称Unicode大小写折叠。Char('A')可能显示a，但精确匹配仍要求原Char('A')；Tab/Esc/BackTab/功能键等依赖上游Display，并非本文件逐项定义。没有把ShiftTab强制归一成BackTab的代码。
8. L90及94–96 `key_hint_style`返回`Style::default().dim()`，即dim Span 与布局边界分离；没有指定前景/背景颜色，没有width预算、裁剪、换行或字形降级。DIM在不同终端的实际可读性仍需host验证。该Span不注册快捷键、点击区域、tooltip或辅助技术描述。
9. L98–100 `has_ctrl_or_alt`先看CONTROL或ALT，再排除`is_altgr`。它是字符输入分类helper，不修改事件，不生成字符，不决定全部命令路由。
10. L102–106 Windows `is_altgr`只要求contains ALT和CONTROL；Shift及其它额外位不影响true。L108–112非Windows分支恒false。因此Windows AltGr 启发式把真实AltGr与普通CtrlAlt组合都归入例外，不能识别键盘布局、左右Alt、IME或终端实际编码。其它平台即使收到CtrlAlt也不会被此函数排除。

## 平台、事件与文本的可检验边界

| 输入/配置 | 显示或分类的源代码结果 | 边界 |
| --- | --- | --- |
| 任意target的cfg(test) Alt binding | `⌥ + `前缀 | Linux测试快照也可能看起来像macOS；不是Linux生产显示证据 |
| non-test macOS / non-test非macOS | `⌥ + ` / `alt + ` | 不检测实际终端或用户键盘 |
| NONE或SHIFT-only | has_ctrl_or_alt=false | SHIFT仍参与binding精确匹配，helper false不代表无任何修饰键 |
| CONTROL-only或ALT-only | has_ctrl_or_alt=true | 两个平台分支一致 |
| CONTROL|ALT，Windows | is_altgr=true，has_ctrl_or_alt=false | 真实CtrlAlt chord也被视作文字候选；不能承诺永不误分类 |
| CONTROL|ALT，非Windows含Linux/WSL | is_altgr=false，has_ctrl_or_alt=true | WSL提示策略不改变此cfg分支 |
| CONTROL|ALT|SHIFT，Windows | 仍is_altgr=true | 这是contains逻辑，无精确等值约束 |
| binding与event完全相同，Repeat | is_press=true | 宿主前置路由可拒绝；formatter没有重复抑制 |
| 额外SUPER但visible label相同 | is_press取决于完整位集是否等值 | 文字碰撞，不等于事件碰撞 |
| Release | is_press=false | 宿主可在判断前flush其它状态，不能推导整个应用绝对无副作用 |

本文件没有异步任务、I/O、定时器、订阅、焦点栈或持久化。显示产生String分配但没有测量耗时/RSS，也未依据112行小文件推导资源预算通过。错误路径主要来自调用者所选binding与实际终端事件不一致、可见文字不足和上下文不适用；函数本身没有Result或恢复状态。没有快捷键重绑定注册表，也不提供国际化翻译入口。

## 必要调用链：提示可见不等于动作可用

`bottom_pane/footer.rs` L880–1020、1044–1060：`ShortcutBinding.matches`判断DisplayCondition而非KeyEvent；Always、WhenShiftEnterHint、WhenNotShiftEnterHint、WhenUnderWSL、WhenCollaborationModesEnabled依据ShortcutsState，descriptor的`binding_for`取第一个满足条件者，overlay_entry把其key转Span。显示条件由调用者选择。Newline在ShiftEnter与CtrlJ间选择；PasteImage把WSL CtrlAltV放在Always CtrlV之前；ChangeMode使用ShiftTab且只在协作模式启用时显示。顺序很重要：如果Always先命中，平台专用提示会被遮蔽。这里仅审阅显示选择，不声称它验证了剪贴板真实动作。

footer L1706–1743的`paste_image_shortcut_prefers_ctrl_alt_v_under_wsl`在Linux调用实际WSL检测，否则false，构造ShortcutsState并assert_eq actual_key与按is_wsl选出的expected_key。它不是强制执行true/false双分支的参数化测试，也没有执行剪贴板粘贴。本轮只读1测试、执行0。Windows AltGr的cfg(windows)与Linux上WSL运行时判断是两层不同机制，不可互相充当证据。

`chat_composer.rs` L3007–3045、3090–3113：Char事件的`has_ctrl_or_alt`影响paste-burst ASCII/非ASCII分类，有Ctrl/Alt的字符会清除burst，Enter保留特定处理、其它键清除。L3150–3174的问号overlay切换要求Press、无Ctrl/Alt分类、composer空且非paste。该helper对文本候选的保护只适用于已读调用路径；不能保证所有输入或快捷键都走同一过滤器。

`approval_overlay.rs` L370–422：CtrlA full-preview仅Press且contains CONTROL，o选择来源thread仅Press并检查thread_label，模式中未限定o的modifiers。其它选项才通过`shortcuts().any(|s| s.is_press(*e))`查找第一个选项。即使同一overlay也混用contains、未限定修饰键和严格KeyBinding，且选项helper可接受Repeat。必须按真实分支验证，而不是把“KeyBinding严格”推广为整个审批UI严格。

`bottom_pane/mod.rs` L112–128、656–680：QUIT_SHORTCUT_TIMEOUT保留1秒，但DOUBLE_PRESS_QUIT_SHORTCUT_ENABLED=false；show_quit_shortcut先检查开关并return，之后才是tokio/thread的延迟redraw分支。禁用状态与保留timer代码同时成立。本文件key_hint没有退出计时器；不能因相邻模块定义1秒常量就为Zenpi复制双击退出或声称该实验仍启用。

## 与冻结当前Zenpi的操作映射

上下文捕获时间和每段bytes/hash在context-capture.json；本轮一次捕获TUI为579524B，SHA256 `d2a98934d4931a5aa202e542acd556bdda5667f0e60df11a68731dacf00eccf1`。该值与封存release的build-inputs.json中src/tui.rs相同。之后没有跟随主库滚动读写；下列判断限定于此版本与片段。

| 操作/提示 | 当前目标事实 | 映射判断与待验证边界 |
| --- | --- | --- |
| 通用footer | L6354–6390手写文字；宽<100显示Enter/CtrlJ/CtrlR/CtrlC，宽屏增加CtrlG/CtrlU/CtrlY/AltR/AltC/AltB | 已有可发现入口；不是统一KeyBinding descriptor，提示与路由可能独立漂移 |
| 后台审批 | L998–1041筛非当前项目且pending>0，最多3个来源名，名称裁至28宽，其余用+N projects，提示switch tab, Alt-A review | 当前已实现，不能沿用旧版本“完全缺失后台footer”的结论；来源数量/窄屏可见性仍有限 |
| footer竞争 | L6354–6390：checkpoint warning > background approval > adjacent paste > compact/wide general | 目标提示按优先级覆盖；保存失败可遮蔽后台操作文字，粘贴或后台提示可遮蔽一般快捷键；需要其它可发现路径配合 |
| 样式/裁剪 | background且无unsaved用Yellow，其余DarkGray，统一truncate_to_width，零面积return | DarkGray不是源DIM；窄屏/Unicode裁剪由目标承担，不能从formatter推导没有重叠 |
| 审批入口和焦点 | L1042–1075 picker优先；active project有请求才响应精确ALT+a；focus后精确CONTROL+c取消，其余非空modifiers拒绝；Esc退回草稿 | AltA是当前项目review，不是从任意后台直接决策；提示switch tab有操作意义。多修饰键策略与普通CONTROL分支不同 |
| 审批footer | L1140–1208含y/n选择、Enter确认、Tab下一项、PgUp/PgDn滚动、Esc draft、CtrlC cancel；小于4宽或5高return | 不把“有footer”当作tiny terminal中必可见，也不省略明确确认步骤 |
| reasoning/copy/blocks | L5081–5106精确ALT匹配r/b/c，copy没有答复时设置No assistant answer to copy | 当前有AltR/AltB/AltC；无答复不是无声成功。片段未验证OS剪贴板拒绝、选定块复制或重启恢复 |
| 普通字符和事件 | L4900–4928先flush，Release再return；ordinary分类排除ALT/CONTROL/SUPER。L4952–4970主match仅Press进入handle_key | “Press-only”只描述后段key分派；Repeat可能进入前段ordinary字符缓冲，Release也先flush；需保留时序测试 |
| CTRL快捷键 | L5184–5206 contains CONTROL：空草稿忙碌CtrlC→Interrupt，空草稿CtrlC/D→Quit，非空CtrlC→Interrupt | 目标取消与焦点路由分层；该分支不是KeyBinding精确等值，也没有已读AltGr例外。CtrlAlt可能落入CONTROL分支是静态风险，真实Windows事件尚未复现 |
| 最终字符插入 | L5348–5365只排除ALT/CONTROL，没有排除SUPER | 目标字符过滤不一致：Super字符虽跳过burst仍可能在后段插入。这里是可达性待验证候选，不能说已发生实际用户数据损坏 |
| Esc | L5478–5497历史草稿恢复、空输入Interrupt、非空保持draft并给状态 | 属于目标语义，不能以Codex的footer或双击退出实验覆盖目标CtrlC/D合同 |

共同可借鉴的是把显示与binding定义集中、使同一动作的提示来源清晰，并显式记录平台和焦点条件。实际迁移须先确定目标动作owner及事件阶段；本报告没有创建新抽象或修改src/tui.rs。对无法显示的修饰键，后续可选择扩展文案或拒绝公开此binding，但当前源没有实施任何一种策略，不能把建议记成已有功能。

## 已有release证据与本轮零执行分账

封存主库历史public manifest SHA256 `4a3e21c0fb5738b18abbda180fea89282c69932cbf7d916aa9aa87bd800ece7f`，原目录`.ops/stage1_execution/release-background-20260912`。manifest记录126个artifacts、complete=false；master-verification记录226个构建输入检查通过。worker仅逐项校验本包选入的原文件bytes/hash，不声称重新读取或复跑全部126个原始artifact或226个输入。build-inputs原表已原样保留，仅将TUI条目与本轮捕获绑定。

所有7套UX结果记录相同binary SHA256 `1d7b2e61ecc9096ad0f5e6cd3f3c03c6820cafe8371d9201de3497bb6b4e8f58`，binary.json记录6033168B；本轮未运行或重新hash二进制本体。各自run.json exit_code=0，结果文件由public manifest绑定。run.json里的sha256绑定output log，不是结果JSON，不能拿它冒充结果hash。

| 历史套件 | 原结果形态与数量 | 原证据限定 |
| --- | --- | --- |
| background | 4个布尔checks=true；status passed；1TUI/2HTTP | 后台badge/footer出现、当前Unicode草稿布局保持；切回AltA/y/Enter后仅来源cwd写入，完成提示消失 |
| approval | 14个布尔checks=true；passed=true；12HTTP | full_diff_scrolling只覆盖80行fixture；stale once只验证该错误项目路径，不是所有身份tuple竞态 |
| bentobox | 11个checks条目；其中9布尔true、1尺寸列表、1加号操作对象；status passed；3TUI | resize为1×1、40×12、100×28、180×45、140×40；3次加号操作依赖恰有1个直接子目录，不是任意路径上界 |
| picker | 12条assertions字符串；status passed | 含Unicode/空格/alias/同basename、实际cwd写入、迟到输出来源、重启和terminal restored；不误报成12个布尔checks |
| new | 8布尔checks=true；status passed；4TUI/5JSONL/6HTTP | 同项目新会话、上下文隔离、幂等、草稿/layout恢复、真实请求、取消/CAS |
| policy | 9布尔checks=true；status passed；3TUI/2JSONL/21HTTP | pending/审批/scheduled阻止，后台不阻塞idle项目，授权scope；configured Deny与bound worker仍另验 |
| recovery | 3布尔checks=true；status passed；4JSONL/4HTTP | macOS/Unix pre/postcommit强杀及replay打开失败恢复，不是全部grace/postcommit时序 |

/new三套合计20组、7TUI、11JSONL、31HTTP是历史套件的汇总；本轮新增0。七套发布交互并不专门验证key_hint的Windows/macOS文字、AltGr真实输入、Super键或Press/Repeat/Release全矩阵。

同一历史budget.json记录8/8 gates true、ok=true：依赖15、binary6033168B、冷启动5样本751.967292/44.427125/45.611625/45.128208/38.709ms，max751.967292ms，RSS max5111808B；queue1593.783µs、render662.788µs、layout1.07245µs、10000 dirty合并1帧。没有丢首样本或用median代替最大值。本次通过只属于该release该组样本。review.md保留旧1044.823959ms和1208.732708ms失败的指向；本包没有复制旧失败全部原件，也没有归因冷启动波动根因已修复。PID3781是time包装进程而非已辨认zenpi child；1.95GB构建进程树不能当产品RSS。

budget原JSON完整保存；本轮解析指标与原始流身份，并离线解码校验其5组stdout/stderr字节、hash和未截断长度，只是证据完整性检查。未执行计时器或产品。历史review中的4个Python诊断fixture测试是仪器测试；此前52项Rust/Clippy也不是本轮新增。release manifest的complete=false保持，不据七套通过推导蓝图完成。

## 最小实验矩阵（建议，全部未执行）

这些实验由后续获授权的产品owner选择执行，不能将源阅读、Python结构检查或git apply回放记为通过。每组必须记录实际binary/source、目标OS、终端、键盘布局、输入序列、观察值和退出/恢复状态；对于权限、资源或焦点失败保留旧有效状态，不使用静态推断替代真实入口。

### P01 — 精确 key 与全部 modifiers

最小输入：构造 plain/ctrl/ctrl_alt 的 Press、Repeat、Release，加入额外 Shift/Super 并改变 Char 大小写。

判据：只有同 code 同全部 modifiers 的 Press/Repeat 匹配；Release 拒绝；记录宿主前置路由差异。状态：本轮未执行；静态阅读提出的实验要求。

### P02 — 五个 const 构造器

最小输入：检查 NONE、ALT、SHIFT、CONTROL、CONTROL|ALT 的值及 new 任意组合。

判据：各构造器与 new 等值；不隐式添加或删除位。状态：本轮未执行；静态阅读提出的实验要求。

### P03 — 显示修饰键顺序固定

最小输入：CONTROL|SHIFT|ALT 及仅 Super/Hyper/Meta，与 plain 相同 Char 对比。

判据：只显示 ctrl、shift、alt，遗漏位仍参与匹配；记录可见字符串碰撞。状态：本轮未执行；静态阅读提出的实验要求。

### P04 — 八个显式键名

最小输入：Enter、Space、四箭头、PageUp/Down、其余 fallback、ASCII 大写与非 ASCII。

判据：专用名精确；fallback仅ASCII小写；不从显示反推原 KeyCode。状态：本轮未执行；静态阅读提出的实验要求。

### P05 — 测试配置统一 Option 前缀

最小输入：分别比较 test、macOS non-test、Linux/Windows non-test 的 Alt 文案。

判据：test总为⌥；生产非macOS为alt；fixture不能单独证明生产平台文字。状态：本轮未执行；静态阅读提出的实验要求。

### P06 — Windows AltGr 启发式

最小输入：真实 Windows AltGr、人工 CtrlAlt、CtrlAltShift 输入以及 Linux/WSL 对照。

判据：记录真实终端事件；CTRL+ALT 在 Windows helper一律排除，非Windows不排除；避免丢字或误触命令。状态：本轮未执行；静态阅读提出的实验要求。

### P07 — dim Span 与布局边界

最小输入：owned/borrowed 转 Span，比对 content/style；窄屏、Unicode、缺失字形、resize。

判据：同内容同DIM；渲染层自行裁剪；不把 DarkGray 当作 DIM 等价。状态：本轮未执行；静态阅读提出的实验要求。

### P08 — 显示条件由调用者选择

最小输入：WSL开关、ShiftEnter设置、协作模式开关及审批焦点组合。

判据：first matching descriptor；提示只在适用状态出现；事件真实路径与提示一致。状态：本轮未执行；静态阅读提出的实验要求。

### P09 — 目标提示按优先级覆盖

最小输入：保存失败同时后台待审批、邻接粘贴、宽99/100、无答复AltC。

判据：warning优先，其次background、paste、宽度；无答复有可见反馈；裁剪后仍可发现所需操作。状态：本轮未执行；静态阅读提出的实验要求。

### P10 — 目标取消与焦点路由

最小输入：picker/审批焦点、空闲空草稿/忙碌/非空 CtrlC/D、Esc及额外修饰键。

判据：真实owner收到正确操作，草稿保留或中断符合合同；不移植双击退出。状态：本轮未执行；静态阅读提出的实验要求。

### P11 — 目标字符过滤不一致

最小输入：Super+Char、CtrlAlt+Char、Repeat普通字、Release前有待flush文本。

判据：分类、插入和快捷键分别记录；不因Press-only分派而假定Repeat全过程无副作用。状态：本轮未执行；静态阅读提出的实验要求。

### P12 — 发布证据不替代平台验证

最小输入：在后续授权执行时绑定同一binary、host、键盘/终端，保存输入/输出和恢复状态。

判据：保留已有release证据范围；补跨平台、窄屏、权限/剪贴板失败与恢复；未执行不得记通过。状态：本轮未执行；静态阅读提出的实验要求。

## 证据包、补丁与接收边界

证据目录`Docs/quality/stage1/ZS1-308/worker-key-hint-review-3.1.20`包含source/key_hint.rs、原worker报告、原ready receipt、蓝图快照、18段必要上下文及全文件捕获身份、历史release选入原件、函数/测试/能力清单、连续阅读日志和master-baseline.json。原报告的“AltGr保证普通文本不被吞”措辞在此收窄为特定调用路径启发式；旧报告原字节未覆盖。

master标准报告在本轮单独只读检查时不存在，因此master.patch仅新增该报告；worker.patch从封存原worker报告精确更新。两个补丁均只包含一个标准report路径。隔离临时目录先git init，再分别forward check/apply、reverse check/apply，并验证新旧原字节、master新增文件逆向删除和无关sentinel不变，共8步。绝不在主库或worker根目录试apply。check_static.py与verify_package.py只作离线结构、hash和补丁校验，不验证产品行为或代替语义G-FILE。

ready的manifest冻结所有随包文件bytes/SHA256；README给出离线复核入口。原ready及301/302/303/304/305/306/307和其他既有ready保持原样。master接收前应复核当前标准路径基线；若后来已有不同文件，停止直接apply，按精确基线重制独立补丁，禁止force覆盖。撤回仅反向应用本报告补丁，不动产品、主库会话、蓝图/索引或已接受其它报告。

本轮只有单文件报告与独立证据产出，Cargo0、PTY0、HTTP0、产品实验0、主库写入0、子agent0。阅读与静态映射完成后停在ZS1-308边界；master是否接受本文件，以及ZS1-125/353/其它生产合同是否完成，仍由各自独立验收决定。
