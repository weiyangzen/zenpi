# codex-rs/tui/src/key_hint.rs — candidate whole-file review

Status: [_] master acceptance pending.
Source path: `codex-rs/tui/src/key_hint.rs`
Source root: `/Users/wangweiyang/GitHub/codex`
Source bytes: 3306
Source SHA256: `07f34aab630b2658560d2d4e73719481ec8638e33eb38401d7a23643689f13c8`
Reference HEAD: `b3b3d262787f4902a7449f17d793241a34d311ad`

## Behavior

Key binding display and matching. All 112 lines read. KeyBinding matches exact code and modifiers, accepts press and repeat. ctrl/alt/shift/ctrl_alt constructors share one dim Span formatter; platform-specific alt prefix and named arrow/page/space keys are explicit. has_ctrl_or_alt excludes Windows AltGr so ordinary text is not swallowed. No tests are defined in this file.

## Zenpi mapping and limitations

Zenpi currently has hand-written footer hints and accepts Press only in its event router. Preserve actual Ctrl-C interrupt/Ctrl-D quit rather than copying Codex Esc wholesale. Add discoverable transcript/reasoning/copy bindings that match the real key path; modified AltGr text remains a composer concern for 122.

## Validation and coverage

One <=256KiB chunk; file hash below. No source build/tests run; this is a read-only behavior audit, not Codex test evidence. Byte range [0,3306) is contiguous and equals the whole file; its chunk SHA256 equals source SHA256. This is one file report, not a grouped replacement. Directory integration can only count this report after master acceptance and must include every other frozen direct file/child directory.
