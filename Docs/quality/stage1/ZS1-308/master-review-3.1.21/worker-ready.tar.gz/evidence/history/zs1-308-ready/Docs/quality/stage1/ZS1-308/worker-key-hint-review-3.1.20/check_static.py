"""Offline evidence structure and hashes only; no product execution."""
from pathlib import Path
import hashlib,json,re,base64
E=Path(__file__).resolve().parent;root=E.parents[4]
def read(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def bound(p,r):
 b=p.read_bytes();assert len(b)==r['bytes'] and sha(b)==r['sha256'],str(p)
s=(E/'source/key_hint.rs').read_bytes();assert len(s)==3306 and len(s.splitlines())==112 and sha(s)=='07f34aab630b2658560d2d4e73719481ec8638e33eb38401d7a23643689f13c8'
assert not re.search(r'#\[(?:test|tokio::test)',s.decode());assert read(E/'source-tests.json')==[]
rl=read(E/'read-log.json');assert rl['formal_byte_chunks']==[[0,3306]] and rl['sequential_reads'][0]['sha256']==sha(s)
inputs=read(E/'inputs.json');assert inputs['formal_files']==1 and len(inputs['files'])==44
for r in inputs['files']:bound(root/r['snapshot'],r)
cs=read(E/'context-capture.json');assert len(cs)==5 and sum(len(c['excerpts']) for c in cs)==18
assert len(cs[0]['excerpts'])==9 and cs[0]['full_bytes']==579524 and cs[0]['full_sha256']=='d2a98934d4931a5aa202e542acd556bdda5667f0e60df11a68731dacf00eccf1'
report=(root/'Docs/learn/stage1_pi_mono/references/codex/files/codex-rs/tui/src/key_hint.rs_learn.md').read_text()
assert not re.search(r'^\s*[-*]\s+\[[xX]\]',report,re.M)
funcs=[(i,m[1]) for i,l in enumerate(s.decode().splitlines(),1) if (m:=re.search(r'\bfn (\w+)\(',l))]
inv=read(E/'function-inventory.json');assert len(inv)==14 and [(r['source_line'],r['name']) for r in inv]==funcs
assert all(r['read'] and r['name'] in report for r in inv)
mat=read(E/'capability-matrix.json');assert len(mat)==12 and all(not r['executed_in_308'] and r['source_fact'] in report for r in mat)
ct=read(E/'context-tests.json');assert ct['context_only'] and ct['executed']==0 and len(ct['tests'])==1
for t in ct['tests']:
 lines=(E/t['snapshot']).read_text().splitlines();assert lines[t['source_line']-1706].strip()==f"fn {t['name']}() {{";assert t['name'] in report
for token in ['源测试实际执行数0','AltGr','SUPER','Repeat','Release','first','1044.823959','1208.732708','P12','d2a989','complete=false']:assert token in report,token
h=E/'history/release';m=read(h/'manifest.json');assert sha((h/'manifest.json').read_bytes())=='4a3e21c0fb5738b18abbda180fea89282c69932cbf7d916aa9aa87bd800ece7f';assert len(m['artifacts'])==126 and m['complete'] is False
selected=[]
for p in h.iterdir():
 if p.name in m['artifacts']:bound(p,m['artifacts'][p.name]);selected.append(p.name)
assert read(h/'master-verification.json')['sha256']==sha((h/'manifest.json').read_bytes())
assert read(h/'build-inputs.json')['src/tui.rs']['sha256']==cs[0]['full_sha256']
binary=read(h/'binary.json');assert binary==dict(sha256='1d7b2e61ecc9096ad0f5e6cd3f3c03c6820cafe8371d9201de3497bb6b4e8f58',bytes=6033168)
summ=[]
for name,count in [('background',4),('approval',14),('bentobox',11),('picker',12),('new',8),('policy',9),('recovery',3)]:
 d=read(h/(name+'.json'));run=read(h/(name+'.run.json'));assert d['binary_sha256']==binary['sha256'] and run['exit_code']==0
 assert d.get('status')=='passed' or d.get('passed') is True
 checks=d.get('checks',d.get('assertions'));assert len(checks)==count
 if name not in ['bentobox','picker']:assert all(v is True for v in checks.values())
 elif name=='bentobox':assert sum(v is True for v in checks.values())==9 and isinstance(checks['plus_to_valid_project'],dict) and isinstance(checks['responsive_resize_preserves_unicode_draft_and_layout'],list)
 else:assert isinstance(checks,list) and all(isinstance(v,str) for v in checks)
 summ.append(dict(name=name,entries=count,run_exit=0,scope='historical only'))
b=read(h/'budget.json');assert len(b['gates'])==8 and all(v is True for v in b['gates'].values()) and b['ok'] is True
assert b['cold_start']['elapsed_ms']['samples']==[751.967292,44.427125,45.611625,45.128208,38.709]
streams=0
for obs in b['cold_start']['observations']:
 assert obs['binary_sha256']==binary['sha256'] and obs['returncode']==0 and obs['timed_out'] is False
 for name in ['stdout','stderr']:
  rec=obs[name];raw=base64.b64decode(rec['prefix_base64'],validate=True);assert not rec['truncated'] and len(raw)==rec['bytes'] and sha(raw)==rec['sha256'];streams+=1
assert streams==10 and read(h/'budget.run.json')['exit_code']==0
print(json.dumps(dict(passed=True,kind='offline structure; semantic G-FILE pending',source_bytes=3306,source_lines=112,source_functions=14,compiled_function_definitions=13,source_tests_read=0,source_tests_executed=0,context_tests_read=1,context_tests_executed=0,capability_groups=12,input_snapshots_checked=44,all_context_excerpts=18,target_context_excerpts=9,historical_manifest_members_checked=len(selected),historical_results=summ,raw_stream_hashes_checked=streams,cargo_runs=0,pty_runs=0,http_runs=0),ensure_ascii=False,indent=2))
