# codex-rs/tui/src/slash_command.rs — whole-file candidate review

Status: [_] master acceptance pending.
Source root: `/Users/wangweiyang/GitHub/codex`
Reference HEAD: `b3b3d262787f4902a7449f17d793241a34d311ad`
Source bytes: 8020
Source SHA256: `9e53ca5bff5a5e7b86aa97731da985082db5d130c453e2d363edb9c5758ebc5a`
Read coverage: 217/217 lines, including all inline tests if present. Single chunk [0,8020), <=256KiB; chunk hash equals source hash. Frozen blueprint hash matches.

The enum declaration order is the popup presentation order, not alphabetical. String derives provide kebab-case names, special spellings and aliases; stop is canonical while clean parses as its alias. Each command carries a short user-facing description, an explicit inline-argument capability and an exhaustive available_during_task match. Visibility additionally hides Windows-only sandbox path controls elsewhere, Android clipboard and release-only debug commands. built_in_slash_commands filters this authoritative enum, rather than duplicating a UI list.

The two inline tests check canonical stop and clean parsing. No runtime, model capability fetch or actual handler is implemented in this file, so its list alone does not prove a command works. Zenpi should derive visible completions from COMMAND_SPECS plus the current resource catalogue and actual available model metadata. Busy/idle dispatch must agree with what the menu enables; accepting a name is distinct from executing it. Templates must not shadow builtins or send malformed slash commands to a provider. Unsupported Codex-specific commands are not Zenpi menu candidates.

Candidate mapping: ZS1-123. This is a standalone file review; directory completion awaits every registered file and direct child directory accepted by the master. No external reference tests were run or claimed.
