# codex-rs/tui/src/status_indicator_widget.rs — candidate whole-file review

Status: [_] master acceptance pending.
Source path: `codex-rs/tui/src/status_indicator_widget.rs`
Source root: `/Users/wangweiyang/GitHub/codex`
Source bytes: 15810
Source SHA256: `e35e3efbd18784b55343366b2001bda08dfc1543f7e4a88700a715562d519cc5`
Reference HEAD: `b3b3d262787f4902a7449f17d793241a34d311ad`

## Behavior

Busy status, elapsed time and interrupt affordance. All 440 lines read, including seven inline tests. Widget owns header/details/inline message, explicit interruption dispatch, running elapsed duration with idempotent pause/resume, optional animations and frame requests. It formats seconds/minutes/hours, wraps prefixed details with bounded line count and ellipsis, truncates header to width and keeps interrupt hint before optional context. Animations request a frame after32ms. Tests cover elapsed formatting, wide/narrow snapshots, detail wrapping/truncation, preservation of capitalization and paused timing.

## Zenpi mapping and limitations

Zenpi has a spinner/status line and footer, but no elapsed timer, context/token/model summary or explicit background-project status. Use shared AgentSnapshot and actual provider Usage values, show approval waiting distinctly and never infer token counts. Reasoning must remain separate from answer; status may summarize it but never turn it into final text. Keep existing BentoBox pane composition.

## Validation and coverage

One <=256KiB chunk; file hash below. Source tests inspected, not executed in the large external Codex tree. Byte range [0,15810) is contiguous and equals the whole file; its chunk SHA256 equals source SHA256. This is one file report, not a grouped replacement. Directory integration can only count this report after master acceptance and must include every other frozen direct file/child directory.
