# codex-rs/tui/src/bottom_pane/paste_burst.rs — whole-file candidate review

Status: [_] master acceptance pending; ZS1-302.
Source root: `/Users/wangweiyang/GitHub/codex`
Reference HEAD: `b3b3d262787f4902a7449f17d793241a34d311ad`
Source bytes: 24594
SHA256: `c80558dfd3cbde437f2fec9a855b01a3180542a53bb135dc92ce7c81299f1ee7` (matches frozen blueprint).
Read coverage:572/572 lines in contiguous1–320 and321–572 ranges, including5 inline tests. Single chunk [0,24594), <=256KiB; chunk hash equals source hash.

A pure state machine for terminals that deliver pasted content as rapid ordinary key events. ASCII initially holds one character; a second sufficiently fast character begins a buffer without rendering the held character. The non-ASCII/IME route never holds its first character and can retro-capture an already displayed prefix only when it contains whitespace or at least16 characters. Retro-capture counts characters and returns a UTF-8 byte boundary. Normal/non-Windows inter-character and active-idle thresholds are8ms; Windows uses30ms and60ms. Enter suppression lasts120ms after burst activity, including after the buffer flush.

Flush and clear are intentionally different operations. Before modified or non-character input, the caller must flush buffered/pending input, apply it through paste handling, then clear timing state. Clearing without flushing can strand or drop pending content. Explicit bracketed paste clears all burst state. Idle checks use strict greater-than comparisons, and tests cross thresholds by at least1ms. The module itself never mutates the textarea and does not impose a byte cap on its buffer; the host must retain its own bounded input admission.

The5 source tests verify held ASCII flush, two-character buffering, pending-character flush before modified input, selective retro-capture and suppression after flush. They were fully read, not executed. Caller interactions and large composition tests are in chat_composer.rs and are not implicitly accepted by this report.

Zenpi122 mapping: preserve existing explicit bracketed-paste handling; route any fallback detector only through plain character input, never Ctrl/Alt command chords. Flush before focus/project changes and tick while idle so no first character sticks. Keep the canonical draft bound and avoid interpreting pasted slash/shell text as immediate submission. If adopted, PTY helpers must distinguish simulated typing from intentionally rapid paste; tests must verify literal multiline input and no unintended provider or shell dispatch. This is reference behavior, not an unqualified requirement to use the same timing constants on every terminal.
