# codex-rs/tui/src/file_search.rs — whole-file candidate review

Status: [_] master acceptance pending.
Source root: `/Users/wangweiyang/GitHub/codex`
Reference HEAD: `b3b3d262787f4902a7449f17d793241a34d311ad`
Source bytes: 4009
Source SHA256: `7aaa33ac7fd28cbe5fa3405cd3490b30e614272122bb572c9c352acc418b71d9`
Read coverage: 133/133 lines, including all inline tests if present. Single chunk [0,4009), <=256KiB; chunk hash equals source hash. Frozen blueprint hash matches.

FileSearchManager owns one codex-file-search session rooted at an explicit cwd. Query edits update the existing session, equal queries are ignored, and empty queries drop it. A cwd update drops the session and clears the query before the next search. Starting a session increments a wrapping token; its reporter shares a mutex-protected latest query and sends snapshots tagged with their own query. It discards callbacks from old sessions and empty queries. Indices are requested for matching highlights; session construction errors only log and keep no session.

There are no inline tests in this file; search implementation and UI result-consumer tests are outside this frozen file's scope. A notable consumer boundary is that the reporter checks session identity and query emptiness, not exact equality between snapshot.query and latest_query. A same-session stale-query snapshot still reaches the UI tagged with its query, so the consumer must reject it when inappropriate. Zenpi can use bounded local path completion with explicit project cwd and query/generation identity; result application must preserve draft text, source path and owner. Completion is discovery, not permission to read/execute a file. Project changes and cancellation must invalidate pending results. No need to import Codex's search runtime as a second application owner.

Candidate mapping: ZS1-123. This is a standalone file review; directory completion awaits every registered file and direct child directory accepted by the master. No external reference tests were run or claimed.
