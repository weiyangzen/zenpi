# ZS1-308 independent offline candidate

Only formal report: Docs/learn/stage1_pi_mono/references/codex/files/codex-rs/tui/src/key_hint.rs_learn.md
Source: 3306 bytes, 112 lines, SHA256 07f34aab630b2658560d2d4e73719481ec8638e33eb38401d7a23643689f13c8.

Run from any directory:

    python3 <ready>/Docs/quality/stage1/ZS1-308/worker-key-hint-review-3.1.20/verify_package.py

This checks every manifest member, source identity, 44 frozen inputs, historical result formats and raw-stream hashes, then replays both single-report patches in isolated temporary Git repositories. No Cargo, PTY, HTTP or product execution. Source tests defined/read/executed: 0/0/0; context tests read/executed: 1/0. Twelve proposed experiment groups are unexecuted.

master.patch adds the report to the individually checked absent master path. worker.patch replaces only the exact original report preserved in history. Check the receiving baseline before applying. If the master path now exists, do not force application; prepare an exact-baseline patch. Reverse only this report patch for rollback. Never reset or clean the repository.

Manifest status remains candidate; master semantic G-FILE acceptance pending. Historical release 1d7b2e61 and all seven UX suites remain historical evidence, not new worker runs. Current source TUI capture d2a98934 is frozen, not tracked live. Old cold-start failures remain unresolved and are not overwritten.
