from pathlib import Path
import datetime,hashlib,json,os,shutil,stat,subprocess
W=Path(__file__).resolve().parent;ROOT=W.parent.parent;M=Path('/Users/wangweiyang/GitHub/zenpi');C=Path('/Users/wangweiyang/GitHub/codex')
def info(p):
 assert stat.S_ISREG(p.lstat().st_mode),str(p)
 b=p.read_bytes();return {'bytes':len(b),'lines':len(b.splitlines()),'sha256':hashlib.sha256(b).hexdigest()}
def inv(p):
 result={}
 for d,ds,fs in os.walk(p,followlinks=False):
  ds[:]=[n for n in ds if not Path(d,n).is_symlink()]
  for n in fs:
   f=Path(d,n)
   if stat.S_ISREG(f.lstat().st_mode):result[str(f.relative_to(p))]=info(f)
 return result
def dump(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
roots=sorted(p for p in (ROOT/'.ops').glob('*-ready') if p.is_dir())+[ROOT/'.ops/stage125-render-review320/ready',ROOT/'.ops/stage126-independent320/ready',ROOT/'.ops/stage126-independent320/ready-final']
tracked={str(ROOT/x.decode()):info(ROOT/x.decode()) for x in subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).split(b'\0') if x and (ROOT/x.decode()).is_file()}
before={'ready':{str(p):inv(p) for p in roots},'tracked':tracked};dump(W/'preservation-before.json',before)
selected={'codex':['AGENTS.md','codex-rs/tui/src/key_hint.rs','codex-rs/tui/src/bottom_pane/footer.rs','codex-rs/tui/src/bottom_pane/chat_composer.rs','codex-rs/tui/src/bottom_pane/textarea.rs','codex-rs/tui/src/bottom_pane/mod.rs','codex-rs/tui/src/bottom_pane/approval_overlay.rs'],'zenpi':['src/tui.rs','tests/tui_composer.rs','Docs/stage_1_v3_pi_mono_blueprint.md','Docs/execution/active_requirement.json','Docs/learn/stage1_pi_mono/references/codex/source_manifest.tsv','Docs/learn/stage1_pi_mono/references/codex/file_learn_index.tsv']}
files=[]
for tag,paths in selected.items():
 for rel in paths:
  src={'codex':C,'zenpi':M}[tag]/rel;dst=W/'capture'/tag/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);assert info(src)==info(dst);files.append({'path':str(dst.relative_to(W)),'origin':str(src),'role':'subject-full' if rel=='codex-rs/tui/src/key_hint.rs' else 'context-only',**info(dst)})
external=[]
for name in ['zs1-308-ready','codex-reference-ready']:
 src=Path('/Users/wangweiyang/.codex/worktrees/2267/zenpi/.ops')/name;dst=W/'history'/name;shutil.copytree(src,dst);x=inv(src);assert inv(dst)==x;external.append({'origin':str(src),'path':str(dst.relative_to(W)),'files':x})
dump(W/'external-preservation-before.json',external)
dump(W/'capture.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'item':'ZS1-308','version':'3.1.21','codex_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=C,text=True).strip(),'files':files,'old_ready':len(roots),'old_ready_regular':sum(map(len,before['ready'].values())),'tracked':len(tracked),'read_claim':'Copies alone are not a complete read of a context file.'})
dump(W/'preparation-issues.json',[])
print(json.dumps({'captures':len(files),'old_ready':len(roots),'old_ready_regular':sum(map(len,before['ready'].values())),'tracked':len(tracked),'historical_files':[len(x['files']) for x in external],'source':files[1]},indent=2))
