from pathlib import Path
import hashlib,json,sys
W=Path(__file__).resolve().parent;src=W/sys.argv[1];lo,hi=map(int,sys.argv[2:4]);b=src.read_bytes();lines=b.splitlines(keepends=True);assert 1<=lo<=hi<=len(lines);a=sum(map(len,lines[:lo-1]));z=sum(map(len,lines[:hi]));chunk=b[a:z];assert len(chunk)<=256*1024
p=W/'reads';p.mkdir(exist_ok=True);index=W/'read-binding.json';rows=json.loads(index.read_text()) if index.exists() else [];out=p/f'{len(rows)+1:03d}.txt';assert not out.exists();out.write_bytes(chunk)
rows.append({'source':str(src.relative_to(W)),'source_bytes':len(b),'source_sha256':hashlib.sha256(b).hexdigest(),'lines':[lo,hi],'byte_range':[a,z],'path':str(out.relative_to(W)),'bytes':len(chunk),'sha256':hashlib.sha256(chunk).hexdigest()});index.write_text(json.dumps(rows,indent=2)+'\n')
for i,s in enumerate(chunk.decode().splitlines(),lo):print(f'{i}: {s}')
