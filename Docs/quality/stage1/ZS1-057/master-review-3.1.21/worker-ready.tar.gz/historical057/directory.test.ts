import {it,expect,afterAll} from 'vitest';
import {writeFileSync} from 'node:fs';
import {Agent} from './source/packages/agent/src/agent.ts';
import {prepareCompaction,compactWithRequest} from './source/packages/agent/src/harness/compaction/compaction.ts';
import {buildSessionContext} from './source/packages/agent/src/harness/session/context.ts';
import {convertToLlm} from './source/packages/agent/src/harness/messages.ts';
import {BACKGROUND_CONTEXT as bg,withAbortSignal} from './source/packages/agent/src/harness/context.ts';
import {getOrThrow} from './source/packages/agent/src/harness/types.ts';
import {model,user,assistant,toolCall,scriptedStream} from './fixture-helpers.mjs';
const records:any[]=[];const settings={enabled:true,reserveTokens:100,keepRecentTokens:8};
const deferred=()=>{let resolve!:()=>void;const promise=new Promise<void>(r=>resolve=r);return {promise,resolve};};
const text=(s:string)=>assistant([{type:'text',text:s}]);
const requestsUsers=(r:any)=>r.context.messages.filter((m:any)=>m.role==='user').map((m:any)=>typeof m.content==='string'?m.content:m.content.map((c:any)=>c.text||'').join(''));
const entries=(ms:any[])=>ms.map((message,i)=>({type:'message',id:'m'+i,parentId:i?'m'+(i-1):null,seq:i,timestamp:i,message}));
function gatedTool(start:any,gate:any):any{return {name:'fixture_tool',label:'fixture',description:'in-memory gate',parameters:{type:'object',properties:{},additionalProperties:false},execute:async()=>{start.resolve();await gate.promise;return {content:[{type:'text',text:'TOOL_RESULT'}],details:{}};}};}
afterAll(()=>writeFileSync(process.env.DIR_OBSERVATIONS!,JSON.stringify(records,null,2)+'\n'));

it('D057-01 real Agent queues join context projected by actual compaction after long preparation',async()=>{
 const started=deferred(),toolGate=deferred(),summaryStarted=deferred(),summaryGate=deferred();
 const requests:any[]=[],events:string[]=[],summaryPrompts:string[]=[];let preparations=0;let checkpoint:any;
 const agent=new Agent({initialState:{model,messages:[user('OLD_HISTORY'),text('old done')],tools:[gatedTool(started,toolGate)]},convertToLlm,
 streamFn:scriptedStream([assistant([toolCall('call','fixture_tool',{})],'toolUse'),text('after S1'),text('after S2'),text('after F1')],requests),
 prepareNextTurnWithContext:async(snapshot:any,signal:any)=>{
  if(preparations++)return;
  const context=withAbortSignal(signal,bg);
  const p=getOrThrow(prepareCompaction(entries(snapshot.context.messages) as any,settings))!;
  const result=getOrThrow(await compactWithRequest(p,{model},async(ctx:any,options:any)=>{
   expect(options.signal).toBe(signal);summaryPrompts.push(ctx.messages[0].content[0].text);summaryStarted.resolve();await summaryGate.promise;return text('CHECKPOINT_PENDING');
  },context));
  checkpoint={type:'compaction',id:'cp',parentId:null,seq:10,timestamp:10,...result};
  const messages=await buildSessionContext([checkpoint],undefined,context);
  return {context:{...snapshot.context,messages}};
 }});
 agent.subscribe(e=>{events.push(e.type);});
 const running=agent.prompt('task');await started.promise;toolGate.resolve();await summaryStarted.promise;
 agent.steer(user('S1'));agent.steer(user('S2'));agent.followUp(user('F1'));expect(requests).toHaveLength(1);
 summaryGate.resolve();await running;await agent.waitForIdle();
 expect(requests).toHaveLength(4);
 expect(requestsUsers(requests[1]).at(-1)).toBe('S1');expect(requestsUsers(requests[2]).at(-1)).toBe('S2');expect(requestsUsers(requests[3]).at(-1)).toBe('F1');
 expect(JSON.stringify(requests[1].context.messages)).toContain('CHECKPOINT_PENDING');
 expect(JSON.stringify(requests[1].context.messages)).not.toContain('OLD_HISTORY');
 expect(JSON.stringify(agent.state.messages)).toContain('OLD_HISTORY');expect(JSON.stringify(agent.state.messages)).not.toContain('CHECKPOINT_PENDING');
 expect(summaryPrompts.join('\n')).toContain('OLD_HISTORY');
 expect(agent.hasQueuedMessages()).toBe(false);expect(agent.state.isStreaming).toBe(false);expect(agent.state.pendingToolCalls.size).toBe(0);
 records.push({case:'D057-01',requests,summaryPrompts,checkpoint,events,agentState:agent.state.messages,preparedProviderContextDoesNotAutomaticallyReplaceAgentHistory:true});
});
it('D057-02 cooperative summary cancellation settles Agent and leaves late steering available for a fresh run',async()=>{
 const started=deferred(),toolGate=deferred(),summaryStarted=deferred(),summaryGate=deferred();const requests:any[]=[];let once=false;
 const agent=new Agent({initialState:{model,tools:[gatedTool(started,toolGate)]},streamFn:scriptedStream([assistant([toolCall('call','fixture_tool',{})],'toolUse'),text('fresh')],requests),
 prepareNextTurnWithContext:async(snapshot:any,signal:any)=>{
  if(once)return;once=true;const ctx=withAbortSignal(signal,bg);const p=getOrThrow(prepareCompaction(entries(snapshot.context.messages) as any,settings))!;
  getOrThrow(await compactWithRequest(p,{model},async()=>{summaryStarted.resolve();await summaryGate.promise;expect(signal.aborted).toBe(true);return assistant([],'aborted');},ctx));
 }});
 const running=agent.prompt('task');await started.promise;toolGate.resolve();await summaryStarted.promise;agent.steer(user('LATE_STEER'));agent.abort();summaryGate.resolve();await running;
 expect(agent.state.messages.at(-1)?.stopReason).toBe('aborted');expect(agent.state.isStreaming).toBe(false);expect(agent.state.pendingToolCalls.size).toBe(0);expect(agent.hasQueuedMessages()).toBe(true);
 await agent.prompt('fresh task');expect(requests).toHaveLength(2);expect(requests[1].aborted).toBe(false);expect(requestsUsers(requests[1])).toContain('LATE_STEER');expect(agent.hasQueuedMessages()).toBe(false);
 records.push({case:'D057-02',requests,cancelledPreparationThenFreshSignal:true,lateQueueRetainedUntilNextRun:true});
});
it('D057-03 preparation failure after early drain loses pending steering before any message event',async()=>{
 const started=deferred(),toolGate=deferred();const requests:any[]=[],messages:any[]=[];
 const agent=new Agent({initialState:{model,tools:[gatedTool(started,toolGate)]},streamFn:scriptedStream([assistant([toolCall('call','fixture_tool',{})],'toolUse')],requests),prepareNextTurnWithContext:async()=>{throw Error('PREPARE_FAILED');}});
 agent.subscribe(e=>{if(e.type==='message_end')messages.push(e.message);});
 const running=agent.prompt('task');await started.promise;agent.steer(user('EARLY_STEER'));toolGate.resolve();await running;
 expect(agent.state.messages.at(-1)?.stopReason).toBe('error');expect(agent.state.errorMessage).toContain('PREPARE_FAILED');
 expect(agent.hasQueuedMessages()).toBe(false);expect(JSON.stringify(messages)).not.toContain('EARLY_STEER');expect(JSON.stringify(agent.state.messages)).not.toContain('EARLY_STEER');expect(requests).toHaveLength(1);
 expect(agent.state.isStreaming).toBe(false);expect(agent.state.pendingToolCalls.size).toBe(0);
 records.push({case:'D057-03',requests,messages,drainedBeforePreparation:true,pendingInputLostOnPreparationError:true});
});

