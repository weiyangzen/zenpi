# ZS1-057 — packages/agent/src

Provisional [_]. Authority 3.1.18 / cb96a3db9b57ea0d9d3ad43f0be954129aabf69bc5d438210a14b674a4a8af85. Required direct files are agent-loop.ts (010) and agent.ts (011); the direct child is harness (054). These dependencies remain pending. The immediate inventory records index.ts, node.ts, proxy.ts, stream-fn.ts, types.ts and search as context-only.

Agent owns messages, pending tools, the active lifecycle promise and separate steering/follow-up queues. createLoopConfig binds their drain callbacks to agent-loop. The loop finishes tool batches, polls steering, prepares the next turn, injects pending input, and polls follow-up after the inner loop would stop. Preparation polls steering again only if the previous poll returned nothing.

Standalone Agent does not automatically invoke harness compaction or storage. The preparation callback is an explicit caller adapter. Barrel exports alone do not connect these owners.

## Three actual integration tests

D057-01 connects Agent → agent-loop → preparation callback → actual compaction helpers → session projection → harness convertToLlm. While the summary is gated, S1/S2/F1 are enqueued. Four requests observe the initial tool turn followed by S1, S2 and F1, once each. Prepared context contains the checkpoint summary and complete current tool turn, excluding older completed history. Agent finishes idle without pending tools or queued messages.

The prepared provider context does not replace Agent.state.messages automatically: public state still contains old history and no checkpoint summary. The caller created a checkpoint-shaped object for projection; no journal was committed.

D057-02 cancels the actual signal during summary generation. Agent records an aborted terminal message and clears streaming/pending-tool state. Steering added after the earlier empty poll remains queued; a fresh run in the same process consumes it with a new signal.

D057-03 queues steering during a gated tool, then throws from preparation. The loop already drained the item into its local pending array. Agent settles with an error, but the input is absent from both the queue and message-end events/history. Error cleanup does not prove admitted-input preservation.

All three pass with real Node 24.19.0, Vitest 4.1.9, TypeBox 1.3.27 and 31 unchanged source files. Streams use the actual AssistantMessageEventStream with scripted replies. Tools are in-memory gates. Old 010/011 process-tool evidence is referenced without rerunning or recounting it.

The initial one-token retention fixture ended on a tool result with no later valid cut and retained all history. Its failed expectation and exact logs are preserved. The final eight-token fixture retains the entire current tool turn while summarizing older history. No source or history-removal assertion was weakened.

## Ownership limits and closure

Cancellation, async ordering and throws execute real code. Provider networking, external tool effects, durable checkpoint commit, process restart and the AgentHarness runtime are not tested here. A fresh Agent run is not relabeled as restart recovery.

Zenpi input_queue/core/runtime must preserve admitted input through preparation failures. context/session own validation and durable publication; the caller must reconcile public history and prepared provider context. Existing product evidence remains separate.

The closure is 010 + 011 + 054 → 057 → 061. Child 054 includes 050/051. No context-only sibling or package is accepted by this provisional synthesis.

