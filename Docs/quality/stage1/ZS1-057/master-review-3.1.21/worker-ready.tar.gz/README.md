# ZS1-057 portable candidate, 3.1.21

Only the report under report/Docs/learn/stage1_pi_mono/packages/agent/src/current_folder_learn.md is proposed for authority integration. report.patch is its exact new-file patch. This private packet is not a master receipt or acceptance.

Run `python3 -B verify.py` from this packet, or pass the absolute path to verify.py from any working directory. Python standard library only; the verifier reads this packet, including tar members in memory, and prints JSON. It does not import/execute archived scripts or source code, contact the network, install packages, write files, or require the original workspace. Outer manifest checks bind every payload. Historical057 holds the original62 payloads and manifest; accepted/ preserves all83 actual receipt artifacts and the157-payload accepted054 archive. Original runtime logs remain historical.

read-ranges.json records seven new complete context reads,1138 lines. reused-read-boundaries.json distinguishes prior full-source/caller understanding. direct-inventory.json separates seven physical files/two directories from three formal children. source-final-check.json records current identity checks; it is a snapshot, not a claim about future mutations. External work/offline.run.json and offline.stdout.json record the actual fresh verifier execution after sealing.

057 remains pending independent master semantic review. Rollback is report-only. No product edits, old runners, FIFO changes, HOME/CODEX_HOME changes, new tasks,117 experiments or131 resumption.
