#!/usr/bin/env python3
"""Portable read-only evidence audit. Never imports/executes product or archived code."""
from pathlib import Path,PurePosixPath
import hashlib,json,csv,io,tarfile,difflib,re
ROOT=Path(__file__).resolve().parent
checks=[]
def check(name,value):
    if not value: raise AssertionError(name)
    checks.append(name)
def raw(rel):
    q=PurePosixPath(rel)
    if q.is_absolute() or '..' in q.parts: raise AssertionError('unsafe relative path')
    p=ROOT.joinpath(*q.parts)
    if p.is_symlink():raise AssertionError('symlink payload')
    return p.read_bytes()
def js(rel):return json.loads(raw(rel))
def ident(b,r):return len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256']
def txt(rel):return raw(rel).decode()
manifest=js('manifest.json'); rows=manifest['files']
check('outer payload names unique',len({r['path'] for r in rows})==len(rows))
check('all outer identities',all(ident(raw(r['path']),r) for r in rows))
check('exact outer inventory',{str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()}=={r['path'] for r in rows}|{'manifest.json'})
check('candidate scope only057',manifest['candidate_paths']==['Docs/learn/stage1_pi_mono/packages/agent/src/current_folder_learn.md'] and manifest['runtime_executions_this_round']==0)
cap=js('capture.json'); old=js('historical057/manifest.json')
check('old manifest identity',ident(raw('historical057/manifest.json'),cap['historical_manifest']))
check('old62 exact payloads',len(old['files'])==62 and all(ident(raw('historical057/'+r['path']),r) for r in old['files']))
check('old authority and pending states unchanged',old['authority']=='3.1.18' and all(not d['master_accepted'] for d in old['dependencies']))
for dep in cap['accepted_dependencies']:
    rp='accepted/'+dep['receipt']; receipt=js(rp)
    check(dep['item']+' actual receipt identity',ident(raw(rp),dep))
    check(dep['item']+' accepted authority',receipt['complete'] is True and receipt['manual_review']['decision']=='accepted' and receipt['requirement_digest']==manifest['requirement_digest'] and receipt['baseline_snapshot_sha256']==manifest['baseline_snapshot_sha256'])
    check(dep['item']+' all artifacts',len(receipt['artifacts'])==dep['artifact_count'] and all(ident(raw('accepted/'+r['path']),r) for r in receipt['artifacts']))
    if 'source_path' in receipt:
        sr=next(r for r in js('source-identities.json') if r['path']==receipt['source_path'])
        check(dep['item']+' full source read reuse',receipt['read_ranges']==[[0,sr['bytes']]] and receipt['source_hash']==sr['sha256'])
prefix='accepted/Docs/quality/stage1/ZS1-054/master-review-3.1.21/'
with tarfile.open(fileobj=io.BytesIO(raw(prefix+'worker-ready.tar.gz')),mode='r:gz') as archive:
    members=archive.getmembers(); names=[x.name for x in members]
    check('054 archive regular safe unique',len(names)==len(set(names)) and all(x.isfile() and not PurePosixPath(x.name).is_absolute() and '..' not in PurePosixPath(x.name).parts for x in members))
    blobs={x.name:archive.extractfile(x).read() for x in members}
    am=json.loads(blobs['manifest.json'])
    check('054 archive manifest identity',blobs['manifest.json']==raw(prefix+'worker-manifest.json'))
    check('054 archive157 payload identities',len(am['files'])==157 and all(ident(blobs[r['path']],r) for r in am['files']) and set(names)=={r['path'] for r in am['files']}|{'manifest.json'})
    check('054 source reuse capture24',len(js('accepted054-source-identities.json'))==24 and all(ident(blobs[r['archive_member']],r) for r in js('accepted054-source-identities.json')))
check('captured source copies identities',all(ident(raw(r['evidence_path']),r) for r in js('source-identities.json')))
reads=js('read-ranges.json')
check('new complete contexts1138 lines',len(reads)==7 and sum(r['line_ranges'][0][1] for r in reads)==1138 and all(r['read_ranges']==[[0,r['bytes']]] and r['line_ranges']==[[1,len(raw('context-source/'+r['path']).splitlines())]] and not r['formal_acceptance'] for r in reads))
inv=js('direct-inventory.json')
check('physical seven files two dirs',len(inv)==9 and sum(r['kind']=='file' for r in inv)==7 and sum(r['kind']=='directory' for r in inv)==2)
check('formal children versus physical context',{r['name']:r['formal_item'] for r in inv if r['formal_item']}=={'agent-loop.ts':'ZS1-010','agent.ts':'ZS1-011','harness':'ZS1-054'})
check('harness12files7dirs',sum(x['kind']=='file' for x in next(r for r in inv if r['name']=='harness')['direct_children'])==12 and sum(x['kind']=='directory' for x in next(r for r in inv if r['name']=='harness')['direct_children'])==7)
check('search one actual file',[x['name'] for x in next(r for r in inv if r['name']=='search')['direct_children']]==['index.ts'])
fi=list(csv.DictReader(io.StringIO(txt('authority/Docs/learn/stage1_pi_mono/file_learn_index.tsv')),delimiter='\t'))
di=list(csv.DictReader(io.StringIO(txt('authority/Docs/learn/stage1_pi_mono/folder_learn_index.tsv')),delimiter='\t'))
check('formal file index exact direct set',{r['item_id'] for r in fi if str(PurePosixPath(r['source_path']).parent)=='packages/agent/src'}=={'ZS1-010','ZS1-011'})
check('formal directory index exact direct set',{r['item_id'] for r in di if str(PurePosixPath(r['folder_path']).parent)=='packages/agent/src'}=={'ZS1-054'})
d057=next(r for r in di if r['item_id']=='ZS1-057')
check('057 dependency scope pending',d057['depends']=='ZS1-010,ZS1-011,ZS1-054' and d057['status']=='[ ]' and not cap['current057receipt_present'])
check('061 pending',next(r for r in di if r['item_id']=='ZS1-061')['status']=='[ ]')
blue=txt('authority/Docs/stage_1_v3_pi_mono_blueprint.md')
check('blueprint agrees local closure',all('- [x] **ZS1-'+n+'**' in blue for n in ('010','011','054')) and '- [ ] **ZS1-057**' in blue)
selector=js('authority/Docs/execution/active_requirement.json')
check('selector relevant frozen sources',all(selector['baseline_files'][dep]['sha256']==js('accepted/Docs/learn/stage1_pi_mono/receipts/'+dep+'.master.json')['source_hash'] for dep in ('ZS1-010','ZS1-011')))
ctx='context-source/packages/agent/src/'
check('node export declarations',txt(ctx+'node.ts').splitlines()==['export { NodeExecutionEnv } from "./harness/env/nodejs.ts";','export * from "./index.ts";'])
index=txt(ctx+'index.ts')
check('barrel explicit declarations',all(x in index for x in ('"./agent.ts"','"./agent-loop.ts"','"./harness/agent-harness.ts"','"./proxy.ts"','"./search/index.ts"','setDefaultStreamFn')) and 'getDefaultStreamFn' not in index)
search=txt(ctx+'search/index.ts')
check('search required versus optional methods',re.findall(r'(\w+)\?\(',search)==['searchEntries'] and all(x+'(' in search for x in ('searchSessions','sync','notify','remove','close')))
pkg=js('context-source/packages/agent/package.json')
check('package source entry declarations',pkg['name']=='@earendil-works/pi-agent-core' and pkg['exports']['.']['import']=='./dist/index.js' and pkg['exports']['./node']['import']=='./dist/node.js' and pkg['engines']['node']=='>=22.19.0')
proxy=txt(ctx+'proxy.ts');options=proxy.split('function buildProxyRequestOptions')[1].split('export function streamProxy')[0]
check('proxy selected serializable options',all(x not in options for x in ('authToken:','proxyUrl:','signal:')) and 'headers: options.headers' in options)
check('proxy parser documented static anchors',all(x in proxy for x in ('line.startsWith("data: ")','buffer += decoder.decode();','if (!sawTerminalEvent)','signal: options.signal','removeEventListener("abort", abortHandler)')))
oldtest=txt('historical057/initial-fixture-failure/directory.test.ts');newtest=txt('historical057/directory.test.ts')
expected=oldtest.replace('keepRecentTokens:1','keepRecentTokens:8').replace("expect(JSON.stringify(agent.state.messages)).toContain('OLD_HISTORY');","expect(JSON.stringify(agent.state.messages)).toContain('OLD_HISTORY');expect(JSON.stringify(agent.state.messages)).not.toContain('CHECKPOINT_PENDING');")
check('exact two fixture changes only',newtest==expected)
first=js('historical057/initial-fixture-failure/test-results.json');last=js('historical057/test-results.json')
check('historical first2pass1fail preserved',first['numTotalTests']==3 and first['numPassedTests']==2 and first['numFailedTests']==1 and not first['success'])
check('historical corrected3pass preserved',last['numTotalTests']==3 and last['numPassedTests']==3 and last['numFailedTests']==0 and last['success'])
obs=js('historical057/observations.json');a,b,c=obs
check('three actual observation IDs',[r['case'] for r in obs]==['D057-01','D057-02','D057-03'])
def ser(x):return json.dumps(x)
def textcontent(m):return m['content'] if isinstance(m['content'],str) else ''.join(x.get('text','') for x in m['content'])
check('D05701 requests drain order',len(a['requests'])==4 and [textcontent(r['context']['messages'][-1]) for r in a['requests'][1:]]==['S1','S2','F1'])
check('D05701 context/history separation',all('CHECKPOINT_PENDING' in ser(r['context']['messages']) and 'OLD_HISTORY' not in ser(r['context']['messages']) for r in a['requests'][1:]) and 'OLD_HISTORY' in ser(a['agentState']) and 'CHECKPOINT_PENDING' not in ser(a['agentState']))
check('D05701 real retained complete tool turn',[m['role'] for m in a['checkpoint']['retainedTail']]==['user','assistant','toolResult'] and a['checkpoint']['retainedTail'][1]['content'][0]['id']==a['checkpoint']['retainedTail'][2]['toolCallId']=='call' and 'OLD_HISTORY' in '\n'.join(a['summaryPrompts']))
check('D05702 fresh signal and late queue',len(b['requests'])==2 and b['requests'][1]['aborted'] is False and 'LATE_STEER' in ser(b['requests'][1]['context']['messages']) and any(m.get('stopReason')=='aborted' and m.get('errorMessage')=='Summarization aborted' for m in b['requests'][1]['context']['messages']))
check('D05703 failure before input event',len(c['requests'])==1 and 'EARLY_STEER' not in ser(c['messages']) and c['messages'][-1]['stopReason']=='error' and c['messages'][-1]['errorMessage']=='PREPARE_FAILED')
check('fixture uses in memory tool only','gatedTool(' in newtest and 'processTool(' not in newtest and 'AgentHarness(' not in newtest)
reportpath=manifest['candidate_paths'][0];report=txt('report/'+reportpath)
check('original057 report verbatim appendix',report.endswith(txt('historical057/current_folder_learn.md')))
check('sole report exact portable patch',txt('report.patch')==''.join(difflib.unified_diff([],report.splitlines(True),fromfile='/dev/null',tofile='b/'+reportpath)))
print(json.dumps({'ok':True,'checks':len(checks),'payloads':len(rows),'historical_payloads':62,'accepted_artifacts':83,'accepted054_archive_payloads':157,'new_context_lines':1138,'runtime_executions_this_round':0,'checks_performed':checks},ensure_ascii=False,indent=2))
