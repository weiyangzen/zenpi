from pathlib import Path
import json,hashlib,shutil,subprocess,datetime
W=Path(__file__).resolve().parent;ROOT=W.parent.parent;MAIN=Path('/Users/wangweiyang/GitHub/zenpi');REPORT='Docs/learn/stage1_pi_mono/targets/zenpi/files/src/view_model.rs_learn.md'
def identity(path):
 data=path.read_bytes();return {'bytes':len(data),'lines':len(data.splitlines()),'sha256':hashlib.sha256(data).hexdigest()}
def inventory(root):return {str(p.relative_to(root)):identity(p) for p in sorted(root.rglob('*')) if p.is_file() and not p.is_symlink()}
def save(name,data):(W/name).write_text(json.dumps(data,indent=2)+'\n')
ready=sorted(p for p in (ROOT/'.ops').glob('*-ready') if p.is_dir())+[ROOT/'.ops/stage125-render-review320/ready',ROOT/'.ops/stage126-independent320/ready',ROOT/'.ops/stage126-independent320/ready-final']
tracked={str(ROOT/p.decode()):identity(ROOT/p.decode()) for p in subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).split(b'\0') if p and (ROOT/p.decode()).is_file()}
before={'ready':{str(p):inventory(p) for p in ready},'tracked':tracked};save('preservation-before.json',before)
paths=['src/view_model.rs','src/core.rs','src/tui.rs','src/render.rs','src/headless.rs','tests/view_model.rs','tests/headless_event_budget.rs','tests/tui_transcript_ux.rs','Docs/stage_1_v3_pi_mono_blueprint.md','Docs/execution/active_requirement.json','Docs/learn/stage1_pi_mono/targets/zenpi/source_manifest.tsv','Docs/learn/stage1_pi_mono/targets/zenpi/file_learn_index.tsv'];files=[]
for rel in paths:
 src=MAIN/rel;dst=W/'capture/zenpi'/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);assert identity(src)==identity(dst);files.append({'path':str(dst.relative_to(W)),'origin':str(src),'role':'subject-full' if rel=='src/view_model.rs' else 'context-only',**identity(dst)})
history=[]
for src in [Path('/Users/wangweiyang/.codex/worktrees/38de/zenpi/.ops/target086-review-3.1.20-ready'),ROOT/'.ops/target096-render321-ready',ROOT/'.ops/reference308-keys321-ready',ROOT/'.ops/reference309-status321-ready']:
 dst=W/'history'/src.name;shutil.copytree(src,dst);old=inventory(src);assert inventory(dst)==old;history.append({'origin':str(src),'path':str(dst.relative_to(W)),'files':old})
save('external-preservation-before.json',history);save('preparation-issues.json',[{'operation':'Local086 report/ready locator','result':'rg found no local named086 package and returned1; no reading credit. Bounded other-worktree glob located existing38de old086 ready; main and inherited canonical reports absent.'}])
save('capture.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'item':'ZS1-086','version':'3.1.21','report':REPORT,'report_original_exists':(MAIN/REPORT).exists(),'files':files,'old_ready':len(ready),'old_regular':sum(map(len,before['ready'].values())),'tracked':len(tracked)})
print(json.dumps({'subject':files[0],'captures':len(files),'old_ready':len(ready),'old_regular':sum(map(len,before['ready'].values())),'tracked':len(tracked),'history_counts':[len(r['files']) for r in history],'main_report_exists':(MAIN/REPORT).exists()},indent=2))
