from pathlib import Path
import json,hashlib,shutil,datetime
W=Path(__file__).resolve().parent;P=W.with_name(W.name+'-ready');assert not P.exists()
def identity(p):
 b=p.read_bytes();return {'bytes':len(b),'lines':len(b.splitlines()),'sha256':hashlib.sha256(b).hexdigest()}
def inventory(root):return {str(p.relative_to(root)):identity(p) for p in sorted(root.rglob('*')) if p.is_file() and not p.is_symlink()}
# Last pre-freeze preservation is independently re-evaluated, never executed.
before=json.loads((W/'preservation-before.json').read_text());assert all(inventory(Path(p))==data for p,data in before['ready'].items());assert all(identity(Path(p))==data for p,data in before['tracked'].items())
for row in json.loads((W/'external-preservation-before.json').read_text()):assert inventory(Path(row['origin']))==row['files'] and inventory(W/row['path'])==row['files']
cap=json.loads((W/'capture.json').read_text());assert identity(Path(cap['files'][0]['origin']))=={k:cap['files'][0][k] for k in ['bytes','lines','sha256']};assert not (Path('/Users/wangweiyang/GitHub/zenpi')/cap['report']).exists()
shutil.copytree(W,P)
files=inventory(P);manifest={'schema':'worker-report-candidate/v1','item':'ZS1-086','version':'3.1.21','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'candidate-pending-independent-master-review','owned_paths':[cap['report']],'runtime_executions':0,'maximum_frozen_auditor_runs':1,'files':files};(P/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
for p in P.rglob('*'):p.chmod(0o555 if p.is_dir() else 0o444)
P.chmod(0o555)
print(json.dumps({'ready':str(P),'payload_regular':len(files),'all_regular':len(files)+1,'manifest':identity(P/'manifest.json')},ensure_ascii=False))
