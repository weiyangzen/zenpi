#!/usr/bin/env python3
"""Offline ZS1-086 input integrity and Docs-only patch roundtrip; no product execution."""
import argparse,difflib,hashlib,json,re,subprocess,tarfile,tempfile
from pathlib import Path,PurePosixPath
ENTRY='Docs/quality/stage1/ZS1-086/worker-target-review-3.1.20'
REPORT='Docs/learn/stage1_pi_mono/targets/zenpi/files/src/view_model.rs_learn.md'
EXPECTED={'baseline-view_model.rs':(40591,1220,'1089a9f352b5aaebc755b51ece8189c1daaca1aa82060d2f009630b915b3abee'),'current-view_model.rs':(42009,1255,'094833f051ab66d30ce3f6cc74fcc0334ed938e79f5fd8e9269341b62bed08fe')}
def sha(b):return hashlib.sha256(b).hexdigest()
def checked(b,f):assert len(b)==f['bytes'] and sha(b)==f['sha256'],f
def safe(n):
 p=PurePosixPath(n);assert not p.is_absolute() and '..' not in p.parts and str(p)==n;return p

def verify(root,live=False):
 e=root/ENTRY;c=json.loads((e/'read-coverage.json').read_text());assert {f['path'] for f in c['inputs']}==set(EXPECTED)
 for f in c['inputs']:
  b=(e/f['path']).read_bytes();checked(b,f);ls=b.splitlines(True);assert (len(b),len(ls),sha(b))==EXPECTED[f['path']];assert f['inline_tests']==b.count(b'#[test]')==0
  offset=0;first=1
  for chunk in f['chunks']:
   assert (offset,first)==(chunk['byte_start'],chunk['first_line']);raw=b''.join(ls[first-1:chunk['last_line']]);checked(raw,chunk);assert len(raw)<=262144
   first=chunk['last_line']+1;offset+=len(raw);assert offset==chunk['byte_end']
  assert offset==len(b) and first==len(ls)+1
 assert c['complete_continuous_read'] and c['new_behavior_runs']==0
 diff=''.join(difflib.unified_diff((e/'baseline-view_model.rs').read_text().splitlines(True),(e/'current-view_model.rs').read_text().splitlines(True),fromfile='blueprint-frozen/src/view_model.rs',tofile='current-captured/src/view_model.rs',n=0));assert diff==(e/'baseline-to-current.diff').read_text()
 idx=json.loads((e/'evidence-index.json').read_text());archives={}
 for n,f in idx['archives'].items():
  safe(n);checked((e/n).read_bytes(),f);out={}
  with tarfile.open(e/n) as t:
   ms=t.getmembers();assert len(ms)==len(f['members']) and {m.name for m in ms}==set(f['members'])
   for m in ms:
    safe(m.name);assert m.isfile() and not m.issym() and not m.islnk();b=t.extractfile(m).read();checked(b,f['members'][m.name]);out[m.name]=b
  archives[n]=out
 deps=archives['dependency-context.tar.gz'];ctx=json.loads((e/'dependency-context.json').read_text());assert set(deps)==set(ctx['files'])
 for n,f in ctx['files'].items():
  b=deps[n];checked(b,f);assert len(b.splitlines())==f['lines'] and f['captured_at'];assert all(1<=a<=z<=f['lines'] for a,z in f['read_intervals']);assert f['full_read']==(n=='tests/view_model.rs')
 assert sha(deps['tests/view_model.rs'])=='4cadeff6ed161894a4e7265170b2461621c6ebc24f09db7770f26066c9f9c9c3'
 amap=json.loads((e/'assertion-map.json').read_text());ls=deps['tests/view_model.rs'].decode().splitlines();actual=[]
 for i,s in enumerate(ls):
  if s.strip()=='#[test]':actual.append((re.search(r'fn (\w+)\(',ls[i+1]).group(1),i+2))
 assert len(actual)==11 and actual==[(t['name'],t['declaration_line']) for t in amap['external_tests']];assert not amap['inline_tests'] and all(t['assertions'] for t in amap['external_tests'])
 for s in amap['supplemental']:
  ls=deps[s['path']].decode().splitlines();assert ls[s['declaration_line']-1].startswith('fn '),s
 hist=archives['historical108-selected.tar.gz'];assert sha(hist['manifest.json'])=='522e94f9794b5a65c163fc8e952779d2f64874dfa0da5c34403956512362374a'
 review=json.loads(hist['controller-review.json']);assert review['manifest_sha256']==sha(hist['manifest.json'])
 assert 'initial_failure' in json.loads(hist['replay-verification.json'])
 assert b'14 passed; 1 failed' in hist['registry-fixture-before.log'] and b'left: Bool(false)' in hist['registry-fixture-before.log'] and b'Peer disconnected' in hist['registry-fixture-before.log']
 for name in ['reasoning_is_separate_from_answer_and_projects_to_a_separate_view_block','actual_command_updates_precede_terminal_and_reuse_canonical_event']:
  assert ('test '+name+' ... ok').encode() in hist['combined-tests.log']
 assert b'Running tests/view_model.rs' not in hist['combined-tests.log'];assert b'15 passed; 0 failed' in hist['combined-tests.log'] and b'38 passed; 0 failed; 1 ignored' in hist['combined-tests.log']
 assert idx['new_behavior_runs']==ctx['new_behavior_runs']==amap['new_behavior_runs']==0
 report=(root/REPORT).read_text();assert all(v[2] in report for v in EXPECTED.values()) and '14 passed / 1 failed' in report
 if live:assert Path('/Users/wangweiyang/GitHub/zenpi/src/view_model.rs').read_bytes()==(e/'current-view_model.rs').read_bytes(),'live subject drift'
 return dict(source_lines=[1220,1255],inline_tests=[0,0],external_tests_read=11,supplemental_test_excerpts=2,archive_members=sum(map(len,archives.values())),historical_failures_retained=True,new_behavior_runs=0,full_dependency_closure_verified=False,live_subject_only_checked=live)

def packet_check(packet):
 m=json.loads((packet/'manifest.json').read_text());files=m['files'];assert len(files)==len({f['path'] for f in files})
 for f in files:
  assert safe(f['path']).parts[0]=='Docs' and f['receiver_base']=='absent';checked((packet/'files'/f['path']).read_bytes(),f)
 assert {str(p.relative_to(packet/'files')) for p in (packet/'files').rglob('*') if p.is_file()}=={f['path'] for f in files}
 patch=(packet/'candidate.patch').resolve();checked(patch.read_bytes(),m['patch'])
 with tempfile.TemporaryDirectory(prefix='target086-roundtrip-') as tmp:
  r=Path(tmp)
  def git(*a):return subprocess.run(['git','-C',tmp,*a],check=True,capture_output=True,timeout=30).stdout
  git('init','-q');git('apply','--check',str(patch));git('apply',str(patch))
  for f in files:checked((r/f['path']).read_bytes(),f)
  assert {str(p.relative_to(r)) for p in r.rglob('*') if p.is_file() and '.git' not in p.relative_to(r).parts}=={f['path'] for f in files}
  verify(r);git('apply','--reverse','--check',str(patch));git('apply','--reverse',str(patch));assert not any(p.is_file() for p in (r/'Docs').rglob('*'))
 return dict(files=len(files),forward='exact candidate bytes and file set',reverse='all receiver paths restored absent')
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[5]);p.add_argument('--live',action='store_true');p.add_argument('--packet',type=Path);a=p.parse_args();out=verify(a.root.resolve(),a.live)
 if a.packet:out['packet']=packet_check(a.packet.resolve())
 print(json.dumps(out,indent=2))
if __name__=='__main__':main()
