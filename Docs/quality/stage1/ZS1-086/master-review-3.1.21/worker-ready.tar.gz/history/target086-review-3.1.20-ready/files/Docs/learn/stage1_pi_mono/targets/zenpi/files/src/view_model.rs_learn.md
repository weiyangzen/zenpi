# ZS1-086 · src/view_model.rs 全文件审读

本项提交的是 worker A 的完整文件学习与静态审查候选，等待 master 独立验收。权威版本为 3.1.20，requirement digest 为 `8d525b351d066ce9b0487a485337647d47233275782e4f4d154423a623fe1645`。本轮新增 Cargo、PTY、HTTP、产品行为运行均为 0；离线证据与 Docs 补丁核验不计作产品运行。未改产品代码或完成状态。

| 输入 | 字节 / 行 / 内联测试 | SHA-256 |
| --- | --- | --- |
| 蓝图冻结 src/view_model.rs | 40591 / 1220 / 0 | `1089a9f352b5aaebc755b51ece8189c1daaca1aa82060d2f009630b915b3abee` |
| main 捕获 src/view_model.rs | 42009 / 1255 / 0 | `094833f051ab66d30ce3f6cc74fcc0334ed938e79f5fd8e9269341b62bed08fe` |

冻结输入来自 A 的 input-host-before；当前输入直接来自 main，捕获时间 `2026-09-12T10:59:55.573637Z`。A 工作树原产品文件不同，未拿它代替当前 main。两版均从首行连续读至 EOF；冻结版一次 601–1300 的截断输出不计入，随后完整补读 601–900、901–1220。分块字节偏移、连续行区间与 SHA 见同项 quality 的 `read-coverage.json`。没有内联测试可逐项验收，故另完整阅读 main 的 `tests/view_model.rs` 425 行、11 个测试。

查找时 main、A、其他工作树的 canonical 086 学习报告均未找到，main `Docs/quality/stage1/ZS1-086` 当时不存在；本项没有可继承的 086 旧报告前缀。此前 084 等报告、快照和 ready 保持原样。最终各接收路径是否存在，以 ready manifest 的逐路径 receiver base 为准。

## 文件责任与完整结构

本文件把 provider/core 事件投影为 renderer-neutral 数据：明确 sequence/request/turn/block 的关联和基本界限，不引入终端组件或网络 runtime。它不是 provider 原始事件、JSONL 外层协议或持久化 WAL 的替代品。

| 当前行 | 责任与已核对行为 |
| --- | --- |
| 1–30 | 独立 schema version=1；ID 128 B、单文本 256 KiB、消息 128 blocks、list 128 items、序列化 event 512 KiB、终态 turn 记忆 256 个 |
| 32–104 | StreamingBlock 私有状态；new 校验 ID；append 校验控制字符及累计文本；complete(Some) 用最终全文覆盖已积累文本，complete(None) 保留增量，成功后禁止追加或再次完成 |
| 106–173 | 具体错误类型，以及 role、tool status、approval state 枚举；错误区分关联缺失、容量、序号、终态和关闭 |
| 175–295 | 11 类 ViewBlock；redacted 返回副本，针对文本体调用 security::redact_text，结构字段保留 |
| 297–424 | 每种 block 的字段校验、kind discriminant、MarkdownBlock 映射及全文解析；每个 Markdown list item 转为独立单项 List，不恢复连续列表编号 |
| 427–497 | ViewBlockKind 与 ViewMessage；构造器显式 validate，role/turn/blocks 为公开字段；非空与数量限制在 validate 中 |
| 499–622 | admission/rejection/stream 枚举与完整生命周期 payload；ReasoningDelta 是相对冻结版新增的一种 event |
| 624–730 | payload 校验、turn/block 必需条件；Usage/Warning/Handoff/Failed/Cancelled 等与严格 turn-bound 内容事件的条件不同 |
| 732–995 | ViewEvent envelope、schema/关联/编码后大小校验、AgentEvent 和 ProviderEvent 两组完整投影 |
| 998–1167 | ViewEventBuffer：数量与字节双限、单调连续 sequence、有限终态墓碑、全流 Closed、drain 与 replay gap/future 区分 |
| 1169–1255 | TurnMode/NotSubmittedReason 显式转换；版本缺省；按 UTF-8 边界截断的默认 block ID；token/text 校验帮助函数 |

## 冻结版到当前版的变化

完整 diff 仅包含 reasoning 和工具进度接入，共增加 35 行。`ReasoningDelta` 有单文本限制，要求 turn_id 和 block_id；provider adapter 生成 `turn-prefix:reasoning`，普通 TextDelta/TextDone/Refusal 仍默认 `turn-prefix:assistant`。两类内容不会在普通短 turn ID 下共用 block。ReasoningDelta 分支不采用调用者传入的 block_id，其他内容分支优先采用它；这是可见 API 行为，不应把签名里的可选 block_id 理解为对所有事件都生效。

`AgentEvent::ToolProgress` 使用 SHA-256(turn bytes + NUL + call_id bytes + stream tag) 生成 `output-` 加 64 位十六进制的 block ID。stdout/stderr 分别用 0/1 tag，turn ID、call ID 参与键，request ID 不参与；同一调用流的多次快照因此更新同一块。NUL 在最终 event 校验的 ID 中不允许。实际 payload 来自 `OutputProgress::canonical_kind`：附 stream、已观察字节数及丢弃更新提示，正文按 UTF-8 边界截到单文本限额，产出 Running 的 ToolStatus block；它是当前输出快照，不是要求 UI 再拼接的文本 delta。

其余结构、校验、buffer 和帮助函数与冻结版一致。schema version 仍为 1；新增枚举 variant 会让不认识 reasoning_delta 的旧 decoder 无法解析，向后扩展兼容性需由协议迁移约定界定，不能仅凭 version 未变认定所有旧消费者兼容。

## 数据约束、关联与生命周期

构造器调用 validate，但 serde Deserialize 为派生实现，没有把字段语义校验接到反序列化完成之后。ViewBlock、ViewMessage、ViewEvent 的公开字段也允许调用方绕过构造器；接收未信任数据时仍须显式 validate。`deny_unknown_fields` 属于解析形状约束，不能代替 heading 1–6、ID 长度、schema=1、turn/block 必填及总事件大小检查。未知字段与 flatten 的具体兼容行为未新增运行验证。

token 不得全空白、超字节数或包含任意控制字符；text 允许空串和 LF/CR/TAB，但拒绝其他 `char::is_control` 字符。它不是 Markdown/路径/工具权限校验，也不是 Unicode bidi 等全部终端视觉混淆字符的过滤器。language 上限 64 B，diff path 4 KiB，tool name/error code 等有独立 token 限额。

单 List 的每一项可达 256 KiB，128 项约 32 MiB；一个 ViewMessage 又允许 128 个这样的块，理论文本聚合量可达 4 GiB。当前 validate 没有消息级总字节上限。`from_markdown_text` 先完整 parse 再检查 block 数量，不能作为解析前输入内存限制。ViewEvent 增加了序列化后 512 KiB 限制，但会先产生 JSON Vec；JSON 转义扩张也计入此限额。这些都是不同层次的界限，不宜将“bounded”解释为所有输入的统一小内存预算。

RequestAccepted、TurnStarted、文本/reasoning/block、工具及审批事件、TurnCompleted 要求 turn_id；文本/reasoning/block 还要求 block_id。TurnFailed、TurnCancelled 可以无 turn，因此不会自动给 buffer 建立某个 turn 的终态墓碑。AgentEvent::Error 正是无 turn 的 TurnFailed，retryable=false；provider Failed 映射 code=provider_failed、retryable=true，但 adapter 不把这个布尔值变成实际重试权限。ToolResult success 只映射成功/失败状态，output=None；Handoff 不承担 turn 终结，Usage 三个计数不强制算术一致。

Provider Completed 被规范化为 TurnCompleted，语义上描述一次 provider response；一个 core turn 可能跨工具调用经历多个 response。若直接把它们都 append 到同一 turn 的 ViewEventBuffer，第一次 Completed 就会阻止后续该 turn 的事件。因此宿主必须区分 provider 完成和 runtime 终结，不能把该映射当作完整 core 状态机。

## Buffer 的确切保证与静态边界

new 将 capacity 和 max_bytes 的 0 提升为 1；append 先 validate，再查 Closed、精确 next_sequence 和已知终态 turn，再检查单事件是否超过 buffer 字节预算。成功后保持 next_sequence 单调，按最旧优先驱逐，dropped 饱和累计；take_dropped 只清计数，不回退游标。

replay_from 是包含指定 sequence 的后缀。小于首保留序号返回 ReplayGap，大于 next_sequence 返回 ReplayFuture，等于 next_sequence 返回空；drain 清事件与 bytes，但保留游标、墓碑、closed 和丢弃计数，故清空之后旧 cursor 仍是 gap。它不是重置会话 API，也不是持久化 replay。

终态 ID 只保留最近 256 个，与实际保留 event 的容量独立。第 257 个终态会遗忘最早 turn；之后同 ID 的事件可以再次进入，即使大容量队列仍保留其旧终态。本文件注释中“terminal turn”保证实际受该有界记忆窗口限制。建议接收方若需全会话唯一性，应另有 turn epoch/已退休集合或拒绝重用策略。

append 在 `checked_add(1)` 之前已经插入 terminal_turns 或设置 closed。当 next_sequence 为 u64::MAX，返回 SequenceExhausted 仍可能改变这些内部状态，与其他早期失败路径不同。由于游标私有且从 0 起，这需要耗尽整个序列空间，当前公开 API 中没有短程触发路径；保留为低优先级原子性边界，未声称实际复现。

默认 block ID 截掉 turn 的后缀以容纳 `:assistant` 或 `:reasoning`，并保证 UTF-8 完整。不同合法长 turn ID 若共享前缀，会产生相同 block_id。完整 envelope 仍带原 turn_id，按二元键 (turn_id, block_id) 索引可区分；只按 block_id 索引会碰撞。该行为与 ToolProgress 使用 hash 的键策略不同。

## 脱敏与宿主上下文

ViewBlock::redacted 是显式可选方法，仅对正文、列表项、代码文本、diff patch、tool output、approval arguments、错误消息使用 shared redact_text 且 known-secret 列表为空。language、path、call_id、name、approval_id、tool、error code 等保持原值。StreamingBlock、ViewMessage 构造、ViewEvent 构造与两组 adapter 均未自动调用 redacted；校验控制字符不等于隐藏凭据。这里记录的是层级契约，不声称未读的完整宿主泄漏真实秘密。

依赖捕获各有 SHA、时间和实际阅读区间，完整字节归档只是为了可追溯。`src/headless.rs` 于 `2026-09-12T11:03:30.433930Z` 捕获为 365555 B / 9229 行 / `958837ad933fea4e55c3ac966f0c8d605dd03674a696e2ef0595b54aca628ef9`，晚于已冻结 084，不能用于替换其证据。

headless 两处 provider 投影失败时加入 view_error，仍保留原 provider payload；agent 的 write_buffered_events 则用 `?` 传播投影错误。辅助顶层 block 会 redacted，嵌入 view 从 adapter 另行构造；不能从顶层 block 脱敏推导其余所有字段也已脱敏。JSONL 外层 sequence 与 replay.remember_event 属于宿主，未调用这里的 ViewEventBuffer。

TUI 读取片段显示 provider Completed 被跳过，整轮完成由 owning runtime 决定，避免工具续轮被提前终结；每次 drain 的本地 view_sequence 从 0 开始，并非全会话 replay cursor。工具输出按 job ID 与 block_id 更新现有块，ToolFinished 再按 call_id 改终态。`apply_view_event_for_job` 直接匹配 payload，不在入口重新 validate；这些片段不能证明其所有上游输入和 stale-job 分支都完整封闭。

## 测试证据与不足

`tests/view_model.rs` 当前捕获 12246 B / 425 行 / SHA `4cadeff6ed161894a4e7265170b2461621c6ebc24f09db7770f26066c9f9c9c3` 已全文读完，11 项断言分别是：消息 roundtrip、Error 脱敏、Markdown 映射、控制字符/数量/单文本限制、event 关联与 flatten、stream 合并冻结、两类 adapter 关联、双元素 buffer 驱逐和 gap/future、序号错误不改状态、terminal turn 拒绝 late event、Closed 拒绝后续事件。逐项函数名与行号见 assertion-map。它们是当前测试源码审读，未在本轮执行，也未覆盖本轮新增 reasoning/tool-progress 的全部边界。

额外片段 `tests/stage1_chat_stream.rs:229` 验证 reasoning 不进入 answer、annotation 保留且两个 block ID 不同，但未断言显式 block_id override 和长 ID；`tests/stage1_tool_output.rs:319` 观察命令未结束前出现首输出并产出 canonical Block，没有直接断言 from_agent_event 的 hash 键唯一性。两份外部测试文件仅片段审读，不报全文件完成。

选取 historical chat-reasoning-integration 记录归档，combined-tests.log 中上述两个命名测试为 ok，chat 组 15 passed、tool-output 组 38 passed / 1 ignored；这些是历史结果，不是本轮运行，也不折算为当前 086 的通过数。该组合没有独立 tests/view_model.rs 组。manifest 仅做字段/subject 查询，未在本项重建它全部 39 文件的历史输入闭包。

保留了两类原始失败背景：replay-verification 记载初次在嵌套非 git 根目录应用补丁未生效，被字节等同性检查发现，baseline-tests 只能算旧源码运行；registry-fixture-before.log 保留 chat 14 passed / 1 failed，断言期望 streaming=true 但 fixture 实际为 false，继而 Peer disconnected。controller-review 记录明确 fixture override 后修复，combined log 为后续通过。未删除失败或把 controller 的说明升级为当前依赖验证。

优先后续验证点是：未校验 Deserialize 的接收路径、消息聚合预算、provider/core 终态区分、reasoning block ID 契约、ToolProgress hash 关联、256 个墓碑淘汰、以及嵌入 view 与结构字段的脱敏覆盖。当前没有证据证明这些边界均已满足产品验收。

本项 quality 附原始两版、零上下文 diff、阅读覆盖、断言映射、带时间依赖快照、保留失败的历史精选与离线 verifier。ready 以 main 每个 Docs 路径的精确 base 建包，独立目录执行正向 apply/check、逐文件字节与文件集合检查、反向 apply/check 恢复，再做离线复验；master 的最终判定仍独立。
