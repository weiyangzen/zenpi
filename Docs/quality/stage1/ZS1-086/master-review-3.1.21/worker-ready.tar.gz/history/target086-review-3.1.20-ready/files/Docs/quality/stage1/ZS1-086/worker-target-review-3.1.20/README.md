# ZS1-086 worker review entry · 3.1.20

Subject: `src/view_model.rs`; candidate status only. Whole frozen and captured-main files read; both have zero inline tests. Eleven current external tests read in full; two supplemental tests and six dependency files have explicitly recorded coverage. No product code changes or new product executions.

`read-coverage.json` binds complete consecutive source ranges to bytes and SHA-256. `assertion-map.json` records actual assertions, not inferred test passes. `dependency-context.tar.gz` contains complete captured bytes with partial-read ranges in `dependency-context.json`; it is not a current build closure. Later headless capture is independent of immutable ZS1-084. `historical108-selected.tar.gz` is a selected historical archive with original fixture failure and unapplied-baseline context retained; its manifest's entire 39-file packet was not reconstructed here.

Canonical report: `Docs/learn/stage1_pi_mono/targets/zenpi/files/src/view_model.rs_learn.md`.

From the receiving repository root, run:

```text
python3 Docs/quality/stage1/ZS1-086/worker-target-review-3.1.20/verify.py
python3 Docs/quality/stage1/ZS1-086/worker-target-review-3.1.20/verify.py --packet /absolute/path/to/target086-review-3.1.20-ready
```

Optional `--live` checks only the recorded main subject path for drift. Default offline verification requires neither main nor any other worktree. Packet verification creates its own temporary git root, checks/applies the Docs patch, compares exact file set and bytes, reruns offline verification, checks/reverses the patch and verifies the absent receiver base. It does not run Cargo, network or PTY fixtures.

The first local offline verifier rejected a supplemental assertion-map line number (318 was the test attribute, actual function is 319). The map and report were corrected before packaging; `preflight-correction.json` retains this failure. This mechanical correction is not a product failure or a new product test.

Static follow-ups remain unexecuted: explicit post-deserialization validation, aggregate message limits, optional redaction/structural fields, provider response versus core terminal distinction, reasoning override and truncated long-ID keys, tool output SHA identity, terminal tombstone eviction, and sequence-exhaustion mutation. The canonical report states their practical limits and avoids claiming current-host exploit or failure reproduction.
