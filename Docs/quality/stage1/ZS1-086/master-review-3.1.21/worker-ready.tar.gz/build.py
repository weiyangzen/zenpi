from pathlib import Path
import json,hashlib,datetime,difflib
W=Path(__file__).resolve().parent

def identity(p):
 b=p.read_bytes();return {'bytes':len(b),'lines':len(b.splitlines()),'sha256':hashlib.sha256(b).hexdigest()}
def inventory(root):return {str(p.relative_to(root)):identity(p) for p in sorted(root.rglob('*')) if p.is_file() and not p.is_symlink()}
def save(name,v):(W/name).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
cap=json.loads((W/'capture.json').read_text());summary=json.loads((W/'analysis-summary.json').read_text());report=(W/'report-body.md').read_text().replace('重复ID不增加镜像，饱和拒收','重复ID不增加镜像，饱和时不再记入ID并设置饱和标记，但仍显示审批块')
report+='\n## 连续语义单元索引\n\n| 单元 | 当前行 | 责任 / 映射 |\n| --- | --- | --- |\n'
for r in json.loads((W/'semantic-units.json').read_text()):report+='| %s | %d–%d | %s / %s |\n'%(r['id'],*r['lines'],r['title'],r['map'])
report+='\n## 全部函数绑定\n\n每个函数正文的精确范围、字节数和SHA见function-bindings.json；同名方法按行号区分。\n\n| 函数 | 当前行 | 映射 |\n| --- | --- | --- |\n'
for r in json.loads((W/'function-bindings.json').read_text()):report+='| %s | %d–%d | %s |\n'%(r['name'],*r['lines'],r['map'])
report+='\n## 外部测试逐项绑定\n\n| ID / 名称 | 当前测试行 | assert宏 / 本轮执行 |\n| --- | --- | --- |\n'
for r in json.loads((W/'external-tests.json').read_text()):report+='| %s · %s | %d–%d | %d / 0 |\n'%(r['id'],r['name'],*r['lines'],r['ordinary_assert_sites'])
report+='\n共29条正文阅读记录，5条正式源连续全文、2条外部测试连续全文，其余为有界上下文与旧报告。19项operation-map将21个连续单元绑定到owner与现有测试/未执行验收标准。完整复制不等于全文阅读。\n'
path=W/'files'/cap['report'];path.parent.mkdir(parents=True,exist_ok=True);assert not path.exists();path.write_text(report)
forward=''.join(difflib.unified_diff([],report.splitlines(True),fromfile='/dev/null',tofile='b/'+cap['report']));reverse=''.join(difflib.unified_diff(report.splitlines(True),[],fromfile='a/'+cap['report'],tofile='/dev/null'));(W/'report.patch').write_text(forward);(W/'rollback.patch').write_text(reverse)
summary.update({'report':identity(path),'patch':identity(W/'report.patch'),'rollback':identity(W/'rollback.patch')});save('analysis-summary.json',summary)
# Read only current origins; drift capture is separate and conveys no new full-read credit.
origins=[]
for row in cap['files']:
 p=Path(row['origin']);now=identity(p);changed=now!={k:row[k] for k in ['bytes','lines','sha256']};item={'origin':str(p),'captured_path':row['path'],'now':now,'changed':changed}
 if changed:
  dest=W/'freeze-drift'/row['path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.read_bytes());item['drift_path']=str(dest.relative_to(W));item['new_full_read_credit']=False
 origins.append(item)
assert not origins[0]['changed'];assert not (Path('/Users/wangweiyang/GitHub/zenpi')/cap['report']).exists()
save('freeze-origin-identities.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'formal_source_unchanged':True,'files':origins})
before=json.loads((W/'preservation-before.json').read_text());external=json.loads((W/'external-preservation-before.json').read_text());differences=[]
for p,expected in before['ready'].items():
 if inventory(Path(p))!=expected:differences.append(p)
for p,expected in before['tracked'].items():
 if identity(Path(p))!=expected:differences.append(p)
for row in external:
 if inventory(Path(row['origin']))!=row['files'] or inventory(W/row['path'])!=row['files']:differences.append(row['origin'])
result={'old_ready_count':len(before['ready']),'old_regular_count':sum(map(len,before['ready'].values())),'tracked_count':len(before['tracked']),'external_regular_count':sum(len(r['files']) for r in external),'differences':differences};save('preservation-after.json',result);assert not differences
print(json.dumps({'report':summary['report'],'preserved':result,'drift':[r for r in origins if r['changed']]},ensure_ascii=False))
