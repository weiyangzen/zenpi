from pathlib import Path
import json,hashlib,re,difflib,datetime
W=Path(__file__).resolve().parent

def ident(data):return {'bytes':len(data),'lines':len(data.splitlines()),'sha256':hashlib.sha256(data).hexdigest()}
def save(name,value):(W/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
source=(W/'capture/zenpi/src/view_model.rs').read_bytes();lines=source.splitlines(keepends=True)
# Every source byte is in exactly one semantic section; function bodies are independently bounded.
sections=[(1,'schema','版本和预算'),(32,'stream','增量块'),(106,'schema','错误与状态枚举'),(173,'blocks','块数据形状'),(230,'redaction','显式脱敏'),(297,'validation','块语义校验'),(374,'blocks','种类与Markdown单块'),(415,'markdown','Markdown全文转换'),(427,'message','消息形状与校验'),(499,'events','事件枚举'),(624,'event_validation','载荷校验'),(706,'association','关联必需条件'),(732,'envelope','事件信封'),(803,'agent','Agent投影'),(916,'provider','Provider投影'),(1003,'buffer','缓冲区初始化与访问'),(1062,'append','追加与驱逐'),(1133,'replay','drain与replay'),(1169,'conversion','模式与拒绝原因转换'),(1191,'ids','版本与默认块ID'),(1207,'tokens','token和text校验')]
criteria={
'schema':('独立schema=1、字节/数量预算与错误枚举','协议消费者','版本不匹配拒绝；数量错误的max显示单位不能当实际字节预算。'),
'stream':('new→append→complete私有单块状态','TUI流投影','T06覆盖None冻结和迟到拒绝；补验Some空/非法最终全文保持原状态、累计边界、clone独立和同job重建。'),
'blocks':('11类ViewBlock与kind映射','renderer-neutral消息','T01/T03仅部分种类；逐一验证11种kind、默认可选字段、list单项映射与ordered编号丢失。'),
'redaction':('显式redacted副本','安全策略与输出宿主','T02仅Error Bearer样例；补验正文各分支与未脱敏结构字段，不把validate或序列化当脱敏。'),
'validation':('每种块字段条件','不可信输入接收者','T04部分负例；补验heading边界、language/path/token限额、list空/最大数量/聚合量、arguments非JSON仍合法。'),
'markdown':('parse全部结果后检查128块','096 render解析器','T03映射；补验空Markdown、128/129块、前端256KiB截断与sanitize后再校验，区分直接构造。'),
'message':('new/from_markdown/validate','消息宿主','T01往返；补验空blocks、可选turn、每块上限与无消息聚合限额，Deserialize后显式validate。'),
'events':('20种生命周期载荷和独立状态枚举','core/provider/宿主','见事件表逐类criterion；状态是展示值，没有工具执行或审批授权转移。'),
'event_validation':('event.validate所有match分支','事件构造者','逐类合法/非法payload，Usage计数不校验算术，Dropped0拒绝，Finished的Queued和Resolved的Pending合法。'),
'association':('12类turn必需、3类block必需','关联接收者','T05缺turn；补验单独缺block、Failed/Cancelled无turn、Reasoning显式block覆盖规则及未执行project匹配。'),
'envelope':('with_context→validate→encoded_len','公开字段/Serde接收者','T05形状和roundtrip；补验schema、控制字符、JSON转义后512KiB阈值，先编码后拒绝并非解析前分配预算。'),
'agent':('9类AgentEvent→ViewEvent','core emit与TUI drain','T07部分分支；补验progress turn/call/stdout/stderr哈希键、无turn Error、delegated canonical_kind不冒领全文审读。'),
'provider':('11类ProviderEvent→ViewEvent','provider response与core turn','T07部分分支；补验Reasoning块、Refusal、Usage、Failed、两次provider Completed间工具续轮及显式block优先级。'),
'buffer':('新实例容量与读取接口','持有者/重连层','T08访问；补验0归一1、clone独立、bytes不计堆/clone、take_dropped只清计数。'),
'append':('validate/closed/sequence/tombstone/size→mutate→evict','流所有者','T08–T11基本分支；补验byte驱逐、256墓碑淘汰、无turn终态、不同预算早拒绝，以及u64耗尽先改终态的理论边界。'),
'replay':('inclusive replay与drain','内存恢复调用方','T08 gap/future；补验empty/current/future、drain保留seq/closed/tombstone/dropped，不宣称磁盘恢复。'),
'conversion':('TurnMode3种和NotSubmitted5种','core admission','T07部分；逐一断言转换，ViewRejection Closed/Invalid并非该From自动产生。'),
'ids':('UTF8截取默认block ID','跨turn索引','补验128B多字节ID前缀碰撞、(turn,block)复合键、suffix常量与schema默认。'),
 'tokens':('trim空/字节长/控制字符','所有显式validate路径','T04 ESC/超长；补验空text合法、LF/CR/TAB合法、token保留空格且拒control、format字符未统一过滤。')}
# Count enum variants from declaration indentation, not guessed event count.
variants=[]
for line in lines[534:622]:
 m=re.match(rb'^    ([A-Z]\w+)(?:\s*\{|,)',line)
 if m is not None:variants.append(m.group(1).decode())
criteria['events']=(str(len(variants))+'种生命周期载荷和独立状态枚举',criteria['events'][1],criteria['events'][2])
units=[]
for i,(lo,key,title) in enumerate(sections):
 hi=sections[i+1][0]-1 if i+1<len(sections) else len(lines);chunk=b''.join(lines[lo-1:hi]);start=sum(map(len,lines[:lo-1]));units.append({'id':'U%02d'%(i+1),'lines':[lo,hi],'byte_range':[start,start+len(chunk)],'bytes':len(chunk),'sha256':hashlib.sha256(chunk).hexdigest(),'map':key,'title':title})
save('semantic-units.json',units)
save('operation-maps.json',[{'id':k,'source':v[0],'target':v[1],'owners':'ZS1-086报告；产品责任仍属调用方，未修改','criterion':v[2],'new_runtime_executions':0} for k,v in criteria.items()])
fns=[]
for lo,line in enumerate(lines,1):
 m=re.match(rb'^\s*(?:pub\s+)?(?:const\s+)?fn\s+(\w+)',line)
 if m is None:continue
 indent=line[:len(line)-len(line.lstrip())];hi=next(n for n in range(lo+1,len(lines)+1) if lines[n-1].rstrip()==indent+b'}');chunk=b''.join(lines[lo-1:hi]);u=next(u for u in units if u['lines'][0]<=lo<=u['lines'][1]);fns.append({'name':m.group(1).decode(),'lines':[lo,hi],'bytes':len(chunk),'sha256':hashlib.sha256(chunk).hexdigest(),'unit':u['id'],'map':u['map'],'kind':'production'})
save('function-bindings.json',fns)
testpath='capture/zenpi/tests/view_model.rs';tl=(W/testpath).read_bytes().splitlines(keepends=True);tests=[]
for lo,line in enumerate(tl,1):
 m=re.match(rb'^fn (\w+)',line)
 if m is None:continue
 hi=next(n for n in range(lo+1,len(tl)+1) if tl[n-1].rstrip()==b'}');chunk=b''.join(tl[lo-1:hi]);tests.append({'id':'T%02d'%(len(tests)+1),'name':m.group(1).decode(),'source':testpath,'lines':[lo,hi],'bytes':len(chunk),'sha256':hashlib.sha256(chunk).hexdigest(),'ordinary_assert_sites':len(re.findall(rb'\bassert(?:_eq|_ne)?!',chunk)),'snapshot_sites':0,'executed':False})
save('external-tests.json',tests);save('source-tests.json',[])
basepath='history/target086-review-3.1.20-ready/files/Docs/quality/stage1/ZS1-086/worker-target-review-3.1.20/baseline-view_model.rs';base=(W/basepath).read_bytes();diff=''.join(difflib.unified_diff(base.decode().splitlines(True),source.decode().splitlines(True),fromfile='baseline/src/view_model.rs',tofile='current/src/view_model.rs'));(W/'baseline-to-current.diff').write_text(diff)
save('baseline-comparison.json',{'baseline_path':basepath,'baseline':ident(base),'current':ident(source),'net_bytes':len(source)-len(base),'net_lines':len(lines)-len(base.splitlines()),'baseline_new_full_read':False,'old086_current_exact':source==(W/basepath.replace('baseline-','current-')).read_bytes(),'diff':ident(diff.encode())})
reuse=[]
for item,name,prefix in [('096','target096-render321-ready',''),('308','reference308-keys321-ready','evidence/'),('309','reference309-status321-ready','evidence/')]:
 package=W/'history'/name;cap=json.loads((package/prefix/'capture.json').read_text());row=next(r for r in cap['files'] if r['role']=='subject-full');old=(package/prefix/row['path']).read_bytes();live=Path(row['origin']).read_bytes();assert live==old
 reuse.append({'item':item,'package':'history/'+name,'manifest':ident((package/'manifest.json').read_bytes()),'source_path':'history/'+name+'/'+prefix+row['path'],'origin':row['origin'],'source':ident(old),'live_same_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'formal086_credit':False,'new_runtime_executions':0})
save('reference-reuse.json',reuse)
summary={'formal_reads':5,'all_read_records':len(json.loads((W/'read-binding.json').read_text())),'semantic_units':len(units),'functions':len(fns),'inline_tests':0,'external_tests':len(tests),'external_assert_sites':sum(t['ordinary_assert_sites'] for t in tests),'event_variants':variants,'operation_maps':len(criteria),'runtime_executions':0};save('analysis-summary.json',summary);print(json.dumps(summary,ensure_ascii=False))
