from pathlib import Path
import json
w=Path(__file__).resolve().parent
roles={'anthropic-messages.ts':'正式016；Messages请求与事件折叠；复用主审完整阅读','google-generative-ai.ts':'正式017；Gemini协议；复用本任务完整阅读及主审','openai-completions.ts':'正式029；Chat兼容协议；复用本任务完整候选阅读','azure-openai-responses.ts':'Azure Responses；新读1–60行边界','bedrock-converse-stream.ts':'AWS Converse；新读1–60行边界','cloudflare-ai-binding.ts':'Workers binding fetch适配；新读全文','cloudflare.ts':'Gateway URL模板；新读全文','constrained-sampling.ts':'受限采样归一化；复用029全文阅读','github-copilot-headers.ts':'Copilot initiator/图片头；新读全文','google-shared.ts':'Google native parts/history；复用017全文阅读','google-vertex.ts':'Vertex SDK接入；新读1–60行边界','lazy.ts':'加载与事件转发；新读全文','mistral-conversations.ts':'Mistral协议；新读1–60行边界','openai-codex-responses.ts':'Codex Responses接入；新读1–60行边界','openai-prompt-cache.ts':'cache key截断；新读全文','openai-responses-shared.ts':'Responses共享转换/折叠；新读1–60行边界','openai-responses.ts':'Responses SDK接入；新读1–60行边界','openrouter-images.ts':'图像生成；新读1–60行边界','pi-messages.ts':'gateway消息协议；新读1–60行边界','simple-options.ts':'Simple基础选项/思考预算；新读全文','transform-messages.ts':'历史/图片/签名/工具转换；新读全文'}
rows=json.loads((w/'direct-inventory.json').read_text())
table='\n\n### 真实直接项逐文件清单\n\n当前目录有32个直接文件、0个直接子目录，与旧055清单的名称/类型/字节/哈希逐项一致。以下29个非正式文件均为context-only，不因阅读或位于该目录就获独立验收；完整SHA及行数在direct-inventory.json。\n\n| 直接项 | 字节 | 职责与阅读范围 |\n| --- | ---: | --- |\n'
for r in rows:
 n=r['name'];role=roles.get(n,('图像生成延迟导入，独立ProviderImages；新读全文' if n=='openrouter-images.lazy.ts' else '相应API延迟导入'+('及Bedrock构建override'if n=='bedrock-converse-stream.lazy.ts'else'')+'；新读全文'))
 table+=f'| `{n}` | {r["bytes"]} | {role} |\n'
old=w/'historical055/files/Docs/learn/stage1_pi_mono/packages/ai/src/api/current_folder_learn.md'
b=old.read_bytes()+(w/'report-addendum.md').read_bytes()+table.encode()
p=w/'files/Docs/learn/stage1_pi_mono/packages/ai/src/api/current_folder_learn.md';p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
(w/'report-body.md').write_bytes(b)
print(len(b))
