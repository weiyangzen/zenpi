import assert from 'node:assert/strict';
import { anthropicMessagesApi } from '/Users/wangweiyang/GitHub/pi-mono/packages/ai/src/api/anthropic-messages.lazy.ts';
import { googleGenerativeAIApi } from '/Users/wangweiyang/GitHub/pi-mono/packages/ai/src/api/google-generative-ai.lazy.ts';
import { openAICompletionsApi } from '/Users/wangweiyang/GitHub/pi-mono/packages/ai/src/api/openai-completions.lazy.ts';
let reply = ''; const requests: any[] = []; const records: any[] = [];
const watchdog = setTimeout(() => { console.error('15s probe watchdog'); process.exit(2); }, 15000);
const server = Bun.serve({hostname:'127.0.0.1', port:0, async fetch(req) {
  requests.push({path:new URL(req.url).pathname, headers:Object.fromEntries(req.headers), body:await req.json()});
  return new Response(reply, {headers:{'content-type':'text/event-stream'}});
}});
const frame = (e:any) => `event: ${e.type}\ndata: ${JSON.stringify(e)}\n\n`;
const context:any = {messages:[{role:'user',content:'hello',timestamp:0}]};
const cases = [
  {api:'anthropic-messages', id:'claude-sonnet-4-5', provider:'anthropic', factory:anthropicMessagesApi, base:'', path:'/v1/messages', auth:'x-api-key', value:'fixture-key', reply:[
    {type:'message_start',message:{id:'msg_fixture',model:'claude-sonnet-4-5',usage:{input_tokens:1,output_tokens:0}}},
    {type:'content_block_start',index:0,content_block:{type:'text',text:''}},
    {type:'content_block_delta',index:0,delta:{type:'text_delta',text:'hello'}},
    {type:'content_block_stop',index:0},
    {type:'message_delta',delta:{stop_reason:'end_turn'},usage:{output_tokens:1}},
    {type:'message_stop'}].map(frame).join('')},
  {api:'google-generative-ai',id:'gemini-2.5-flash',provider:'google',factory:googleGenerativeAIApi,base:'/v1beta',path:'/v1beta/models/gemini-2.5-flash:streamGenerateContent',auth:'x-goog-api-key',value:'fixture-key',reply:'data: '+JSON.stringify({responseId:'one',candidates:[{content:{role:'model',parts:[{text:'hello'}]},finishReason:'STOP'}]})+'\n\n'},
  {api:'openai-completions',id:'fixture-chat',provider:'fixture',factory:openAICompletionsApi,base:'/v1',path:'/v1/chat/completions',auth:'authorization',value:'Bearer fixture-key',reply:'data: '+JSON.stringify({id:'one',choices:[{index:0,delta:{content:'hello'},finish_reason:'stop'}]})+'\n\ndata: [DONE]\n\n'}
];
try {
  for (const c of cases) {
    const api = c.factory();
    assert.equal(api.cancelDeferred, undefined);
    const model:any = {id:c.id,name:'fixture',api:c.api,provider:c.provider,baseUrl:`http://127.0.0.1:${server.port}${c.base}`,reasoning:true,input:['text'],contextWindow:100000,maxTokens:4096,cost:{input:1,output:1,cacheRead:0,cacheWrite:0}};
    for (const mode of ['success','missing-auth','preaborted']) {
      reply = c.reply; const before = requests.length; const controller = new AbortController();
      if (mode === 'preaborted') controller.abort();
      const options:any = {maxRetries:0,cacheRetention:'none',signal:controller.signal};
      if (mode !== 'missing-auth') options.apiKey = 'fixture-key';
      let s:any; assert.doesNotThrow(() => { s = api.streamSimple(model,context,options); });
      assert.equal(typeof s[Symbol.asyncIterator], 'function'); assert.equal(typeof s.result, 'function');
      const events:any[]=[]; for await (const e of s) events.push(e);
      const result = await s.result(); const last = events.at(-1);
      assert.strictEqual(result,last.message ?? last.error);
      assert.equal(events.filter(e=>e.type==='done'||e.type==='error').length,1);
      if (mode === 'success') {
        assert.equal(events[0].type,'start'); assert.equal(last.type,'done'); assert.equal(result.stopReason,'stop');
        assert.equal(result.content[0].text,'hello'); assert.equal(requests.length-before,1);
        assert.equal(requests[before].path,c.path); assert.equal(requests[before].headers[c.auth],c.value);
      } else {
        assert.equal(last.type,'error'); assert.equal(result.stopReason,mode==='missing-auth'?'error':'aborted');
        assert.equal(requests.length,before);
        if(mode==='missing-auth') {assert.deepEqual(events.map(e=>e.type),['error']); assert.deepEqual(result.content,[]);}
      }
      records.push({api:c.api,mode,events:events.map(e=>e.type),stopReason:result.stopReason,httpRequests:requests.length-before,resultIdentity:true,status:'pass'});
      console.log(JSON.stringify(records.at(-1)));
    }
  }
  console.log(JSON.stringify({cases:records.length,httpRequests:requests.length,status:'pass',mockedImports:[],scope:'actual lazy wrappers, actual adapters and SDKs, local raw SSE server'}));
} finally { server.stop(true); clearTimeout(watchdog); }
