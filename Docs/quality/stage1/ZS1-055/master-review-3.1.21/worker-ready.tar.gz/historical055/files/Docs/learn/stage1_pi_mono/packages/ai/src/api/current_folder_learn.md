# ZS1-055 packages/ai/src/api 目录复核 [_]

Authority 3.1.17，requirement_digest `4b4bbb809fc660d55186317e9e12cfdccc7f3a2ba4567dc94b93d96858584f1a`。本报告为 provisional 候选，不继承子项接受状态。捕获时 016/017/029 的主控 master receipt 均不存在。本轮不修改产品源码，也不扩展冻结源文件集合。

## 范围与直属清单

冻结子集只有 016 anthropic-messages.ts、017 google-generative-ai.ts、029 openai-completions.ts；各文件完整原报告和实际源码探针的原件副本在 `Docs/quality/stage1/ZS1-055/worker-directory-review/original-evidence/{016,017,029}`，本报告不替代其逐文件复核。目录有 32 个直属文件、0 个直属目录。精确字节数、行数、SHA 和逐个 scope 见 inventory.json；三个源 SHA 分别为 `8e105cc5b2dd304547ed613b70de4740c4db93cee830dc452c2de945052b12b7`、`1395c3f2a90bf701b8b5fc1b6f7de8d323193ed339e07a60630900099a543757`、`5874bf0b121db117bd4eba8fffa750252f5f7617f38306c6eb1f746575896319`。

另外 29 文件仅作直属 inventory / 连接上下文：anthropic-messages.lazy.ts、azure-openai-responses.lazy.ts、azure-openai-responses.ts、bedrock-converse-stream.lazy.ts、bedrock-converse-stream.ts、cloudflare-ai-binding.ts、cloudflare.ts、constrained-sampling.ts、github-copilot-headers.ts、google-generative-ai.lazy.ts、google-shared.ts、google-vertex.lazy.ts、google-vertex.ts、lazy.ts、mistral-conversations.lazy.ts、mistral-conversations.ts、openai-codex-responses.lazy.ts、openai-codex-responses.ts、openai-completions.lazy.ts、openai-prompt-cache.ts、openai-responses-shared.ts、openai-responses.lazy.ts、openai-responses.ts、openrouter-images.lazy.ts、openrouter-images.ts、pi-messages.lazy.ts、pi-messages.ts、simple-options.ts、transform-messages.ts。没有对其余 provider 宣称完整覆盖。

## 实际调用与数据流

三个 adapter 互不调用。各自 lazy factory → lazyApi → lazyStream 同步返回外层 AssistantMessageEventStream，异步 import 本 adapter 后调用 stream/streamSimple。forwardStream 按顺序转发同一事件引用，末尾等待内层 result；不是复制快照、重排器或校验器。三个 factory 都没有启用 deferred fetch/cancel 能力。外层 setup rejection 构造空 assistant/error，usage 为零，模型身份来自传入 model；因此入口不同会改变缺鉴权异常的传播方式。

streamSimple 先处理鉴权、通用采样/输出上限和 reasoning，再调用各自 stream；stream 构造请求、SDK、累积消息和流事件。simple-options 合并模型采样默认值与调用者覆盖，按 contextWindow 减估算输入及 4096 余量限制输出，预算 thinking 至少给答案预留 1024；这属于请求参数计算，不等于真实 token 计量或 host 花费落账。Anthropic 使用 Messages SDK 与原生 blocks；Google 使用 GoogleGenAI，经 google-shared 转换 contents/parts；Chat 使用 OpenAI SDK，处理 choices/delta/tool_calls 与多种 reasoning 字段。SDK版本分别0.124.0、2.21.0、6.40.0，旧 probe 的 package/lock/install 文件保留可核查依赖来源。

Anthropic/Chat 的 transform-messages 在请求历史上保留同模型签名、清理跨模型不兼容签名、规范化外模型 tool ID 并关联 result；丢弃 error/aborted assistant，给未配对调用补合成错误 toolResult。Google 有自己的 parts/signature 转换。合成结果只修整后续请求上下文，不证明工具执行过，也不能代替持久化 journal 的事实结果。utils/event-stream 位于本目录外，仅为连接上下文：FIFO、terminal 识别、result promise 与可变 partial 引用的语义，不属于本目录新增文件覆盖。

## 事件、异常、取消和恢复

| 边界 | 实际源码组合行为 | 证据与限制 |
| --- | --- | --- |
| 正常流 | start → 分块 start/delta/end → done，result 与终态 message 是同一对象 | 新 lazy-native 3 个成功场景逐个断言，真实 SDK 和本机原始 SSE，3 次 HTTP |
| 鉴权缺失 | 直接 streamSimple 同步抛错；lazy 调用返回流，只有 error，空 content，没有 HTTP | 旧三份源码 probe 验证直接调用；新3场景验证 lazy，没有 mock imports |
| 预取消 | signal 传至 adapter/SDK；终态 error 事件 reason=aborted，没有 HTTP | 新3场景，终态唯一、result identity 均断言 |
| 末尾错误 | 三者都检查 signal 和合法 stop/finish reason；缺终态变 error，保留已有 partial 并清除临时解析字段 | 旧真实源码23/17/33场景包含结束原因、参数修复、tool end 早于后续错误等；不是本轮新增73场景 |
| Chat 兼容 EOF | 显式 supportsFinishReason=false 可按是否有工具推断 stop/toolUse；普通模式缺 finish_reason 必须报错 | 029 原探针和当前读取的源码尾部相符 |
| length | 源 stop reason 可以 length 并发 done，不能自动等价于工具参数完整或目标可接受结果 | 旧映射场景；目标策略另见下表 |
| 取消传播范围 | lazy 本身不取消 import promise；通用 stream 不证明外部进程退出或会话落账 | 本轮仅执行 preabort，未执行半包中断、网络停顿、并发消费、模块加载失败及恢复重试 |
| 可重放性 | source history 转换是下一次请求的数据准备；错误 partial 仍可被调用者观察 | 没有源码持久化/session 恢复测试；不能将合成 tool result 当成执行证据 |

23/17/33 是各独立 source probe 的场景数，不与9个目录组合场景或历史 target cases 相加称端到端覆盖。016 初次同模型ID预期错误及修正后的成功记录原样保留。actual SDK 是未修改依赖；loopback server、model/context/options 是显式测试输入。没有外网模型调用、Bun tsc、upstream 全套测试或性能预算结论。

## 当前目标的实际责任映射

当前目标完整快照和 SHA 在 inventory.json 的 snapshots 中；读取重点是函数入口、原生分派、finish 和校验边界。目标测试仍沿用原证据的旧 source hash，不声称本次重新运行当前 Rust 快照。

| Source 责任 | 当前目标函数/数据边界 | 差异及验收归属 |
| --- | --- | --- |
| Anthropic 请求/blocks/terminal | src/providers/anthropic.rs request_body、Fold::event、Fold::finish、read_response；backend.rs 原生分派 | finish 要求 message_stop、合法 blocks 与 stop/tool 一致，能力允许后才发布 ToolCallDone/Completed；source 的早 toolcall_end 不能当 host 执行授权 |
| Google 请求/parts | src/providers/google.rs request_body、Fold::chunk/finish、derive_calls/read_response | 目标校验 responseId、请求模型与 modelVersion、parts/signature/capability；不是 source 宽松候选零消费策略的逐字移植 |
| Chat 累积/终态/reasoning | src/backend/chat_stream.rs Stream::event/finish/read、Reasoning::fold/annotate、validate_history/replay | 当前已有结构化 reasoning 历史校验，不能沿用旧报告“尚无此能力”的表述。finish 完整检查 tool IDs/names/arguments 后才发完成事件；BTreeMap 按索引收集与source首次出现顺序有差别 |
| 请求控制 | backend.rs complete_with_control、transport::send_json、各 read_response/read(cancelled,sink) | 短接收轮询、取消谓词和 sink 返回错误由 Rust host 路径承担，不存在 TypeScript lazy import 的同构目标目录 |
| 模型与 reasoning | providers/registry.rs ModelDescriptor::effective_capabilities/validate_reasoning；backend.rs validate_model/model_descriptor | exact provider/id 描述与 wire 能力相交；定价为整数带来源，未知不是免费；没有由 source 所在目录推出目标 owner |

目标源 snapshot 只证明本次读到的实现；主控的当前整体验收、会话重载、工具重新校验、预算持久化分别归属其 owner，不由055承接。历史target-native日志和owner-hashes保留原时间/范围，禁止提升为本次当前目标测试结果。

## 验证、交付和回滚

新增 lazy-native.log SHA `4582475b24653c4df9a61a0689d3f9e90cb45e6f8827727c37305e9acd6f1907`，9/9通过、3次HTTP；runner receipt 记录实际命令、时间、HOME/CODEX_HOME保留。evidence verifier 校验直属inventory、源/快照、原依赖证据与日志收据，不把哈希核对当行为测试。G-STAGE 单独保留主仓只读运行结果；缺master回执时不得宣布接受。冻结包由patch前向/反向全字节验证。回滚仅移除本055报告与独立证据目录，不递归删除子报告、不修改旧冻结包或产品源码。
