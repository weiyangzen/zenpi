from pathlib import Path
import hashlib,json
root=Path.cwd(); ev=root/'Docs/quality/stage1/ZS1-055/worker-directory-review'
sha=lambda b:hashlib.sha256(b).hexdigest()
j=json.loads((ev/'inventory.json').read_text()); source=Path('/Users/wangweiyang/GitHub/pi-mono')/j['folder']
assert len(j['entries'])==32 and all(r['kind']=='file' for r in j['entries'])
assert sorted(p.name for p in source.iterdir())==[r['name'] for r in j['entries']]
for r in j['entries']:assert sha((source/r['name']).read_bytes())==r['sha256']
for r in j['snapshots']:assert sha((root/r['snapshot']).read_bytes())==r['sha256']
for r in json.loads((ev/'original-evidence.json').read_text()):assert sha((root/r['copy']).read_bytes())==r['sha256']
r=json.loads((ev/'lazy-native.json').read_text());assert r['exit_code']==0 and sha(Path(r['output']).read_bytes())==r['sha256']
rows=[json.loads(s) for s in (ev/'lazy-native.log').read_text().splitlines()];assert rows[-1]['cases']==9 and rows[-1]['httpRequests']==3 and all(x['status']=='pass' for x in rows)
print('PASS: 32 direct entries, selected source hashes, snapshots, original evidence, 9-case actual runtime receipt; no acceptance inferred')
