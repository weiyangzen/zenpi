"""ZS1-055 data-only portable audit. No subprocess/network/old script invocation."""
from pathlib import Path
import csv,hashlib,json,re,sys,tarfile
root=Path(sys.argv[1]).resolve()
live='--live' in sys.argv[2:]
checks=[]
report='Docs/learn/stage1_pi_mono/packages/ai/src/api/current_folder_learn.md'
items={'ZS1-055','ZS1-016','ZS1-017','ZS1-029'}
def load(p):return json.loads(p.read_text())
def ident(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def match(p,r):return p.is_file() and ident(p)=={k:r[k]for k in ['bytes','sha256']}
def check(n,v,detail=None):checks.append({'name':n,'passed':bool(v),'detail':detail})
def rows(p):
 with p.open()as f:return list(csv.DictReader(f,delimiter='\t'))
def exactset(p,names):return not any(x.is_symlink()for x in p.rglob('*')) and {str(x.relative_to(p))for x in p.rglob('*')if x.is_file()}==set(names)
def apply_data(base, patch, reverse=False):
    """Reconstruct unified text hunks in memory only, with exact preimage checks."""
    lines = base.splitlines(True); out = []; pos = 0
    pl = patch.splitlines(True); i = 0; hunks = 0
    while i < len(pl):
        m = re.match(rb'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@', pl[i])
        if not m:
            i += 1; continue
        a, ac, b, bc = m.groups(); ac = int(ac or b'1'); bc = int(bc or b'1')
        old_start, old_count = (int(b), bc) if reverse else (int(a), ac)
        new_count = ac if reverse else bc
        begin = old_start - 1 if old_count else old_start
        assert pos <= begin <= len(lines)
        out.extend(lines[pos:begin]); pos = begin; consumed = produced = 0; i += 1
        while i < len(pl) and pl[i][:1] in (b' ', b'+', b'-'):
            tag = pl[i][:1]; payload = pl[i][1:]; i += 1
            if i < len(pl) and pl[i].startswith(b'\\ No newline'):
                payload = payload[:-1] if payload.endswith(b'\n') else payload; i += 1
            if reverse: tag = {b'+': b'-', b'-': b'+', b' ': b' '}[tag]
            if tag in (b' ', b'-'):
                assert pos < len(lines) and lines[pos] == payload
                pos += 1; consumed += 1
            if tag in (b' ', b'+'): out.append(payload); produced += 1
        assert consumed == old_count and produced == new_count
        hunks += 1
    assert hunks
    out.extend(lines[pos:]); return b''.join(out)

inputs=load(root/'input-inventory.json');inv=load(root/'direct-inventory.json')
check('47 current input identities',len(inputs)==47 and all(match(root/r['path'],r)for r in inputs))
api=root/'source/packages/ai/src/api'
check('32 direct files no directories or links',len(inv)==32 and exactset(api,[r['name']for r in inv])and all(p.is_file()for p in api.iterdir()))
check('all direct inventory bytes hashes lines',all(match(api/r['name'],r)and len((api/r['name']).read_bytes().splitlines())==r['lines']for r in inv))
check('only016017029 formal',sorted(r['scope']for r in inv if r['scope']!='context-only')==['formal016','formal017','formal029'])
hist=root/'historical055';hm=load(hist/'manifest.json');hi=load(root/'historical-inventory.json');cap=load(root/'capture.json')
check('198 original055 physical files',len(hi)==198 and exactset(hist,[r['path']for r in hi])and all(match(hist/r['path'],r)for r in hi))
check('historical055 manifest frozen identity',match(hist/'manifest.json',cap['historical055_manifest']))
check('65 historical payloads and bases',len(hm['files'])==65 and all(match(hist/'files'/r['path'],r)and match(hist/'base'/r['path'],{'bytes':r['base_bytes'],'sha256':r['base_sha256']})for r in hm['files']))
check('historical candidate patch runner identity',match(hist/'candidate.patch',{'bytes':hm['patch_bytes'],'sha256':hm['patch_sha256']})and ident(hist/'run_candidate_probe.py')['sha256']==hm['runner_sha256'])
patches=[];ok=True
for r in hm['files']:
 pb=(hist/('patches/'+r['path'].replace('/','__')+'.patch')).read_bytes();patches.append(pb)
 base=(hist/'base'/r['path']).read_bytes();b=(hist/'files'/r['path']).read_bytes()
 try:ok &= hashlib.sha256(pb).hexdigest()==r['patch_sha256']and apply_data(base,pb)==b and apply_data(b,pb,True)==base
 except (AssertionError,ValueError):ok=False
check('65 historical forward reverse memory reconstructions',ok)
check('combined historical patch exact',b''.join(patches)==(hist/'candidate.patch').read_bytes())
e=hist/'files/Docs/quality/stage1/ZS1-055/worker-directory-review';old=load(e/'inventory.json')
check('32 direct identities equal old inventory',[(r['name'],r['kind'],r['bytes'],r['sha256'])for r in inv]==[(r['name'],r['kind'],r['bytes'],r['sha256'])for r in old['entries']])
check('original copied leaf evidence identities',all(match(hist/'files'/r['copy'],r)for r in load(e/'original-evidence.json')))
for n,code in [('lazy-native',0),('evidence-verified',0),('g-stage-main',1)]:
 r=load(e/(n+'.json'));check('historical receipt '+n,r['exit_code']==code and r['started_at'].startswith('2026-09-10')and match(e/(n+'.log'),r))
obs=[json.loads(s)for s in(e/'lazy-native.log').read_text().splitlines()]
check('historical9 scenarios3 HTTP actual imports',len(obs)==10 and obs[-1]['cases']==9 and obs[-1]['httpRequests']==3 and obs[-1]['mockedImports']==[]and all(r['status']=='pass'and r['resultIdentity']for r in obs[:-1]))
check('historical matrix and terminal identity observations', {(r['api'],r['mode'])for r in obs[:-1]}=={(a,m)for a in ['anthropic-messages','google-generative-ai','openai-completions']for m in ['success','missing-auth','preaborted']}and all(r['httpRequests']==(1 if r['mode']=='success'else 0)and r['stopReason']=={'success':'stop','missing-auth':'error','preaborted':'aborted'}[r['mode']]for r in obs[:-1]))
check('historical055 G-STAGE missing receipt retained',load(e/'g-stage-main.log')['structural']['ok']and'ZS1-055.master.json'in(e/'g-stage-main.log').read_text())
for n,code in [('source-native',1),('source-native-final',0)]:
 p=e/'original-evidence/016';r=load(p/(n+'.json'));check('original016 '+n+' preserved',r['exit_code']==code and match(p/(n+'.log'),r))
for child,pkg,ver in [('016','@anthropic-ai/sdk','0.124.0'),('017','@google/genai','2.21.0'),('029','openai','6.40.0')]:
 lock=load(e/'original-evidence'/child/'package-lock.json')['packages'];check('historical SDK '+child,lock['node_modules/'+pkg]['version']==ver)
check('historical partial-json version',load(e/'original-evidence/029/package-lock.json')['packages']['node_modules/partial-json']['version']=='0.1.7')
ledger=load(root/'reading-ledger.json')
check('41 new actually read ranges exact',len(ledger)==41 and all(match(root/r['excerpt'],r)and(root/r['path']).read_bytes()[slice(*r['byte_range'])]==(root/r['excerpt']).read_bytes()==b''.join((root/r['path']).read_bytes().splitlines(True)[r['line_range'][0]-1:r['line_range'][1]])for r in ledger))
check('nine context-only adapter readings limited to first60 lines',sum(r['kind'].startswith('new import/interface')and r['line_range']==[1,60]for r in ledger)==9)
a=load(root/'authority/Docs/execution/active_requirement.json')
keys=['blueprint_version','requirement_digest','baseline_snapshot_sha256','run_id']
check('3.1.21 authority binding',a['blueprint_version']=='3.1.21'and a['requirement_digest']=='3456abcbbebbc4e0ab383c319851b0a6e71b19ee9b3c060a6e212f61a89c9d9d'and a['baseline_snapshot_sha256']=='92b06c4b1dcdca7614d226ce5f41205646a9e63967789d2b6ed4ee272d240884'and a['run_id']=='zenpi-stage1-20260911')
for child,count in [('016',118),('017',11)]:
 p=root/('dependency'+child);r=load(p/'receipt.json')
 check('master receipt identity '+child,match(p/'receipt.json',cap['dependencies'][child]['receipt']))
 check('accepted authority and complete read ranges '+child,r['complete']and r['role']=='master'and r['manual_review']['decision']=='accepted'and all(r[k]==a[k]for k in keys if k!='blueprint_version')and r['source_hash']==ident(root/'source'/r['source_path'])['sha256']and r['read_ranges'][0][0]==0 and r['read_ranges'][-1][1]==(root/'source'/r['source_path']).stat().st_size and all(x[1]==y[0]for x,y in zip(r['read_ranges'],r['read_ranges'][1:])))
 check('all master artifacts '+child,len(r['artifacts'])==count and all(match(p/x['path'],x)for x in r['artifacts'])and exactset(p,['receipt.json']+[x['path']for x in r['artifacts']]))
p17=root/'dependency017/Docs/quality/stage1/ZS1-017/master-review-3.1.21'
check('017 canonical is worker plus actual master review',(root/'dependency017/Docs/learn/stage1_pi_mono/files/packages/ai/src/api/google-generative-ai.ts_learn.md').read_bytes()==(p17/'worker-report.md').read_bytes()+b'\n\n'+(p17/'review.md').read_bytes())
with tarfile.open(p17/'worker-ready.tar.gz')as t:
 members={m.name:m for m in t.getmembers() if m.isfile()};m=json.loads(t.extractfile('manifest.json').read())
 check('017 master archive470 files and original manifest',len(members)==470 and t.extractfile('manifest.json').read()==(p17/'worker-manifest.json').read_bytes()and set(members)=={'manifest.json'}|{r['path']for r in m['files']})
 check('017 archive all469 payload bytes',all(len(b:=t.extractfile(r['path']).read())==r['bytes']and hashlib.sha256(b).hexdigest()==r['sha256']for r in m['files']))
 check('017 selected reused members exact',all(match(root/r['path'],r)and t.extractfile(r['member']).read()==(root/r['path']).read_bytes()for r in load(root/'reused017-inventory.json')))
 sl=json.loads(t.extractfile('reading-ledger.json').read());src=(api/'google-generative-ai.ts').read_bytes()
 check('017 prior three full readings reused',len(sl)==3 and b''.join(t.extractfile(r['excerpt']).read()for r in sl)==src and all(src[slice(*r['byte_range'])]==t.extractfile(r['excerpt']).read()for r in sl))
 check('Google shared current equals previously read archive',(api/'google-shared.ts').read_bytes()==t.extractfile('source/packages/ai/src/api/google-shared.ts').read())
p29=root/'dependency029-candidate';m29=load(p29/'manifest.json')
check('029 candidate identity pending at capture',not cap['dependencies']['029']['receipt_exists']and match(p29/'manifest.json',cap['dependencies']['029']['manifest']))
check('029 all577 physical576payload exact',len(m29['files'])==576 and exactset(p29,['manifest.json']+[r['path']for r in m29['files']])and all(match(p29/r['path'],r)for r in m29['files']))
sl=load(p29/'reading-ledger.json');src=(api/'openai-completions.ts').read_bytes()
check('029 seven prior full readings reused',len(sl)==7 and b''.join((p29/r['excerpt']).read_bytes()for r in sl)==src and all(src[slice(*r['byte_range'])]==(p29/r['excerpt']).read_bytes()for r in sl))
ctx=load(p29/'context-reading-ledger.json')
check('all29 reused029 context ranges remain exact',len(ctx)==29 and all(match(p29/r['excerpt'],r)and(p29/r['path']).read_bytes()[slice(*r['byte_range'])]==(p29/r['excerpt']).read_bytes()for r in ctx))
check('constrained-sampling current equals prior full reading',(api/'constrained-sampling.ts').read_bytes()==(p29/'source/packages/ai/src/api/constrained-sampling.ts').read_bytes())
check('current Google equals accepted017 context',(root/'target/src/providers/google.rs').read_bytes()==(root/'reused017/target/src/providers/google.rs').read_bytes())
rels=['src/backend/chat_stream.rs','src/backend.rs','src/providers/registry.rs','src/backend/transport.rs','src/core.rs','src/headless.rs']
check('six current target contexts equal prior029 reading snapshots',all((root/'target'/p).read_bytes()==(p29/'target'/p).read_bytes()for p in rels))
drift=load(root/'old-current-drift.json')
check('all15 old/current snapshots retained',len(drift)==15 and all(match(root/r['historical'],r['old'])and match(root/r['current'],r['new'])and r['same']==(r['old']==r['new'])for r in drift))
check('exactlythree target protocol files changed',{r['current']for r in drift if not r['same']}=={'target/src/providers/anthropic.rs','target/src/providers/google.rs','target/src/backend/chat_stream.rs'})
check('only055 authored candidate',exactset(root/'files',[report])and(root/'files'/report).read_bytes()==(root/'report-body.md').read_bytes())
check('old report full prefix preserved',(root/'files'/report).read_bytes().startswith((hist/'files'/report).read_bytes()))
for name,base in [('candidate.patch',b''),('append-existing-report.patch',(hist/'files'/report).read_bytes())]:
 if(root/name).exists():
  pb=(root/name).read_bytes();target=(root/'files'/report).read_bytes();check('new candidate memory forward reverse '+name,apply_data(base,pb)==target and apply_data(target,pb,True)==base)
for n in ['source_manifest.tsv','file_learn_index.tsv']:
 selected=[r for r in rows(root/'authority/Docs/learn/stage1_pi_mono'/n)if r['item_id']in items]
 check('formal scope bindings '+n,len(selected)==3 and {r['item_id']for r in selected}==items-{'ZS1-055'}and all(r['source_hash']==ident(root/'source'/r['source_path'])['sha256']for r in selected))
fr=[r for r in rows(root/'authority/Docs/learn/stage1_pi_mono/folder_learn_index.tsv')if r['item_id']=='ZS1-055']
check('055 own folder binding and formal dependency list',len(fr)==1 and fr[0]['folder_path']=='packages/ai/src/api'and fr[0]['folder_artifact']==report and fr[0]['depends']=='ZS1-016,ZS1-017,ZS1-029'and fr[0]['status']=='[ ]')
def relevant_blueprint(p):return [s for s in p.read_text().splitlines()if any('**'+i+'**'in s for i in items)]
def scope_compare(first,last):
 k=all(load(first/'Docs/execution/active_requirement.json')[k]==load(last/'Docs/execution/active_requirement.json')[k]for k in keys)
 diffs={}
 for n in ['source_manifest.tsv','file_learn_index.tsv','folder_learn_index.tsv']:
  path='Docs/learn/stage1_pi_mono/'+n
  x=[r for r in rows(first/path)if r['item_id']in items];y=[r for r in rows(last/path)if r['item_id']in items]
  diffs[n]={'initial':x,'final':y,'same':x==y}
 diffs['blueprint']={'initial':relevant_blueprint(first/'Docs/stage_1_v3_pi_mono_blueprint.md'),'final':relevant_blueprint(last/'Docs/stage_1_v3_pi_mono_blueprint.md')}
 diffs['blueprint']['same']=diffs['blueprint']['initial']==diffs['blueprint']['final']
 return k,diffs
if(root/'authority-final').exists():
 observation=load(root/'authority-scope-observation.json');k,diffs=scope_compare(root/'authority',root/'authority-final')
 check('final full authority captures retained',all(match(root/'authority'/r['path'],r['initial'])and match(root/'authority-final'/r['path'],r['final'])for r in observation['files']))
 check('final relevant keys stable and scope observations exact',k and diffs==observation['relevant_scope'])
 check('055 own row unchanged',diffs['folder_learn_index.tsv']['same'])
 # Child status transitions are recorded for master review rather than silently closing dependencies.
 check('child authority structural bindings unchanged',all([{k:v for k,v in r.items()if k!='status'}for r in d['initial']]==[{k:v for k,v in r.items()if k!='status'}for r in d['final']]for n,d in diffs.items()if n!='blueprint'))
if live:
 check('live relevant sources and target contexts unchanged',all(match(Path(r['origin']),r)for r in inputs))
 check('live api physical direct set stable',{p.name for p in Path('/Users/wangweiyang/GitHub/pi-mono/packages/ai/src/api').iterdir()}=={r['name']for r in inv})
 master=Path('/Users/wangweiyang/GitHub/zenpi');k,diffs=scope_compare(root/'authority-final'if(root/'authority-final').exists()else root/'authority',master)
 check('live scoped authority equals final relevant capture',k and all(d['same']for d in diffs.values()))
 for child in ['016','017']:
  check('live accepted child receipt '+child,match(master/('Docs/learn/stage1_pi_mono/receipts/ZS1-'+child+'.master.json'),cap['dependencies'][child]['receipt']))
 oldprotected=load(root/'old-ready-inventory.json');check('6080 old ready files immutable',len(oldprotected)==6080 and all(match(Path(p),r)for p,r in oldprotected.items()))
if(root/'manifest.json').exists():
 m=load(root/'manifest.json');check('frozen all payloads exact',all(match(root/r['path'],r)for r in m['files']));check('frozen exact physical file set',exactset(root,['manifest.json']+[r['path']for r in m['files']]))
result={'schema':'zs1-055-independent-directory-offline/v1','passed':all(r['passed']for r in checks),'checks':checks,'mode':'portable and live scoped'if live else'portable only','candidate':ident(root/'files'/report),'runtime_executions_this_round':0,'scope':'055 candidate only;016017 accepted captured,029 candidate pending; no dependency closure or old script execution'}
print(json.dumps(result,ensure_ascii=False,indent=2));sys.exit(0 if result['passed']else 1)
