# ZS1-055 3.1.21 独立目录候选

唯一拟整合报告：`files/Docs/learn/stage1_pi_mono/packages/ai/src/api/current_folder_learn.md`。
旧055全文作为报告前缀保留，新判断在3.1.21追加节。candidate.patch用于空目标；append-existing-report.patch只针对包内旧055正文。二者均在内存中验证，未应用到主线。

本包只读携带旧055整包、016/017主审receipt及其全部artifacts、029候选整包，保留所有旧失败和版本。不得把目录下旧runner/probe/accept脚本作为本轮核验命令运行。产品、SDK、HTTP、Bun/Cargo、预算执行均为0。

便携核验仅需Python标准库（不安装依赖、不联网）：

```
python3 /path/to/package/verify_offline.py /path/to/package
```

原机额外只读检查：

```
python3 /path/to/package/verify_offline.py /path/to/package --live
```

--live比较相关代码、四个权威键、本目录及正式子项行，并检查原B/C的6080文件保护清单；整份blueprint其他进度变化不作门禁。外机不使用--live。

阅读与证据：direct-inventory.json是32文件/0目录实际清单；reading-ledger.json为41段本轮实际阅读，9个大型上下文文件只读1–60行；reused017-inventory和dependency029-candidate原始ledger明确区分本任务此前完整阅读的精确复用；016源阅读依主审receipt区间，不冒称本轮源全读。old-current-drift保留3个目标协议文件漂移。

capture记录016/017 accepted、029候选未获主审的状态；最终scope observation仍确认029无receipt。055也是候选，离线passed不是语义验收或依赖闭合。

offline-audit-initial为初次58项通过记录，offline-audit-final为冻结前最终核验；冻结manifest不自包含。冻结后原机及便携核验输出保存在包外，避免改动ready。
