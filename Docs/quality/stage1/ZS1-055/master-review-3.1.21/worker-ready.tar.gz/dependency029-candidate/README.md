# ZS1-029 independent single-file review, authority3.1.21

Only `files/Docs/learn/stage1_pi_mono/files/packages/ai/src/api/openai-completions.ts_learn.md` is the report candidate. All other files are evidence. Product/source files are snapshots and are not installation patches. Master semantic acceptance remains pending.

Portable verification, using Python standard library only:

```text
python3 /path/to/package/verify_offline.py /path/to/package
```

On the original machine append `--live` to compare actual relevant source/context, the029 scoped authority keys and5813 protected original ready files. No subprocess/network or old-script invocation occurs; old unified patches are reconstructed in memory against their exact preimages and reversed, never applied to a checkout. All historical scripts/install logs are data only. No behavior tests, build/npm/HTTP/PTY/budget reruns.

`reading-ledger.json` binds seven new contiguous source readings covering62416 bytes/1717 lines. `context-reading-ledger.json` distinguishes new full/partial context reads from eight earlier exact context reuses in this same task. `reused-context-inventory.json` identifies those prior artifacts. No sibling or parent acceptance follows.

`historical-inventory.json` binds all508 physical files across the three old C029 packages. This includes the12/63/268 original manifest payload tables and nested exact copies, the complete report prefix chain,33 source cases/37 HTTP requests, original8 target passes and later15/20/22 Chat receipts. These historical totals are separate runs, never additive new coverage. The current Chat test file has22 definitions; current headless521c remains a different integrated runtime identity from old executions.

The initial58-check live audit passed. Afterwards the initial/final authority snapshots were both retained: unrelated054/406 acceptance changed overall authority files, while029 source/row and requirement version/digest/baseline/run stayed stable. The final audit also verifies these captures. This local rule does not modify global G-STAGE.

`manifest.json` binds the final exact payload set and hashes. Postfreeze receipts are outside the immutable ready package to avoid recursive self-hashing. Historical core-drift integrity failure and missing-master-receipt G-STAGE failures remain unchanged. This report/package alone does not mark029 accepted.
