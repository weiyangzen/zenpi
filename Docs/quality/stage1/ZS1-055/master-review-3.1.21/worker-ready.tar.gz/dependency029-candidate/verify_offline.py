"""ZS1-029 package-only audit; optional original-machine --live check. No subprocess/network."""
from pathlib import Path
import csv
import hashlib
import json
import re
import sys

root = Path(sys.argv[1]).resolve()
live = '--live' in sys.argv[2:]
checks = []
report = 'Docs/learn/stage1_pi_mono/files/packages/ai/src/api/openai-completions.ts_learn.md'
source = 'packages/ai/src/api/openai-completions.ts'
def load(p): return json.loads(p.read_text())
def ident(p):
    b = p.read_bytes()
    return {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}
def match(p, row): return p.is_file() and ident(p) == {k: row[k] for k in ('bytes', 'sha256')}
def check(n, v, detail=None): checks.append({'name': n, 'passed': bool(v), 'detail': detail})
def rows(p):
    with p.open() as f: return list(csv.DictReader(f, delimiter='\t'))
def apply_data(base, patch, reverse=False):
    """Reconstruct unified text hunks in memory only, with exact preimage checks."""
    lines = base.splitlines(True); out = []; pos = 0
    pl = patch.splitlines(True); i = 0; hunks = 0
    while i < len(pl):
        m = re.match(rb'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@', pl[i])
        if not m:
            i += 1; continue
        a, ac, b, bc = m.groups(); ac = int(ac or b'1'); bc = int(bc or b'1')
        old_start, old_count = (int(b), bc) if reverse else (int(a), ac)
        new_count = ac if reverse else bc
        begin = old_start - 1 if old_count else old_start
        assert pos <= begin <= len(lines)
        out.extend(lines[pos:begin]); pos = begin; consumed = produced = 0; i += 1
        while i < len(pl) and pl[i][:1] in (b' ', b'+', b'-'):
            tag = pl[i][:1]; payload = pl[i][1:]; i += 1
            if i < len(pl) and pl[i].startswith(b'\\ No newline'):
                payload = payload[:-1] if payload.endswith(b'\n') else payload; i += 1
            if reverse: tag = {b'+': b'-', b'-': b'+', b' ': b' '}[tag]
            if tag in (b' ', b'-'):
                assert pos < len(lines) and lines[pos] == payload
                pos += 1; consumed += 1
            if tag in (b' ', b'+'): out.append(payload); produced += 1
        assert consumed == old_count and produced == new_count
        hunks += 1
    assert hunks
    out.extend(lines[pos:]); return b''.join(out)

inputs=load(root/'input-inventory.json')
check('all captured inputs exact',all(match(root/r['kind']/r['path'],r)for r in inputs))
src=(root/'source'/source).read_bytes()
check('62416 bytes1717 lines frozen source',len(src)==62416 and len(src.splitlines())==1717 and hashlib.sha256(src).hexdigest()=='5874bf0b121db117bd4eba8fffa750252f5f7617f38306c6eb1f746575896319')
ledger=load(root/'reading-ledger.json');cursor=0;ok=True
for r in ledger:
    a,b=r['byte_range'];x,z=r['line_range']
    ok &= a==cursor and src[a:b]==(root/r['excerpt']).read_bytes()==b''.join(src.splitlines(True)[x-1:z])and match(root/r['excerpt'],r)
    cursor=b
check('seven new complete contiguous source readings',ok and cursor==62416 and len(ledger)==7)
context=load(root/'context-reading-ledger.json')
check('all29 context ranges byte and line exact',len(context)==29 and all(match(root/r['excerpt'],r)and(root/r['path']).read_bytes()[slice(*r['byte_range'])]==(root/r['excerpt']).read_bytes()==b''.join((root/r['path']).read_bytes().splitlines(True)[r['line_range'][0]-1:r['line_range'][1]])for r in context))
reused=load(root/'reused-context-inventory.json')
check('eight earlier context identities reused separately',len(reused)==8 and all(match(root/r['current_artifact'],r)for r in reused))
historical=load(root/'historical-inventory.json')
for item in historical:
    p=root/'historical'/item['name'];m=load(p/'manifest.json')
    check('original physical package '+item['name'],match(p/'manifest.json',item['manifest'])and all(match(p/r['path'],r)for r in item['artifacts'])and {str(q.relative_to(p))for q in p.rglob('*')if q.is_file()}=={r['path']for r in item['artifacts']})
    check('original payloads '+item['name'],all(match(p/'files'/r['path'],r)for r in m['files']))
    if 'patch_sha256' in m:
        check('original bases '+item['name'],all(match(p/'base'/r['path'],{'bytes':r['base_bytes'],'sha256':r['base_sha256']})for r in m['files']))
        check('original patch and runner '+item['name'],match(p/'candidate.patch',{'bytes':m['patch_bytes'],'sha256':m['patch_sha256']})and ident(p/'run_candidate_probe.py')['sha256']==m['runner_sha256'])
        patches=[];valid=True
        for r in m['files']:
            pb=(p/r.get('patch_file','patches/'+r['path'].replace('/','__')+'.patch')).read_bytes();patches.append(pb)
            base=(p/'base'/r['path']).read_bytes();target=(p/'files'/r['path']).read_bytes()
            try: valid &= hashlib.sha256(pb).hexdigest()==r['patch_sha256']and apply_data(base,pb)==target and apply_data(target,pb,True)==base
            except (AssertionError,ValueError): valid=False
        check('all memory forward reverse patches '+item['name'],valid)
        check('combined patch equals constituent sequence '+item['name'],b''.join(patches)==(p/'candidate.patch').read_bytes())
    else:
        check('current-map original artifact table',all(match(p/n,r)for n,r in m['artifacts'].items()))
        target=(p/'files'/report).read_bytes();prior=(p/'files/Docs/quality/stage1/ZS1-029/worker-current-map320/prior-report.md').read_bytes()
        for name,base in [('candidate.patch',b''),('append-existing-report.patch',prior)]:
            pb=(p/name).read_bytes()
            check('current-map memory forward reverse '+name,apply_data(base,pb)==target and apply_data(target,pb,True)==base)
beh=root/'historical/source029-behavior-ready';reuse=root/'historical/source029-reuse320-ready';current=root/'historical/source029-current-map320-ready'
reuse_e=reuse/'files/Docs/quality/stage1/ZS1-029/worker-reuse320';current_e=current/'files/Docs/quality/stage1/ZS1-029/worker-current-map320'
check('report prefix chain exact',(reuse/'files'/report).read_bytes().startswith((beh/'files'/report).read_bytes())and(current/'files'/report).read_bytes().startswith((reuse/'files'/report).read_bytes()))
for package in [beh,reuse]:
    nested=current_e/'reused'/package.name
    check('current-map nested prior package exact '+package.name,all((nested/r['path']).read_bytes()==(package/r['path']).read_bytes()for r in next(x for x in historical if x['name']==package.name)['artifacts']))
for name,p,manifest,chunks,base in [('reuse320',reuse_e,'input-manifest.json','ordered_complete_read_chunks',reuse/'files'),('current-map320',current_e,'input-manifest.json','chunks',current_e)]:
    im=load(p/manifest);cursor=0;ok=True
    for r in im[chunks]:
        x,y=r['byte_start'],r['byte_end'];payload=(base/r['artifact']).read_bytes()
        ok &= x==cursor and src[x:y]==payload and hashlib.sha256(payload).hexdigest()==r['sha256'];cursor=y
    check('historical complete reading exact '+name,ok and cursor==62416 and im['sha256']==hashlib.sha256(src).hexdigest())
probe=beh/'files/Docs/quality/stage1/ZS1-029/worker-source-probe'
check('11 behavior artifacts exact across revisions',all((beh/'files'/r['path']).read_bytes()==(reuse/'files'/r['path']).read_bytes() for r in load(beh/'manifest.json')['files']if r['path']!=report))
check('actual probe identity',match(probe/'probe.ts',{'bytes':11700,'sha256':'24b10046c6b517ba6aa43299815c00fd22a0b1b928afb1b64c9c9f247d30b1a6'}))
for name in ['source-native','target-chat']:
    receipt=load(probe/(name+'.json'))
    check('historical command receipt '+name,receipt['exit_code']==0 and receipt['started_at'].startswith('2026-09-10')and match(probe/(name+'.log'),receipt))
obs=load(probe/'source-native.log')
check('historical33 cases37 requests',len(obs['scenarios'])==33 and all(r['status']=='pass'for r in obs['scenarios'])and obs['http_requests']==37 and obs['mocked_imports']==[] and obs['sdk']=='openai@6.40.0')
lock=load(probe/'package-lock.json')['packages']
check('historical pinned SDK/parser',lock['node_modules/openai']['version']=='6.40.0'and lock['node_modules/partial-json']['version']=='0.1.7')
check('historical8 target passes','8 passed; 0 failed' in (probe/'target-chat.log').read_text())
later=[]
for name,count in [('worker-reasoning-replay/acceptance-reviewed',15),('worker-json-strict/joint-final',20),('worker-contract318/prescribed108',22)]:
    p=reuse_e/'historical/Docs/quality/stage1/ZS1-108'/name;r=load(p.with_suffix('.json'));log=p.with_suffix('.log')
    # Select only the stage1_chat_stream section; do not count unrelated suites.
    sections=re.split(r'(?=     Running tests/)',log.read_text());selected=[s for s in sections if s.startswith('     Running tests/stage1_chat_stream.rs')]
    check('later historical Chat receipt '+name,r['exit_code']==0 and match(log,r)and len(selected)==1 and f'{count} passed; 0 failed' in selected[0])
    later.append({'receipt':str(p.with_suffix('.json').relative_to(root)),'chat_tests':count})
for name in ['integrity-final','integrity-reviewed']:
    r=load(reuse_e/(name+'.json'))
    check('historical integrity preserved '+name,match(reuse_e/(name+'.log'),r)and r['exit_code']==(1 if name=='integrity-final'else 0))
check('core drift failure retained','AssertionError: /Users/wangweiyang/GitHub/zenpi/src/core.rs' in (reuse_e/'integrity-final.log').read_text()and(reuse_e/'target-references-initial.json').is_file()and(reuse_e/'target-drift-review.json').is_file())
for name,p in [('reuse320',reuse_e/'gstage-main'),('current-map320',current_e/'commands/gstage-current-main')]:
    r=load(p.with_suffix('.json'));log=load(p.with_suffix('.log'))
    check('G-STAGE original failure '+name,r['exit_code']==1 and match(p.with_suffix('.log'),r)and log['structural']['ok']and 'ZS1-029.master.json' in json.dumps(log))
refs=load(current_e/'target-references.json')
check('five current target identities match prior mapping',len(refs)==5 and all(match(root/'target'/r['relative_path'],r)for r in refs))
check('15 prior mapping excerpts exact',sum(len(r['excerpts'])for r in refs)==15 and all((root/'target'/r['relative_path']).read_bytes()[e['byte_start']:e['byte_end']]==(current_e/e['artifact']).read_bytes()and match(current_e/e['artifact'],e)for r in refs for e in r['excerpts']))
check('current22 Chat definitions',(root/'target/tests/stage1_chat_stream.rs').read_text().count('#[test]')==22)
for r in load(current_e/'dependency-identities.json'):
    rel=str(Path(r['source']).relative_to('/Users/wangweiyang/GitHub/pi-mono'))
    check('previous dependency identity '+rel,match(root/'source'/rel,r))
authority=root/'authority';a=load(authority/'Docs/execution/active_requirement.json')
check('3.1.21 authority baseline',a['blueprint_version']=='3.1.21'and a['requirement_digest']=='3456abcbbebbc4e0ab383c319851b0a6e71b19ee9b3c060a6e212f61a89c9d9d'and a['baseline_snapshot_sha256']=='92b06c4b1dcdca7614d226ce5f41205646a9e63967789d2b6ed4ee272d240884'and a['run_id']=='zenpi-stage1-20260911')
for name in ['source_manifest.tsv','file_learn_index.tsv']:
    selected=[r for r in rows(authority/'Docs/learn/stage1_pi_mono'/name)if r['item_id']=='ZS1-029']
    check('029 only source/report binding '+name,len(selected)==1 and selected[0]['source_path']==source and selected[0]['source_hash']==hashlib.sha256(src).hexdigest()and selected[0]['target_artifact']==report and selected[0]['status']=='[ ]')
check('only029 authored candidate',[str(p.relative_to(root/'files'))for p in(root/'files').rglob('*')if p.is_file()]==[report]and(root/'files'/report).read_bytes()==(root/'report-body.md').read_bytes())
if(root/'authority-scope-observation.json').exists():
    obs=load(root/'authority-scope-observation.json')
    check('initial and final authority captures retained',all(match(root/'authority'/r['path'],r['initial'])and match(root/'authority-final'/r['path'],r['final'])for r in obs))
    final_a=load(root/'authority-final/Docs/execution/active_requirement.json')
    check('final captured029 authority scope stable',all(a[k]==final_a[k]for k in ['blueprint_version','requirement_digest','baseline_snapshot_sha256','run_id'])and next(l for l in(root/'authority/Docs/stage_1_v3_pi_mono_blueprint.md').read_text().splitlines()if '**ZS1-029**'in l)==next(l for l in(root/'authority-final/Docs/stage_1_v3_pi_mono_blueprint.md').read_text().splitlines()if '**ZS1-029**'in l))
if live:
    check('live relevant source/context unchanged',all(match(Path(r['origin']),r)for r in inputs if r['kind']!='authority'))
    check('earlier context original artifacts unchanged',all(match(Path(r['prior_package'])/r['prior_artifact'],r)and match(Path(r['prior_package'])/'manifest.json',r['prior_manifest'])for r in reused))
    master=Path('/Users/wangweiyang/GitHub/zenpi');la=load(master/'Docs/execution/active_requirement.json')
    check('live requirement relevant keys',all(a[k]==la[k]for k in ['blueprint_version','requirement_digest','baseline_snapshot_sha256','run_id']))
    def selected(p):return next(l for l in p.read_text().splitlines()if '**ZS1-029**'in l)
    check('029 scoped blueprint unchanged',selected(master/'Docs/stage_1_v3_pi_mono_blueprint.md')==selected(authority/'Docs/stage_1_v3_pi_mono_blueprint.md'))
    for name in ['source_manifest.tsv','file_learn_index.tsv']:
        p='Docs/learn/stage1_pi_mono/'+name
        check('029 live scoped row '+name,[r for r in rows(master/p)if r['item_id']=='ZS1-029']==[r for r in rows(authority/p)if r['item_id']=='ZS1-029'])
    old=load(root/'old-ready-inventory.json')
    check('5813 original ready files unchanged',len(old)==5813 and all(match(Path(p),r)for p,r in old.items()))
if(root/'manifest.json').exists():
    m=load(root/'manifest.json');check('ready payload hashes',all(match(root/r['path'],r)for r in m['files']));check('ready exact file set',{str(p.relative_to(root))for p in root.rglob('*')if p.is_file()}=={'manifest.json'}|{r['path']for r in m['files']})
result={'schema':'zs1-029-independent-offline/v1','passed':all(r['passed']for r in checks),'checks':checks,'mode':'live scoped and portable'if live else'portable only','runtime_executions_this_round':0,'candidate':ident(root/'files'/report),'historical_receipts':later,'scope':'029 complete file only; unrelated status/Gantt not gates; no old script/product execution or master acceptance'}
print(json.dumps(result,ensure_ascii=False,indent=2));sys.exit(0 if result['passed']else 1)
