# ZS1-029 / SRC-0306 — packages/ai/src/api/openai-completions.ts

Status [_], independent worker source candidate. Authority 3.1.13 / 154a7e902cc3752e90396868b419c71adaab1414b7652bbc22c6c2125e489be2. Source SHA 5874bf0b121db117bd4eba8fffa750252f5f7617f38306c6eb1f746575896319, 62416 bytes, 1717 lines. No preexisting report was found in this worktree or main Docs/learn/.ops inventory. The source was read completely in ordered contiguous chunks 1–290, 291–580, 581–870, 871–1150, 1151–1435, 1436–1717, after 017 was frozen. All source bytes are unchanged. This file is independently reviewed; no sibling/directory acceptance follows.

## Complete behavior review

1–290: Runtime SDK plus local cost/clamping, stream, JSON repair, identity hash, retry, headers, schema/grammar, message conversion helpers. Auth accepts explicit API key or nonempty authorization/cf gateway header; missing auth fails. Tool-history and deferred-tool helpers gather tools by name. Runtime reasoning-detail validator accepts text/summary/encrypted variants with common metadata shape; structured signature parsing falls back to legacy encrypted tool signature. Consecutive text/summary details merge, encrypted entries remain discrete. These are replay metadata, not visible deltas. Options include full compatible toolChoice and thinking budgets.

291–580: Cache defaults short with scoped env override. Stream creates a live mutable AssistantMessage, resolves provider/url compat and grammar tools, creates actual SDK client, builds params, invokes onPayload, then establishes stream through shared retry helper with SDK retries disabled. onResponse runs before start. Separate text/thinking blocks and tool maps by index/ID accept late identity. Tool content order is first-seen order; custom tools turn raw grammar input into incremental JSON string properties. finishBlock strips scratch data and emits block completion. Each chunk records first response ID and differing serving model, reads top-level or choice-level usage, consumes first choice only and records finish reason.

581–870: Visible text and first nonempty reasoning_content/reasoning/reasoning_text alias emit separate deltas, preventing double counting. opencode-go rewrites reasoning signature label for replay. Tool deltas accumulate partial repaired JSON or custom input; unknown grammar tool gets an input fallback field. Valid reasoning_details merge into an opaque serialized signature on finalization. After upstream iteration, all blocks finish BEFORE final error/abort/missing-reason checks; a consumer must not treat source toolcall_end as whole-response success. Explicit supportsFinishReason=false permits EOF inference. Catch strips scratch buffers, preserves partial content/signatures, records error/aborted and includes provider metadata once. streamSimple checks auth synchronously, clamps requested thinking level, then delegates. SDK client merges User-Agent/model, optional Copilot, affinity and request headers; custom fetch supported. Request converts messages, sets stream/usage/store/token caps/temperature/tools/toolChoice and starts compat-specific thinking assembly.

871–1150: Full thinking formats: zai, qwen, qwen-chat-template, chat-template, baseten, deepseek, openrouter, ant-ling, together, string-thinking and ordinary OpenAI. Mapped null/missing/off semantics differ by branch. Shared token budget leaves answer room and optional provider field applies independently of format. Routing objects and Vercel preferences are payload data. samplingParams applies last and can overwrite named fields. Template variables resolve enabled/effort/budget and omitWhenOff. Anthropic-style cache markers mutate converted instruction, last tool and last text-bearing conversation part; long retention includes 1h TTL.

1151–1435: Message conversion handles Responses pipe IDs with short deterministic hash for long names; transformMessages only normalizes cross-model identities. Reasoning-capable models may use developer role; compatibility can insert synthetic assistant bridges after tool results. Users include text and image data URLs. Assistant ordinary text joins into a plain string, thinking uses a known original alias, structured details, or plain-text compatibility. Tool replay is function JSON or raw custom grammar input. Legacy encrypted signature replay remains accepted; optional empty reasoning_content supports selected proxies. Assistant messages with no visible content/tool call are dropped even if reasoning details alone exist. Tool results use text/placeholders, optional name, collect images separately and gather Kimi deferred names.

1436–1717: Grouped result images create a subsequent user message; Kimi can inject system tool declarations. convertTools emits native custom grammar or function JSON schema with strict opt-in/unsupported handling. Usage picks cache-read aliases, separates cache writes, floors normal input at zero, includes reasoning inside output once, and computes cost. Stops: stop/end, length, function_call/tool_calls are mapped; filtered/network/unknown are errors. URL/provider heuristics choose store, roles, token field, reasoning format/support, strict schema, affinity and caching; explicit model.compat overrides defaults per field. This broad compatibility adapter does not bound accumulated stream/frame/tool JSON bytes.

## Executed source behavior

`Docs/quality/stage1/ZS1-029/worker-source-probe/probe.ts` runs 33 independent behavior cases through unchanged source and actual pinned openai 6.40.0 plus partial-json 0.1.7, with 37 private loopback HTTP requests carrying deterministic SSE bytes. No imported implementation, SDK, parser or client is mocked. NODE_PATH resolves dependencies installed only in .ops/source029-runtime; package.json/package-lock/install.log are retained. Before/after source SHA matches. This is a runnable fixture against actual implementation, not a replacement model or schema-field count.

Assertions cover path/auth/developer/token/usage requests, response callback, first-nonempty reasoning alias, response/serving model/first choice, interleaved indices and late IDs, repaired partial tool JSON, early block finish followed by terminal error, explicit EOF fallback, clean EOF with finish reason, seven extra finish mappings, usage aliases/reasoning accounting, structured reasoning-detail merge/replay, sampling and payload changes, all eleven thinking formats, simple effort clamp/shared token budget, explicit compatibility overrides/header auth, empty-tools history and unique cross-protocol IDs, cache/affinity/routing, missing auth/preabort. No failures in this probe. Fixture uses immediate deterministic responses; this report does not claim source in-flight DNS/connect cancellation, provider retry outage handling, real service compatibility, tsc, or the complete upstream Vitest suite. Located upstream retry/thinking/details/cache/tool-choice/ID tests are reference inventory only, not claimed read/executed. Native custom grammar, image-result and Kimi loader branches were fully read but are not claimed independently executed here.

## Exact zenpi owner mapping and differences

Current source hashes and owner snapshot hashes are in owner-hashes.json. `src/backend/chat_stream.rs` Stream::event:60 owns strict SSE state; finish:204 validates all arguments/identity/terminal before publishing TextDone/ToolCallDone/Completed; read:265 bounds 256 KiB frames and total response bytes and polls cancellation. It orders tools by index through BTreeMap, requires unique bounded ID/name and object JSON, rejects extra choices/nonzero choice index, changed response/model identity, unsupported custom tools and choice data after terminal. finish_reason must match tool presence. stop/tool_calls can succeed; length is incomplete failure, whereas source exposes length as a successful terminal result. Both implementations allow clean EOF after a complete final-reason frame; neither this mapping nor tests claim DONE is mandatory.

`src/backend.rs` request assembly Chat branch:1059, streamed dispatch:1333/1344 and existing attachment/policy/model checks own actual request/HTTP behavior. `src/providers/registry.rs` exact model×wire intersection and `src/core.rs` canonical session/tool owner prevent provider output from bypassing tool gates. `tests/stage1_chat_stream.rs` rerun covers first delta before terminal, interleaved tools, malformed/truncated streams, split UTF-8/multiline SSE, reasoning view block, oversized frame, actual production headless JSONL and midstream cancel/closed socket. target-chat.json/log gives exact command/result. Main has later shared event-output changes; candidate changes only this report/evidence and main must revalidate its integrated owner.

Intentional narrowing and unfinished parity: target rejects partial JSON repair/EOF-inferred stop and delays executable tool completion; source is more permissive and may emit toolcall_end before final error. Source keeps first identity even if later chunks differ, target rejects changes. Source consumes first choice and orders by first appearance, target rejects multi-choice and orders by tool index. Target supports function tools and a bounded request subset rather than eleven vendor thinking formats, arbitrary sampling overrides, schema grammar/Kimi deferred tools or auto-detected provider routing/caching. Target currently handles reasoning_content and reasoning, not source reasoning_text/structured reasoning_details replay; if reasoning_content is present but empty its fallback differs from source's first-nonempty selection. These gaps are not advertised as equivalent. Source cost/alias accounting is broader than target's Usage record. Signed Anthropic/Google history uses existing host metadata and cannot be silently translated by this Chat path. Cross-platform debt remains: macOS shared transport has actual cancellation proof; non-macOS hostname DNS and non-Unix connect still need implementations and native-host validation. No unsupported parity or all-platform pass is claimed.

## Side effects, recovery and acceptance

The source mutates request-local assistant/stream buffers, invokes caller callbacks, performs SDK HTTP and generates compatibility payloads; it does not persist sessions. Abort/error returns partial message and terminal error; callers own durable history/retry/restart. Target session persistence, replay and tool approvals remain existing Agent/session owners. Test SDK installations and owned loopback servers are isolated; HOME/CODEX_HOME remain inherited. No source/native production edits or new release binary budget were needed. G-FILE/G-STAGE master acceptance and directory closure are not claimed. Status remains [_].

## 3.1.20 完整单文件复核与当前 Chat owner 补充（worker candidate [_]）

当前合同为 3.1.20 / `8d525b351d066ce9b0487a485337647d47233275782e4f4d154423a623fe1645`。原报告 10771 字节、SHA `ebdf9a3c3a3233f13aab7335f94145c419109cc2cf2532f8722b9ae7b4488d53` 保留为完整前缀；上文属于当时版本的 target gap/test 描述，以下当前映射替代其过时部分。只复核 ZS1-029，不处理 028，不授予目录或产品 108 验收。

再次完整顺序阅读冻结源码 1717 行 / 62416 字节，SHA `5874bf0b121db117bd4eba8fffa750252f5f7617f38306c6eb1f746575896319`。行 1–290、291–580、581–870、871–1150、1151–1435、1436–1717 对应半开字节区间 `[0,9725)`、`[9725,19881)`、`[19881,30064)`、`[30064,41177)`、`[41177,51523)`、`[51523,62416)`。`worker-reuse320/input-manifest.json` 和原始片段绑定所有字节，无间隙/重叠；不以符号索引代替阅读。imports/auth、reasoning validators、stream 与 catch、全部 thinking/cache/compat 分支、message/tool 转换、usage/stop mapping 和文件尾均覆盖。

### 源端流、reasoning、工具与终止边界

`stream` 创建并返回可消费 stream，异步任务维护同一个 mutable output；事件的 partial 引用不是独立不可变快照。先构造兼容参数、await onPayload（可替换整个 params），再通过 SDK 建立请求，await onResponse，最后才发布 start。onPayload/onResponse 自身失败进入外层 catch；它们不是共享 retry 的组成部分。`streamSimple` 缺 auth 同步抛错，直接 stream 的错误则作为 error 事件。auth precheck 看 options.apiKey 或 options.headers 中非空 Authorization/cf-aig-authorization；不能仅凭 model.headers 已含凭据推断此 precheck 一定通过。

文本、thinking 与 tool block 按首次出现顺序加入 output.content。一次 chunk 先处理文本，再取 `reasoning_content → reasoning → reasoning_text` 首个非空字符串，避免多个 alias 重复累计；thinking block 只创建一次，首次使用的 alias 作为原始 signature 标签，opencode-go 的 reasoning 改记 reasoning_content。后续 alias 改变不重新创建 block。reasoning_details 独立于可见 thinking_delta：有效 text/summary/encrypted 条目进入内存元数据，最终 JSON 序列化到 thinkingSignature。连续同类型 text/summary 直接合并，即使 id/index 不同也不按它们分组；补齐缺字段，encrypted 原样分开。validator 检查已知字段形状、保留其他字段、跳过无效条目；不验证服务商签名真实性，也不是完整封闭 schema。

Tool delta（490–547、630–657）先按 numeric index 找 block，再按 truthy id 查；两者都缺或未命中会新建。name/id 仅在空时补入，但新的 id 仍可更新 map 别名；这里不验证 identity 始终一致、index 非负整数、最终 name/id 唯一或参数必须 object。函数 arguments 逐段拼接并调用 parseStreamingJson，partial JSON 可被修复；identity-only delta 也可发出空字符串 toolcall_delta。custom grammar 分支转为一个字符串参数属性，未知工具 fallback 为 input；收到 custom delta 时可转换并清掉原 partialArgs。源 adapter 不执行工具，SDK 类型声明与上层 tool gate 不能算成本文件自身校验。

正常结束 for-await 后（675–696）先逐 block 发 text_end/thinking_end/toolcall_end 并剥离 scratch，再检查 signal、error stop reason 和缺失 finish_reason。因此这些 block-end 不是整响应成功许可。迭代本身抛错直接进入 catch，不保证每块都收到 end。catch 保留 partial content、reasoning metadata 并剥 scratch，按 signal 决定 aborted/error，发送 error 后 end；不写 journal、不撤回已见 deltas。解析/累计没有本文件统一 frame/response/tool-JSON 大小上限。

finish_reason 只在 truthy 时记录；`mapStopReason(null)` 的分支不会由当前 truthy call site 将 null 当有效终止。stop/end→stop，length→length 并可发 done，function_call/tool_calls→toolUse，不核对工具是否实际存在；filter/network/unknown→error。源端不在首个 finish_reason 后关闭状态或拒绝后续 choice，后续值可覆盖 raw/stop reason；首个 response ID 与首个不同于请求模型的 serving model 保留，未拒绝后续 identity 变化。只消费 choices[0]，不检查额外 choices。默认要求 finish reason；显式 supportsFinishReason=false 才在无 reason 的正常迭代 EOF 按有无 tool 推断结果。旧实测证明完整终止 frame 后干净 EOF 可成功，无需 DONE；不能据此声称 SDK 的任意截断/坏帧都可接受。

### retry、取消与请求兼容层

共享 `retryProviderRequest` 只包 `client.chat.completions.create(...).withResponse()`；SDK maxRetries 明确 0，流迭代错误不会从该调用点重试。辅助文件经本轮只读确认：maxRetries 默认为 0；支持按 x-should-retry、status undefined、408/409/429/5xx 决定请求建立错误是否可重试；Retry-After/Retry-After-ms 与默认 60 秒 server delay 上限、可中断 backoff 由 helper 负责。具体网络阶段取消交由 SDK/fetch；本文件仅向 SDK/retry 传 signal 并在正常迭代尾检查，不自行中断永不返回的 onPayload/onResponse。timeoutMs 传 SDK request，不等于包含用户 callback、整个重试链和所有清理的总 deadline。helper 及 transform-messages.ts 的当前只读快照/哈希在 source-dependency-references.json；没有给依赖单独验收。

旧 33-case run 的 maxRetries 均设 0，只有预先 abort 的用例验证未发 HTTP；它没有覆盖请求建立重试、DNS/connect/midstream abort 或 backoff 时延。不得将源端共享 helper 的实现阅读转换为本轮执行证明。目标已有实际取消证据另有 owner 和原始收据。

buildParams 的十一种 thinking formats、独立 budget、routing、cache、grammar/strict 分支在上文完整描述仍适用。补充限制：simple 才按支持级别 clamp，直接 stream 接收显式 effort；thinking budget 在 samplingParams 之前计算，samplingParams 最后可覆盖已计算字段，onPayload 更可替换整体，不能把早期计算当最终出站不变式。compat 字段逐个 nullish override，不是 URL heuristic 的真实性验证。cache marks 修改的是转换后的请求结构；此处不实现服务端缓存保证。

### 签名与跨模型回放

`convertMessages`（1178–1468）先调用真实 transformMessages。原报告“only normalizes cross-model identities”不足以描述该依赖：它同时归一 null content、降级无视觉模型的图片、按 provider/api/model 三者判定同模型；跨模型将非空普通 thinking 转文本、丢 redacted thinking 与 tool thoughtSignature，并正规化 tool ID/后续 result ID。它跳过 error/aborted assistant，并对缺失 tool result 合成错误占位消息。这里只表示 adapter 生成请求历史，并不执行 tool，也不是服务商认可的签名迁移。

同模型 thinkingSignature 的第一个有效非空 structured-details 数组优先于各 tool 上的 legacy encrypted detail；选中的数组回放到 reasoning_details。无 structured details 时，首个非空 thinking block 的合法 alias 标签控制 reasoning 字段；requiresThinkingAsText 则把其当文本，不能认为所有 thinking 都保留原格式。只有 reasoning metadata、没有 content/tool_calls 的 assistant 最后仍会被跳过。签名 JSON 形状通过不代表它与可见文本、工具参数绑定，更无加密验签操作；输入 opaque 字节只按兼容规则保存/去除。Responses `call|item` 转短 ID 的 hash 仅用于长度/区分，普通超长 ID 截断及哈希本身均非数学上的无碰撞保证；正规化 callback 只用于跨模型路径。

### 当前 Zenpi Chat adapter 映射

当前只读 owner 哈希与 15 个映射片段在 target-references.json；主仓 core/backend/chat/test 四个文件相对旧 029 已变化，registry 未变化。不声明完整审查这五个目标文件，也不以旧 8 pass 代替当前测试。

| 主题 | 当前已实现与源端差异 |
| --- | --- |
| Reasoning 差距已更新 | chat_stream.rs 当前 SHA `80da76080a8ccc6d54a7c7369804513c0a4371601c4e9b62a9805571471a07ba`，已经支持三个 alias 的首个非空优先级、opencode-go 映射、text/summary 合并、encrypted 离散保存以及 JSON fallback。旧“无 reasoning_text/details/空首字段 fallback 不同”结论已过时。 |
| 严格边界 | 当前 Reasoning 对所有出现的 alias 检查类型，details 非数组/无效条目直接失败，限制 128 条、64 KiB；源跳过部分无效值/条目。它先保留可见 delta，只有成功终止才发布 replay annotation。两者不是无条件等价。 |
| Replay owner | 主机生成 native_history/chat_reasoning，包含 wire/provider/model 与 SHA-256 tuple digest；读取时限制 role、重复数、大小、字段和相同 provider/model/wire，摘要不匹配即拒绝。digest 是无密钥的一致性检查，覆盖 reasoning tuple，不是服务商签名认证，也不绑定整个 assistant 文本/tool transcript。可见 reasoning 或 digest 不授权工具执行。 |
| 工具流终止 | Stream 按 u64 index BTreeMap 排序，最多 128 tool calls，ID/name 不可变且有界、唯一，最终 arguments 要严格可解析 object。先完成整组校验及 reasoning annotation 再发 ready tools/Completed；length/filter、缺 reason、reason 与工具存在性不匹配均失败。源 first-seen order、partial JSON repair、length done 和 permissive identities 是保留差异。 |
| EOF 与 DONE | 256 KiB frame、总 MAX_RESPONSE_BYTES 限制、partial frame EOF 失败；干净 EOF 只要已完成有效 reason 可成功。DONE 前必须有 reason，同一已读取 chunk 中 DONE 后数据会被拒绝；read 在完成当前 chunk 后若 done 则停止再读，不能宣称一定检测尚未读取到的所有尾随字节。 |
| 取消与 retry | read 的 sink wrapper 在每个发布事件前检查取消，能够在 TextDone 或首个 ToolCallDone 触发取消后抑制后续 ready/Completed；已发布事件不能撤回。backend 的 retry 仅在当前 attempt 尚未 emitted、错误可重试、有剩余次数且非 semantic_compaction 时启用；流有可观察事件后不重发。前置/中途网络关闭由独立 transport owner 提供，本轮没有网络实验或跨平台新验证。 |
| JSON fallback | backend.rs 当前 SHA `d11105597a7e4260c67c9ce7796394687b4219617a6ebfdfeca637ae469c3357`，非 SSE 响应走 bounded JSON body + validate_json，严格检查唯一 choice/index/终止状态和工具全集，拒绝保留字段伪造后才发布事件；逐事件取消也存在。这是当前实际分支，不是旧源 SDK SSE 测试证明。 |
| 请求与 session | backend Chat 构建 function tools、system instructions、max_completion_tokens 等受限请求，不自动实现源十一 vendor thinking formats/任意 sampling/grammar/Kimi/cache routing。chat_message 回放 host reasoning history，validate_history_model 提前拒绝不匹配；registry 做 model×wire capability 交集。core:3478 保存 completion annotations，3878 保存工具轮 annotations，再由 SessionStore 持久化。历史恢复/工具 gate 属于这些 owner，源 adapter 不持久化。 |
| Usage | 目标仍是 input/output/total 三项 Usage；源 cache-read 多别名、cache-write、reasoning 与 cost 字段更广。reasoning 不能再加到已含 reasoning 的 completion_tokens 上。此处没有改写目标计费实现。 |

目标历史证据按版本分开：旧 029 target-chat 为 8 pass；后续 reasoning-ready 有 15 个 Chat 用例；JSON-strict 的联合日志包含当时 20 个 Chat 用例；contract318 的 prescribed108 中有 22 个 Chat 用例（全组三个目标 38 pass）。这些原收据分别保留于 historical/，没有相加成独立覆盖数，也没有标成当前主树新通过。当前 chat_stream.rs 与测试文件匹配 cancel318 冻结哈希，backend.rs 匹配 JSON-strict 冻结哈希；core 已继续变化，因此仍需主审判断整合范围。当前测试 owner 明确包含 alias/details 回放、坏 metadata/跨模型预先拒绝、journal restart、实际 headless 取消与 JSON fallback、终端回调取消两例；本轮只读相关片段，不重跑。

### 复用真实性、复验与交付范围

旧 `.ops/source029-behavior-ready/manifest.json` SHA `56e2e684a31171db291b193d330e394da6a5351316a5391fdac34bc8d775a713`，12 文件逐字节校验；source-native 实际 exit 0，33 个场景全 pass、37 次私有 127.0.0.1 HTTP 请求，日志 SHA `b29b0e1048b4fdfebd4074a6035addfa7ed07c89bd1b9b80ebfda27cce9b1bf2`。使用真实 pinned openai 6.40.0、partial-json 0.1.7 和未改 source；无 imported-module/client/parser mock，服务端 SSE 全部为即时确定性 fixture。case 名称中的 onPayload “without forced stream”仅实际断言新增 top_p/采样覆盖，没有测试改成 stream:false；reasoning_details case 断言相邻 text 与 encrypted，并未穷举所有 summary/legacy/custom/image/Kimi分支。上文全面分支阅读不得冒充更多运行场景。

精确纯完整性入口：在 worker 根运行 `PYTHONDONTWRITEBYTECODE=1 python3 Docs/quality/stage1/ZS1-029/worker-reuse320/verify_reuse.py`，校验完整阅读范围、报告前缀、旧包/日志、当前目标及两个依赖锚点，调用真实 G-FILE 校验函数。目标哈希后续变化应提示重新审查，不自动更新为新通过。

可选独立源复演入口为 `PYTHONDONTWRITEBYTECODE=1 python3 Docs/quality/stage1/ZS1-029/worker-reuse320/replay_source_bounded.py`。要求已有 Bun 与 `.ops/source029-runtime/node_modules`；使用原 probe/source 哈希，设置 NODE_PATH，保留 HOME/CODEX_HOME，运行只监听私有 loopback 的既有 probe，最多 10 秒运行及 2 秒清理，保留最多 64 KiB 合并输出。不安装依赖、不连接真实模型服务；该 wrapper 本轮仅 AST 语法检查，未运行。原准确命令和版本/lock 仍在 worker-source-probe 下。新 runtime/Bun/Cargo/HTTP 实验次数为 0。

G-STAGE 主仓只读原结果单独保存；缺主审收据仍是失败，不由完整性检查替代语义验收。候选仅新增报告补充和证据，不改主库/Pi/清单、不创建任务、不处理 028、不恢复停止的深度工作。023 及全部既有 frozen ready 包保持不变。

冻结前校验补记：首轮 integrity-final 真实 exit 1，因为主仓 core.rs 已从 `6a881cc8eb1193dfbe4d4b06e71d6d28b3b78f4fe00bc836c1ea74c2f2c60b63` 更新为 `52311b129c0bb467abac36de216f5bc97bf3c4c42d03dcd6170a717339c2a869`（278737 字节、6869 行）。重新阅读 3450–3510、3850–3910；两个 annotation 保存映射片段的原位置与字节均未变化。旧 target-references-initial.json、失败收据和 target-drift-review.json 保留，当前锚点只在此有限复核后更新；不宣称审查 core 其他变化或运行当前目标测试。修订后的纯完整性收据另存 integrity-reviewed。


---

## 3.1.20 当前映射复核：冻结源码不变、五个目标身份不变

本轮是 ZS1-029 / SRC-0306 的单文件理解候选，等待主控独立语义审查；不更新蓝图状态。完整保留上方 25992 字节旧报告，前缀 SHA-256 `aaf79c93fafc908ca776c4fdc249e45eea1c170f2874ef22612f8f48585ff2c7`。首轮及上次补充中的历史执行时间、原失败和未覆盖声明继续有效，不把报告中的候选 `[_]` 当作主库状态。

当前蓝图的唯一源路径为 `packages/ai/src/api/openai-completions.ts`，唯一标准报告为本文件，L1、依赖 ZS1-001；G-FILE 要求完整内容、接口/状态/错误/副作用及目标映射，不由 hash 或编译代替。G-STAGE 按 `--item ZS1-029` 单独执行；目录闭包及 028/108 等其它项均不在本轮接受。requirement digest `8d525b351d066ce9b0487a485337647d47233275782e4f4d154423a623fe1645`。

本轮再次连续读完 1717 行 / 62416 字节，摘要仍为 `5874bf0b121db117bd4eba8fffa750252f5f7617f38306c6eb1f746575896319`。本次实际阅读分段为 1–280、281–560、561–850、851–1130、1131–1420、1421–1717；各段字节区间、原始片段、SHA 和捕获 UTC 见 `Docs/quality/stage1/ZS1-029/worker-current-map320/input-manifest.json`。六段首尾连接、无遗漏、无重叠；下列索引是读完后的语义核对，不替代全文阅读。

### 全文件函数、类型及分支复核

| 源行 | 函数/接口范围 | 本轮语义结论与证据强度 |
|---|---|---|
|1–162|imports、hasHeader/getClientApiKey、tool history/deferred name lookup、四类 content guards、reasoning detail validators|鉴权前检接受显式 key 或 options 非空 authorization/cf-aig-authorization；header 名不区分大小写，空/null 值不算。deferred names 用 Set，按工具 name 查找时忽略不存在项。detail 校验已知 type/字段形状而不验签。auth/history 有历史案例；deferred 工具全分支仅源码复核。|
|163–300|options、resolved compat、cache 类型、reasoning detail 三分支、签名解析/合并、alias guard|完整类型定义读过；JSON signature 必须非空合法数组，legacy encrypted 额外要求非空 id/data。仅相邻同型 text/summary 合并，encrypted 独立；缺公共字段补齐。类型声明不等于所有入站 JSON 都被严格校验。text/encrypted 历史实测；summary/legacy 形状分支不扩写为新实测。|
|301–310|resolveCacheRetention|显式 cacheRetention 优先，否则 scoped env 的 PI_CACHE_RETENTION=long，最后 short；实际服务端缓存效果不由该函数保证。|
|311–547|stream 初始化、onPayload/request retry/onResponse、StreamingToolCallBlock 与局部 ensure/finish helpers|先创建请求局部可变 output；onPayload 可整体替换 params；建流 retry 禁用 SDK 内层重试，start 在 onResponse 之后。文本/thinking 单块，工具 index/id map，先出现先入 content。custom input 缓冲增量 JSON 字符串属性，未知工具 fallback=input，最终剥离 scratch。历史案例只覆盖函数工具及回调部分，custom 分支是源码理解。|
|548–674|完整 chunk fold|先记录首个 responseId/不同 serving model，优先 chunk usage、否则首 choice usage；只看首 choice。记录 truthy finish_reason 后仍处理该 delta。文本与 reasoning 分流，三个 alias 首非空；工具增量拼接并 partial JSON 修复；reasoning_details 合并进 replay metadata，不变成可见 detail delta。历史 text/reasoning/tool/usage 有实际断言，类型异常和全部组合不宣称覆盖。|
|675–724|block finish、终止检查、catch/end|正常迭代结束先发各 block-end，再查 abort/error/缺 reason；只在显式 compat 不要求 reason 时推断 EOF stop/toolUse。catch 保留 partial 与 reasoning signature、删临时字段、规范化错误，raw metadata 未出现才追加；error 和 done 互斥终止流。历史缺 reason、预 abort、finish mapping 已实测；中途网络与 callback 悬挂没有源实测。|
|726–790|streamSimple、createClient|simple 缺 auth 同步抛错并 clamp reasoning，直接 stream 的错误由异步 catch 发事件。客户端 headers 的覆盖顺序为 User-Agent/model、Copilot、session affinity、options；可注入 fetch。headers 允许范围与服务商鉴权成功不是同一结论。|
|792–995|buildParams 全部参数分支|convertMessages→cache key/retention→stream usage/store/token/temperature→工具/deferred history→cache marks/toolChoice/priority→thinking/budget→routing→最后 samplingParams。onPayload 又位于此函数之后，故“早期参数合法”不能当最终出站不变式。历史 enabled-format/部分 override/cache 有实测；全部 off/null 分支仅源码复核。|
|997–1060|budget field、answer-room clamp、template build/resolve|显式 budget field 优先兼容布尔开关；只有 reasoning enabled 才计算，max_tokens 优先 max_completion_tokens 再 model.maxTokens。模板支持 enabled/budget/effort，omitWhenOff 可去除字段；解析结果为空则不设模板对象。实际 clamp 的一个边界历史实测，未穷举所有预算输入。|
|1062–1176|getCompatCacheControl、apply 与全部 addCacheControl helpers|只有 anthropic 格式且 retention 非 none 才设 ephemeral；long 且支持才加 1h TTL。标记首 system/developer、最后 tool、最后可标记 user/assistant/tool 文本；string 转单文本数组，空 string 无标记，数组逆向找最后 text。它修改转换后的请求结构，不写持久化缓存。|
|1178–1468|convertMessages 及局部 normalizeToolCallId|完整 user/text/image、assistant thinking/tool/legacy signature、相邻 tool results 图片组合、synthetic bridge、Kimi system tools 分支读过。调用 transformMessages 的语义沿用既有独立上下文；本文件自身并不执行工具或存 session。跨协议短 ID 的有限历史案例不等于无碰撞数学保证。|
|1470–1505|convertTools|按 helper 结果生成 native custom grammar，或 function JSON schema；strict 只在兼容支持时携带，默认 false，schema 修整交 helper。未运行 grammar/strict helper 全套测试。|
|1507–1574|parseChunkUsage、mapStopReason|cache-read 三处优先级、独立 writes、input floor、reasoning 子集、cost 调用；stop/end、length、function_call/tool_calls、filter/network/unknown 各分支明确。历史用例未断言每个成本数字，也未把 null helper 分支当有效 finish frame。|
|1581–1717|detectCompat、getCompat|按 provider/baseUrl 子串推导默认能力，再逐字段 nullish override；包含 tokens、roles、store、reasoning、strict、cache/affinity、routing/template、deferred/priority。只说明兼容启发式，不证明域名身份或远程服务支持；显式 false 可覆盖默认，undefined/null 多处回落默认。读到文件末尾。|

### 参数、终止与 usage 的精确补充

buildParams 的十一种 thinking 格式有不同关闭语义，历史高强度 enabled 请求不能覆盖所有关闭分支：zai 用 enabled/disabled 且启用时 clear_thinking=false；qwen 用 enable_thinking 布尔；qwen-chat-template 同时设置 preserve_thinking；chat-template/baseten 解析各自模板对象；deepseek 在 off 映射不是 null 时发 disabled；openrouter/string-thinking 在 off 映射不是 null 时默认 none；ant-ling 只有显式请求且映射为 string 才发 nested effort；together 发 enabled 布尔；普通 OpenAI off 仅在 off 映射为 string 时写 reasoning_effort。各分支 supportsReasoningEffort、映射 undefined/null 的具体处理不同，不能用统一赋值模型替代。budget 字段独立于 thinkingFormat，samplingParams 最后覆盖及 onPayload 整体替换仍保留。

源端 stop/end→stop，length→length 并允许 done，function_call/tool_calls→toolUse；content_filter/network_error/未知值→error。只有 truthy finish_reason 才调用映射，null 不建立终止证据。后续 choice 仍可能覆盖 stopReason/rawStopReason；没有像目标那样在首终止 reason 后拒绝后续 choice。block-end 在最终 error 之前可见，消费端必须等整个响应完成再决定可执行工具；这不等于源 adapter 自身执行了工具或绕过审批。

源 usage 以最新收到的一份值替换 output.usage，非累加每个 chunk。chunk.usage 存在时优先，choice.usage 只在前者不存在时回落；cacheRead 优先 prompt_tokens_details.cached_tokens，再 prompt_cache_hit_tokens，再 cached_tokens，nullish 优先级保留显式 0；cacheWrite 单独取值。普通 input=max(0,prompt-cacheRead-cacheWrite)，output=completion_tokens，reasoning_tokens 是 output 子集不再加一次，total=input+output+cacheRead+cacheWrite，最后调用 calculateCost。源码未在此提供严格的非负/有限数值完整验证；上游字段异常的所有数值情形未执行，不能将 TS 类型当运行时保证。

### 当前目标映射及保持的差异

本轮重新绑定五个必要目标文件的整文件身份，并读取 15 个精确映射片段。五者都与上轮 source029-reuse320-ready 的最终锚点相同，因此没有“目标变化已修复”的新增结论。保存全文件 hash 仅用于身份；片段复核不代表 backend、core、registry 或测试 owner 的整文件验收，也不扩展到 transport/模型的完整实现。

| 目标 | 当前 SHA-256 | 所选片段说明 |
|---|---|---|
|src/backend/chat_stream.rs|`80da76080a8ccc6d54a7c7369804513c0a4371601c4e9b62a9805571471a07ba`|reasoning 校验/annotation、同模型 history、bind/completed_call、JSON 校验、SSE fold/finish/read。|
|src/backend.rs|`d11105597a7e4260c67c9ce7796394687b4219617a6ebfdfeca637ae469c3357`|Chat 请求、token/format、SSE/JSON 分派、history 预检、retry、chat_message、usage。|
|src/providers/registry.rs|`cf229a62681933e7c1b4058c4d2fada41dff4fcd05c4cd300e18accfe245b944`|模型能力与 wire 能力交集、reasoning effort 检查片段。|
|src/core.rs|`52311b129c0bb467abac36de216f5bc97bf3c4c42d03dcd6170a717339c2a869`|普通 completion 和 tool turn 的 annotations 保存位置。|
|tests/stage1_chat_stream.rs|`39710fa209ec83b3de359b9574c08b4b8ae1740aff2c93c3925df256829223f3`|alias 选取测试输入、TextDone/首 ToolCallDone 触发取消的两段完整测试。只读，未重跑。|

1. **流式文本/reasoning。** 目标已经有 reasoning_content→reasoning→reasoning_text 首非空规则与 opencode-go 回放映射，旧首轮报告缺少第三 alias 的差距仍属过时结论。目标检查所有出现 alias 的类型，拒绝错误 details，而源跳过部分无效值；目标 64 KiB/128 details 边界仍在。细节 metadata 的 tuple 摘要用于一致性检查，不是供应商签名认证，更不是工具授权。
2. **工具与终止。** 目标要求 u64 index、最多 128 calls，BTreeMap 按 index 顺序；ID/name 不得中途改变且有界、唯一；最终参数必须严格 object JSON，整个工具集合完成校验再发布 ready。只接受与有无工具匹配的 stop/tool_calls；length/filter/缺失或未知 reason 失败。源 first-seen 顺序、可修复 partial JSON、length done 和 permissive identity 保持明确差异。
3. **EOF 与截断。** 目标按 frame/总 response 上限检查、拒绝未结束 SSE frame；clean EOF 在有效 finish reason 后可成功。DONE 是可选尾标志而非成功唯一依据；已读 chunk 中 DONE 后数据可被拒绝，读循环在完成该 chunk 后停止，不能声称检测所有尚未读取字节。源端 SDK 的 framing 由依赖提供，本文件没有同类显式统一字节上限；本轮不运行它的网络或 SDK 截断边界。
4. **取消与重试。** 目标 sink wrapper 在每次事件前检查取消，终端 callback 取消后可抑制后续 ready/Completed，但已发布事件不能撤回。backend 仅在 attempt 没有 emitted、错误可重试且次数允许、非 semantic_compaction 时重试；有事件后不重发。源 retry 只包建流请求、SDK maxRetries=0；迭代错误不经该 retry 点重来。源 callback 的任意挂起不被此文件主动打断。运输层 DNS/connect/跨平台清理结论沿用原证据限制，不从本轮片段推导新的平台通过。
5. **JSON fallback 与请求。** 目标非 SSE 分支使用有界 JSON body、唯一 choice 和终止/工具集校验，reasoning.fold/annotate 后逐事件取消；源码参考的流入口只处理 SDK streaming 结果，不把两条分支视为同一已测试实现。目标请求仍以 function tools/system/max_completion_tokens 等受限映射为主，没有自动继承源十一格式、任意 sampling、grammar/Kimi、affinity/cache/routing 全集合。
6. **历史与持久化。** 目标拒绝跨 provider/model/wire 的 native Chat history、不匹配 tuple 摘要、错误 role/重复 envelope；chat_message 调 replay。core 所选两处保存 annotations，后续 session/tool gate 仍由原 owner 承担。源端不持久化，跨模型 transformMessages 的降级和工具结果补齐规则属于历史已读依赖上下文；本轮仅比较其身份，未重新接受整个依赖。
7. **usage。** 目标 parse_usage 保留 input/output/total 三项，读取 prompt/input、completion/output 别名及显式 total，缺 total 才饱和相加；源 cache-read/write、reasoning、cost 更丰富。输入“普通非缓存 tokens”与“含缓存 prompt tokens”并非同一统计口径，不能只比较字段名称宣称计费完全等价。

### 历史实测与本轮行为执行严格分开

完整旧 source029-behavior-ready（12 payload / 39 常规文件）与 source029-reuse320-ready（63 payload / 192 常规文件）保留在本轮 reused/ 中。原 manifest 分别为 `56e2e684a31171db291b193d330e394da6a5351316a5391fdac34bc8d775a713` 和 `5e5b1205149292a7b72962df100502069ae8fd3a816c041c28523d292ccd7b9c`；不重写原收据、旧失败或历史版本。

本轮完整读过历史 probe.ts 的 36 行 / 11700 字节，并核对 source-native 原收据：2026-09-10T19:47:19Z，exit 0，33 个 scenario、37 次实际私有 loopback SDK HTTP 请求，log SHA-256 `b29b0e1048b4fdfebd4074a6035addfa7ed07c89bd1b9b80ebfda27cce9b1bf2`；实际导入冻结源码、openai@6.40.0 和 partial-json，mocked_imports=[]。本轮未执行 probe、未启动 loopback 服务、未安装依赖或运行 Node/Bun。

历史断言覆盖请求 path/header/developer/token/usage option、onResponse header、首 alias、首 identity/choice、交错工具和 late ID、partial JSON repair、缺 reason 后 block-end、EOF fallback、七种额外 stop mapping、usage 多位置、text/encrypted detail 合并/回放、sampling/部分 onPayload、十一 enabled-format、一个 simple clamp、显式 compat/header auth、两个短 Responses ID、cache/affinity/routing、缺 auth 与预 abort。保持以下范围修正：

- 名为“onPayload replaces without forced stream”的案例只新增 top_p 并断言 sampling 覆盖，未设置 stream:false；不能宣称这种 SDK 返回类型变化已经实测。
- 名为“IDs normalize without collisions”的案例只验证两个具体短 pipe ID 不相同，未证明长 ID 截断/hash 不可能碰撞。
- 十一种 format 各验证一个 enabled/high 请求字段，不代表 off/null/全部 flag 组合、真实厂商 endpoint 可用。
- usage 案例断言 cacheRead、output、total 和一个 choice fallback，不穷举所有 cost、异常数值与 cache-write 极端组合。
- 全部源请求 maxRetries=0；预 abort 不发 HTTP 不能替代 in-flight DNS/connect/中途流/backoff 取消。
- custom grammar、图片结果、Kimi deferred、summary/legacy 全分支、onPayload/onResponse 失败或挂起、完整上游 Vitest/tsc 均无本轮运行证据。

旧 029 目标 8 pass，以及后续 reasoning/JSON/cancel 历史收据保留原始范围；它们不是本轮当前源码新通过，也不相加制造覆盖数量。上次因 core.rs 摘要变化产生的 integrity-final exit 1 与 log SHA-256 `26529ee882790d6f280e8191489cf30e5cb35537354b88dea51f37452bb057b6` 原样保留；后续有限片段复核及 integrity-reviewed 的修订记录也全部保留。本轮五个目标 hash 已与该最终版本匹配，没有再次“修复”那个历史失败。

本轮新增产品/源行为运行数 **0**：Cargo、PTY、HTTP、网络、源 Node/Bun、真实 provider、测试 runtime 均为 **0**。仅进行只读 G-STAGE、G-FILE 的源码/区间/产物结构组件校验及离线包/补丁完整性校验；结构通过不等于语义接受。

### 接收、门禁和回退

本轮实际只读 G-STAGE --item ZS1-029 退出 1，structural.ok=true，缺少主库 `Docs/learn/stage1_pi_mono/receipts/ZS1-029.master.json`；原始日志 SHA-256 `a50371e0fb52fe2c463c9ee3718ec51b1dc7126970edf4f60a6137ebfe186877`，不补写主控 receipt、不隐藏非零。主库标准报告在捕获时仍不存在；本轮提供唯一标准报告的 absent 接收补丁和旧前缀追加补丁，两者择一，均不改产品。完整证据另在新目录随 manifest 交付。

离线 verifier 不执行历史收据中的命令，不调用源运行器，也不重跑测试。它校验完整 source/分块、旧报告前缀、原包和历史原日志、当前目标片段身份记录、失败保留及标准报告两个基线的正逆 apply/check。源码/目标身份一旦后续变化，主控需再次审阅关联范围，不能从旧 checksum 自动得到新验收。回退只撤回本次报告候选与新增证据；Pi、主库产品、旧 ready、状态和其它报告保持不变。
