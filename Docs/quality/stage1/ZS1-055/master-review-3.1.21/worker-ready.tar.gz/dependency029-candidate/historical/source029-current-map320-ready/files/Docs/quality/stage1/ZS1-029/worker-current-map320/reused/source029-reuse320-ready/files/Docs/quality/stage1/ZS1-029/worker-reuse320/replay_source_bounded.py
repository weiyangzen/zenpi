"""Optional independent replay, not executed for this evidence-reuse supplement."""
from pathlib import Path
import hashlib,json,os,selectors,shutil,signal,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[5]
SOURCE=Path('/Users/wangweiyang/GitHub/pi-mono/packages/ai/src/api/openai-completions.ts')
PROBE=ROOT/'Docs/quality/stage1/ZS1-029/worker-source-probe/probe.ts'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(SOURCE.read_bytes())=='5874bf0b121db117bd4eba8fffa750252f5f7617f38306c6eb1f746575896319'
assert sha(PROBE.read_bytes())=='24b10046c6b517ba6aa43299815c00fd22a0b1b928afb1b64c9c9f247d30b1a6'
bun=shutil.which('bun');assert bun,'Bun must already be available on PATH; this script does not install it'
assert os.name=='posix','Process-group supervisor requires POSIX'
runtime=ROOT/'.ops/source029-runtime/node_modules';assert runtime.is_dir(),'Existing isolated dependencies required'
started=time.monotonic();deadline=started+10.0;output=bytearray();reason='completed';status=None
child=subprocess.Popen([bun,str(PROBE)],cwd=ROOT,env={**os.environ,'NODE_PATH':str(runtime)},stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True)
sel=selectors.DefaultSelector();os.set_blocking(child.stdout.fileno(),False);sel.register(child.stdout,selectors.EVENT_READ);eof=False
try:
 while not (eof and child.poll() is not None):
  if time.monotonic()>=deadline:reason='timeout';break
  for key,_ in sel.select(min(0.05,max(0.0,deadline-time.monotonic()))):
   chunk=os.read(key.fileobj.fileno(),min(8192,65537-len(output)))
   if not chunk:sel.unregister(key.fileobj);eof=True;continue
   output.extend(chunk)
   if len(output)>65536:reason='output_limit';break
  if reason!='completed':break
 status=child.poll()
finally:
 if reason!='completed' or child.poll() is None:
  try:os.killpg(child.pid,signal.SIGKILL)
  except ProcessLookupError:pass
 try:status=child.wait(timeout=2)
 except subprocess.TimeoutExpired:reason='cleanup_timeout';status=126
 child.stdout.close();sel.close()
sys.stdout.buffer.write(output[:65536]);sys.stdout.buffer.flush()
assert sha(SOURCE.read_bytes())=='5874bf0b121db117bd4eba8fffa750252f5f7617f38306c6eb1f746575896319'
code=124 if reason=='timeout' else 125 if reason=='output_limit' else 126 if reason=='cleanup_timeout' else status
print(json.dumps({'optional_replay':True,'reason':reason,'exit_code':code,'child_exit_code':status,'elapsed_seconds':time.monotonic()-started,'output_bytes_captured':min(len(output),65536),'output_sha256':sha(output[:65536]),'HOME_preserved':True,'CODEX_HOME_preserved':True,'bounds':'10 seconds execution plus at most 2 seconds direct-child cleanup; 64 KiB retained output'}),file=sys.stderr)
raise SystemExit(code)
