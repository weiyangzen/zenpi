"""Offline verification; no source runtime, stored-command execution, network, or product tests."""
from pathlib import Path
import argparse,hashlib,json,os,stat,subprocess
args=argparse.ArgumentParser();args.add_argument('--scratch',type=Path,required=True);options=args.parse_args()
root=Path(__file__).resolve().parent;EV='Docs/quality/stage1/ZS1-029/worker-current-map320';E=root/'files'/EV
def info(p):
    b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def inventory(p):
    out={}
    for directory,dirs,files in os.walk(p,followlinks=False):
        dirs[:]=[n for n in dirs if not Path(directory,n).is_symlink()]
        for n in files:
            q=Path(directory,n)
            if stat.S_ISREG(q.lstat().st_mode):out[str(q.relative_to(p))]=info(q)
    return out
m=json.loads((root/'manifest.json').read_text());assert m['item']=='ZS1-029' and m['status']=='[_]' and m['product_paths']==[] and m['new_behavior_runs']==0
actual=inventory(root);actual.pop('manifest.json');assert actual==m['artifacts']
for row in m['files']:assert info(root/'files'/row['path'])=={k:row[k] for k in ['bytes','sha256']}
s=json.loads((E/'input-manifest.json').read_text());source=(E/'openai-completions.ts').read_bytes();assert info(E/'openai-completions.ts')=={k:s[k] for k in ['bytes','sha256']}
assert s['sha256']=='5874bf0b121db117bd4eba8fffa750252f5f7617f38306c6eb1f746575896319' and len(source.splitlines())==1717
offset=0;line=1;joined=[]
for part in s['chunks']:
    data=(E/part['artifact']).read_bytes();assert part['byte_start']==offset and part['lines'][0]==line
    assert data==source[part['byte_start']:part['byte_end']] and info(E/part['artifact'])=={k:part[k] for k in ['bytes','sha256']}
    assert len(data.splitlines())==part['lines'][1]-part['lines'][0]+1
    joined.append(data);offset=part['byte_end'];line=part['lines'][1]+1
assert b''.join(joined)==source and offset==62416 and line==1718
REPORT=s['owned_report'];report=(root/'files'/REPORT).read_bytes();prior=(E/'prior-report.md').read_bytes();assert len(prior)==25992 and report.startswith(prior) and len(report)>len(prior) and info(E/'prior-report.md')==s['report_prefix']
preserved=json.loads((E/'preservation-before.json').read_text())
for row in json.loads((E/'reused-packages.json').read_text()):
    copied=E/row['artifact'];old=json.loads((copied/'manifest.json').read_text())
    assert info(copied/'manifest.json')['sha256']==row['manifest_sha256'] and inventory(copied)==preserved['ready'][row['source']]
    for member in old['files']:assert info(copied/'files'/member['path'])=={k:member[k] for k in ['bytes','sha256']}
behavior=E/'reused/source029-behavior-ready/files/Docs/quality/stage1/ZS1-029/worker-source-probe'
reuse=E/'reused/source029-reuse320-ready/files/Docs/quality/stage1/ZS1-029/worker-reuse320'
def receipt(folder,name,exit_code):
    record=json.loads((folder/f'{name}.json').read_text());p=folder/f'{name}.log';assert record['exit_code']==exit_code and info(p)==dict(bytes=record['bytes'],sha256=record['sha256']);return p
raw=json.loads(receipt(behavior,'source-native',0).read_text());assert len(raw['scenarios'])==33 and all(x['status']=='pass' for x in raw['scenarios']) and raw['http_requests']==37 and raw['mocked_imports']==[] and raw['source_sha256']==s['sha256']
assert '8 passed; 0 failed' in receipt(behavior,'target-chat',0).read_text()
assert 'src/core.rs' in receipt(reuse,'integrity-final',1).read_text();receipt(reuse,'integrity-reviewed',0)
hist=reuse/'historical/Docs/quality/stage1/ZS1-108'
for folder,name in [('worker-reasoning-replay','acceptance-reviewed'),('worker-json-strict','joint-final'),('worker-contract318','prescribed108')]:receipt(hist/folder,name,0)
oldrefs={r['relative_path']:r for r in json.loads((reuse/'target-references.json').read_text())};count=0
for row in json.loads((E/'target-references.json').read_text()):
    assert row['same_as_previous'] and row['sha256']==row['previous_sha256']==oldrefs[row['relative_path']]['sha256']
    for part in row['excerpts']:
        assert info(E/part['artifact'])=={k:part[k] for k in ['bytes','sha256']};count+=1
assert count==15
for row in json.loads((E/'dependency-identities.json').read_text()):assert row['same_as_previous'] and row['sha256']==row['previous_sha256']
g=json.loads(receipt(E/'commands','gstage-current-main',1).read_text());assert g['structural']['ok'] and not g['ok'] and any('ZS1-029.master.json' in error for error in g['errors'])
f=json.loads(receipt(E/'commands','file-structure-current',0).read_text());assert f['passed'] and f['new_behavior_runs']==0 and f['report_sha256']==info(root/'files'/REPORT)['sha256']
assert json.loads((E/'preservation-result.json').read_text())['passed']
scratch=options.scratch.resolve();assert not scratch.exists() and not scratch.is_relative_to(root);scratch.mkdir(parents=True);operations=[]
for label,patch,before in [('main-absent','candidate.patch',None),('prior-report','append-existing-report.patch',prior)]:
    work=scratch/label;work.mkdir();p=work/REPORT;p.parent.mkdir(parents=True)
    if before is not None:p.write_bytes(before)
    sentinel=work/'unrelated-sentinel';sentinel.write_bytes(b'preserve\x00\r\n')
    subprocess.run(['git','init','--quiet'],cwd=work,check=True,capture_output=True)
    stats=subprocess.run(['git','apply','--numstat',str(root/patch)],cwd=work,check=True,capture_output=True,text=True).stdout.splitlines();assert len(stats)==1 and stats[0].split('\t')[2]==REPORT
    for phase,flags in [('forward-check',['--check']),('forward',[]),('reverse-check',['--reverse','--check']),('reverse',['--reverse'])]:
        if phase=='reverse-check':assert p.read_bytes()==report
        result=subprocess.run(['git','apply',*flags,str(root/patch)],cwd=work,capture_output=True);assert result.returncode==0,result.stderr
        operations.append(dict(baseline=label,phase=phase,exit_code=0));assert sentinel.read_bytes()==b'preserve\x00\r\n'
    assert (not p.exists()) if before is None else p.read_bytes()==before
print(json.dumps(dict(passed=True,item='ZS1-029',manifest_sha256=info(root/'manifest.json')['sha256'],artifacts=len(actual),source=info(E/'openai-completions.ts'),source_lines=1717,report=info(root/'files'/REPORT),target_excerpts=count,historical_source_cases=33,historical_source_HTTP_requests=37,new_behavior_runs=0,gstage_exit_preserved=1,semantic_acceptance=False,patch_operations=operations),indent=2))
