from pathlib import Path
import difflib,hashlib,json,os,shutil,stat
W=Path(__file__).resolve().parent;R=W.parents[1];E=W/'files/Docs/quality/stage1/ZS1-029/worker-current-map320'
def info(p):
    b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def inventory(root):
    out={}
    for directory,dirs,files in os.walk(root,followlinks=False):
        dirs[:]=[n for n in dirs if not Path(directory,n).is_symlink()]
        for n in files:
            p=Path(directory,n)
            if stat.S_ISREG(p.lstat().st_mode):out[str(p.relative_to(root))]=info(p)
    return out
def dump(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
baseline=json.loads((W/'preservation-before.json').read_text())
for path,expected in baseline['ready'].items():assert inventory(Path(path))==expected,path
for path,expected in baseline['tracked'].items():assert info(Path(path))==expected,path
s=json.loads((E/'input-manifest.json').read_text());assert info(Path(s['source']))=={k:s[k] for k in ['bytes','sha256']}
for row in json.loads((E/'target-references.json').read_text()):assert info(Path(row['source']))=={k:row[k] for k in ['bytes','sha256']}
assert not (Path('/Users/wangweiyang/GitHub/zenpi')/s['owned_report']).exists()
shutil.copyfile(W/'preservation-before.json',E/'preservation-before.json')
dump(E/'preservation-result.json',dict(passed=True,ready_packages=len(baseline['ready']),ready_regular_files=sum(map(len,baseline['ready'].values())),tracked_regular_files=len(baseline['tracked']),source_unchanged=True,target_files_unchanged=True,main_report_still_absent=True,method='regular-file sets and SHA-256; FIFO never opened'))
for p in (W/'commands').iterdir():
    q=E/'commands'/p.name;q.parent.mkdir(exist_ok=True);shutil.copyfile(p,q)
ready=R/'.ops/source029-current-map320-ready';ready.mkdir()
for rel in inventory(W/'files'):
    p=ready/'files'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(W/'files'/rel,p)
for name in ['verify.py','prepare.py','freeze.py','append.md','check-live.py']:shutil.copyfile(W/name,ready/name)
shutil.copyfile(R/'.ops/run_candidate_probe.py',ready/'run_candidate_probe.py')
REPORT=s['owned_report'];prior=(E/'prior-report.md').read_bytes();after=(W/'files'/REPORT).read_bytes();assert after.startswith(prior)
for name,before in [('candidate.patch',b''),('append-existing-report.patch',prior)]:
    patch=''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+REPORT if before else '/dev/null',tofile='b/'+REPORT)).encode();assert len(patch)<256*1024;(ready/name).write_bytes(patch)
files=[dict(path=rel,**record) for rel,record in inventory(ready/'files').items()]
manifest=dict(item='ZS1-029',status='[_]',authority_version='3.1.20',authority_digest=s['authority_digest'],source={k:s[k] for k in ['source','source_path','bytes','sha256','lines']},owned_report=REPORT,report_prefix=s['report_prefix'],main_base_exists=False,product_paths=[],new_behavior_runs=0,historical_source_cases=33,historical_source_HTTP_requests=37,source_Node_runs=0,Cargo_runs=0,PTY_runs=0,HTTP_runs=0,network_runs=0,gstage_exit_code=1,semantic_acceptance=False,files=files,artifacts=inventory(ready))
dump(ready/'manifest.json',manifest)
print(json.dumps(dict(ready=str(ready),manifest=info(ready/'manifest.json'),report=info(ready/'files'/REPORT),report_lines=len(after.splitlines()),candidate_patch=info(ready/'candidate.patch'),append_patch=info(ready/'append-existing-report.patch'),files=len(files),artifacts=len(manifest['artifacts'])),indent=2))
