

---

## 3.1.20 当前映射复核：冻结源码不变、五个目标身份不变

本轮是 ZS1-029 / SRC-0306 的单文件理解候选，等待主控独立语义审查；不更新蓝图状态。完整保留上方 25992 字节旧报告，前缀 SHA-256 `aaf79c93fafc908ca776c4fdc249e45eea1c170f2874ef22612f8f48585ff2c7`。首轮及上次补充中的历史执行时间、原失败和未覆盖声明继续有效，不把报告中的候选 `[_]` 当作主库状态。

当前蓝图的唯一源路径为 `packages/ai/src/api/openai-completions.ts`，唯一标准报告为本文件，L1、依赖 ZS1-001；G-FILE 要求完整内容、接口/状态/错误/副作用及目标映射，不由 hash 或编译代替。G-STAGE 按 `--item ZS1-029` 单独执行；目录闭包及 028/108 等其它项均不在本轮接受。requirement digest `8d525b351d066ce9b0487a485337647d47233275782e4f4d154423a623fe1645`。

本轮再次连续读完 1717 行 / 62416 字节，摘要仍为 `5874bf0b121db117bd4eba8fffa750252f5f7617f38306c6eb1f746575896319`。本次实际阅读分段为 1–280、281–560、561–850、851–1130、1131–1420、1421–1717；各段字节区间、原始片段、SHA 和捕获 UTC 见 `Docs/quality/stage1/ZS1-029/worker-current-map320/input-manifest.json`。六段首尾连接、无遗漏、无重叠；下列索引是读完后的语义核对，不替代全文阅读。

### 全文件函数、类型及分支复核

| 源行 | 函数/接口范围 | 本轮语义结论与证据强度 |
|---|---|---|
|1–162|imports、hasHeader/getClientApiKey、tool history/deferred name lookup、四类 content guards、reasoning detail validators|鉴权前检接受显式 key 或 options 非空 authorization/cf-aig-authorization；header 名不区分大小写，空/null 值不算。deferred names 用 Set，按工具 name 查找时忽略不存在项。detail 校验已知 type/字段形状而不验签。auth/history 有历史案例；deferred 工具全分支仅源码复核。|
|163–300|options、resolved compat、cache 类型、reasoning detail 三分支、签名解析/合并、alias guard|完整类型定义读过；JSON signature 必须非空合法数组，legacy encrypted 额外要求非空 id/data。仅相邻同型 text/summary 合并，encrypted 独立；缺公共字段补齐。类型声明不等于所有入站 JSON 都被严格校验。text/encrypted 历史实测；summary/legacy 形状分支不扩写为新实测。|
|301–310|resolveCacheRetention|显式 cacheRetention 优先，否则 scoped env 的 PI_CACHE_RETENTION=long，最后 short；实际服务端缓存效果不由该函数保证。|
|311–547|stream 初始化、onPayload/request retry/onResponse、StreamingToolCallBlock 与局部 ensure/finish helpers|先创建请求局部可变 output；onPayload 可整体替换 params；建流 retry 禁用 SDK 内层重试，start 在 onResponse 之后。文本/thinking 单块，工具 index/id map，先出现先入 content。custom input 缓冲增量 JSON 字符串属性，未知工具 fallback=input，最终剥离 scratch。历史案例只覆盖函数工具及回调部分，custom 分支是源码理解。|
|548–674|完整 chunk fold|先记录首个 responseId/不同 serving model，优先 chunk usage、否则首 choice usage；只看首 choice。记录 truthy finish_reason 后仍处理该 delta。文本与 reasoning 分流，三个 alias 首非空；工具增量拼接并 partial JSON 修复；reasoning_details 合并进 replay metadata，不变成可见 detail delta。历史 text/reasoning/tool/usage 有实际断言，类型异常和全部组合不宣称覆盖。|
|675–724|block finish、终止检查、catch/end|正常迭代结束先发各 block-end，再查 abort/error/缺 reason；只在显式 compat 不要求 reason 时推断 EOF stop/toolUse。catch 保留 partial 与 reasoning signature、删临时字段、规范化错误，raw metadata 未出现才追加；error 和 done 互斥终止流。历史缺 reason、预 abort、finish mapping 已实测；中途网络与 callback 悬挂没有源实测。|
|726–790|streamSimple、createClient|simple 缺 auth 同步抛错并 clamp reasoning，直接 stream 的错误由异步 catch 发事件。客户端 headers 的覆盖顺序为 User-Agent/model、Copilot、session affinity、options；可注入 fetch。headers 允许范围与服务商鉴权成功不是同一结论。|
|792–995|buildParams 全部参数分支|convertMessages→cache key/retention→stream usage/store/token/temperature→工具/deferred history→cache marks/toolChoice/priority→thinking/budget→routing→最后 samplingParams。onPayload 又位于此函数之后，故“早期参数合法”不能当最终出站不变式。历史 enabled-format/部分 override/cache 有实测；全部 off/null 分支仅源码复核。|
|997–1060|budget field、answer-room clamp、template build/resolve|显式 budget field 优先兼容布尔开关；只有 reasoning enabled 才计算，max_tokens 优先 max_completion_tokens 再 model.maxTokens。模板支持 enabled/budget/effort，omitWhenOff 可去除字段；解析结果为空则不设模板对象。实际 clamp 的一个边界历史实测，未穷举所有预算输入。|
|1062–1176|getCompatCacheControl、apply 与全部 addCacheControl helpers|只有 anthropic 格式且 retention 非 none 才设 ephemeral；long 且支持才加 1h TTL。标记首 system/developer、最后 tool、最后可标记 user/assistant/tool 文本；string 转单文本数组，空 string 无标记，数组逆向找最后 text。它修改转换后的请求结构，不写持久化缓存。|
|1178–1468|convertMessages 及局部 normalizeToolCallId|完整 user/text/image、assistant thinking/tool/legacy signature、相邻 tool results 图片组合、synthetic bridge、Kimi system tools 分支读过。调用 transformMessages 的语义沿用既有独立上下文；本文件自身并不执行工具或存 session。跨协议短 ID 的有限历史案例不等于无碰撞数学保证。|
|1470–1505|convertTools|按 helper 结果生成 native custom grammar，或 function JSON schema；strict 只在兼容支持时携带，默认 false，schema 修整交 helper。未运行 grammar/strict helper 全套测试。|
|1507–1574|parseChunkUsage、mapStopReason|cache-read 三处优先级、独立 writes、input floor、reasoning 子集、cost 调用；stop/end、length、function_call/tool_calls、filter/network/unknown 各分支明确。历史用例未断言每个成本数字，也未把 null helper 分支当有效 finish frame。|
|1581–1717|detectCompat、getCompat|按 provider/baseUrl 子串推导默认能力，再逐字段 nullish override；包含 tokens、roles、store、reasoning、strict、cache/affinity、routing/template、deferred/priority。只说明兼容启发式，不证明域名身份或远程服务支持；显式 false 可覆盖默认，undefined/null 多处回落默认。读到文件末尾。|

### 参数、终止与 usage 的精确补充

buildParams 的十一种 thinking 格式有不同关闭语义，历史高强度 enabled 请求不能覆盖所有关闭分支：zai 用 enabled/disabled 且启用时 clear_thinking=false；qwen 用 enable_thinking 布尔；qwen-chat-template 同时设置 preserve_thinking；chat-template/baseten 解析各自模板对象；deepseek 在 off 映射不是 null 时发 disabled；openrouter/string-thinking 在 off 映射不是 null 时默认 none；ant-ling 只有显式请求且映射为 string 才发 nested effort；together 发 enabled 布尔；普通 OpenAI off 仅在 off 映射为 string 时写 reasoning_effort。各分支 supportsReasoningEffort、映射 undefined/null 的具体处理不同，不能用统一赋值模型替代。budget 字段独立于 thinkingFormat，samplingParams 最后覆盖及 onPayload 整体替换仍保留。

源端 stop/end→stop，length→length 并允许 done，function_call/tool_calls→toolUse；content_filter/network_error/未知值→error。只有 truthy finish_reason 才调用映射，null 不建立终止证据。后续 choice 仍可能覆盖 stopReason/rawStopReason；没有像目标那样在首终止 reason 后拒绝后续 choice。block-end 在最终 error 之前可见，消费端必须等整个响应完成再决定可执行工具；这不等于源 adapter 自身执行了工具或绕过审批。

源 usage 以最新收到的一份值替换 output.usage，非累加每个 chunk。chunk.usage 存在时优先，choice.usage 只在前者不存在时回落；cacheRead 优先 prompt_tokens_details.cached_tokens，再 prompt_cache_hit_tokens，再 cached_tokens，nullish 优先级保留显式 0；cacheWrite 单独取值。普通 input=max(0,prompt-cacheRead-cacheWrite)，output=completion_tokens，reasoning_tokens 是 output 子集不再加一次，total=input+output+cacheRead+cacheWrite，最后调用 calculateCost。源码未在此提供严格的非负/有限数值完整验证；上游字段异常的所有数值情形未执行，不能将 TS 类型当运行时保证。

### 当前目标映射及保持的差异

本轮重新绑定五个必要目标文件的整文件身份，并读取 15 个精确映射片段。五者都与上轮 source029-reuse320-ready 的最终锚点相同，因此没有“目标变化已修复”的新增结论。保存全文件 hash 仅用于身份；片段复核不代表 backend、core、registry 或测试 owner 的整文件验收，也不扩展到 transport/模型的完整实现。

| 目标 | 当前 SHA-256 | 所选片段说明 |
|---|---|---|
|src/backend/chat_stream.rs|`80da76080a8ccc6d54a7c7369804513c0a4371601c4e9b62a9805571471a07ba`|reasoning 校验/annotation、同模型 history、bind/completed_call、JSON 校验、SSE fold/finish/read。|
|src/backend.rs|`d11105597a7e4260c67c9ce7796394687b4219617a6ebfdfeca637ae469c3357`|Chat 请求、token/format、SSE/JSON 分派、history 预检、retry、chat_message、usage。|
|src/providers/registry.rs|`cf229a62681933e7c1b4058c4d2fada41dff4fcd05c4cd300e18accfe245b944`|模型能力与 wire 能力交集、reasoning effort 检查片段。|
|src/core.rs|`52311b129c0bb467abac36de216f5bc97bf3c4c42d03dcd6170a717339c2a869`|普通 completion 和 tool turn 的 annotations 保存位置。|
|tests/stage1_chat_stream.rs|`39710fa209ec83b3de359b9574c08b4b8ae1740aff2c93c3925df256829223f3`|alias 选取测试输入、TextDone/首 ToolCallDone 触发取消的两段完整测试。只读，未重跑。|

1. **流式文本/reasoning。** 目标已经有 reasoning_content→reasoning→reasoning_text 首非空规则与 opencode-go 回放映射，旧首轮报告缺少第三 alias 的差距仍属过时结论。目标检查所有出现 alias 的类型，拒绝错误 details，而源跳过部分无效值；目标 64 KiB/128 details 边界仍在。细节 metadata 的 tuple 摘要用于一致性检查，不是供应商签名认证，更不是工具授权。
2. **工具与终止。** 目标要求 u64 index、最多 128 calls，BTreeMap 按 index 顺序；ID/name 不得中途改变且有界、唯一；最终参数必须严格 object JSON，整个工具集合完成校验再发布 ready。只接受与有无工具匹配的 stop/tool_calls；length/filter/缺失或未知 reason 失败。源 first-seen 顺序、可修复 partial JSON、length done 和 permissive identity 保持明确差异。
3. **EOF 与截断。** 目标按 frame/总 response 上限检查、拒绝未结束 SSE frame；clean EOF 在有效 finish reason 后可成功。DONE 是可选尾标志而非成功唯一依据；已读 chunk 中 DONE 后数据可被拒绝，读循环在完成该 chunk 后停止，不能声称检测所有尚未读取字节。源端 SDK 的 framing 由依赖提供，本文件没有同类显式统一字节上限；本轮不运行它的网络或 SDK 截断边界。
4. **取消与重试。** 目标 sink wrapper 在每次事件前检查取消，终端 callback 取消后可抑制后续 ready/Completed，但已发布事件不能撤回。backend 仅在 attempt 没有 emitted、错误可重试且次数允许、非 semantic_compaction 时重试；有事件后不重发。源 retry 只包建流请求、SDK maxRetries=0；迭代错误不经该 retry 点重来。源 callback 的任意挂起不被此文件主动打断。运输层 DNS/connect/跨平台清理结论沿用原证据限制，不从本轮片段推导新的平台通过。
5. **JSON fallback 与请求。** 目标非 SSE 分支使用有界 JSON body、唯一 choice 和终止/工具集校验，reasoning.fold/annotate 后逐事件取消；源码参考的流入口只处理 SDK streaming 结果，不把两条分支视为同一已测试实现。目标请求仍以 function tools/system/max_completion_tokens 等受限映射为主，没有自动继承源十一格式、任意 sampling、grammar/Kimi、affinity/cache/routing 全集合。
6. **历史与持久化。** 目标拒绝跨 provider/model/wire 的 native Chat history、不匹配 tuple 摘要、错误 role/重复 envelope；chat_message 调 replay。core 所选两处保存 annotations，后续 session/tool gate 仍由原 owner 承担。源端不持久化，跨模型 transformMessages 的降级和工具结果补齐规则属于历史已读依赖上下文；本轮仅比较其身份，未重新接受整个依赖。
7. **usage。** 目标 parse_usage 保留 input/output/total 三项，读取 prompt/input、completion/output 别名及显式 total，缺 total 才饱和相加；源 cache-read/write、reasoning、cost 更丰富。输入“普通非缓存 tokens”与“含缓存 prompt tokens”并非同一统计口径，不能只比较字段名称宣称计费完全等价。

### 历史实测与本轮行为执行严格分开

完整旧 source029-behavior-ready（12 payload / 39 常规文件）与 source029-reuse320-ready（63 payload / 192 常规文件）保留在本轮 reused/ 中。原 manifest 分别为 `56e2e684a31171db291b193d330e394da6a5351316a5391fdac34bc8d775a713` 和 `5e5b1205149292a7b72962df100502069ae8fd3a816c041c28523d292ccd7b9c`；不重写原收据、旧失败或历史版本。

本轮完整读过历史 probe.ts 的 36 行 / 11700 字节，并核对 source-native 原收据：2026-09-10T19:47:19Z，exit 0，33 个 scenario、37 次实际私有 loopback SDK HTTP 请求，log SHA-256 `b29b0e1048b4fdfebd4074a6035addfa7ed07c89bd1b9b80ebfda27cce9b1bf2`；实际导入冻结源码、openai@6.40.0 和 partial-json，mocked_imports=[]。本轮未执行 probe、未启动 loopback 服务、未安装依赖或运行 Node/Bun。

历史断言覆盖请求 path/header/developer/token/usage option、onResponse header、首 alias、首 identity/choice、交错工具和 late ID、partial JSON repair、缺 reason 后 block-end、EOF fallback、七种额外 stop mapping、usage 多位置、text/encrypted detail 合并/回放、sampling/部分 onPayload、十一 enabled-format、一个 simple clamp、显式 compat/header auth、两个短 Responses ID、cache/affinity/routing、缺 auth 与预 abort。保持以下范围修正：

- 名为“onPayload replaces without forced stream”的案例只新增 top_p 并断言 sampling 覆盖，未设置 stream:false；不能宣称这种 SDK 返回类型变化已经实测。
- 名为“IDs normalize without collisions”的案例只验证两个具体短 pipe ID 不相同，未证明长 ID 截断/hash 不可能碰撞。
- 十一种 format 各验证一个 enabled/high 请求字段，不代表 off/null/全部 flag 组合、真实厂商 endpoint 可用。
- usage 案例断言 cacheRead、output、total 和一个 choice fallback，不穷举所有 cost、异常数值与 cache-write 极端组合。
- 全部源请求 maxRetries=0；预 abort 不发 HTTP 不能替代 in-flight DNS/connect/中途流/backoff 取消。
- custom grammar、图片结果、Kimi deferred、summary/legacy 全分支、onPayload/onResponse 失败或挂起、完整上游 Vitest/tsc 均无本轮运行证据。

旧 029 目标 8 pass，以及后续 reasoning/JSON/cancel 历史收据保留原始范围；它们不是本轮当前源码新通过，也不相加制造覆盖数量。上次因 core.rs 摘要变化产生的 integrity-final exit 1 与 log SHA-256 `26529ee882790d6f280e8191489cf30e5cb35537354b88dea51f37452bb057b6` 原样保留；后续有限片段复核及 integrity-reviewed 的修订记录也全部保留。本轮五个目标 hash 已与该最终版本匹配，没有再次“修复”那个历史失败。

本轮新增产品/源行为运行数 **0**：Cargo、PTY、HTTP、网络、源 Node/Bun、真实 provider、测试 runtime 均为 **0**。仅进行只读 G-STAGE、G-FILE 的源码/区间/产物结构组件校验及离线包/补丁完整性校验；结构通过不等于语义接受。

### 接收、门禁和回退

本轮实际只读 G-STAGE --item ZS1-029 退出 1，structural.ok=true，缺少主库 `Docs/learn/stage1_pi_mono/receipts/ZS1-029.master.json`；原始日志 SHA-256 `a50371e0fb52fe2c463c9ee3718ec51b1dc7126970edf4f60a6137ebfe186877`，不补写主控 receipt、不隐藏非零。主库标准报告在捕获时仍不存在；本轮提供唯一标准报告的 absent 接收补丁和旧前缀追加补丁，两者择一，均不改产品。完整证据另在新目录随 manifest 交付。

离线 verifier 不执行历史收据中的命令，不调用源运行器，也不重跑测试。它校验完整 source/分块、旧报告前缀、原包和历史原日志、当前目标片段身份记录、失败保留及标准报告两个基线的正逆 apply/check。源码/目标身份一旦后续变化，主控需再次审阅关联范围，不能从旧 checksum 自动得到新验收。回退只撤回本次报告候选与新增证据；Pi、主库产品、旧 ready、状态和其它报告保持不变。
