# ZS1-029 / 3.1.20 evidence reuse supplement

Candidate status [_]. The full 1717-line, 62416-byte source is captured with six contiguous reading chunks. The original 10771-byte report remains an exact prefix; the supplement corrects current reasoning replay, tool completion, cancellation/retry and signature boundaries.

Pure integrity check from this worktree root:

    PYTHONDONTWRITEBYTECODE=1 python3 Docs/quality/stage1/ZS1-029/worker-reuse320/verify_reuse.py

The verifier checks source/ranges, report prefix, all 12 old frozen report/evidence files, nine copied historical target artifacts, current target/dependency hashes and real G-FILE helpers. It starts no runtime fixture. The old source receipt records 33 cases and 37 actual loopback HTTP requests through pinned OpenAI SDK 6.40.0 and partial-json 0.1.7 with no imported module mock. The original target eight passes and later 108 receipts retain their original dates/scopes; none are new target executions.

Optional independent replay (not executed for this supplement):

    PYTHONDONTWRITEBYTECODE=1 python3 Docs/quality/stage1/ZS1-029/worker-reuse320/replay_source_bounded.py

Requires existing Bun and .ops/source029-runtime/node_modules; no install. The wrapper verifies unchanged source/probe hashes, sets NODE_PATH, preserves HOME/CODEX_HOME, bounds execution to 10 seconds plus up to 2 seconds direct-child cleanup and retains at most 64 KiB combined output. It supervises the original private loopback probe in an owned POSIX process group. Only AST syntax is checked here. No new Bun/Cargo/HTTP experiment occurred.

G-STAGE output is retained separately, including a missing master receipt failure. Integrity success is not semantic or directory acceptance. Only report/evidence candidates are delivered; main and Pi sources are read-only.
