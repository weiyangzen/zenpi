from pathlib import Path
import datetime,hashlib,json,os,shutil,stat,subprocess
W=Path(__file__).resolve().parent;R=W.parents[1];M=Path('/Users/wangweiyang/GitHub/zenpi')
REPORT='Docs/learn/stage1_pi_mono/files/packages/ai/src/api/openai-completions.ts_learn.md';EV='Docs/quality/stage1/ZS1-029/worker-current-map320';E=W/'files'/EV
E.mkdir(parents=True)
def info(p):
    b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def dump(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def inventory(root):
    out={}
    for directory,dirs,files in os.walk(root,followlinks=False):
        dirs[:]=[n for n in dirs if not Path(directory,n).is_symlink()]
        for n in files:
            p=Path(directory,n)
            if stat.S_ISREG(p.lstat().st_mode):out[str(p.relative_to(root))]=info(p)
    return out
preserved={str(p):inventory(p) for p in (R/'.ops').iterdir() if p.is_dir() and p.name.endswith('-ready')}
p=R/'.ops/stage125-render-review320/ready';preserved[str(p)]=inventory(p)
tracked={}
for rel in subprocess.check_output(['git','ls-files','-z'],cwd=R).split(b'\0'):
    if rel:
        p=R/os.fsdecode(rel)
        if p.exists() and stat.S_ISREG(p.lstat().st_mode):tracked[str(p)]=info(p)
dump(W/'preservation-before.json',dict(ready=preserved,tracked=tracked))
reused=[]
for name,expected in [('source029-reuse320-ready','5e5b1205149292a7b72962df100502069ae8fd3a816c041c28523d292ccd7b9c'),('source029-behavior-ready','56e2e684a31171db291b193d330e394da6a5351316a5391fdac34bc8d775a713')]:
    root=R/'.ops'/name;assert info(root/'manifest.json')['sha256']==expected;m=json.loads((root/'manifest.json').read_text())
    for row in m['files']:assert info(root/'files'/row['path'])=={k:row[k] for k in ['bytes','sha256']}
    for rel in preserved[str(root)]:
        p=E/'reused'/name/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/rel,p)
    assert inventory(E/'reused'/name)==preserved[str(root)]
    reused.append(dict(source=str(root),artifact='reused/'+name,manifest_sha256=expected,payloads=len(m['files']),regular_files=len(preserved[str(root)])))
dump(E/'reused-packages.json',reused)
prior=R/'.ops/source029-reuse320-ready/files'/REPORT;assert prior.read_bytes()==(R/REPORT).read_bytes();assert info(prior)['sha256']=='aaf79c93fafc908ca776c4fdc249e45eea1c170f2874ef22612f8f48585ff2c7';assert not (M/REPORT).exists();shutil.copyfile(prior,E/'prior-report.md')
selector=json.loads((M/'Docs/execution/active_requirement.json').read_text());assert selector['blueprint_version']=='3.1.20' and selector['requirement_digest']=='8d525b351d066ce9b0487a485337647d47233275782e4f4d154423a623fe1645';dump(E/'active-requirement.json',selector)
source=Path('/Users/wangweiyang/GitHub/pi-mono/packages/ai/src/api/openai-completions.ts');b=source.read_bytes();assert info(source)['sha256']=='5874bf0b121db117bd4eba8fffa750252f5f7617f38306c6eb1f746575896319';shutil.copyfile(source,E/'openai-completions.ts');lines=b.splitlines(keepends=True);chunks=[]
for a,z in [(1,280),(281,560),(561,850),(851,1130),(1131,1420),(1421,1717)]:
    p=E/f'read-{a:04}-{z:04}.txt';p.write_bytes(b''.join(lines[a-1:z]));chunks.append(dict(artifact=p.name,lines=[a,z],byte_start=len(b''.join(lines[:a-1])),byte_end=len(b''.join(lines[:z])),**info(p)))
dump(E/'input-manifest.json',dict(item='ZS1-029',source=str(source),source_path=selector['baseline_files']['ZS1-029']['path'],**info(source),lines=1717,captured_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),chunks=chunks,owned_report=REPORT,report_prefix=info(prior),main_report_exists=False,authority_digest=selector['requirement_digest'],new_behavior_runs=0))
oldrefs=json.loads((R/'.ops/source029-reuse320-ready/files/Docs/quality/stage1/ZS1-029/worker-reuse320/target-references.json').read_text());oldhash={row['relative_path']:row['sha256'] for row in oldrefs}
selection={'src/backend/chat_stream.rs':[(1,188),(190,287),(317,697)],'src/backend.rs':[(1059,1115),(1180,1212),(1342,1434),(1503,1555),(1610,1698),(1750,1798),(2565,2585)],'src/providers/registry.rs':[(66,96)],'src/core.rs':[(3468,3495),(3865,3888)],'tests/stage1_chat_stream.rs':[(389,435),(1390,1454)]}
refs=[]
for rel,ranges in selection.items():
    p=M/rel;b=p.read_bytes();lines=b.splitlines(keepends=True);ex=[]
    for a,z in ranges:
        q=E/'target'/f'{rel.replace("/","_")}-{a}-{z}.txt';q.parent.mkdir(exist_ok=True);q.write_bytes(b''.join(lines[a-1:z]));ex.append(dict(artifact=str(q.relative_to(E)),lines=[a,z],byte_start=len(b''.join(lines[:a-1])),byte_end=len(b''.join(lines[:z])),**info(q)))
    refs.append(dict(source=str(p),relative_path=rel,**info(p),lines=len(lines),previous_sha256=oldhash[rel],same_as_previous=info(p)['sha256']==oldhash[rel],excerpts=ex,captured_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='selected mapping fragments only; not full target owner acceptance'))
assert all(row['same_as_previous'] for row in refs);dump(E/'target-references.json',refs)
dep=[]
for row in json.loads((R/'.ops/source029-reuse320-ready/files/Docs/quality/stage1/ZS1-029/worker-reuse320/source-dependency-references.json').read_text()):
    p=Path(row['path']);dep.append(dict(source=str(p),**info(p),previous_sha256=row['sha256'],same_as_previous=info(p)['sha256']==row['sha256'],scope='identity comparison only; dependency content review remains historical'))
dump(E/'dependency-identities.json',dep)
blueprint=M/'Docs/stage_1_v3_pi_mono_blueprint.md';rows=blueprint.read_bytes().splitlines(keepends=True)
(E/'blueprint-context.txt').write_bytes(b''.join(rows[126:154])+b''.join(rows[180:181]));dump(E/'blueprint-context.json',dict(source=str(blueprint),**info(blueprint),selected_lines=[[127,154],[181,181]],excerpt=info(E/'blueprint-context.txt')))
(W/'commands').mkdir();print(json.dumps(dict(source=info(source),report_prefix=info(prior),reused=reused,targets_unchanged=all(row['same_as_previous'] for row in refs),target_excerpts=sum(len(row['excerpts']) for row in refs),preserved_ready=len(preserved)),indent=2))
