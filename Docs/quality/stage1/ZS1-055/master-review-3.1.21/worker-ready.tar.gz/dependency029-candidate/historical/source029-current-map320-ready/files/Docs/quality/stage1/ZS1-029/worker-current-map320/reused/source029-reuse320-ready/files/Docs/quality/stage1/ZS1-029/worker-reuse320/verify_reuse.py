from pathlib import Path
import ast,hashlib,json,runpy,sys,re
ROOT=Path.cwd();EV=ROOT/'Docs/quality/stage1/ZS1-029/worker-reuse320';MAIN=Path('/Users/wangweiyang/GitHub/zenpi');sha=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((EV/'input-manifest.json').read_text());b=Path(m['source']).read_bytes();assert len(b)==62416 and len(b.splitlines())==1717 and sha(b)==m['sha256']==m['frozen']['sha256'];assert (EV/'openai-completions.ts').read_bytes()==b
parts=[];ranges=[]
for c in m['ordered_complete_read_chunks']:
 d=(ROOT/c['artifact']).read_bytes();assert d==b[c['byte_start']:c['byte_end']] and sha(d)==c['sha256'];parts.append(d);ranges.append([c['byte_start'],c['byte_end']])
assert b''.join(parts)==b
reuse=json.loads((EV/'reused-evidence.json').read_text());pkg=Path(reuse['package']);assert sha((pkg/'manifest.json').read_bytes())==reuse['manifest_sha256']
for r in reuse['records']:
 d=Path(r['path']).read_bytes();assert len(d)==r['bytes'] and sha(d)==r['sha256'],r['path']
for r in reuse['historical_copies']:assert (ROOT/r['artifact']).read_bytes()==(ROOT/r['original']).read_bytes()
old=pkg/'files/Docs/quality/stage1/ZS1-029/worker-source-probe'
for name in ['source-native','target-chat']:
 r=json.loads((old/(name+'.json')).read_text());d=(old/(name+'.log')).read_bytes();assert r['exit_code']==0 and r['bytes']==len(d) and r['sha256']==sha(d)
parsed=json.loads((old/'source-native.log').read_text());assert len(parsed['scenarios'])==33 and all(x['status']=='pass' for x in parsed['scenarios']) and parsed['http_requests']==37 and parsed['mocked_imports']==[]
assert 'mock.module(' not in (old/'probe.ts').read_text()
assert '8 passed; 0 failed' in (old/'target-chat.log').read_text()
hist=EV/'historical/Docs/quality/stage1/ZS1-108'
for folder,name in [('worker-reasoning-replay','acceptance-reviewed'),('worker-json-strict','joint-final'),('worker-contract318','prescribed108')]:
 r=json.loads((hist/folder/(name+'.json')).read_text());d=(hist/folder/(name+'.log')).read_bytes();assert r['exit_code']==0 and r['bytes']==len(d) and r['sha256']==sha(d)
counts=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed', (hist/'worker-contract318/prescribed108.log').read_text());assert sum(int(x[0]) for x in counts)==38 and sum(int(x[1]) for x in counts)==0
assert '22 passed; 0 failed' in (hist/'worker-contract318/prescribed108.log').read_text()
for r in json.loads((EV/'source-dependency-references.json').read_text()):
 d=Path(r['path']).read_bytes();assert len(d)==r['bytes'] and sha(d)==r['sha256'] and d==(ROOT/r['artifact']).read_bytes()
report=ROOT/'Docs/learn/stage1_pi_mono/files/packages/ai/src/api/openai-completions.ts_learn.md';text=report.read_bytes();prior=(EV/'prior-report.md').read_bytes();assert text.startswith(prior) and sha(prior)=='ebdf9a3c3a3233f13aab7335f94145c419109cc2cf2532f8722b9ae7b4488d53'
count=0
for r in json.loads((EV/'target-references.json').read_text()):
 d=Path(r['path']).read_bytes();assert len(d)==r['bytes'] and sha(d)==r['sha256'],r['path']
 for c in r['excerpts']:
  part=(ROOT/c['artifact']).read_bytes();assert part==d[c['byte_start']:c['byte_end']] and sha(part)==c['sha256'];count+=1
ast.parse((EV/'replay_source_bounded.py').read_text()) # Syntax check only; no subprocess is started.
sys.path.insert(0,str(MAIN/'tools'));g=runpy.run_path(str(MAIN/'tools/validate_stage1_blueprint.py'));bp=g['parse']((MAIN/'Docs/stage_1_v3_pi_mono_blueprint.md').read_text());f=bp.files['ZS1-029'];assert f.path==m['source_path'] and f.sha256==m['sha256'] and bp.requirement==m['requirement_digest'];g['check_ranges'](ranges,len(b));g['artifact'](ROOT,{'path':str(report.relative_to(ROOT)),'bytes':len(text),'sha256':sha(text)})
sel=json.loads((MAIN/'Docs/execution/active_requirement.json').read_text());assert sel['blueprint_version']==m['authority'] and sel['requirement_digest']==m['requirement_digest'] and sel['baseline_files']['ZS1-029']==m['frozen']
print(json.dumps({'ok':True,'source_bytes':len(b),'source_lines':1717,'read_ranges':ranges,'reused_manifest_sha256':reuse['manifest_sha256'],'reused_artifacts':len(reuse['records']),'historical_source_cases':33,'historical_source_http_requests':37,'mocked_source_modules':0,'historical_029_target_tests':8,'historical_318_prescribed_tests':38,'historical_318_chat_tests':22,'new_runtime_tests':0,'target_excerpts':count,'bounded_replay':'syntax checked only, not executed','report_bytes':len(text),'report_sha256':sha(text),'checks':'Actual G-FILE source/range/artifact; preserved report prefix; immutable historical evidence/receipts; current target and dependency hashes','not_claimed':'Source in-flight cancellation or retry execution, real provider service, upstream Vitest/tsc, new current target runtime tests, cryptographic signature authenticity, cross-platform cleanup, or master/directory acceptance'},indent=2))
