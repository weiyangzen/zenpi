from pathlib import Path
import hashlib,json,runpy,sys
W=Path(__file__).resolve().parent;M=Path('/Users/wangweiyang/GitHub/zenpi');E=W/'files/Docs/quality/stage1/ZS1-029/worker-current-map320'
sha=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((E/'input-manifest.json').read_text());b=Path(m['source']).read_bytes();assert sha(b)==m['sha256'] and len(b)==m['bytes']
ranges=[]
for c in m['chunks']:
    d=(E/c['artifact']).read_bytes();assert d==b[c['byte_start']:c['byte_end']] and sha(d)==c['sha256'];ranges.append([c['byte_start'],c['byte_end']])
for row in json.loads((E/'target-references.json').read_text()):
    d=Path(row['source']).read_bytes();assert sha(d)==row['sha256'] and len(d)==row['bytes']
    for part in row['excerpts']:assert (E/part['artifact']).read_bytes()==d[part['byte_start']:part['byte_end']]
sys.path.insert(0,str(M/'tools'));g=runpy.run_path(str(M/'tools/validate_stage1_blueprint.py'));bp=g['parse']((M/'Docs/stage_1_v3_pi_mono_blueprint.md').read_text());f=bp.files['ZS1-029']
assert f.path==m['source_path'] and f.sha256==m['sha256'] and bp.requirement==m['authority_digest']
g['check_ranges'](ranges,len(b));report=W/'files'/m['owned_report'];data=report.read_bytes();g['artifact'](W/'files',dict(path=m['owned_report'],bytes=len(data),sha256=sha(data)))
print(json.dumps(dict(passed=True,scope='G-FILE structural components only; not semantic acceptance',called_components=['parse','check_ranges','artifact'],checker_sha256=sha((M/'tools/validate_stage1_blueprint.py').read_bytes()),source_sha256=sha(b),source_lines=1717,ranges=ranges,target_fragments=15,report_sha256=sha(data),new_behavior_runs=0),indent=2))
