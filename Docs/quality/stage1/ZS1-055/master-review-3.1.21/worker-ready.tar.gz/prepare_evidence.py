from pathlib import Path
import json,hashlib,shutil,tarfile
w=Path(__file__).resolve().parent
pi=Path('/Users/wangweiyang/GitHub/pi-mono'); master=Path('/Users/wangweiyang/GitHub/zenpi')
def ident(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(n,d): (w/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def cp(src,dst):
 dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
inputs=[]
for p in (w/'source').rglob('*'):
 if p.is_file(): inputs.append({'path':str(p.relative_to(w)),'origin':str(pi/p.relative_to(w/'source')),**ident(p)})
for rel in ['packages/ai/src/providers/'+n+'.ts' for n in ['anthropic','google','openai','openrouter']]+['packages/ai/src/compat.ts','packages/ai/src/models.ts','packages/ai/src/utils/event-stream.ts']:
 cp(pi/rel,w/'source'/rel);inputs.append({'path':'source/'+rel,'origin':str(pi/rel),**ident(w/'source'/rel)})
for rel in ['src/providers/anthropic.rs','src/providers/google.rs','src/backend/chat_stream.rs','src/backend.rs','src/providers/registry.rs','src/backend/transport.rs','src/core.rs','src/headless.rs']:
 cp(master/rel,w/'target'/rel);inputs.append({'path':'target/'+rel,'origin':str(master/rel),**ident(w/'target'/rel)})
save('input-inventory.json',inputs)
ledger=[]
def reading(path,start=1,end=None,kind='new full context reading in055'):
 p=w/path;lines=p.read_bytes().splitlines(True);end=end or len(lines);a=sum(map(len,lines[:start-1]));b=sum(map(len,lines[:end]));part=b''.join(lines[start-1:end]);dest='reading-excerpts/'+path.replace('/','__')+f'-{start}-{end}.txt';(w/dest).parent.mkdir(exist_ok=True);(w/dest).write_bytes(part)
 ledger.append({'path':path,'excerpt':dest,'line_range':[start,end],'byte_range':[a,b],'kind':kind,**ident(w/dest)})
for p in (w/'source/packages/ai/src/api').glob('*.lazy.ts'): reading(str(p.relative_to(w)))
for n in ['lazy.ts','cloudflare.ts','cloudflare-ai-binding.ts','github-copilot-headers.ts','openai-prompt-cache.ts','simple-options.ts','transform-messages.ts']:reading('source/packages/ai/src/api/'+n)
for n in ['azure-openai-responses.ts','bedrock-converse-stream.ts','google-vertex.ts','mistral-conversations.ts','openai-codex-responses.ts','openai-responses-shared.ts','openai-responses.ts','openrouter-images.ts','pi-messages.ts']:reading('source/packages/ai/src/api/'+n,1,60,'new import/interface boundary reading only; not whole-file review')
for n in ['anthropic','google','openai','openrouter']:reading('source/packages/ai/src/providers/'+n+'.ts')
reading('source/packages/ai/src/utils/event-stream.ts')
reading('source/packages/ai/src/compat.ts',175,230,'new registration boundary excerpt')
reading('source/packages/ai/src/models.ts',750,875,'new actual dispatch boundary excerpt')
reading('target/src/providers/anthropic.rs',243,330,'new request-boundary partial context')
reading('target/src/providers/anthropic.rs',664,790,'new terminal/sink cancellation partial context')
reading('historical055/files/Docs/learn/stage1_pi_mono/packages/ai/src/api/current_folder_learn.md',kind='new full historical report reading')
reading('historical055/files/Docs/quality/stage1/ZS1-055/worker-directory-review/probe.ts',kind='new full historical probe reading; no execution')
reading('dependency016/Docs/learn/stage1_pi_mono/files/packages/ai/src/api/anthropic-messages.ts_learn.md',kind='new full accepted canonical016 report reading; source reading reused via receipt')
reading('dependency016/Docs/quality/stage1/ZS1-016/master-rebind-3.1.21/review.md',kind='new full master016 rebind reading')
reading('dependency017/Docs/quality/stage1/ZS1-017/master-review-3.1.21/review.md',kind='new full master017 independent review reading')
save('reading-ledger.json',ledger)
# Read prior017 archive only as data; no extraction or old scripts run.
archive=next((w/'dependency017').rglob('worker-ready.tar.gz'))
reuse=[]
with tarfile.open(archive) as t:
 for rel in ['reading-ledger.json','context-reading-ledger.json','source/packages/ai/src/api/google-shared.ts','target/src/providers/google.rs']:
  b=t.extractfile(rel).read();p=w/'reused017'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);reuse.append({'archive':str(archive.relative_to(w)),'member':rel,'path':str(p.relative_to(w)),**ident(p)})
save('reused017-inventory.json',reuse)
old=json.loads((w/'historical055/files/Docs/quality/stage1/ZS1-055/worker-directory-review/inventory.json').read_text())
drift=[]
for r in old['snapshots']:
 original=Path(r['original']);base=pi if 'pi-mono/' in str(original) else master;cur=('source/' if base==pi else 'target/')+str(original.relative_to(base));now=ident(w/cur)
 drift.append({'historical':'historical055/files/'+r['snapshot'],'current':cur,'old':{k:r[k]for k in ['bytes','sha256']},'new':now,'same':now=={k:r[k]for k in ['bytes','sha256']}})
save('old-current-drift.json',drift)
print(json.dumps({'inputs':len(inputs),'new_readings':len(ledger),'old_current_drift':[(r['current'],r['same'])for r in drift]},indent=2))
