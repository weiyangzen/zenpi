

## 3.1.21 独立目录复核追加（Worker B，ZS1-055 候选）

本节是当前判断；前文 3.1.17 历史报告逐字保留，不把其中当时的依赖未验收状态、旧目标快照或测试数字解释为当前状态。本轮仅交付 `packages/ai/src/api` 目录候选，不签发 master receipt、不关闭依赖、不修改主线勾选。正式子项只有 ZS1-016、ZS1-017、ZS1-029。捕获时 016、017 有 3.1.21 master accepted receipt；029 只有刚完成的 Worker B 候选。目录 055 本身仍待主审。父目录 059 和其他 provider API 不由本报告验收。

权威绑定为 blueprint 3.1.21，requirement digest `3456abcbbebbc4e0ab383c319851b0a6e71b19ee9b3c060a6e212f61a89c9d9d`，baseline `92b06c4b1dcdca7614d226ce5f41205646a9e63967789d2b6ed4ee272d240884`，run `zenpi-stage1-20260911`。检查范围是 055、三个正式子项的实际行、源文件身份与相关代码；不以无关 checkbox、Gantt 或总完成计数作门禁。最终权威快照及差异观察另存，不能因总文件哈希改变就宣称本目录失效，也不能悄悄把子项中途验收变化改写成捕获时已闭合。

### 实际阅读与复用边界

`reading-ledger.json` 记录本轮 41 段实际阅读及字节/行区间：所有 11 个 lazy 文件、lazy 主体、7 个小型/共享文件中的对应全篇、四个目录外 provider 工厂、event-stream 全篇；compat 注册与 models 实际分发片段；当前 Anthropic 请求入口和 finish/sink 片段；旧 055 报告与完整 probe；016 当前 canonical 全文与 rebind；017 主审追加全文。9 个大型非正式适配器仅新读 1–60 行的导入/接口边界，不能称为全文件理解。

正式源文件逐字阅读证据按身份复用：016 的 master receipt 覆盖 `[0,10223) [10223,18033) [18033,30114) [30114,39526) [39526,48616)`；017 本任务此前完整阅读三段 `[0,6110) [6110,11521) [11521,16027)`，现由主审 canonical 与 11 个 receipt artifacts 绑定；029 本任务此前完整阅读七段至 62416 字节，577 文件候选包原样嵌入。这里没有把 receipt/index/hash 校验冒称为本轮重读源代码。Google-shared 全文、constrained-sampling 全文、Google/Chat 当前目标及后端/transport/core/headless 的相关片段，沿用本任务 017/029 的已读证据；必要的真实调用边界本轮另行读代码，结论不只来自文件列表。

### 目录职责及调用关系

该目录承担 provider 协议请求构造、消息历史转换、SDK/传输响应到内部事件的折叠，以及延迟加载接入。三份正式实现不互相调用，也不代表三家供应商唯一的协议实现。`anthropicProvider`、`googleProvider` 分别接入对应 lazy adapter；`openaiProvider` 默认接入 `openAIResponsesApi`，不是 029 的 Chat Completions。OpenRouter 则提供按 API 键选择的 Anthropic/Chat 实现表。`createProvider`（models.ts 750–875）明确区分单一 implementation 与按 `model.api` 取值的 map；缺项经 lazyStream 产生 stream error。单一 implementation 不进行该 map 查找。compat 175–230 的内置注册只填缺失项，reset 清表再注册，因此不能由目录名推导每次请求都固定走某一个正式子项。

路径可概括为：目录外 provider/model 选择 → `*.lazy.ts` 动态 import → `stream` 或 `streamSimple` → 适配器请求/历史转换 → SDK 或 fetch → `AssistantMessageEventStream`。认证解析、模型目录、注册覆盖来自目录外；工具实际执行、回合调度、重试后的持久化、用户界面不由这些 API 文件完成。

共享修改需要按调用者核对影响范围：simple-options 在 Simple 路径合并采样、限额、signal、hook 等参数；transform-messages 先处理图片、跨模型签名/ID，再补缺失的工具结果并跳过 error/aborted assistant；Google 的 native parts 转换经 google-shared 调用 transform-messages，不能写成完全独立于公共转换层。Responses 系列还共享 openai-responses-shared；Vertex 共用 Google 层。这里只说明所读依赖关系，不把所有调用者自动纳入正式验收。

### lazy / event contract 的精确含义

三个正式 `*.lazy.ts` 都是很薄的 `lazyApi(() => import(...).then(...))`。每次调用都会调用 load 函数；实际模块缓存由运行时处理，并非 lazy.ts 自建一次性缓存 Promise。`lazyApi` 的 async setup 把导入、实现选择以及实现同步抛错转换到 Promise 拒绝链。`lazyStream` 自身直接调用 setup；对于违反其 Promise 契约而直接同步 throw 的任意 setup，不应承诺这一层能捕获。正式三个 wrapper 的 async setup 不属于该反例。

`forwardStream` 对内部事件逐个 `target.push(event)`，保持对象引用，没有深拷贝、schema 校验、排序或背压。迭代完成后若有 `result()` 则等待，再调用 end。catch 覆盖的还可能是转发迭代/result 的拒绝，不能仅命名为“import 错误”；构造的失败结果是空 assistant、零 usage、stopReason error。若外流已经收到终止事件，EventStream 忽略其后的 push，已解决的最终 Promise 也不会被后来的 end 覆写，所以不能外推所有后置异常都会产生第二个可见 error。

AssistantMessageEventStream 以 done/error 识别完成并取出同一个 message/error 对象，`result()` 返回该 Promise。partial 是可变对象，不是历史快照。外层 lazy 不建立网络取消机制、不取消动态 import，也不规定 reader.cancel。正常预先取消由适配器检查 signal 并输出 aborted；若先发生导入失败则 setup error 的规则不同。`fetchDeferred`/`cancelDeferred` 仅按 capability 配置暴露；三个正式 wrapper 均未启用。不能拿别的 Responses lazy capability 说明这三个协议已支持 deferred。

目录也不是全体都返回这种流：`openrouter-images.lazy.ts` 实现独立 `ProviderImages.generateImages` async 方法。Bedrock lazy 为静态 Bun 构建提供显式 module override 与 .ts/.js import 路径选择，仅作为上下文静态阅读；本轮没有构建验证。Cloudflare binding 检查并绑定 fetch 接收者、透传参数；Cloudflare.ts 是 URL 模板。该事实不取消 Google 对自定义 fetch 的拒绝规则。Copilot headers 按最后消息角色选择 initiator 并检查 user/tool 图片；prompt cache 截断采用 Unicode code point 的 Array.from，不能写成 64 字节。

### 三个正式子项的整合含义

| 子项 | 源码身份 / 当前证据状态 | 目录层需要保持的差异 |
| --- | --- | --- |
| 016 Anthropic Messages | 48616 字节，`8e105cc5b2dd304547ed613b70de4740c4db93cee830dc452c2de945052b12b7`；118 个主审 artifacts；3.1.21 accepted rebind | native blocks/thinking signatures/tool_use，按 SDK 原生事件折叠；源侧 block/tool end 不等于整个响应通过目标严格终止校验；源 refusal 为 error，当前 Rust 可生成带 refusal 的 Completion。 |
| 017 Google Generative AI | 16027 字节，`1395c3f2a90bf701b8b5fc1b6f7de8d323193ed339e07a60630900099a543757`；11 个主审 artifacts；3.1.21 accepted | google-shared 转 native parts，thought signature 与工具身份需要协议规则；source cache/input 口径与目标聚合口径不同；主审纠正必须覆盖旧候选的过宽措辞。 |
| 029 OpenAI Chat Completions | 62416 字节，`5874bf0b121db117bd4eba8fffa750252f5f7617f38306c6eb1f746575896319`；候选 manifest `70c63be72d4fd8c2d69b03d679bf28a5ad8a49c52be26651ca6cb029218a7322`；捕获时无 master receipt | 多 provider 兼容分支、reasoning replay 与 tool argument 增量修复；Chat 不是 Responses；完整文件阅读和离线审计不自动等于主审验收。 |

017 master-review-3.1.21 已完整阅读，明确采用其三项限定。第一，公共 transform 的 tool ID normalize callback 只有 provider/API/model 三元组不一致才执行；同模型不因为 ID 看起来“不规范”就经过该 callback。Google 自己同 provider/model 的 base64/signature 层规则需另外区分。第二，simple-options 当 contextWindow > 0 时返回 `Math.min(maxTokens, Math.max(1, available))`，下限 1 只保护 available，显式 maxTokens 为 0 或负值仍可能保留；contextWindow <= 0 的分支才对传入 maxTokens 用 Math.max(1,...)。不能写成输出一律至少 1。第三，一些负向测试仅断言 is_err，名称不能单独证明错误来自被命名的条件；saved-model resume fixture 同时可能有不完整 metadata。不得把历史通过当成隔离了所有失败原因。

同一主审还明确模型成本分层选择最高的严格超过阈值层；Google source input 排除 cached token，而 Rust input 聚合包含缓存，不能直接逐字段比较收费或总数。Anthropic source 输入与 cache read/write、目标汇总同样需要说明口径，Chat 也有 reasoning/output/cache 明细；统一事件类型不意味着三个 usage 对象能无条件同义替换。Provider/model/API 身份和签名必须跨历史保留；修复 JSON/补合成 tool result 是源侧宽容转换，不是严格 type/schema 验证，更不等于允许直接执行 partial tool。

016 主审保留了同模型 bad:id 初始预期错误及更正：同模型保留原值，跨模型才归一化为 bad_id 并同步结果引用。还保留主审准备阶段第三方 JSON 文件尾换行断言失败、随后改用 JSON 解析校验的过程。其历史主审确有 23 场景/24 HTTP source 执行，但那是旧执行，不是本轮。source Anthropic 的 onPayload 后强制 stream=true 与 Google/Chat 路径不可混写；thinkingBudgetTokens 的 `|| 1024` 会覆盖 0；reader finally releaseLock 不等于 cancel；hook 等待无独立有界保证。这些已归入正式子项说明，本轮没有因此新增产品修复。

### 当前 Zenpi 映射及旧目标漂移

映射使用 `src/providers/anthropic.rs`、`src/providers/google.rs`、`src/backend/chat_stream.rs`，后端入口仍在 backend.rs，协议/能力分发在 registry.rs。transport 负责受限读取/取消与传输，core/headless 的回合、工具执行与持久化所有权属于另外层次。本目录报告不把 UI、持久化或运行预算算成 API adapter 自身已证明的能力。

旧 055 的 10 个 Pi 快照全部字节相同。旧 5 个目标快照中 backend.rs、registry.rs 相同；Anthropic、Google、Chat 三个文件已有漂移，完整旧副本和新副本及哈希对照均保留在 `old-current-drift.json`。因此旧 17/17/8 target log 不能直接宣称覆盖当前目标。

本轮重新读当前 Anthropic request_body 243–330：附件总量、类型、structured-output 不支持项以及历史工具结果顺序在请求前校验。finish/read_response 664–790 则先要求 message_stop、检查 blocks/stop_reason/capabilities，再形成 Completion；空拒绝归一化后同时保持可见文本与 replay block；usage 使用 checked_add；发 ToolCallDone 前已完成上述终止校验。sink wrapper 每次发送前检查取消，包括终止 batch 中途取消。这与源侧逐 block 发 toolcall_end 的时间点不同。该片段阅读不是整个 Anthropic 887 行全读的声明，其完整行为依照已接受016报告及当前身份复核。

Google 当前文件与017已读快照、Chat 和公共 backend/registry/transport/core/headless 与029已读快照逐字复用核对。已有 metadata/native history 被保存的当前事实，覆盖旧报告中可能把历史能力简化为纯文本的说法。目标的严格 terminal gating、schema/size/capability 检查及取消所有权不能由源宽容 parser 的成功样例推出。当前 Google/Chat 定义数 19/22 与旧执行 17/8 是不同时间层；本轮没有运行这些测试，不相加成新通过数。

### 历史 055 实验可以证明什么

完整旧 probe.ts 已逐句重读。它启动一个本机 Bun HTTP fixture server，用实际三种 lazy factory/SDK，对每个 API 做 success、missing-auth、preaborted 三种场景，共 9 场景、3 HTTP。它检查 streamSimple 调用不同步 throw，返回 async iterable 且有 result，终止 done/error 数为 1，最终 result 与终止事件对象严格同一引用；success 检查 hello/stop、请求路径和认证；缺认证与预取消没有 HTTP。三种 success 的日志记录 start/text_start/text_delta/text_end/done，但 probe 并未逐条严格断言所有中间事件序列。它只显式断言没有 cancelDeferred；未显式断言 fetchDeferred，后者缺失来自 wrapper 代码阅读。

lazy-native 原始 receipt 是 2026-09-10T23:25:58Z 附近、exit 0、约 0.578 秒，日志 1577 字节 / SHA `4582475b24653c4df9a61a0689d3f9e90cb45e6f8827727c37305e9acd6f1907`。SDK 身份来自原依赖锁：Anthropic 0.124.0、Google 2.21.0、OpenAI 6.40.0、partial-json 0.1.7。代码的 15 秒 watchdog 是该 probe 的保险，不证明生产流超时。没有覆盖 load rejection、动态 import 期间取消、首事件后取消、并发消费者、延迟终端、背压或任意 inner.result 拒绝。原始 Google fixture 与目标更严格的 metadata 契约不同，不能当作同一输入的源目标完全等价实验。

旧 leaf 016 的 23/24、017 的 17/20、029 的 33/37 分别保留原日志及失败版本；旧 target 17/17/8 和后来的叶子测试数字都不和这 9/3 相加。旧 evidence-verified exit 0 仅是当时结构核验。旧 G-STAGE exit 1、结构部分 ok、缺少 ZS1-055.master.json 的错误仍原样保存；它既不是本轮源行为失败，也不能删去或改成成功。新 verifier 仅用 Python 标准库读文件、JSON/tar 和内存 patch 重建，不执行这些旧脚本或 SDK，也不启动 HTTP、Rust、Bun 或产品。

### 新发现与交付边界

本轮没有确认新的产品运行缺陷。新补强的是目录声明的证据精度：OpenAI 默认协议与029的区别、图像接口例外、lazy 异常/引用/取消边界、Google共享转换、017主审三项限定，以及旧目标三文件漂移。上述均应由主审逐项核阅，而不是自动以离线哈希检查取代语义判断。

历史 C 包 198 个实体文件、65 个 manifest payload、candidate.patch（554702 字节）和 runner 全量只读复制；新 verifier 在内存中验证每个旧 patch 正向/反向重建与总 patch 拼接，保留空 base 和历史失败。016/017 receipt artifact 链、017归档内manifest及完整阅读区间、029完整候选原包、32个真实直接项清单、新阅读切片、当前目标与最终权威观察均随包携带。原始 B/C 共6080文件的保护清单用于本机只读检查；外机 portable 模式不要求这些绝对路径存在。

离线结果证明文件身份、引用闭合和限定的历史结构事实，不授予055或029 accepted 状态。最终核验输出、冻结 manifest 与原始文件保护结果另交主审；本轮 SDK/产品/构建/预算执行数为0。只提供这一目录候选报告，不写主线目标文件，不更新权限、claims、BentoBox、旧ready或全局checker。
