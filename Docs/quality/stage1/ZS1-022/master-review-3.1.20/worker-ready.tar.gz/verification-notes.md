# Preseal verifier corrections
+
+The first static verifier attempt exited1 before patch checks because its archive source member name omitted the nested source path. The old manifest identified the correct member, which was then used.
+
+The second attempt exited1 on exact fragment line count: the requested runner1246–1299 capture reaches EOF1286. Its bytes were already correct; the new context index/file name and current appendix were corrected to1246–1286. The verifier line-count assertion was preserved. The old historical report remains byte-for-byte unchanged.
+
+These were packet preparation failures, not product or runtime tests. Subsequent static verification is recorded separately. No archived script, Node, Cargo, PTY, HTTP or product process was executed.
+