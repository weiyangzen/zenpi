#!/usr/bin/env python3
"""Static packet/patch verification; never execute archived runtime probes."""
from pathlib import Path
import argparse, hashlib, json, re, subprocess, tarfile, tempfile

root = Path(__file__).resolve().parent
sha = lambda data: hashlib.sha256(data).hexdigest()
def read_json(path):
    return json.loads(path.read_text())
def checked(data, record):
    assert len(data) == record['bytes'], record
    assert sha(data) == record['sha256'], record
def verify(skip_manifest=False):
    manifest_verified = False
    if not skip_manifest:
        manifest = read_json(root/'manifest.json')
        paths = []
        for row in manifest['files']:
            path = root/row['path']
            assert path.resolve().is_relative_to(root)
            checked(path.read_bytes(), row)
            paths.append(row['path'])
        assert len(paths) == len(set(paths))
        assert set(paths) == {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name != 'manifest.json'}
        manifest_verified = True
    binding = read_json(root/'report-binding.json')
    canonical = binding['canonical']
    assert canonical == 'Docs/learn/stage1_pi_mono/files/packages/coding-agent/src/core/extensions/types.ts_learn.md'
    prefix = (root/'history/prefix.md').read_bytes()
    report = (root/binding['report']).read_bytes()
    appendix = (root/'appendix.md').read_bytes()
    for label, data in [('prefix',prefix),('appendix',appendix),('report',report)]:
        assert len(data) == binding[label+'_bytes']
        assert sha(data) == binding[label+'_sha256']
    assert report == prefix + appendix
    assert len(prefix) == 23695 and sha(prefix) == 'f69ae4fbae43ad256fc4f810b17f4ccc8658e78365116c8717a4eb399eaa044d'
    with tarfile.open(root/'history/prior-ready.tar.gz', 'r:gz') as archive:
        # Read members without extraction or execution.
        prior_bytes = archive.extractfile('prior-ready/manifest.json').read()
        assert sha(prior_bytes) == binding['old_manifest_sha256']
        prior = json.loads(prior_bytes)
        for row in prior['files']:
            checked(archive.extractfile('prior-ready/'+row['path']).read(), row)
        assert len(prior['files']) == 18
        assert archive.extractfile('prior-ready/learn-report.md').read() == prefix
        old_source = archive.extractfile('prior-ready/source/packages/coding-agent/src/core/extensions/types.ts').read()
    source = (root/'source/types.ts').read_bytes()
    assert source == old_source
    coverage = read_json(root/'coverage-current.json')
    checked(source, coverage['subject'])
    assert coverage['subject']['sha256'] == '96e20f8038027f0b0172f311b6b9d9ddf42123b2f5b2a018f533af026fd3371e'
    lines = source.splitlines(keepends=True)
    cursor, next_line = 0, 1
    for row in coverage['complete_contiguous_read']:
        a,b = row['byte_range']
        assert a == cursor and 0 < b-a <= 256*1024
        assert row['start_line'] == next_line
        data = b''.join(lines[row['start_line']-1:row['end_line']])
        assert data == source[a:b]
        checked(data,row)
        cursor, next_line = b, row['end_line']+1
    assert cursor == len(source) == 63623 and next_line == len(lines)+1 == 1798
    assert coverage['read_ranges'] == [r['byte_range'] for r in coverage['complete_contiguous_read']]
    text = source.decode()
    declarations = [{'line':text[:m.start()].count('\n')+1,'kind':m[1],'name':m[2]}
                    for m in re.finditer(r'^(?:export )?(interface|type|function)\s+(\w+)',text,re.M)]
    assert declarations == [{k:r[k] for k in ('line','kind','name')} for r in coverage['declarations']]
    events = re.findall(r'\bon\(\s*event:\s*"([^"]+)"',text)
    assert events == coverage['on_event_overloads'] and len(events) == len(set(events)) == 36
    mapping = read_json(root/'event-mapping-current.json')
    assert [r['source_event'] for r in mapping] == events
    assert sum(r['target_hook'] is not None for r in mapping) == 8
    fragments = 0
    for record in read_json(root/'context-index.json')['files']:
        for fragment in record['fragments']:
            data = (root/fragment['path']).read_bytes()
            checked(data,fragment)
            assert len(data.splitlines()) == fragment['end_line'] - fragment['start_line'] + 1
            fragments += 1
    patches = []
    for filename, original in [('create-report.patch',b''),('append-report.patch',prefix)]:
        patch = root/filename
        headers = [line for line in patch.read_text().splitlines() if line.startswith(('--- ','+++ '))]
        assert headers == ['--- '+('/dev/null' if not original else 'a/'+canonical),'+++ b/'+canonical]
        assert patch.stat().st_size < 256*1024
        with tempfile.TemporaryDirectory(prefix='source022-verify-',dir=root.parent) as temporary:
            directory = Path(temporary)
            def git(*args):
                result = subprocess.run(['git',*args],cwd=directory,capture_output=True,text=True)
                assert result.returncode == 0, {'argv':args,'stdout':result.stdout,'stderr':result.stderr}
            git('init','--quiet')
            target = directory/canonical
            if original:
                target.parent.mkdir(parents=True)
                target.write_bytes(original)
            git('apply','--check',str(patch))
            git('apply',str(patch))
            assert target.read_bytes() == report
            assert {p.relative_to(directory).as_posix() for p in (directory/'Docs').rglob('*') if p.is_file()} == {canonical}
            git('apply','--reverse','--check',str(patch))
            git('apply','--reverse',str(patch))
            assert (target.read_bytes() == original) if original else not target.exists()
        patches.append({'patch':filename,'sha256':sha(patch.read_bytes()),'apply_and_reverse':'passed','only_path':canonical})
    return {'ok':True,'kind':'static integrity and private exact-apply only','manifest_verified':manifest_verified,
            'prior_artifacts_verified':18,'source_bytes':len(source),'source_lines':len(lines),
            'declaration_entries':len(declarations),'subscription_events':len(events),'context_fragments':fragments,
            'exact_prefix_preserved':True,'report_sha256':sha(report),'patch_checks':patches,
            'runtime_tests_executed':0,'G_STAGE_executed':False,'semantic_gate':'pending independent master review'}

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--without-manifest',action='store_true',help='preseal verification only')
    args = parser.parse_args()
    print(json.dumps(verify(args.without_manifest),indent=2))
