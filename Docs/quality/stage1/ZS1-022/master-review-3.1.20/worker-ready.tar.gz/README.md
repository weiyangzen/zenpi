# ZS1-022 current source-understand candidate

Only canonical deliverable: `files/Docs/learn/stage1_pi_mono/files/packages/coding-agent/src/core/extensions/types.ts_learn.md`.
The old 23,695-byte report is an exact prefix; the appendix supplies current semantics, owner mapping and execution boundaries.

Use **one** patch: `create-report.patch` only for an absent canonical report, or `append-report.patch` only for the exact prefix in `report-binding.json`. Both result in identical bytes. Inspect/reconcile any other receiver state; never blindly overwrite it. No product/status/selector/other-report change is included.

`history/prior-ready.tar.gz` preserves all historical source/helper/integration evidence and scripts. Those scripts were **not run** in this refresh. Do not treat older Node/helper/host pass counts as fresh execution.

`coverage-current.json` provides complete byte ranges and declaration audit inventory; the report supplies semantics. `event-mapping-current.json` lists all36 subscriptions. `context-index.json` binds only bounded context fragments to captured full-file hashes; it accepts no sibling/target file.

Run `python3 verify.py` from any cwd to read/verify this packet and apply/reverse both alternative report patches in new private temporary directories. It invokes Git only; no Cargo/Node/PTY/HTTP/network/product process. Verification is structural, not G-STAGE or semantic acceptance.

Master still owns independent G-FILE review, integration and G-STAGE --item ZS1-022. ZS1-023/052 and product gates remain outside this delivery.
