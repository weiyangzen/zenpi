# ZS1-071 runtime owner review

[_] Worker candidate, authority3.1.16; master acceptance pending. See learn-report.md for complete source review, scope and concrete observations.

Read all 912 lines /33333 bytes of src/runtime.rs, SHA256 7a42c428083f8f3edb0019311296b479004ff562b548d7cdc504729f7cbd1f21. The prior report hash exactly matches the first763 lines and is preserved as baseline context; it was not substituted for the current full read.

No product source changes. Executed runtime12 + input_queue17 + observation probes4 =33 top-level passed,0 failed,1 parent-launched subprocess helper ignored in the top-level list. Four probes observe actual event backpressure, a transport-admitted tail with no worker event after shutdown, completion overriding an already observed cancellation, zero pending normalized to one, and builder/Drop not revoking an old input boundary. These are current behavior observations, not fixes. stderr's fixture panic belongs to the successful catch_unwind test.

The input-queue tests use real filesystem/journal and a separate OS process; runtime probes use actual Rust threads/channels. No external model/network, native UI/PTY, system thread-exhaustion injection or all-interleavings proof is claimed. Replay dependencies/toolchain remain external.

Verify manifest hashes, then `python3 unpack-replay.py /new/empty/destination`; run test-command.json's argv in that directory with your own CARGO_TARGET_DIR. Full snapshot source/tests/build inputs and four-probe source are frozen; no original repository is required to reconstruct these inputs. Exact-read segments, original report, baseline prefix and post-run master subject comparison are included. All product input hashes match the read-only snapshot.
