# ZS1-071 — src/runtime.rs 完整 owner 复核

状态：[_] 独立阅读/行为候选，主控未接受。authority 3.1.16；requirement digest `c0262492bc6e3b4d5f56b35bedc7c1d1658854df11c4a975eb612a514cceef8f`。

本次 subject 为主控只读快照 `src/runtime.rs`，912行、33333字节、SHA256 `7a42c428083f8f3edb0019311296b479004ff562b548d7cdc504729f7cbd1f21`。按1–340、341–660、661–912完整逐行读取，字节范围并集为[0,33333)，各段hash见 `read-coverage.json`。没有以函数索引、旧摘要或测试通过代替全文阅读；本次未改任何product源文件。

旧报告为28121字节/hash `2183b622d96a8fdc084784af8f537fa09a4e1703b5ff70de3bc459d29fb05315`。重新计算证明它恰好对应当前文件前763行；因此只把其基线定位作为同hash背景复用，新增764–912行必须重新审阅。旧报告和该前缀原字节均冻结。尤其纠正旧报告“原子状态”的含混表述：当前取消/完成是两个AtomicBool，不是一个保证先到者赢的CAS终态机。

## 职责、owner 与来源映射

本文件拥有两个不同层次：BackgroundRunner是泛型、进程内、单active job调度器；InputBoundaryGate是一个既有job内部下一次model turn之前的可撤销输入边界凭据。前者的pending FIFO不是steer/follow-up持久队列，JobId也不是用户稳定input ID。后者不启动线程、不调用provider、不执行tool、不直接写journal，真正消费/持久化由InputQueue与core完成。

与冻结的pi `agent-loop.ts`（ZS1-010）和 `agent.ts`（ZS1-011）比较，源实现中等待整批工具、准备后输入再检查、steer优先于最终follow-up等语义需要core/InputQueue共同实现。runtime的gate只提供“当前整批未完/prepare未完/取消时不可取boundary”的局部能力。不能把名字中的pending follow-up或单个Gate当成ZS1-101全部完成，也不能从本文件给工具进程回收、provider transport、extension lease、session recovery等其他owner打勾。

当前快照core在创建gate时先new再with_context_parent(turn_id)，之后才使用boundary；headless在Agent成功返回并跨过durable completion后调用mark_completed。这些是已定位的适配器使用约束，不是本文件自行证明持久化完成。TUI也有独立的完成标记调用点；本次没有跑native TUI/PTY。

## 逐段职责与全部控制分支

| 行 | 实现与分支 | ownership / 限制 |
|---|---|---|
| 1–47 | 模块契约、默认shutdown grace 1s、上限30s、JobId新类型/get | 不承诺强杀任意Rust代码；ID用于一次runner日志关联 |
| 49–99 | CancellationToken::new/cancel/is_cancelled/mark_completed | cancel先读completed，已完成返回false，否则swap cancelled；is_cancelled同时要求cancelled=true且completed=false；mark_completed无条件置completed |
| 101–134 | RuntimeConfig/default/normalized | 默认command32/event128/pending32/poll10ms；三个容量均至少1、poll至少1ms；不存在“0禁止排队”的配置语义 |
| 136–193 | SubmitError Display/Error、JobOutcome、RuntimeEvent | QueueFull/Closed有transport与worker两处来源；Accepted与Started、Completed与Closed含义分别独立；Cancelled不是rollback |
| 195–234 | Command、Active、ShutdownState、JobExecution | active持有独立token、oneshot接收器和join；deadline剩余时间saturating并取poll上限；返回结果与panic分开 |
| 236–306 | BackgroundRunner字段、Debug、spawn | 两个sync_channel；闭包Arc；WorkerClosedGuard负责全部退出路径的closed位；主worker线程spawn失败直接expect panic，无Result型错误返回 |
| 308–350 | try_submit/try_cancel/try_shutdown/try_shutdown_with_grace | try_send非阻塞；Full或Disconnected映射明确；try_submit先fetch_add再发送，失败仍消耗ID；不会等待worker接受；grace在入口夹到30s |
| 352–374 | next_event/recv_timeout/try_next_event/join | 三种接收包装；裸join要求调用者先drain Closed，不能作为任意状态的非阻塞close |
| 376–421 | shutdown_and_join系列 | 入shutdown命令时如command满就同步消费event腾空间；随后继续drain直到Closed/closed位/断开，再join；已消费Closed也可安全调用；丢弃这些被helper消费的事件是该API的明确取舍 |
| 424–441 | Drop | best effort零grace请求，不阻塞，取走join后detach；命令队列满时发送可失败；不等同于显式shutdown_and_join承诺 |
| 443–509 | worker循环首先检查done | 成功收到结果先join再classify，再finish_active；若停止则返回，否则pending.pop_front启动下一job；done断开单独映射Panicked并走同样收尾；Empty才去读命令 |
| 511–542 | shutdown期限与读取命令 | 已过期限且active存在则丢Active，关闭done接收器、detach job、发Cancelled及剩余关闭序列；active时recv_timeout，无active阻塞recv；命令端断开转默认grace shutdown |
| 544–589 | Submit三分支 | idle且未停止：Accepted(false)后start；active且未停止：pending满则Rejected QueueFull，否则push并Accepted(true)/Queued(depth)；stopping时读到的Submit发Rejected Closed |
| 590–616 | Cancel | 命中active则token.cancel并发CancelRequested（不检查cancel返回值，因此已完成/重复取消也可有该通知）；命中pending则删除并发CancelRequested、Completed Cancelled；未知ID无事件 |
| 617–638 | Shutdown | 新deadline仅能缩短既有期限；有active置取消并发请求事件；无active则cancel_pending后Closed并返回 |
| 640–674 | classify_execution/finish_active | token当前有效取消优先，甚至覆盖闭包Err/Panicked；否则映射Succeeded/Failed/Panicked；完成事件先于shutdown时pending取消和Closed；所有发送失败立即退出 |
| 676–710 | cancel_pending、grace归一、WorkerClosedGuard::drop | FIFO逐个取消，发送失败停止；guard不依赖event通道，退出时Release写closed |
| 712–763 | start_job/emit | 新token/容量1结果通道；job内部catch_unwind；线程spawn失败发Rejected Closed，不发Started；正常先保存Active，再发Started；emit是阻塞send |
| 765–805 | InputBoundary字段/accessor/is_current、Gate状态 | boundary复制model ID/parent/would_stop并共享epoch/cancelled；is_current要求未取消且epoch一致；外部不能直接伪造私有字段，但能通过公开Gate创建合法形状凭据 |
| 806–831 | new/with_context_parent | IDs调用protocol同一验证；起始空tools、未prepare、epoch0、未cancel；builder设置parent不递增epoch |
| 833–855 | begin_tool_batch | 空/超过32/已有tools/正在prepare拒绝；所有ID合法且去重完成后才递增epoch并替换集合；失败不半写tools、不撤销旧boundary |
| 857–887 | tool_completed/begin_prepare/finish_prepare | 完成未知或重复tool拒绝；每次有效完成epoch++；未整批结束不能prepare；重复begin、未begin的finish拒绝；有效切换均使旧boundary失效 |
| 889–912 | boundary/cancel | 存在tool、prepare或cancelled时拒绝；否则生成快照。would_stop是调用者给的布尔值，并非gate探测agent状态；cancel永久置位，没有reset；cancel后部分状态修改方法仍可返回Ok，但始终不能再取boundary |

## 数据流与故障语义

请求先经过command通道，再由worker决定Accepted/Rejected，accepted的active/pending才有已建立的job生命周期。command容量与pending容量不是同一上限。事件通道的bounded含义是内存受限；它是阻塞send，因此host必须持续drain。Started发送前job线程已经spawn，host看到Started的时刻不等于副作用刚开始。done优先于新命令，已经完成的结果可先于排队取消被分类。

shutdown grace从worker实际处理Shutdown时开始，不能覆盖此前事件背压或命令等待；非协作job到期detach后可继续执行任意副作用，迟到结果不能回到已断开的done接收器。这里的“可能短暂继续”不是一个job退出时间上限。已有测试自己释放非协作fixture；不应把fixture最终释放误算为runtime强制回收。

源码中job线程spawn失败仅有Rejected事件，错误原因被压成Closed。静态读取还表明：若启动pending失败但Rejected发送成功，start_job返回true且active为空，剩余pending没有在该分支立即继续启动；下一轮可能等新command。这是未执行的系统线程耗尽分支，不宣称已有可重复故障证据或修复。本次也不声称覆盖主worker spawn失败、done sender异常断开、JobId u64回绕、全部内存顺序交错。

Gate的撤销是epoch/cancel状态的协议，不是Rust对象生存期撤销。begin_tool_batch/begin_prepare/finish_prepare/tool_completed会使旧凭据过期，但with_context_parent和Drop都不会。它与InputQueue的防重复model-turn应用、真实session绑定是不同层；仅Gate不能证明model-turn所属session或would_stop的真实性。

## 实际行为证据

本次在未修改product的完整只读输入快照中执行：`tests/runtime.rs` 12通过；`tests/stage1_input_queue.rs` 17通过、1独立进程helper在顶层标ignored；新 `target071_review_probe.rs` 4通过。合计33个顶层通过、0失败，不把parent调用的helper再加一次。真实线程、sync_channel、文件操作和session journal被执行；provider只用已有echo fixture，无外部provider。现有panic测试的stderr中“fixture panic”是预期catch_unwind路径，不是套件失败。

新增探针逐项观察如下，均是对当前行为的陈述，不是把缺口测试绿化后宣称功能修好：

1. event_capacity=1时让Accepted占满event通道，job线程已运行、worker阻塞发送Started。try_cancel返回Ok后25ms，job token仍未取消；drain后才置位。再预先排入Shutdown及一个tail Submit，tail的try_submit成功返回JobId(2)，但直到Closed都没有该ID的Accepted/Rejected/Completed事件。只有“进入command通道”，没有worker承诺。这一点比旧摘要“拒绝有显式事件”更窄；读到Submit的stopping分支会Rejected，但Shutdown后未读到的command可随receiver释放而消失。
2. job先实际观察到token.is_cancelled=true，再调用mark_completed，则is_cancelled变false，最终Succeeded(7)。它不是仅阻止“晚到取消”的通用原子仲裁；adapter必须只在真实语义完成后调用，不能先标记再执行未完成工作。
3. max_pending=0、poll=0的配置允许一条pending（depth1），下一条被worker明确Rejected QueueFull，证明归一化行为而非零容量模式。
4. 先取parent=None的boundary，再对Gate调用with_context_parent("new-parent")，随后提交非法重复tool batch并Drop gate；旧boundary仍能把真实journal中的队列项Applied，parent仍为None。当前core正常构造顺序避免这个builder用法，但公共能力不承诺builder/Drop撤销；要撤销应明确cancel或有效epoch状态变更。

现有runtime测试另覆盖off-thread admission、同Agent跨job保留session、FIFO、pending饱和、active/queued取消顺序、late marker、panic后worker存活、已消费Closed再join、双channel饱和shutdown drain、非协作job bounded detach。InputQueue套件另覆盖真实双文件工具批次后边界、prepare前后至多一次应用、lane优先级、编辑revision/取消/容量、过时session writer、跨session拒绝、独立进程恢复、截断尾记录和畸形事件。这些是交互证据，不能据此把input_queue.rs或其目录的全文阅读项一起接受。

## 结论与候选边界

071提供一份当前hash完整阅读报告和可重放行为包；没有产品补丁、没有把上述API局限自动扩展成跨owner修复。主控需要在host职责中保留持续drain、区分transport admission/worker acceptance、正确调用mark_completed、显式撤销boundary四项约束。代码中未证实的系统资源故障分支保留静态标注。acceptance、ledger、其他文件和所有既有候选保持不变。
