from pathlib import Path
import hashlib,json,runpy,sys
ROOT=Path.cwd();EV=ROOT/'Docs/quality/stage1/ZS1-017/worker-reuse320';MAIN=Path('/Users/wangweiyang/GitHub/zenpi');sha=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((EV/'input-manifest.json').read_text());b=Path(m['source']).read_bytes();assert len(b)==16027 and len(b.splitlines())==526 and sha(b)==m['sha256']==m['frozen']['sha256'];assert (EV/'google-generative-ai.ts').read_bytes()==b
parts=[];ranges=[]
for c in m['ordered_complete_read_chunks']:
 d=(ROOT/c['artifact']).read_bytes();assert d==b[c['byte_start']:c['byte_end']] and sha(d)==c['sha256'];parts.append(d);ranges.append([c['byte_start'],c['byte_end']])
assert b''.join(parts)==b
reuse=json.loads((EV/'reused-evidence.json').read_text());pkg=Path(reuse['package']);assert sha((pkg/'manifest.json').read_bytes())==reuse['manifest_sha256']
for r in reuse['records']:
 d=Path(r['path']).read_bytes();assert len(d)==r['bytes'] and sha(d)==r['sha256'],r['path']
old=pkg/'files/Docs/quality/stage1/ZS1-017/worker-source-probe'
for name,code in [('source-native',0),('target-native',0)]:
 r=json.loads((old/(name+'.json')).read_text());d=(old/(name+'.log')).read_bytes();assert r['exit_code']==code and r['bytes']==len(d) and r['sha256']==sha(d)
source=json.loads((old/'source-native.log').read_text());assert len(source['scenarios'])==17 and all(c['status']=='pass' for c in source['scenarios']) and source['http_requests']==20
assert '17 passed; 0 failed' in (old/'target-native.log').read_text()
report=ROOT/'Docs/learn/stage1_pi_mono/files/packages/ai/src/api/google-generative-ai.ts_learn.md';text=report.read_bytes();prior=(EV/'prior-report.md').read_bytes();assert text.startswith(prior) and sha(prior)=='fa2853bce8507405711530960e8f9cf994271a7bba96c5156dea4dfec5676cc1'
count=0
for r in json.loads((EV/'target-references.json').read_text()):
 d=Path(r['path']).read_bytes();assert len(d)==r['bytes'] and sha(d)==r['sha256'],r['path']
 for c in r['excerpts']:
  part=(ROOT/c['artifact']).read_bytes();assert part==d[c['byte_start']:c['byte_end']] and sha(part)==c['sha256'];count+=1
sys.path.insert(0,str(MAIN/'tools'));g=runpy.run_path(str(MAIN/'tools/validate_stage1_blueprint.py'));bp=g['parse']((MAIN/'Docs/stage_1_v3_pi_mono_blueprint.md').read_text());f=bp.files['ZS1-017'];assert f.path==m['source_path'] and f.sha256==m['sha256'] and bp.requirement==m['requirement_digest'];g['check_ranges'](ranges,len(b));g['artifact'](ROOT,{'path':str(report.relative_to(ROOT)),'bytes':len(text),'sha256':sha(text)})
print(json.dumps({'ok':True,'source_bytes':len(b),'source_lines':526,'read_ranges':ranges,'reused_manifest_sha256':reuse['manifest_sha256'],'reused_artifacts':len(reuse['records']),'historical_source_cases':17,'historical_http_requests':20,'historical_target_tests':17,'new_runtime_tests':0,'target_excerpts':count,'report_bytes':len(text),'report_sha256':sha(text),'checks':'G-FILE source/range/artifact; preserved report prefix; historical immutable evidence and receipts; current target hashes','not_claimed':'Remote model execution, rerun of historical tests, whole dependency graph frozen, or master/directory acceptance'},indent=2))
