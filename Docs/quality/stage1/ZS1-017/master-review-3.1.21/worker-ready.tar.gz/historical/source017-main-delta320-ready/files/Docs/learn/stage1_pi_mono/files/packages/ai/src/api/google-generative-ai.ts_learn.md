# ZS1-017 — packages/ai/src/api/google-generative-ai.ts

Worker candidate: [_]. learn_mode: understand. source_id: SRC-0296. source_hash: `1395c3f2a90bf701b8b5fc1b6f7de8d323193ed339e07a60630900099a543757`; 16027 bytes, 526 lines. Complete byte range [0,16027), lines 1–526 read in ordered chunks 1–250 and 251–526. Frozen hash matches. No sibling or directory acceptance inferred.

## Complete behavior review

1–250: SDK GoogleGenAI and shared conversion/retry/cost helpers. Requires API key, rejects nondefault custom fetch, builds payload with optional replacement. generateContentStream receives AbortSignal. Response uses candidate zero, records first nonempty response ID, separates thought=true text from visible text, retains signatures on both text and reasoning. Function calls close prior text blocks, normalize absent/duplicate IDs with name/time/counter, default args to object, emit tool start/delta/done immediately. Finish reason maps through shared helper; stop with tools becomes toolUse. Usage separates cached input and adds thoughts to candidate output. Abort/error/missing stop are errors; catch retains partial response.

251–526: simple stream selects absent/disabled reasoning versus mapped level/budget; family heuristics include Gemini 3 Pro/Flash, 2.5 Pro/Flash/Lite and Gemma 4. Gemini 3 disabled uses a minimal supported level with includeThoughts=false rather than disabling internal thinking. 2.5 budgets are explicit; unknown budget mapping is dynamic -1. Custom base URL sets SDK apiVersion empty; headers merge default User-Agent. BuildParams carries converted contents, systemInstruction, tools, function calling strict mode, temperature, maxOutputTokens and thinkingConfig; SDK request config is translated to REST generationConfig by the target adapter.

## Direct dependency review

Read google-shared.ts completely, 453 lines / 15695 bytes. It sanitizes Unicode, transforms message/tool identities, filters signatures by exact provider/model and base64 validity, preserves signed empty blocks, and changes foreign thinking to plain text. Tool results become functionResponse output/error with IDs for newer models; adjacent tool responses merge into one user message. Legacy image result routing differs by model version. Tool schemas use parametersJsonSchema normally and a lossy OpenAPI fallback for legacy mode. Strict mode resolves VALIDATED; explicit none/any map to NONE/ANY. Raw stop reasons preserve STOP/MAX_TOKENS, other reasons fail; retries normalize SDK status errors. Dependency review does not claim it as an independently accepted blueprint source item.

Fully read google-shared-signed-empty-blocks.test.ts and google-shared-gemini3-unsigned-tool-call.test.ts. They pin signed empty parts, unsigned legacy calls, exact provider/model signature rules and newer-model IDs. Source tests were not executed. Other source tests were located or partially inspected only and are not claimed complete.

## Target mapping and intentional differences

ZS1-110 implements native contents/parts, systemInstruction, inlineData images, functionDeclarations parametersJsonSchema, functionResponse, generationConfig thinking budgets, native API-key header, generateContent/streamGenerateContent endpoints, strict bounded JSON/SSE, native usage and STOP validation in src/providers/google.rs plus backend/config/core/registry integration.

Ordered provider parts and signatures remain unchanged; local correlation IDs are stored separately and never added to ID-less provider parts. Saved parts carry a serialization digest to detect missing/altered signature data. Exact model required for opaque reasoning; incompatible wire/provider/model fails before model-selection persistence or request. No signature bypass sentinel, history repair, OAuth/Vertex identity, SDK dependency, implicit downloads or legacy schema reduction. Validated tool completion is emitted only at whole-response success, unlike source block-local done. Unknown models remain conservative text-only registry entries; unsupported native fields fail explicitly. A finite parts/history/frame/response/request bound replaces unbounded SDK accumulation.

Errors before full STOP cannot execute tools. Body cancellation drops the one active HTTP connection; shared pre-header/connect cancellation is a separately tracked root-authorized follow-up and not claimed solved by this item. Restart uses existing canonical session recovery and the native-history metadata persistence added by 109. A104 owns opaque-history compaction/pinning and byte accounting. Main integration acceptance is still required.

## Independent runnable source supplement — authority 3.1.13

Original report SHA 91750012d64d0b8e2de62aa83ee46cc9d39c9604bc5dc2db7f80d60a2363d44f matches gemini-ready source_audit and is reused as this supplement base. After independent 016 freezing, reread unchanged source 1–280, 281–526 and google-shared.ts 1–250, 251–453. Source SHA still 1395c3f2a90bf701b8b5fc1b6f7de8d323193ed339e07a60630900099a543757.

17 passing scenarios execute the actual source and actual pinned @google/genai 2.21.0 SDK, with owned loopback HTTP returning raw SSE bytes. No import/parser/client is mocked; SDK installed only in .ops/source017-runtime and resolved using explicit NODE_PATH. Exact command/timing/output in source-native.json/log, dependency lock retained. Covers native endpoint/API-key/system/output limit, thought flag versus signed visible text, first response ID, usage/cache/reasoning arithmetic, missing/duplicate function IDs, early toolcall_end followed by missing-finish error, finish mappings and first candidate only, signed empty same-model replay/foreign signature dropping, ID-less 2.5 replay and coalesced function responses, 2.5 budgets/custom overrides versus 3.x off minima, 3.x mapped thinking/VALIDATED strict schema, onPayload changes, unsupported fetch/missing auth and pre-abort/no HTTP. No probe failures. This is source behavior execution, not type/schema-count substitution.

Current target owners: src/providers/google.rs validate_effort:49, endpoint:57, validate_parts:75, request_body:251, read_response:665; backend.rs owns wire dispatch/API-key/transport; registry.rs exact model capabilities; core.rs durable native metadata with local IDs separate. target-native reruns the existing complete stage1_gemini test target; command receipt records exact result. No native implementation change. The old shared-preheader wording above is historical: current macOS DNS/TLS/header plus actual stalled IPv4 TCP cancellation has independent shared-transport evidence, while non-macOS DNS/non-Unix connect remain incomplete.

Demonstrated differences: source emits each function call end immediately and can fail later; zenpi delays executable completion until whole-response success. Source regenerates absent/duplicate call IDs, while target preserves provider parts and stores local correlation separately. Source drops foreign/invalid signatures and may convert thinking to visible text; target refuses incompatible signed history using exact provider/model plus digest. Source merges adjacent same-kind text parts into blocks, retaining the last nonempty signature; target preserves ordered native parts. Source first-candidate/family-name heuristics and broader strict/legacy/image result behavior are not copied wholesale; native target registry remains conservative and finite. Gemini 3 hidden thinking minima are not equivalent to turning provider thinking off. No hosted Google account, OAuth/Vertex path, full upstream suite, real SDK network retry outage or cross-platform cancellation claim. [_] only; directory review remains separate.

## 3.1.20 单文件完整复核与证据复用

当前authority为3.1.20，digest `8d525b351d066ce9b0487a485337647d47233275782e4f4d154423a623fe1645`。本项冻结源与审查义务未变：`packages/ai/src/api/google-generative-ai.ts`，16027 bytes，526 lines，SHA `1395c3f2a90bf701b8b5fc1b6f7de8d323193ed339e07a60630900099a543757`。本轮完整读取1–240与241–526行，对应连续字节[0,7885)、[7885,16027)；原字节快照和每段hash在 `Docs/quality/stage1/ZS1-017/worker-reuse320/input-manifest.json`。

既有 `.ops/source017-behavior-ready/manifest.json` SHA `1c0da066885a3531ba40fdd33c7a23114837470585ba54d69c63a2b0593b7dbe` 与12个冻结artifact已校验。前文完整报告SHA `fa2853bce8507405711530960e8f9cf994271a7bba96c5156dea4dfec5676cc1` 保留为精确前缀，本节只补当前owner、逐分支边界、回放入口和历史证据限制，不制造第二份同等报告、不重跑旧case。原报告中版本较早的目标/取消说明，以本节明确核对部分为准。唯一主审Pi文件仍为本文件；google-shared等仅作被调用上下文，其历史完整审查不提升为新的目录或兄弟项验收。

### 完整源码分支与异常边界

| 源行/入口 | 实际源码行为与证据边界 |
|---|---|
| 1–50 | SDK、cost/clamp、error/headers、event-stream、Google shared与base options依赖；GoogleOptions增加auto/none/any及enabled/budgetTokens/level。类型和注释不执行SDK行为，预算和签名转换依赖明确helper。模块级toolCallCounter在每次无ID或重复ID时递增。 |
| stream:53，setup:80–99 | 返回事件流后异步工作；初始化请求model/provider、pending和全零usage。自定义fetch仅允许缺省或与globalThis.fetch相同对象，否则流内error；apiKey必须存在，不以headers替代认证。createClient与buildParams后await onPayload，非undefined替换整个params，未经再次合并/校验；这和Anthropic强制stream=true的替换处理不同。 |
| SDK建立:97 / chunk loop:104 | retryGoogleRequest只包装generateContentStream初始Promise，随后for-await不在同一retry调用内。保留第一个truthy responseId；只读candidates[0]，未验证其他candidate或modelVersion。源码不独立校验“finish之后不能再有chunk”。 |
| text/thinking:110–172 | `thought === true`才表示thinking，thoughtSignature单独存在不改变文本类型。相邻同类parts合并入currentBlock，类别切换才end旧block/start新block；start创建空内容，然后delta追加。签名helper保留最后非空signature，分别写thinkingSignature或textSignature；这个输出块聚合方式不是native parts逐项保全。 |
| functionCall:174–213 | 先结束currentBlock；缺ID或响应内重复ID生成name+Date.now+counter，本地ID不稳定重放生成。args仅TypeScript cast和nullish默认{}，这里没有运行时object验证。每个functionCall立即发start、一次JSON.stringify全参数delta、end，不等待finishReason；这些end不能直接授权工具执行。text和functionCall是两个独立if，因此同一part同时含二者也会依次处理，区别于严格native互斥校验。 |
| finish/usage:216–243 | finishReason交shared.mapStopReason；只在映射stop且已含工具时转toolUse。每个usageMetadata重建完整Usage，缺字段用`|| 0`，不是累加或逐字段保留；input=prompt-cache，output=candidates+thoughts，cacheRead=cache，cacheWrite=0，reasoning=thoughts，total直接用SDK字段。没有非负/有限/递增/总数一致检查，也未防cache大于prompt导致负input。旧数值fixture仅证明正常100/20/10/5/115算式，不证明异常输入处理。 |
| terminal/catch:246–291 | 结束currentBlock后检查signal.aborted；pending因缺finishReason报错，error/aborted报对应provider stop错误；成功done/end。catch保留partial、移除可能index，使用normalizeProviderError/formatProviderError并按signal区分aborted/error。这不证明源本文件实现任意错误的全面脱敏。 |
| streamSimple:297–336 | 缺apiKey同步throw；无reasoning委托thinking.enabled=false。请求reasoning先clamp再resolve Google level；3 Pro/Flash/Gemma4采用level，其他采用budget。raw stream的maxTokens只在调用者提供时设置，不能把simple helpers的clamp假定为所有raw stream强制上限。 |
| createClient:338 / buildParams:359 | 自定义baseUrl时apiVersion设空，避免SDK重复追加版本；合并User-Agent、model.headers、options.headers，经helper转record。contents由google-shared.convertMessages返回；config承载temperature/maxOutputTokens/systemInstruction/tools/functionCallingMode/thinking/abortSignal。这里的SDK `config` 被SDK序列化为REST `generationConfig`，不是Zenpi在本文件中转换。 |
| 387–416 thinking/signal | enabled且model.reasoning才includeThoughts=true；level优先于budget。disabled且model.reasoning才走disabled config。buildParams发现pre-abort会throw，否则把原signal放config.abortSignal。onPayload整体替换发生在其后，可能替换掉这个config；本函数不会重新强制保留signal。 |
| model family:419–448 | 3 Pro/Flash/Gemma4用lowercase正则/明确latest别名判断；disabled返回LOW或MINIMAL，**省略**includeThoughts，并未显式设置false，亦非承诺远端零思考。旧2.x返回thinkingBudget=0。前文“includeThoughts=false”应按此实际对象纠正。 |
| getThinkingLevel:450–484 | 3 Pro minimal/low→LOW，medium/high→HIGH；Gemma4 minimal/low→MINIMAL，medium/high→HIGH；其他逐级MINIMAL/LOW/MEDIUM/HIGH。名称识别和clamp并非从实际服务协商得到的能力。 |
| getGoogleBudget:486–526 | 自定义budget的值只要不是undefined就直接返回，包括0、负值；2.5-pro默认128/2048/8192/32768，flash-lite为512/2048/8192/24576，flash为128/2048/8192/24576；先匹配lite后flash。budget分支对model.id做大小写敏感includes，未知返回-1动态。没有在此文件验证自定义预算区间。 |

本源没有逐chunk/part/stream.push的signal检查；依赖SDK接收的abortSignal中止迭代，末尾再判abort。原17case只有pre-abort/noHTTP，不能证明取消发生在SDK等待读取或一个chunk中途的最大延迟。options.maxRetries/maxRetryDelayMs/signal由shared.retryGoogleRequest:432传递；该支持文件上下文显示它给带status但无headers的Error补headers属性后交通用retry，不实现body断流续传。本轮不新增网络/取消验证。

继承的通用StreamOptions并非都被这个adapter落实：本文件未调用onResponse，未将timeoutMs配置给createClient/buildParams，也未将samplingParams、cacheRetention、sessionId、transport、metadata作为通用请求参数应用。onPayload是实有入口，但整个params替换的合法性由后续SDK/服务处理；旧fixture仅改maxOutputTokens，没有证明任意替换保持认证、signal或其他不变量。

### 既有实际证据、owner及其限制

源执行owner为 `Docs/quality/stage1/ZS1-017/worker-source-probe/probe.ts`，SHA `aec2b272926225ce8c72505d82953ad95d81fa68d31d105fdb50030af1f17cf1`。它直接import不变源文件，以Bun.serve在127.0.0.1随机端口返回预设SSE，使用fixture-key和fixture模型参数，SDK2.21.0实际发HTTP，未mock import/client/parser。它不是远端Google模型推理；一份Response(reply)中的SSE文本不能证明真实服务端chunk延时、背压或完整SDK错误面。

历史source-native于2026-09-10实际17case通过、20次HTTP，exit0，log SHA `ba0f6e777e3d236bb36d09f9b9708aaf41d75aaff562d8f2e6220194817e7d6e`。包括endpoint/auth/system/output cap、thought与签名、first responseId、正常usage、缺/重ID、早toolcall_end再失败、4种非STOP finish、候选0、signed empty回放与foreign丢弃、2.5 ID-less工具回放/结果合并、thinking预算和3.x最低档、VALIDATED工具schema、onPayload、fetch拒绝/缺认证、pre-abort。没有新增通过数量，没有将未覆盖的缓存异常、mid-stream取消、重试故障、Gemma4预算等加入已测清单。旧上游测试阅读记录不是本轮执行结果。

历史target-native于2026-09-10实际17pass，log SHA `d5373c17720831ea4079d63c58a9f926bbb39ea7d601eceadb5a587c31862472`。执行owner是当时工作树 `tests/stage1_gemini.rs`，既有本地TcpListener/backend测试，也有CARGO_BIN_EXE_zenpi CLI和临时session重启，不是 hosted inference。当前target已有19个test，其中两个terminal取消测试是后来增加的，旧17pass收据不能作为它们的结果。历史五个target owner中4个已变，transport.rs未变；记录的google-shared.ts SHA `7244f109a63e0eb32737ee6910e18d4805c992b8e00c6b58f9830bceb95e2436` 仍相同。这能复用该helper的历史身份，但并未冻结所有传递Pi依赖。详细差异在historical-owner-drift.json。

### 精确replay入口

历史运行目录为 `/Users/wangweiyang/.codex/worktrees/ff51/zenpi`。源argv：`env NODE_PATH=/Users/wangweiyang/.codex/worktrees/ff51/zenpi/.ops/source017-runtime/node_modules bun Docs/quality/stage1/ZS1-017/worker-source-probe/probe.ts`。package-lock锁定SDK版本；本次检查已有安装为2.21.0，没有安装或执行此命令。probe.run→stream/streamSimple→buildParams:359→google-shared.convertMessages:131→SDK；signed empty和tool replay case把旧assistant/工具结果放进context.messages，再捕获真实下一请求contents。支持文件的resolveThoughtSignature只保留同provider/model且base64有效的签名，requiresToolCallId决定何时输出原/规范ID；这些不能误算为本源直接实现所有转换。

历史target argv：`cargo +stable-aarch64-apple-darwin test --locked --test stage1_gemini -- --test-threads=1`。当前CLI helper在 `tests/stage1_gemini.rs:107`，实际命令从`:114`构造，使用--mode headless、临时session.jsonl与隔离ZENPI_HOME；`:415` signed_tool_results_and_restart_use_exact_native_parts创建前后两个CLI，检查三次请求中的原始parts完全相同且ID-less functionResponse不被补ID。当前product replay为core保存annotations/tool_calls/content→Google request_body:251→assistant_parts:185→校验后返回原parts，functionResponse与本地correlation关联。以上是可定位入口，不是本次新执行。

### 当前Zenpi映射与差异

目标片段4个文件共13段由target-references.json给出全文件hash和字节范围，属于映射上下文而非完整目标文件验收。backend.rs:1041/1215/1307分别分派native request_body、endpoint、read_response；core.rs:3855之后保留completion.content、annotations/model和canonical tool_calls，不再是早期“会丢原始历史”的状态。

`src/providers/google.rs:75` validate_parts采用严格字段和类型，text/functionCall必须恰有一种、args必须object、signature必须非空可解码base64、thought必须boolean，并有parts/history上限。`:143` parts_digest是原parts序列化SHA-256完整性记录，**不是**验证Google加密签名真实性。`:152` derive_calls对无ID从response_id/part index派生稳定本地ID，从不写入native part；重复provider ID拒绝，区别于源重生ID。`:185` assistant_parts要求wire/provider、digest、canonical文本/calls一致，带thought/signature跨model拒绝；这与源丢弃外来签名/降级文本不同。

Fold.chunk:490附近拒绝多候选、非0索引和终止后内容；仅STOP能完成，不接受源MAX_TOKENS→length那样的部分成功。usage用u64、checked_add、cache≤prompt、total一致与累计不下降检查；公共input保留含cache的prompt值，source.input扣cache，不能直接比同名input数值。cache/thought额外记录在gemini_finish annotation，公共Usage不等于源完整cost结构。

Fold.finish:584验证STOP、内容、responseId、modelVersion和model capability；Gemini3首工具调用要求签名。read_response:665当前有每个sink event前cancel guard和受限body/line/frame读取，完整finish后才发ToolCallDone/Usage/Completed。源每函数块立即end不代表目标可提前执行。native signature保持原parts顺序，源相邻文本会聚合成输出block，不能声称二者布局完全相同。

当前`:883`和`:888`两个terminal取消测试不在旧17收据中；本轮只定位。源宽松候选/usage/ID/family heuristic、广泛SDK兼容、Vertex/OAuth/legacy schema等不作为Zenpi原样移植要求。本项保持单文件审查，未扩展至ZS1-055或目录验收，也没有跨平台取消、所有重试分支、全SDK或真实模型执行结论。主库、产品源码、旧冻结包与未完成深度搜索候选保持不动。

本次G-STAGE --item ZS1-017实际exit1，structural.ok=true，缺少主库ZS1-017.master.json。失败原log SHA 7006622e80e458e030f0d63b1e5033f6bd6279845b948ab937a3b20ccf1d5fb5 保留；范围与引用结构通过不等于主控语义验收，未写验收标记。

## 3.1.20 当前主库差异复核增量（2026-09-12；provisional）

本次已有完整 ready，因此复用 `.ops/source017-reuse320-ready`（manifest SHA-256 `a7875c319828ff456d97e50a5477c930fc0f9473745f2095169ed96c399bc0fd`），不另造一份同等成果。该包全部 40 个 payload、单独 patch 和原 candidate.patch 均校验；已有报告 20705 字节 / 89 行、SHA-256 `555192ff2fb817aa4a7aa6e61d80da14de9214b4cbdce6f61478a5f140303a4b` 保留为本报告的精确前缀。历史旧措辞的纠正和证据限制继续有效。

冻结 Pi 源仍为 16027 字节 / 526 行、`1395c3f2a90bf701b8b5fc1b6f7de8d323193ed339e07a60630900099a543757`。此次为了对照增量，重新连续完整阅读 1–265 与 266–526 行，字节覆盖 [0,8407)、[8407,16027)，记录在 `Docs/quality/stage1/ZS1-017/worker-main-delta320/source-coverage.json`。这不是新运行测试。没有执行 SDK、Bun、Cargo、HTTP、PTY 或网络，也未安装依赖。

参照主库已经接受的 015/016 报告中 controller contract、current mapping 和 acceptance boundary 章节：类型契约不等于实现；同名事件不等于相同事件顺序；历史 fixture 通过不覆盖当前所有代码；只接受单源文件理解不等于接受 provider 产品项。两份真实 master receipt 的 complete=true、manual_review.decision=accepted、source_hash 和 report artifact hash 已检查；仅用作格式和证据分层参考，不复制它们的 accepted 决定给本项，也不把保留的历史叙述算作本轮新阅读或运行。

### 当前差异确实在哪里

采集时间和六个必要目标上下文的全文件身份见 baseline-state.json；13 段实际读取的上下文及精确字节范围见 target-references.json，均只用于映射，不声称目标整文件验收。

| 目标 | 上一轮至当前主库 | 对本源映射的影响 |
|---|---|---|
| src/providers/google.rs | 29333 字节 / 759 行，`f0d56a364cda38b5a10bff74e68057ad76bf539000c883ee6e820c2105081890`，完全未变 | 不能宣称本轮新增 Gemini 行为或新增通过测试。 |
| src/backend.rs | 98741 字节，`d11105597a7e4260c67c9ce7796394687b4219617a6ebfdfeca637ae469c3357`，未变 | native request/endpoint/read_response 分派和 retry owner 沿用上一轮映射。 |
| src/backend/transport.rs | 21483 字节，`d166d173c77aec88ccee1c248b74424a20c9783b6f4cada95fc762cbf3fe1cfd`，未变 | 取消实现的平台边界仍存在。 |
| tests/stage1_gemini.rs | 35033 字节 / 971 行，`0b89fa8b1587cfbd1ed36fb53b7280d79586acd3323da1e2b4280cb033d85367`，未变 | 当前有 19 个测试定义，旧 target-native 的 17 pass 仍不能覆盖后来两个 terminal cancel case。 |
| src/core.rs | 从 `6a881cc8eb1193dfbe4d4b06e71d6d28b3b78f4fe00bc836c1ea74c2f2c60b63` / 274600 字节变为 `52311b129c0bb467abac36de216f5bc97bf3c4c42d03dcd6170a717339c2a869` / 278737 字节 | diff 是新增会话准备与替换会话 commit/cancel 路径。原 3855–3882 工具调用、原文、annotations/model 保存片段完全不变。本轮不验收新会话行为，也不由此推断 Gemini replay 新增保障。 |
| src/providers/registry.rs | 当前15905字节，`cf229a62681933e7c1b4058c4d2fada41dff4fcd05c4cd300e18accfe245b944`；与已接受015的上下文同一身份 | 注册表提供明确的 gemini-2.5-flash 能力/预算。provider 内存在 Gemini3 检查分支不等于默认开放所有 3.x/Gemma4 模型。 |

旧 target-references 的全部 13 段在当前主库仍逐字节相同，包括 core 保存片段；target-drift.json 记录每项结果。core-context-delta.patch 仅为必要 caller 差异证据，不是产品补丁，不应用。主库映射报告当前仍不存在；新候选提供唯一报告和依赖证据，旧包不改。

### 状态、事件与工具的完整合同对照

| 边界 | 冻结源实际行为 | 当前 Zenpi 已实现的对应及明确差异 |
|---|---|---|
| setup / start | 源53–99：raw stream 返回事件容器，异步 auth/fetch/build/onPayload/SDK 建流错误进入 error；streamSimple297–307 的缺 key 则同步 throw。start 在 SDK 建流 Promise 成功后才发布。 | backend1041/1215/1307 分派原生 Google 请求/endpoint/parser；目标 ResponseCreated 从第一份有效解析数据发出。这不是源共享 partial/start 事件协议的逐字实现。 |
| partial text / thinking | 源104–172：只取候选0；thought===true 决定 thinking，signature 本身不改变文本类型；同类相邻文本合并块，最后非空签名保留；partial 为同一可变 output 对象。 | Google Fold453–540：拒绝多候选、非零 index 与终止后候选；逐个保留 native parts，发 owned TextDelta/ReasoningDelta。目标没有复制 source contentIndex/start/end 的三段式内容块合同。 |
| tool readiness | 源174–213：缺/重 ID 用名称、时间和模块计数器生成；args 仅 cast/nullish 默认；每个 functionCall 立即 start/delta/end，之后还可能流失败。 | 目标 parts/args 校验和 derive_calls 使用独立本地相关 ID，provider parts 原样保留；Fold.finish584–664 在 STOP、identity、parts 和 capability 校验后才发 ToolCallDone。delta 不授权执行。源 early end 后缺 finish 的失败已被旧实际 case 证明；本轮没有重跑。 |
| terminal / partial error | 源216–291：STOP 经工具判断变 toolUse；MAX_TOKENS 经 shared 映射为 length；缺 finish 报错；catch保留partial，并按外部 signal 将 stopReason 设 aborted/error。 | 目标仅 STOP 可完成；MAX_TOKENS 仍失败。responseId 必须最终存在，modelVersion 必须匹配请求模型或允许的数字后缀；源只保存第一个非空 responseId，不检查后续身份变化，也不读取 modelVersion。本轮静态确认这些差异，不把源的宽松路径当成必须移植的安全边界。 |
| usage / cost | 源225–243：每次 usageMetadata 替换全套计数，input=prompt-cache、output=candidates+thoughts、total取服务字段，calculateCost另算价格；缺项通过 `||0` 处理，无本地数值一致检查。 | 目标548–583使用u64、checked_add、cache≤prompt、total一致及不下降检查；公共input含cache，output含thoughts，额外信息在gemini_finish annotation。目标Usage可缺省，存在字段才执行相应计数校验；并非与源cache/cost完整结构等价。 |
| signed history / replay | 源参数由google-shared.convertMessages转换；旧完整审查与实际case证明同provider/model签名保留、外来签名丢弃/思考降级，工具结果相邻合并。 | 当前assistant_parts185–250核对wire/provider、序列化digest、canonical text/calls，opaque history跨model拒绝；core3855–3882保存原文、annotations、model和canonical calls供下一请求使用。digest证明本地数据一致性，不证明Google密码学签名真实性。源和目标并不采用同样的历史降级策略。 |
| cancel / error / retry | 源buildParams403–410传signal，只有pre-abort检查；逐chunk循环依赖SDK中止，结束后再次检查。onPayload整体替换可改变config。retryGoogleRequest只包建流Promise，不包body迭代。normalize/format helper不是本文件全局脱敏证明。 | 目标read_response665–744在读循环、结束和每个sink事件之前检查取消；backend retry1587–1696要求尚未发任何事件、可重试错误、次数预算且不是semantic compaction。send_json58–103有请求私有取消标志/工作线程join，不能据此宣称任何平台任何DNS调用立即中止。未发布工具完成的错误路径不会变成可执行工具。 |

### 思考、工具配置与未闭合路径

当前 request_body251–437 只接受已支持请求形状，并约束历史完整性、首尾 user/工具响应、附件数/字节、输出上限和最终32 MiB请求大小；它不直接透传源SDK options。

- **明确已实现**：原生 generateContent/streamGenerateContent、systemInstruction、parts/inlineData 图片、functionDeclarations.parametersJsonSchema、functionResponse 成功/错误、本地相关ID与原provider ID分离、原native历史恢复、受限JSON/SSE、STOP之后工具完成、usage一致性检查。以上为当前源码映射；实际执行支撑仍仅引用旧收据限定的版本与案例。
- **思考配置覆盖较窄**：validate_effort49–56只支持 gemini-2.5-flash 的 none/minimal/low/medium/high；预算分别0/128/2048/8192/24576。registry255–286对应这一确切模型。源419–526还包含3 Pro/Flash、Gemma4、2.5 Pro/Lite、custom budgets与未知动态-1；目标未提供这些完整映射。Gemini3首函数签名检查是响应校验分支，不是这些模型/思考配置已默认可用的证明。源3.x“off”省略includeThoughts并用最低支持level，仍不能解读为远端零思考。
- **工具与通用options尚不等价**：源auto/none/any以及支持strict时的VALIDATED配置未完整映射到目标request_body；源温度、onPayload任意替换和SDK/headers对象接口也没有同形公共入口。目标显式拒绝structured output、非semantic_compaction metadata、远程图片引用和不支持附件类型。source继承的onResponse/timeoutMs/samplingParams等并非本adapter自动实现。应分别记录为未实现的等价路径或有意收窄，不能由类型015的字段存在推出已完成，也不能据此扩展当前产品验收范围。
- **真实未闭合的取消平台路径**：transport411–466对非macOS hostname仍走DefaultResolver；313–328非Unix connect走有限connect_timeout，没有Unix poll取消机制。本源017的旧pre-abort案例和目标17项历史测试都不能证明这些路径已解决。本轮没有重跑或新增任何平台取消验证。
- **仍缺新的执行证据**：当前19-test target中的terminal取消边界虽有源码断言（880–971，检查取消后late为空、后续ready数量及无Completed），两项不在历史17 pass里；本次严格静态，只记录其断言内容，不宣称通过。源异常usage、SDK故障重试、mid-stream取消、任意onPayload替换、完整thinking族和真实Google模型行为也未由旧17case全面验证。

这些是本源理解与当前映射的边界，不等于把每个源宽松/SDK兼容分支列为Zenpi必须照搬的需求。本项不改产品；必要功能是否收口仍由蓝图对应product owner与主控独立验证决定。

### 证据、离线门禁与交接

历史source-native保持17个case、20次loopback HTTP、exit0，日志SHA `ba0f6e777e3d236bb36d09f9b9708aaf41d75aaff562d8f2e6220194817e7d6e`；target-native保持17pass、exit0，日志SHA `d5373c17720831ea4079d63c58a9f926bbb39ea7d601eceadb5a587c31862472`。这些日期仍是2026-09-10，本轮新增运行测试数为0。旧probe/lock/receipt/log和旧verifier原字节保留；未修改旧verifier的目标hash来制造当前通过。当前core发生文件级变化，用新的增量validator绑定当前上下文。

新verify_delta.py只执行离线源范围/报告/上下文/历史证据核对与补丁正逆检查；通过不等于语义主控验收。G-STAGE --item ZS1-017仍真实退出1，structural=true，原因是主库缺017.master.json；失败日志原样保存。71个先前顶层ready包及产品tracked文件均保持原字节。准备时一次错误引用src/registry.rs已记录为FileNotFound，随后通过文件名定位实际src/providers/registry.rs；不把失败准备当作成功检查。

唯一更新的映射报告仍是本文件。输出独立provisional ready，保留旧报告精确前缀及可解析引用；不写017、Gemini product、兄弟文件或目录验收标记。
