
## 3.1.20 当前主库差异复核增量（2026-09-12；provisional）

本次已有完整 ready，因此复用 `.ops/source017-reuse320-ready`（manifest SHA-256 `a7875c319828ff456d97e50a5477c930fc0f9473745f2095169ed96c399bc0fd`），不另造一份同等成果。该包全部 40 个 payload、单独 patch 和原 candidate.patch 均校验；已有报告 20705 字节 / 89 行、SHA-256 `555192ff2fb817aa4a7aa6e61d80da14de9214b4cbdce6f61478a5f140303a4b` 保留为本报告的精确前缀。历史旧措辞的纠正和证据限制继续有效。

冻结 Pi 源仍为 16027 字节 / 526 行、`1395c3f2a90bf701b8b5fc1b6f7de8d323193ed339e07a60630900099a543757`。此次为了对照增量，重新连续完整阅读 1–265 与 266–526 行，字节覆盖 [0,8407)、[8407,16027)，记录在 `Docs/quality/stage1/ZS1-017/worker-main-delta320/source-coverage.json`。这不是新运行测试。没有执行 SDK、Bun、Cargo、HTTP、PTY 或网络，也未安装依赖。

参照主库已经接受的 015/016 报告中 controller contract、current mapping 和 acceptance boundary 章节：类型契约不等于实现；同名事件不等于相同事件顺序；历史 fixture 通过不覆盖当前所有代码；只接受单源文件理解不等于接受 provider 产品项。两份真实 master receipt 的 complete=true、manual_review.decision=accepted、source_hash 和 report artifact hash 已检查；仅用作格式和证据分层参考，不复制它们的 accepted 决定给本项，也不把保留的历史叙述算作本轮新阅读或运行。

### 当前差异确实在哪里

采集时间和六个必要目标上下文的全文件身份见 baseline-state.json；13 段实际读取的上下文及精确字节范围见 target-references.json，均只用于映射，不声称目标整文件验收。

| 目标 | 上一轮至当前主库 | 对本源映射的影响 |
|---|---|---|
| src/providers/google.rs | 29333 字节 / 759 行，`f0d56a364cda38b5a10bff74e68057ad76bf539000c883ee6e820c2105081890`，完全未变 | 不能宣称本轮新增 Gemini 行为或新增通过测试。 |
| src/backend.rs | 98741 字节，`d11105597a7e4260c67c9ce7796394687b4219617a6ebfdfeca637ae469c3357`，未变 | native request/endpoint/read_response 分派和 retry owner 沿用上一轮映射。 |
| src/backend/transport.rs | 21483 字节，`d166d173c77aec88ccee1c248b74424a20c9783b6f4cada95fc762cbf3fe1cfd`，未变 | 取消实现的平台边界仍存在。 |
| tests/stage1_gemini.rs | 35033 字节 / 971 行，`0b89fa8b1587cfbd1ed36fb53b7280d79586acd3323da1e2b4280cb033d85367`，未变 | 当前有 19 个测试定义，旧 target-native 的 17 pass 仍不能覆盖后来两个 terminal cancel case。 |
| src/core.rs | 从 `6a881cc8eb1193dfbe4d4b06e71d6d28b3b78f4fe00bc836c1ea74c2f2c60b63` / 274600 字节变为 `52311b129c0bb467abac36de216f5bc97bf3c4c42d03dcd6170a717339c2a869` / 278737 字节 | diff 是新增会话准备与替换会话 commit/cancel 路径。原 3855–3882 工具调用、原文、annotations/model 保存片段完全不变。本轮不验收新会话行为，也不由此推断 Gemini replay 新增保障。 |
| src/providers/registry.rs | 当前15905字节，`cf229a62681933e7c1b4058c4d2fada41dff4fcd05c4cd300e18accfe245b944`；与已接受015的上下文同一身份 | 注册表提供明确的 gemini-2.5-flash 能力/预算。provider 内存在 Gemini3 检查分支不等于默认开放所有 3.x/Gemma4 模型。 |

旧 target-references 的全部 13 段在当前主库仍逐字节相同，包括 core 保存片段；target-drift.json 记录每项结果。core-context-delta.patch 仅为必要 caller 差异证据，不是产品补丁，不应用。主库映射报告当前仍不存在；新候选提供唯一报告和依赖证据，旧包不改。

### 状态、事件与工具的完整合同对照

| 边界 | 冻结源实际行为 | 当前 Zenpi 已实现的对应及明确差异 |
|---|---|---|
| setup / start | 源53–99：raw stream 返回事件容器，异步 auth/fetch/build/onPayload/SDK 建流错误进入 error；streamSimple297–307 的缺 key 则同步 throw。start 在 SDK 建流 Promise 成功后才发布。 | backend1041/1215/1307 分派原生 Google 请求/endpoint/parser；目标 ResponseCreated 从第一份有效解析数据发出。这不是源共享 partial/start 事件协议的逐字实现。 |
| partial text / thinking | 源104–172：只取候选0；thought===true 决定 thinking，signature 本身不改变文本类型；同类相邻文本合并块，最后非空签名保留；partial 为同一可变 output 对象。 | Google Fold453–540：拒绝多候选、非零 index 与终止后候选；逐个保留 native parts，发 owned TextDelta/ReasoningDelta。目标没有复制 source contentIndex/start/end 的三段式内容块合同。 |
| tool readiness | 源174–213：缺/重 ID 用名称、时间和模块计数器生成；args 仅 cast/nullish 默认；每个 functionCall 立即 start/delta/end，之后还可能流失败。 | 目标 parts/args 校验和 derive_calls 使用独立本地相关 ID，provider parts 原样保留；Fold.finish584–664 在 STOP、identity、parts 和 capability 校验后才发 ToolCallDone。delta 不授权执行。源 early end 后缺 finish 的失败已被旧实际 case 证明；本轮没有重跑。 |
| terminal / partial error | 源216–291：STOP 经工具判断变 toolUse；MAX_TOKENS 经 shared 映射为 length；缺 finish 报错；catch保留partial，并按外部 signal 将 stopReason 设 aborted/error。 | 目标仅 STOP 可完成；MAX_TOKENS 仍失败。responseId 必须最终存在，modelVersion 必须匹配请求模型或允许的数字后缀；源只保存第一个非空 responseId，不检查后续身份变化，也不读取 modelVersion。本轮静态确认这些差异，不把源的宽松路径当成必须移植的安全边界。 |
| usage / cost | 源225–243：每次 usageMetadata 替换全套计数，input=prompt-cache、output=candidates+thoughts、total取服务字段，calculateCost另算价格；缺项通过 `||0` 处理，无本地数值一致检查。 | 目标548–583使用u64、checked_add、cache≤prompt、total一致及不下降检查；公共input含cache，output含thoughts，额外信息在gemini_finish annotation。目标Usage可缺省，存在字段才执行相应计数校验；并非与源cache/cost完整结构等价。 |
| signed history / replay | 源参数由google-shared.convertMessages转换；旧完整审查与实际case证明同provider/model签名保留、外来签名丢弃/思考降级，工具结果相邻合并。 | 当前assistant_parts185–250核对wire/provider、序列化digest、canonical text/calls，opaque history跨model拒绝；core3855–3882保存原文、annotations、model和canonical calls供下一请求使用。digest证明本地数据一致性，不证明Google密码学签名真实性。源和目标并不采用同样的历史降级策略。 |
| cancel / error / retry | 源buildParams403–410传signal，只有pre-abort检查；逐chunk循环依赖SDK中止，结束后再次检查。onPayload整体替换可改变config。retryGoogleRequest只包建流Promise，不包body迭代。normalize/format helper不是本文件全局脱敏证明。 | 目标read_response665–744在读循环、结束和每个sink事件之前检查取消；backend retry1587–1696要求尚未发任何事件、可重试错误、次数预算且不是semantic compaction。send_json58–103有请求私有取消标志/工作线程join，不能据此宣称任何平台任何DNS调用立即中止。未发布工具完成的错误路径不会变成可执行工具。 |

### 思考、工具配置与未闭合路径

当前 request_body251–437 只接受已支持请求形状，并约束历史完整性、首尾 user/工具响应、附件数/字节、输出上限和最终32 MiB请求大小；它不直接透传源SDK options。

- **明确已实现**：原生 generateContent/streamGenerateContent、systemInstruction、parts/inlineData 图片、functionDeclarations.parametersJsonSchema、functionResponse 成功/错误、本地相关ID与原provider ID分离、原native历史恢复、受限JSON/SSE、STOP之后工具完成、usage一致性检查。以上为当前源码映射；实际执行支撑仍仅引用旧收据限定的版本与案例。
- **思考配置覆盖较窄**：validate_effort49–56只支持 gemini-2.5-flash 的 none/minimal/low/medium/high；预算分别0/128/2048/8192/24576。registry255–286对应这一确切模型。源419–526还包含3 Pro/Flash、Gemma4、2.5 Pro/Lite、custom budgets与未知动态-1；目标未提供这些完整映射。Gemini3首函数签名检查是响应校验分支，不是这些模型/思考配置已默认可用的证明。源3.x“off”省略includeThoughts并用最低支持level，仍不能解读为远端零思考。
- **工具与通用options尚不等价**：源auto/none/any以及支持strict时的VALIDATED配置未完整映射到目标request_body；源温度、onPayload任意替换和SDK/headers对象接口也没有同形公共入口。目标显式拒绝structured output、非semantic_compaction metadata、远程图片引用和不支持附件类型。source继承的onResponse/timeoutMs/samplingParams等并非本adapter自动实现。应分别记录为未实现的等价路径或有意收窄，不能由类型015的字段存在推出已完成，也不能据此扩展当前产品验收范围。
- **真实未闭合的取消平台路径**：transport411–466对非macOS hostname仍走DefaultResolver；313–328非Unix connect走有限connect_timeout，没有Unix poll取消机制。本源017的旧pre-abort案例和目标17项历史测试都不能证明这些路径已解决。本轮没有重跑或新增任何平台取消验证。
- **仍缺新的执行证据**：当前19-test target中的terminal取消边界虽有源码断言（880–971，检查取消后late为空、后续ready数量及无Completed），两项不在历史17 pass里；本次严格静态，只记录其断言内容，不宣称通过。源异常usage、SDK故障重试、mid-stream取消、任意onPayload替换、完整thinking族和真实Google模型行为也未由旧17case全面验证。

这些是本源理解与当前映射的边界，不等于把每个源宽松/SDK兼容分支列为Zenpi必须照搬的需求。本项不改产品；必要功能是否收口仍由蓝图对应product owner与主控独立验证决定。

### 证据、离线门禁与交接

历史source-native保持17个case、20次loopback HTTP、exit0，日志SHA `ba0f6e777e3d236bb36d09f9b9708aaf41d75aaff562d8f2e6220194817e7d6e`；target-native保持17pass、exit0，日志SHA `d5373c17720831ea4079d63c58a9f926bbb39ea7d601eceadb5a587c31862472`。这些日期仍是2026-09-10，本轮新增运行测试数为0。旧probe/lock/receipt/log和旧verifier原字节保留；未修改旧verifier的目标hash来制造当前通过。当前core发生文件级变化，用新的增量validator绑定当前上下文。

新verify_delta.py只执行离线源范围/报告/上下文/历史证据核对与补丁正逆检查；通过不等于语义主控验收。G-STAGE --item ZS1-017仍真实退出1，structural=true，原因是主库缺017.master.json；失败日志原样保存。71个先前顶层ready包及产品tracked文件均保持原字节。准备时一次错误引用src/registry.rs已记录为FileNotFound，随后通过文件名定位实际src/providers/registry.rs；不把失败准备当作成功检查。

唯一更新的映射报告仍是本文件。输出独立provisional ready，保留旧报告精确前缀及可解析引用；不写017、Gemini product、兄弟文件或目录验收标记。
