from pathlib import Path
import hashlib,json,os,runpy,sys
E=Path(__file__).resolve().parent;R=E.parents[4];MAIN=Path('/Users/wangweiyang/GitHub/zenpi');sha=lambda b:hashlib.sha256(b).hexdigest();frozen='--frozen' in sys.argv
state=json.loads((E/'baseline-state.json').read_text());m=json.loads((E/'source-coverage.json').read_text());source=(E/'google-generative-ai.ts').read_bytes()
assert len(source)==16027 and len(source.splitlines())==526 and sha(source)==m['sha256']=='1395c3f2a90bf701b8b5fc1b6f7de8d323193ed339e07a60630900099a543757'
parts=[];ranges=[]
for c in m['ordered_read_chunks']:
 b=(R/c['artifact']).read_bytes();assert b==source[c['byte_start']:c['byte_end']] and sha(b)==c['sha256'];parts.append(b);ranges.append([c['byte_start'],c['byte_end']])
assert b''.join(parts)==source
assert len(json.loads((E/'symbol-inventory.json').read_text()))==10
prior=json.loads((E/'prior-manifest.json').read_text());assert sha((E/'prior-manifest.json').read_bytes())=='a7875c319828ff456d97e50a5477c930fc0f9473745f2095169ed96c399bc0fd'
assert sha((E/'prior-candidate.patch').read_bytes())==prior['patch_sha256']
report_meta=json.loads((E/'report-final.json').read_text());report=(R/report_meta['path']).read_bytes();old=(E/'prior-report.md').read_bytes()
assert report==old+(E/'supplement.md').read_bytes() and sha(old)=='555192ff2fb817aa4a7aa6e61d80da14de9214b4cbdce6f61478a5f140303a4b'
assert sha(report)==report_meta['sha256'] and len(report)==report_meta['bytes']
for row in json.loads((E/'reused-payloads.json').read_text()):
 b=old if row['path']==report_meta['path'] else (R/row['path']).read_bytes()
 assert sha(b)==row['sha256'] and len(b)==row['bytes'],row['path']
old_ev=R/'Docs/quality/stage1/ZS1-017/worker-source-probe'
for stem in ['source-native','target-native']:
 rec=json.loads((old_ev/(stem+'.json')).read_text());b=(old_ev/(stem+'.log')).read_bytes()
 assert rec['exit_code']==0 and len(b)==rec['bytes'] and sha(b)==rec['sha256']
scenarios=json.loads((old_ev/'source-native.log').read_text());assert len(scenarios['scenarios'])==17 and scenarios['http_requests']==20
assert all(x['status']=='pass' for x in scenarios['scenarios'])
assert '17 passed; 0 failed' in (old_ev/'target-native.log').read_text()
refs=json.loads((E/'target-references.json').read_text());count=0
for row in refs:
 if not frozen:
  data=(MAIN/row['path']).read_bytes();assert len(data)==row['bytes'] and sha(data)==row['sha256'],row['path']
 for c in row['excerpts']:
  b=(R/c['artifact']).read_bytes();assert sha(b)==c['sha256'];count+=1
  if not frozen:assert b==data[c['byte_start']:c['byte_end']]
assert all(x['previous_excerpts_still_byte_identical'] for x in json.loads((E/'target-drift.json').read_text()))
for n in ['015','016']:
 rec=json.loads((E/f'accepted-{n}-receipt.json').read_text());b=(E/f'accepted-{n}-report.md').read_bytes()
 assert rec['complete'] and rec['manual_review']['decision']=='accepted' and rec['role']=='master'
 a=next(x for x in rec['artifacts'] if x['path'].endswith('_learn.md'))
 assert sha(b)==a['sha256'] and len(b)==a['bytes']
sys.path.insert(0,str(E/'gate-context/tools'));g=runpy.run_path(str(E/'gate-context/tools/validate_stage1_blueprint.py'))
bp=g['parse']((E/'gate-context/Docs/stage_1_v3_pi_mono_blueprint.md').read_text());f=bp.files['ZS1-017']
assert f.path==m['path'] and f.sha256==m['sha256'] and bp.requirement=='8d525b351d066ce9b0487a485337647d47233275782e4f4d154423a623fe1645'
g['check_ranges'](ranges,len(source));g['artifact'](R,{'path':report_meta['path'],'bytes':len(report),'sha256':sha(report)})
rec=json.loads((E/'gstage-main.json').read_text());log=(E/'gstage-main.log').read_bytes();assert rec['exit_code']==1 and sha(log)==rec['sha256'];result=json.loads(log);assert result['structural']['ok'] and not result['ok']
if not frozen:
 assert Path('/Users/wangweiyang/GitHub/pi-mono/packages/ai/src/api/google-generative-ai.ts').read_bytes()==source
 assert not (MAIN/report_meta['path']).exists()
 for p,d in state['prior_ready_files'].items():assert sha((R/p).read_bytes())==d,p
 for p,d in state['tracked_files'].items():assert sha((R/p).read_bytes())==d,p
 assert os.environ.get('HOME')==state['HOME'] and os.environ.get('CODEX_HOME')==state['CODEX_HOME']
print(json.dumps({'ok':True,'frozen':frozen,'G_FILE':'source identity / contiguous ranges / report artifact checks; not semantic master acceptance','source_bytes':len(source),'source_lines':526,'read_ranges':ranges,'source_callables':10,'old_payloads':40,'historical_source_cases':17,'historical_target_tests':17,'new_runtime_tests':0,'current_target_files':len(refs),'context_excerpts':count,'report_sha256':sha(report),'report_bytes':len(report),'old_report_prefix_unchanged':True,'prior_ready_files_checked':0 if frozen else len(state['prior_ready_files']),'gstage_exit':1,'acceptance':False},indent=2))
