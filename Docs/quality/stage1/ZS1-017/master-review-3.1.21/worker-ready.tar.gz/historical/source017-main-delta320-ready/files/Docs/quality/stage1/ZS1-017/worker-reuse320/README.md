# ZS1-017 reuse supplement / authority3.1.20

Source google-generative-ai.ts unchanged:16027B/526lines SHA1395c3f2a90bf701b8b5fc1b6f7de8d323193ed339e07a60630900099a543757. Entire source read as [0,7885),[7885,16027). Prior complete report remains exact prefix; only current-authority mappings and semantic/fixture/replay clarifications appended.

Reused immutable source017-behavior-ready manifest1c0da066885a3531ba40fdd33c7a23114837470585ba54d69c63a2b0593b7dbe and12original artifacts. Historical17source scenarios/20local HTTP and17target tests are not rerun. Actual SDK local transport with synthetic responses is not hosted model inference. Existing google-shared.ts historical hash remains equal; the full transitive Pi dependency graph was not frozen. Five target owner hashes:4changed, transport unchanged. Current19tests are not represented by the old17pass receipt.

New evidence binds4target files/13excerpts and complete source bytes. verify_reuse.py uses actual G-FILE range/artifact/source checks, preserves old package/report prefix, and validates historical receipt/log hashes plus current target excerpts. G-STAGE read-only against main returns structural.ok=true, exit1 missing017master receipt. No fabricated acceptance, installation, new runtime cases, product mutations, directory expansion, or depth-search probe.

Main lacks the report and old source-probe artifacts: final package adds updated full report and bundles11old evidence files byte-exactly, without re-generating them or requiring an old patch against an absent report. The old frozen package stays unchanged. Package authority metadata is3.1.20/digest8d525b351d066ce9b0487a485337647d47233275782e4f4d154423a623fe1645; source freeze/obligation unchanged from the earlier evidence.
