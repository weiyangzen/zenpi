# ZS1-017 source behavior [_]

17 passing source scenarios using unchanged adapter and actual @google/genai@2.21.0 over private loopback HTTP/SSE. No mocked imports. Existing source report reused by frozen source_audit hash. Exact source-native and target-native receipts/logs remain separate. package.json/package-lock/install.log reproduce isolated SDK dependencies; NODE_PATH is explicit in the command. No source edits, external provider requests, real credentials, static-typecheck or upstream full-suite claim. Non-macOS DNS and non-Unix connect remain incomplete.
