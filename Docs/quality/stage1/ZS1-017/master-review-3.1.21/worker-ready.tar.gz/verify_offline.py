"""ZS1-017 package-only audit; optional original-machine --live check. No subprocess/network."""
from pathlib import Path
import csv
import hashlib
import json
import re
import sys

root = Path(sys.argv[1]).resolve()
live = '--live' in sys.argv[2:]
checks = []
report = 'Docs/learn/stage1_pi_mono/files/packages/ai/src/api/google-generative-ai.ts_learn.md'
source = 'packages/ai/src/api/google-generative-ai.ts'
def load(p): return json.loads(p.read_text())
def ident(p):
    b = p.read_bytes()
    return {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}
def match(p, row): return p.is_file() and ident(p) == {k: row[k] for k in ('bytes', 'sha256')}
def check(n, v, detail=None): checks.append({'name': n, 'passed': bool(v), 'detail': detail})
def rows(p):
    with p.open() as f: return list(csv.DictReader(f, delimiter='\t'))
def apply_data(base, patch, reverse=False):
    """Reconstruct unified text hunks in memory only, with exact preimage checks."""
    lines = base.splitlines(True); out = []; pos = 0
    pl = patch.splitlines(True); i = 0; hunks = 0
    while i < len(pl):
        m = re.match(rb'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@', pl[i])
        if not m:
            i += 1; continue
        a, ac, b, bc = m.groups(); ac = int(ac or b'1'); bc = int(bc or b'1')
        old_start, old_count = (int(b), bc) if reverse else (int(a), ac)
        new_count = ac if reverse else bc
        begin = old_start - 1 if old_count else old_start
        assert pos <= begin <= len(lines)
        out.extend(lines[pos:begin]); pos = begin; consumed = produced = 0; i += 1
        while i < len(pl) and pl[i][:1] in (b' ', b'+', b'-'):
            tag = pl[i][:1]; payload = pl[i][1:]; i += 1
            if i < len(pl) and pl[i].startswith(b'\\ No newline'):
                payload = payload[:-1] if payload.endswith(b'\n') else payload; i += 1
            if reverse: tag = {b'+': b'-', b'-': b'+', b' ': b' '}[tag]
            if tag in (b' ', b'-'):
                assert pos < len(lines) and lines[pos] == payload
                pos += 1; consumed += 1
            if tag in (b' ', b'+'): out.append(payload); produced += 1
        assert consumed == old_count and produced == new_count
        hunks += 1
    assert hunks
    out.extend(lines[pos:]); return b''.join(out)

inputs = load(root/'input-inventory.json')
check('all captured input identities', all(match(root/r['kind']/r['path'], r) for r in inputs))
src = (root/'source'/source).read_bytes()
check('frozen source 16027 bytes 526 lines', len(src)==16027 and len(src.splitlines())==526 and hashlib.sha256(src).hexdigest()=='1395c3f2a90bf701b8b5fc1b6f7de8d323193ed339e07a60630900099a543757')
ledger = load(root/'reading-ledger.json'); cursor = 0; full = True
for r in ledger:
    a,b=r['byte_range']; ls=src.splitlines(True); x,z=r['line_range']
    full &= a==cursor and src[a:b]==b''.join(ls[x-1:z]) and match(root/r['excerpt'],r) and (root/r['excerpt']).read_bytes()==src[a:b]
    cursor=b
check('new source reading contiguous complete ranges', full and cursor==len(src) and len(ledger)==3)
ctx=load(root/'context-reading-ledger.json')
check('all newly read context ranges exact',all((root/r['path']).read_bytes()[slice(*r['byte_range'])]==(root/r['excerpt']).read_bytes() and match(root/r['excerpt'],r) and b''.join((root/r['path']).read_bytes().splitlines(True)[r['line_range'][0]-1:r['line_range'][1]])==(root/r['excerpt']).read_bytes() for r in ctx))
history=load(root/'historical-inventory.json')
for item in history:
    p=root/'historical'/item['name']; m=load(p/'manifest.json')
    check('exact original physical package '+item['name'],match(p/'manifest.json',item['manifest']) and all(match(p/r['path'],r) for r in item['artifacts']) and {str(q.relative_to(p))for q in p.rglob('*')if q.is_file()}=={r['path']for r in item['artifacts']})
    check('original payload identities '+item['name'],all(match(p/'files'/r['path'],r) and match(p/'base'/r['path'],{'bytes':r['base_bytes'],'sha256':r['base_sha256']})for r in m['files']))
    check('original combined patch and runner '+item['name'],match(p/'candidate.patch',{'bytes':m['patch_bytes'],'sha256':m['patch_sha256']})and ident(p/'run_candidate_probe.py')['sha256']==m['runner_sha256'])
    patches=[]; valid=True
    for r in m['files']:
        patch=p/r.get('patch_file','patches/'+r['path'].replace('/','__')+'.patch')
        pb=patch.read_bytes(); patches.append(pb)
        base=(p/'base'/r['path']).read_bytes(); target=(p/'files'/r['path']).read_bytes()
        try: valid &= hashlib.sha256(pb).hexdigest()==r['patch_sha256'] and apply_data(base,pb)==target and apply_data(target,pb,True)==base
        except (AssertionError,ValueError): valid=False
    check('in-memory forward reverse all patches '+item['name'],valid)
    check('combined patch exact constituent sequence '+item['name'],b''.join(patches)==(p/'candidate.patch').read_bytes())
beh=root/'historical/source017-behavior-ready'; reuse=root/'historical/source017-reuse320-ready'; delta=root/'historical/source017-main-delta320-ready'
check('three old report prefix chain', (reuse/'files'/report).read_bytes().startswith((beh/'files'/report).read_bytes()) and (delta/'files'/report).read_bytes().startswith((reuse/'files'/report).read_bytes()))
probe_path='Docs/quality/stage1/ZS1-017/worker-source-probe'
probe=beh/'files'/probe_path
check('11 original behavior artifacts identical across all revisions',all((beh/'files'/r['path']).read_bytes()==(reuse/'files'/r['path']).read_bytes()==(delta/'files'/r['path']).read_bytes() for r in load(beh/'manifest.json')['files'] if r['path']!=report))
for n in ['source-native','target-native']:
    receipt=load(probe/(n+'.json'))
    check('historical actual command receipt '+n,receipt['exit_code']==0 and receipt['started_at'].startswith('2026-09-10')and match(probe/(n+'.log'),receipt))
observed=load(probe/'source-native.log')
check('historical17 source cases and20 requests',len(observed['scenarios'])==17 and all(r['status']=='pass'for r in observed['scenarios'])and observed['http_requests']==20 and observed['sdk']=='@google/genai@2.21.0'and observed['mocked_imports']==[])
check('historical17 target passes', '17 passed; 0 failed' in (probe/'target-native.log').read_text())
lock=load(probe/'package-lock.json')
check('historical SDK lock2.21.0',lock['packages']['node_modules/@google/genai']['version']=='2.21.0')
for version in ['worker-reuse320','worker-main-delta320']:
    p=delta/'files/Docs/quality/stage1/ZS1-017'/version
    r=load(p/'gstage-main.json'); log=load(p/'gstage-main.log')
    check('old G-STAGE failure retained '+version,r['exit_code']==1 and match(p/'gstage-main.log',r) and log['structural']['ok'] and 'ZS1-017.master.json' in json.dumps(log))
oldrefs=load(delta/'files/Docs/quality/stage1/ZS1-017/worker-main-delta320/target-references.json')
check('six current relevant target files match previous mapping',len(oldrefs)==6 and all(match(root/'target'/r['path'],r)for r in oldrefs))
check('13 historical mapping excerpts exact',sum(len(r['excerpts'])for r in oldrefs)==13 and all((root/'target'/r['path']).read_bytes()[e['byte_start']:e['byte_end']]==(delta/'files'/e['artifact']).read_bytes() and hashlib.sha256((delta/'files'/e['artifact']).read_bytes()).hexdigest()==e['sha256']for r in oldrefs for e in r['excerpts']))
check('current19 Gemini test definitions old17 receipt only',(root/'target/tests/stage1_gemini.rs').read_text().count('#[test]')==19)
check('current521c and domain regression frozen',ident(root/'target/src/headless.rs')['sha256']=='521c2102519b502fbd6184f31ffb53cba8eeef840bf84d19450836429d9b49f0'and ident(root/'target/tests/headless_domain_owner.rs')['sha256']=='6f121e2ea3e1f7f0ffc19d8470f94662163b1eb1e78cd3a71c97975ad06361e6')
authority=root/'authority'; a=load(authority/'Docs/execution/active_requirement.json')
check('3.1.21 exact authority baseline',a['blueprint_version']=='3.1.21'and a['requirement_digest']=='3456abcbbebbc4e0ab383c319851b0a6e71b19ee9b3c060a6e212f61a89c9d9d'and a['baseline_snapshot_sha256']=='92b06c4b1dcdca7614d226ce5f41205646a9e63967789d2b6ed4ee272d240884'and a['run_id']=='zenpi-stage1-20260911')
for name in ['source_manifest.tsv','file_learn_index.tsv']:
    selected=[r for r in rows(authority/'Docs/learn/stage1_pi_mono'/name)if r['item_id']=='ZS1-017']
    check('017 sole source report binding '+name,len(selected)==1 and selected[0]['source_path']==source and selected[0]['source_hash']==hashlib.sha256(src).hexdigest()and selected[0]['target_artifact']==report and selected[0]['status']=='[ ]')
check('only017 candidate exactly authored report',[str(p.relative_to(root/'files'))for p in (root/'files').rglob('*')if p.is_file()]==[report]and(root/'files'/report).read_bytes()==(root/'report-body.md').read_bytes())
if live:
    check('current related live input identities',all(match(Path(r['origin']),r)for r in inputs if r['kind']!='authority'))
    master=Path('/Users/wangweiyang/GitHub/zenpi'); la=load(master/'Docs/execution/active_requirement.json')
    check('live requirement relevant keys unchanged',all(a[k]==la[k]for k in ['blueprint_version','requirement_digest','baseline_snapshot_sha256','run_id']))
    def selected(p):return next(l for l in p.read_text().splitlines()if '**ZS1-017**' in l)
    check('017 blueprint record unchanged',selected(master/'Docs/stage_1_v3_pi_mono_blueprint.md')==selected(authority/'Docs/stage_1_v3_pi_mono_blueprint.md'))
    for name in ['source_manifest.tsv','file_learn_index.tsv']:
        p='Docs/learn/stage1_pi_mono/'+name
        check('017 live scoped row '+name,[r for r in rows(master/p)if r['item_id']=='ZS1-017']==[r for r in rows(authority/p)if r['item_id']=='ZS1-017'])
    old=load(root/'old-ready-inventory.json')
    check('all5258 protected original ready files unchanged',len(old)==5258 and all(match(Path(p),r)for p,r in old.items()))
if (root/'manifest.json').exists():
    m=load(root/'manifest.json')
    check('all ready payloads exact',all(match(root/r['path'],r)for r in m['files']))
    check('exact ready physical file set',{str(p.relative_to(root))for p in root.rglob('*')if p.is_file()}=={'manifest.json'}|{r['path']for r in m['files']})
result={'schema':'zs1-017-independent-offline/v1','passed':all(r['passed']for r in checks),'checks':checks,'mode':'live scoped plus portable'if live else'portable package only','runtime_executions_this_round':0,'candidate':ident(root/'files'/report),'scope':'017 only; no main gate execution or acceptance; no sibling/Gantt full-tree assertion'}
print(json.dumps(result,ensure_ascii=False,indent=2));sys.exit(0 if result['passed']else 1)
