"""Offline integrity and patch checks only; never execute product or historical scripts."""
from pathlib import Path
import csv,datetime,difflib,hashlib,json,os,re,stat,subprocess,sys,tempfile
P=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent
E=P/'evidence' if (P/'evidence').is_dir() else P
C=P/'files' if (P/'files').is_dir() else P/'candidate'
checks=[]
def check(name,ok):
 assert ok,name
 checks.append(name)
def read(p):return json.loads(p.read_text())
def info(p):
 assert stat.S_ISREG(p.lstat().st_mode),str(p)
 b=p.read_bytes();return {'bytes':len(b),'lines':len(b.splitlines()),'sha256':hashlib.sha256(b).hexdigest()}
def meta(x):return {k:x[k] for k in ['bytes','sha256']}
def inv(p):
 out={}
 for d,ds,fs in os.walk(p,followlinks=False):
  ds[:]=[n for n in ds if not Path(d,n).is_symlink()]
  for n in fs:
   f=Path(d,n)
   if stat.S_ISREG(f.lstat().st_mode):out[str(f.relative_to(p))]=info(f)
 return out
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True).encode()).hexdigest()
start=datetime.datetime.now(datetime.timezone.utc).isoformat();payload=None
if (P/'manifest.json').exists():
 actual=inv(P);actual.pop('manifest.json');expected={x['path']:{k:x[k] for k in ['bytes','lines','sha256']} for x in read(P/'manifest.json')['files']}
 check('frozen exact inventory',actual==expected);payload=len(actual)
cap=read(E/'capture.json')
for f in cap['files']:check('capture '+f['path'],info(E/f['path'])=={k:f[k] for k in ['bytes','lines','sha256']})
source=E/'capture/codex/codex-rs/tui/src/file_search.rs';b=source.read_bytes();s=b.decode();lines=b.splitlines(keepends=True)
check('exact source',info(source)=={'bytes':4009,'lines':133,'sha256':'7aaa33ac7fd28cbe5fa3405cd3490b30e614272122bb572c9c352acc418b71d9'})
reads=read(E/'read-binding.json')
for r in reads:
 src=E/r['source'];raw=src.read_bytes();ls=raw.splitlines(keepends=True);a,z=r['lines'];lo=sum(map(len,ls[:a-1]));hi=sum(map(len,ls[:z]));chunk=E/r['path']
 check('read source '+r['path'],len(raw)==r['source_bytes'] and hashlib.sha256(raw).hexdigest()==r['source_sha256'])
 check('read exact range '+r['path'],r['byte_range']==[lo,hi] and chunk.read_bytes()==raw[lo:hi] and meta(info(chunk))==meta(r) and len(raw[lo:hi])<=256*1024)
formal=[r for r in reads if r['source']=='capture/codex/codex-rs/tui/src/file_search.rs']
check('formal complete independent read',len(formal)==1 and formal[0]['lines']==[1,133] and formal[0]['byte_range']==[0,4009])
check('no source tests',not re.search(r'#\[(?:test|tokio::test)|mod tests',s))
functions=[{'name':m.group(1),'line':s[:m.start()].count('\n')+1} for m in re.finditer(r'^    (?:pub )?fn (\w+)\(',s,re.M)]
check('seven exact functions',functions==read(E/'function-inventory.json') and [x['name'] for x in functions]==['new','update_search_dir','on_user_query','start_session_locked','send_snapshot','on_update','on_complete'])
units=read(E/'source-units.json');previous=0
for u in units:
 a,z=u['lines'];lo=sum(map(len,lines[:a-1]));hi=sum(map(len,lines[:z]))
 check('unit '+u['name'],lo==previous and u['byte_range']==[lo,hi] and hashlib.sha256(b[lo:hi]).hexdigest()==u['sha256'] and bool(u['meaning']))
 previous=hi
check('14 units full byte partition',len(units)==14 and previous==4009)
mat=read(E/'capability-matrix.json')
check('12 ordered capabilities',[x['id'] for x in mat]==['C%02d'%i for i in range(1,13)])
for m in mat:check('capability '+m['id'],all(m[k] for k in ['source_lines','target_context','current_behavior','difference_or_limit','validation_criterion']) and m['executed'] is False)
history=read(E/'history-comparison.json');H=E/'history/zs1-307-ready';Q=H/'Docs/quality/stage1/ZS1-307/worker-file-search-review-3.1.20';rb=read(E/'report-binding.json');rel=rb['path']
for key,path in [('old_report',H/rel),('old_original_report',Q/'history/original-worker-report.md'),('old_manifest',H/'manifest.json'),('old_read_log',Q/'read-log.json'),('old_source',Q/'source/file_search.rs')]:check(key,info(path)==history[key])
check('old source same bytes',b==(Q/'source/file_search.rs').read_bytes() and history['subject_equal'] and not history['source_delta'])
oldlog=read(Q/'read-log.json');check('old full chain',oldlog['formal_byte_chunks']==[[0,4009]] and oldlog['sequential_reads'][0]['sha256']==info(source)['sha256'])
hr=[r['lines'] for r in reads if r['source']=='history/zs1-307-ready/'+rel];check('old report actual complete reread',hr==[[1,48],[49,100],[101,140]])
external=read(E/'external-preservation-before.json')
for old in external:
 root=E/old['path'];actual=inv(root);check('historical exact '+old['path'],actual==old['files']);manifest=read(root/'manifest.json');actual.pop('manifest.json')
 check('historical inner manifest '+old['path'],{p:meta(x) for p,x in actual.items()}=={p:meta(x) for p,x in manifest['files'].items()})
oldcontexts=read(Q/'context-capture.json')
for d in history['contexts']:
 old=next(x for x in oldcontexts if x['path']==d['origin']);current=next(x for x in cap['files'] if x['origin']==d['origin']);data=(E/current['path']).read_bytes()
 check('context identity '+d['origin'],d['before']=={'bytes':old['full_bytes'],'sha256':old['full_sha256']} and d['after']==meta(current) and d['full_file_same']==(old['full_sha256']==current['sha256']))
 check('context new read ranges '+d['origin'],d['current_actual_read_ranges']==[r['lines'] for r in reads if r['source']==current['path']])
 for x in d['old_excerpts']:
  q=E/x['path'];raw=q.read_bytes();offset=data.find(raw)
  check('historical excerpt exact '+x['path'],info(q)==x['identity'] and x['exact_bytes_found_in_current']==(offset>=0) and x['current_byte_range_if_exact']==([offset,offset+len(raw)] if offset>=0 else None))
selector=read(E/'capture/zenpi/Docs/execution/active_requirement.json');blueprint=E/'capture/zenpi/Docs/stage_1_v3_pi_mono_blueprint.md'
check('captured authority binding',selector['active'] and selector['blueprint_version']=='3.1.21' and selector['requirement_digest']=='3456abcbbebbc4e0ab383c319851b0a6e71b19ee9b3c060a6e212f61a89c9d9d' and selector['snapshot_sha256']==info(blueprint)['sha256'])
row=next(x for x in csv.DictReader((E/'capture/zenpi/Docs/learn/stage1_pi_mono/references/codex/source_manifest.tsv').open(),delimiter='\t') if x['item_id']=='ZS1-307')
check('formal manifest row',row['source_hash']==info(source)['sha256'] and int(row['source_bytes'])==4009 and row['target_artifact']==rel and row['mapping_mode']=='understand')
report=C/rel;text=report.read_text();reportinfo={k:rb[k] for k in ['bytes','lines','sha256']}
check('only one report',inv(C)=={rel:reportinfo})
check('report scope',rb['functions']==7 and rb['units']==14 and rb['capabilities']==12 and rb['read_blocks']==len(reads) and rb['context_tests_read']==4 and rb['product_changes'] is False)
check('no runtime claims',all(rb[x]==0 for x in ['source_tests_present','source_tests_run','cargo_runs','pty_runs','http_runs']))
check('all report mappings',all('|'+m['id']+' '+m['capability'] in text for m in mat))
check('report links resolve',all(Path(path).exists() or (P/path.split('/reference307-search321-ready/',1)[1]).exists() for path in re.findall(r'\]\((/[^)]+)\)',text) if '/reference307-search321-ready/' in path) if payload is not None else True)
check('forward exact',''.join(difflib.unified_diff([],text.splitlines(True),fromfile='/dev/null',tofile='b/'+rel))==(P/'candidate.patch').read_text())
check('reverse exact',''.join(difflib.unified_diff(text.splitlines(True),[],fromfile='a/'+rel,tofile='/dev/null'))==(P/'rollback.patch').read_text())
check('patch bounded',(P/'candidate.patch').stat().st_size<256*1024)
if (E/'preservation-after.json').exists():
 before=read(E/'preservation-before.json');after=read(E/'preservation-after.json')
 check('local preservation record',after['all_preserved'] and after['ready']=={p:{'files':len(x),'inventory_sha256':digest(x)} for p,x in before['ready'].items()} and after['tracked_inventory_sha256']==digest(before['tracked']))
 check('external preservation record',after['external']=={x['origin']:{'files':len(x['files']),'inventory_sha256':digest(x['files'])} for x in external})
proof=[]
with tempfile.TemporaryDirectory(prefix='zs1-307-document-') as td:
 t=Path(td);(t/'unrelated').write_text('preserve original unrelated text\n');subprocess.run(['git','init','-q',str(t)],capture_output=True,check=True)
 for args,expected in [(['--check',str(P/'candidate.patch')],0),([str(P/'candidate.patch')],0),(['--check',str(P/'candidate.patch')],1),(['--check',str(P/'rollback.patch')],0),([str(P/'rollback.patch')],0)]:
  r=subprocess.run(['git','apply',*args],cwd=t,capture_output=True,text=True);proof.append({'argv':['git','apply',*args],'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr});check('temporary git '+str(args),r.returncode==expected)
  if args==[str(P/'candidate.patch')]:check('actual report after apply',(t/rel).read_bytes()==report.read_bytes())
 check('rollback and unrelated preserved',{p:x for p,x in inv(t).items() if not p.startswith('.git/')}=={'unrelated':info(t/'unrelated')} and (t/'unrelated').read_text()=='preserve original unrelated text\n')
print(json.dumps({'status':'passed','started_at':start,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'static_checks':len(checks),'payload_files':payload,'formal_files':1,'source':info(source),'report':info(report),'read_blocks':len(reads),'functions':7,'units':14,'capabilities':12,'product_executions':0,'source_tests_run':0,'temporary_git':proof,'checks':checks},indent=2))
