from pathlib import Path
import datetime,hashlib,json,os,shutil,stat,subprocess
W=Path(__file__).resolve().parent;ROOT=W.parent.parent
M=Path('/Users/wangweiyang/GitHub/zenpi');C=Path('/Users/wangweiyang/GitHub/codex')
def info(p):
 assert stat.S_ISREG(p.lstat().st_mode),str(p)
 b=p.read_bytes();return {'bytes':len(b),'lines':len(b.splitlines()),'sha256':hashlib.sha256(b).hexdigest()}
def inv(p):
 out={}
 for d,ds,fs in os.walk(p,followlinks=False):
  ds[:]=[n for n in ds if not Path(d,n).is_symlink()]
  for n in fs:
   f=Path(d,n)
   if stat.S_ISREG(f.lstat().st_mode):out[str(f.relative_to(p))]=info(f)
 return out
def dump(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
old=sorted(p for p in (ROOT/'.ops').glob('*-ready') if p.is_dir())+[ROOT/'.ops/stage125-render-review320/ready',ROOT/'.ops/stage126-independent320/ready',ROOT/'.ops/stage126-independent320/ready-final']
tracked={str(ROOT/x.decode()):info(ROOT/x.decode()) for x in subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).split(b'\0') if x and (ROOT/x.decode()).is_file()}
before={'ready':{str(p):inv(p) for p in old},'tracked':tracked};dump(W/'preservation-before.json',before)
selected={'codex':['AGENTS.md','codex-rs/tui/src/file_search.rs','codex-rs/tui/src/app.rs','codex-rs/tui/src/app_event.rs','codex-rs/tui/src/chatwidget.rs','codex-rs/tui/src/bottom_pane/mod.rs','codex-rs/tui/src/bottom_pane/chat_composer.rs','codex-rs/tui/src/bottom_pane/file_search_popup.rs','codex-rs/file-search/src/lib.rs'],'zenpi':['src/tui.rs','src/slash.rs','tests/tui_command_palette.rs','Docs/stage_1_v3_pi_mono_blueprint.md','Docs/execution/active_requirement.json','Docs/learn/stage1_pi_mono/references/codex/source_manifest.tsv','Docs/learn/stage1_pi_mono/references/codex/file_learn_index.tsv']}
files=[]
for tag,rels in selected.items():
 for rel in rels:
  src={'codex':C,'zenpi':M}[tag]/rel;dst=W/'capture'/tag/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);assert info(src)==info(dst);files.append({'path':str(dst.relative_to(W)),'origin':str(src),'role':'subject-full' if tag=='codex' and rel=='codex-rs/tui/src/file_search.rs' else 'context-only',**info(dst)})
external=[]
for name in ['zs1-307-ready','codex-reference-ready']:
 src=Path('/Users/wangweiyang/.codex/worktrees/2267/zenpi/.ops')/name;dst=W/'history'/name;shutil.copytree(src,dst);x=inv(src);assert inv(dst)==x;external.append({'origin':str(src),'path':str(dst.relative_to(W)),'files':x})
dump(W/'external-preservation-before.json',external)
dump(W/'capture.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'item':'ZS1-307','version':'3.1.21','codex_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=C,text=True).strip(),'files':files,'old_ready':len(old),'old_ready_regular':sum(map(len,before['ready'].values())),'tracked':len(tracked),'read_claim':'Copied whole context files are not full-read claims.'})
dump(W/'preparation-issues.json',[{'operation':'Broad rg --files across old/new .ops trees','result':'No output after approximately 42 seconds; terminated only owned PID 88700 with SIGTERM. Bounded top-level inventory then located old307ready.','exit_code':143},{'operation':'Initial old307 report read bundled with AGENTS/inventory','result':'Aggregate output truncated; not credited as complete. Read again in bounded chunks from capture.'}])
print(json.dumps({'captured':len(files),'subject':files[1],'old_ready':len(old),'old_ready_regular':sum(map(len,before['ready'].values())),'tracked':len(tracked),'historical_files':[len(x['files']) for x in external]},indent=2))
