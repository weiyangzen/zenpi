"""Offline structure only. No source tests, Cargo, PTY, HTTP or product execution."""
from pathlib import Path
import hashlib,json,re
E=Path(__file__).resolve().parent;root=E.parents[4]
def read(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def bound(p,r):
    b=p.read_bytes()
    if isinstance(r,str):assert sha(b)==r,str(p)
    else:assert len(b)==r['bytes'] and sha(b)==r['sha256'],str(p)
source=(E/'source/file_search.rs').read_bytes();s=source.decode()
assert len(source)==4009 and len(source.splitlines())==133
assert sha(source)=='7aaa33ac7fd28cbe5fa3405cd3490b30e614272122bb572c9c352acc418b71d9'
assert not re.search(r'#\[(?:test|tokio::test)',s)
assert read(E/'source-tests.json')==[]
reads=read(E/'read-log.json')['sequential_reads']
assert len(reads)==1 and reads[0]['lines']==[1,133] and reads[0]['bytes']==[0,4009] and reads[0]['sha256']==sha(source)
inputs=read(E/'inputs.json');assert inputs['formal_files']==1 and len(inputs['files'])==34
for r in inputs['files']:bound(root/r['snapshot'],r)
captures=read(E/'context-capture.json');assert len(captures)==8 and sum(len(c['excerpts']) for c in captures)==20
assert captures[0]['full_bytes']==579524 and captures[0]['full_sha256']=='d2a98934d4931a5aa202e542acd556bdda5667f0e60df11a68731dacf00eccf1'
for c in captures:
    for r in c['excerpts']:bound(root/r['snapshot'],r)
report=(root/'Docs/learn/stage1_pi_mono/references/codex/files/codex-rs/tui/src/file_search.rs_learn.md').read_text()
assert not re.search(r'^\s*[-*]\s+\[[xX]\]',report,re.M)
functions=[(i,m[1]) for i,l in enumerate(s.splitlines(),1) if (m:=re.match(r'    (?:pub )?fn (\w+)\(',l))]
inv=read(E/'function-inventory.json');assert len(inv)==7
assert [(r['source_line'],r['name']) for r in inv]==functions
assert all(r['read'] and r['name'] in report for r in inv)
matrix=read(E/'capability-matrix.json');assert len(matrix)==11
for r in matrix:assert not r['executed_in_307'] and r['source_fact'] in report
ct=read(E/'context-tests.json');assert ct['context_only'] and ct['executed']==0 and len(ct['tests'])==3
test_capture=next(c for c in captures if c['label']=='target-tests')
for t in ct['tests']:
    fragment=next(r for r in test_capture['excerpts'] if r['source_lines'][0]<=t['source_line']<=r['source_lines'][1])
    lines=(root/fragment['snapshot']).read_text().splitlines()
    assert lines[t['source_line']-fragment['source_lines'][0]].strip()==f"fn {t['name']}() {{"
    assert t['name'] in report
for token in ['源测试实际执行数0','pending_query','wrapping_add','on_complete','150ms','P11','d2a989','same']:
    assert token in report,token
historical=[]
for family in ['ux123-provenance','ux123-source-inspector']:
    h=E/'history'/family;m=read(h/'manifest.json')
    for p in h.rglob('*'):
        if p.is_file() and p.name!='manifest.json':bound(p,m['artifacts'][str(p.relative_to(h))])
h=E/'history/ux123-source-inspector';m=read(h/'manifest.json')
helper=next(c for c in captures if c['label']=='historical-helper')
for name,count,code in [('final-after2',23,0),('final-negative-final',5,1),('final-negative2',23,0)]:
    p=h/f'evidence/ux123-source-inspector-{name}.json';d=read(p);run=read(p.with_name(p.stem+'.run.json'))
    assert len(d['checks'])==count and all(v is True for v in d['checks'].values())
    assert run['exit_code']==code and run['outputs'][p.name]==sha(p.read_bytes())
    assert d['binary_sha256']==run['binary_sha256']
    assert run['helpers']['tui_command_palette_smoke.py']==helper['full_sha256']
    if code==0:
        assert d['passed'] is True and d['request_count']==12 and d['binary_sha256']=='3d1b5fefcb7f05b97aef467dda4098f5fe0435f1dc7b9234a43cc202023b57bc'
    else:
        assert 'passed' not in d and 'status' not in d and d['binary_sha256']=='240e00b6009aba6dfc817fc95487c7e9c9f6003048a4d5af50dd2725d024baa5'
    historical.append(dict(name=name,checks_true=count,run_exit=code,passed=d.get('passed'),binary_sha256=d['binary_sha256'],scope='historical only'))
print(json.dumps(dict(passed=True,kind='structural only; G-FILE pending',source_bytes=4009,source_lines=133,source_tests_read=0,source_tests_executed=0,source_functions=7,capability_groups=11,input_snapshots_checked=34,continuous_reads=1,target_context_excerpts=11,all_context_excerpts=20,context_tests_read=3,context_tests_executed=0,historical_results=historical,cargo_runs=0,pty_runs=0,http_runs=0),ensure_ascii=False,indent=2))
