# ZS1-307 · file_search.rs 完整单文件 learn 复核

worker完整单文件候选，主控 G-FILE 待审。understand；蓝图3.1.20，requirement digest `8d525b351d066ce9b0487a485337647d47233275782e4f4d154423a623fe1645`。本项只复核文件搜索编排，不扩展其它owner或目录完成，不改产品、主库、蓝图、索引或验收勾选。

## 唯一源、基线和当前上下文

正式源`codex-rs/tui/src/file_search.rs`，HEAD `b3b3d262787f4902a7449f17d793241a34d311ad`，4009B、133行，SHA256 `7aaa33ac7fd28cbe5fa3405cd3490b30e614272122bb572c9c352acc418b71d9`。1–133连续完整读取，单byte chunk `[0,4009)`；没有test module或内联测试，**源测试数0、源测试实际执行数0**。全部7函数已读，无需用抽样补足。外部codex-file-search引擎、Drop、排序与线程实现不是本正式文件；没有执行其测试。

[完整冻结源](/Users/wangweiyang/.codex/worktrees/2267/zenpi/Docs/quality/stage1/ZS1-307/worker-file-search-review-3.1.20/source/file_search.rs)；[连续阅读](/Users/wangweiyang/.codex/worktrees/2267/zenpi/Docs/quality/stage1/ZS1-307/worker-file-search-review-3.1.20/read-log.json)；[7函数入口](/Users/wangweiyang/.codex/worktrees/2267/zenpi/Docs/quality/stage1/ZS1-307/worker-file-search-review-3.1.20/function-inventory.json)

原报告2040B/hash `eb836e68285dea1791ca042f633bd0f252f0f66ea51555ec970ab83659400d2d`与原ready收据保留原字节。旧报告指出manager不作snapshot/latest严格相等是正确局部事实；本次补读必要consumer片段后确认**popup另有严格相等过滤**，因此不能把旧局部观察直接写成已发生的旧query覆盖UI错误。旧“需要query/generation identity”是建议，分别对照当前实际query对象与job ID。

[原报告](/Users/wangweiyang/.codex/worktrees/2267/zenpi/Docs/quality/stage1/ZS1-307/worker-file-search-review-3.1.20/history/original-worker-report.md)；[原ready收据](/Users/wangweiyang/.codex/worktrees/2267/zenpi/Docs/quality/stage1/ZS1-307/worker-file-search-review-3.1.20/history/original-ready-manifest.json)

当前目标冻结时间2026-09-12T10:40:05.488614+00:00；TUI579524B/hash `d2a98934d4931a5aa202e542acd556bdda5667f0e60df11a68731dacf00eccf1`，与主控指定当前版本相同。没有沿用93a旧TUI快照，也不将旧背景审批缺口当当前事实；本307不评估审批修复。目标测试文件21110B/hash `3bf46fa713dd2ab4252330106c2430f2a34ae9c967419fa42c26595b9000d5ec`只读两段含3项相关测试，不计整文件完成。

共34输入快照：20个必要片段中，9个目标TUI、2个目标测试、8个Codex调用/消费片段、1个历史helper。Codex调用方共5文件（App、ChatWidget、BottomPane、ChatComposer、FileSearchPopup）；完整文件hash/片段byte/hash/来源行都在context-capture.json，**均仅上下文，不报独立learn完成**。没有复制整个大TUI或大composer来冒称学习。历史H123两个原review和manifest、三组结果/run保留原字节，不以历史实际运行代替本轮静态。

[当前片段与全文件hash](/Users/wangweiyang/.codex/worktrees/2267/zenpi/Docs/quality/stage1/ZS1-307/worker-file-search-review-3.1.20/context-capture.json)；[34输入快照](/Users/wangweiyang/.codex/worktrees/2267/zenpi/Docs/quality/stage1/ZS1-307/worker-file-search-review-3.1.20/inputs.json)；[3项目标测试只读记录](/Users/wangweiyang/.codex/worktrees/2267/zenpi/Docs/quality/stage1/ZS1-307/worker-file-search-review-3.1.20/context-tests.json)

## 全部源代码与分支

| S行 / 单元 | 本文件真实行为与限制 |
|---|---|
| 1–14文档/import | @token变化通过StartFileSearch驱动，编排一个当前root的session。file_search alias指外部库，Arc/Mutex保护共享state；文档没有定义具体fuzzy/递归/内容检索算法。 |
| 16–26状态 | manager持state Arc、独立PathBuf search_dir、AppEventSender；SearchState仅latest_query String、Option<FileSearchSession>、usize session_token。没有query generation、project/session identity、deadline、错误状态或result缓存。 |
| 29–39 new | root与sender照收，shared latest空/session None/token0；不校验root存在、canonical或absolute，不启动搜索。 |
| 44–50 update_search_dir | 先赋新root，再unwrap mutex；take并drop当前session、clear latest。即使路径相等也执行，不重启、不直接发清列表事件、不增加token。清query使旧reporter随后检查被过滤；真正后续new session会递增token。 |
| 53–60 query去重 | unwrap锁，完整String与latest精确相等则立即return；不同则clear旧String再push新query。没有trim、大小写折叠或debounce。空白字符串属于非空搜索，超长字符串也无此层上限。 |
| 62–65 空query | 在latest已变空后take/drop session并return。不显式清UI matches，也不发取消/完成事件。若当前本来空query，前面的相等return使此段不执行，但正常构造状态session本来None。 |
| 67–73 非空query | session None时尝试创建；有session才update_query。后续不同query复用同一session和同一token，调用仍在mutex guard范围内。库update是否同步callback不在此文件。 |
| 75–82 epoch/reporter | 每次create尝试先wrapping_add(1)，从0到1；构造reporter持同state/sender与该token。失败也消耗token；usize溢出回绕，不panic、不提供永不碰撞的数学保证。实际需要极多次重建，未当当前可复现错误。 |
| 83–91 create_session | 单元素roots vec含search_dir clone；compute_indices=true，其余options Default；reporter传入、cancel_flag None。只证明请求计算匹配位置，是否递归、忽略文件、排序、结果数量、启动线程/释放线程等都依赖库默认和实现，不能从名称猜。 |
| 92–99结果 | Ok存session，Err tracing::warn并保持None；没有AppEvent错误、loading终止或自动retry。latest仍是失败query，所以再传完全相同query会在56处return，不重试；改query或update_root清latest后才再create。 |
| 102–106 reporter字段 | state/sender共享、session_token拷贝。不持root/query generation，callback本身不能将结果归属到独立UI session。 |
| 109–117 send_snapshot门槛 | unwrap锁；session_token不符，或latest为空，或snapshot.query为空，任一则return。**未要求snapshot.query==latest_query，也未检查st.session.is_some**；后者是否必要不能脱离库callback合同断言。 |
| 118–123发送 | clone snapshot.query，显式drop guard，再clone snapshot.matches发送FileSearchResult。event只携query与matches，不携root/token；不合并、去重、限额或回执处理。解锁后其它query/root可变化，已发送/排队event无法靠之后token变化被撤回。 |
| 127–133 trait | on_update唯一动作send_snapshot；on_complete空函数，不清session/latest、不通知UI完成、不主动重试。共有7函数：new、update_search_dir、on_user_query、start_session_locked、send_snapshot、on_update、on_complete。 |

三处lock().unwrap遇poison会panic；#[expect(clippy::unwrap_used)]只是lint注解，不是恢复策略。create_session、session.update_query和take所得session的Drop都发生在持state锁期间。若外部库在这些同步路径重入reporter或阻塞等待reporter，需检查依赖保证；本307未读库实现，**不宣称已发生deadlock或Drop必然立即取消/有界join**。send前unlock避免将sender调用置于该guard内，但这不等于整个搜索链没有锁等待。

对象生命周期上，root变化清query暂时屏蔽旧callback，下一次create产生新token再拒老token；同session内query变化不换token，所以细query新旧由下游处理。None cancel_flag表示本层未传显式取消标记；drop session和停止实际文件工作是否同时完成须外部Drop合同证明。本文件只读发现结果，不授权文件读取、上传或执行。

## 必要调用方的完整接线边界

App2507–2514在resume成功后shutdown当前thread、换config并调用update_search_dir(config.cwd)，再建chatwidget。此片段证明这一resume路径接根目录更新，**不代表所有项目切换/新建/fork路径都已审阅**。App2751–2756将StartFileSearch交manager、FileSearchResult交ChatWidget；ChatWidget8638–8642转BottomPane；BottomPane1099–1102转composer后总request_redraw，即使结果被consumer拒绝也会重绘。

ChatComposer1231–1244取current_at_token：没有token则return；token不starts_with(result query)则return；只有active popup是File才调用popup.set_matches。仅看这一层仍允许旧query是当前token前缀。**FileSearchPopup67–77再要求result query严格等于pending_query**，不同即return；相等则更新display_query、matches、waiting=false并clamp selection/ensure_visible。因而常见同session `a→ab` 后收到`a`，虽可经过manager和composer，仍在pending=ab的popup被拒。这是本次相对旧报告新增的可核查结论。

Popup43–52 set_query只有改变pending时才置waiting=true，保留已有matches和display_query；56–63空prompt清display/pending/matches、waiting=false并reset选择。保留旧matches等待新结果是状态事实；本次没有读取popup render/选择按键实现，不能断言等待时旧候选一定可选、一定隐藏或有spinner。

Composer3509–3551精确相同dismissed token直接return不重开；空query发StartFileSearch空并让popup显示空prompt，非空发送query并set_query，必要时new FileSearchPopup；current_file_query随空/非空设None/Some，最后清dismissed marker。同步片段3254–3304显示history browsing、command popup、mention转入或无file token时可发送空query并清current marker。popups_enabled=false的较前分支不在本片段范围，不能借这些路径说所有失焦都一定cancel。

残余身份边界：锁内通过检查后才unlock/send；如果一个旧root的同名query结果已排进AppEvent，后续新root再次出现同名pending query，仅凭当前event的query+matches无法识别旧root/token。相等过滤解决“不同query”，不能自动证明跨root同query已排队event绝不被接受。是否实际可发生、是否其它App队列生命周期提供隔离要用有限调度测试，P04/P06列为待验，不把静态字段缺失直接称用户已遇到错文件。

## 11组当前目标映射

| 能力 / S行 | 源事实 | 冻结目标/调用方 | 结论 / 待验 |
|---|---|---|---|
| C01 状态与根目录 / 16–39 | 显式search_dir、shared latest/session/token；new空session不读文件 | TUI561–573;4027–4104：完整FileCompletionQuery含root/input/prefix/path/raw，无复用索引session | 一个source session与每query后台扫描不同；P01 |
| C02 query更新/去重 / 53–73 | 精确相同先return；非空复用session.update_query，无本层debounce；空drop | TUI4027–4104;10979–11017：desired完整对象变才cancel/submit；cursor非末/dismissed/picker/browser无query | 目标不是每字符都起有效query，普通@空path可列目录；P02 |
| C03 新session与失败 / 75–99 | wrapping token每次create尝试递增；compute_indices=true、其它Default、None cancel；error只warn | TUI640–726;10779–10788;10979–11017：prefix单目录扫描，worker返回错误可显示；Completed失败保留last query | 源/目标同query失败恢复都需明确retry；P03 |
| C04 callback过滤 / 109–123 | 拒token不符或latest/snapshot空；不比较query相等，锁释放后发仅query/matches | Codex composer1231–1244;popup43–77；TUI4091–4104;10995–11017：source composer前缀门槛后popup pending_query严格相等；目标active JobId+完整query | 已接线旧query会被popup拒，但same-query跨root事件缺身份仍需验；P04 |
| C05 取消与完成 / 44–49;62–64;90;128–132 | clear/drop，没有显式cancel flag/join；on_complete空；drop时机由依赖 | TUI10979–11017;10779–10788;640–688：query变取消旧job并换ID，worker协作cancel；只消费matching Completed | 丢session不是本文件证明即时停线程；拒绝/关闭/迟到事件需验；P05 |
| C06 root变化与epoch / 44–49;76;112–122 | 即使同root也drop清query，不递增token直至next create；AppEvent无root/token | Codex app2507–2514；TUI1974–1984;561–568：resume明确update_root；目标switch清cache，query含root但无project/session generation | 跨root通常被完整对象拒；同root同text新session不是自动独立epoch；P06 |
| C07 搜索语义与边界 / 83–90 | 只知single root+indices，排序/递归/忽略/预算依赖defaults未读 | TUI640–726：父目录内starts_with、最多2048枚举/150ms软截止、排序后truncate128，无recursive/fuzzy | 截断无has_more/完整性标记，不能把128结果当完整目录；P07 |
| C08 路径与授权 / 全部1–133 | 不校验root/path/query、不读取结果内容或授予许可；只转matches | TUI640–726;10699–10723：拒absolute/parent/control/symlink子目录，候选metadata；提交时owner attachment_for_path | discovery不同于content读取；根信任/TOCTOU及最终读取安全未审依赖；P08 |
| C09 交互与选择 / 1–6;120–123 | AppEvent驱动，无键盘/绘制/选中代码 | Codex composer3509–3551；TUI4242–4257;4388–4428;4505–4525：source空@只提示；目标目录继续browse，文件补尾空格、明确二次提交，显示source | 失焦与等待/空结果语义不同，不复制/agent或旧审批缺口；P09 |
| C10 锁与资源 / 17;47;55;75–96;109–122 | unwrap poison会panic；create/update/drop在锁持有时，send前unlock；无本层限额/背压 | TUI640–688;10779–10788：后台扫描非UI loop，但fs调用本身可能阻塞，150ms不含前置pathwalk且不是hard deadline | 不声称性能、取消join或线程总量已验证；P10 |
| C11 源测试和历史 / 1–133无test模块 | 0内联测试、7函数，全文件完整读 | 目标3测试片段；H123 after2与2种negative：目标3测试只读；历史file marker真实但并非当前race/timeout验证 | 不能把resource inspector失败或old23pass当307新运行；P11 |

## 当前Zenpi补全链路与具体差距

目标FileCompletionQuery完整相等包含root、完整input、prefix、path、raw_selection。file_completion_query先排除palette_dismissed、cursor不在input末、directory picker或transcript browser；**这里没有直接排除history_search或focused approval**。别的输入路由可能阻止普通编辑，但不能据此函数保证任意modal下无后台搜索。paste folds先用等byte数空格mask避免折叠文字生成@token；四个slash路径入口`/attach /diff /review /reload`只有无fold才处理，reload用raw path，其余处理quote；普通非slash文本只取最后一个word-boundary @引用，必须在输入末且不与fold重叠，闭合token后的空白使query结束。解析函数对path>4096、过多引用报错；该层错误经ok()?使query None，不在此显示原因。

目标空`@`或`/attach `可形成empty path query并列project根目录；source空@发空query/drop session且popup显示提示。目标不是源同样的搜索模式：complete_file_query仅扫描path父目录一层、按name.starts_with(needle)大小写敏感前缀筛选；没有递归、fuzzy或内容搜索实现。源引擎默认算法本轮未读，所以只说source提供可复用session接口，不虚构它一定比目标递归/更快。

生产loop desired!=last_file_query时take旧active ID并try_cancel（错误忽略）、清cache、记录last，submit新query，成功记active ID，submit失败last=None使下轮可重试。完成事件仅matching active ID消费；Succeeded再次apply_file_completion要求当前完整query相等，缓存后归零palette并dirty；Failed仅当当前query==last时显示错误。last在正常Failed后没有清，所以相同query不会重新调度，需改输入/状态再回来；sourcecreate失败也有同query不重试问题但source只warn而目标可见。只看到matching Completed处理，异步Rejected/Closed等事件如何保证不留下active ID要查BackgroundRunner合同，本轮不扩展该文件。

两道过滤（job ID、完整query）能拒常见迟到旧query/root。query字段却没有project ID或session generation：同root+同input+同prefix/path/raw仍相等，不能宣称新session相同草稿有独立epoch。项目切换片段会清file_completion；本报告不重审全部new/restore路径。文件补全通常与session无关是否应继续复用，可以作产品选择，但要明示而不是当强身份验证已存在。

扫描先拒>4096/control path、absolute与ParentDir/RootDir/Prefix；逐父路径组件用symlink_metadata拒symlink或非目录。query.root本身在此不canonicalize或symlink检查，依赖project_cwd可信；文件系统在检查与读取间仍可变化，不是TOCTOU安全证明。read_dir最多取2048项，迭代前检查cancel、每项再检查cancel/elapsed>150ms；150ms计时在父目录walk之后，单次filesystem调用不被deadline中断，故是协作软预算，**不能称150ms硬时限或有界取消join**。只收Unicode有效、非control、匹配前缀、非symlink的file/dir；非UTF8名称略过。任何entry/file_type错误会返回Err而非保留已有部分结果。

候选先在read_dir返回顺序/时间预算内收集，再按directory优先、input字典序排序，最后truncate128。2048/150ms/128截断没有返回truncated/has_more/reason，不能区分完整无匹配与未扫到匹配；在巨大目录还可能得到不同截断子集。这里有明确可用性差距：用户无法知道列表是否完整，也没有本返回模型的“更多”入口。P07要求保留预算同时对截断给出可理解状态/可继续方式；本轮不修改产品。

候选input是prefix加quote_input_path转义后的路径（raw reload例外），directory加斜杠；source字段为root.join(path)展示，directory bool用于选择。slash_choices仅当cached query仍匹配时优先返回候选；choose_slash对directory继续browse、不加空格，对file加末尾空格并dismiss，清cache后返回。它只补文本，没有在此提交provider或读取文件体；真正再次Enter后，Model worker在10699–10723按owner root重新解析非slash @引用，拒未闭合/空path并调用attachment_for_path，再传attachments。我们没有展开attachment_for_path内部，所以不把completion词法检查当最终安全读取已完整审计。

source展示在菜单说明“File reference · validated again at submission”，路径展示经过menu_source裁切；本source manager只给matches/indices，并不画菜单。本307只对文件发现与关联给差距，不引入资源F2、审批或外部编辑的新owner工作。

## 源测试不存在；目标测试仅作阅读上下文

source-tests.json为空数组，正式源测试0、执行0。目标tests/tui_command_palette.rs只读以下3个测试，**也没有执行**：

| 目标行 | 名称 | 精确覆盖 |
|---|---|---|
| 241 | `file_completion_is_cwd_bound_quoted_and_stale_query_safe` | Unicode空格目录两次Tab补全，完整查询旧结果拒绝，完成文件尾空格与后面正文不触发query；仅直接API，未运行 |
| 268 | `slash_paths_and_negative_boundaries_do_not_mutate_draft` | attach带空格quote、父目录拒绝保稿、cancelled true报错、Unix symlink目录拒绝；未运行 |
| 391 | `completion_result_and_path_limits_remain_bounded` | 200文件返回128、应用缓存128；4097字符path报错、draft长度4105；未运行 |

这些测试通过direct函数手动生成entries/apply，不是生产后台worker/JobId、事件重排或并发根切换测试。200文件期望128在源assert中确实存在，但不覆盖2048枚举/150ms截断、慢FS硬阻塞或Unicode无效文件名。Unix symlink测试只覆盖子目录链接，不是root symlink/竞态证明。不计成3个Codex源测试，不把读到assert写成3 passed。

## 最小待验标准（全部未运行）

| P | 有限输入/调度 | 必须观察的结果 |
|---|---|---|
| P01 初始化与root | source new合法/不存在root不发query；目标两个不同root同输入。 | new只初始化；首query才尝试session。目标query身份包含真实root，错root结果拒绝，不自动读取或提交文件。 |
| P02 query序列 | source空→a→同a→ab→空→同空；target尾部@、已闭合尾空格、slash、fold中@、光标中部。 | sourcecreate1/update a与ab、相等不update、空drop；目标只生成其明确支持query，空path浏览与source空prompt区别保留。 |
| P03 失败重试 | 用可控create失败/恢复条件，重复同query再改query；target worker目录错误后恢复目录但query不变。 | 记录目前同query不重试；如产品需要重试提供有限明确入口，不必诱导用户随便改文本。错误提示/等待态均可理解，不能只log称已反馈。 |
| P04 callback旧query | source reporter旧token、空latest、空snapshot分别调用；同session a→ab收a；再收ab；冻结event在send前/发送后调度。 | manager门槛准确；popup pending严格拒a，只接受ab；重绘可发生但无旧候选覆盖。send后已排队event不能借新token“撤回”。 |
| P05 cancel与完成 | source空/root变drop；模拟迟到on_update/on_complete；target query变后旧job success/cancel/async rejection。 | 旧ID不能apply；明确Drop/join与worker取消合同，不假定on_complete清UI；无永久active/loading，失败和关闭可恢复。 |
| P06 相同query跨root/session | A root结果event已入队，再切B root并输入同query；目标同root新session同draft与不同root切换分别调度。 | 不显示A的错误来源；需要root/session generation时必须在消息和消费端可核验，若选择session无关复用应有明确规则和测试。 |
| P07 截断与发现性 | 129候选、2049枚举中末尾唯一匹配、模拟软150ms提前退出，之后缩小prefix。 | 最大保留128；列表明确告知不完整/提供继续方式，不能将截断后的空列表误称无文件；排序只保证已采集子集，记录未覆盖硬FS延迟。 |
| P08 路径与授权 | absolute/../control、quoted Unicode/空格、子symlink、root链接、发现后文件换内容，随后用户明确提交。 | 发现拒非法而保稿；提交重新走owner附件路径；metadata/列名不是读内容权限，实际读取/上传发生在明确提交之后并使用新校验。 |
| P09 选择与modal | directory→file两次Tab，停下不Enter；Esc后同query与改query；picker/history/approval可见时检查后台search。 | 补全文本而不发HTTP/执行；目录继续、文件尾空格；modal不偷输入，是否继续查找由明确gate决定，不把query函数当全焦点合同。 |
| P10 锁和预算 | instrumented可控session创建/update/drop，尝试同步reporter回调；慢read_dir由测试替身控制，不实际无限挂起。 | 验证锁重入/Drop线程合同，不能以unwrap或150ms语句推断不阻塞；poison有明确错误边界，所有性能结果另绑定环境。 |
| P11 历史与当前 | 未来主控获准运行对应release路径时固定binary/source/helper并留原始请求/草稿/事件；当前3目标测试按原名运行。 | 区分旧H123file marker成功、新静态和新真实运行；旧资源F2失败不冒称搜索失败，0源测试保持真实，不按boolean数重复计算验收。 |

## 历史证据及失败的准确范围

H123 source-inspector原review和provenance原review本轮完整读并保留。各原manifest绑定hash；source-inspector复制final-after2、final-negative-final、final-negative2的原result/run。run.outputs哈希与result字节、run binary/helper绑定分别核对；原大PTY/HTTP日志未重新运行或逐字节语义手审，原manifest/outputs继续指向它们。

| 原run | 原结果 | 本307能引用什么 |
|---|---|---|
| final-after2 | release `3d1b5fefcb7f05b97aef467dda4098f5fe0435f1dc7b9234a43cc202023b57bc`，23项true、passed=true、run exit0、12HTTP；原review记4TUI | 其中明确一项实际Unicode空格文件选择/附件和非法path保稿，不能以其余资源/model组数充文件搜索并发验证。 |
| final-negative-final | 旧release `240e00b6009aba6dfc817fc95487c7e9c9f6003048a4d5af50dd2725d024baa5`，先5项true、run exit1；result无passed/status字段 | 失败在缺F2资源source inspector，尚未到file attachment检查。不能写“file completion negative passed”或编造passed=false字段。 |
| final-negative2 | 实际仍new release3d1b…，23true、passed=true、exit0、12HTTP | 名字虽negative，wrapper模式错误选new binary，是额外positive replay。保留错误，不当旧binary反例或独立修复。 |

历史helper完整文件SHA `3499964aac990089389ba7c4ba2b60edff7f6b160a51d8b80a170c4c8df95073`与run.helpers绑定，仅冻结109–114必要片段。实际动作是键入inspect @工作→看工作 folder/→Tab→看note file.txt→Tab→草稿有quoted文件及空格→输入please→deliberate Enter；随后HTTP请求含FILE_ATTACHMENT_MARKER的base64，journal不含该正文且出现sha256。它证明该夹具确实选到并提交文件，不是仅菜单截图，但没有逐字段对比每个附件digest/完整root身份。非法`/attach ../denied`保留draft且HTTP数量不变，是另一个明确负例。

provenance review历史20检查/12HTTP、source-index修复、source-inspector review128Rust/strictclippy与其它范围只是原review记录；本307没有复制/重验它们所有raw结果，不将其列成本次执行。之前编译支持不匹配、fixture checkpoint竞争、source截断、copy后预期错误、negative2选错binary等原失败保留，不混成当前d2a TUI的搜索错误或成功。

这批H123基于蓝图3.1.16、旧release，当前d2a TUI与source/search代码是本次静态快照；二者不是相同全文件hash/同binary。本307没有新的Cargo、PTY、HTTP、平台或性能验证，不以历史总23项盖过source 0tests或P01–P11未执行。

## 精确交付与离线验证

主库标准报告逐项只读实测不存在，见master-baseline.json；master.patch仅新增本报告，worker.patch以原2040B报告替换。独立临时git init仓库分别正向check/apply、逆向check/apply，核对新/旧实际字节及无关sentinel。回退只反向本报告delta，不撤销主控新TUI或任何历史ready。

check_static.py核对唯一源4009B/133行/连续byte、0源测试、7函数、11组映射、34输入与20片段、3目标测试只读标签及H123原manifest/result/run绑定；verify_package.py核对ready完整artifact集合/byte/hash、唯一报告路径delta、正逆精确字节。结构通过只表示交付可核验，不等于主控G-FILE语义通过。

不跑Cargo/PTY/HTTP，不改产品/主库/蓝图/索引或勾选，不开新任务/subagent。所有既有304/303/301/302/305/306及相关H123 ready原字节保留；仅本307一个正式文件候选，不把必要caller或target片段扩展成它们的owner工作。主控独立复核后才决定G-FILE，交付即停在此单文件边界。
