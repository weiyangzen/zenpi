ZS1-307 Codex file_search.rs 完整单文件 learn 候选；主控 G-FILE 待审。

4009B/133行/7函数全部顺读，源文件无内联测试，实际执行0。必要目标3测试只读未运行。34输入快照、20必要片段（11目标、8 Codex调用方、1历史helper）；11组行为映射和P01–P11未运行判据。

当前TUI冻结于2026-09-12T10:40:05.488614+00:00，579524B/hash d2a98934d4931a5aa202e542acd556bdda5667f0e60df11a68731dacf00eccf1。没有沿用93a旧审批缺口，也不扩展审批owner。下游popup严格query过滤、已排队同query跨root身份、同query失败重试及扫描截断提示的实际边界见报告。

主库标准报告逐项实测不存在，master.patch只新增该报告；worker.patch替换原2040B报告。正逆apply/check及实际字节在独立临时Git仓库验证，保留无关sentinel。

离线复验：python3 Docs/quality/stage1/ZS1-307/worker-file-search-review-3.1.20/verify_package.py。只读本ready文件并写自身临时Git仓库，检查全部manifest产物、结构、单报告delta和正逆字节。

H123历史结果、错误命名negative2和真正旧binary失败均保留，不当本307新执行。无Cargo/PTY/HTTP、产品/主库/蓝图/索引/勾选修改，无新任务/subagent。305/304/303/301/302/306及历史ready原字节保持。仅一个正式文件候选，交付后停在单文件边界。
