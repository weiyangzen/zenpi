from pathlib import Path
import datetime,hashlib,json,os,shutil,stat
W=Path(__file__).resolve().parent;R=W.with_name(W.name+'-ready')
def read(p):return json.loads(p.read_text())
def dump(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def info(p):
 assert stat.S_ISREG(p.lstat().st_mode),str(p)
 b=p.read_bytes();return {'bytes':len(b),'lines':len(b.splitlines()),'sha256':hashlib.sha256(b).hexdigest()}
def inv(p):
 out={}
 for d,ds,fs in os.walk(p,followlinks=False):
  ds[:]=[n for n in ds if not Path(d,n).is_symlink()]
  for n in fs:
   f=Path(d,n)
   if stat.S_ISREG(f.lstat().st_mode):out[str(f.relative_to(p))]=info(f)
 return out
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True).encode()).hexdigest()
assert not R.exists(),str(R)
before=read(W/'preservation-before.json');external=read(W/'external-preservation-before.json');capture=read(W/'capture.json');rb=read(W/'report-binding.json')
for p,x in before['ready'].items():assert inv(Path(p))==x,p
for p,x in before['tracked'].items():assert info(Path(p))==x,p
for x in external:assert inv(Path(x['origin']))==x['files'],x['origin']
after={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'all_preserved':True,'ready':{p:{'files':len(x),'inventory_sha256':digest(x)} for p,x in before['ready'].items()},'tracked_inventory_sha256':digest(before['tracked']),'tracked_files':len(before['tracked']),'external':{x['origin']:{'files':len(x['files']),'inventory_sha256':digest(x['files'])} for x in external}}
dump(W/'preservation-after.json',after)
drift=[]
for x in capture['files']:
 now=info(Path(x['origin']));was={k:x[k] for k in ['bytes','lines','sha256']}
 if now!=was:drift.append({'origin':x['origin'],'before':was,'after':now,'role':x['role']})
assert not any(x['role']=='subject-full' for x in drift),'formal source drift'
canonical=Path('/Users/wangweiyang/GitHub/zenpi')/rb['path'];assert not canonical.exists(),str(canonical)
dump(W/'freeze-input-state.json',{'at':after['at'],'capture_drift':drift,'formal_source_unchanged':True,'main_canonical_absent':True,'bound_scope':'Only captured identities and actual read ranges support this report; unrelated main progress is not frozen.'})
R.mkdir();shutil.copytree(W/'candidate',R/'files');E=R/'evidence';E.mkdir()
for p in sorted(W.iterdir()):
 if p.name=='candidate':continue
 if p.name in ['candidate.patch','rollback.patch','verify.py']:shutil.copyfile(p,R/p.name)
 elif p.is_dir():shutil.copytree(p,E/p.name)
 else:shutil.copyfile(p,E/p.name)
files=inv(R);manifest={'item':'ZS1-307','blueprint_version':'3.1.21','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'formal_files':1,'master_acceptance':False,'report':rb,'source':rb['source'],'before_canonical_absent':True,'product_changes':False,'runtime_executions':0,'patches':{n:info(R/n) for n in ['candidate.patch','rollback.patch']},'files':[{'path':p,**x} for p,x in sorted(files.items())]}
dump(R/'manifest.json',manifest)
result={'ready':str(R),'payload_files':len(files),'regular_files_including_manifest':len(files)+1,'manifest':info(R/'manifest.json'),'report':info(R/'files'/rb['path']),'patches':manifest['patches'],'preserved_ready':len(before['ready']),'preserved_ready_regular_files':sum(map(len,before['ready'].values())),'preserved_tracked':len(before['tracked']),'external_preserved_files':sum(len(x['files']) for x in external),'capture_drift':drift}
dump(W/'freeze-result.json',result);print(json.dumps(result,indent=2))
