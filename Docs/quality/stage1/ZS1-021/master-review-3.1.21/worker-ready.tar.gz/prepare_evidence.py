from pathlib import Path
import json,hashlib,datetime,re
P=Path(__file__).resolve().parent
M=Path('/Users/wangweiyang/GitHub/zenpi'); S=Path('/Users/wangweiyang/GitHub/pi-mono')
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(n,d):
 q=P/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def identity(b):return {'bytes':len(b),'sha256':sha(b)}
checks=[]
def ck(n,ok,**kw):checks.append({'name':n,'pass':bool(ok),**kw})
origins={'workerB':Path('/Users/wangweiyang/.codex/worktrees/2267/zenpi/.ops/zs1-021-ready'),'workerC-behavior':Path('/Users/wangweiyang/.codex/worktrees/ff51/zenpi/.ops/source021-behavior-ready'),'workerC-reuse':Path('/Users/wangweiyang/.codex/worktrees/ff51/zenpi/.ops/source021-reuse320-ready')}
for x in json.loads((P/'historical-inventory.json').read_text()):
 b=(P/'historical'/x['path']).read_bytes();head,tail=x['path'].split('/',1)
 ck('historical-copy:'+x['path'], identity(b)=={k:x[k] for k in ('bytes','sha256')} and b==(origins[head]/tail).read_bytes())
for kind in origins:
 root=P/'historical'/kind;m=json.loads((root/'manifest.json').read_text())
 if kind=='workerB':
  for n,x in m['artifacts'].items():ck('historical-manifest:'+kind+'/'+n,identity((root/n).read_bytes())=={k:x[k] for k in ('bytes','sha256')})
 else:
  for x in m['files']:ck('historical-manifest:'+kind+'/'+x['path'],identity((root/'files'/x['path']).read_bytes())=={k:x[k] for k in ('bytes','sha256')})
  ck('historical-patch:'+kind,sha((root/'candidate.patch').read_bytes())==m['patch_sha256'])
  ck('historical-runner-identity-only:'+kind,sha((root/'run_candidate_probe.py').read_bytes())==m['runner_sha256'])
probe=P/'historical/workerC-behavior/files/Docs/quality/stage1/ZS1-021/worker-source-probe'
sources=[]
for x in json.loads((probe/'source-hashes.json').read_text()):
 origin=Path(x['path']);b=origin.read_bytes();rel=origin.relative_to(S);out=P/'source-context'/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b)
 sources.append({'original_path':str(origin),'snapshot':str(out.relative_to(P)),**identity(b),'historical_sha256':x['sha256'],'same':sha(b)==x['sha256'],'read_scope':'identity-only dependency; main resource-loader has separate full-read ledger'})
 ck('source-dependency:'+str(rel),sha(b)==x['sha256'])
test=S/'packages/coding-agent/test/resource-loader.test.ts';q=P/'source-context'/test.relative_to(S);q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(test.read_bytes())
dump('source-identity-reuse.json',sources)
runs=[]
for name in ['source-native','source-native-final','source-native-reviewed']:
 meta=json.loads((probe/(name+'.json')).read_text());data=(probe/(name+'.log')).read_bytes();ck('historical-log:'+name,identity(data)=={k:meta[k] for k in ('bytes','sha256')})
 run={'name':name,'execution':'historical only; not rerun','exit_code':meta['exit_code'],'started_at':meta['started_at'],'ended_at':meta['ended_at'],**identity(data)}
 if name!='source-native':
  log=json.loads(data);ck('historical-cases:'+name,log['cases']==23 and len(log['records'])==23 and all(x['status']=='pass' for x in log['records']));run.update(cases=log['cases'],records=log['records'])
 else:ck('historical-failure-preserved',meta['exit_code']==1 and b'AssertionError' in data)
 runs.append(run)
checks_in_probe=re.findall(r"await check\('([^']+)'",(probe/'probe.ts').read_text());reviewed=json.loads((probe/'source-native-reviewed.log').read_text());ck('reviewed-case-names-correspond-to-probe',checks_in_probe==[x['name'] for x in reviewed['records']],count=len(checks_in_probe))
dump('historical-execution-audit.json',{'runs':runs,'distinct_reviewed_cases':23,'new_runtime_executions':0,'mocked_modules':reviewed['mocked_modules'],'boundaries':reviewed['boundaries'],'failure_explanation':'Initial probe expected error but actual preserved diagnostic was warning. Final correction then reviewed strengthening retained as separate historical records; not 46 distinct cases.'})
ledger=[]
def readrow(n,a,b,label,scope):
 data=(P/n).read_bytes();lines=data.splitlines(keepends=True);start=sum(map(len,lines[:a-1]));end=sum(map(len,lines[:b]));frag=data[start:end];out='reading-excerpts/'+label+'.txt';q=P/out;q.parent.mkdir(exist_ok=True);q.write_bytes(frag)
 ledger.append({'id':label,'snapshot':n,'start_line':a,'end_line':b,'start_byte':start,'end_byte':end,'excerpt':out,**identity(frag),'full_sha256':sha(data),'scope':scope})
for i,(a,b) in enumerate([(1,190),(191,390),(391,590),(591,790),(791,990),(991,1097)],1):readrow('source/resource-loader.ts',a,b,'S'+str(i),'new full-source reading, contiguous part; 1-based lines, half-open UTF-8 byte offsets')
for i,(n,a,b) in enumerate([('src/resource_loader.rs',1,280),('src/skills.rs',142,262),('src/skills.rs',281,317),('src/extensions.rs',161,311),('src/prompt_templates.rs',78,195),('src/core.rs',2212,2345),('src/core.rs',2108,2211),('src/slash_actions.rs',46,146),('src/core.rs',6244,6315)],1):readrow('target/'+n,a,b,'T'+str(i),'new bounded context reading; no file acceptance'+('; full current loader file read' if i==1 else '; incidental stale anchor, no resource mapping conclusion' if i==9 else ''))
readrow(str((probe/'probe.ts').relative_to(P)),1,len((probe/'probe.ts').read_bytes().splitlines()),'H-probe','new full probe reading, historical behavior implementation only; not executed')
dump('reading-ranges.json',{'source_full_read':True,'source_lines':1097,'source_bytes':40180,'notes':['Raw excerpt creation follows actual tool reading, not an execution replay.','Old B report reviewed with clipped output recovered by additional bounded reads.','Initial source reads 1-590 used live Pi path, remaining reads used captured copy; exact identity verified.','Other complete target/dependency snapshots are identity evidence only unless listed.','Current core 6244-6315 is an incidental stale anchor; correctly located extension prepare/publish 2108-2211 read subsequently.'],'ranges':ledger})
croot=P/'historical/workerC-reuse/files';refs=json.loads((croot/'Docs/quality/stage1/ZS1-021/worker-reuse320/target-references.json').read_text());comp=[]
for row in refs:
 current=(P/'target'/row['relative_path']).read_bytes();lines=current.splitlines(keepends=True)
 for ex in row['excerpts']:
  old=(croot/ex['artifact']).read_bytes();now=b''.join(lines[ex['line_start']-1:ex['line_end']]);idx=current.find(old)
  comp.append({'path':row['relative_path'],'old_lines':[ex['line_start'],ex['line_end']],'full_same':sha(current)==row['sha256'],'same_line_excerpt_same':old==now,'old_excerpt_sha256':sha(old),'exact_fragment_found':idx>=0,'relocated_lines':None if idx<0 else [current[:idx].count(b'\n')+1,current[:idx+len(old)].count(b'\n')],'reading':'historical fragment identity reuse only'})
  ck('C-fragment-preserved:'+ex['artifact'],sha(old)==ex['sha256'])
dump('C-target-reference-comparison.json',comp)
old123=Path('/Users/wangweiyang/.codex/worktrees/2267/zenpi/.ops/zs1-123-busy-diff321-ready/manifest.json');ck('sealed123-manifest-readonly-identity',sha(old123.read_bytes())=='8392f836280fab40e899267fb49a5324695c83a309faa1a14cf5707be4e2bfb5')
dump('input-audit.json',{'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'execution':'new offline identity/source-evidence audit; no historical script imported or invoked','checks':checks,'passed':all(x['pass'] for x in checks),'new_runtime_executions':0})
print(json.dumps({'checks':len(checks),'passed':all(x['pass'] for x in checks),'failed':[x for x in checks if not x['pass']],'C_reference_comparison':comp},ensure_ascii=False,indent=2))
