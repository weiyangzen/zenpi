# ZS1-021 · 3.1.21 source review candidate

唯一拟整合文件：`Docs/learn/stage1_pi_mono/files/packages/coding-agent/src/core/resource-loader.ts_learn.md`。`candidate.patch`仅创建该报告，保留B旧报告32,797字节前缀后附本轮复核。若主控已生成同路径，应人工merge，不能覆盖。

- 源新完整读：1,097行/40,180字节，6段连续覆盖；阅读范围和原始节选在reading-ranges.json及reading-excerpts/。
- 当前目标：resource_loader.rs整文件新读，skills/extensions/templates/core/slash仅ledger所列范围；其它完整快照只作身份依据。C旧core6244–6315逐字迁移至当前6347–6418，不混用行号。
- 历史B/C三包245物理文件原样保留；C 23场景最终结果仅在4个明确mock边界内复用，初次失败和两次后续日志均保留。13源文件身份匹配。本轮产品/源runtime执行0。
- 387项新离线输入检查通过，不是行为测试次数；主控acceptance仍为false。唯一正式依赖001的34个receipt artifacts按hash复制，本轮不验收目录/123/114/整阶段。
- 初末authority六份、目标九份快照相同。main标准报告与021 master receipt在最终观察时不存在。没有写main、claims、authority、产品、旧ready；123冻结manifest只读核对。

可将整个目录复制到任意路径，运行：

```sh
cd /tmp
python3 /absolute/path/to/packet/verify_packet.py > /absolute/path/outside-packet/portable.json
```

新verifier仅用Python标准库，根目录由自己的`__file__`定位，只读本包；不访问历史绝对机器路径、网络或产品，不import/run历史脚本，不创建pycache。外置receipt避免manifest自引用。manifest.json包含自身之外所有payload的路径、bytes、SHA256及总数。准备脚本只作为生成过程记录，移交后不运行；特别不要运行historical/中的任何旧runner。

这是便携候选，等待主控独立全文复核和当前项G-STAGE/manual receipt。回滚只撤本报告候选及本轮私有包，不改其它项。
