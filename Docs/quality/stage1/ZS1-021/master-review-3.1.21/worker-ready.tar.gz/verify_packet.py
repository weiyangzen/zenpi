#!/usr/bin/env python3
"""Read-only portable evidence verifier; never imports/executes captured programs."""
from pathlib import Path
import datetime,difflib,hashlib,json,re,sys
P=Path(__file__).resolve().parent
checks=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def read(n):return (P/n).read_bytes()
def js(n):return json.loads(read(n))
def ck(n,v,**info):checks.append({'name':n,'pass':bool(v),**info})
def safe(n):return not Path(n).is_absolute() and '..' not in Path(n).parts
R='Docs/learn/stage1_pi_mono/files/packages/coding-agent/src/core/resource-loader.ts_learn.md'
EXPECTED={'blueprint_version':'3.1.21','requirement_digest':'3456abcbbebbc4e0ab383c319851b0a6e71b19ee9b3c060a6e212f61a89c9d9d','baseline_snapshot_sha256':'92b06c4b1dcdca7614d226ce5f41205646a9e63967789d2b6ed4ee272d240884','run_id':'zenpi-stage1-20260911'}
def main():
 m=js('manifest.json');rows=m['payload'];listed=[x['path'] for x in rows]
 actual=sorted(str(x.relative_to(P)) for x in P.rglob('*') if x.is_file() and x!=P/'manifest.json')
 ck('manifest-path-set',sorted(listed)==actual and len(listed)==len(set(listed)))
 ck('manifest-no-symlinks',not any(x.is_symlink() for x in P.rglob('*')))
 for x in rows:
  ck('safe-relative:'+x['path'],safe(x['path']))
  b=read(x['path']);ck('payload:'+x['path'],len(b)==x['bytes'] and sha(b)==x['sha256'])
 ck('manifest-total',m['payload_bytes']==sum(x['bytes'] for x in rows) and m['payload_files']==len(rows))
 ck('candidate-not-acceptance',m['item']=='ZS1-021' and m['master_accepted'] is False and m['product_changes'] is False and m['new_runtime_executions']==0 and m['owned_paths']==[R])
 source=read('source/resource-loader.ts');ck('full-source-identity',len(source)==40180 and len(source.splitlines())==1097 and sha(source)=='1877e9535820cb8b45e5a84598ac8ae581058bb0fbee6f0c64ec672f8ab986dd')
 ledger=js('reading-ranges.json');sr=[r for r in ledger['ranges'] if r['id'].startswith('S')]
 ck('source-six-actual-read-ranges',[(r['start_line'],r['end_line']) for r in sr]==[(1,190),(191,390),(391,590),(591,790),(791,990),(991,1097)])
 ck('source-bytes-contiguous',sr[0]['start_byte']==0 and sr[-1]['end_byte']==len(source) and all(a['end_byte']==b['start_byte'] for a,b in zip(sr,sr[1:])))
 ck('source-excerpts-reassemble',b''.join(read(r['excerpt']) for r in sr)==source)
 for row in ledger['ranges']:
  full=read(row['snapshot']);lines=full.splitlines(keepends=True);frag=b''.join(lines[row['start_line']-1:row['end_line']]);ck('reading:'+row['id'],read(row['excerpt'])==frag==full[row['start_byte']:row['end_byte']] and len(frag)==row['bytes'] and sha(frag)==row['sha256'] and sha(full)==row['full_sha256'])
 for root in ['authority','authority-final']:
  s=js(root+'/Docs/execution/active_requirement.json');ck('authority-four-keys:'+root,all(s[k]==v for k,v in EXPECTED.items()) and s['active'] is True)
  ck('authority-source-baseline:'+root,s['baseline_files']['ZS1-021']['sha256']==sha(source) and s['baseline_files']['ZS1-021']['bytes']==len(source))
  bp=read(root+'/Docs/stage_1_v3_pi_mono_blueprint.md').decode();lines=bp.splitlines()
  own=[l for l in lines if re.match(r'- \[[^]]\] \*\*ZS1-021\*\*',l)];dep=[l for l in lines if re.match(r'- \[[^]]\] \*\*ZS1-001\*\*',l)]
  ck('authority-scoped-item:'+root,len(own)==1 and 'Depends: ZS1-001 |' in own[0] and R in own[0] and not own[0].startswith('- [x]'))
  ck('authority-scoped-dependency:'+root,len(dep)==1 and dep[0].startswith('- [x]'))
  claims=js(root+'/Docs/learn/stage1_pi_mono/claims.json')['claims'];ownclaims=[c for c in claims if c['item_id']=='ZS1-021']
  ck('claim-owner:'+root,len(ownclaims)==1 and ownclaims[0]['owned_paths']==[R] and ownclaims[0]['session']=='01a08be3-4677-7463-832b-bdb571ea6b9a' and ownclaims[0]['requirement_digest']==EXPECTED['requirement_digest'] and ownclaims[0]['run_id']==EXPECTED['run_id'])
  rec=js(root+'/Docs/learn/stage1_pi_mono/receipts/ZS1-001.master.json');ck('dependency-receipt:'+root,rec['complete'] and rec['item_id']=='ZS1-001' and rec['role']=='master' and all(rec[k]==EXPECTED[k] for k in ['requirement_digest','baseline_snapshot_sha256','run_id']))
 before=js('authority/Docs/execution/active_requirement.json');after=js('authority-final/Docs/execution/active_requirement.json')
 ck('authority-key-stability',all(before[k]==after[k] for k in EXPECTED))
 for n in ['Docs/stage_1_v3_pi_mono_blueprint.md','Docs/learn/stage1_pi_mono/claims.json']:
  a=read('authority/'+n);b=read('authority-final/'+n)
  ck('observed-full-authority-stability:'+n,a==b)
 for x in js('authority/Docs/learn/stage1_pi_mono/receipts/ZS1-001.master.json')['artifacts']:
  b=read('formal-dependency/'+x['path']);ck('formal001-artifact:'+x['path'],sha(b)==x['sha256'] and len(b)==x['bytes'])
 ck('formal001-rebind-read-identity',sha(read('formal-dependency/Docs/quality/stage1/ZS1-001/master-rebind-3.1.21/review.md'))=='4469f72b134af732ad85b54083e028b1b950a53fddc6612679656edcfac2f351')
 for x in js('input-inventory.json')['target']:
  initial=read('target/'+x['path']);final=read('target-final/'+x['path']);ck('target-capture:'+x['path'],initial==final and sha(initial)==x['sha256'] and len(initial)==x['bytes'])
 observation=js('final-observation.json');ck('final-observation',not observation['master_report_exists'] and not observation['master_receipt_exists'] and all(x['same'] for x in observation['source']))
 for x in js('source-identity-reuse.json'):
  b=read(x['snapshot']);ck('source-reuse:'+x['snapshot'],sha(b)==x['sha256']==x['historical_sha256'] and len(b)==x['bytes'])
 for x in js('historical-inventory.json'):
  b=read('historical/'+x['path']);ck('historical-preservation:'+x['path'],sha(b)==x['sha256'] and len(b)==x['bytes'])
 for kind in ['workerB','workerC-behavior','workerC-reuse']:
  old=js('historical/'+kind+'/manifest.json')
  rr=old['artifacts'].items() if kind=='workerB' else [(x['path'],x) for x in old['files']]
  for path,x in rr:
   b=read('historical/'+kind+('/' if kind=='workerB' else '/files/')+path);ck('old-manifest:'+kind+'/'+path,len(b)==x['bytes'] and sha(b)==x['sha256'])
 refs=js('historical/workerB/evidence/context-references.json')['references']
 for ref in refs:
  prefix='/Users/wangweiyang/GitHub/zenpi/';snap='target/'+ref['source'][len(prefix):] if ref['source'].startswith(prefix) else 'source-context/packages/coding-agent/test/resource-loader.test.ts'
  raw=read(snap);frag=b''.join(raw.splitlines(keepends=True)[ref['start_line']-1:ref['end_line']]);old=read('historical/workerB/evidence/'+ref['excerpt']);ck('B-reference:'+ref['id'],old==frag and len(old)==ref['bytes'] and sha(old)==ref['sha256'])
 cp='historical/workerC-reuse/files/'
 for ref in js(cp+'Docs/quality/stage1/ZS1-021/worker-reuse320/target-references.json'):
  raw=read('target/'+ref['relative_path'])
  for ex in ref['excerpts']:
   frag=read(cp+ex['artifact']);ck('C-reference:'+ex['artifact'],sha(frag)==ex['sha256'] and frag in raw)
 pr='historical/workerC-behavior/files/Docs/quality/stage1/ZS1-021/worker-source-probe/'
 for name,code in [('source-native',1),('source-native-final',0),('source-native-reviewed',0)]:
  run=js(pr+name+'.json');log=read(pr+name+'.log');ck('historical-execution:'+name,run['exit_code']==code and run['bytes']==len(log) and run['sha256']==sha(log))
  if code==0:
   result=json.loads(log);ck('historical-23-results:'+name,result['cases']==len(result['records'])==23 and all(r['status']=='pass' for r in result['records']))
  else:ck('preserved-failure-stack',b'AssertionError' in log)
 results=js(pr+'source-native-reviewed.log');names=re.findall(r"await check\('([^']+)'",read(pr+'probe.ts').decode());ck('reviewed-case-names',names==[r['name'] for r in results['records']] and len(set(names))==23)
 ck('four-explicit-doubles',set(results['mocked_modules'])=={'core/package-manager.ts','core/settings-manager.ts','core/extensions/loader.ts','modes/interactive/theme/theme.ts'})
 inp=js('input-audit.json');ck('new-input-audit-record',len(inp['checks'])==387 and inp['passed'] and all(c['pass'] for c in inp['checks']) and inp['new_runtime_executions']==0)
 previous=read('historical/workerB/'+R);report=read(R)
 ck('report-immutable-prefix',len(previous)==32797 and report.startswith(previous) and sha(previous)=='cd8de44c352ac754ea520d258dec0941171e756fb262e95862fdb39db3305a04')
 ck('report-addendum',report==previous+read('current-addendum.md') and all(v.encode() in report for v in EXPECTED.values()))
 patch=''.join(difflib.unified_diff([],report.decode().splitlines(keepends=True),fromfile='/dev/null',tofile='b/'+R)).encode();ck('single-owned-create-patch',patch==read('candidate.patch'))
 ck('report-has-limits',all(t.encode() in report for t in ['master_accepted=false','本轮运行次数0','不是387个行为测试','6347–6418','不验收 ZS1-056']))
try:main()
except Exception as e:ck('verifier-exception',False,error=type(e).__name__+': '+str(e))
result={'schema':'zs1-021-portable-audit/v1','generated_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'packet_manifest_sha256':sha(read('manifest.json')),'execution':'new read-only Python offline verification; no captured scripts imported/executed; no external path access','cwd':str(Path.cwd()),'checks':checks,'check_count':len(checks),'passed':all(c['pass'] for c in checks),'new_product_or_source_runtime_executions':0,'master_accepted':False}
print(json.dumps(result,ensure_ascii=False,indent=2));sys.exit(0 if result['passed'] else 1)
