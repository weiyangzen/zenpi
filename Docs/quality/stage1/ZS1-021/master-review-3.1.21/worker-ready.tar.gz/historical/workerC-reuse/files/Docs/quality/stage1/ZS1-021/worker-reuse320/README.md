# ZS1-021 source reuse, authority 3.1.20, worker candidate [_]

Only resource-loader.ts. Complete ordered source read: 1097 lines / 40180 bytes / SHA-256 1877e9535820cb8b45e5a84598ac8ae581058bb0fbee6f0c64ec672f8ab986dd. input-manifest.json binds exact four read chunks; report retains previous 13351-byte prefix. See report supplement for actual discovery, precedence, trust and reload failure boundaries and current Zenpi mapping.

Old immutable package: .ops/source021-behavior-ready, manifest SHA acf161d1c0b40246f445ac8ce88866d95c216e07c4f6f948a65d77451b36fb8f. Its 15 files are checked. 23 historical controller cases passed with four explicitly mocked package/settings/extension-loader/theme boundaries; real filesystem, prompt/skill parsers, source-info and Git finder. Manual Git metadata is not a real git worktree command; directory-read warning is not an EACCES test. Initial wrong missing-skill error expectation is preserved alongside corrected final/reviewed logs. Target 12 resource tests and historical 68 pass / 1 ignored host recheck remain historical. No new runtime/Cargo/Bun/network/install/depth probe executed.

7 current target file hashes and 11 read excerpts are anchored in target-references.json; only mapping snippets, not whole-target-file acceptance. Four owners match historical recorded main hashes, core differs. New hashes do not transfer old runtime claims onto new core. historical/ contains byte-exact copies of eight earlier references, including old manifests and target logs; these copies preserve their original scopes.

Pure integrity replay from /Users/wangweiyang/.codex/worktrees/ff51/zenpi:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 Docs/quality/stage1/ZS1-021/worker-reuse320/verify_reuse.py
```

Old behavior replay, only if independently needed, requires existing Bun and .ops/source021-runtime/node_modules; package and lock remain in worker-source-probe:

```sh
env NODE_PATH=/Users/wangweiyang/.codex/worktrees/ff51/zenpi/.ops/source021-runtime/node_modules bun Docs/quality/stage1/ZS1-021/worker-source-probe/probe.ts
```

The frozen delivery includes all 14 old evidence files unchanged and the full report as new paths because they are absent in the main tree, plus this supplement. Patch is checked forward/reverse with byte hashes in a temporary tree. integrity-final is an actual pure Python/G-FILE check, not a new runtime test. gstage-main is the actual read-only primary validator result; a missing master receipt is retained as failure and never converted into acceptance. No main/source writes, commits or acceptance marks.
