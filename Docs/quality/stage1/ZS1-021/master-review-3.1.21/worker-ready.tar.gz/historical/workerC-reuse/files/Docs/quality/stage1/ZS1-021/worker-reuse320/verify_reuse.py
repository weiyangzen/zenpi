from pathlib import Path
import hashlib,json,runpy,sys,re
ROOT=Path.cwd();EV=ROOT/'Docs/quality/stage1/ZS1-021/worker-reuse320';MAIN=Path('/Users/wangweiyang/GitHub/zenpi');sha=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((EV/'input-manifest.json').read_text());b=Path(m['source']).read_bytes();assert len(b)==40180 and len(b.splitlines())==1097 and sha(b)==m['sha256']==m['frozen']['sha256'];assert (EV/'resource-loader.ts').read_bytes()==b
parts=[];ranges=[]
for c in m['ordered_complete_read_chunks']:
 d=(ROOT/c['artifact']).read_bytes();assert d==b[c['byte_start']:c['byte_end']] and sha(d)==c['sha256'];parts.append(d);ranges.append([c['byte_start'],c['byte_end']])
assert b''.join(parts)==b
reuse=json.loads((EV/'reused-evidence.json').read_text());pkg=Path(reuse['package']);assert sha((pkg/'manifest.json').read_bytes())==reuse['manifest_sha256']
for r in reuse['records']:
 d=Path(r['path']).read_bytes();assert len(d)==r['bytes'] and sha(d)==r['sha256'],r['path']
for r in reuse['historical_copies']:
 assert (ROOT/r['artifact']).read_bytes()==(ROOT/r['original']).read_bytes()
old=pkg/'files/Docs/quality/stage1/ZS1-021/worker-source-probe'
for name,code in [('source-native',1),('source-native-final',0),('source-native-reviewed',0)]:
 r=json.loads((old/(name+'.json')).read_text());d=(old/(name+'.log')).read_bytes();assert r['exit_code']==code and r['bytes']==len(d) and r['sha256']==sha(d)
source=json.loads((old/'source-native-reviewed.log').read_text());assert source['cases']==len(source['records'])==23 and all(c['status']=='pass' for c in source['records']) and len(source['mocked_modules'])==4
assert (old/'probe.ts').read_text().count('mock.module(')==4
hist=EV/'historical/Docs/quality/stage1/ZS1-114'
commands=json.loads((hist/'worker-resources/commands.json').read_text());r=commands[0];d=(hist/'worker-resources/tests.log').read_bytes();assert r['exit_code']==0 and r['output_bytes']==len(d) and r['output_sha256']==sha(d)
assert '12 passed; 0 failed' in d.decode()
recheck=(hist/'worker-current-recheck/tests.log').read_text();results=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',recheck);assert sum(int(x[0]) for x in results)==68 and sum(int(x[1]) for x in results)==0 and sum(int(x[2]) for x in results)==1,results
report=ROOT/'Docs/learn/stage1_pi_mono/files/packages/coding-agent/src/core/resource-loader.ts_learn.md';text=report.read_bytes();prior=(EV/'prior-report.md').read_bytes();assert text.startswith(prior) and sha(prior)=='e7770faa4ce5ef8d595b3469dec1e7d2b195920d79944fc95701239b72f7487c'
count=0
for r in json.loads((EV/'target-references.json').read_text()):
 d=Path(r['path']).read_bytes();assert len(d)==r['bytes'] and sha(d)==r['sha256'],r['path']
 for c in r['excerpts']:
  part=(ROOT/c['artifact']).read_bytes();assert part==d[c['byte_start']:c['byte_end']] and sha(part)==c['sha256'];count+=1
sys.path.insert(0,str(MAIN/'tools'));g=runpy.run_path(str(MAIN/'tools/validate_stage1_blueprint.py'));bp=g['parse']((MAIN/'Docs/stage_1_v3_pi_mono_blueprint.md').read_text());f=bp.files['ZS1-021'];assert f.path==m['source_path'] and f.sha256==m['sha256'] and bp.requirement==m['requirement_digest'];g['check_ranges'](ranges,len(b));g['artifact'](ROOT,{'path':str(report.relative_to(ROOT)),'bytes':len(text),'sha256':sha(text)})
sel=json.loads((MAIN/'Docs/execution/active_requirement.json').read_text());assert sel['blueprint_version']==m['authority'] and sel['requirement_digest']==m['requirement_digest'] and sel['baseline_files']['ZS1-021']==m['frozen']
print(json.dumps({'ok':True,'source_bytes':len(b),'source_lines':1097,'read_ranges':ranges,'reused_manifest_sha256':reuse['manifest_sha256'],'reused_artifacts':len(reuse['records']),'historical_source_cases':23,'mocked_source_subsystems':4,'historical_resource_tests':12,'historical_target_recheck_passed':68,'historical_target_recheck_ignored':1,'new_runtime_tests':0,'target_excerpts':count,'report_bytes':len(text),'report_sha256':sha(text),'checks':'Actual G-FILE source/range/artifact; preserved report prefix; immutable historical evidence/receipts including initial failure; current target hashes','not_claimed':'Package install, settings persistence locks, real jiti/cache, actual theme validation, remote model execution, entire dependency graph freeze, current runtime rerun or master/directory acceptance'},indent=2))
