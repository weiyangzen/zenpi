# ZS1-021 single-file ready

provisional；learn_mode: understand。唯一源resource-loader.ts全文1097行/40180字节，SHA256 1877e9535820cb8b45e5a84598ac8ae581058bb0fbee6f0c64ec672f8ab986dd；报告 Docs/learn/stage1_pi_mono/files/packages/coding-agent/src/core/resource-loader.ts_learn.md，32797字节，SHA256 cd8de44c352ac754ea520d258dec0941171e756fb262e95862fdb39db3305a04。

candidate.patch只新增上述标准报告，master/worker before均absent。正式源连续五段完整阅读；16个有界目标/测试上下文精确记录整文件hash、行/字节和片段hash，当前核对无漂移，不代表目标整文件验收。

覆盖所有类型、getter、公开/私有函数，分类发现/CLI与默认优先、canonical路径与名称碰撞、context祖先与nested worktree、SYSTEM/APPEND信任规则、sourceInfo、inline与两阶段预加载、override及失败状态。源reload逐字段更新无统一回滚；target resource快照原子发布为增强，extension由host另准备/发布；旧Arc不保证未加载技能正文永远可读。实际extension冲突检测只处理tools/flags，commands由runner处理。

G-FILE辅助字节结构通过；G-STAGE实际exit1、structural.ok=true，唯一错误缺ZS1-021.master.json，semantic/manual pending。没有生成master receipt或complete状态。源/目标产品测试、Cargo、PTY、HTTP、网络均0。没有改master/产品/018/125/旧ready/调度器，也没有新任务/subagent。

018与两份125ready共152个artifacts及3个manifest精确核验保留。verify.py只校验本包与临时git目录正反check/apply/hash/sentinel，不运行产品，不写主库。运行记录在本包外的zs1-021-work/offline-verification.json。master应独立复核语义和集成，不能直接把worker命令当阶段验收。
