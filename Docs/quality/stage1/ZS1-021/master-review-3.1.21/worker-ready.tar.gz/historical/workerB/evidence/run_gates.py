from pathlib import Path
import hashlib,json,subprocess,datetime,sys
W=Path(__file__).resolve().parent;M=Path('/Users/wangweiyang/GitHub/zenpi')
sha=lambda b:hashlib.sha256(b).hexdigest()
argv=['python3','-B',str(W/'context/tools/validate_stage1_blueprint.py'),'--root',str(M),'--blueprint','Docs/stage_1_v3_pi_mono_blueprint.md','--evidence-root','Docs/learn/stage1_pi_mono','--source-root','/Users/wangweiyang/GitHub/pi-mono','--item','ZS1-021','--json']
start=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(argv,cwd=W,capture_output=True)
(W/'gstage.stdout.json').write_bytes(p.stdout);(W/'gstage.stderr.log').write_bytes(p.stderr)
receipt={'argv':argv,'cwd':str(W),'started_at':start,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':p.returncode,'environment_overrides':{},'python_bytecode_disabled':True,'master_root_read_only':True,'stdout':{'path':'gstage.stdout.json','bytes':len(p.stdout),'sha256':sha(p.stdout)},'stderr':{'path':'gstage.stderr.log','bytes':len(p.stderr),'sha256':sha(p.stderr)}}
(W/'gstage.run.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(p.stdout.decode());print('exit_code',p.returncode)
stage=json.loads(p.stdout);assert stage['structural']['ok'] and p.returncode==1 and not stage['ok']
assert len(stage['errors'])==1 and 'ZS1-021.master.json' in stage['errors'][0]
report=W/'report.md';text=report.read_text()
assert '### 本轮实际结构门禁' not in text
text+='\n### 本轮实际结构门禁与定位表\n\nG-STAGE 实际 exit 1，structural.ok=true，唯一错误是主库缺少 `Docs/learn/stage1_pi_mono/receipts/ZS1-021.master.json`。没有创建该receipt。G-FILE 本地仅检查source hash、完整范围、report身份和context片段hash；semantic_verified_by_checker=false，master语义复核仍pending。产品行为执行数为0。\n\n以下行/字节为context原文件的一基闭合行范围、零基半开字节范围；片段SHA和source文件SHA完整记录于evidence/context-references.json。这里的定位表不扩大正式复核范围。\n\n| ID | 上下文文件 | 行 | 字节 | 文件SHA256 |\n|---|---|---|---|---|\n'
refs=json.loads((W/'context-references.json').read_text())['references']
for r in refs:
 text+=f"| {r['id']} | {r['source']} | {r['start_line']}–{r['end_line']} | [{r['start_byte']},{r['end_byte']}) | `{r['source_sha256']}` |\n"
report.write_text(text)
sys.dont_write_bytecode=True;sys.path.insert(0,str(W/'context/tools'))
import validate_stage1_blueprint as gate
source=(W/'source/resource-loader.ts').read_bytes();lines=source.splitlines(keepends=True);ranges=[];reads=[];offset=0
for start in range(0,len(lines),220):
 b=b''.join(lines[start:start+220]);ranges.append([offset,offset+len(b)]);reads.append({'start_line':start+1,'end_line':min(start+220,len(lines)),'start_byte':offset,'end_byte':offset+len(b),'sha256':sha(b)});offset+=len(b)
gate.check_ranges(ranges,len(source));bp=gate.parse((W/'context/Docs/stage_1_v3_pi_mono_blueprint.md').read_text());f=bp.files['ZS1-021']
assert sha(source)==f.sha256 and f.path in text and f.sha256 in text
for r in refs:
 b=(W/r['excerpt']).read_bytes();assert len(b)==r['bytes'] and sha(b)==r['sha256']
drift=sorted({r['source'] for r in refs if sha(Path(r['source']).read_bytes())!=r['source_sha256']})
inputs=json.loads((W/'inputs.json').read_text())['files']
input_drift=[p for p,r in inputs.items() if 'copy' in r and sha(Path(p).read_bytes())!=r['sha256']]
g={'item':'ZS1-021','learn_mode':'understand','source_sha256':sha(source),'source_bytes':len(source),'source_lines':len(lines),'read_ranges':ranges,'ordered_reads':reads,'report_path':f.artifact,'report_sha256':sha(report.read_bytes()),'report_bytes':report.stat().st_size,'context_excerpts':len(refs),'context_hashes_verified':True,'current_context_drift':drift,'current_input_drift':input_drift,'structural_checks_passed':True,'semantic_verified_by_checker':False,'master_receipt_created':False,'source_tests_run':0,'target_tests_run':0,'scope':'source understand + bounded target mapping; independent master semantic G-FILE pending'}
(W/'gfile.json').write_text(json.dumps(g,indent=2)+'\n');print(json.dumps(g,indent=2))
