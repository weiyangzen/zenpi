from pathlib import Path
import json,hashlib,difflib,shutil
W=Path(__file__).resolve().parent;R=W.parent/'zs1-021-ready';assert not R.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
g=json.loads((W/'gfile.json').read_text());rel=g['report_path'];report=(W/'report.md').read_bytes()
assert sha(report)==g['report_sha256']
for root in [W.parent.parent,Path('/Users/wangweiyang/GitHub/zenpi')]:assert not (root/rel).exists()
p=R/rel;p.parent.mkdir(parents=True);p.write_bytes(report)
(R/'candidate.patch').write_text(''.join(difflib.unified_diff([],report.decode().splitlines(True),fromfile='/dev/null',tofile='b/'+rel)))
for file in W.rglob('*'):
 if not file.is_file() or file.name in ['report.md','verify.py']:continue
 dest=R/'evidence'/file.relative_to(W);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(file,dest)
shutil.copyfile(W/'verify.py',R/'verify.py')
checked=[]
for name,digest in {
 'zs1-018-ready':'e7047e64ee2a3a2b67cfdeab755ba546272a4e6aa648e0293695fc461568e60a',
 'zs1-125-render-tail-ready':'822b201ac8e8f3f5bb4172599ac42c807addbba69c13362d24c26576d36f9581',
 'zs1-125-tail-wiring-ready':'492042afb6a11f28fb6527a4b709e800bd0d3fff247798e229c3637eeae90c4d',
}.items():
 root=W.parent/name;manifest=root/'manifest.json';assert sha(manifest.read_bytes())==digest
 items=json.loads(manifest.read_text())['artifacts']
 for path,rec in items.items():
  b=(root/path).read_bytes();assert sha(b)==rec['sha256'] and len(b)==rec['bytes']
 checked.append({'ready':str(root),'manifest_sha256':digest,'artifacts':len(items),'all_exact':True})
(R/'evidence/prior-ready-preservation.json').write_text(json.dumps(checked,indent=2)+'\n')
(R/'evidence/read-observations.txt').write_text('Prior-report rg search found no matching worker .ops/Docs or master Docs/learn paths (expected rg no-match exit 1); standard report before absent in both checkouts. One broad blueprint keyword locator output was truncated; exact protocol lines 130-155 and ZS1-021 row were read separately. Formal source was read in five untruncated contiguous chunks. Context T3 initially ended at 302; extended to 311 and read registration commit tail before packaging. T10 is explicitly a bounded test fragment ending at 290, not the entire test. No source or target behavior tests executed. G-STAGE command exit 1 is retained, not suppressed as semantic success. No master/worker authority status modified.\n')
(R/'README.md').write_text(f'''# ZS1-021 single-file ready

provisional；learn_mode: understand。唯一源resource-loader.ts全文1097行/40180字节，SHA256 {g['source_sha256']}；报告 {rel}，{len(report)}字节，SHA256 {g['report_sha256']}。

candidate.patch只新增上述标准报告，master/worker before均absent。正式源连续五段完整阅读；16个有界目标/测试上下文精确记录整文件hash、行/字节和片段hash，当前核对无漂移，不代表目标整文件验收。

覆盖所有类型、getter、公开/私有函数，分类发现/CLI与默认优先、canonical路径与名称碰撞、context祖先与nested worktree、SYSTEM/APPEND信任规则、sourceInfo、inline与两阶段预加载、override及失败状态。源reload逐字段更新无统一回滚；target resource快照原子发布为增强，extension由host另准备/发布；旧Arc不保证未加载技能正文永远可读。实际extension冲突检测只处理tools/flags，commands由runner处理。

G-FILE辅助字节结构通过；G-STAGE实际exit1、structural.ok=true，唯一错误缺ZS1-021.master.json，semantic/manual pending。没有生成master receipt或complete状态。源/目标产品测试、Cargo、PTY、HTTP、网络均0。没有改master/产品/018/125/旧ready/调度器，也没有新任务/subagent。

018与两份125ready共152个artifacts及3个manifest精确核验保留。verify.py只校验本包与临时git目录正反check/apply/hash/sentinel，不运行产品，不写主库。运行记录在本包外的zs1-021-work/offline-verification.json。master应独立复核语义和集成，不能直接把worker命令当阶段验收。
''')
m={'item':'ZS1-021','scope':'one source file understand report; bounded target context only','complete':False,'master_accepted':False,'product_changes':False,'report_path':rel,'report_sha256':g['report_sha256'],'source_sha256':g['source_sha256'],'source_bytes':40180,'source_lines':1097,'before_master':'absent','before_worker':'absent','source_tests_run':0,'target_tests_run':0,'cargo_runs':0,'pty_runs':0,'http_runs':0,'network_runs':0,'gstage_exit_code':1,'gstage_structural_ok':True,'master_receipt':'missing; not fabricated'}
m['artifacts']={str(p.relative_to(R)):{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(R.rglob('*')) if p.is_file()}
(R/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
print(json.dumps({'ready':str(R),'artifacts':len(m['artifacts']),'manifest_sha256':sha((R/'manifest.json').read_bytes()),'report_sha256':g['report_sha256'],'patch_sha256':sha((R/'candidate.patch').read_bytes()),'README_sha256':sha((R/'README.md').read_bytes())},indent=2))
