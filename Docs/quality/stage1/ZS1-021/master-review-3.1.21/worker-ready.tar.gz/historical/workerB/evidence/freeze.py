from pathlib import Path
import json,hashlib,datetime
W=Path(__file__).resolve().parent;M=Path('/Users/wangweiyang/GitHub/zenpi')
S=Path('/Users/wangweiyang/GitHub/pi-mono/packages/coding-agent/src/core/resource-loader.ts')
records={}
def capture(p,rel):
 b=p.read_bytes();q=W/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);records[str(p)]={'copy':rel,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()};return b
b=capture(S,'source/resource-loader.ts');assert hashlib.sha256(b).hexdigest()=='1877e9535820cb8b45e5a84598ac8ae581058bb0fbee6f0c64ec672f8ab986dd'
for rel in ['Docs/stage_1_v3_pi_mono_blueprint.md','Docs/execution/active_requirement.json','Docs/learn/stage1_pi_mono/source_manifest.tsv','Docs/learn/stage1_pi_mono/file_learn_index.tsv','tools/validate_stage1_blueprint.py','tools/validate_blueprint.py']:
 capture(M/rel,'context/'+rel)
report='Docs/learn/stage1_pi_mono/files/packages/coding-agent/src/core/resource-loader.ts_learn.md'
for root,label in [(M,'master'),(Path.cwd(),'worker')]:
 p=root/report;records[label+'_standard_report']={'exists':p.exists()}
 if p.exists():capture(p,'before/'+label+'.md')
for p,r in records.items():
 if 'copy' in r:assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==r['sha256']
(W/'inputs.json').write_text(json.dumps({'captured_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':records},indent=2)+'\n')
print(len(b),len(b.splitlines()))
