# ZS1-021 — packages/coding-agent/src/core/resource-loader.ts

Worker candidate: provisional；learn_mode: understand。仅本源文件完整理解与有界目标映射，master 独立语义 G-FILE 尚未通过。

source_id: SRC-0931
source_path: packages/coding-agent/src/core/resource-loader.ts
source_hash: 1877e9535820cb8b45e5a84598ac8ae581058bb0fbee6f0c64ec672f8ab986dd
source_bytes: 40180
source_lines: 1097
coverage: 完整字节区间 [0,40180)，按 1–220、221–440、441–660、661–880、881–1097 连续全文阅读，包含声明、注释、构造器、所有私有辅助函数和文件结尾；未执行源代码。小于 256 KiB，不触发大文件强制分块。

唯一标准产物：`Docs/learn/stage1_pi_mono/files/packages/coding-agent/src/core/resource-loader.ts_learn.md`。捕获前搜索本 worker `.ops`/`Docs` 的 ZS1-021/resource-loader.ts 及主库 Docs/learn，没有找到既有完整 ready 或标准报告；标准路径在 master/worker 均 absent。因此新建本报告，不覆盖旧结论，不借其他项的接受状态。输入 authority、manifest/index、checker 精确副本与 hash 在 evidence/inputs.json；目标仅使用 evidence/context-references.json 指定的行、字节和 hash 片段，无目标整文件接受声明。报告沿用 G-FILE 的身份、全文语义、行为判据、目标映射和证据限界格式。

## 职责、类型和状态所有权（1–53、159–303）

该文件是资源编排器：通过 SettingsManager/DefaultPackageManager 获得资源路径，再分别加载 executable extensions、skills、prompt templates、themes、context files、system/append prompt。它不实现技能 Markdown/YAML 语法、模板参数展开、扩展工具实际执行、包安装协议、模型调用或 session 持久化。导入的路径/Git/BOM/source-info/timing/theme/extension 工具各有独立 owner；这里说明其调用条件和结果使用，不把依赖模块算作已整文件复核。

ResourceExtensionPaths 只有 skillPaths/promptPaths/themePaths 三组 `{path, metadata}`；名字中的 Extension 表示扩展贡献资源，不允许用它动态添加新的 extension module。ResourceLoaderReloadOptions 仅有可选异步 resolveProjectTrust 回调，参数为预加载的 extensionsResult、结果 boolean，无 AbortSignal。ResourceLoader 接口有九个资源 getter、extendResources 和 reload；类的公开 loadProjectTrustExtensions 不在该接口中。ResourceCollision/ResourceDiagnostic 是外部声明的 re-export，本文件不另定义其 schema。

DefaultResourceLoaderOptions 必须给 cwd、agentDir；可注入 settingsManager/eventBus，可添加四类路径、inline extensionFactories、五种 no* 开关、显式 systemPrompt/appendSystemPrompt，以及 extensions/skills/prompts/themes/agentsFiles/systemPrompt/appendSystemPrompt 七类 override。override 同步执行，可替换/删除/重排结果，也可抛异常；不是验证器或隔离沙箱。类型系统约束不能当作运行时数据验证。

构造器 resolve cwd/agentDir，缺省创建 settings/eventBus/packageManager；保留选项路径数组和工厂数组引用，未冻结或复制。结果初始为空 arrays/diagnostics，extensionsResult 有新 runtime，systemPrompt/sourcePath 为 undefined，last*Paths、三个 extension source-info Map、metadata Map 为空，loaded=false。构造器没有调用 reload；创建默认 SettingsManager 的具体 I/O 不归本文件保证为纯操作。

getExtensions 直接返回内部结果对象；getSkills/getPrompts/getThemes/getAgentsFiles 仅新建外层 wrapper，内部数组/对象共享。getSystemPrompt 是字符串/undefined；getAppendSystemPrompt 返回共享数组；两个 source getter 构造新 `{path}` 对象/数组。没有版本号、不可变 generation、锁、深复制或并发调用互斥。调用者持有旧引用与后续字段替换、对象原地 sourceInfo 修改的关系必须分别理解。

## 文本输入与上下文发现（54–158）

resolvePromptInput：undefined 或空字符串直接返回 undefined；存在的 input 路径 readFileSync UTF-8 并 stripBom；读失败输出黄色 console.error 后返回原 input 字符串；不存在路径也按字面文本返回。这里不先做 cwd/tilde/file URL 规范化，不检查必须普通文件、不设读取字节上限。因而存在但不可读的路径并非使整个 reload 必然失败，也不能保证返回的是文件内容。

loadContextFileFromDir 按 AGENTS.override.md、AGENTS.md、AGENTS.MD、CLAUDE.md、CLAUDE.MD 顺序尝试；跳过不存在和非普通文件；stat/read 错误警告后尝试下一个。每目录只取第一个成功项，stripBom；都失败返回 null。不同大小写在具体文件系统可能指同一文件，本文件没有另外大小写归一化。

findShadowedContextFile 先 findGitPaths，再 canonicalize commonGitDir/repoDir，取 dirname(commonGitDir) 为主库候选；只在 worktree root 真正位于该主库内、且主库 `.git` canonical 路径等于 commonGitDir 时处理。worktree root 自己找到 context 后，返回主库下同 basename 的候选，避免 nested worktree 与祖先主库的同名逻辑副本重复。不比较内容 hash，不把不同文件名当同一副本，不清除所有祖先；普通 repo、sibling worktree、bare 容器、submodule 不满足该结构时不屏蔽。返回值是 canonical 主库目录 join basename；不能将注释推成对任意 context 文件 symlink 的完整规范化保证。

loadProjectContextFiles 先 resolve cwd/agentDir、加载 global context 并登记原路径，再从 cwd 一直向 filesystem root 走，每目录一项，用 unshift 形成根→叶顺序，最后接在 global 后。seenPaths 按返回路径字符串去重；shadow 比较才 canonicalize context path。不会在 git root 停止，不用 projectTrusted 过滤 context（与项目 SYSTEM/extensions 等不同）。读取 ancestor 文件即使随后判为 shadowed 也已经发生。没有目录深度/总内容大小/取消限制；不写 context 文件。错误容忍主要在目录候选读取，导入 Git/path 工具异常是否兜底属于依赖模块。

## 增量扩展资源和 reload 顺序（304–548）

extendResources 先 normalizeExtensionPaths 三类条目：path 与可选 metadata.baseDir 用 resolveResourcePath，baseDir 存在时 shallow copy metadata。随后把每类 createSourceInfo 写入对应 Map，同一路径后写覆盖；三组 Map 先写完，再按 skill→prompt→theme 分别 merge(lastPaths, 新 paths)、更新 lastPaths、重载该类全部资源。空条目组不触发该类重载。旧路径先于新路径，不等于新贡献同名资源必胜；无清除 API、不加载新 extension、不刷新 context/system。它可在首次 reload 前使用；override/归属 stat 抛错时 Maps、lastPaths 或更早类别可能已经变化，无全组回滚。下一次完整 reload 清空这些贡献 source-info Maps，并重建 lastPaths，因此之前通过 extendResources 添加的路径须由外部生命周期再次贡献，不能假称自动持久化。

loadProjectTrustExtensions 明确 setProjectTrusted(false)，await settings.reload，再 loadCurrentExtensionSet(includeInlineFactories=true)。它返回预加载结果，不直接赋 this.extensionsResult；自身也不恢复原信任状态。回调执行前用户/允许的资源及 inline factories 已可能执行，不能称为没有执行代码的扫描。

reload 的精确阶段如下：

1. resetTimings("extensions")；仅 loaded=true 时 clearExtensionCache。若上一次首次 reload 在尾部失败，loaded 仍 false，但前面加载过模块，下一次本入口不会因为该失败自动清缓存。
2. 若提供 resolveProjectTrust，先执行上述不可信预加载，await 回调，再把返回信任写入 settings。随后无论是否回调，再 await settings.reload（注释说明保留 trust），await packageManager.resolve，await resolveExtensionSources(additionalExtensionPaths,{temporary:true})。
3. 至此才替换 resourceMetadataByPath，并清空三组扩展贡献 source-info。局部 getEnabledResources 对所有 ResolvedResource 首次路径保存 metadata，即使 disabled 也保存，然后筛 enabled；getEnabledPaths 再取 path。元数据“first path wins”与是否加载不是同一规则。
4. 收集常规四类资源，其中 skills 经过 mapSkillPath；给 CLI extension/skill 结果路径在未登记时预写 `{source:"cli",scope:"temporary",origin:"top-level"}`。CLI prompts/themes 没有同样这两段强制标记，随后使用其资源 metadata；重复路径不会覆盖既有记录。
5. extensionPaths 在 noExtensions 时仍取 CLI enabled extensions，否则 merge(CLI,常规)。await loadFinalExtensionSet 后，对 additionalExtensionPaths 中 isLocalPath 且不存在者追加 error；赋 extensionsOverride 后结果，再 applyExtensionSourceInfo。
6. skills：noSkills 时 merge(CLI skills,additionalSkillPaths)，否则 merge(CLI skills + enabled mapped skills,additionalSkillPaths)。先保存 lastSkillPaths，再 updateSkillsFromPaths。对额外 local 缺失路径且尚无相同 path diagnostic 才补 error。
7. prompts 同 skills 的路径构造，但使用 additionalPromptTemplatePaths/noPromptTemplates/updatePromptsFromPaths。缺失 local 额外路径补相应 error。
8. themes 同样构造并更新，额外主题路径不先用 isLocalPath 筛选。先前 loadThemes 已有同 path warning 时，不再补 error；“额外缺失 theme 一律 error”不成立。
9. 根据 noContextFiles 决定 [] 或 loadProjectContextFiles，再 agentsFilesOverride 后赋值。这个开关不阻止 override 注入 context。
10. systemPromptSource 使用显式 `??` 自动发现：显式空字符串抑制自动发现但解析为空；resolvePromptInput 后 systemPromptOverride 再赋值。source path 独立按原输入 existsSync 判断并 resolvePath；不因 override 返回文本而取消来源，也不代表读取一定成功。
11. appendSources 用 falsy 判断：undefined 自动发现最多一个文件，显式 [] 为 truthy 因而禁用自动发现；按输入顺序解析，过滤 undefined，appendSystemPromptOverride 后赋数组。sourcePaths 独立只保留存在的原输入并规范化，不按 override 内容回推、不去重，也不保证与最终文本逐项对应。最后 loaded=true。

这些 await 和连续赋值之间没有 candidate snapshot/commit 或 catch rollback。包解析/信任回调失败时可能只改过 settings/cache/runtime；扩展成功而 skill/prompt/sourceInfo/override 失败时可留下新 extensions 和旧后续资源；lastPaths 甚至可先于结果改变。loaded=true 只表示至少一次完整执行到末尾，不证明当前字段属于同一批。reload/extendResources 无取消参数、timeout 或并发 guard；并发 reload 可以交错，外部停止等待不撤销 I/O 或 extension side effects。这里没有任何 session journal、原子 rename 或重启恢复。

## 扩展预加载复用与诊断（549–635、946–969、1060–1097）

loadCurrentExtensionSet 重新做两次包路径解析、enabled 过滤和 CLI-first/noExtensions 路径选择，再 loadExtensionsCached。includeInlineFactories=false 原样返回；true 则串行加载 inline，把成功及错误分别 append。该辅助入口不执行冲突诊断和 sourceInfo 归属，不能把预加载结果当最终结果。

resolveExtensionLoadPath 用 cwd 及 normalizeUnicodeSpaces:true；resolveResourcePath 用 cwd 及 trim:true。两条规范化调用选项不相同，不能声称所有路径都采用同一 canonical key。

loadFinalExtensionSet 无 preTrust 时正常 cached load、附加 inline、addExtensionConflictDiagnostics。有 preTrust 时：排除 path 以 `<inline:` 开始的项，按 resolvedPath 建预加载 Map；错误路径经 resolveExtensionLoadPath 入 failed Set；只加载最终列表中既非成功也非失败 preload 的剩余路径，传入同一个 preTrust runtime。remaining 成功覆盖同 key，按最终 extensionPaths 重排能找到的成功模块，再 append 原预加载 inline；返回全部 preTrust errors + remaining errors 和旧 runtime。预加载失败本次不重试；预加载成功但最终未列入者不会放进最终数组，但已发生的副作用没有撤销；预加载错误也不按最终路径过滤。inline 复用而非再执行。路径字串/解析结果一致性依赖 extension loader，本文件没有额外realpath归一去重 Map。

loadExtensionFactories 对每个输入顺序 await loadExtensionFromFactory，共享 cwd/eventBus/runtime。函数输入用 `<inline:1>` 等一基序号；命名输入用 `<inline:name>`，成功时 extension.hidden=isNamed && input.hidden（可为 false/undefined），失败捕获 Error.message 或固定字符串并继续下一项。没有并行、超时、取消、释放 hook；工厂抛错前产生的副作用不回滚。

addExtensionConflictDiagnostics 把 detectExtensionConflicts 的 `{path,message}` 转成结果 errors，不卸载任何扩展。detectExtensionConflicts 只遍历 tools.keys 和 flags.keys，两张 owner Map 记录首个 ext.path；同名且不同 path 时给后者报冲突，不覆盖首 owner；同 path 重复不报跨扩展冲突。实际未遍历 commands，尽管上层注释说 tools/commands/flags。本文件仅报告 load-order 冲突，最终工具选择和同名 command 的调用名归 ExtensionRunner；S2/S5 测试片段期望 deploy:1/deploy:2 共存、CLI tool 获胜，但不是该函数直接构造这些别名。

## 分类加载、路径、sourceInfo（636–864）

mapSkillPath 只对 metadata.source==auto 或 metadata.origin==package 的目录尝试精确 SKILL.md；stat 失败/非目录返回原路径，SKILL.md exists 即映射并首次复制 metadata，不先检查该文件是否普通文件。非 auto 且非 package 直接保留，不对 CLI skills 统一调用它。这样 auto/package 技能目录可只读入口，显式目录仍留给技能 loader 的发现语法；不是本文件实现 YAML 或禁用模型调用策略。

updateSkillsFromPaths 在 noSkills && paths为空时先给空结果，否则调用 loadSkills(includeDefaults:false)。该开关关闭默认发现、并不禁显式输入。skillsOverride 后 shallow copy 每个 skill，sourceInfo 顺序是扩展额外归属/包 metadata 查找 → skill 原 sourceInfo → 默认归属；再替换 diagnostics。本文件不自己实现技能同名裁决，须区分路径去重和 loadSkills 的名称冲突合同。

updatePromptsFromPaths 同理 noPromptTemplates + 空路径特殊分支；正常 loadPromptTemplates(includeDefaults:false)，接着本文件 dedupePrompts。override 发生在去重之后，可重新引入重复。逐 prompt shallow copy 补 sourceInfo，diagnostics 原样接收 override 结果。模板文本不作为可执行 extension，也不解释为技能。

updateThemesFromPaths 的正常分支 loadThemes(paths,false)、dedupeThemes，合并读 warning 与 collision diagnostics，再 themesOverride；主题对象的 sourceInfo 是原地修改，sourcePath 缺失时保留原值。三种 updater 都可能在 override/sourceInfo 抛出时留下先前阶段的修改；没有统一错误封装。

applyExtensionSourceInfo 用 extension.path（不直接用 resolvedPath）找 metadata 或默认归属，并把同一 sourceInfo 赋给每个 command/tool；flags 不在这段传播。它不保留 extension 原 sourceInfo 作为中间 fallback。inline 尖括号路径归临时来源。

findSourceInfoForPath 空路径 undefined；以 `<` 开头先走默认归属。普通路径用 path.resolve（不是统一 canonicalizePath）；extraSourceInfos 遍历插入顺序，匹配等于或带 sep 的祖先即返回 shallow copy 且 path 改为当前资源；再查 metadata 的 normalized exact/original exact，最后遍历 metadata 祖先。没有 longest-prefix 选择，宽祖先早插入可胜过晚插入更窄祖先；extra ancestor 也先于 metadata exact。完全无匹配返回 undefined。

getDefaultSourceInfoForPath 对完整 `<...>` 产生 source=内部冒号前首段或 temporary、scope=temporary/origin=top-level。其他路径按 agentDir 下 skills/prompts/themes/extensions 四根先匹配 user，再按 cwd/CONFIG_DIR_NAME 四根匹配 project，source=local/baseDir=对应根；否则 scope=temporary、baseDir 由 statSync 判断目录本身或父目录。最后 stat 没有 catch；override 虚构不存在的资源可令 reload/extendResources 抛错。只以 `<` 开头但不以 `>` 结尾的输入并不获得完整虚拟路径豁免。isUnderPath 规范 root 后做等于或带 sep 前缀，避免 skills2 被当 skills；它不校验 symlink containment。

mergePaths 按 primary 再 additional 遍历，各项 resolveResourcePath 后 canonicalizePath 做 seen 去重，保留第一次的 resolved 路径。返回列表不是 canonical 路径本身；顺序稳定但依赖上游枚举，不排序；相同实际路径不同写法只占首次位置。对于常规 package 返回的 project/user 优先次序，本文件不重新排序；S1 展示组合合同 project 胜 user，不能单凭 mergePaths 推出 package resolver 的所有排序分支。additionalExtensionPaths 的 CLI-first 和 additionalSkill/Prompt/ThemePaths 在尾部不是同一个优先策略。

## 主题文件、同名去重和系统文本发现（865–945、970–1059）

loadThemes(paths,includeDefaults=true) 可先读 agentDir/themes、cwd/CONFIG_DIR_NAME/themes 两个默认目录；当前 updateThemesFromPaths 明确传 false，不能把私有默认参数当本轮 reload 真实的 user-first 发现序。逐 path 规范化：不存在 warning；目录直接枚举；普通 .json 文件加载；其他类型/后缀 warning；stat/目录调用错误转 warning。不递归、不排序、不设文件数/大小上限，实际 JSON theme 解析和校验委托 loadThemeFromPath。

loadThemesFromDir 不存在直接返；readdir withFileTypes 遍历文件，symlink 用 stat 跟随，仅指向普通文件才可能加载；broken symlink 静默跳过；非文件/非 .json 跳过。目录读错误 warning；loadThemeFromFile 捕获解析/读取异常 warning 后继续其他文件。故 source 允许主题文件 symlink 的语义不能映射成 target 的统一拒绝策略。没有写主题文件或终端应用主题行为。

dedupePrompts 按 name 保留第一个，后者生成 collision resourceType=prompt/name/winnerPath/loserPath，消息带 /name；dedupeThemes 用 t.name ?? unnamed 为 key，同样 first-wins，缺 sourcePath 时诊断用 <builtin>。空 name 不等于 undefined，不会转 unnamed；三次重名分别指向首 winner。它们只管本类名字，不跨 skills/templates/extensions 检查；不能把 prompt 名与 extension command 名相等视为这里自动裁决。Map 输出保持首次名称插入顺序。

discoverSystemPromptFile/discoverAppendSystemPromptFile 分别检查当前 cwd/CONFIG_DIR_NAME 下 SYSTEM.md/APPEND_SYSTEM.md：projectTrusted 且 exists 时优先，否则 agentDir 同文件，最后 undefined。不会遍历祖先项目、也不合并 global+project。只影响自动发现，显式选项不经此 trust check。它们先 exists 后读取，目录/权限竞态交给 resolvePromptInput，可能退回字面路径。上下文 AGENTS 分层、系统替换文本、append 文本、模板和技能是五条不同通道，不应混为一个 prompt 字符串加载策略。

## 可运行行为判据与已读测试上下文

本轮源/目标产品测试运行均为 0；没有 Cargo、Node 源执行、PTY、HTTP、网络、安装、provider 或扩展工厂执行。以下是明确 fixture/操作/期望，可交由 master 后续运行的语义判据；S/T 引用是已读测试/实现片段，既不等于测试通过，也不构成测试文件全覆盖。

| 合同组 | fixture、操作与应观察结果 | 证据 |
|---|---|---|
| 空状态/getter/选项 | 构造后各结果空；改变 getSkills().skills 数组会影响该实例；显式空 systemPrompt 不自动发现，append=[] 也不发现 | 源构造器/getter/reload 分支推导；需隔离 fixture |
| 上下文候选/祖先 | global override、project AGENTS、leaf override 同时存在，应按 global→project→leaf；候选是目录则 fallback CLAUDE；noContextFiles 返回空（无override时） | S3 |
| nested worktree | 同名 main/worktree context 只保留 worktree；main CLAUDE 与 worktree AGENTS 均保留；bare/sibling/submodule/普通repo/坏gitdir仍保留相应祖先 | S6 |
| trust 两阶段 | 用户模块顶层计数器+project 模块；回调只看到预信任集合，true 后 project→user 且用户计数为1；false 自动 project SYSTEM 不用但 project AGENTS 仍加载 | S2、S3 |
| flags 与显式路径 | noSkills=true + additionalSkillPaths 仍调用 loader；noExtensions=true + CLI/inline 仍可执行；同 canonical 路径重复保留第一次 | 源路径条件推导；并非全禁执行开关 |
| 三类优先 | user/project 同名 skill/prompt/theme 由完整发现组合得到 project；两 prompt 同名只保留输入次序首项并给 loser collision；两个 unnamed theme 同理 | S1；dedupe 分支推导 |
| extension 贡献 | extendResources 注入技能目录与模板文件并给 extension:extra metadata，所得资源 path 是实际入口且 source 为该 metadata；后续 reload 没有重新贡献则不保证保留 | S4；reload 清图/lastPaths 分支 |
| 分类/映射 | auto/package dir 内 SKILL.md 和其他 Markdown，mapSkillPath 选择 SKILL.md；非 auto/nonpackage 原路径保持；模板 loader 不执行扩展工厂 | 源 mapSkillPath/updaters 的可构造判据 |
| 工厂/冲突 | 成功A、抛错B、成功C按序执行，共享runtime，B变error但C继续；tools/flags后者冲突仍保留；commands冲突不生成该类error | 源工厂/检测；S2、S5 |
| preload失败复用 | preload A成功、B失败；final含A/B/C，仅C再次load，A复用、B不重试，errors保留B；inline不再执行 | loadFinalExtensionSet 分支判据，未执行计数探针 |
| 来源规则 | extra宽祖先先插入、窄祖先后插入应选宽者；metadata exact优于metadata祖先但低于extra；override给缺失普通资源触发默认stat异常 | 源 findSourceInfo/getDefaultSourceInfo 推导 |
| 文本/主题错误 | 不存在 system 字符串按字面用；存在但读取失败警告后原字符串；broken theme symlink跳过、坏JSON warning、其余主题继续 | 源读取/catch 分支；无故障注入执行 |
| reload部分更新 | 先成功一次，再让 promptsOverride throw；观察 extensions/skills/lastPromptPaths 可已更新而 prompts/themes/context仍旧，loaded保留先前true | 源连续赋值，无统一回滚的可运行判据 |
| target原子快照 | v1成功后v2技能/模板+缺失文本路径，reload_with_paths错误，Arc::ptr_eq和原选择均保留；成功再发布generation2 | T5、T8已读断言 |
| target旧turn/取消 | 已选技能body和模板/text保留v1；旧snapshot未选skill在文件变更后load_body拒绝；每candidate取消检查点旧Arc保持 | T2、T9；仅已读测试 |
| target host | active turn用generation1时reload发布generation2，status同时显示1/2；失效/cancel资源不发布、不写选择记录 | T6、T10片段（后者含HTTP fixture，本轮未执行） |

未实际执行的错误/取消/恢复判据不会变成通过计数。源此文件没有 AbortSignal 或 restart journal，因此“取消自动回滚”和“重启恢复资源 generation”属于源不适用/目标增强；仍须分别验证 target owner，不从本源报告获得验收。

## 当前 zenpi 映射与反向范围核对

精确定位与 hash 索引见下文引用表及 evidence/context-references.json；这些是本轮捕获的 master 当前片段，不是假定 worker checkout 与 master 相同。正式源只此 resource-loader.ts，目标 src/skills.rs、src/extensions.rs 与调用方/测试均 context-only。

| 源责任 | 当前 owner/已观察实现 | 差异、缺口或范围排除 |
|---|---|---|
| 技能发现/同名/元数据 | src/skills.rs T1：user→project→explicit，后层替换前层；同scope TOML胜Markdown；collision winner/loser可查询；显式缺失、根symlink、预算超限为错误 | 源这里编排loadSkills和metadata，不拥有TOML hooks；target explicit后条胜与源additional paths尾部/路径first保留不可简单视为等价 |
| 技能正文生命周期 | src/skills.rs T2：按需read_skill_text，hash与发现时不同拒绝；Model调用尊重disable_model_invocation | 源resource-loader只加载Skill对象并归属，不在此load正文/执行模型技能；target旧Arc仅保留元数据不自动冻结未读取文件 |
| 模板独立加载 | src/resource_loader.rs T4/T5将templates与skills分开，统一collisions只含Skill/Template；T8明确explicit template胜project/user，同优先不同文件同名拒绝 | 源prompt first-wins+collision继续，target同优先重复是整次失败；完整模板语法owner为src/prompt_templates.rs/ZS1-020映射，本次未整文件验收 |
| loader结果生命周期 | T5先构造skills/templates/text，再最后提交paths与Arc，checked generation、取消检查、文本总1MiB | 原子发布是target增强；源逐字段赋值且无取消/预算；ResourceSnapshot无theme/extension/context/system专用字段，不能声称已覆盖所有源类别 |
| extension发现与注册 | src/extensions.rs T3：排序直接子目录、跳隐藏/目录symlink，manifest<=256KiB、disabled仅summary，enabled校验可执行文件并拒重名、最多32；register_with_lease先clone registry后整批成功赋回，API2要求runtime | source执行TS/inline并宽容收集errors；target TOML/本地进程catalog不同，不等于实现packageResolver、inlineFactory、projectTrust预加载、命令别名或source metadata全套 |
| host资源+extension reload | src/core.rs T6：clone/new候选loader完成后prepare_extensions，取消复查，append选择provenance再发布skills/loader及extension候选；reload_resources沿当前选择；restore只Idle；status有generation/active_generation | extension不在ResourceSnapshot本体，host负责协调；prepare/publish内部、session append耐久性和旧extension lease全合同超出该片段，不据此宣称跨进程事务 |
| slash入口/路径选择 | src/slash_actions.rs T7：/reload无参沿原选择，有参读workspace内JSON选择文件，拒绝绝对/父目录选择文件，配置内相对路径以workspace为基准再configure_resources | 源文件无slash处理；target选择文件约束不等于其中每个资源路径必须位于workspace，代码没有在此做该承诺 |
| context/system/append | T4/T5可显式选named text_resources并保存source/hash/content，T6负责host接入 | 没有在这些已读owner片段看到AGENTS.override多候选祖先分层、nested worktree去重、SYSTEM trust fallback和append来源数组。是本映射未证明的语义缺口；不能用generic text读取冒充完整对等，也不对未读其他owner作全库不存在断言 |
| themes | 源loadThemes*、dedupeThemes、theme override/sourceInfo完整说明 | 目标选定skills/extensions/resource snapshot没有theme catalog；UI主题属于不同owner，本轮无整合或验收，明确排除 |
| sourceInfo/override/package paths | 源metadata/extra归属、任意同步override、package/CLI解析 | target技能/模板source/hash/scope和extension summary不是完整SourceInfo的source/origin/baseDir语义；目标CLI包路径/JS override注入/两阶段trust均未由本片段证明 |

反向核对：src/skills.rs 的工具允许列表、legacy hooks、模型技能工具注册和沙箱资源读取细节，不属于本源文件直接职责，需其各自源/目标项；src/extensions.rs 的安装/删除/升级、能力broker、子进程调用和会话hook运行也不是本文件实现，排除其整文件接受。src/core.rs 只引用资源配置发布/状态片段，不碰turn loop、session树或provider。源文件所有额外职责（theme、context、system、append、path/sourceInfo、override、inline/preload）已逐项说明并映射/列缺口，不通过只看skills/templates跳过私有分支。

## 证据与门禁

源全文读取/字节连续范围见 evidence/gfile.json；所有context记录有整文件hash、片段行/字节边界和片段hash，可在相同输入重建。本轮只读结构checker，实际命令、cwd、argv、起止时间、exit、stdout/stderr bytes/hash在 evidence/gstage.run.json。checker只能判断结构，不替代本报告语义复核；缺master receipt必须保留provisional，禁止捏造complete或更改authority/index/checklist状态。

候选patch只新增唯一标准报告。source/context/scripts/校验记录均在私有ready证据包，不进入产品diff；master checkout、源库、A/C工作树、018/125和更早ready、scheduler/任务/产品代码无写入。没有G-RUST/G-HOST/G-CODE新通过声明。本项回滚是撤回该新增报告；实际patch只在临时git目录正反check/apply，并核对报告精确字节及无关sentinel不变，不在master应用。

### 本轮实际结构门禁与定位表

G-STAGE 实际 exit 1，structural.ok=true，唯一错误是主库缺少 `Docs/learn/stage1_pi_mono/receipts/ZS1-021.master.json`。没有创建该receipt。G-FILE 本地仅检查source hash、完整范围、report身份和context片段hash；semantic_verified_by_checker=false，master语义复核仍pending。产品行为执行数为0。

以下行/字节为context原文件的一基闭合行范围、零基半开字节范围；片段SHA和source文件SHA完整记录于evidence/context-references.json。这里的定位表不扩大正式复核范围。

| ID | 上下文文件 | 行 | 字节 | 文件SHA256 |
|---|---|---|---|---|
| T1 | /Users/wangweiyang/GitHub/zenpi/src/skills.rs | 142–262 | [3904,8635) | `a6d0a2f671febdef2e631ca53d2788ab869ab7b86db6c0cb1feaf24d128f83e8` |
| T2 | /Users/wangweiyang/GitHub/zenpi/src/skills.rs | 281–317 | [9325,10744) | `a6d0a2f671febdef2e631ca53d2788ab869ab7b86db6c0cb1feaf24d128f83e8` |
| T3 | /Users/wangweiyang/GitHub/zenpi/src/extensions.rs | 161–311 | [5061,10537) | `38a242eff3ec911f4560e3dea3868b742d511205ff0ccab1b622962b41e420ed` |
| T4 | /Users/wangweiyang/GitHub/zenpi/src/resource_loader.rs | 17–94 | [533,2991) | `121d3b6ea7760d137e0e074e7d9b269023ddc6ca2ecca199f23072890bd06858` |
| T5 | /Users/wangweiyang/GitHub/zenpi/src/resource_loader.rs | 117–226 | [3511,7285) | `121d3b6ea7760d137e0e074e7d9b269023ddc6ca2ecca199f23072890bd06858` |
| T6 | /Users/wangweiyang/GitHub/zenpi/src/core.rs | 2212–2345 | [85956,91566) | `52311b129c0bb467abac36de216f5bc97bf3c4c42d03dcd6170a717339c2a869` |
| T7 | /Users/wangweiyang/GitHub/zenpi/src/slash_actions.rs | 86–146 | [3477,5992) | `5912f71faa07e7f529b1c9bef875a977873c6a5e152d103e837d0fbac001cd32` |
| T8 | /Users/wangweiyang/GitHub/zenpi/tests/stage1_prompt_resources.rs | 178–242 | [6055,8397) | `1bbdbff6927a996a06c08bb7afe84d9a94f25722b89c757d7bd1867a9c46a40f` |
| T9 | /Users/wangweiyang/GitHub/zenpi/tests/stage1_prompt_resources.rs | 244–322 | [8398,10943) | `1bbdbff6927a996a06c08bb7afe84d9a94f25722b89c757d7bd1867a9c46a40f` |
| T10 | /Users/wangweiyang/GitHub/zenpi/tests/stage1_resource_host.rs | 194–290 | [6997,10521) | `6bfe5c0861bcd58c6dd42b8ca6a8ef4505ee8b030e20974cdc0024ba7695f4ae` |
| S1 | /Users/wangweiyang/GitHub/pi-mono/packages/coding-agent/test/resource-loader.test.ts | 101–160 | [3372,5713) | `4d7043fbae033b5398db34046feea2ac3e910079e8def6a1d198b7c840190fb0` |
| S2 | /Users/wangweiyang/GitHub/pi-mono/packages/coding-agent/test/resource-loader.test.ts | 191–303 | [6799,10495) | `4d7043fbae033b5398db34046feea2ac3e910079e8def6a1d198b7c840190fb0` |
| S3 | /Users/wangweiyang/GitHub/pi-mono/packages/coding-agent/test/resource-loader.test.ts | 348–475 | [12179,17929) | `4d7043fbae033b5398db34046feea2ac3e910079e8def6a1d198b7c840190fb0` |
| S4 | /Users/wangweiyang/GitHub/pi-mono/packages/coding-agent/test/resource-loader.test.ts | 557–622 | [21326,23127) | `4d7043fbae033b5398db34046feea2ac3e910079e8def6a1d198b7c840190fb0` |
| S5 | /Users/wangweiyang/GitHub/pi-mono/packages/coding-agent/test/resource-loader.test.ts | 845–959 | [30076,33595) | `4d7043fbae033b5398db34046feea2ac3e910079e8def6a1d198b7c840190fb0` |
| S6 | /Users/wangweiyang/GitHub/pi-mono/packages/coding-agent/test/resource-loader.test.ts | 960–1119 | [33595,41570) | `4d7043fbae033b5398db34046feea2ac3e910079e8def6a1d198b7c840190fb0` |
