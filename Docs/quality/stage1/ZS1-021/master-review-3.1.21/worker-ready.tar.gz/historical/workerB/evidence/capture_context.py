from pathlib import Path
import json,hashlib,datetime
W=Path(__file__).resolve().parent
M=Path('/Users/wangweiyang/GitHub/zenpi');S=Path('/Users/wangweiyang/GitHub/pi-mono')
specs=[
 ('T1',M,'src/skills.rs',142,262),('T2',M,'src/skills.rs',281,317),
 ('T3',M,'src/extensions.rs',161,311),
 ('T4',M,'src/resource_loader.rs',17,94),('T5',M,'src/resource_loader.rs',117,226),
 ('T6',M,'src/core.rs',2212,2345),('T7',M,'src/slash_actions.rs',86,146),
 ('T8',M,'tests/stage1_prompt_resources.rs',178,242),('T9',M,'tests/stage1_prompt_resources.rs',244,322),
 ('T10',M,'tests/stage1_resource_host.rs',194,290),
 ('S1',S,'packages/coding-agent/test/resource-loader.test.ts',101,160),
 ('S2',S,'packages/coding-agent/test/resource-loader.test.ts',191,303),
 ('S3',S,'packages/coding-agent/test/resource-loader.test.ts',348,475),
 ('S4',S,'packages/coding-agent/test/resource-loader.test.ts',557,622),
 ('S5',S,'packages/coding-agent/test/resource-loader.test.ts',845,959),
 ('S6',S,'packages/coding-agent/test/resource-loader.test.ts',960,1119),
]
refs=[]
for ident,root,rel,start,end in specs:
 p=root/rel;b=p.read_bytes();lines=b.splitlines(keepends=True);assert end<=len(lines)
 lo=sum(map(len,lines[:start-1]));hi=sum(map(len,lines[:end]));part=b[lo:hi]
 name='excerpts/'+ident+'-'+p.name+'.txt';q=W/name;q.parent.mkdir(exist_ok=True);q.write_bytes(part)
 refs.append(dict(id=ident,source=str(p),source_sha256=hashlib.sha256(b).hexdigest(),source_bytes=len(b),start_line=start,end_line=end,start_byte=lo,end_byte=hi,excerpt=name,bytes=len(part),sha256=hashlib.sha256(part).hexdigest(),scope='bounded context only; no whole-file acceptance'))
(W/'context-references.json').write_text(json.dumps({'captured_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'references':refs},indent=2)+'\n')
print(json.dumps(refs,indent=2))
