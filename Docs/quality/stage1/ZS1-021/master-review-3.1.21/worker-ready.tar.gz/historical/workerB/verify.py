"""Offline integrity/patch check only; no product or authority execution."""
from pathlib import Path
import json,hashlib,tempfile,subprocess,datetime
R=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((R/'manifest.json').read_text());assert m['item']=='ZS1-021' and not m['complete'] and not m['product_changes']
actual={str(p.relative_to(R)) for p in R.rglob('*') if p.is_file() and p!=R/'manifest.json'}
assert actual==set(m['artifacts'])
for path,rec in m['artifacts'].items():
 p=Path(path);assert not p.is_absolute() and '..' not in p.parts
 b=(R/p).read_bytes();assert len(b)==rec['bytes'] and sha(b)==rec['sha256'],path
g=json.loads((R/'evidence/gfile.json').read_text());source=(R/'evidence/source/resource-loader.ts').read_bytes()
assert len(source)==40180 and sha(source)=='1877e9535820cb8b45e5a84598ac8ae581058bb0fbee6f0c64ec672f8ab986dd'
cursor=0
for start,end in g['read_ranges']:
 assert start==cursor and start<end<=len(source);cursor=end
assert cursor==len(source)
for r in g['ordered_reads']:assert sha(source[r['start_byte']:r['end_byte']])==r['sha256']
report=(R/m['report_path']).read_bytes();assert sha(report)==g['report_sha256']==m['report_sha256'] and len(report)==g['report_bytes']
assert not g['semantic_verified_by_checker'] and not g['master_receipt_created']
for r in json.loads((R/'evidence/context-references.json').read_text())['references']:
 b=(R/'evidence'/r['excerpt']).read_bytes();assert len(b)==r['bytes'] and sha(b)==r['sha256']
run=json.loads((R/'evidence/gstage.run.json').read_text())
for stream in ['stdout','stderr']:
 r=run[stream];b=(R/'evidence'/r['path']).read_bytes();assert len(b)==r['bytes'] and sha(b)==r['sha256']
stage=json.loads((R/'evidence/gstage.stdout.json').read_text())
assert run['exit_code']==1 and stage['structural']['ok'] and not stage['ok'] and 'ZS1-021.master.json' in stage['errors'][0]
ops=[]
with tempfile.TemporaryDirectory(prefix='zs1-021-replay-') as raw:
 temp=Path(raw)
 def git(args):
  started=datetime.datetime.now(datetime.timezone.utc).isoformat();argv=['git',*args]
  p=subprocess.run(argv,cwd=temp,capture_output=True)
  ops.append({'argv':argv,'cwd':raw,'started_at':started,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':p.returncode,'stdout':p.stdout.decode(),'stdout_sha256':sha(p.stdout),'stderr':p.stderr.decode(),'stderr_sha256':sha(p.stderr)})
  assert p.returncode==0,(args,p.stdout,p.stderr)
  return p.stdout.decode()
 git(['init','--quiet']);sentinel=temp/'unrelated';sentinel.write_bytes(b'unchanged\x00\r\n');path=temp/m['report_path'];patch=R/'candidate.patch'
 stats=git(['apply','--numstat',str(patch)]).splitlines();assert len(stats)==1 and stats[0].split('\t')[2]==m['report_path']
 for phase,flags in [('forward-check',['--check']),('forward',[]),('reverse-check',['--reverse','--check']),('reverse',['--reverse'])]:
  git(['apply',*flags,str(patch)])
  if phase in ['forward','reverse-check']:assert path.read_bytes()==report
  else:assert not path.exists()
  assert sentinel.read_bytes()==b'unchanged\x00\r\n';ops[-1].update({'phase':phase,'exact_bytes':True,'sentinel_preserved':True})
print(json.dumps({'passed':True,'manifest_sha256':sha((R/'manifest.json').read_bytes()),'artifacts':len(actual),'report_sha256':sha(report),'patch_sha256':sha((R/'candidate.patch').read_bytes()),'operations':ops,'semantic_acceptance':False,'gstage':'structural passed; missing master receipt; provisional','product_executions':0},indent=2))
