
---

## 3.1.21 独立逐文件复核补记（本轮候选，尚未主控验收）

本节是本轮结论。前 32,797 字节为 worker B 历史报告原文，SHA-256 `cd8de44c352ac754ea520d258dec0941171e756fb262e95862fdb39db3305a04`，逐字保留；其中当时的搜索结果、authority、路径与未执行说明不改写成本轮事实。本次另找到 C 的 behavior 与 reuse320 封存包，完整复制其物理文件用于身份复用。B 旧报告、C 旧执行、当前源阅读、当前目标有限阅读和本轮离线检查是五种不同证据，不把历史通过次数叠加为新执行次数。

本轮唯一正式文件项为 ZS1-021 / SRC-0931，唯一 owned path 为本报告。正式依赖仅 ZS1-001；不验收 ZS1-056、ZS1-114、ZS1-123 或整个 core 目录。本轮未改产品、main、claims、selector、blueprint、旧 ready 或旧 runner，未新跑 Bun/Cargo/PTY/HTTP/Git-worktree/性能预算，也未导入或执行封存脚本。状态为 source review candidate，`master_accepted=false`；离线检查通过不等于 G-STAGE semantic/manual gate 通过。

### 当前 authority 与证据边界

- version：`3.1.21`；run：`zenpi-stage1-20260911`。
- requirement：`3456abcbbebbc4e0ab383c319851b0a6e71b19ee9b3c060a6e212f61a89c9d9d`。
- baseline：`92b06c4b1dcdca7614d226ce5f41205646a9e63967789d2b6ed4ee272d240884`。
- 初末完整 selector、blueprint、claims、manifest/index 与001 receipt分别保存在 `authority/`、`authority-final/`。本次六份完整快照初末均相同；独立核对四键、001/021 item行与021 claim，不把其它项状态作为本项验收条件。
- 001当前master receipt的34个artifacts逐个按声明 bytes/SHA核对后复制到 `formal-dependency/`；另实际阅读完整 `master-rebind-3.1.21/review.md`。它仅保留001未变义务的既有验收；并不为021或任何新增项授予通过。
- 初末 main 标准021报告和021 master receipt均不存在。因此补丁是仅创建本报告的候选；不得用补丁自动覆盖以后主控已生成的报告。

### 新完整源阅读覆盖

源 `/Users/wangweiyang/GitHub/pi-mono/packages/coding-agent/src/core/resource-loader.ts` 为 1,097 行、40,180 字节，SHA-256 `1877e9535820cb8b45e5a84598ac8ae581058bb0fbee6f0c64ec672f8ab986dd`。本轮按 1–190、191–390、391–590、591–790、791–990、991–1097 六段连续完整阅读，不把旧 B 的五段或 C 的四段充作新阅读。`reading-ranges.json` 为每段记录1-based行号、半开UTF-8字节区间、原始节选hash和完整快照hash；六段拼接覆盖所有40,180字节，无空洞和重叠。`source/resource-loader.ts` 是完整原文。前三段最初读自实际Pi路径，随后快照与当前源做相同身份检查。

结合前述完整报告，新独立复核确认以下容易误读的边界：

1. **构造与状态所有权**：constructor只保存选项、normalize cwd/agentDir和建立空catalogue/runtime，不隐式reload；多数getter暴露可变数组/结果引用，source-path getter才构造新记录。配置数组和override/factory等引用也可由调用方持有。本文件是发现/编排层，并非模板解析器、模型执行器、持久会话或扩展命令路由的完整owner。
2. **提示与上下文**：resolvePromptInput对存在路径读UTF-8并strip BOM；读取失败warn后返回原输入文字，非存在输入本来就是文字，不提供统一read预算或取消。显式空system字符串会阻止自动发现、最终返回undefined；显式空append数组阻止自动append。自动SYSTEM/APPEND只在信任允许时用cwd `.pi`，否则/缺失时用global，每类至多一份，不搜祖先。context文件另按global→root-to-cwd祖先顺序，每目录AGENTS.override.md、AGENTS.md、AGENTS.MD、CLAUDE.md、CLAUDE.MD选择首个成功regular file；读失败允许尝试下一候选，不受同一个project trust过滤，也不在普通git根停止。
3. **嵌套worktree**：只在common git目录/主仓真实路径关系满足时跳过嵌套主仓中的同名context副本；不同basename仍可能同时保留。普通仓、兄弟worktree、bare/submodule不能从此特例推广；路径去重与影子过滤不是内容去重，影子文件可能已先读入再被过滤。
4. **发现与来源**：no*关闭默认集合仍允许CLI/additional、inline或override提供内容；package/CLI结果携带第一条path metadata，包括disabled记录。自动/package技能目录可映射到存在的SKILL.md，CLI skill列表不走同一映射。extendResources先更新三个额外来源map，再按canonical路径合并旧路径优先、保留首个拼写，顺序重载skills→prompts→themes。来源不是最长prefix：额外map的首个祖先匹配在metadata精确匹配之前，之后metadata才查normalized/raw exact及首个祖先；普通路径resolve与canonical identity用途不同。默认来源优先检查user roots再project roots，fallback stat可能抛错。
5. **信任与扩展**：bootstrap阶段先以false信任reload settings，再预载允许的global/CLI和inline，回调决定后续信任；异常不保证恢复之前trust状态。预载成功按resolvedPath复用，预载失败集合阻止重试，inline不会第二次执行；预载错误不因最终过滤而消失。扩展工厂的外部副作用无回滚。本文件冲突检查实际只枚举tools/flags，尽管注释也提到commands；发现冲突追加diagnostics而保留module，不能由此宣称commands已经拒绝注册。
6. **加载、覆盖与失败**：skills override后重新构造带sourceInfo的skill，prompts先按name首项优先并记录collision再override（override可重新引入同名项），themes去重后override且原对象sourceInfo会原位赋值。theme目录只直接扫描JSON文件，允许指向regular file的symlink，坏JSON诊断warning；没有递归或文件数限制。已有同path诊断可能阻止追加missing-path error，不能把所有无结果归类error。
7. **部分提交**：reload不是事务：早期清理metadata/贡献map、保存路径、随后逐项赋值，后段override抛错可能保留新prompts与旧system等混合状态；extendResources也相同。`loaded`只在成功尾部置true，因此首次失败后下一次不会通过该条件清cache，第二次以后的失败又可能已经清cache。没有并发序号、AbortSignal/统一取消、journal或恢复owner；getter也不是持久不可变snapshot。这是源契约记录，不能为了迁移“对齐”而消除Zenpi已有的原子发布/取消保护。

### 当前 Zenpi 映射：实际新读范围及差异

完整目标快照仅用于hash和便携比对，除 `src/resource_loader.rs` 1–280整文件外，不宣称其它完整目标文件都已阅读。本轮新读范围列在reading ledger；`core.rs`最初按旧行号读到6244–6315，发现当前内容是无关tool-call校验，明确作为incidental read记录，未据此写资源恢复结论。C原片段实际逐字存在于当前6347–6418，这只计身份定位；扩展prepare/publish另在当前2108–2211完整新读。

| 当前文件与实际新读范围 | 当前行为及与Pi的关系 |
| --- | --- |
| `src/resource_loader.rs:1–280`，SHA `121d3b6ea7760d137e0e074e7d9b269023ddc6ca2ecca199f23072890bd06858` | ResourcePaths显式user/project roots、extra技能/模板和named text；new建立generation0的Arc空snapshot。reload_with_paths先normalize并完成skills/templates/text，再取消检查、提交paths和snapshot；失败保留两者旧值。generation checked_add，text最多64份、总1MiB，名字1–128 ASCII alnum/_/-，duplicate报错。ResourcePaths deny_unknown_fields，TextResourcePath不作同样声明。绝对路径不全等于canonical；text parent存在时canonical化而保留末段供读取检查。snapshot字段只有skills/templates/text，不包含本文件级Pi themes/context/system/append/extension列表；不由此断言其它Zenpi模块完全没有这些功能。Arc catalog也不等于技能正文冻结。 |
| `src/skills.rs:142–262,281–317` | 临时catalog按user→project→explicit加载；后作用域覆盖前者，explicit后项赢，同scope TOML覆盖Markdown；有collision、数量/索引字节与取消检查，symlink root拒绝。正文调用时重新读取并校验source hash；changed要求reload。不是照搬Pi prompts首name优先，也不是Arc保证延迟读取内容恒定。 |
| `src/prompt_templates.rs:78–195` | 直接.md子文件、排序、重复同一文件去重；同scope同name错误，跨scope后者覆盖并记录collision。显式路径、目录项、catalog字节有界，拒绝symlink，支持取消；与Pi prompt warning并保留首项不同。 |
| `src/extensions.rs:161–311` | TOML manifest/本地可执行目录catalog，disabled summary保留，验证兼容性、路径与32个enabled上限；register_with_lease克隆registry后统一替换，API2需要session runtime。它不是Pi jiti/factory或包管理系统等价实现。 |
| `src/core.rs:2108–2211,2212–2345` | prepare_extensions要求Idle且拒绝BlueprintWorker权限；准备candidate runtime/registry。configure_resources先资源candidate，再已配置扩展candidate、取消检查、append provenance event，之后发布skills/loader/extension。prepare失败不会发布，但publish_extensions关闭旧runtime、替换后启动新runtime，hook失败转AgentEvent::Error，不回滚已append journal或新资源。不能把资源构建原子性夸大为扩展副作用/日志完整事务。restore_resources只在Idle重建路径并标记stale；其helper完整实现不在本轮新读范围。 |
| `src/slash_actions.rs:46–146` | 资源控制通过Agent owner；/reload无参数重载当前paths，有参数限workspace内的relative selection JSON，无absolute/ParentDir且最长4096字节；取消透传、各相对资源路径锚定workspace。该段没有证明整个host调度/跨平台/PTY并发。 |

初末9个目标完整快照相同。与B旧引用比较，16个原节选全部逐字一致，只有T7所处slash_actions完整文件发生历史→当前变更：旧41,343字节/current76,284字节，旧86–146本身未变；不把整文件hash不等误报为该片段漂移。C的11个原节选也均可逐字定位，其中core旧6244–6315迁至6347–6418；core和slash完整文件hash发生历史变化，其余5个C目标文件身份相同。完整列表、原/新hash和行号见两个comparison文件。旧目标tests的范围/行为只按历史报告和逐字片段复用，不计本轮新test阅读或运行，更不宣布当前集成二进制测试通过。

### 行为证据复用与真实失败链

本轮新完整阅读C保存的71行dense `probe.ts`，读取run metadata与reviewed逐案日志，核对三个日志实际bytes/SHA，并把reviewed日志23个case名称按顺序与probe里的23个`await check(...)`逐一比对。源控制器加12个依赖共13个源文件的旧SHA与本轮当前快照完全一致；依赖只做身份复用，未充作新完整阅读。源码和FS控制器证据因此可在下列明确边界内复用，无法升级成完整上游suite或当前Zenpi执行。

- 原始 `source-native`：2026-09-10 20:18:18 UTC，exit1；输出3,309字节，SHA `805766d54873c475dca41cbab6ad1f16e98770a445556d3f95f2e4524c7d1c93`。原probe错误期待missing skill诊断为error，实际是此前已有warning；源控制器并未为此修改。原始失败栈和期待表达式保留。
- `source-native-final`：同日20:18:42 UTC，exit0；输出3,322字节，SHA `ee045f4efee7e648c9bd1aea16bf101f1e1e229f6dbdc49d6edc12f2d12e8ace`，修正诊断期待后23例通过。
- `source-native-reviewed`：同日20:19:35 UTC，exit0；输出3,331字节，SHA `baf79e0a7483f784cf3f507ac50231f93545ba8cd41230a2a2762c1897c7c2af`，额外强化no-resource场景确实包括additional prompt，仍是23个独立场景，不是再加23例。本轮运行次数0。

场景覆盖：空constructor getter、真实prompt碰撞/来源、no*下CLI/additional、disabled与额外来源优先、真实skill parser自动SKILL.md、symlink canonical去重、extend path/baseDir与first ancestor、getter可变引用、reload读新prompt并丢贡献、missing诊断、reload/extend晚期失败部分状态、system/append信任路径、literal/file来源、目录无法当文件读取时warn+literal、pretrust成功失败复用与inline只执行一次、tools/flags冲突且commands保留、inline错误隔离/hidden、theme JSON诊断、context顺序/文件名/BOM、重复context及非文件候选、嵌套worktree同名影子、普通仓祖先context。详细23条逐案名称及结果在 `historical-execution-audit.json` 中原样保存。

四个明确替身是 package-manager（预定resolve/CLI结果，无真实install/network）、settings-manager（注入trust及reload记录，无真实设置持久化）、extensions/loader（预定extension/runtime及cache计数，受控factory，不是真实jiti/cache/provider系统）和theme模块（对真实fixture bytes作JSON.parse，不是完整schema/render）。其余controller、FS、skills/prompts parser、path/sourceInfo、Git finder使用源实现。Git场景是手写`.git/HEAD/commondir` metadata，不是执行git worktree；目录读取失败不是EACCES权限实验；override抛错是公开选项，不是私有方法替换。未证明Windows、真实主题渲染、安装、权限竞态、并行reload、所有扩展生命周期或生产host。

B历史G-STAGE exit1/structural true与C reuse320历史G-STAGE exit1（缺021 master receipt）均原样保留，没有重跑或转写为pass。本轮387项输入离线检查全部通过，内容为物理副本/旧manifest/13源身份/三次日志/23场景名称/原节选身份及只读123 manifest核对；这387项不是387个行为测试。最终便携检查另产生外置receipt，校验manifest全payload、六段覆盖、scope与正式依赖、report前缀与补丁，不访问开发机器的绝对源路径，也不导入任何旧脚本。

### 交付与主控处理

便携包根目录包含标准report、单文件创建补丁、全部原始历史包副本、初末authority与目标快照、源快照/reading ledger、identity audit、formal001依赖证据，以及新写的纯Python离线 `verify_packet.py`。`manifest.json`列举除自身外所有payload的相对路径/bytes/SHA，`README.md`说明运行方式与本轮限制。生成脚本也只是新私有证据，旧runner全部保持惰性数据。

主控需独立完整审阅本文件报告与源覆盖、确认上述迁移差异和复用边界，再决定整合唯一owned报告、运行/出具当前项正式gate/receipt；本包不写任何worker/master acceptance receipt。若移交后main已经有报告，应人工merge本轮补记，不盲目应用create补丁。撤回范围只限本报告和本轮私有包，不改其它文件项。完成本轮后停止，不自行扩展到目录、产品修复或预算工作。
