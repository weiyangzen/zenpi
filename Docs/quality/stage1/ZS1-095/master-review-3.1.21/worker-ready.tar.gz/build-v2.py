from pathlib import Path
import json,hashlib,re,difflib,shutil
W=Path(__file__).resolve().parent
REPORT=json.loads((W/'capture.json').read_text())['report']
def save(name,data):(W/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def ident(data):return {'bytes':len(data),'lines':len(data.splitlines()),'sha256':hashlib.sha256(data).hexdigest()}
source=(W/'capture/zenpi/src/approval.rs').read_bytes();lines=source.splitlines(keepends=True)
spans=[(1,19,'M01','模块与依赖'),(20,39,'M10','策略枚举'),(40,57,'M01','请求字段'),(58,106,'M01','结构校验'),(107,121,'M01','决策响应'),(122,148,'M02','共享状态'),(149,164,'M02','构造'),(165,189,'M03','双请求入口'),(190,243,'M03','请求等待'),(244,267,'M04','drain'),(268,289,'M04','reveal'),(290,343,'M05','响应接受'),(344,352,'M06','pending查询'),(353,368,'M06','accepted查询'),(369,388,'M07','持久化协作'),(389,404,'M07','mark'),(405,432,'M08','普通取消'),(433,444,'M08','epoch取消'),(445,464,'M09','撤回'),(465,483,'M10','策略数据及默认'),(484,525,'M10','判定优先级'),(526,567,'M11','记忆恢复'),(568,572,'M12','记忆mutator'),(573,590,'M12','错误类型'),(591,601,'M13','测试配置及导入'),(602,619,'M13','策略测试一'),(620,632,'M13','策略测试二'),(633,648,'M13','策略测试三'),(649,690,'M14','协调器测试一'),(691,742,'M14','协调器测试二'),(743,780,'M14','协调器测试三')]
units=[]
for index,(lo,hi,mapping,title) in enumerate(spans,1):
 data=b''.join(lines[lo-1:hi]); start=sum(map(len,lines[:lo-1])); units.append({'id':'U%02d'%index,'title':title,'lines':[lo,hi],'byte_range':[start,start+len(data)],'map':mapping,**{k:v for k,v in ident(data).items() if k!='lines'}})
save('semantic-units.json',units)
fns=[]
for number,line in enumerate(lines,1):
 match=re.search(rb'\bfn\s+(\w+)',line)
 if match is None:continue
 indent=line[:len(line)-len(line.lstrip())]; hi=next(i for i in range(number+1,len(lines)+1) if lines[i-1].rstrip()==indent+b'}')
 data=b''.join(lines[number-1:hi]); unit=next(u for u in units if u['lines'][0]<=number<=u['lines'][1])
 fns.append({'name':match.group(1).decode(),'lines':[number,hi],'unit':unit['id'],'map':unit['map'],'kind':'source-test' if number>=602 else 'production',**{k:v for k,v in ident(data).items() if k!='lines'}})
save('function-bindings.json',fns)
tests=[]
for row in fns:
 if row['kind']!='source-test':continue
 lo,hi=row['lines'];data=b''.join(lines[lo-1:hi]); tests.append({**row,'id':'T%02d'%(len(tests)+1),'ordinary_assert_sites':len(re.findall(rb'\bassert(?:_eq|_ne)?!',data)),'snapshot_sites':0,'executed':False})
save('source-tests.json',tests)
body=(W/'report-body.md').read_text()
body=body.replace('本次没有运行125测试或宣告其最终验收。','本次没有运行125测试或宣告其最终验收。\n\n随后主控再次提供9dea→e451的页脚修正：另捕获 `delta/tui-footer.rs`，668438 B / 16361 L / SHA-256 `e45131dcf190d55068e369e55b8a3cc0dda18234ccee2c2ca335c9cefdd15904`；完整读取109行的root-footer-increment.patch。render_approval在未focused时直接返回，由render_footer统一选择文案，优先未保存警告、其次本项目隐藏审批、再后台审批及其他提示，避免后绘制审批文本覆盖警告或残留快捷键。两条新增TestBackend断言分别核resize后整行精确提示/保留草稿与请求、磁盘满警告优先；仅读新增测试，未运行，也不把主控仍在执行的回归写成通过。该增量没有修改095源码或9dea响应/计时语义。')
body=body.replace('随后只读相关明确行。','随后只读相关明确行。另一次新读页脚patch误请求L1–160（实际109行），read.py在写ledger前AssertionError退出；原命令、exit与traceback保存在preparation-footer-read-failure.log，随后按真实L1–109完成读取。该准备错误不删除，也不是冻结审计重跑。新build.py另发生一次metadata字段名冲突：identity的lines数量覆盖unit的lines区间，生成unit后在函数归属查找时报TypeError；原脚本、部分输出、命令/exit/traceback完整保存于preparation-build-v1，随后新build-v2.py排除标量lines覆盖。失败发生在候选与审计生成前，没有运行产品或冻结审计。')
maps=[]
for line in body.splitlines():
 if re.match(r'\| M\d\d ',line):
  columns=[part.strip() for part in line.strip('|').split('|')]
  maps.append({'id':columns[0].split()[0],'topic':columns[0][4:],'source':columns[1],'target':columns[1],'owners':columns[1].split('；')[-1],'criterion':columns[2]})
assert len(maps)==16
save('operation-maps.json',maps)
body+='\n## 全函数索引与读取核对\n\n以下为完整源码的29个fn声明（23生产函数、6源测试）。索引包含persist_accepted<E>泛型；Default同名函数依行号区分。状态/输入/错误/副作用结论已在前文逐一说明，索引不替代语义。\n\n| 函数 | 行区间 | 类型 | 语义映射 |\n|---|---|---|---|\n'
for row in fns:body+='| `%s` | %d–%d | %s | %s / %s |\n'%(row['name'],*row['lines'],row['kind'],row['unit'],row['map'])
body+='\n连续semantic-units共31段覆盖L1–780，含所有空行/注释与测试配置；read-binding的四个正式片段覆盖0–29396字节。上下文和历史读取独立列账，不计成正式源码第二轮阅读。source-tests的14普通assert文本位置、0snapshot与本次runtime执行0分别记录，不能换算成测试通过。\n'
path=W/'candidate'/REPORT;path.parent.mkdir(parents=True,exist_ok=True);assert not path.exists();path.write_text(body)
report_data=path.read_bytes();report_lines=body.splitlines(True)
(W/'report.patch').write_text(''.join(difflib.unified_diff([],report_lines,fromfile='/dev/null',tofile='b/'+REPORT)))
(W/'rollback.patch').write_text(''.join(difflib.unified_diff(report_lines,[],fromfile='a/'+REPORT,tofile='/dev/null')))
# Readonly reuse of already reviewed 303 evidence, no historical scripts or auditors invoked.
prior=W.parent/'reference303-approval321-ready';reuse_dir=W/'history/reference303-reuse';reuse_dir.mkdir()
for name in ['read-binding.json','operation-maps.json','source-tests.json','analysis-summary.json']:
 shutil.copyfile(prior/name,reuse_dir/name)
prior_rows=json.loads((prior/'read-binding.json').read_text());prior_name='capture/codex/codex-rs/tui/src/bottom_pane/approval_overlay.rs';prior_source=(prior/prior_name).read_bytes();assert prior_source==(W/prior_name).read_bytes();selected=[r for r in prior_rows if r['source']==prior_name]
save('reference-reuse.json',{'item':'ZS1-303','manifest':ident((prior/'manifest.json').read_bytes()),'report':ident((W/'history/reference303-report.md').read_bytes()),'source':ident(prior_source),'previous_full_read_chunks':len(selected),'previous_chunks_exact':all((prior/r['path']).read_bytes()==prior_source[slice(*r['byte_range'])] for r in selected),'formal095_credit':False,'new_runtime_execution':False})
active=json.loads((W/'capture/zenpi/Docs/execution/active_requirement.json').read_text())
save('authority-selection.json',{'formal':'current-main approval.rs explicitly assigned; baseline unchanged','baseline_sha256':'c592686334a95047f749d7c61c793abc03ce93d5312b22aadeefa5aed9c85844','blueprint_captured_sha256':'c392c1835d4749d4a6248a799b4317f165351cb6467d5f1527c10a88b7e1c25d','active_requirement_captured':active,'owned_paths':[REPORT],'master_semantic_acceptance_required':True})
save('analysis-summary.json',{'item':'ZS1-095','subject':ident(source),'formal_reads':4,'all_read_records':len(json.loads((W/'read-binding.json').read_text())),'semantic_units':len(units),'functions':len(fns),'production_functions':sum(r['kind']=='production' for r in fns),'source_tests':len(tests),'ordinary_assert_sites':sum(r['ordinary_assert_sites'] for r in tests),'snapshot_sites':0,'operation_maps':len(maps),'runtime_executions':0,'report':ident(report_data),'patch':ident((W/'report.patch').read_bytes()),'rollback':ident((W/'rollback.patch').read_bytes()),'scope':'one owned report creation, main and inherited report untouched'})
print((W/'analysis-summary.json').read_text())
