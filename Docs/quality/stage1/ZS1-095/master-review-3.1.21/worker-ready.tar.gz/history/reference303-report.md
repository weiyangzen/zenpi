# ZS1-303 · ApprovalOverlay 完整源码审查（3.1.21候选）

状态：[_] 候选，主控独立 G-FILE 接受待定。唯一owned path为本报告；产品/权威/旧ready未修改。
正式源 `codex-rs/tui/src/bottom_pane/approval_overlay.rs`；HEAD `b3b3d262787f4902a7449f17d793241a34d311ad`；57262 B /1556行 /SHA256 `c924923b402b198f8f77b249f0d37892896c0b84002c0f6e48330917da80cecc`。7块顺序读取覆盖[0,57262)，每块≤256KiB，包含所有源码、注释、声明、helpers和tests。
run_id `zenpi-stage1-20260911`；requirement_digest `3456abcbbebbc4e0ab383c319851b0a6e71b19ee9b3c060a6e212f61a89c9d9d`；blueprint snapshot `52e9772ec898dd54d445a2dfb2b10e75758362fff8157cb139db15d77f82b6c3`；baseline snapshot `92b06c4b1dcdca7614d226ce5f41205646a9e63967789d2b6ed4ee272d240884`。
fresh main tui 648110 B /15853行 /`a19dfcf74a5ae07e394dc1e434e563f088bb555fdd739a61e2736acfc3a9d0b8`，已集成123补全/矮屏，保留BentoBox。B私有125计时修复不算当前main；freeze漂移另记录。
结论：overlay把已构造的选择转为thread-scoped事件，并管理本地完成/后进先出视图队列。源默认确认可批准且y直接提交；zenpi默认拒绝并需Enter确认。源清队列、local done、sender调用均不等于所有owner已终结；目标的原子接受、取消命令入队、持久化和实际副作用必须分别验证。
新补充有界上下文确认：KeyBinding包含Repeat；List默认首项和数字/导航；生产父层Esc先走on_ctrl_c而非overlay选项；sender吞错误；5份快照已读；主线后台审批hint/badges已有。旧报告未读这些上下文的局限不再直接沿用。

## 全部操作与目标owner映射

以下源码观察不等于运行。所有判据均是待执行步骤，本轮源测试/目标测试/runtime/Cargo/PTY/HTTP/release执行数为0。

### M01 类型、来源与显示身份 → ZS1-124/123

源L1–113定义Exec、Permissions、ApplyPatch、McpElicitation四型，均保ThreadId与可选label；关联分别为id/call_id/id/server+RequestId。Exec携owner提供choices、网络context和附加权限；Patch带cwd/HashMap改动。thread_id复制、label借用；label Some（含空串）控制显示/导航及本地history抑制，不是来源认证。

新主线tui L1043–1068把请求放active_project的view；approval.rs L40–105验证ID不空/≤128B/无控制字符、arguments对象、digest64小写hex、lease、worker必需policy+lease、preview.validate。请求本身没有project字段；响应另由tui L1291–1333核owner_project、active_project、request/turn/call及pending。结构校验不能证明真正来源。

源T03只验证plain o的ThreadId。判据：相同ID错thread/turn/call、当前项目与owner错配分别拒绝；目标context tests的actual_coordinator用错owner/错call再Deny与重复响应，不能扩大成所有四型来源测试。

### M02 初始化、队列次序与容量 → ZS1-124/132

源L116–142 new先创建默认list再set_current；set_current清current_complete、重建header/options/list，但不重置done。enqueue只是push；advance_queue L364–370使用pop，因此A当前、B再C排队，A完成后取C。无去重/长度限制。try_consume L475–481总enqueue并None，即使done；重用完成对象不会自动复活。

tui L1043–1123按项目Vec保请求、最多128、同request_id不重复；首次设index0/scroll0/deny/不记忆，retire重置选择。approval.rs L133–138的pending为BTreeMap，drain L247–264按key遍历一次mark visible；不是到达FIFO，也没有从view128推导coordinator总容量。第129项显示丢弃与owner等待如何协调仍需124/132。

源T01只是queue空；无LIFO或done后enqueue测试。判据：A/B/C顺序、重复ID、满view第129项仍能有终态、done对象新请求拒收或新建；目标capacity测试只断言view128，不能证明所有等待者终结。

### M03 选项生成与策略范围 → ZS1-124/123

源L144–211 build_options取exec_options或三种固定列表，标题按network host/请求类型分；_features未使用。SelectionItem仅label、display shortcut回落additional第一项，dismiss_on_select=false，其余Default。L660–748遍历原available_decisions保序，唯一显式过滤是exec prefix渲染含LF/CR。无组合校验、去重或host/prefix匹配。

目标只有Allow/Deny加remember，不是任意ReviewDecision；worker在UI与coordinator都禁止remember。network/additional参数主要改源文案，不会自动删owner已提供的exec-policy或network Deny。源同键p或d冲突由第一个匹配决定；改动权限取决于payload而非label。

T05精确echo prefix，T06/T08/T10/T17输入未含声称隐藏项，不能证明过滤矛盾列表。判据：network+execprefix、Allow和prefix两个p、Denied和networkDeny两个d、空list、CR/LF、重复项；精确核payload与顺序。

### M04 快捷键、导航与默认确认 → ZS1-122/124

源L372–430先Ctrl-A Press且containsCONTROL发FullScreenApprovalRequest；o仅Press、label Some、无modifier限制。其它遍历options首match直接apply，无Enter二次确认。新读KeyBinding L29–33：is_press包括Press与Repeat、modifier精确相等，名字不等于Press-only。List上下/jk/Ctrl-P/N含C0回退、数字1–9、Enter由委托处理，本身未按kind过滤。默认首选index0，源初始Enter可批准。

目标tui L1124–1203 y/n只选择并清remember，Enter才RespondApproval，默认deny；r应在y/n之后，Tab/左右换请求重置deny/scroll/remember。除exact Alt-A与Ctrl-C其余modified先吞掉，所以常见Shift+BackTab虽有分支但可被前置拒绝。真实handle_event L5705只送Press，direct handle_key仅过滤Release，两个入口不能混称。

源T02仅看任意SubmitThreadOp，T19精确初始Approved+overlay done；T03不覆盖modified o。判据：长按Repeat连续跨队列决策、Release直调与生产父层、shift数字/BackTab、CtrlShiftA、同键冲突；目标选择未Enter不得执行。

### M05 Esc、Ctrl-C及外层焦点 → ZS1-122/124/305

源L432–469 done早退Handled；否则当前未complete就发送对应Abort/Cancel，清整个queue、done=true但不设current_complete、不清current_request。源直接Esc option可仅完成当前并advance；然而父BottomPane L369–455看到preferEsc默认false，先on_ctrl_c，因此生产Esc清队列并pop一个view，不等于直接overlay.handle_key_event(Esc)。Permissions无Esc选项，直调仅让list完成而overlay.done未跟随；生产父层才发空Turn取消。

目标Esc解除focused并保pending/draft，slash解除后继续输入，Alt-A重进；Ctrl-C返回Interrupt。picker在approval_key最前让出；present can_focus没排除history_search。当前BentoBox存在时的键路由和渲染顺序分别实现，不能用文案证明所有焦点组合。

源T01未读rx，不验证Abort或每个排队请求回包；正常host卸下done对象是防止取消后重入再答的重要前提。判据：同一对象Ctrl-C后再y可能再次尝试提交、两个queued分别收何终态；所有差异为静态分析，未运行复现。

### M06 选择分派、发送失败与完成态 → ZS1-124/132

源L213–252 current_complete/无效index早退；匹配request和decision才调用handler，非法配对空分支但随后仍current_complete=true并advance。正常build_options生成匹配类型。handler没有current request时return；外层仍完成。AppEventSender新读L18–26先log（非CodexOp）再unbounded send，失败只记error不返回Result；overlay推进不等待发送成功或后端ACK。

目标tui L1291–1333 coordinator.respond成功后retire+system消息，生产L12511–12542失败也retire并显示Approval unavailable。approval.rs L297–341在mutex内拒unknown/duplicate、拒workerremember、原子remove pending、保存accepted+decision、notify；这是决策接受，不是工具完成/持久化成功。

源缺失sender关闭、非法内部组合、取消后重入测试。目标tests wrongcall/duplicate/stale只有限定owner用例。判据：断开channel、重复答、跨项目及response后tool失败分开计数，UI done不能作exactly-once端到端证明。

### M07 Exec决策、历史与持久策略 → ZS1-124/123

源L254–275无label先User history cell，再SubmitThreadOp ExecApproval{id,turn_id:None,decision}到存储ThreadId；command用于历史，不在此执行。Approved=y；Session=a；prefix=p；network Allow=p/Deny=d；Denied=d继续不执行；Abort=Esc/n改变做法。prefix和network amendment保原精确对象。

zenpi modal y/n是Allow/Deny，n不是Abort；remember是tool粒度，不等于命令prefix、网络host永久规则或跨会话全局grant。当前coordinator仅允许普通origin remember；策略replay的全实现不在本次源范围，目标tui_approval_focus后两测试验证限定session/Deny合并，但仅源码读取。

源T05只核decision prefix，未核thread/id/turn；T18直接history_cell四行28列并非overlay全链路。判据：label None/Some空各history数量、sender失败后历史已显示但操作未送达、Session/Denied/Abort精确payload；持久写由真正owner验证。

### M08 Permissions精确profile和scope → ZS1-124/123

源L277–320 Approved/Session克隆请求profile；Denied/Abort及两类amendment均默认空profile；只有Session决定scopeSession，其余Turn。无label本地history先看profile是否empty，再看Session，空Session也显示未授予。发送RequestPermissionsResponse{id:call_id,permissions,scope}，不调用OS权限接口。固定L858–879 y/a/n，无Esc shortcut。

zenpi通用工具Allow/Deny没有这里同型profile响应证据；workerpolicy/lease和toolremember不等价OS/network/filesystem范围。归124决策绑定、123能力披露；不为产品未实现能力制造通过结论。

源T11仅label，T12只Session scope+看到响应，不检精确profile/id/thread；T15快照。判据：空profile Session、Denied/Abort Turn、外部requested→PermissionProfile转换、不可见字段应逐字段比较，不能以批准文案证明实际授予。

### M09 Patch与MCP及全屏预览 → ZS1-124/123

源L322–362 Patch只发id/decision，MCP发server/request/Accept-Decline-Cancel且content/meta恒None；不是填写表单。Patch固定y/a/Esc+n，MCP y/n/Esc+c。Ctrl-A只把完整当前request clone送事件，不审批，也不证明consumer展示全量。父chatwidget L3337–3359先尝试form类型，失败才这类MCP fallback。

目标tui L1204–1287展示owner给的Diff preview，truncated时提示inspect source，End/scroll查看已有patch；没有focused Ctrl-A完整原文动作，本轮未查阅全屏consumer或ToolPreview所有实现，因此不把截断补全文入口当已验证。MCP专有请求交互也无本次目标同型证据。

源无Patch/MCP实例响应测试或Ctrl-A测试。目标full_diff_scroll用150行未截断fixture只检末行149和resize不panic，不能证明截断原文可取回。判据：全量变化字节/来源hash、打开返回焦点、请求已失效后确认，禁止以导航动作视作授权。

### M10 标题、命令、reason与权限披露 → ZS1-124/125

源L498–636 footer总Enter/Esc，有label加o。Exec/Permissions reason Some空也插行，Patch只非空；network标题仅host未显示protocol，并隐藏command（虽仍构造highlight）。普通command strip_bash_lc_and_escape后首行加$；Patch DiffSummary(changes,cwd)，MCP Server+message。本文件不验证内容长度、签名或路径。

目标tui L1243–1287显示Project/Request/Turn/Call/Tool/sideeffect/Policy/Lease及redact_json arguments，preview再转换为render_plain_prefixed行；policy digest不是diff sourcehash。背景hint按项目名限宽，不能作身份凭证。source highlighting/diff处理未全文读，不声明所有控制字符/转义已安全处理。

源T07仅命令snippet存在，T13仅Permission rule/network存在；T17含host、无curl和无dontask文案。判据：换行/control/reason空串、相同标题不同owner、路径超长、network host和amendment不同；明确展示内容和真正授权内容一致。

### M11 权限格式化全部分支 → ZS1-123/124/125

源L750–833 network enabled true显示network；read/write Some即join，空Vec仍read/write前缀。macOS preferences默认ReadOnly省略，ReadWrite/None显示；automation All/非空BundleIds显示、None/空省略；accessibility/calendar/reminders true显示；contacts非None列readonly/readwrite。macos_launch_services无输出分支。parts空None，否则分号连；requested.clone().into委托同formatter。显示省略不等于权限未授予。

目标限定上下文未见同型macOS/network profile UI，泛化工具arguments/preview显示不构成对等。归123能力、124授权范围、125可见披露；仅文字renderer不改OS权限。

源T16的macos_launch_services=false、contactsNone，不检省略字段为true；仅覆盖RWpreferences、两个bundle和三个bool。判据：launch_services true、preferencesNone、contacts两种、空目录Vec、network false/None与组合全profile逐项核对。

### M12 鼠标、粘贴与窗口尺寸 → ZS1-122/124/125/126

ApprovalOverlay没有鼠标接口；BottomPaneView trait无mouse方法，paste默认false，此overlay未覆盖；故本层没有点击批准，也不把paste作为快捷键。height/render/cursor完全委托list。Source shortcut与list直接入口的keykind规则不同，不能把父层Release过滤当overlay自身实现。

目标event L5707–5745 focused审批且mouse.row>0只滚动±3，其他鼠标吞掉并redraw；row0继续handle_mouse，本轮不扩大到该handler全部行为。paste先解除审批焦点再分给browser/picker/history/composer，literal y+LF不会自动答。render L1226小于4×5不画focused modal，但键路由无尺寸门；backtab修饰和不可见确认仍独立边界。

目标full_diff_scroll经1×1/4×5/20×10/100×30仅render无末态断言；source无mouse/尺寸测试。判据：点击/拖动审批按钮位置不得当Enter、滚动不改决定、resize隐藏后确认可见性、paste保持draft与请求未答。

### M13 后台提醒、来源切换与计时 → ZS1-124/125

源只有label/o及事件转发，不在overlay管理全局后台数量；父pane合并请求时仅redraw，新modal暂停status，完成无条件resume/enable，计时不属于ApprovalOverlay。Ctrl-A/o都未检查done；生命周期须父层停止分派。

当前主线a19df…已包含123补全与矮屏，background_approval_hint L1079–1109最多展示3个项目、每名28列与余量，view实际仍保全部允许项；BentoBox L7189–7232保留，审批最后画。set_status L3859–3893仍字符串Approval触发pause，B私有125修复不算主线。目标12个focus tests中的背景用例覆盖两renderer、!2→!1→无、活动草稿不变。

源T03/T04仅带label导航/footer；不能证明后台banner/计时终态。判据：后台请求出现不抢当前稿、切原项目再审批、label空串、两请求仅一结束时timer不误恢复；此轮无计时运行。

### M14 取消传递、错误及持久化边界 → ZS1-124/132

源本地clear队列无逐queued terminal，无ACK，无重启序列；sender error被吞，done仅UI。反复Ctrl-C done时幂等Handled，而done后key缺guard是不同入口。

新tui L13167–13202先local_diff_host.cancel_current，再new_sessions，再拒跨project activejob；pending_inputs.cancel后runner.try_cancel，仅非QueueFull才emergency_cancel和清审批。coordinator L405–441对所有pending保存Deny并增加emergency epoch；request_inner cancelled检查移除状态返回Cancelled。无activejob、poison、QueueFull均不能说取消全成功。L370–402提供persist/retract，但request_inner看到decision即返回，request_response仅保留accepted给调用者；durable-before-sideeffect仍依赖真实core使用合同，本文件或注释不足证明锁内持久化门。

目标test owner385–400检查emergency后process错误、note.txt不存在、pending消失；context helpers已读，执行0。判据：正常确认、持久化失败、已经答但未消费、QueueFull、跨project与强停分别证明终态，不能以UI关闭或原子remove推导工具副作用已终止。

### M15 测试与快照证据精度 → ZS1-303/124

全文1556行已按7块连续读，29生产fn+5helpers+19tests，所有声明和注释都在范围账本。helpers渲染取完整cell symbol并trim_end，normalize只/tmp/readme.txt与/tmp/out.txt。源T19名称without_dismissing其实断言overlay done=true。五处snapshot全新读；network snap assertion_line821是旧metadata，当前调用1474，不能用旧行号定位。

目标tui_approval_focus.rs全428行作为context读（12 tests），另approval_owner一test及helpers限定范围；不新增这些源文件的逐文件接受数。代码写了fixture动作不代表本轮动作发生。

缺测试矩阵：Patch/MCP exactpayload、Ctrl-A、LIFO、反复key、隐藏options混合、prefix CR/LF、发送失败、鼠标、全部macOS、队列取消全部waiters。每个前文判据均待运行，本轮源/目标/Cargo/PTY/HTTP/runtime执行0。

### M16 历史、owned路径与审计合同 → ZS1-303（本报告）

旧303 ready60 regular+aggregate17完整保存；旧38605B/176行report与原3623B/16行均重读，但未代替正式源码阅读。旧报告未读KeyBinding/List/snap本轮补充，原FIFO建议不能转源/目标FIFO事实。

唯一owned报告创建/撤回；不改main产品/蓝图/index/旧ready，不使用305的有缺陷verifier、不重跑旧探针。102旧ready29926regular与145tracked先后hash保护。当前main取a19df…，freeze漂移另记，不把B125私有结果当集成。G-FILE最终是主控独立语义审阅，不由hash/checker代替。

新portable verifier先静态复核变量绑定、补丁创建/删除和只读包；最多一次冻结执行。失败完整保留；结构审计只验证材料自洽，不能写19tests passed或工具安全总验收。

## 字节分区和全部函数

每行连续归入一个单元，非函数空行/属性计入邻接单元。精确函数body范围/hash独立绑定；表格计数不能替代上文语义。

|单元|源行|字节[起,止)|映射|
|---|---|---|---|
|U01|1–115|[0,3920)|M01|
|U02|116–143|[3920,4916)|M02|
|U03|144–212|[4916,7325)|M03|
|U04|213–253|[7325,8887)|M06|
|U05|254–276|[8887,9698)|M07|
|U06|277–321|[9698,11556)|M08|
|U07|322–363|[11556,12695)|M09|
|U08|364–371|[12695,12876)|M02|
|U09|372–421|[12876,14514)|M04|
|U10|422–431|[14514,14821)|M04|
|U11|432–474|[14821,16239)|M05|
|U12|475–483|[16239,16425)|M02|
|U13|484–497|[16425,16762)|M12|
|U14|498–515|[16762,17276)|M10|
|U15|516–637|[17276,21808)|M10|
|U16|638–659|[21808,22314)|M03|
|U17|660–749|[22314,26628)|M03|
|U18|750–834|[26628,29624)|M11|
|U19|835–857|[29624,30592)|M09|
|U20|858–880|[30592,31548)|M08|
|U21|881–903|[31548,32527)|M09|
|U22|904–983|[32527,35539)|M15|
|U23|984–994|[35539,35990)|M05|
|U24|995–1012|[35990,36738)|M04|
|U25|1013–1041|[36738,37838)|M01|
|U26|1042–1066|[37838,38741)|M13|
|U27|1067–1118|[38741,40618)|M07|
|U28|1119–1157|[40618,42198)|M03|
|U29|1158–1192|[42198,43537)|M10|
|U30|1193–1226|[43537,44806)|M03|
|U31|1227–1249|[44806,45513)|M07|
|U32|1250–1274|[45513,46375)|M03|
|U33|1275–1290|[46375,46874)|M08|
|U34|1291–1317|[46874,47790)|M08|
|U35|1318–1365|[47790,49681)|M10|
|U36|1366–1396|[49681,50975)|M11|
|U37|1397–1407|[50975,51391)|M08|
|U38|1408–1443|[51391,52984)|M11|
|U39|1444–1500|[52984,55341)|M10|
|U40|1501–1531|[55341,56397)|M07|
|U41|1532–1556|[56397,57262)|M04|

53个文本fn=29生产+5helpers+19tests。没有按名字去重，也不把上下文符号计入本文件。

|函数|行|类别|单元/映射|
|---|---|---|---|
|`thread_id`|84–91|production|U01/M01|
|`thread_label`|93–100|production|U01/M01|
|`new`|116–129|production|U02/M02|
|`enqueue_request`|131–133|production|U02/M02|
|`set_current`|135–142|production|U02/M02|
|`build_options`|144–211|production|U03/M03|
|`apply_selection`|213–252|production|U04/M06|
|`handle_exec_decision`|254–275|production|U05/M07|
|`handle_permissions_decision`|277–320|production|U06/M08|
|`handle_patch_decision`|322–337|production|U07/M09|
|`handle_elicitation_decision`|339–362|production|U07/M09|
|`advance_queue`|364–370|production|U08/M02|
|`try_handle_shortcut`|372–418|production|U09/M04|
|`handle_key_event`|422–430|production|U10/M04|
|`on_ctrl_c`|432–469|production|U11/M05|
|`is_complete`|471–473|production|U11/M05|
|`try_consume_approval_request`|475–481|production|U12/M02|
|`desired_height`|485–487|production|U13/M12|
|`render`|489–491|production|U13/M12|
|`cursor_pos`|493–495|production|U13/M12|
|`approval_footer_hint`|498–514|production|U14/M10|
|`build_header`|516–636|production|U15/M10|
|`shortcuts`|653–657|production|U16/M03|
|`exec_options`|660–748|production|U17/M03|
|`format_additional_permissions_rule`|750–827|production|U18/M11|
|`format_requested_permissions_rule`|829–833|production|U18/M11|
|`patch_options`|835–856|production|U19/M09|
|`permissions_options`|858–879|production|U20/M08|
|`elicitation_options`|881–902|production|U21/M09|
|`absolute_path`|921–923|test-helper|U22/M15|
|`render_overlay_lines`|925–939|test-helper|U22/M15|
|`normalize_snapshot_paths`|941–950|test-helper|U22/M15|
|`make_exec_request`|952–963|test-helper|U22/M15|
|`make_permissions_request`|965–981|test-helper|U22/M15|
|`ctrl_c_aborts_and_clears_queue`|984–992|source-test|U23/M05|
|`shortcut_triggers_selection`|995–1010|source-test|U24/M04|
|`o_opens_source_thread_for_cross_thread_approval`|1013–1039|source-test|U25/M01|
|`cross_thread_footer_hint_mentions_o_shortcut`|1042–1064|source-test|U26/M13|
|`exec_prefix_option_emits_execpolicy_amendment`|1067–1116|source-test|U27/M07|
|`network_deny_forever_shortcut_is_not_bound`|1119–1155|source-test|U28/M03|
|`header_includes_command_snippet`|1158–1190|source-test|U29/M10|
|`network_exec_options_use_expected_labels_and_hide_execpolicy_amendment`|1193–1224|source-test|U30/M03|
|`generic_exec_options_can_offer_allow_for_session`|1227–1247|source-test|U31/M07|
|`additional_permissions_exec_options_hide_execpolicy_amendment`|1250–1272|source-test|U32/M03|
|`permissions_options_use_expected_labels`|1275–1288|source-test|U33/M08|
|`permissions_session_shortcut_submits_session_scope`|1291–1315|source-test|U34/M08|
|`additional_permissions_prompt_shows_permission_rule_line`|1318–1363|source-test|U35/M10|
|`additional_permissions_prompt_snapshot`|1366–1394|source-test|U36/M11|
|`permissions_prompt_snapshot`|1397–1405|source-test|U37/M08|
|`additional_permissions_macos_prompt_snapshot`|1408–1441|source-test|U38/M11|
|`network_exec_prompt_title_includes_host`|1444–1498|source-test|U39/M10|
|`exec_history_cell_wraps_with_two_space_indent`|1501–1529|source-test|U40/M07|
|`enter_sets_last_selected_index_without_dismissing`|1532–1555|source-test|U41/M04|

## 所有19个源测试

普通assert位置24，snapshot位置5；不是运行断言次数。5helpers已全读：绝对路径构造、Buffer逐cell/trim、两个路径替换、Exec与Permissions fixture。fixture字符串含命令不表示执行过命令。

|测试|行|普通assert/snap|准确观察与局限|
|---|---|---|---|
|T01 `ctrl_c_aborts_and_clears_queue`|984–992|3/0|Ctrl-C Handled、queue空、done；rx未读，没有Abort payload/queued terminal断言；M05|
|T02 `shortcut_triggers_selection`|995–1010|2/0|初态未done、y后至少任意SubmitThreadOp；无具体decision/ID/count；M04|
|T03 `o_opens_source_thread_for_cross_thread_approval`|1013–1039|1/0|plain o首事件SelectAgentThread等于源ID；无modified/无label覆盖；M01|
|T04 `cross_thread_footer_hint_mentions_o_shortcut`|1042–1064|0/1|80列跨thread snapshot，显示o，不是导航执行；M13|
|T05 `exec_prefix_option_emits_execpolicy_amendment`|1067–1116|2/0|p后ExecApproval exact echo prefix并确认找到；无ID/thread/count；M07|
|T06 `network_deny_forever_shortcut_is_not_bound`|1119–1155|1/0|只给Allow网络amendment未给Deny，d无事件；不证明Deny过滤；M03|
|T07 `header_includes_command_snippet`|1158–1190|1/0|80列含echo hello world；非所有escaping或完整命令；M10|
|T08 `network_exec_options_use_expected_labels_and_hide_execpolicy_amendment`|1193–1224|1/0|network四label比较，输入没有execprefix；hide命名不证过滤；M03|
|T09 `generic_exec_options_can_offer_allow_for_session`|1227–1247|1/0|generic Approved/Session/Abort三label；M07|
|T10 `additional_permissions_exec_options_hide_execpolicy_amendment`|1250–1272|1/0|additional列表仅Approved/Abort；未传被称为隐藏的amendment；M03|
|T11 `permissions_options_use_expected_labels`|1275–1288|1/0|Permissions三label；不核每个payload；M08|
|T12 `permissions_session_shortcut_submits_session_scope`|1291–1315|2/0|a找到响应且Session scope；未核profile/id/thread；M08|
|T13 `additional_permissions_prompt_shows_permission_rule_line`|1318–1363|2/0|120列存在Permission rule和network;，未逐项比路径；M10|
|T14 `additional_permissions_prompt_snapshot`|1366–1394|0/1|120列additional快照，两个路径规范化；M11|
|T15 `permissions_prompt_snapshot`|1397–1405|0/1|120列Permissions快照；M08|
|T16 `additional_permissions_macos_prompt_snapshot`|1408–1441|0/1|120列macOS快照，未覆盖launch_services=true/contacts非None；M11|
|T17 `network_exec_prompt_title_includes_host`|1444–1498|3/1|100列Buffer Debug快照+host在标题+无curl+无dontask；输入无execprefix；M10|
|T18 `exec_history_cell_wraps_with_two_space_indent`|1501–1529|1/0|外部history_cell 28列精确四行/两空格，不运行git；M07|
|T19 `enter_sets_last_selected_index_without_dismissing`|1532–1555|2/0|Enter overlay done=true且收到Approved；名withoutdismissing并非overlay留存；M04|

五份关联snapshot全部完整读，期望文件本身不等于新输出：network为100×12 Buffer Debug含styles，选中“just once”、无命令；cross-thread80列首项批准、o提示；additional120列network/read/write；permissions120列三选项；macOS120列长rule换行。旧assertion_line和expression metadata未必当前代码逐字一致，不以它冒称新跑insta。

## 读取上下文账本

本轮总读取块46，正式subject7块。上下文仅为具体语义边界，即使小文件或428行目标tests完整读，也不为其对应G-FILE新增接受数。仅复制未列范围的文件不算读过。

|块|文件|行|
|---|---|---|
|reads/001.txt|`capture/codex/codex-rs/tui/src/bottom_pane/approval_overlay.rs`|1–250|
|reads/002.txt|`capture/codex/codex-rs/tui/src/bottom_pane/approval_overlay.rs`|251–500|
|reads/003.txt|`capture/codex/codex-rs/tui/src/bottom_pane/approval_overlay.rs`|501–750|
|reads/004.txt|`capture/codex/codex-rs/tui/src/bottom_pane/approval_overlay.rs`|751–1000|
|reads/005.txt|`capture/codex/codex-rs/tui/src/bottom_pane/approval_overlay.rs`|1001–1250|
|reads/006.txt|`capture/codex/codex-rs/tui/src/bottom_pane/approval_overlay.rs`|1251–1500|
|reads/007.txt|`capture/codex/codex-rs/tui/src/bottom_pane/approval_overlay.rs`|1501–1556|
|reads/008.txt|`capture/codex/codex-rs/tui/src/bottom_pane/list_selection_view.rs`|245–356|
|reads/009.txt|`capture/codex/codex-rs/tui/src/bottom_pane/list_selection_view.rs`|408–478|
|reads/010.txt|`capture/codex/codex-rs/tui/src/bottom_pane/list_selection_view.rs`|576–690|
|reads/011.txt|`capture/codex/codex-rs/tui/src/bottom_pane/bottom_pane_view.rs`|1–90|
|reads/012.txt|`capture/zenpi/src/tui.rs`|1043–1255|
|reads/013.txt|`capture/zenpi/src/tui.rs`|1285–1338|
|reads/014.txt|`capture/zenpi/src/tui.rs`|5642–5762|
|reads/015.txt|`capture/zenpi/src/tui.rs`|3859–3893|
|reads/016.txt|`capture/zenpi/src/tui.rs`|1254–1287|
|reads/017.txt|`capture/zenpi/src/approval.rs`|18–102|
|reads/018.txt|`capture/zenpi/src/approval.rs`|190–350|
|reads/019.txt|`capture/zenpi/src/approval.rs`|355–459|
|reads/020.txt|`capture/codex/codex-rs/tui/src/chatwidget.rs`|3292–3405|
|reads/021.txt|`capture/codex/codex-rs/tui/src/app_event_sender.rs`|1–28|
|reads/022.txt|`capture/codex/codex-rs/tui/src/key_hint.rs`|1–72|
|reads/023.txt|`capture/codex/codex-rs/tui/src/bottom_pane/mod.rs`|369–455|
|reads/024.txt|`capture/codex/codex-rs/tui/src/bottom_pane/mod.rs`|465–504|
|reads/025.txt|`capture/codex/codex-rs/tui/src/bottom_pane/mod.rs`|904–921|
|reads/026.txt|`capture/codex/codex-rs/tui/src/bottom_pane/mod.rs`|1031–1055|
|reads/027.txt|`capture/codex/codex-rs/tui/src/bottom_pane/snapshots/codex_tui__bottom_pane__approval_overlay__tests__network_exec_prompt.snap`|1–38|
|reads/028.txt|`capture/codex/codex-rs/tui/src/bottom_pane/snapshots/codex_tui__bottom_pane__approval_overlay__tests__approval_overlay_cross_thread_prompt.snap`|1–14|
|reads/029.txt|`capture/codex/codex-rs/tui/src/bottom_pane/snapshots/codex_tui__bottom_pane__approval_overlay__tests__approval_overlay_additional_permissions_prompt.snap`|1–17|
|reads/030.txt|`capture/codex/codex-rs/tui/src/bottom_pane/snapshots/codex_tui__bottom_pane__approval_overlay__tests__approval_overlay_additional_permissions_macos_prompt.snap`|1–18|
|reads/031.txt|`capture/codex/codex-rs/tui/src/bottom_pane/snapshots/codex_tui__bottom_pane__approval_overlay__tests__approval_overlay_permissions_prompt.snap`|1–16|
|reads/032.txt|`history/zs1-303-ready/Docs/learn/stage1_pi_mono/references/codex/files/codex-rs/tui/src/bottom_pane/approval_overlay.rs_learn.md`|1–60|
|reads/033.txt|`history/zs1-303-ready/Docs/learn/stage1_pi_mono/references/codex/files/codex-rs/tui/src/bottom_pane/approval_overlay.rs_learn.md`|61–120|
|reads/034.txt|`history/zs1-303-ready/Docs/learn/stage1_pi_mono/references/codex/files/codex-rs/tui/src/bottom_pane/approval_overlay.rs_learn.md`|121–176|
|reads/035.txt|`capture/zenpi/tests/tui_approval_focus.rs`|1–215|
|reads/036.txt|`capture/zenpi/tests/tui_approval_focus.rs`|216–428|
|reads/037.txt|`history/codex-reference-ready/Docs/learn/stage1_pi_mono/references/codex/files/codex-rs/tui/src/bottom_pane/approval_overlay.rs_learn.md`|1–16|
|reads/038.txt|`capture/zenpi/src/approval.rs`|103–189|
|reads/039.txt|`capture/zenpi/src/approval.rs`|460–464|
|reads/040.txt|`capture/zenpi/tests/approval_owner.rs`|385–403|
|reads/041.txt|`capture/zenpi/Docs/stage_1_v3_pi_mono_blueprint.md`|133–141|
|reads/042.txt|`capture/zenpi/Docs/stage_1_v3_pi_mono_blueprint.md`|403–421|
|reads/043.txt|`capture/zenpi/src/tui.rs`|13167–13223|
|reads/044.txt|`capture/zenpi/src/tui.rs`|12511–12545|
|reads/045.txt|`capture/zenpi/src/tui.rs`|7189–7235|
|reads/046.txt|`capture/zenpi/tests/approval_owner.rs`|1–87|

目标test声明：tui_approval_focus12项（default、paste/Esc、多个请求/项目、后台、worker/Release、150行diff/resize、真实coordinator错配/重复、取消后stale、容量、sessionremember、replay、picker），以及approval_owner emergency_cancel一项及其helpers。测试源码都只是阅读；此处不列passed数。没有鼠标点击授权或满队列全部waiter终态实测。

## 历史保留、失败与回滚

旧303报告38605 B/176行/SHA256 `f34fde7190c902f643c58d302eeb3f981b7fa61ba0c1e6a140a0b43af53358bc`，本轮完整重读；原聚合report3623 B/16行/29c2cbd33bbc44f2b1f4ec3f2c78ee1c783182236cc923ea521036feb08b2472也全读。旧303整包60 regular与聚合17完整复制保留，源文件须逐字节一致；旧基线tui577503 B/93a68354…不当当前main。旧context片段字节匹配只作漂移定位，不作阅读信用。
历史H132 9policy+8control+3recovery成功组与其expanded/background/deps/control失败原记录均保留；旧124 before8true/12false失败、after26true、legacy14true仅历史范围。expanded因slash后缺Alt-A的夹具失败、旧proxy失败、构建cwd/API/依赖错误和冷启动1208.732708ms超1000ms不抹去。旧报告提及但原包没有的大日志保持其原链接，不虚构复制。没有为303重跑任何旧程序。
本轮准备阶段一次新read.py请求app_event_sender1–85超实际28行，AssertionError原输出与exit1保存在preparation-read-failure.log；范围验证在ledger写入前停止，随后1–28正常阅读，不伪报第一次成功。初始定位不存在selection_view.rs亦记录，实际使用list_selection_view.rs。
保全102旧ready/29926 regular与145 tracked，冻结前只读复比；只创建新候选及唯一报告正反patch。master正向创建报告、reverse仅删除报告，不触碰索引/蓝图/产品。新审计脚本不执行history/capture/build代码，只查manifest、范围、语义绑定、只读payload与临时补丁回放；先静态复核避免305的walrus覆盖manifest，再最多一次冻结审计，原始输出存包外。任何审计失败原样保留不重试。结构通过也不替代G-FILE语义接受或安全工具验收。
