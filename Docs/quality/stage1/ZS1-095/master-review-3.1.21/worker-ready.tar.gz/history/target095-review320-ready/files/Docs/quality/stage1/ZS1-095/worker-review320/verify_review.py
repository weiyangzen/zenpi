from pathlib import Path
import hashlib,json,runpy,sys,re,difflib
R=Path.cwd();M=Path('/Users/wangweiyang/GitHub/zenpi');E=R/'Docs/quality/stage1/ZS1-095/worker-review320';H=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((E/'input-manifest.json').read_text());sel=json.loads((M/'Docs/execution/active_requirement.json').read_text());assert sel['blueprint_version']==m['authority']=='3.1.20' and sel['requirement_digest']==m['requirement_digest'] and sel['baseline_files']['ZS1-095']==m['frozen']
all_ranges={}
for label in ['baseline','current']:
 row=m[label];b=Path(row['path']).read_bytes();assert len(b)==row['bytes'] and len(b.splitlines())==row['lines'] and H(b)==row['sha256'] and b==(R/row['artifact']).read_bytes();parts=[];rr=[]
 for c in row['read_chunks']:
  d=(R/c['artifact']).read_bytes();assert H(d)==c['sha256'] and d==b[c['byte_start']:c['byte_end']];parts.append(d);rr.append([c['byte_start'],c['byte_end']])
 assert b''.join(parts)==b;all_ranges[label]=rr
assert m['baseline']['sha256']==m['frozen']['sha256'] and m['baseline']['bytes']==m['frozen']['bytes']
expected=''.join(difflib.unified_diff((E/'baseline-approval.rs').read_text().splitlines(True),(E/'current-approval.rs').read_text().splitlines(True),fromfile='frozen/src/approval.rs',tofile='current/src/approval.rs'));assert (E/'baseline-to-current.diff').read_text()==expected
# The reviewed current change is exactly the additional replay helper.
current=(E/'current-approval.rs').read_text();a=current.index('    /// Rebuild only durable human choices');z=current.index('    pub fn remember(',a);assert current[:a]+current[z:]==(E/'baseline-approval.rs').read_text()
refs=json.loads((E/'owner-references.json').read_text());excerpts=0
for row in refs:
 b=(R/row['snapshot_artifact']).read_bytes() if 'snapshot_artifact' in row else Path(row['path']).read_bytes();assert len(b)==row['bytes'] and H(b)==row['sha256'],row['path']
 for c in row['excerpts']:
  d=(R/c['artifact']).read_bytes();assert H(d)==c['sha256'] and d==b[c['byte_start']:c['byte_end']];excerpts+=1
reuse=json.loads((E/'reused-evidence.json').read_text())
for row in reuse:
 b=(R/row['artifact']).read_bytes();assert len(b)==row['bytes'] and H(b)==row['sha256'] and b==Path(row['path']).read_bytes()
base=E/'reused/.ops/stage1_execution'
for folder,name in [('approval-submenu-integration','targeted-tests'),('approval-submenu-integration','legacy-approval'),('new132-ownership-integration','policy-first')]:
 receipt=json.loads((base/folder/(name+'.run.json')).read_text());d=(base/folder/(name+'.log')).read_bytes();assert receipt['exit_code']==0 and receipt['bytes']==len(d) and receipt['sha256']==H(d)
log=(base/'approval-submenu-integration/targeted-tests.log').read_text();assert '11 passed; 0 failed' in log and '13 passed; 0 failed' in log
legacy=json.loads((base/'approval-submenu-integration/legacy-approval.json').read_text());assert legacy['passed'] and len(legacy['checks'])==14 and all(legacy['checks'].values()) and legacy['request_count']==12
oldlog=(base/'approval-integration/all-tests.log').read_text();section=oldlog.split('Running tests/approval_owner.rs',1)[1].split('Running tests/',1)[0];assert '8 passed; 0 failed' in section
p=base/'new132-ownership-integration';proof=json.loads((p/'policy-first.json').read_text());http=json.loads((p/'policy-first.http.json').read_text());wires=json.loads((p/'policy-first.jsonl.json').read_text());assert proof['status']=='passed' and len(proof['checks'])==6 and all(proof['checks'].values()) and proof['server_errors']==[] and len(http)==proof['request_count']==17 and len(wires)==proof['jsonl_processes']==2 and all(w['returncode']==0 for w in wires)
assert proof['binary_sha256']=='78cf6b9795b5bc6487fd3e3cd280d3f64f84fdcb6a8f1c7a7c4d7b596eceaa6e'
rows=[x for w in wires for x in w['rows']];responses={x.get('id'):x for x in rows if x.get('type')=='response'}
for key in ['busy-provider-new','busy-approval-new']:assert responses[key]['code']=='agent_busy'
for key in ['settled-provider-new','new-after-remembered-allow','new-after-remembered-deny','new-with-process-never']:assert responses[key]['success']
for token in ['WRITE_ALLOW_OLD','WRITE_ALLOW_NEW','WRITE_DENY_OLD','WRITE_DENY_NEW','WRITE_AFTER_RESTART']:
 assert any(x.get('request_id')==token and x.get('event',{}).get('type')=='approval_request' for x in rows)
for token in ['WRITE_ALLOW_SAME','WRITE_DENY_SAME','WRITE_NEVER']:
 assert not any(x.get('request_id')==token and x.get('event',{}).get('type')=='approval_request' for x in rows)
inputs=json.loads((base/'new132-integration/master-final-inputs.json').read_text());assert inputs['src/approval.rs']['sha256']==m['current']['sha256'];core=next(x for x in refs if x['relative_path']=='src/core.rs');assert inputs['src/core.rs']['sha256']==core['sha256']
inv=json.loads((E/'report-inventory.json').read_text());report=R/inv['owned_path'];assert inv['prior_prefix_bytes']==0 and not inv['local_report_existed'] and not inv['main_report_existed'];b=report.read_bytes()
sys.path.insert(0,str(M/'tools'));g=runpy.run_path(str(M/'tools/validate_stage1_blueprint.py'));bp=g['parse']((M/'Docs/stage_1_v3_pi_mono_blueprint.md').read_text());f=bp.files['ZS1-095'];assert f.path==m['frozen']['path'] and f.sha256==m['baseline']['sha256'] and bp.requirement==m['requirement_digest']
for label in ['baseline','current']:g['check_ranges'](all_ranges[label],m[label]['bytes'])
g['artifact'](R,{'path':str(report.relative_to(R)),'bytes':len(b),'sha256':H(b)})
print(json.dumps({'ok':True,'item':'ZS1-095','baseline':m['baseline']['sha256'],'current':m['current']['sha256'],'complete_ranges':all_ranges,'owner_excerpts':excerpts,'original_artifacts_reused':len(reuse),'worker_runtime_runs':0,'historical_owner_tests':8,'historical_targeted_tests':24,'historical_pty_checks':14,'controller_current_round_policy_checks':6,'controller_current_round_http_requests':17,'controller_current_round_jsonl_processes':2,'report_bytes':len(b),'report_sha256':H(b),'limits':'Integrity and source/receipt consistency only. No new runtime run or master/directory acceptance. Configured Deny and bound worker across /new remain unexecuted in the six-case controller fixture.'},indent=2))
