# ZS1-095 / 3.1.20 single target file review

Frozen approval.rs (737 lines, 27606 bytes) and current approval.rs (780 lines, 29396 bytes) are fully read and separately captured. The sole production delta is with_remembered_events. No prior report existed in main or worker; report inventory records this.

Run pure checks from worker root:

    PYTHONDONTWRITEBYTECODE=1 python3 Docs/quality/stage1/ZS1-095/worker-review320/verify_review.py

This checks original and current bytes, contiguous read ranges, exact delta, seven current owner/test mappings plus one frozen later helper context, sixteen reused evidence artifacts, real G-FILE helpers and recorded controller JSONL/HTTP event correspondence. It runs no Cargo, binary, PTY or HTTP fixture.

Historical approval-owner eight tests, targeted twenty-four tests and legacy PTY fourteen checks retain original versions. Controller policy-first is new controller evidence this round: six checks, seventeen HTTP requests, two normal-exit production CLI processes. It does not test configured Deny or a bound worker across /new. The controller extended its helper during review: two failed integrity receipts and original references are retained; later helper snapshot is explicitly not the exact policy-first execution source. No seventh-case result is inferred.

G-STAGE result is retained even when master receipt is absent. File integrity is not semantic acceptance. No product, main, Pi or earlier frozen package was changed.
