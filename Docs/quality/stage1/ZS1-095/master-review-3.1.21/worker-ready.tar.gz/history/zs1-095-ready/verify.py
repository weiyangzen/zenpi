"""Offline integrity + two alternative report patch replays; no product execution."""
from pathlib import Path
import datetime, hashlib, json, subprocess, tempfile

R = Path(__file__).resolve().parent
sha = lambda b: hashlib.sha256(b).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
m = json.loads((R/'manifest.json').read_text())
assert m['item'] == 'ZS1-095' and not m['complete'] and not m['master_accepted'] and not m['product_changes']
actual = {str(p.relative_to(R)) for p in R.rglob('*') if p.is_file() and p != R/'manifest.json'}
assert actual == set(m['artifacts'])
for path, record in m['artifacts'].items():
    rel = Path(path)
    assert not rel.is_absolute() and '..' not in rel.parts
    data = (R/rel).read_bytes()
    assert len(data) == record['bytes'] and sha(data) == record['sha256'],path
g = json.loads((R/'evidence/gfile.json').read_text())
assert not g['semantic_verified_by_checker'] and not g['master_receipt_created']
for name, rec in g['sources'].items():
    data = (R/'evidence'/rec['path']).read_bytes()
    assert len(data) == rec['bytes'] and sha(data) == rec['sha256']
    pos = 0
    for start,end in rec['read_ranges']:
        assert start == pos and start < end <= len(data)
        pos = end
    assert pos == len(data)
    for read in rec['ordered_reads']:
        assert sha(data[read['start_byte']:read['end_byte']]) == read['sha256']
assert g['sources']['baseline']['sha256'] == 'c592686334a95047f749d7c61c793abc03ce93d5312b22aadeefa5aed9c85844'
assert g['sources']['current']['sha256'] == '5488ad365670e515eba5e7d82a91dbf935be854b848c20fd99725f102e1f185f'
prefix = (R/'evidence/before/worker.md').read_bytes()
report = (R/m['report_path']).read_bytes()
assert report.startswith(prefix) and len(prefix) == 3428 and sha(prefix) == g['preserved_prefix_sha256']
assert prefix == (R/'evidence/before/ui.md').read_bytes()
assert prefix.startswith((R/'evidence/before/reference.md').read_bytes())
assert len(report) == g['report_bytes'] and sha(report) == g['report_sha256'] == m['report_sha256']
for rec in json.loads((R/'evidence/context-references.json').read_text())['references']:
    data = (R/'evidence'/rec['excerpt']).read_bytes()
    assert len(data) == rec['bytes'] and sha(data) == rec['sha256']
for attempt in ['', 'gate-attempt1/']:
    root = R/'evidence'/attempt
    receipt = json.loads((root/'gstage.run.json').read_text())
    for stream in ['stdout','stderr']:
        rec = receipt[stream]
        data = (root/rec['path']).read_bytes()
        assert len(data) == rec['bytes'] and sha(data) == rec['sha256']
    stage = json.loads((root/'gstage.stdout.json').read_text())
    assert receipt['exit_code'] == 1 and stage['structural']['ok'] and not stage['ok']
    assert len(stage['errors']) == 1 and 'ZS1-095.master.json' in stage['errors'][0]
receipt = json.loads((R/'evidence/gstage.run.json').read_text())
assert receipt['live_inputs_unchanged_during_checker']
for rec in receipt['live_inputs_before'].values():
    data = (R/'evidence'/rec['copy']).read_bytes()
    assert len(data) == rec['bytes'] and sha(data) == rec['sha256']
operations = []
for scenario, patch_name, before in [('master-absent','candidate.patch',None),('existing-exact-prefix','append-current.patch',prefix)]:
    with tempfile.TemporaryDirectory(prefix='zs1-095-replay-') as raw:
        temp = Path(raw)
        def git(args):
            argv = ['git',*args]
            started = now()
            proc = subprocess.run(argv,cwd=temp,capture_output=True)
            operations.append(dict(scenario=scenario,argv=argv,cwd=raw,started_at=started,ended_at=now(),exit_code=proc.returncode,stdout=proc.stdout.decode(),stderr=proc.stderr.decode(),stdout_sha256=sha(proc.stdout),stderr_sha256=sha(proc.stderr)))
            assert proc.returncode == 0,(args,proc.stdout,proc.stderr)
            return proc.stdout.decode()
        git(['init','--quiet'])
        target = temp/m['report_path']
        if before is not None:
            target.parent.mkdir(parents=True)
            target.write_bytes(before)
        sentinel = temp/'unrelated'
        sentinel.write_bytes(b'unchanged\x00\r\n')
        patch = R/patch_name
        stats = git(['apply','--numstat',str(patch)]).splitlines()
        assert len(stats) == 1 and stats[0].split('\t')[2] == m['report_path']
        for phase, flags in [('forward-check',['--check']),('forward',[]),('reverse-check',['--reverse','--check']),('reverse',['--reverse'])]:
            git(['apply',*flags,str(patch)])
            expected = report if phase in ['forward','reverse-check'] else before
            if expected is None:
                assert not target.exists()
            else:
                assert target.read_bytes() == expected
            assert sentinel.read_bytes() == b'unchanged\x00\r\n'
            operations[-1].update(phase=phase,exact_bytes=True,sentinel_preserved=True)
print(json.dumps(dict(passed=True,manifest_sha256=sha((R/'manifest.json').read_bytes()),artifacts=len(actual),report_sha256=sha(report),report_bytes=len(report),preserved_prefix_sha256=sha(prefix),operations=operations,semantic_acceptance=False,product_executions=0),indent=2))
