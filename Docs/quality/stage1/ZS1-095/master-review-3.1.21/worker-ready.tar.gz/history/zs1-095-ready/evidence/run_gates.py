from pathlib import Path
import datetime, difflib, hashlib, json, re, subprocess, sys

W = Path(__file__).resolve().parent
M = Path('/Users/wangweiyang/GitHub/zenpi')
sha = lambda b: hashlib.sha256(b).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
argv = ['python3', '-B', str(W/'context/tools/validate_stage1_blueprint.py'), '--root', str(M), '--blueprint', 'Docs/stage_1_v3_pi_mono_blueprint.md', '--evidence-root', 'Docs/learn/stage1_pi_mono', '--source-root', '/Users/wangweiyang/GitHub/pi-mono', '--item', 'ZS1-095', '--json']
live_inputs = {}
for rel in ['Docs/stage_1_v3_pi_mono_blueprint.md', 'Docs/execution/active_requirement.json', 'Docs/learn/stage1_pi_mono/source_manifest.tsv', 'Docs/learn/stage1_pi_mono/file_learn_index.tsv']:
    data = (M/rel).read_bytes()
    dest = W/'gstage-live-inputs'/rel
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes(data)
    live_inputs[rel] = dict(bytes=len(data),sha256=sha(data),copy=str(dest.relative_to(W)))
started = now()
p = subprocess.run(argv, cwd=W, capture_output=True)
receipt = dict(argv=argv, cwd=str(W), started_at=started, ended_at=now(), exit_code=p.returncode, environment_overrides={}, python_bytecode_disabled=True, master_root_read_only=True)
receipt['live_inputs_before'] = live_inputs
receipt['live_inputs_unchanged_during_checker'] = all(sha((M/rel).read_bytes()) == rec['sha256'] for rel,rec in live_inputs.items())
assert receipt['live_inputs_unchanged_during_checker']
for name, data in [('stdout', p.stdout), ('stderr', p.stderr)]:
    rel = 'gstage.' + ('stdout.json' if name == 'stdout' else 'stderr.log')
    (W/rel).write_bytes(data)
    receipt[name] = dict(path=rel, bytes=len(data), sha256=sha(data))
(W/'gstage.run.json').write_text(json.dumps(receipt, indent=2)+'\n')
stage = json.loads(p.stdout)
print(json.dumps(stage, indent=2))
assert stage['structural']['ok'] and p.returncode == 1 and not stage['ok']
assert len(stage['errors']) == 1 and 'ZS1-095.master.json' in stage['errors'][0]
sys.dont_write_bytecode = True
sys.path.insert(0, str(W/'context/tools'))
import validate_stage1_blueprint as gate
bp = gate.parse((W/'context/Docs/stage_1_v3_pi_mono_blueprint.md').read_text())
f = bp.files['ZS1-095']
sources = {}
for kind in ['baseline', 'current']:
    data = (W/f'source/{kind}-approval.rs').read_bytes()
    lines = data.splitlines(keepends=True)
    ranges = []
    reads = []
    offset = 0
    for start in range(0, len(lines), 210):
        part = b''.join(lines[start:start+210])
        ranges.append([offset, offset+len(part)])
        reads.append(dict(start_line=start+1, end_line=min(start+210,len(lines)), start_byte=offset, end_byte=offset+len(part), sha256=sha(part)))
        offset += len(part)
    gate.check_ranges(ranges, len(data))
    sources[kind] = dict(path=f'source/{kind}-approval.rs', sha256=sha(data), bytes=len(data), lines=len(lines), read_ranges=ranges, ordered_reads=reads)
assert sources['baseline']['sha256'] == f.sha256 == 'c592686334a95047f749d7c61c793abc03ce93d5312b22aadeefa5aed9c85844'
assert sources['current']['sha256'] == '5488ad365670e515eba5e7d82a91dbf935be854b848c20fd99725f102e1f185f'
base = (W/'source/baseline-approval.rs').read_text().splitlines(True)
current = (W/'source/current-approval.rs').read_text().splitlines(True)
ops = [x for x in difflib.SequenceMatcher(a=base,b=current,autojunk=False).get_opcodes() if x[0] != 'equal']
assert len(ops) == 1 and ops[0][0] == 'insert' and ops[0][4]-ops[0][3] == 43
prefix = (W/'before/worker.md').read_bytes()
assert len(prefix) == 3428 and sha(prefix) == 'e55b4d0ffeb10a792660cee15d84105c83af12231cc913d52457d9772ea1647b'
assert prefix == (W/'before/ui.md').read_bytes() and prefix.startswith((W/'before/reference.md').read_bytes())
refs = json.loads((W/'context-references.json').read_text())['references']
for r in refs:
    part = (W/r['excerpt']).read_bytes()
    assert len(part) == r['bytes'] and sha(part) == r['sha256']
context_drift = sorted({r['source'] for r in refs if sha(Path(r['source']).read_bytes()) != r['source_sha256']})
inputs = json.loads((W/'inputs.json').read_text())['files']
input_drift = [path for path,r in inputs.items() if 'copy' in r and sha(Path(path).read_bytes()) != r['sha256']]
delta = (W/'current-delta.md').read_text()
text = prefix.decode() + delta
assert '### 本轮实际门禁与精确上下文定位' not in text
text += '\n### 本轮实际门禁与精确上下文定位\n\nG-STAGE 实际 exit 1、structural.ok=true，唯一错误是主库缺少 ZS1-095.master.json；没有创建该 receipt，仍为 provisional。G-FILE 辅助范围/hash/精确前缀检查通过，但 semantic_verified_by_checker=false。\n\n'
text += '检查时 current_input_drift=' + json.dumps(input_drift,ensure_ascii=False) + '；current_context_drift=' + json.dumps(context_drift,ensure_ascii=False) + '。若有漂移，正文仅针对冻结摘录；不冒充随后状态。\n\n'
text += '首次 gate-attempt1 原样保留；第二次门禁另存 gstage-live-inputs，运行前后 hash 一致。它使用整合中的当前 authority；正文基线身份仍以首次冻结蓝图的 ZS1-095 行为准，不因其它条目状态变化重写既有基线。\n\n'
text += '| ID | 上下文原文件 | 行（闭合） | 字节（半开） | 文件 SHA256 |\n|---|---|---|---|---|\n'
for r in refs:
    text += f"| {r['id']} | {r['source']} | {r['start_line']}–{r['end_line']} | [{r['start_byte']},{r['end_byte']}) | `{r['source_sha256']}` |\n"
(W/'report.md').write_bytes(text.encode())
symbols = []
for n,line in enumerate(current,1):
    match = re.match(r'^    (?:pub )?fn ([a-zA-Z_][a-zA-Z_0-9]*)',line)
    if match:
        symbols.append([n,match.group(1)])
missing = [x for x in symbols if x[1] not in delta]
assert not missing,missing
(W/'symbol-coverage.json').write_text(json.dumps(dict(note='Auxiliary signature inventory, not semantic verification. All inline test names included. Types/constants separately explained.',symbols=symbols,missing=missing),indent=2)+'\n')
g = dict(item='ZS1-095', learn_mode='understand', source_path=f.path, sources=sources, report_path=f.artifact, report_sha256=sha(text.encode()), report_bytes=len(text.encode()), preserved_prefix_bytes=len(prefix), preserved_prefix_sha256=sha(prefix), current_delta_net_lines=43, diff_opcodes=ops, context_excerpts=len(refs), current_input_drift=input_drift, current_context_drift=context_drift, structural_checks_passed=True, semantic_verified_by_checker=False, master_receipt_created=False, source_tests_run=0, target_tests_run=0)
(W/'gfile.json').write_text(json.dumps(g,indent=2)+'\n')
print(json.dumps(g,indent=2))
