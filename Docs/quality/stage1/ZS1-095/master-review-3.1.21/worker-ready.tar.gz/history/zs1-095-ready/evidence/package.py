from pathlib import Path
import datetime, difflib, hashlib, json, shutil

W = Path(__file__).resolve().parent
R = W.parent/'zs1-095-ready'
M = Path('/Users/wangweiyang/GitHub/zenpi')
assert not R.exists()
sha = lambda b: hashlib.sha256(b).hexdigest()
g = json.loads((W/'gfile.json').read_text())
rel = g['report_path']
report = (W/'report.md').read_bytes()
prefix = (W/'before/worker.md').read_bytes()
assert sha(report) == g['report_sha256'] and report.startswith(prefix)
assert not (M/rel).exists()
assert (W.parent.parent/rel).read_bytes() == prefix
assert sha((M/'src/approval.rs').read_bytes()) == g['sources']['current']['sha256']
prior = json.loads((W/'prior-ready-inventory.json').read_text())
for path,rec in prior['files'].items():
    data = (W.parent.parent/path).read_bytes()
    assert len(data) == rec['bytes'] and sha(data) == rec['sha256'],path
(W/'prior-ready-preservation.json').write_text(json.dumps(dict(checked_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),roots=len(prior['roots']),files=len(prior['files']),all_exact=True,inventory_sha256=sha((W/'prior-ready-inventory.json').read_bytes())),indent=2)+'\n')
dest = R/rel
dest.parent.mkdir(parents=True)
dest.write_bytes(report)
for name,before,fromfile in [('candidate.patch',b'','/dev/null'),('append-current.patch',prefix,'a/'+rel)]:
    patch = ''.join(difflib.unified_diff(before.decode().splitlines(True),report.decode().splitlines(True),fromfile=fromfile,tofile='b/'+rel))
    (R/name).write_text(patch)
for src in sorted(W.rglob('*')):
    if not src.is_file() or src == W/'report.md' or src == W/'verify.py':
        continue
    dest = R/'evidence'/src.relative_to(W)
    dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(src,dest)
shutil.copyfile(W/'verify.py',R/'verify.py')
(R/'README.md').write_text(f'''# ZS1-095 / 3.1.20 approval.rs understand ready

provisional，master独立语义接受pending。仅标准报告 {rel}，{len(report)}字节，SHA256 {sha(report)}。原3428字节完整报告前缀精确保留，旧124历史测试/PTY文字不作为本轮运行成功。

本轮基线27606 bytes/737 lines（c592686334a95047f749d7c61c793abc03ce93d5312b22aadeefa5aed9c85844）与当前29396 bytes/780 lines（5488ad365670e515eba5e7d82a91dbf935be854b848c20fd99725f102e1f185f）各四段全文复读；唯一码差是新增43行with_remembered_events。全部类型/方法/六个内联测试、策略顺序、路径依赖、可见与应答、取消/撤回/持久化、回放边界均有说明。15个hash有界context不扩大其他owner验收，fixture/echo不冒充G-HOST。

两种补丁互斥：主库标准路径当前absent用candidate.patch；已安装精确旧3428字节前缀用append-current.patch。勿顺序重复应用。verify.py在两个独立临时git目录各做正反check/apply、精确字节和sentinel验证；不运行产品或改主库。实际回执在包外zs1-095-work/offline-verification.json。

G-FILE辅助结构通过，semantic_verified_by_checker=false。两次实际G-STAGE都是exit1、structural.ok=true，唯一缺ZS1-095.master.json；未制造receipt。初次之后补存门禁现场输入，第二次运行前后hash一致。两authority文件漂移仅主控ZS1-089从[ ]到[x]及selector snapshot_sha256；095基线/当前源码、15片段均未漂移，第一次回执完整保留。

初始50个ready目录共2850个现存文件逐项hash保全。无产品/Cargo/Node/PTY/HTTP/网络/新任务/subagent，无主库/蓝图/claims/状态和worker标准报告写入。完成交付后停止等待。
''')
m = dict(item='ZS1-095',learn_mode='understand',complete=False,master_accepted=False,product_changes=False,report_path=rel,report_bytes=len(report),report_sha256=sha(report),baseline_sha256=g['sources']['baseline']['sha256'],current_sha256=g['sources']['current']['sha256'],before_master='absent',before_worker_sha256=sha(prefix),prefix_preserved_bytes=len(prefix),source_tests_run=0,target_tests_run=0,cargo_runs=0,node_runs=0,pty_runs=0,http_runs=0,network_runs=0,gstage_exit_code=1,gstage_structural_ok=True,prior_ready_roots=50,prior_ready_files=2850)
m['artifacts'] = {str(p.relative_to(R)):dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in sorted(R.rglob('*')) if p.is_file()}
(R/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
print(json.dumps(dict(ready=str(R),artifacts=len(m['artifacts']),manifest_sha256=sha((R/'manifest.json').read_bytes()),report_sha256=sha(report),report_bytes=len(report),patch_sha256=sha((R/'candidate.patch').read_bytes()),append_patch_sha256=sha((R/'append-current.patch').read_bytes()),README_sha256=sha((R/'README.md').read_bytes())),indent=2))
