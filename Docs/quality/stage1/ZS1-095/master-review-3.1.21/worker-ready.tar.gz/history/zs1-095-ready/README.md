# ZS1-095 / 3.1.20 approval.rs understand ready

provisional，master独立语义接受pending。仅标准报告 Docs/learn/stage1_pi_mono/targets/zenpi/files/src/approval.rs_learn.md，28613字节，SHA256 26e1fed660594ae8fdbf0c5d724c5eb687a1efcbb081ad09f9b295d7ae184f0a。原3428字节完整报告前缀精确保留，旧124历史测试/PTY文字不作为本轮运行成功。

本轮基线27606 bytes/737 lines（c592686334a95047f749d7c61c793abc03ce93d5312b22aadeefa5aed9c85844）与当前29396 bytes/780 lines（5488ad365670e515eba5e7d82a91dbf935be854b848c20fd99725f102e1f185f）各四段全文复读；唯一码差是新增43行with_remembered_events。全部类型/方法/六个内联测试、策略顺序、路径依赖、可见与应答、取消/撤回/持久化、回放边界均有说明。15个hash有界context不扩大其他owner验收，fixture/echo不冒充G-HOST。

两种补丁互斥：主库标准路径当前absent用candidate.patch；已安装精确旧3428字节前缀用append-current.patch。勿顺序重复应用。verify.py在两个独立临时git目录各做正反check/apply、精确字节和sentinel验证；不运行产品或改主库。实际回执在包外zs1-095-work/offline-verification.json。

G-FILE辅助结构通过，semantic_verified_by_checker=false。两次实际G-STAGE都是exit1、structural.ok=true，唯一缺ZS1-095.master.json；未制造receipt。初次之后补存门禁现场输入，第二次运行前后hash一致。两authority文件漂移仅主控ZS1-089从[ ]到[x]及selector snapshot_sha256；095基线/当前源码、15片段均未漂移，第一次回执完整保留。

初始50个ready目录共2850个现存文件逐项hash保全。无产品/Cargo/Node/PTY/HTTP/网络/新任务/subagent，无主库/蓝图/claims/状态和worker标准报告写入。完成交付后停止等待。
