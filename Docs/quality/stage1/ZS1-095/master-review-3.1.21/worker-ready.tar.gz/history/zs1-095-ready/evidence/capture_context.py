from pathlib import Path
import json,hashlib,datetime
W=Path(__file__).resolve().parent
M=Path('/Users/wangweiyang/GitHub/zenpi');S=Path('/Users/wangweiyang/GitHub/pi-mono')
specs=[
 ('C1',M,'src/tools.rs',64,99),
 ('C2',M,'src/tools.rs',575,640),
 ('C3',M,'src/tools.rs',935,999),
 ('C4',M,'src/tools.rs',3026,3055),
 ('C5',M,'src/core.rs',4235,4434),
 ('C6',M,'src/core.rs',4435,4478),
 ('C7',M,'src/core.rs',2605,2720),
 ('C8',M,'src/core.rs',3300,3317),
 ('C9',M,'src/core.rs',1338,1350),
 ('C10',M,'src/core.rs',5195,5212),
 ('C11',M,'src/core.rs',5311,5336),
 ('T1',M,'tests/tui_approval_focus.rs',337,402),
 ('T2',M,'tests/approval_owner.rs',160,203),
 ('T3',M,'tests/approval_owner.rs',1,74),
 ('S1',S,'packages/coding-agent/src/core/extensions/runner.ts',982,1004),
]
refs=[]
for ident,root,rel,start,end in specs:
 p=root/rel;b=p.read_bytes();lines=b.splitlines(keepends=True);assert end<=len(lines)
 lo=sum(map(len,lines[:start-1]));hi=sum(map(len,lines[:end]));part=b[lo:hi]
 name='excerpts/'+ident+'-'+p.name+'.txt';q=W/name;q.parent.mkdir(exist_ok=True);q.write_bytes(part)
 refs.append(dict(id=ident,source=str(p),source_sha256=hashlib.sha256(b).hexdigest(),source_bytes=len(b),start_line=start,end_line=end,start_byte=lo,end_byte=hi,excerpt=name,bytes=len(part),sha256=hashlib.sha256(part).hexdigest(),scope='bounded context only; no whole-file acceptance'))
(W/'context-references.json').write_text(json.dumps({'captured_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'references':refs},indent=2)+'\n')
print(json.dumps(refs,indent=2))
