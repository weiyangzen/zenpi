# ZS1-095 — zenpi src/approval.rs 完整 learn 复核

状态 [_]，worker C 单文件候选。合同 3.1.20 / `8d525b351d066ce9b0487a485337647d47233275782e4f4d154423a623fe1645`。本项只评审审批原语文件；core/TUI/headless/测试仅作明确调用边界，不授予其它文件、目录或产品项验收。写入前在主库与本 worktree 的 Docs/learn 和 .ops 命名清单未找到既有 approval learn 报告，owned path 两处均不存在，因而没有覆盖旧前缀；库存记录见 worker-review320/report-inventory.json。

冻结目标基线为 27606 字节、737 行、SHA `c592686334a95047f749d7c61c793abc03ce93d5312b22aadeefa5aed9c85844`；使用 worker `.ops/extension115-mainimport/previous/src/approval.rs` 的哈希匹配副本，顺序完整读 1–250、251–500、501–737，对应半开范围 `[0,9223)`、`[9223,18955)`、`[18955,27606)`。当前主库为 29396 字节、780 行、SHA `5488ad365670e515eba5e7d82a91dbf935be854b848c20fd99725f102e1f185f`；顺序完整读 1–260、261–520、521–780，对应 `[0,9613)`、`[9613,19694)`、`[19694,29396)`。两套原始快照、片段、manifest 与完整 diff 都保存于 `Docs/quality/stage1/ZS1-095/worker-review320`。差异只有当前 525–566 新增 with_remembered_events；其余生产逻辑及六个内嵌测试保持原字节。下文行号均指当前文件，不能用当前哈希替换合同基线。

## 全文件职责与分支覆盖

### 1–121：策略模式、请求与响应

七个 ApprovalMode 以 snake_case 序列化；默认 Always。枚举注释只是意图，实际自动许可必须按 491–522 的优先级解释：Always 仍允许只读和显式 per_tool Allow，不等于每次都提示；Headless 是一个拒绝无既定许可副作用的策略枚举，不等于所有 headless CLI 都采用此枚举（当前启动 owner 为 Always）。Never 是显式选择不提示的策略，不能取消工具沙箱、side-effect policy 或 Blueprint gate。

ApprovalRequest 包含 request/turn/call/tool、side_effect、object arguments、可选 preview、origin、policy digest 和 lease。validate 逐项拒绝 trim 后空、超过 128 **字节**、含控制字符的四个标识；arguments 必须 object；digest 必须 64 个小写十六进制字符；lease 有相同 128 字节/空白/控制字符约束。BlueprintWorker 必须同时有 digest 和 lease；其它 origin 可以带这些字段。preview 委托 ToolPreview::validate。这里不验证 digest 对应真实策略、不校验 lease 当前活性、不检查 tool 注册/schema、arguments 大小或秘密内容；这些由调用者负责。preview validation 是依赖边界，不宣称完整审查 tools.rs。

ApprovalResponse 只持 request_id、Allow/Deny 与默认 false 的 remember。没有独立 response.validate；respond_with_request 进行 ID 与 pending 关联校验。Serde derive 不是来源认证。请求 arguments 可能含用户内容，本文件没有通用脱敏/凭据过滤，不应把模块文档“without retaining credentials”理解为任意调用者输入已自动清理。

### 123–242：协调器状态与等待

ApprovalCoordinator 的 clone 共享 Arc<Mutex+Condvar> 以及 AtomicU64 cancellation_epoch；new/default 创建空 pending、visible、decisions、accepted。pending/visible/decisions 是按字符串键排序的 BTreeMap，accepted 是 Vec；本文件没有请求数量、总内存或等待总时长上限。50ms 是轮询等待间隔，不是审批超时。Mutex poison 在请求/响应等 fallible API 返回 Invalid，投影查询可能退回空/false/None；不恢复 poisoned state。

request 与 request_response 都进入 request_inner。请求先 validate，再拒绝同 ID 仍在 pending/decisions 的情况，清旧 visible 后登记。循环优先检查 cancelled callback，取消则清该 ID 的四种状态并返回 Cancelled；再检查 decisions，取出完整 response、清 pending/visible/decision。简化 request 还删除 accepted 并立即调用 policy.remember；request_response 保留 accepted 并把 response 返回给 core，后者负责持久化。未收到决定则 condvar wait_timeout 50ms。cancelled 在持锁期间执行，因此它自身不能阻塞或重入同一个 coordinator；该 API 不提供 callback 时限。

重要边界：request_response **不会等待 mark_persisted 才返回**。accepted 留存用于 caller 的后续 journal ACK；“先落盘才执行”不由这个等待循环单独强制。request 简化入口更没有 journal barrier。当前生产 core 使用 request_response→persist_accepted→remember→dispatch，才形成落盘顺序。两个 API 不能不加区分地互换。完成后的 ID 也不是永久防重放集合；新会话 ID 唯一性由 core 请求 ID 构造与 owner 作用域保证，不能从当前三个 map 的重复检查推导全生命周期唯一。

### 244–399：发布、首个响应、审计回执

drain_pending 按 key 顺序返回尚未 visible 的 pending，登记 visible 后后续 drain 不重复；这不是入队 FIFO。reveal 单独校验 ID 并显示一个 pending，不消耗其它请求。respond 代理 respond_with_request；后者原子检查 pending 存在、未有 decision，禁止 BlueprintWorker 的 remember（Allow 与 Deny 都禁止），移除 pending、追加 accepted、保存 decision 并唤醒等待者。首个响应胜出，后续响应 UnknownRequest，不能预存未来 grant。

“Answer one visible request”注释比实现严格：实际只要求 pending，**没有检查 visible**。reveal/drain 是 host 展示管理，不是不可绕过的认证门。is_pending 也只表示仍需回答，并不代表 worker 未完成或已落盘。accepted 返回第一个匹配 ID 的克隆快照；不消费。mark_persisted 删除该 ID 的 accepted，找不到返回 UnknownRequest，通知 condvar；它不写磁盘，也不验证调用者确实持久化。

persist_accepted 先抓 accepted，执行 caller 提供的 FnOnce journal callback，失败时尝试 retract_response（撤回错误被忽略），返回 Persistence；成功后 mark_persisted，可能返回 Approval 错误。callback 不在 coordinator 锁内执行。撤回只适用于尚存在 decisions 的响应：若 request_response 已消费 decision，retract_response 就会 UnknownRequest；可重试 pending 的注释不是所有时序的保证。当前 core 遇持久化错误直接终止该执行链，因此不能把“撤回未重建 pending”误写成已执行工具，也不能声称该原语对任意独立调用方均有严格落盘屏障。未实测的具体竞争时序列入判据，不写通过。

### 401–463：取消与恢复

cancel_all 把当时仍 pending 的请求变为 remember=false 的 Deny，并保留 accepted 供审计，即使尚未 reveal；它不覆盖已从 pending 移除的既有 Allow。emergency_cancel 先增加 SeqCst epoch 再 cancel_all；正在运行的命令是否停止，取决于 core/工具不断比较 epoch 并实施取消。普通 cancel_all 本身不杀进程。新显式 turn 捕获新 epoch，不是把历史 stop 清零。epoch 没有持久化，进程恢复由 session owner 处理。

retract_response 必须成功移除 decisions 才继续清 accepted；仅当 visible 保留该请求时能重新放回 pending。未展示请求或已经被等待线程消费后，不保证可再次展示。wait 的 cancelled 分支会丢掉尚未确认的 accepted，本文件不承诺每个取消都形成 durable denial；正常 host-close cancel_all 与 out-of-band emergency cancel 的记录边界应分开。

### 465–571：决策顺序与记忆恢复

| 顺序/分支 | 精确结果和作用域 | 可复核依据 |
| --- | --- | --- |
| per_tool[tool] == Deny | 所有模式、只读、trusted、worker=true、Never 都先拒绝 | 497–499；内嵌 explicit_deny 测试当前只选三种 mode；owner 测试含 worker explicit_deny |
| WorkerAllowAfterPreflight | 只有传入 true 才 Allow；false 即 Deny，优先于只读与 remembered Allow | 500–506；decide 传 false；worker 无预检内嵌测试 |
| ReadOnly side effect | 在前两项之后 Allow，包括 Always/Headless；不是所有只读无条件允许 | 507–509；headless 默认测试的策略无 Deny 且非 worker |
| 其它 per_tool 决定 | 按精确 tool 名返回，配置 Allow 或人类记忆都存同一表 | 510–512；本表无 path/arguments/origin 的细粒度键 |
| TrustedWorkspace | 精确名称在 trusted_tools 列表才自动 Allow，其它返回 None | 514–518；并非仅由 cwd 或字符串“trusted”推断信任 |
| Headless / Never | 剩余副作用分别 Deny / Allow | 519–520；core side-effect/gate 仍在外层 |
| Always / ReadOnly / PerTool / 未命中 trust | 剩余返回 None，调用者请求显式决定 | 521；None 不是 Deny，也不是执行许可 |

with_remembered_events 从 **self 配置副本** 开始，顺序扫描传入事件。只接收 type=approval_resolved、remember=true、origin=agent_tool/user_shell、合法字符串 tool/三个关联 ID、decision=allow/deny。忽略其它事件、worker、缺字段及坏 decision。tool/ID 的恢复检查用 is_empty 而非 trim.is_empty，纯空格字符串的接收范围比新请求 validate 宽；不进行请求 ID 查找、session membership、digest/lease真实性或历史 record hash 检查。这里依赖 SessionStore 和 host 传来当前会话的可信事件，不能接受 provider 自报事件作为授权。

对配置中本就 Deny 的 tool，所有记忆事件均跳过；检查的是原 self，不是不断变化的 restored，所以无配置 Deny 时，按时间后来的有效人类 Allow/Deny 覆盖较早决定。configured Allow 可被人类记忆 Deny 覆盖。remember 只是直接 insert，不验证名称或阻止覆盖 Deny；“配置拒绝优先”来自 decide 的先拒绝、正确传入原配置以及 core 仅在审批路径中记忆，不能泛化到任意调用者调用 remember。origin 仅用于允许恢复的事件类别，最终表键仍只有 tool；人类 user_shell 用单独 tool 名 `user_shell`，不等于 `run_command` grant。

此 helper 不恢复 mode、trusted_tools、worker binding 或 lease。Never 不通过 approval_resolved 事件重建。worker 自动许可事件 remember=false 且不能升级为跨调用的人类记忆许可。事件总量/回放耗时在这里没有单独 cap；上层 journal 限制不冒充本文件新增限制。

### 573–780：错误类型与全部六个测试

ApprovalError 区分 Invalid、UnknownRequest、Cancelled；PersistApprovalError 区分协调器错误与泛型持久化错误，无自动重试或执行回退。全部六个测试均在完整读范围：explicit_deny_beats_read_only_trust_and_worker_allow、worker_mode_without_preflight_denies_even_remembered_and_readonly_tools、read_only_is_always_allowed_and_headless_denies_side_effects、coordinator_emits_once_and_correlates_response、accepted_response_is_retained_for_durable_ack_and_first_decision_wins、cancel_all_retains_an_unrevealed_denial_for_durable_ack。后三者用线程调用真实 coordinator，但测试轮询本身无统一总超时；本轮未运行。测试先 mark_persisted 再 join 的顺序不能证明 worker 在 mark 前不能返回。六个测试未直接覆盖新增 replay helper，覆盖来自外部 tui_approval_focus 测试和主控实际场景。

## 当前 owner 与 /new 的边界

owner-references.json 保存八个只读文件的整文件哈希及 20 个实际阅读片段；不宣称完整审查八个文件。当前 core SHA `52311b129c0bb467abac36de216f5bc97bf3c4c42d03dcd6170a717339c2a869`，与主控 new132 的 master-final-inputs 对齐；当前 approval SHA 也匹配该输入清单。旧 approval 集成的 core 哈希不同，旧测试不可变成当前整树回归通过。

core:1247/1270 设置工具时先创建独立 coordinator，默认策略应用当前 session events；1340–1344 set_approval_policy 同时保存原配置与加当前记忆的运行策略。调用者必须传配置基底，若误把已混入记忆的运行表当新配置，记忆也会被“配置化”；当前 /approval 和 /yolo 使用 configured_approval_policy，避开这一点。

core:4250–4305 在审批前检查 binding、真实 call gate 与 side-effect policy；worker_preflight 来自匹配 gate/binding，源 arguments 不能直接置位。approval.rs 的 public bool API 本身不验证来源，可信 host 边界不可省略。core:4344–4391 等待显式决定，先 append approval_resolved/persist，再记忆；4392 后 append consumed 并判断 Deny；4412 自动 worker Allow 留非记忆审计。等待后再检查取消与 binding，后续工具路径继续负责沙箱和 gate。approval Allow 仅是多个必要条件之一。

core:2600–2710 的 user_shell 明确拒绝 worker binding/origin 借用，检查命令 gate 和 side-effect policy，使用独立 `user_shell` 名审批，先 journal 再记忆和执行，再检查取消与 gate。这里不以 provider 的 run_command 参数替代用户 shell 的授权。

当前 new_session_with_commit:5033–5122 要求 Idle、无待队列/未知结果/待恢复操作/附件，准备 fresh journal 只保存模型/persona 等新会话状态；不复制旧 approval_resolved。replace_session_with_commit:5166–5236 在准备 governance/resources/model/extensions、检查取消与 commit 成功后才切换 owner/session；5203–5206 用 **原 configured_approval_policy + 新 self.session.events()** 重建，而非沿用旧 runtime.approval_policy。因此同 owner /new 后配置 Deny 和 process mode 从代码路径保持，旧会话人类记忆消失；恢复旧 journal 则重新应用其人类记忆。准备/commit 失败在这段代码之前，不改变 live policy。coordinator 与 worker binding 没在这段替换中重新创建，真实安全性还依赖 busy/settled guard 和每次 gate 活性验证，不推断所有并发场景。

Never 的“process-only”指当前 host 工作流：TUI:7374–7417 与 headless:7140–7200 的显式命令修改 live 配置 policy；恢复 helper 不解析 mode。core:6104 启动重新选 headless Always/TUI ReadOnly。ApprovalPolicy/ProjectTabMetadata 可序列化不等于本文件技术上禁止外部持久化 Never；TUI metadata/项目切换另有 owner。因此实测结论限定下述 CLI 进程、配置与二进制，不泛化为所有嵌入方式或所有项目路径。配置 Deny 指 host 的 per_tool 配置基底，不能臆造 config.toml 已暴露同名设置。

## 证据来源、已证实范围与剩余判据

本 worker 没有运行 Cargo、PTY、新 HTTP、Bun、工具执行或产品二进制；仅完整阅读、复制原始证据和纯文件完整性校验。不要将下列历史收据和主控新执行合计成“本 worker 新测试数”。reused-evidence.json 对每个原始文件和副本绑定字节/SHA，未修改原路径。

| 证据 | 实际覆盖 | 限制 |
| --- | --- | --- |
| 历史 approval-integration/all-tests.log 与 master-verification | approval_owner 八例通过：真实 coordinator + mock Completion backend、真实 tempfile 工具副作用/拒绝、worker gate 匹配/撤销/缺失/配置 Deny、session ID 分离、Unix emergency cancel；原全套结果仅作原文保存 | 不是网络 provider；不是 /new；不把全套 782 项都算 approval 覆盖；未重跑 |
| 历史 2026-09-12 06:38 UTC targeted-tests.run.json/log | 11 个 tui_approval_focus + 13 个 palette 通过；恢复测试为手工写事件的 SessionStore + Echo，resume 两个 journal 验证记忆 Deny 不外溢、配置 Deny 保留；坏/worker事件不提升许可 | Echo 与构造事件不是实际人类按键/工具调用；不证明 /new 或 process Never 重启 |
| 历史 06:41 UTC legacy-approval.run/json/log | 固定二进制 b32c8b13…，14 checks、12 HTTP 请求：实际生产 PTY 允许写、拒绝不写、错误项目、取消、顺序审批、未完成审批重启不自动执行、记忆 Deny 独立重启仍拒绝 | `audit_precedes_tool_result` 实际断言 journal audit 早于 tool result，不是观测 OS 写入前的瞬间；不声称该脚本覆盖记忆 Allow 的独立重启或 /new |
| 本轮主控 09:05:36 UTC policy-first.run.json/json/http/jsonl/log | 固定二进制 `78cf6b9795b5bc6487fd3e3cd280d3f64f84fdcb6a8f1c7a7c4d7b596eceaa6e`；exit 0、六组检查、17 实际 loopback Responses HTTP 请求、两个生产 JSONL CLI 进程都正常退出 | worker 未复跑。完整读 policy_smoke:623–811；固定 write_file/同项目场景，非 PTY、非真实远程模型、无 configured Deny/bound worker 场景 |

主控六组原始代码/记录具体证明：真实 provider 被 held 时 /new 返回 agent_busy，原请求保留且结束后可切换；真实 write_file 在审批等待时 /new 同样被拒绝，原审批仍能 Allow 并完成。旧 session remember Allow 后同会话可自动写，新 session 必须重新审批；旧 remember Deny 后同会话自动拒绝，新 session 可收到并接受新的决定。`/approval never` 跨同进程 /new 保留自动许可，且新 journal 无 remembered grant；独立 CLI 重启恢复同一个新 session 后 write_file 再次要求审批，Deny 后文件仍不存在。源码判据与 HTTP/JSONL 副本均可核对，不能把“文件存在/不存在”扩大成无任何其它副作用证明。

尚未被这些场景实际覆盖、留给各 owner 的具体判据：

1. 配置 per_tool Deny 跨成功 /new、失败 commit、独立重启后的真实命令/写入矩阵；当前只读路径支持 /new 保留配置，但六组没有配置该表，不写已实测。
2. 真正绑定 worker 的 live/missing/expired/revoked/mismatched gate 跨 /new；原 owner 测试证明单次 gate 约束，不证明跨会话全组合；worker 工具记忆请求被拒绝与 human 记忆不能绕过 worker 预检仍需按真实 host 路径评估。
3. replay 正/反覆盖最后有效人类事件胜出、configured Allow→remembered Deny、未知 type/origin/decision、空白/控制符/超长/缺 ID、user_shell 独立命名；此处给明确分支判据，不以 Python 重写政策充当 Rust 行为证明。
4. coordinator 未 reveal 的 pending 回答、取消与 Allow 竞争、request_response 返回早于 ACK、持久化失败发生在消费前/后、重复 ID 与 retained accepted、Mutex poison。任何未来行为测试应验证实际 core 不执行副作用，且分别记录可重试 pending 是否恢复；现有注释不算场景通过。
5. 回调永不返回、巨大 pending/事件集合、进程恢复与非 Unix 取消不在本文件现有统一 deadline/cap 保证内；不能拿 50ms wait 或 Unix 一例当全平台证明。

这些是本文件完整学习的准确边界，不是本候选新增产品工作或新的目录验收。布局、键位、渲染、协议适配、provider 请求、session 格式以及 tool sandbox 实现均 context-only；审批原语本身不拥有它们，不能遗漏职责分界也不能顺带打勾。

## 纯校验与交付

在本 worker 根运行 `PYTHONDONTWRITEBYTECODE=1 python3 Docs/quality/stage1/ZS1-095/worker-review320/verify_review.py`，仅检查冻结基线/当前文件、完整范围、差异、副本与原日志、owner 片段、主控六组原始 JSONL/HTTP 基本对应及真实 G-FILE helper。它不执行 Rust/CLI/HTTP；哈希漂移会失败，要求复核，不能自动升级成通过。G-STAGE 主仓只读结果另存，缺 master receipt 仍保留失败。ready 包执行 git apply --check、正向逐字节与反向恢复校验；仅交付本报告与必要证据，不修改主库/产品/任何旧 frozen 包，不产生 [x]。

冻结前校验补记：integrity-final 与 integrity-reviewed 两次真实 exit 1，原因是主控在同时扩展 policy_smoke，helper 原路径整文件哈希已变化。原 refs/片段/失败收据全部保留。第一次读到的 623–811 是六组版本，但抓片段时主控已开始加入 TUI 第七组，故初次保存片段并非 policy-first 的精确运行脚本。随后完整读当时 623–849，并以 helper-later-context.py / helper-later-policy-623-849.txt 保存较晚只读上下文及差异；校验该冻结上下文，不追随主控可变脚本。当前报告只采用原 policy-first 六组的固定二进制、原始 HTTP/JSONL/exit 收据，不能以较晚 helper 证明第七组通过或声称精确保存了原运行源码。七个生产/测试 owner 仍校验当前主库哈希，helper 单独限定为后续上下文。最终完整性收据使用 integrity-frozen。
