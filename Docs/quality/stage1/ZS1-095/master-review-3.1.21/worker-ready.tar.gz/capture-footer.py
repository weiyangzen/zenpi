from pathlib import Path
import json,hashlib,datetime
w=Path(__file__).resolve().parent
rows=[]
for origin,rel in [('/Users/wangweiyang/GitHub/zenpi/src/tui.rs','delta/tui-footer.rs'),('/Users/wangweiyang/GitHub/zenpi/.ops/stage1_execution/tui-approval-timer-integration-3.1.21/root-footer-increment.patch','delta/root-footer-increment.patch')]:
 data=Path(origin).read_bytes(); target=w/rel; assert not target.exists(); target.write_bytes(data); rows.append({'origin':origin,'path':rel,'bytes':len(data),'lines':len(data.splitlines()),'sha256':hashlib.sha256(data).hexdigest()})
assert rows[0]['sha256']=='e45131dcf190d55068e369e55b8a3cc0dda18234ccee2c2ca335c9cefdd15904'
(w/'delta/footer-identity.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':rows},indent=2)+'\n'); print(json.dumps(rows,indent=2))
