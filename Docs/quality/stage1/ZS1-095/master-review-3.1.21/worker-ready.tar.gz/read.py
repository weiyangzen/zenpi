from pathlib import Path
import hashlib,json,sys
WORK=Path(__file__).resolve().parent;source=WORK/sys.argv[1];lo,hi=map(int,sys.argv[2:4]);data=source.read_bytes();lines=data.splitlines(keepends=True);assert 1<=lo<=hi<=len(lines)
start=sum(map(len,lines[:lo-1]));end=sum(map(len,lines[:hi]));chunk=data[start:end];assert len(chunk)<=256*1024
index=WORK/'read-binding.json';rows=json.loads(index.read_text()) if index.exists() else [];(WORK/'reads').mkdir(exist_ok=True);path=WORK/'reads'/('%03d.txt'%(len(rows)+1));assert not path.exists();path.write_bytes(chunk)
rows.append({'source':str(source.relative_to(WORK)),'source_bytes':len(data),'source_sha256':hashlib.sha256(data).hexdigest(),'lines':[lo,hi],'byte_range':[start,end],'path':str(path.relative_to(WORK)),'bytes':len(chunk),'sha256':hashlib.sha256(chunk).hexdigest()});index.write_text(json.dumps(rows,indent=2)+'\n')
for number,line in enumerate(chunk.decode().splitlines(),lo):print('%d: %s'%(number,line))
