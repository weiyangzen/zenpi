# ZS1-095 new portable offline auditor; never executes product or historical scripts.
from pathlib import Path
import hashlib,json,re,stat,subprocess,tempfile,sys,traceback
PACKAGE=Path(__file__).resolve().parent
RESULTS=[]
def record(label,passed):
 RESULTS.append({'label':label,'passed':bool(passed)})
def identity(path):
 data=path.read_bytes();return {'bytes':len(data),'lines':len(data.splitlines()),'sha256':hashlib.sha256(data).hexdigest()}
def inventory(root):
 return {str(path.relative_to(root)):identity(path) for path in sorted(root.rglob('*')) if path.is_file() and not path.is_symlink()}
def document(name):
 return json.loads((PACKAGE/name).read_text())
def audit():
 manifest_data=document('manifest.json')
 initial_inventory=inventory(PACKAGE);manifest_identity=initial_inventory.pop('manifest.json')
 record('manifest exact payload',initial_inventory==manifest_data['files'])
 record('no writable files or symlinks',all(not path.is_symlink() and not(path.stat().st_mode & 0o222) for path in [PACKAGE]+list(PACKAGE.rglob('*'))))
 capture_data=document('capture.json');summary_data=document('analysis-summary.json')
 subject_name='capture/zenpi/src/approval.rs';subject_path=PACKAGE/subject_name;source_data=subject_path.read_bytes();source_lines=source_data.splitlines(keepends=True)
 record('formal29396B780Lexact',identity(subject_path)=={'bytes':29396,'lines':780,'sha256':'5488ad365670e515eba5e7d82a91dbf935be854b848c20fd99725f102e1f185f'})
 for capture_row in capture_data['files']:
  record('capture '+capture_row['path'],identity(PACKAGE/capture_row['path'])=={key:capture_row[key] for key in ['bytes','lines','sha256']})
 for delta_name in ['delta/identity.json','delta/footer-identity.json']:
  for delta_row in document(delta_name)['files']:
   record('delta '+delta_row['path'],identity(PACKAGE/delta_row['path'])=={key:delta_row[key] for key in ['bytes','lines','sha256']})
 baseline_row=document('delta/identity.json')['baseline']
 record('baseline separate and delta43L1790B',identity(PACKAGE/baseline_row['path'])=={key:baseline_row[key] for key in ['bytes','lines','sha256']} and baseline_row['sha256']=='c592686334a95047f749d7c61c793abc03ce93d5312b22aadeefa5aed9c85844' and document('delta/identity.json')['approval_delta']=={'bytes':1790,'lines':43})
 read_rows=document('read-binding.json');formal_rows=[row for row in read_rows if row['source']==subject_name]
 record('four contiguous formal reads',len(formal_rows)==4 and formal_rows[0]['byte_range'][0]==0 and formal_rows[-1]['byte_range'][1]==len(source_data) and all(left['byte_range'][1]==right['byte_range'][0] for left,right in zip(formal_rows,formal_rows[1:])))
 record('all47readrecords',len(read_rows)==47 and summary_data['all_read_records']==47)
 for read_row in read_rows:
  path=PACKAGE/read_row['source'];data=path.read_bytes();all_lines=data.splitlines(keepends=True);lo,hi=read_row['lines'];start=sum(map(len,all_lines[:lo-1]));end=sum(map(len,all_lines[:hi]));chunk=(PACKAGE/read_row['path']).read_bytes()
  record('read '+read_row['path'],1<=lo<=hi<=len(all_lines) and read_row['source_bytes']==len(data) and read_row['source_sha256']==hashlib.sha256(data).hexdigest() and read_row['byte_range']==[start,end] and chunk==data[start:end] and len(chunk)==read_row['bytes']<=256*1024 and hashlib.sha256(chunk).hexdigest()==read_row['sha256'])
 units=document('semantic-units.json');maps=document('operation-maps.json');map_ids={row['id'] for row in maps}
 record('31continuousunits',len(units)==31 and units[0]['byte_range'][0]==0 and units[-1]['byte_range'][1]==len(source_data) and all(left['byte_range'][1]==right['byte_range'][0] for left,right in zip(units,units[1:])))
 record('16maps',len(map_ids)==16 and all(all(row.get(key) for key in ['source','target','owners','criterion']) for row in maps))
 for unit_row in units:
  lo,hi=unit_row['lines'];chunk=b''.join(source_lines[lo-1:hi]);start=sum(map(len,source_lines[:lo-1]));record('unit '+unit_row['id'],unit_row['byte_range']==[start,start+len(chunk)] and len(chunk)==unit_row['bytes'] and hashlib.sha256(chunk).hexdigest()==unit_row['sha256'] and unit_row['map'] in map_ids)
 function_rows=document('function-bindings.json');found_functions=[]
 for number,line in enumerate(source_lines,1):
  function_match=re.search(rb'\bfn\s+(\w+)',line)
  if function_match is not None:found_functions.append((number,function_match.group(1).decode()))
 record('29allfnincludinggeneric',len(found_functions)==29 and found_functions==[(row['lines'][0],row['name']) for row in function_rows] and any(row['name']=='persist_accepted' and row['lines'][0]==370 for row in function_rows))
 record('23production6sourcetests',sum(row['kind']=='production' for row in function_rows)==23 and sum(row['kind']=='source-test' for row in function_rows)==6)
 for function_row in function_rows:
  lo,hi=function_row['lines'];chunk=b''.join(source_lines[lo-1:hi]);opening=source_lines[lo-1];indent=opening[:len(opening)-len(opening.lstrip())];actual_end=next(number for number in range(lo+1,len(source_lines)+1) if source_lines[number-1].rstrip()==indent+b'}')
  record('function '+str(lo)+' '+function_row['name'],hi==actual_end and len(chunk)==function_row['bytes'] and hashlib.sha256(chunk).hexdigest()==function_row['sha256'] and any(unit['id']==function_row['unit'] and unit['lines'][0]<=lo<=unit['lines'][1] and unit['map']==function_row['map'] for unit in units))
 tests=document('source-tests.json');record('6tests14assert0snapnoneexecuted',len(tests)==6 and sum(row['ordinary_assert_sites'] for row in tests)==14 and sum(row['snapshot_sites'] for row in tests)==0 and all(not row['executed'] for row in tests))
 for test_row in tests:
  lo,hi=test_row['lines'];chunk=b''.join(source_lines[lo-1:hi]);record('test '+test_row['id'],hashlib.sha256(chunk).hexdigest()==test_row['sha256'] and len(re.findall(rb'\bassert(?:_eq|_ne)?!',chunk))==test_row['ordinary_assert_sites'])
 for historic in document('external-preservation-before.json'):
  record('complete history '+historic['path'],inventory(PACKAGE/historic['path'])==historic['files'])
 reuse=document('reference-reuse.json');record('303reuseidentitynorecount',reuse['source']==identity(PACKAGE/'capture/codex/codex-rs/tui/src/bottom_pane/approval_overlay.rs') and reuse['manifest']==identity(PACKAGE/'history/reference303-manifest.json') and reuse['report']==identity(PACKAGE/'history/reference303-report.md') and reuse['previous_full_read_chunks']==7 and reuse['previous_chunks_exact'] and not reuse['formal095_credit'] and not reuse['new_runtime_execution'])
 preserve=document('preservation-after.json');record('103ready30100regular145tracked265external preserved',preserve['old_ready_count']==103 and preserve['old_regular_count']==30100 and preserve['tracked_count']==145 and preserve['external_regular_count']==265 and not preserve['differences'])
 record('formal source unchanged at freeze',document('freeze-origin-identities.json')['formal_source_unchanged'])
 record('preparation failures retained',(PACKAGE/'preparation-footer-read-failure.log').is_file() and (PACKAGE/'preparation-build-v1/failure.log').is_file() and (PACKAGE/'preparation-build-v1/build.py').read_bytes()==(PACKAGE/'build.py').read_bytes())
 record('runtime zero',summary_data['runtime_executions']==0)
 report_name=capture_data['report'];report_path=PACKAGE/'files'/report_name
 record('single owned report',set(inventory(PACKAGE/'files'))=={report_name} and manifest_data['owned_paths']==[report_name] and identity(report_path)==summary_data['report'] and not capture_data['report_original_exists'])
 record('patch identities bound',all(identity(PACKAGE/name)==summary_data[key] for name,key in [('report.patch','patch'),('rollback.patch','rollback')]) and (PACKAGE/'report.patch').stat().st_size<=256*1024)
 with tempfile.TemporaryDirectory(prefix='zs1095-offline-') as temp_dir:
  scratch=Path(temp_dir);sentinel=scratch/'unrelated.txt';sentinel.write_bytes(b'preserved\n')
  for patch_name in ['report.patch','rollback.patch']:
   outcome=subprocess.run(['git','apply','--no-index','--whitespace=nowarn',str(PACKAGE/patch_name)],cwd=scratch,capture_output=True,text=True)
   record('temporary apply '+patch_name,outcome.returncode==0)
   if outcome.returncode:RESULTS.append({'label':'raw patch failure','passed':False,'stdout':outcome.stdout,'stderr':outcome.stderr})
   if patch_name=='report.patch':record('forward exact owned report',(scratch/report_name).is_file() and (scratch/report_name).read_bytes()==report_path.read_bytes())
   else:record('rollback only owned report removed',not(scratch/report_name).exists() and inventory(scratch)=={'unrelated.txt':identity(sentinel)})
   record('sentinel '+patch_name,sentinel.read_bytes()==b'preserved\n')
 # This binding is never assigned to a regex result, loop variable or walrus target.
 record('post-audit package exact',inventory(PACKAGE)=={**manifest_data['files'],'manifest.json':manifest_identity})
try:
 audit()
except Exception as error:
 RESULTS.append({'label':'auditor exception','passed':False,'error':str(error),'traceback':traceback.format_exc()})
for result_row in RESULTS:print(json.dumps(result_row,ensure_ascii=False))
failures=sum(not row['passed'] for row in RESULTS)
print(json.dumps({'checks':len(RESULTS),'failed':failures,'structural_only':True,'runtime_execution':False}))
sys.exit(1 if failures else 0)
