from pathlib import Path
import hashlib,json,shutil,datetime,difflib
w=Path(__file__).resolve().parent
pairs=[('/Users/wangweiyang/GitHub/zenpi/src/tui.rs','delta/tui.rs'),('/Users/wangweiyang/GitHub/zenpi/.ops/stage1_execution/tui-approval-timer-integration-3.1.21/root-candidate.patch','delta/root-candidate.patch')]
rows=[]
for origin,rel in pairs:
 p=Path(origin); d=p.read_bytes(); q=w/rel; q.parent.mkdir(exist_ok=True); assert not q.exists(); q.write_bytes(d); rows.append({'origin':origin,'path':rel,'bytes':len(d),'lines':len(d.splitlines()),'sha256':hashlib.sha256(d).hexdigest()})
assert rows[0]['sha256']=='9deac1fe3e76331c24bbf1b968bdcdc99adfa7f67c68ace7e49edae7b6d9e09e'
base=w/'history/zs1-095-ready/evidence/source/baseline-approval.rs'; old=base.read_bytes(); new=(w/'capture/zenpi/src/approval.rs').read_bytes(); assert hashlib.sha256(old).hexdigest()=='c592686334a95047f749d7c61c793abc03ce93d5312b22aadeefa5aed9c85844'
diff=''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='baseline/src/approval.rs',tofile='current/src/approval.rs'))
(w/'delta/baseline-to-current.diff').write_text(diff)
(w/'delta/identity.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':rows,'baseline':{'path':str(base.relative_to(w)),'bytes':len(old),'lines':len(old.splitlines()),'sha256':hashlib.sha256(old).hexdigest()},'approval_delta':{'bytes':len(new)-len(old),'lines':len(new.splitlines())-len(old.splitlines())}},indent=2)+'\n')
print(json.dumps(rows,indent=2)); print(diff)
