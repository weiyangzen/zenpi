from pathlib import Path
import datetime,hashlib,json,shutil,stat,subprocess
W=Path(__file__).resolve().parent;ROOT=W.parent.parent;MAIN=Path('/Users/wangweiyang/GitHub/zenpi');CODEX=Path('/Users/wangweiyang/GitHub/codex');REPORT='Docs/learn/stage1_pi_mono/targets/zenpi/files/src/approval.rs_learn.md'
def identity(path):
 assert stat.S_ISREG(path.lstat().st_mode)
 data=path.read_bytes();return {'bytes':len(data),'lines':len(data.splitlines()),'sha256':hashlib.sha256(data).hexdigest()}
def inventory(root):return {str(path.relative_to(root)):identity(path) for path in sorted(root.rglob('*')) if path.is_file() and not path.is_symlink()}
def save(name,data):(W/name).write_text(json.dumps(data,indent=2)+'\n')
roots=sorted(path for path in (ROOT/'.ops').glob('*-ready') if path.is_dir())+[ROOT/'.ops/stage125-render-review320/ready',ROOT/'.ops/stage126-independent320/ready',ROOT/'.ops/stage126-independent320/ready-final']
tracked={str(ROOT/path.decode()):identity(ROOT/path.decode()) for path in subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).split(b'\0') if path and (ROOT/path.decode()).is_file()}
before={'ready':{str(path):inventory(path) for path in roots},'tracked':tracked};save('preservation-before.json',before)
selected={'zenpi':['src/approval.rs','src/core.rs','src/tui.rs','src/headless.rs','src/slash.rs','tests/tui_approval_focus.rs','tests/approval_owner.rs','Docs/stage_1_v3_pi_mono_blueprint.md','Docs/execution/active_requirement.json','Docs/learn/stage1_pi_mono/targets/zenpi/source_manifest.tsv','Docs/learn/stage1_pi_mono/targets/zenpi/file_learn_index.tsv'],'codex':['codex-rs/tui/src/bottom_pane/approval_overlay.rs']}
files=[];issues=[{'operation':'Initial broad authority rg','result':'Output truncated; no full-reading credit, selected rows read separately later.'}]
for tag,paths in selected.items():
 for rel in paths:
  src={'zenpi':MAIN,'codex':CODEX}[tag]/rel
  if not src.is_file():issues.append({'operation':'Optional capture locator','path':str(src),'result':'Absent'});continue
  dst=W/'capture'/tag/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);assert identity(src)==identity(dst);files.append({'path':str(dst.relative_to(W)),'origin':str(src),'role':'subject-full' if tag=='zenpi' and rel=='src/approval.rs' else 'context-only',**identity(dst)})
external=[]
for src in [ROOT/'.ops/target095-review320-ready',Path('/Users/wangweiyang/.codex/worktrees/2267/zenpi/.ops/zs1-095-ready')]:
 dst=W/'history'/src.name;shutil.copytree(src,dst);old=inventory(src);assert inventory(dst)==old;external.append({'origin':str(src),'path':str(dst.relative_to(W)),'files':old})
# Preserve inherited working report without editing it; it is not the main patch base.
for src,name in [(ROOT/REPORT,'inherited-worker-report.md'),(ROOT/'.ops/reference303-approval321-ready/manifest.json','reference303-manifest.json'),(ROOT/'.ops/reference303-approval321-ready/files/Docs/learn/stage1_pi_mono/references/codex/files/codex-rs/tui/src/bottom_pane/approval_overlay.rs_learn.md','reference303-report.md')]:
 dst=W/'history'/name;shutil.copyfile(src,dst);files.append({'path':str(dst.relative_to(W)),'origin':str(src),'role':'history-identity',**identity(dst)})
save('external-preservation-before.json',external);save('preparation-issues.json',issues)
subject=next(row for row in files if row['role']=='subject-full');save('capture.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'item':'ZS1-095','version':'3.1.21','report':REPORT,'report_original_exists':(MAIN/REPORT).exists(),'files':files,'old_ready':len(roots),'old_regular':sum(map(len,before['ready'].values())),'tracked':len(tracked)})
print(json.dumps({'subject':subject,'captures':len(files),'old_ready':len(roots),'old_regular':sum(map(len,before['ready'].values())),'tracked':len(tracked),'historical_files':[len(entry['files']) for entry in external],'main_report_exists':(MAIN/REPORT).exists(),'issues':issues},indent=2))
