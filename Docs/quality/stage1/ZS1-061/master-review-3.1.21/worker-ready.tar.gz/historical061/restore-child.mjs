import {readFile} from 'node:fs/promises';
import {Agent} from './source/packages/agent/src/agent.ts';
import {getDefaultStreamFn} from './source/packages/agent/src/stream-fn.ts';
import {buildSessionContext} from './source/packages/agent/src/harness/session/context.ts';
import {BACKGROUND_CONTEXT} from './source/packages/agent/src/harness/context.ts';
import {convertToLlm} from './source/packages/agent/src/harness/messages.ts';
import {model,assistant,scriptedStream} from './fixture-helpers.mjs';
const input=JSON.parse(await readFile(process.argv[2],'utf8'));
const projected=await buildSessionContext(input.entries,undefined,BACKGROUND_CONTEXT);
const requests=[],events=[];let defaultAvailable=true;
try{getDefaultStreamFn();}catch{defaultAvailable=false;}
const agent=new Agent({initialState:{model,messages:projected},streamFn:scriptedStream([assistant([{type:'text',text:'CHILD_REPLY'}])],requests),...(input.mode==='explicit'?{convertToLlm}:{})});
const initiallyQueued=agent.hasQueuedMessages();agent.subscribe(e=>events.push(e));
await agent.continue();await agent.waitForIdle();
console.log(JSON.stringify({pid:process.pid,projected,requests,events,defaultAvailable,initiallyQueued,streaming:agent.state.isStreaming,pendingTools:agent.state.pendingToolCalls.size}));

