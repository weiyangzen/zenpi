# ZS1-061 — packages/agent

Provisional [_]. Authority 3.1.18 / cb96a3db9b57ea0d9d3ad43f0be954129aabf69bc5d438210a14b674a4a8af85. The only frozen direct children are src057 and test058, both pending. There is no in-scope direct file. directory-scope.json lists the real package files and other directories, including README/CHANGELOG/package/build/test configs and benchmark/docs/scripts, as context-only.

## Package entry points and actual child integration

The reviewed package.json exports compiled dist entries for the root, node, harness/context, session and selected helpers. Build uses tsgo; ordinary test and harness-test scripts have different discovery scopes. README shows Agent receiving an explicit model stream function. The original public index.ts exports Agent, loop and harness APIs, but merely exporting them does not make standalone Agent automatically compact or persist history.

Our child-directory evidence resolves a narrow unchanged source closure. It does not initialize every root barrel export, build dist, publish npm artifacts, execute the broad package test command or accept unrelated direct files. The original package/config/barrel files are retained for this distinction.

057 establishes actual Agent/loop queue and caller-preparation behavior;058 preserves the exact original23-test execution and its assertion limits, with collection-only verification. Their runs are referenced, not repeated. At package level the missing connection is host ownership of checkpoint representation, provider conversion and process-local state.

## Three new real subprocess checks

Each test writes a caller-owned JSON fixture in a real temporary directory, starts a different Node process, reads that file there, and executes unchanged session projection, Agent and loop code. The child uses native TypeScript stripping and an explicit alias loader forwarding to real source functions. Raw child stdout/stderr, PID, arguments, input and outputs are captured. The file remains byte-identical after the run.

D061-01 restores older ancestry plus a latest checkpoint and later input. Projection produces summary, eligible retained tail and later user input, excluding old ancestry and an aborted retained assistant. With the actual harness converter supplied to Agent, one scripted provider request contains the checkpoint summary. Continuation emits only the new assistant message, then settles idle with no pending tools.

D061-02 uses the same projection with Agent's default converter. The compactionSummary role is omitted from the request while tail and later input remain. A stored/projected checkpoint therefore does not establish that a provider consumed its summary: the host must connect the appropriate converter.

D061-03 registers a parent-process default stream and enqueues parent steering. The fresh child has neither that stream registration nor that queued input. Only the caller's serialized entries are restored, and parent queue state remains intact. This demonstrates process-local state ownership; it does not claim the fixture format ought to contain queue state or implement automatic queue persistence.

All three pass with real Vitest4.1.9 and Node24.19.0. Child replies are scripted through the real event stream; there is no network model. This is actual independent-process reconstruction from a caller-owned file, not upstream JSONL session-store recovery, crash/power-loss proof, journal integrity validation or durable admission replay.

## Exceptions, cancellation and closure

The new subprocess tests cover normal reconstruction and two negative integration boundaries. Active cancellation is supplied by057's separate real signal/summary tests and010/011's historical tool-owner evidence; none is rerun or relabeled as a package-level kill/reap test.058 documents what original014 does and does not assert.

Zenpi's lifecycle owner must explicitly persist admission identity, checkpoint provenance and pending state, then restore the converter/context used by the selected backend. Source Agent public history and a prepared provider context can diverge; a hash or restored object alone cannot prove summary use. Existing target runtime/core/context/session owners must validate those contracts independently.

Root-to-leaf closure is061→057(010,011,054→050/051) and061→058(014). All in-scope immediate children are linked; context-only benchmark/docs/scripts and extra source/test branches add no accepted count. Master acceptance remains pending for the dependencies and this directory. No product, master checkout, ledger, skill or old frozen package was changed.

