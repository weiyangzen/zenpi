export async function resolve(specifier,context,nextResolve) {
 const aliases={
  '@earendil-works/pi-ai':'./pi-ai-runtime.mjs',
  '@earendil-works/chord/context':'./source/packages/chord/src/context/index.ts',
  '@earendil-works/pi-telemetry':'./source/packages/telemetry/src/index.ts'
 };
 if(aliases[specifier])return {url:new URL(aliases[specifier],import.meta.url).href,shortCircuit:true};
 if(specifier==='typebox'||specifier.startsWith('typebox/'))return nextResolve(specifier,{...context,parentURL:new URL('./runtime/anchor.mjs',import.meta.url).href});
 return nextResolve(specifier,context);
}

