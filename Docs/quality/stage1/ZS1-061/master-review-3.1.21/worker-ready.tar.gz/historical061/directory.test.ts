import {it,expect,afterAll} from 'vitest';
import {writeFileSync} from 'node:fs';
import {mkdtemp,writeFile,readFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {Agent} from './source/packages/agent/src/agent.ts';
import {setDefaultStreamFn} from './source/packages/agent/src/stream-fn.ts';
import {model,user,assistant,scriptedStream} from './fixture-helpers.mjs';
const records:any[]=[];const base=fileURLToPath(new URL('.',import.meta.url));
const entries:any[]=[
 {type:'message',id:'old',parentId:null,seq:0,timestamp:0,message:user('OLD_EXCLUDED')},
 {type:'compaction',id:'cp',parentId:'old',seq:1,timestamp:1,summary:'CHECKPOINT_PENDING',tokensBefore:200,retainedTail:[user('TAIL'),assistant([],'aborted')]},
 {type:'message',id:'new',parentId:'cp',seq:2,timestamp:2,message:user('NEW_INPUT')}
];
async function run(mode:string){
 const root=await mkdtemp(join(tmpdir(),'zenpi-dir061-'));try{
  const path=join(root,'caller-checkpoint.json');const input=JSON.stringify({mode,entries});await writeFile(path,input);
  const args=['--experimental-strip-types','--experimental-loader',join(base,'loader.mjs'),join(base,'restore-child.mjs'),path];
  const out=await promisify(execFile)(process.execPath,args,{cwd:base,timeout:8000,maxBuffer:1024*1024});
  expect(await readFile(path,'utf8')).toBe(input);const value=JSON.parse(out.stdout);expect(value.pid).not.toBe(process.pid);
  records.push({mode,input,args,stdout:out.stdout,stderr:out.stderr,value,callerFileUnchanged:true});return value;
 }finally{await rm(root,{recursive:true,force:true});}
}
afterAll(()=>writeFileSync(process.env.DIR_OBSERVATIONS!,JSON.stringify(records,null,2)+'\n'));
it('D061-01 fresh process projects caller checkpoint and sends summary tail and later input through Agent',async()=>{
 const v=await run('explicit');expect(v.projected.map((m:any)=>m.role)).toEqual(['compactionSummary','user','user']);
 expect(v.requests).toHaveLength(1);expect(JSON.stringify(v.requests[0].context.messages)).toContain('CHECKPOINT_PENDING');
 expect(JSON.stringify(v.requests[0].context.messages)).not.toContain('OLD_EXCLUDED');
 expect(v.events.filter((e:any)=>e.type==='message_end').map((e:any)=>e.message.role)).toEqual(['assistant']);
 expect(v.streaming).toBe(false);expect(v.pendingTools).toBe(0);
});
it('D061-02 default Agent conversion omits projected compactionSummary unless host supplies converter',async()=>{
 const v=await run('default');expect(v.projected[0].role).toBe('compactionSummary');
 expect(JSON.stringify(v.requests[0].context.messages)).not.toContain('CHECKPOINT_PENDING');
 expect(v.requests[0].context.messages.map((m:any)=>m.content)).toEqual(['TAIL','NEW_INPUT']);
});
it('D061-03 default stream registration and queued input are process-local caller state',async()=>{
 const parent=new Agent({initialState:{model},streamFn:scriptedStream([],[])});parent.steer(user('UNSAVED_STEER'));expect(parent.hasQueuedMessages()).toBe(true);
 setDefaultStreamFn(scriptedStream([],[]));
 try{const v=await run('explicit');expect(v.defaultAvailable).toBe(false);expect(v.initiallyQueued).toBe(false);expect(JSON.stringify(v)).not.toContain('UNSAVED_STEER');expect(parent.hasQueuedMessages()).toBe(true);}
 finally{setDefaultStreamFn(undefined);}
});

