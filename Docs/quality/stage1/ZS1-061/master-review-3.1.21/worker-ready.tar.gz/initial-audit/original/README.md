# ZS1-061 independent package directory candidate

Read report/Docs/learn/stage1_pi_mono/packages/agent/current_folder_learn.md. Sole candidate report.patch adds that one path from an absent base. No receipt, authority, product or source modifications.

Formal children057/058 have independent current acceptance;061/064 remain pending. Physical inventory is7 files/5 directories. New complete readings28 files/3603lines include actual package/build/test/export connections, documentation generator, session benchmark entry code and faux e2e source. Context is not additional formal acceptance.

71 accepted receipt artifacts,057 original175-payload tar,058 preserved43-member evidence tar, and old061 original63-payload packet are portable. The historical3-child-process observations establish caller-file reconstruction and converter/process-local boundaries, not SessionRepo/JSONL/crash recovery. Prior failed057 expectations and058 integrity preparation mistakes remain in the dependency evidence.

Run python3 /absolute/path/to/copied-ready/verify.py from outside the copied directory, with stdout/stderr outside ready. The verifier is read-only Python standard library; no original machine paths are required, and no captured scripts, SDK, build, test, product, benchmark,117 or131 are run. Freeze first and run this output package at most once per worker delivery. Hash checks establish identity, not independent semantic acceptance.

Actual worker audit argv/UTC/exit/raw outputs are outside ready under .ops/stage1-worker/source061-directory-3.1.21. final-observation records actual live checks; portable audit validates the captured observations. Main target core drift is kept separate from unchanged source evidence. Six old packets and retained117 fixture remain frozen.
