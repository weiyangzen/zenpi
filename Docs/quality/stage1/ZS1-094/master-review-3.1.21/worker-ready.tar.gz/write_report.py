from pathlib import Path
import difflib,hashlib,json
w=Path('.ops/zs1-094-source321-work')
name='Docs/learn/stage1_pi_mono/targets/zenpi/files/src/layout.rs_learn.md'
old=(w/'worker-before'/name).read_text()
semantic=old[old.index('## 身份与状态层'):old.index('## 必要调用片段与漂移边界')]
tests=old[old.index('## 外部测试全文阅读'):old.index('## 历史证据边界')]
experiments=old[old.index('## 最小实验矩阵'):old.index('## 精确补丁与接收回退')]
header='''# ZS1-094 — src/layout.rs 单文件完整复核（3.1.21）

状态 `[_]`：worker report-only candidate，Master 独立 G-FILE / G-STAGE 接收待定。唯一 owned path 为本报告；本轮不改 BentoBox 或任何产品文件，不处理 085 F2/F3，也不将本报告当作 120/090 或122验收。主控当前50/121仅是接单时状态。

## 权威、基线与本轮重新完整阅读

2026-09-13T01:28:27.549820+00:00 从主库只读捕获 `src/layout.rs`：54632 B、1567行，SHA256 `218c1b1cb7853da8f5c03b51e09d552f0634efb82284e029cbcfaeb434dac05a`。与3.1.21蓝图第119行及 selector.baseline_files.ZS1-094 完全一致。蓝图第210行指定本报告、依赖ZS1-001、G-FILE/G-STAGE及仅撤回报告；第240行090、第434行120是上层依赖，本轮不代验。

run_id=`zenpi-stage1-20260911`，requirement digest=`3456abcbbebbc4e0ab383c319851b0a6e71b19ee9b3c060a6e212f61a89c9d9d`，baseline snapshot=`92b06c4b1dcdca7614d226ce5f41205646a9e63967789d2b6ed4ee272d240884`。捕获蓝图153896 B，snapshot=`aa9412fe226f42c2dc6898b09cf94ba34e76ee26f268abd4d43d13fad57e7dc1`；selector active=true、3.1.21及 snapshot 匹配。状态后续改变不自动使本输入失效；不拿全局状态hash作无关任务阻塞条件。主库、blueprint、claims、master receipts和旧ready只读。

虽然源文件相对冻结基线没有变化，本轮重新按顺序读完：1–320（工具a9da2c）、321–640（e580e0）、641–960（e9f4cd）、961–1260（19f47b）、1261–1567至EOF（4c3bd7），各段完整输出未截断。`read-ledger.json`保存逐段字节边界/hash与tool chunk；联合覆盖[0,54632)，不是用旧报告、符号扫描或hash替代新读。全文的77个函数定义以及全部类型、常量、注释和分支纳入下面一份报告。

文件内没有测试模块或测试定义，inline/source tests=0。另完整新读当前直接支持测试 `tests/layout.rs` 1–277（3f6050）和 `tests/layout_persistence.rs` 1–166（4cb931），仅 context-only，共18个已有测试，实际执行0，不新增正式source owner。旧094报告全文也已读并保全；源语义相同的说明与77定义索引经本轮逐段核对后沿用，权威、阅读链、当前TUI映射、历史和交付边界重写。

本轮产品运行、Cargo、PTY、HTTP、release、旧runner均为0；未运行Rust算法或其等价脚本。下文手算与待验证矩阵不是执行证据。旧094及其嵌套历史 source/test/build/PTY/预算数字不重新累加为本轮结果。没有117/131/FIFO/DTrace/预算/预热工作，没有新任务或subagent。

'''
context='''## 当前 TUI adapter 的有界映射与职责边界

本轮 TUI 上下文只读快照为669038 B /16374行，SHA256 `6459360343a260c6dfe7b403a81cd22a8fcac0bb3e10fcabed2bd3c0b8567254`，与layout同次捕获。主控明确正在独立修F2；这个快照已出现共享 session_browser_scroll 和 SessionList 单行绘制，属于其进行中的产品delta，不是本worker修改或验收。仅下列有界片段新读；完整TUI原件仅用于确定片段身份，不声称本轮全文阅读TUI。抓取后可能继续漂移，原capture不覆盖。

| 当前调用位置 | 已读行为及布局映射 | 所属与边界 |
| --- | --- | --- |
| 3438–3506 layout getters/restore/dirty/reset intents | 当前model及legacy preset集合；restore重建Project并给每个model重施当前capabilities，最后清dirty/reset；保存成功清bit与render dirty独立 | typed restore本身不validate；磁盘I/O与项目恢复不在纯模型内 |
| 3566–3779 focus/split/reset/preset/collapse/save/summary/capabilities | next/previous/direction返回Some即标dirty；split只在ratio changed标dirty；focus和collapse先验preset成员及optional可用；展开后聚焦，折叠当前focus时尝试next，无候选仍留原focus则清None；reset记录tab意图；set_workspace_tab保存旧preset，重施capabilities且不变项目身份 | wrapper比model setters严格；同状态collapse返回true代表有效请求，不代表发生变更；request_layout_save只是标记 |
| 3632–3640 workspace_viewport | last_area双0时fallback160×40，否则取last_area尺寸 | last_area由render_bentobox存完整frame，实际adapter取扣除头尾/input后的workspace_area；两者高度不同，不能声称键盘与绘制始终用同一height。是否造成焦点偏差需后续产品owner实证，本轮不修 |
| 5847–5898、5960–6020、6095–6185键盘有界片段 | Release早退；approval、history、picker、transcript browser有先行消费；slash菜单先行；在CONTROL分支且input空时Ctrl方向几何导航，CtrlShift水平调整，CtrlShift竖直仍导航，Ctrl0 reset；空prompt Tab/ShiftTab/BackTab循环pane；CtrlTab循环project | 不是全handle_key审计；不是所有modifiers/终端字节或modal情形都由此证明；模型不负责按键编码或Submit |
| 5386–5646完整handle_mouse | picker/browser/follow、palette/project hit前置；workspace adapter给pane hit；左键up清drag；行缝两格容差记录相邻行及原权重，拖动只转移该pair行权；列缝记录bounded ratios，按workspace宽度折算拖动并保留pair总量；pane点击聚焦；滚轮SessionList移动cursor±3、conversation滚transcript，其余pane_scroll±3 | 两格grip、Ratatui Position、滚动与draft/内容都是TUI策略，不在layout纯几何里；此处新读是上下文，不接管F2或拖拽产品验证 |
| 7292–7335 render_bentobox | 零frame返回；保存last_area；按投影wrap计算动态input高度；tabs/header各1、workspace Min1、input动态、footer1；内容后绘picker/browser/approval | 不改现有BentoBox；overlay优先级、Unicode/wrap和IO需对应owner |
| 7426–7524 render_workspace/render_workspace_pane/scroll | 保存workspace_area；零面积返回；adapter visible pane再排除零rect；Goal专用transcript、其它conversation走普通transcript，其余pane按内容owner取值；SessionList特殊scroll和不wrap，其他内容wrap | layout仅决定pane身份/矩形/visibility；Checks/ApprovalQueue/Diff等占位内容不能因模型有pane定义就算业务已实现 |
| 7526–7550 session_browser_content | 空列表No sessions；最多32项，cursor前加选中标记，拼session_id/turns/events/next，每项一行 | session数据来源/扫描/取消/会话打开在host；不把SessionList pane存在当作数据或状态验收 |
| 7790–7875 PaneFrame/BentoBoxLayoutAdapter/translate/conversation mapping | new用area宽高compute；保留所有pane状态并translate；offset夹到area，坐标饱和加，width/height夹剩余；visible_panes只过滤Visible；pane按ID查找，tab/breakpoint/snapshot/area为getter；conversation按5preset映射 | model在0原点；adapter引入实际区域原点并裁剪。render还要过滤empty，不能仅由Visible证明可绘 |

SessionList 的职责必须拆开：layout preset只规定Left row0、weight45、minimum24×4，和SessionConversation/ReplayControls共享左列；它完全不知道session_browser数组、cursor、32项上限、border减2、pane_scroll或哪一行点击哪条session。捕获TUI的render与mouse都调用session_browser_scroll，mouse再加减去上边框的内容行号，并只接受内部边框坐标；这解释F2修复落在TUI和项目workspace测试，而非layout。主控正在运行的反例/回归不在本包，不推断通过，不覆盖其源码。

模型的输入输出可用于headless/未来GUI，但本轮只证明模块不导入ratatui/crossterm且函数可被普通Rust调用；没有逐读headless endpoint，因此不把设计复用目标表述成某个已上线协议。LayoutPreferences内没有文件I/O或provider秘密；支持测试调用config保存层的安全文件规则，不以测试名称替代当前config完整审阅。本轮未新读config owner，旧094 config片段仅历史。

## 静态边界与手算示例（未执行）

Project在200×40、两optional能力启用时，raw列宽为60/90/50，均满足各列max minimum 24/36/32；实际分配先扣minimum总92，余108按30/45/25分成32/49/27（最大余数给中列），所以最终56/85/59。左列先扣高度4+3+4=11，余29按45/30/25得到13/9/7，最终17/12/11。此为阅读源码后的手算，不是运行样本，说明“ratio”是剩余空间权重而非最终百分比。

需要保留的分支限制：Zero导致可用pane Hidden但不改model；Narrow全user-collapse可以没有pane；低高度Visible可零rect；focus_candidates为空返回None但可能保留旧focused；adjust_focused_split可改focus却因ratio不变返回false；delta0不做bounded；reset_tab删除预存空profile时可能返回false；tab_state/reset并不全validate；model compute容忍非法权重并不等于preferences允许保存；schema存在却非as_u64时legacy回退与needs_migration标记可不同步。上述均按实现说明合同，后续验证输入见矩阵，本轮没有复现新缺陷、修改产品或提升风险等级。

取消/恢复/错误的适用性：本文件没有异步任务、网络、子进程、磁盘写入、终端模式或取消token，因而不存在本文件独立取消/资源reap/TTY恢复实验；同步几何计算和内存修改由host调用。可观察恢复是model_for/legacy迁移/reset及capabilities重新应用，持久化原子写入和失败恢复归config/项目checkpoint owner。typed LayoutError由调用者传播或展示，模型没有向用户弹窗或悄悄写默认文件。

'''
history='''## 旧094历史的原样保全

整个旧 `.ops/zs1-094-ready` 原样复制到本包 `historical/zs1-094-ready/`，旧manifest为8800 B /SHA256 `013e06a06e650f9d17b606021b7c2f444eb43ee806ce5055443a949828375fc5`。包括旧3.1.20报告、source/test读记录、旧静态脚本/审计及嵌套历史证据；本轮不执行其中任何程序。旧worker标准报告另存worker-before，主库标准报告捕获时不存在，故master-before为absent；不能伪称主控此前已接收旧094。

历史release/PTY/预算失败与通过记录仍在旧包原位置，其语义限定于各自当时输入。本轮既不重验其产品结果，也不累加旧source/test/断言/运行数量。原报告中的77定义和18外部测试是同一组源实体，不因重新阅读成为154定义或36个不同测试。新离线完整性审计仅核对复制字节，不能把旧结构passed提升为新的行为passed。

'''
end='''## 唯一报告补丁、回滚与交付

本包只将本标准报告作为owned产物，`candidate/`内恰有此一路径。`master.patch`基于主库捕获absent新增报告；`worker.patch`基于worker-before的精确旧字节更新；对应reverse patch供仅此报告回滚。补丁由精确前后文本生成并由新离线结构核验重建比对，不宣称运行过git apply或产品测试。接收时如主库已有报告，主控先保存新前态并重新合并，不force、不用整树覆盖；回退只恢复该报告前态，绝不reset/stash/clean主库、用户会话或其它项。

`read-ledger.json`是连续全文阅读记录；`context-ledger.json`绑定有界上下文；`capture.json`封存权威及输入身份；`historical/`保全旧094；`master-state/final-observation.json`仅记录交付前有限漂移，未覆盖capture。新verifier完整静态阅读后，冻结包最多运行一次offline结构核验，stdout/stderr/exit/hash在包外；失败原样保留且不重跑。该结构结果不替代Master逐函数/分支语义G-FILE和G-STAGE。报告交付后停止，后续产品验证须另由主控分配。
'''
report=header+semantic+context+tests+history+experiments+end
out=w/'candidate'/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(report)
Path(name).write_text(report)
for label,before,after in [('master','',report),('worker',old,report)]:
 a='/dev/null' if not before else 'a/'+name
 (w/(label+'.patch')).write_text(''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile=a,tofile='b/'+name)))
 (w/(label+'-rollback.patch')).write_text(''.join(difflib.unified_diff(after.splitlines(keepends=True),before.splitlines(keepends=True),fromfile='a/'+name,tofile='/dev/null' if not before else 'b/'+name)))
print(json.dumps(dict(bytes=len(report.encode()),lines=len(report.splitlines()),sha256=hashlib.sha256(report.encode()).hexdigest()),indent=2))
