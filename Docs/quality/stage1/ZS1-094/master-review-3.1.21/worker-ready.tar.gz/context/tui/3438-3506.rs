    /// Borrow the layout model used by the production workspace renderer.
    ///
    /// Keeping this as a typed model lets hosts inspect or adjust bounded
    /// ratios/capabilities without coupling themselves to Ratatui rectangles.
    pub fn workspace_layout(&self) -> &LayoutModel {
        &self.workspace_layout
    }

    /// The project tab is the only top-level workspace scope. Feature
    /// presets may exist for migration, but they are never project identity.
    pub fn active_project_workspace(&self) -> &LayoutModel {
        &self.workspace_layout
    }

    /// Return a bounded snapshot of every persisted pane preset. Project tabs
    /// still own the visible workspace; legacy feature presets remain stored
    /// only for migration and compatibility.
    pub fn workspace_layout_states(&self) -> Vec<LayoutModel> {
        let mut states = Vec::with_capacity(TabId::ALL.len());
        states.push(self.workspace_layout.clone());
        states.extend(self.workspace_layouts.values().cloned());
        states
    }

    /// Restore saved tab models before entering the production event loop.
    /// Unknown tabs are impossible through the typed API; duplicate entries
    /// deterministically use the last one. Host capabilities are applied later
    /// because they are not portable user preferences.
    pub fn restore_workspace_layouts<I>(&mut self, layouts: I)
    where
        I: IntoIterator<Item = LayoutModel>,
    {
        let capabilities = self.workspace_layout.capabilities;
        self.workspace_layouts.clear();
        self.workspace_layout = LayoutModel::new(TabId::Project);
        self.workspace_layout.set_capabilities(capabilities);
        for mut layout in layouts {
            layout.set_capabilities(capabilities);
            if layout.tab == TabId::Project {
                self.workspace_layout = layout;
            } else {
                self.workspace_layouts.insert(layout.tab, layout);
            }
        }
        self.layout_dirty = false;
        self.layout_resets.clear();
        self.dirty = true;
    }

    /// Whether a user-owned layout mutation should be persisted by a host.
    pub fn layout_dirty(&self) -> bool {
        self.layout_dirty
    }

    /// Clear the persistence bit after a successful save. Rendering dirtiness
    /// is intentionally independent and is not affected by this operation.
    pub fn clear_layout_dirty(&mut self) {
        self.layout_dirty = false;
    }

    /// Return tabs whose persisted state should be removed on the next save.
    pub fn layout_reset_tabs(&self) -> Vec<TabId> {
        self.layout_resets.iter().copied().collect()
    }

    /// Clear reset intents after a successful persistence checkpoint.
    pub fn clear_layout_reset_tabs(&mut self) {
        self.layout_resets.clear();
    }
