    pub fn handle_mouse(&mut self, mouse: MouseEvent) -> TuiAction {
        if let Some(picker) = self.directory_picker.as_mut() {
            let result = picker.mouse(mouse);
            self.picker_result(result);
            return TuiAction::Redraw;
        }

        if let Some(browser) = self.transcript_browser.as_mut() {
            if mouse.kind == MouseEventKind::Down(MouseButton::Left)
                && mouse.row == browser.area.y + 2
                && mouse.column > browser.area.x
            {
                let x = mouse.column - browser.area.x - 1;
                let code = if x < 6 {
                    Some(KeyCode::Up)
                } else if x < 13 {
                    Some(KeyCode::Down)
                } else if x < 20 {
                    Some(KeyCode::Enter)
                } else if x < 28 {
                    Some(KeyCode::Esc)
                } else {
                    None
                };
                if let Some(code) = code {
                    let action = browser.key(KeyEvent::new(code, KeyModifiers::NONE));
                    if let Some(action) = action {
                        self.transcript_browser = None;
                        self.dirty = true;
                        return action;
                    }
                }
            }
            if let Some(browser) = self.transcript_browser.as_mut() {
                match mouse.kind {
                    MouseEventKind::ScrollUp => browser.scroll = browser.scroll.saturating_sub(3),
                    MouseEventKind::ScrollDown => browser.scroll = browser.scroll.saturating_add(3),
                    _ => {}
                }
            }
            self.dirty = true;
            return TuiAction::Redraw;
        }
        if mouse.kind == MouseEventKind::Down(MouseButton::Left)
            && self
                .follow_hit
                .is_some_and(|r| r.contains(Position::new(mouse.column, mouse.row)))
        {
            self.follow_latest();
            return TuiAction::Redraw;
        }
        let position = Position::new(mouse.column, mouse.row);
        if mouse.kind == MouseEventKind::Up(MouseButton::Left) {
            self.dragging_split = None;
            self.dragging_row = None;
            return TuiAction::Redraw;
        }
        if mouse.kind == MouseEventKind::Down(MouseButton::Left) {
            if self.palette_area.contains(position) {
                let choices = self.slash_choices();
                if !choices.is_empty()
                    && mouse.row > self.palette_area.y
                    && mouse.row < self.palette_area.bottom() - 1
                {
                    let row = usize::from(mouse.row - self.palette_area.y - 1);
                    if row >= self.palette_rows {
                        return TuiAction::Redraw;
                    }
                    self.palette_index = self.palette_start + row;
                    self.choose_slash(&choices);
                }
                return TuiAction::Redraw;
            }
            if let Some((_, index)) = self
                .project_hits
                .iter()
                .find(|(rect, _)| rect.contains(position))
            {
                if *index == usize::MAX {
                    self.request_project_select(
                        (self.active_project + self.project_tabs.len() - 1)
                            % self.project_tabs.len(),
                    );
                } else if *index == usize::MAX - 1 {
                    self.request_project_select(
                        (self.active_project + 1) % self.project_tabs.len(),
                    );
                } else if *index == self.project_tabs.len() {
                    self.open_directory_picker();
                } else {
                    self.request_project_select(*index);
                }
                return TuiAction::Redraw;
            }
        }
        let adapter = BentoBoxLayoutAdapter::new(&self.workspace_layout, self.workspace_area);
        let panes: Vec<_> = adapter.visible_panes().collect();
        if mouse.kind == MouseEventKind::Down(MouseButton::Left) {
            self.dragging_row = panes.iter().find_map(|top| {
                panes
                    .iter()
                    .find(|bottom| {
                        bottom.id != top.id
                            && bottom.rect.x == top.rect.x
                            && bottom.rect.y == top.rect.bottom()
                            && mouse.row.abs_diff(bottom.rect.y) <= 2
                            && mouse.column > top.rect.x
                            && mouse.column < top.rect.right().saturating_sub(1)
                    })
                    .map(|bottom| {
                        let preset = self.workspace_layout.preset();
                        let weight = |id| {
                            self.workspace_layout
                                .row_weights
                                .get(&id)
                                .copied()
                                .unwrap_or_else(|| {
                                    preset
                                        .panes
                                        .iter()
                                        .find(|spec| spec.id == id)
                                        .unwrap()
                                        .row_weight
                                })
                        };
                        let column = preset
                            .panes
                            .iter()
                            .find(|spec| spec.id == top.id)
                            .unwrap()
                            .column;
                        let specs: Vec<_> = preset
                            .panes
                            .iter()
                            .filter(|spec| {
                                spec.column == column && panes.iter().any(|pane| pane.id == spec.id)
                            })
                            .collect();
                        let total: u16 = specs.iter().map(|spec| weight(spec.id)).sum();
                        let minimum: u16 = specs.iter().map(|spec| spec.min_size.height).sum();
                        (
                            top.id,
                            bottom.id,
                            mouse.row,
                            weight(top.id),
                            weight(bottom.id),
                            self.workspace_area
                                .height
                                .saturating_sub(minimum)
                                .max(1)
                                .saturating_mul(1000)
                                / total.max(1),
                        )
                    })
            });
            let preset = self.workspace_layout.preset();
            self.dragging_split = panes.iter().find_map(|pane| {
                let adjacent = panes
                    .iter()
                    .find(|other| other.rect.x == pane.rect.right())?;
                let left = preset.panes.iter().find(|spec| spec.id == pane.id)?.column;
                let right = preset
                    .panes
                    .iter()
                    .find(|spec| spec.id == adjacent.id)?
                    .column;
                (left != right
                    // Forgiving two-cell grip, matching herdr's coarse-mouse
                    // pane handle behavior.
                    && mouse.column.abs_diff(pane.rect.right()) <= 2
                    && mouse.row >= pane.rect.y
                    && mouse.row < pane.rect.bottom())
                .then_some((
                    left,
                    right,
                    mouse.column,
                    self.workspace_layout.ratios.bounded(),
                ))
            });
            if let Some(pane) = panes.iter().find(|pane| pane.rect.contains(position)) {
                self.focus_workspace_pane(pane.id);
                if pane.id == PaneId::SessionList
                    && mouse.column > pane.rect.x
                    && mouse.column < pane.rect.right().saturating_sub(1)
                    && mouse.row > pane.rect.y
                    && mouse.row < pane.rect.bottom().saturating_sub(1)
                {
                    let row = self
                        .session_browser_scroll(pane.rect)
                        .saturating_add(usize::from(mouse.row.saturating_sub(pane.rect.y + 1)));
                    if row < self.session_browser.len().min(32) {
                        self.session_browser_cursor = row;
                        self.dirty = true;
                        return TuiAction::Redraw;
                    }
                }
            }
        }
        if let Some((top, bottom, origin, top_weight, bottom_weight, scale)) = self.dragging_row
            && matches!(mouse.kind, MouseEventKind::Drag(MouseButton::Left))
        {
            // Transfer only this pair's weight; unrelated rows retain their share.
            let delta = (i32::from(mouse.row) - i32::from(origin)) * 1000 / i32::from(scale.max(1));
            let total = top_weight + bottom_weight;
            let split = (i32::from(top_weight) + delta).clamp(
                i32::from(total.saturating_sub(1000).max(1)),
                i32::from((total - 1).min(1000)),
            ) as u16;
            self.workspace_layout.row_weights.insert(top, split);
            self.workspace_layout
                .row_weights
                .insert(bottom, total - split);
            self.layout_dirty = true;
            self.cached_transcript = None;
        } else if let Some((left, right, origin, initial)) = self.dragging_split
            && matches!(mouse.kind, MouseEventKind::Drag(MouseButton::Left))
            && self.workspace_area.width > 0
        {
            let delta = (i32::from(mouse.column) - i32::from(origin)) * 100
                / i32::from(self.workspace_area.width);
            let total = initial.get(left) + initial.get(right);
            let value =
                (i32::from(initial.get(left)) + delta).clamp(5, i32::from(total - 5)) as u16;
            let mut ratios = initial;
            ratios.set(left, value);
            ratios.set(right, total - value);
            self.workspace_layout.set_ratios(ratios);
            self.layout_dirty = true;
            self.cached_transcript = None;
        }
        if let Some(pane) = panes.iter().find(|pane| pane.rect.contains(position))
            && matches!(
                mouse.kind,
                MouseEventKind::ScrollUp | MouseEventKind::ScrollDown
            )
        {
            self.focus_workspace_pane(pane.id);
            if pane.id == PaneId::SessionList {
                self.move_session_browser_cursor(if mouse.kind == MouseEventKind::ScrollUp {
                    -3
                } else {
                    3
                });
            } else if pane.id == conversation_pane_for_tab(self.workspace_layout.tab) {
                if mouse.kind == MouseEventKind::ScrollUp {
                    self.scroll_up(3);
                } else {
                    self.scroll_down(3);
                }
            } else {
                let scroll = self.pane_scroll.entry(pane.id).or_default();
                *scroll = if mouse.kind == MouseEventKind::ScrollUp {
                    scroll.saturating_sub(3)
                } else {
                    scroll.saturating_add(3)
                };
            }
        }
        self.dirty = true;
        TuiAction::Redraw
    }
