                }
                KeyCode::Char('w') | KeyCode::Backspace => {
                    self.delete_previous_word();
                    return TuiAction::None;
                }
                KeyCode::Char('l') => return TuiAction::Redraw,
                KeyCode::Char('o') => {
                    self.toggle_tool_logs();
                    return TuiAction::Redraw;
                }
                // Workspace controls are kept on modified keys so ordinary
                // arrow navigation remains dedicated to multiline prompt
                // editing. Ctrl-Arrow moves pane focus; Ctrl-Shift-Arrow
                // adjusts the selected split by one bounded step.
                KeyCode::Left | KeyCode::Right | KeyCode::Up | KeyCode::Down
                    if self.input.is_empty() =>
                {
                    let direction = match key.code {
                        KeyCode::Left => FocusDirection::Left,
                        KeyCode::Right => FocusDirection::Right,
                        KeyCode::Up => FocusDirection::Up,
                        KeyCode::Down => FocusDirection::Down,
                        _ => unreachable!(),
                    };
                    if modifiers.contains(KeyModifiers::SHIFT) && direction.is_horizontal() {
                        self.adjust_workspace_split(direction);
                    } else {
                        self.focus_workspace_direction(direction);
                    }
                    return TuiAction::Redraw;
                }
                KeyCode::Char('0') if self.input.is_empty() => {
                    self.reset_workspace_layout();
                    return TuiAction::Redraw;
                }
                // Workspace navigation follows herdr's tab-cycle model; the
                // visible names remain the source of truth, while Ctrl-Tab
                // provides a discoverable non-numeric shortcut.
                KeyCode::Tab if self.input.is_empty() => {
                    let current = self.active_project;
                    let next = if modifiers.contains(KeyModifiers::SHIFT) {
                        (current + self.project_tabs.len() - 1) % self.project_tabs.len()
                    } else {
                        (current + 1) % self.project_tabs.len()
                    };
                    self.request_project_select(next);
                    return TuiAction::Redraw;
                }
                // Keep Ctrl+1..5 as a compatibility shortcut. The visible
                // tab bar is the primary navigation and is mouse-addressable;
                // numeric keys are never interpreted while drafting text.
                KeyCode::Char(character) if ('1'..='9').contains(&character) => {
                    let index = usize::from(character as u8 - b'1');
                    self.request_project_select(index);
                    return TuiAction::Redraw;
                }
                // Ctrl-J is the portable terminal spelling of a newline.
                // Treat Ctrl-Enter the same way because a few terminals send
                // that pair as `KeyCode::Enter` rather than `Char('j')`.
                KeyCode::Char('j') | KeyCode::Enter => {
                    self.insert_text("\n");
                    return TuiAction::None;
                }
                _ => {}
            }
        }
        match key.code {
            // With an empty prompt, Tab cycles BentoBox focus; while typing
            // it remains available to the terminal's normal input handling.
            KeyCode::Tab if self.input.is_empty() => {
                if modifiers.contains(KeyModifiers::SHIFT) {
                    self.focus_previous_workspace_pane();
                } else {
                    self.focus_next_workspace_pane();
                }
                return TuiAction::Redraw;
            }
            // Most terminals report Shift-Tab as BackTab rather than Tab with
            // a SHIFT modifier. Accept both spellings so reverse pane focus
            // works outside synthetic key tests.
            KeyCode::BackTab if self.input.is_empty() => {
                self.focus_previous_workspace_pane();
                return TuiAction::Redraw;
            }
            // Complete a slash command only while the command name is the
            // whole trailing token. Ordinary prompt text keeps Tab inert,
            // and a cursor in the middle of a draft never moves later bytes.
            KeyCode::Tab if modifiers.is_empty() => {
                if self.complete_slash_input() {
                    return TuiAction::Redraw;
                }
