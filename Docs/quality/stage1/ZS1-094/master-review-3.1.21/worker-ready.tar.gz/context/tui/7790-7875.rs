/// Ratatui-facing rectangle for one pane in a computed BentoBox snapshot.
/// The rectangle is clipped to the adapter area, so transient zero/one-cell
/// resize events can never make a widget draw outside the frame.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct PaneFrame {
    pub id: PaneId,
    pub rect: Rect,
    pub visibility: Visibility,
}

/// Reusable bridge from the terminal-independent [`LayoutModel`] to Ratatui.
/// Consumers can inspect the snapshot for diagnostics or use `pane`/
/// `visible_panes` to render their own widgets without duplicating breakpoint
/// and capability logic.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct BentoBoxLayoutAdapter {
    area: Rect,
    snapshot: LayoutSnapshot,
    panes: Vec<PaneFrame>,
}

impl BentoBoxLayoutAdapter {
    pub fn new(model: &LayoutModel, area: Rect) -> Self {
        let snapshot = model.compute(area.width, area.height);
        let panes = snapshot
            .panes
            .iter()
            .map(|pane| PaneFrame {
                id: pane.id,
                rect: translate_pane_rect(area, pane.rect),
                visibility: pane.visibility,
            })
            .collect();
        Self {
            area,
            snapshot,
            panes,
        }
    }

    pub fn area(&self) -> Rect {
        self.area
    }

    pub fn tab(&self) -> TabId {
        self.snapshot.tab
    }

    pub fn breakpoint(&self) -> Breakpoint {
        self.snapshot.breakpoint
    }

    pub fn snapshot(&self) -> &LayoutSnapshot {
        &self.snapshot
    }

    pub fn pane(&self, id: PaneId) -> Option<PaneFrame> {
        self.panes.iter().find(|pane| pane.id == id).copied()
    }

    pub fn visible_panes(&self) -> impl Iterator<Item = PaneFrame> + '_ {
        self.panes
            .iter()
            .copied()
            .filter(|pane| pane.visibility == Visibility::Visible)
    }
}

fn translate_pane_rect(area: Rect, pane: PaneRect) -> Rect {
    let x_offset = pane.x.min(area.width);
    let y_offset = pane.y.min(area.height);
    let x = area.x.saturating_add(x_offset);
    let y = area.y.saturating_add(y_offset);
    let width = pane.width.min(area.width.saturating_sub(x_offset));
    let height = pane.height.min(area.height.saturating_sub(y_offset));
    Rect::new(x, y, width, height)
}

fn conversation_pane_for_tab(tab: TabId) -> PaneId {
    match tab {
        TabId::Project => PaneId::ProjectConversation,
        TabId::Goal => PaneId::GoalConversation,
        TabId::Learn => PaneId::LearnConversation,
        TabId::Review => PaneId::ReviewConversation,
        TabId::Session => PaneId::SessionConversation,
    }
