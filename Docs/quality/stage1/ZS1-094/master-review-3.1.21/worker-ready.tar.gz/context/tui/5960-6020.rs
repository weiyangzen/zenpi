        let choices = self.slash_choices();
        if !choices.is_empty() && key.modifiers.is_empty() {
            match key.code {
                KeyCode::F(2) => {
                    if let Some(resource) = choices
                        .get(self.palette_index % choices.len())
                        .and_then(|choice| {
                            self.command_resources.iter().find(|r| r.command == *choice)
                        })
                    {
                        return TuiAction::InspectResource {
                            command: resource.command.clone(),
                            source_hash: resource.hash.clone(),
                        };
                    }
                }
                // An ambiguous completion selects a highlighted row only once
                // that menu has been drawn. Before then, preserve the common
                // prefix completion below instead of guessing an unseen row.
                KeyCode::Tab if choices.len() == 1 || self.palette_rows > 0 => {
                    self.choose_slash(&choices);
                    return TuiAction::Redraw;
                }
                KeyCode::Down => {
                    self.palette_index = (self.palette_index + 1) % choices.len();
                    return TuiAction::Redraw;
                }
                KeyCode::Up => {
                    self.palette_index = (self.palette_index + choices.len() - 1) % choices.len();
                    return TuiAction::Redraw;
                }
                KeyCode::Esc => {
                    self.palette_dismissed = true;
                    return TuiAction::Redraw;
                }
                KeyCode::Enter => {
                    let exact = choices
                        .get(self.palette_index % choices.len())
                        .is_some_and(|choice| choice.eq_ignore_ascii_case(&self.input));
                    let submenu = matches!(
                        self.input.as_str(),
                        "/persona"
                            | "/personas"
                            | "/model"
                            | "/goal"
                            | "/learn"
                            | "/session"
                            | "/approval"
                            | "/approvals"
                    );
                    if !exact || submenu {
                        self.choose_slash(&choices);
                        return TuiAction::Redraw;
                    }
                }
                _ => {}
            }
        }
        let modifiers = key.modifiers;
        if modifiers.contains(KeyModifiers::CONTROL) {
            match key.code {
