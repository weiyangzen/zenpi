    pub fn render_bentobox(&mut self, frame: &mut Frame<'_>, title: &str) {
        let area = frame.area();
        if area.width == 0 || area.height == 0 {
            return;
        }
        if area != self.last_area {
            self.last_area = area;
            self.cached_transcript = None;
            self.input_scroll = 0;
        }
        let prompt_width = usize::from(area.width.saturating_sub(2)).max(1);
        let prompt_lines = wrap_plain(&self.projection().text, prompt_width).len();
        let desired_input_height = prompt_lines.min(MAX_INPUT_LINES).saturating_add(2);
        let input_height = if area.height > 4 {
            u16::try_from(desired_input_height)
                .unwrap_or(u16::MAX)
                .min(area.height.saturating_sub(4))
        } else {
            0
        };
        let chunks = Layout::default()
            .direction(Direction::Vertical)
            .constraints([
                Constraint::Length(1),
                Constraint::Length(1),
                Constraint::Min(1),
                Constraint::Length(input_height),
                Constraint::Length(1),
            ])
            .split(area);
        self.render_workspace_tabs(frame, chunks[0]);
        self.render_header(frame, chunks[1], title);
        self.render_workspace(frame, chunks[2]);
        self.render_input(frame, chunks[3]);
        self.render_footer(frame, chunks[4]);
        self.render_slash_choices(frame, chunks[3]);
        if let Some(picker) = self.directory_picker.as_mut() {
            picker.render(frame);
        }
        if let Some(browser) = self.transcript_browser.as_mut() {
            browser.render(frame);
        }
        self.render_approval(frame);
    }
