
    /// Return the currently focused BentoBox pane.
    pub fn focused_workspace_pane(&self) -> Option<PaneId> {
        self.workspace_layout.focused_pane()
    }

    /// Move focus to the next pane in the active workspace.  Before the first
    /// frame is drawn there is no measured viewport, so use the wide preset as
    /// a conservative default; a subsequent resize/render applies the real
    /// breakpoint without losing the selected pane.
    pub fn focus_next_workspace_pane(&mut self) -> Option<PaneId> {
        let (width, height) = self.workspace_viewport();
        let focused = self.workspace_layout.focus_next(width, height);
        if focused.is_some() {
            self.layout_dirty = true;
            self.dirty = true;
        }
        focused
    }

    /// Move focus to the previous pane in the active workspace.
    pub fn focus_previous_workspace_pane(&mut self) -> Option<PaneId> {
        let (width, height) = self.workspace_viewport();
        let focused = self.workspace_layout.focus_previous(width, height);
        if focused.is_some() {
            self.layout_dirty = true;
            self.dirty = true;
        }
        focused
    }

    /// Move focus geometrically in the active workspace.
    pub fn focus_workspace_direction(&mut self, direction: FocusDirection) -> Option<PaneId> {
        let (width, height) = self.workspace_viewport();
        let focused = self
            .workspace_layout
            .focus_direction(direction, width, height);
        if focused.is_some() {
            self.layout_dirty = true;
            self.dirty = true;
        }
        focused
    }

    /// Nudge the focused column split by one bounded keyboard step.
    pub fn adjust_workspace_split(&mut self, direction: FocusDirection) -> bool {
        let (width, height) = self.workspace_viewport();
        let changed = self
            .workspace_layout
            .adjust_focused_split(direction, width, height);
        if changed {
            self.layout_dirty = true;
            self.dirty = true;
        }
        changed
    }

    /// Reset ratios, collapsed panes, and focus to the active tab preset.
    pub fn reset_workspace_layout(&mut self) {
        let tab = self.workspace_layout.tab;
        self.workspace_layout.reset_layout();
        self.layout_resets.insert(tab);
        self.layout_dirty = true;
        self.dirty = true;
    }

    fn workspace_viewport(&self) -> (u16, u16) {
        if self.last_area.width == 0 && self.last_area.height == 0 {
            // A wide fallback keeps all required panes keyboard reachable
            // before the first draw.  It is never used after a real frame.
            (160, 40)
        } else {
            (self.last_area.width, self.last_area.height)
        }
    }

    /// Select an internal pane preset for compatibility. This does not alter
    /// the top-level project tab identity.
    pub fn set_workspace_tab(&mut self, tab: TabId) {
        if self.workspace_layout.tab != tab {
            let capabilities = self.workspace_layout.capabilities;
            let current = std::mem::replace(
                &mut self.workspace_layout,
                LayoutModel::new(tab).with_capabilities(capabilities),
            );
            self.workspace_layouts.insert(current.tab, current);
            self.workspace_layout = self
                .workspace_layouts
                .remove(&tab)
                .unwrap_or_else(|| LayoutModel::new(tab).with_capabilities(capabilities));
            self.workspace_layout.set_capabilities(capabilities);
            self.project_checkpoint_dirty = true;
            self.dirty = true;
        }
    }

    /// Select a pane in the active BentoBox tab. A pane that was collapsed is
    /// expanded before focus is assigned; unavailable optional adapters are
    /// rejected without mutating layout state.
    pub fn focus_workspace_pane(&mut self, pane: PaneId) -> bool {
        let valid = self
            .workspace_layout
            .preset()
            .panes
            .into_iter()
            .find(|spec| spec.id == pane)
            .is_some_and(|spec| {
                !spec.optional || pane_available(pane, self.workspace_layout.capabilities)
            });
        if !valid {
            return false;
        }
        let was_focused = self.workspace_layout.focused == Some(pane);
        let was_collapsed = self.workspace_layout.collapsed.remove(&pane);
        let changed = !was_focused || was_collapsed;
        self.workspace_layout.focused = Some(pane);
        if changed {
            self.layout_dirty = true;
            self.dirty = true;
        }
        true
    }

    /// Set the collapsed state of one pane in the active tab. The pane must be
    /// part of the tab preset; unknown panes and unavailable optional panes
    /// are rejected so a slash command cannot poison persisted preferences.
    pub fn set_workspace_pane_collapsed(&mut self, pane: PaneId, collapsed: bool) -> bool {
        let valid = self
            .workspace_layout
            .preset()
            .panes
            .into_iter()
            .find(|spec| spec.id == pane)
            .is_some_and(|spec| {
                !spec.optional || pane_available(pane, self.workspace_layout.capabilities)
            });
        if !valid {
            return false;
        }
        let was_collapsed = self.workspace_layout.collapsed.contains(&pane);
        if was_collapsed == collapsed {
            return true;
        }
        self.workspace_layout.set_collapsed(pane, collapsed);
        if collapsed && self.workspace_layout.focused == Some(pane) {
            let (width, height) = self.workspace_viewport();
            let _ = self.workspace_layout.focus_next(width, height);
            if self
                .workspace_layout
                .focused
                .is_some_and(|focused| focused == pane)
            {
                self.workspace_layout.focused = None;
            }
        }
        self.layout_dirty = true;
        self.dirty = true;
        true
    }

    /// Toggle one pane's collapsed state and return its new state. `None`
    /// means the pane is not present/available in the active preset.
    pub fn toggle_workspace_pane(&mut self, pane: PaneId) -> Option<bool> {
        let valid = self
            .workspace_layout
            .preset()
            .panes
            .into_iter()
            .find(|spec| spec.id == pane)
            .is_some_and(|spec| {
                !spec.optional || pane_available(pane, self.workspace_layout.capabilities)
            });
        if !valid {
            return None;
        }
        let collapsed = !self.workspace_layout.collapsed.contains(&pane);
        self.set_workspace_pane_collapsed(pane, collapsed);
        Some(collapsed)
    }

    /// Request an explicit layout persistence checkpoint. Production TUI
    /// persistence runs at the next event-loop checkpoint; this method keeps
    /// `/layout save` deterministic without writing from the command parser.
    pub fn request_layout_save(&mut self) {
        self.layout_dirty = true;
        self.dirty = true;
    }

    /// Return a small JSON-safe layout projection for slash responses and
    /// diagnostics. Geometry remains computed from the terminal-independent
    /// model and is bounded to the current viewport.
    pub fn workspace_layout_summary(&self) -> serde_json::Value {
        let (width, height) = self.workspace_viewport();
        let snapshot = self.workspace_layout.compute(width, height);
        serde_json::json!({
            "tab": self.workspace_layout.tab,
            "ratios": self.workspace_layout.ratios,
            "focused": self.workspace_layout.focused,
            "collapsed": self.workspace_layout.collapsed,
            "breakpoint": snapshot.breakpoint,
            "visible_panes": snapshot.visible_panes().map(|pane| pane.id).collect::<Vec<_>>(),
            "layout_dirty": self.layout_dirty,
        })
    }

    /// Set optional pane capabilities for a host that has an external adapter.
    /// Browser and PTY panes remain disabled by default in the binary.
    pub fn set_workspace_capabilities(&mut self, capabilities: crate::layout::PaneCapabilities) {
        self.workspace_layout.set_capabilities(capabilities);
        for layout in self.workspace_layouts.values_mut() {
            layout.set_capabilities(capabilities);
        }
        self.dirty = true;
    }
