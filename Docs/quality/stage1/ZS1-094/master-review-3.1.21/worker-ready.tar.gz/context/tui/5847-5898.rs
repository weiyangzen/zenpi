    pub fn handle_key(&mut self, key: KeyEvent) -> TuiAction {
        if key.kind == KeyEventKind::Release {
            return TuiAction::None;
        }
        self.touch_editor_draft();
        self.project_checkpoint_dirty = true;
        if let Some(action) = self.approval_key(key) {
            return action;
        }
        if self.history_search.is_some() {
            return self.history_search_key(key);
        }
        if let Some(picker) = self.directory_picker.as_mut() {
            let result = picker.key(key);
            self.picker_result(result);
            return TuiAction::Redraw;
        }

        if self.transcript_browser.is_some()
            && key.code == KeyCode::Char('c')
            && key.modifiers.contains(KeyModifiers::CONTROL)
        {
            self.transcript_browser = None;
            return if self.busy {
                TuiAction::Interrupt
            } else {
                TuiAction::Redraw
            };
        }
        if let Some(browser) = self.transcript_browser.as_mut() {
            let action = browser.key(key);
            self.dirty = true;
            if let Some(action) = action {
                self.transcript_browser = None;
                return action;
            }
            return TuiAction::Redraw;
        }
        if key.modifiers == KeyModifiers::ALT
            && key.code == KeyCode::Enter
            && let Some(index) = self.adjacent_paste()
        {
            self.cursor = self.paste.folds.remove(index).start_byte;
            self.edited_input();
            self.palette_dismissed = false;
            return TuiAction::Redraw;
        }
        if key.modifiers == KeyModifiers::ALT {
            match key.code {
                KeyCode::Left => {
                    self.move_word(false);
                    return TuiAction::Redraw;
