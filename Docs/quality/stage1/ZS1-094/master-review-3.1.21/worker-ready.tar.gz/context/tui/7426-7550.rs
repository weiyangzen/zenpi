    fn render_workspace(&mut self, frame: &mut Frame<'_>, area: Rect) {
        self.workspace_area = area;
        if area.width == 0 || area.height == 0 {
            return;
        }
        let adapter = BentoBoxLayoutAdapter::new(&self.workspace_layout, area);
        let canonical = conversation_pane_for_tab(adapter.tab());
        for pane in adapter.visible_panes() {
            if pane.rect.width == 0 || pane.rect.height == 0 {
                continue;
            }
            if pane.id == PaneId::GoalConversation {
                self.render_transcript_pane(frame, pane.rect, true);
            } else if pane.id == canonical
                || matches!(
                    pane.id,
                    PaneId::ProjectConversation
                        | PaneId::LearnConversation
                        | PaneId::ReviewConversation
                        | PaneId::SessionConversation
                )
            {
                // Every workspace keeps its ordinary conversation lane
                // visible alongside Goal; tab switching changes context, not
                // the existence of either hot zone.
                self.render_transcript(frame, pane.rect);
            } else {
                self.render_workspace_pane(frame, pane.id, pane.rect);
            }
        }
    }

    fn render_workspace_pane(&self, frame: &mut Frame<'_>, id: PaneId, area: Rect) {
        if area.width == 0 || area.height == 0 {
            return;
        }
        // Keep the split affordance visible without adding a second toolbar:
        // the centered grip is a stable mouse target at every breakpoint.
        let title = format!(" {}  ⋮ ", workspace_pane_title(id));
        let content = match id {
            PaneId::Gantt => self.gantt_pane_content(),
            PaneId::Resources => self.resource_pane_content(),
            PaneId::SessionList => self.session_browser_content(),
            PaneId::ReplayControls => self.replay_pane_content(),
            PaneId::Terminal => self.terminal_snapshot.clone(),
            PaneId::EventTimeline => self.session_timeline_content(),
            // Goal is rendered as a transcript in `render_workspace`; this
            // branch is retained for compact-layout fallback paths.
            PaneId::GoalConversation => "-".into(),
            PaneId::ProjectConversation
            | PaneId::LearnConversation
            | PaneId::ReviewConversation
            | PaneId::SessionConversation => "-".into(),
            PaneId::LearnResources
            | PaneId::LearnQueue
            | PaneId::LearnMapping
            | PaneId::Evidence
            | PaneId::Checks
            | PaneId::ApprovalQueue
            | PaneId::Diff
            | PaneId::Browser => "-".into(),
        };
        let block = Block::default()
            .borders(Borders::ALL)
            .border_style(
                Style::default().fg(if self.workspace_layout.focused == Some(id) {
                    Color::Cyan
                } else {
                    Color::DarkGray
                }),
            )
            .title(title);
        let scroll = if id == PaneId::SessionList {
            self.session_browser_scroll(area)
        } else {
            usize::from(*self.pane_scroll.get(&id).unwrap_or(&0))
        };
        let paragraph = Paragraph::new(content)
            .style(Style::default().fg(Color::DarkGray))
            .block(block)
            .scroll((scroll.min(usize::from(u16::MAX)) as u16, 0));
        // Session selection and mouse hits address items, so every item must
        // occupy one row even when the pane is too narrow for its full label.
        let paragraph = if id == PaneId::SessionList {
            paragraph
        } else {
            paragraph.wrap(Wrap { trim: true })
        };
        frame.render_widget(paragraph, area);
    }

    fn session_browser_scroll(&self, area: Rect) -> usize {
        let visible = usize::from(area.height.saturating_sub(2)).max(1);
        self.session_browser_cursor
            .saturating_sub(visible.saturating_sub(1))
            .max(usize::from(
                *self.pane_scroll.get(&PaneId::SessionList).unwrap_or(&0),
            ))
    }

    fn session_browser_content(&self) -> String {
        if self.session_browser.is_empty() {
            return "No sessions".into();
        }
        self.session_browser
            .iter()
            .take(32)
            .enumerate()
            .map(|(index, summary)| {
                format!(
                    "{}{}  turns={} events={} next={}",
                    if index == self.session_browser_cursor {
                        "> "
                    } else {
                        "  "
                    },
                    summary.session_id,
                    summary.turn_count,
                    summary.event_count,
                    summary.next_seq
                )
            })
            .collect::<Vec<_>>()
            .join("\n")
    }
