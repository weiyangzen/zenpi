"""Offline evidence checks only. Does not execute source or behavior models."""
from pathlib import Path
import hashlib,json,re
E=Path(__file__).resolve().parent;root=E.parents[4]
def read(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def bound(p,r):
 b=p.read_bytes();assert len(b)==r['bytes'] and sha(b)==r['sha256'],str(p)
b=(E/'source/baseline-layout.rs').read_bytes();c=(E/'source/current-layout.rs').read_bytes()
assert b==c and len(c)==54632 and len(c.splitlines())==1567 and sha(c)=='218c1b1cb7853da8f5c03b51e09d552f0634efb82284e029cbcfaeb434dac05a'
assert not re.search(r'#\[(?:test|tokio::test)',c.decode()) and read(E/'source-tests.json')==[]
rl=read(E/'read-log.json')
for key in ['baseline_sequential_reads','current_sequential_reads']:
 pos=0;line=1;parts=[];ls=c.splitlines(keepends=True)
 for r in rl[key]:
  a,z=r['lines'];start,end=r['bytes'];assert a==line and start==pos and end-start<=262144
  piece=b''.join(ls[a-1:z]);assert piece==c[start:end] and sha(piece)==r['sha256'];parts.append(piece);pos=end;line=z+1
 assert pos==54632 and line==1568 and b''.join(parts)==c
assert rl['partial_attempt']['accepted_as_complete'] is False
sel=read(E/'context/authority-selector.json');assert sel['active'] and sel['blueprint_version']=='3.1.20' and sel['requirement_digest']=='8d525b351d066ce9b0487a485337647d47233275782e4f4d154423a623fe1645'
assert sel['snapshot_sha256']==sha((E/'context/blueprint-3.1.20.md').read_bytes())
assert sel['baseline_files']['ZS1-094']==dict(bytes=54632,path='src/layout.rs',scope='target',sha256=sha(c))
inputs=read(E/'inputs.json');assert inputs['formal_files']==1 and len(inputs['files'])==24
for r in inputs['files']:bound(root/r['snapshot'],r)
cs=read(E/'context-capture.json');assert len(cs)==2 and sum(len(r['excerpts']) for r in cs)==8 and len(cs[0]['excerpts'])==7
assert cs[0]['full_bytes']==579524 and cs[0]['full_sha256']=='d2a98934d4931a5aa202e542acd556bdda5667f0e60df11a68731dacf00eccf1'
report=(root/'Docs/learn/stage1_pi_mono/targets/zenpi/files/src/layout.rs_learn.md').read_text();assert not re.search(r'^\s*[-*]\s+\[[xX]\]',report,re.M)
funcs=[(i,m[1]) for i,l in enumerate(c.decode().splitlines(),1) if (m:=re.search(r'\bfn (\w+)\(',l))];inv=read(E/'function-inventory.json');assert len(inv)==77 and [(r['source_line'],r['name']) for r in inv]==funcs and all(r['read'] and r['name'] in report for r in inv)
ct=read(E/'context-tests.json');assert ct['context_only'] and ct['executed']==0 and len(ct['files'])==2
counts=[];assertions=0
for f in ct['files']:
 p=E/f['snapshot'];bound(p,f);txt=p.read_text();ls=txt.splitlines();assert len(ls)==f['lines'] and f['full_file_read'];assert len(re.findall(r'#\[test\]',txt))==len(f['tests'])
 for t in f['tests']:
  a,z=t['source_lines'];assert ls[a-1].strip()==f"fn {t['name']}() {{" and ls[z-1]=='}';body='\n'.join(ls[a-1:z]);assert len(re.findall(r'\bassert(?:_eq|_ne)?!',body))==t['assertions'] and t['read'] and not t['executed'] and t['name'] in report;assertions+=t['assertions']
 counts.append(len(f['tests']))
assert counts==[11,7] and assertions==97
matrix=read(E/'capability-matrix.json');assert len(matrix)==10 and all(not r['executed_in_094'] and r['source_fact'] in report for r in matrix)
for token in ['Standard与','needs_migration','delta=0','零rect','源测试定义/阅读/实际执行均0','P10','97','G-STAGE','1044.823959','1208.732708']:assert token in report,token
h=E/'history/release';m=read(h/'manifest.json');assert sha((h/'manifest.json').read_bytes())=='4a3e21c0fb5738b18abbda180fea89282c69932cbf7d916aa9aa87bd800ece7f' and m['complete'] is False
members=0
for p in h.iterdir():
 if p.name in m['artifacts']:bound(p,m['artifacts'][p.name]);members+=1
bi=read(h/'build-inputs.json');assert bi['src/layout.rs']['sha256']==sha(c) and bi['src/tui.rs']['sha256']==cs[0]['full_sha256']
d=read(h/'bentobox.json');run=read(h/'bentobox.run.json');assert d['status']=='passed' and run['exit_code']==0 and d['tui_processes']==3
assert len(d['checks'])==11 and sum(v is True for v in d['checks'].values())==9
assert isinstance(d['checks']['plus_to_valid_project'],dict) and isinstance(d['checks']['responsive_resize_preserves_unicode_draft_and_layout'],list)
assert d['binary_sha256']==read(h/'binary.json')['sha256']=='1d7b2e61ecc9096ad0f5e6cd3f3c03c6820cafe8371d9201de3497bb6b4e8f58'
budget=read(h/'budget.json');assert budget['ok'] is True and len(budget['gates'])==8 and all(v is True for v in budget['gates'].values()) and read(h/'budget.run.json')['exit_code']==0
print(json.dumps(dict(passed=True,scope='offline evidence structure only; semantic G-FILE/G-STAGE pending',source_bytes=54632,source_lines=1567,baseline_current_identical=True,sequential_reads_per_identity=3,source_functions=77,source_tests_read=0,source_tests_executed=0,context_test_files_fully_read=2,context_tests_read=18,context_assertion_calls=97,context_tests_executed=0,inputs_checked=24,caller_excerpts=8,tui_reads=1,capability_groups=10,historical_manifest_members_checked=members,historical_bentobox_entries=11,historical_bentobox_boolean_true=9,cargo_runs=0,pty_runs=0,http_runs=0,product_behavior_runs=0),ensure_ascii=False,indent=2))
