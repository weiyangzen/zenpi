# ZS1-094 — src/layout.rs 单文件完整复核

状态：worker candidate；master G-FILE / G-STAGE待独立接收。模式understand，产品改动0。本报告替换本项旧worker报告，旧字节完整保留；不继承历史完成标记。

## 权威、基线与完整阅读

本轮直接核对主库`Docs/stage_1_v3_pi_mono_blueprint.md` 3.1.20：第119行列出ZS1-094为`src/layout.rs`，54632B，SHA256 `218c1b1cb7853da8f5c03b51e09d552f0634efb82284e029cbcfaeb434dac05a`；第208行owned path为本报告，依赖ZS1-001，Validators为G-FILE及G-STAGE逐项校验，rollback仅撤此报告。第235行ZS1-090目录整合依赖本项；第421行ZS1-120项目身份/cwd/persistence owner也依赖本项，本轮不代替这些上层验收。

同时封存主库active_requirement.json：active=true，run_id=`zenpi-stage1-20260911`，requirement digest `8d525b351d066ce9b0487a485337647d47233275782e4f4d154423a623fe1645`；selector的ZS1-094 baseline条目与源身份相同。当前蓝图全文hash `b3b623125d1ebbed1c6df1414b0d687ec48629fd6e0e7dbcdd3ce3cc05f96ab2`与selector snapshot_sha256一致。状态变化会改变snapshot，不把它与稳定requirement digest混同。未写selector、claim或checkbox。

基线来自原worktree的冻结匹配字节，当前来自主库只读副本；两份均54632B/1567行、同上述hash，逐字节相等。当前master HEAD仍为`6f252a20c628e9b1ede14e2887acc04657c71d7c`，但基线是带用户变更的worktree，不能仅以HEAD代替文件内容。本项零source delta，不据此跳过阅读。

基线全文按1–550、551–1100、1101–1567连续读取；当前字节先捕获后按同样三段连续复读。初次尝试一次cat当前全文在工具输出中被截断，不计为完成，已用完整三段替代。read-log逐段给出相邻字节边界及hash，联合覆盖[0,54632)，无遗漏、无分区报告。三段只是呈现批次，均小于256KiB，最后只形成本标准路径的一份完整报告。

正式源文件数1（baseline/current是同一文件两个身份副本），完整77函数定义、全部枚举/结构/常量/注释与方法已读；文件内没有test模块、测试函数、断言或snapshot。源测试定义/阅读/实际执行均0。外部`tests/layout.rs` 277行9505B和`tests/layout_persistence.rs`166行6463B全文另读，属于context-only：11+7测试、65+32=97个文本断言调用、1 helper，执行0；一个symlink测试为cfg(unix)。断言调用数不乘循环次数，不是实测检查数。

既有coverage-contract要求一源一报告、目录由接受的文件报告派生，context-only不计覆盖。本轮封存合同文本作为约束说明；正式scope和当前selector来自主控蓝图，不擅自新建替代manifest/目录报告或把support tests提升为正式owner。

## 身份与状态层

TabId是Project/Goal/Learn/Review/Session五种旧pane preset。ALL固定顺序，as_str与Display输出snake_case名字；它不是目录、project ID、session ID或provider profile。PaneId有19个稳定pane名，as_str/Display给出相应snake_case，is_optional仅Browser/Terminal。显示名与项目路径不在本模块关联。

Viewport/MinSize只是u16宽高值构造；PaneRect保存x/y/width/height，right/bottom用饱和加，contains半开区间，intersects先拒绝任一空rect再做严格交集，边缘相接不算重叠。它们没有屏幕原点偏移、border、鼠标坐标或Unicode排版。任意公有rect可由外部构造；算出的布局在0原点，宿主负责嵌入实际workspace。

Column的index固定Left0/Center1/Right2，FocusDirection的is_horizontal只Left/Right，is_forward为Right/Down。PaneCapabilities默认browser=false、terminal=false；仅是声明能力的布尔值，不探测适配器/权限/进程是否存在。

LayoutModel持tab、ratios、row_weights、collapsed、focused、capabilities；new从tab派生preset并用默认能力，preset每次重建内置列表。with_capabilities/set_capabilities、set_ratios/set_focused、set_collapsed都是低层原样写入，不能因为字段typed就认为状态已经validate。toggle_collapsed返回切换后的collapsed状态。focused_pane直接返回保存字段，不保证当前可见或可用。

PersistedTabLayout仅取ratios/row_weights/collapsed/focused；from_model复制这些，apply_to_model不会覆盖capabilities或tab。ProfileLayoutPreferences的tabs按TabId，LayoutPreferences的profiles按String，默认schema1空map。它们和PersistedTabLayout有deny_unknown_fields；ColumnRatios及legacy LayoutModel没有这一属性。把“所有深层未知字段都拒绝”写成结论不符合源码。

## 五个preset及最小尺寸

所有preset默认column weights=30/45/25。以下每列按row顺序列出`pane:row_weight:min_width×min_height`；右列全为optional。row_weight不是最终占整个viewport的精确百分比。

| TabId | 左列 | 中列 | 右列 |
| --- | --- | --- | --- |
| Project | ProjectConversation:45:24×4；Resources:30:22×3；GoalConversation:25:24×4 | Gantt:100:36×6 | Browser:55:32×6；Terminal:45:32×6 |
| Goal | GoalConversation:50:24×4；Resources:25:22×3；ProjectConversation:25:24×4 | Gantt:70:36×6；EventTimeline:30:36×4 | Browser:55:32×6；Terminal:45:32×6 |
| Learn | LearnConversation:45:26×4；LearnResources:35:22×3；LearnQueue:20:22×3 | LearnMapping:65:36×6；Evidence:35:36×4 | Browser:55:32×6；Terminal:45:32×6 |
| Review | ReviewConversation:45:26×4；Checks:35:22×3；ApprovalQueue:20:22×3 | Diff:100:44×8 | Terminal:55:32×6；Browser:45:32×6 |
| Session | SessionList:45:24×4；SessionConversation:35:26×4；ReplayControls:20:24×3 | EventTimeline:65:36×6；Gantt:35:36×4 | Browser:55:32×6；Terminal:45:32×6 |

LayoutPreset::project/goal/learn/review/session只是for_tab便利入口；pane helper把最小宽高构为MinSize，再PaneSpec::new，后者只把row_weight0修为1。LayoutModel不接受外部LayoutPreset替换来注入任意pane列表；LayoutPreset类型本身仍可序列化/构造用于其它用途。ApprovalQueue这个pane名字不处理真实approval响应，Browser/Terminal规格不启动其adapter。

## 比例、分配和计算顺序

ColumnRatios::new/get/set不校验。bounded先将每个weight至少1，weighted_partition把总数100分给三列，再各夹5..90，按第一个可调整index逐点修补总和100。adjust_column在delta=0时直接返回原值，连bounded也不调用；非零先bounded，以i32计算目标并夹5..90，增长按donor扣至MIN，缩小时给donor加至MAX。Left的donor次序Center→Right，Center为Left→Right，Right为Center→Left；不能概括为总是左右平均分担。

LayoutModel::adjust_ratio仅在结果与旧ratios不同才赋值并return true。adjust_focused_split只处理水平键，挑有效focused或第一个focusable pane，写focused，再按Right+5/Left-5调整该pane所在列；竖直键return false。一个边界是focus可被赋值而比例已到边界不变，最后仍return false，宿主不应把这个返回值泛化为全部状态未变。

allocate_lengths先算minimum总和。够放时先分配min，再把剩余按weight给每项，取整后的余数排序决定额外1格；不足时完全退回weighted_partition，不保证min尺寸。weighted_partition也将0权重视1，按权重切总数；两者remainders以`(remainder,index)`整体降序排序，余数相等时较大index优先，不是第一项优先。空spec/weights返回空Vec，注释“always sums total”须限定非空分配对象；全collapsed布局不会填满workspace。

默认preset至多7pane，列至多3，实际调用total是u16或100、权重u16，乘积提升u32；当前有界调用不等于任意u32 total/无限spec的通用算法保证。helper是私有，报告不扩展其API合同。主循环按已分长度饱和累加x/y，布局没有浮点累计误差，但min+remaining算法意味着最终列宽并非恰30%/45%/25%，行高也非恰45%/30%/25%。旧报告“保持比例”只能指保存权重语义。

compute只是compute_viewport的宽高wrapper，完整流水如下：

1. 由tab取内置preset，按width/height分类Breakpoint，所有pane先依capabilities标Visible或Unavailable。
2. width=0或height=0为Zero，可用pane置Hidden；1..79为Narrow，在有效、可用、未user-collapse的focused中优先选，其次第一个required，再第一个optional，只选一pane，其余可用paneCollapsed。80..99为Compact，右列可用paneCollapsed。100..159 Standard与≥160 Wide进入同一分支，未直接采用不同列数规则。
3. 再施加user collapsed和Unavailable；computed状态不回写用户collapsed，窗口变化不等于持久化折叠设置改变。
4. 非Zero/Narrow时调用collapse_optional_for_width。循环比较active列的raw按比重宽度和满足min分配宽度，任一个小于列max-min宽时，选该列可见optional中min_width最大者折叠，重算直到稳定。若没有可折optional，required可在小视口低于min；这不是将用户ratio偷偷扩大到保证所有optional可见。相同max key最终候选遵循迭代器max_by_key行为，未在本文件实现额外稳定ID排序。
5. 收集Visible、按Column并按row排序，仅active columns参与分配；空列不占位置，右列单独可见时也从x0开始。每列min取可见pane最大min_width，row_weights覆盖preset并在计算时夹1..1000。
6. 所有preset pane都返回PaneLayout；非绘制pane默认零rect，可见pane分到rect。height很小时某些Visible pane可得0行；Visibility不是rect非空或最小尺寸达标的同义词。

is_available对非optional恒true，对Browser/Terminal看能力；其它optional spec默认true，但内置preset没有额外种类。PaneState::new和is_available辅助保存computed可用性。Visibility有Visible/Collapsed/Unavailable/Hidden四种，需保留原因差别。LayoutSnapshot::pane按ID查找；visible_panes只过滤枚举，不过滤empty；visible_rects_non_overlapping两两检查rect交叠，空rect自然不相交。因此“非重叠通过”并不证明每块有内容、满足min、坐标一定在viewport内或实际UI没有标题遮盖。

## 焦点、折叠和reset

focusable_panes先compute，再按preset顺序过滤不可用及user-collapse。Narrow返回全部可用未collapse候选，使只有一块可见时仍可切换；其它断点仅返回Visibility::Visible，可能含height极小的零rect。focus_next/previous经focus_cycle环绕；无旧focus时next取首、previous取尾。无candidate返回None但不主动清空self.focused，调用者需要区分返回结果和保存字段。

focus_direction无候选返回None；旧focus无效时总取candidate首项。有效focus有非空rect时，以rect中心判断所选方向，先偏好垂直轴相交，再主轴距离，再次轴距离；相同score不替换先遇到候选。未找到方向项或narrow其它候选没有rect，则按direction.is_forward环绕，不把用户困在唯一visible pane。它是几何导航，不检查crossterm modifiers或modal焦点。

set_collapsed/toggle允许任意PaneId写到集合，没有所属tab检查，compute只处理preset中现有pane；这些无效值可以静默不影响几何，却在持久化validate被拒绝。低层折叠不修focus，不阻止全pane折叠。reset_layout恢复preset ratios、清row_weights/collapsed/focused，保留tab/capabilities；reset仅别名。模型没有undo journal或磁盘写入，reset的错误回退由host保存层处理。

## JSON、迁移与失败原子性

LAYOUT_SCHEMA_VERSION=1；输入/输出序列化文档限制256KiB，MAX_LAYOUT_PROFILES=64，MAX_LAYOUT_COLLAPSED_PANES=64。profile None映射`default`，名字必须1..128字节且全部ASCII alnum/下划线/横线，区分大小写，不接受路径、空格或中文。布局profile属于旧provider profile维度，不能把稳定project ID当任意目录直接填入。

validate按schema、profile数量、profile name、tabs数量、每tab状态验证。tab最多TabId::ALL.len=5；PaneId只有19种且单preset最多7，因此64 collapsed限额是防御上限，正常typed BTreeSet无法靠重复pane绕过；更早的未知pane所属检查实际更严格。ratio每项5..90且饱和总和100；row_weights必须属于该preset、值1..1000；collapsed/focused必须属于tab。不要求focus未collapsed或optional capability可用，也不要求有任何展开pane。InvalidRatios也用于非法row_weight，错误类型不是精细行权错误。

from_json_bytes调用with_migration并丢弃bool；with_migration在解析Value前检查输入len，随后以“schema_version键是否缺失”计算needs_migration，再migrate_value，再validate。解析使用Value中间态，报告不宣称重复JSON key检测或所有unknown深层字段拒绝。当前无文件I/O，解析legacy也不会自动回写磁盘。

migrate_value把schema_version的as_u64再转换u16，太大转u16::MAX后报SchemaVersion；有效数字1按v1结构deserialize。其余None分支deserialize为旧LayoutModel，再preferences.set_model(None,&legacy)。关键静态差距：缺失、null、字符串、负数或小数可能都得不到as_u64，但needs_migration只看键缺失；legacy LayoutModel没有deny_unknown_fields，如果同时有合法legacy必需字段，异常schema键或其它额外字段可能被忽略，返回的migrated还可能false。不能沿用注释“unknown legacy一律拒绝”。这是根据分支提出的待验证输入族，本轮没有执行Rust/等价行为模型，不写成已复现安全漏洞。

legacy所需tab/ratios/collapsed/focused/capabilities由Serde决定，其中row_weights有default；迁移后PersistedTabLayout故意丢弃capabilities，再model_for重建默认false，宿主需重新施加。已有legacy测试默认capability false，因此不能替代enabled capability迁移边界。v1外层deny_unknown_fields不扩展到未标注的ColumnRatios内部。

to_json_bytes先validate，再pretty serialization，追加换行后检查256KiB。输出检查发生在构造Vec后，不能声称从不分配超过上限。BTreeMap/BTreeSet提供稳定序，与序列化规则共同使相同值重复编码确定。set_model先验profile和新state、验self，再clone next、比较同值return false、插入并验证next、最后一次性*self=next；新profile第65个失败时原值不替换。它不调用to_json_bytes，内存模型验证成功不保证最终pretty文档一定在字节限制内。

model_for先全validate，再构建tab preset并应用保存值；即使只想取某个profile，其它profile非法也会失败。tab_state只检查所请求profile key，不全validate，所以公共构造的非法document可被该只读getter返回。reset_tab和reset_profile也只验证请求名字，不先validate整个document，允许从现有对象移除记录；reset_tab删除后empty profile移除。对预先存在的空profile，删除不存在tab可能返回false却移除空profile，这是低层返回“tab是否删除”的语义，不保证整对象没变化。

LayoutError包括SchemaVersion、InvalidProfile、TooManyProfiles、TooManyTabs、InvalidRatios、TooManyCollapsed、UnknownPane、Json，thiserror提供文字。不触及credentials、approval决策或磁盘权限；注释里的“损坏layout不破坏provider”依赖config把文件隔离，不能仅由本文件证明所有host路径成立。

## 必要调用片段与漂移边界

当前TUI只读捕获一次：2026-09-12T11:21:10.831499+00:00，579524B，SHA256 `d2a98934d4931a5aa202e542acd556bdda5667f0e60df11a68731dacf00eccf1`。主控之后的菜单刷新修复不在本快照内，不循环追读，不将旧hash宣称最新完整TUI。当前config必要片段全文件身份为77782B/`f5691bd3818dcaf1481a88b63cc4f3874bc6b007234059e26124b74046325d12`。共7个TUI片段、1个config片段；TUI select_project_tab是前45行，config reset函数只到1556行中部，均不算全函数/完整owner阅读。

| 调用入口 | 片段事实 | 不能外推的部分 |
| --- | --- | --- |
| restore_workspace_layouts L2760–2779 | 保留当前capabilities，重建Project默认并逐项覆盖能力后导入其它preset，清dirty/reset | 未在此验证输入模型；恢复源必须另有validate，未完整审阅项目恢复owner |
| focus_workspace_direction L2892–2902 | 调用model几何导航，返回Some就标layout_dirty/dirty | 不等价于返回值代表实际focus变了；键盘/菜单路由未在此读 |
| reset_workspace_layout L2918–2924 | reset model并记录tab reset，标dirty | 磁盘失败/独立进程重启是后续保存owner范围 |
| set_workspace_pane_collapsed L2986–3018 | 先验pane属于preset及optional能力；同状态return true；折叠当前focus时尝试focus_next，仍相同则清None | 宿主比低层更严格，模型测试不能替代此层错误反馈/焦点验证 |
| set_workspace_capabilities L3067–3073 | 更新当前及其它preset能力，标dirty | 没在片段自动探测adapter，也不说明关闭进程等资源回收 |
| select_project_tab L1915–1959 | 取旧active_project字符串，将workspace_layout clone存project_layouts，其他draft/preset也保留 | 这是稳定host key分层的调用证据，未读完整project ID canonicalization或恢复尾部，不接管ZS1-120 |
| render_bentobox L6397–6440 | 零area return；顶部tabs/header各1行，动态input、footer1行，workspace取剩余chunk，最后叠picker/browser/approval | layout的height应由宿主工作区决定；没有完整读取render_workspace的局部坐标转换，本项不认证overlay/菜单修复 |
| config L1468–1556 | missing布局读default；secure_regular_file/read_layout_bytes后decode；migration显式；save先to_json再ensure_root和atomic_write_if_changed | 只读调用点，没有完整安全文件/atomic writer实现，不以函数名证明race/rename/权限失败全验证 |

## 外部测试全文阅读（18项，本轮执行0）

以下测试是现有支持性代码，完整文件已封存，未升格为新增正式owner或源内联测试。表内断言数是文本调用数，loop迭代不会重复计数。

### tests/layout.rs — 11 tests

- `every_workspace_tab_has_a_named_preset_and_required_panes` L7–29，7断言：五preset具名/非空、需要的Resources/Gantt及Browser/Terminal、min正数；不验每一精确权重。
- `breakpoint_bands_include_zero_and_narrow_resize_states` L32–40，7断言：0、79/80/99/100/159/160边界；未单独试width非零height0。
- `wide_project_layout_respects_ratios_minimums_and_has_no_overlap` L43–64，9断言：200×40 full caps，min、边界、列顺序及非重叠；没有断言精确30/45/25百分比。
- `optional_right_panes_are_unavailable_by_default_and_collapse_on_compact` L67–93，6断言：默认Unavailable、enable后90×30右列Collapsed。
- `narrow_layout_keeps_one_focusable_pane_and_zero_viewport_is_hidden` L96–118，5断言：Goal EventTimeline选中60×20单pane，0×0 Hidden。
- `custom_ratios_collapse_optional_panes_when_minimum_width_cannot_fit` L121–137，3断言：1/98/1在120×30令optional不Visible；只是低层非法持久化权重的compute例。
- `fully_collapsed_state_is_safe_at_a_normal_viewport` L140–153，2断言：required全折叠时无visible且非重叠，证明不是强制保底一pane。
- `pane_focus_cycles_in_preset_order_and_skips_collapsed_or_unavailable_panes` L156–202，7断言：200×40序列/next/previous、skip collapse及关闭能力。
- `directional_focus_prefers_same_row_or_column_before_falling_back` L205–235，5断言：上下左右几何偏好及60×20窄屏fallback；不是所有tie/zero-rect组合。
- `interactive_ratio_adjustment_preserves_bounded_total_and_reset_restores_preset` L242–265，9断言：0/98/1 bounded，Left+100到MAX再次不变、reset；不覆盖delta0无归一化。
- `focused_split_adjustment_uses_horizontal_arrows_only` L268–277，5断言：Down无比例修改，Right到left35、总100。

### tests/layout_persistence.rs — 7 tests

- `profile_and_tab_states_round_trip_independently_and_reset_is_idempotent` L13–48，8断言：tempdir中alpha/beta与Project/Goal隔离、reset幂等；不是稳定project同profile隔离。
- `invalid_state_is_rejected_without_replacing_a_valid_snapshot` L51–64，4断言：0/100/0存失败，磁盘bytes及有效model保留。
- `corrupt_and_oversized_documents_fail_closed_without_mutation` L67–86，4断言：非法JSON、256KiB+1文件读取拒绝并保持原件；不含rename故障注入。
- `out_of_range_and_unknown_pane_values_are_rejected` L89–107，2断言：left4与not_a_real_pane拒绝；未知enum字符串不同于有效PaneId但属于错tab。
- `legacy_layout_model_is_migrated_to_default_profile` L110–130，5断言：默认capability Goal旧model读回，显式migration true再false，schema/default profile。
- `layout_symlink_is_rejected_for_read_write_and_reset` L134–153，6断言：cfg(unix)，tempdir外指symlink读写reset拒绝且outside字节不变；不是所有平台/TOCTOU。
- `layout_preferences_json_round_trip_is_bounded_and_deterministic` L156–166，3断言：空默认preferences重复输出相同且<上限、读回等值；不是巨大profile边界。

没有新增测试或执行现有测试，外部测试通过与否不能从assert源码推断。等待后续产品owner运行时须绑定实际binary/config/项目状态、保存失败原件，并验证独立重启与真实TUI；纯模型测试不能替代键鼠操作/原始终端恢复。

## 历史证据边界

只复用已冻结309包中的历史release子集，原public manifest SHA256 `4a3e21c0fb5738b18abbda180fea89282c69932cbf7d916aa9aa87bd800ece7f`，binary.json记录6033168B/`1d7b2e61ecc9096ad0f5e6cd3f3c03c6820cafe8371d9201de3497bb6b4e8f58`。build-inputs表中的src/layout.rs与本项同hash，TUI与本轮捕获也同hash；不据此声称所有后续菜单变动都被这个release验证。没有本轮读取或运行binary本体。

bentobox历史result status passed、run exit0、3 TUI：11个checks条目中9布尔true、resize尺寸列表和plus操作对象各1。包含真实键鼠布局、缩放、折叠、项目独立布局/草稿及两次重启；resize为1×1/40×12/100×28/180×45/140×40。plus三操作依赖fixture恰一个直接子目录，不能泛化为任意路径上限。原run的sha256是output log，result JSON以public manifest条目绑定。当前只是离线校验原件，不新增一次PTY或把11条都算布尔断言。

该历史预算8 gate true，layout1.07245µs、冷启动max751.967292ms等只证明当时binary样本。原review仍指向旧1044.823959ms和1208.732708ms失败，根因未明，不删除旧失败或拿本次源无差异推导根因解决；review所说complete=false保持。此包没有复制全126历史artifacts，也不重新确认全部226build inputs；只校验选入原件和本文件必要绑定。无本轮G-STAGE、Cargo、PTY、HTTP、真实行为运行。

## 最小实验矩阵（10组，均未执行）

### P01 — 断点与几何可见性

输入：0×N/N×0，79/80/99/100/159/160及height1，5preset×4capability组合。判据：检查Visibility、rect边界/非重叠，不将Visible等同非空或满足min。本轮未执行，只是静态阅读后交给owner的验证要求。

### P02 — 最小值和权重分配

输入：200×40 Project含optional、极端1/98/1、零权重、余数并列、全collapse。判据：minimum先占位后分剩余；不足时退weighted；余数并列后index优先；允许无可见pane。本轮未执行，只是静态阅读后交给owner的验证要求。

### P03 — 用户折叠与能力变化

输入：Browser/Terminal enable→collapse→disable→enable，窄屏焦点及全折叠。判据：Unavailable不被展开强制启用；computed collapse不写model；恢复显式state不丢失。本轮未执行，只是静态阅读后交给owner的验证要求。

### P04 — 焦点与返回值边界

输入：旧focused不属于tab/已collapsed/zero-rect，方向无候选，调整已达ratio边界。判据：None可能保留旧focused；adjust_focused_split可改focus却return false；宿主dirty语义需逐项看。本轮未执行，只是静态阅读后交给owner的验证要求。

### P05 — 交互比例与持久化校验不同

输入：adjust delta0、±极值、任意weights；row_weights0/1001/未知pane。判据：delta0不归一化；非零bounded到5..90和100；compute夹行权但存储拒绝非法。本轮未执行，只是静态阅读后交给owner的验证要求。

### P06 — 偏好事务与大小边界

输入：profile64/65、0/128/129bytes/非ASCII、invalidstate set_model、pretty JSON 256KiB边界。判据：set_model验证/clone/commit保持失败原state；不等同to_json可写；None和default同key。本轮未执行，只是静态阅读后交给owner的验证要求。

### P07 — 迁移与未知字段

输入：legacy带capabilities，v1未知顶层/嵌套ratio字段、legacy未知字段、schema缺失/null/string/负数/超u16。判据：分别观察decoder/validator与migrated标志；不以注释断言一律拒绝；capability丢弃后由host施加。本轮未执行，只是静态阅读后交给owner的验证要求。

### P08 — 恢复与重置

输入：项目A/B同provider不同ratio，preset切换、能力重启变化、reset后写失败。判据：profile不是project身份；准确保存host key；reset不抹capability/用户其它项目。本轮未执行，只是静态阅读后交给owner的验证要求。

### P09 — 真实TUI尺寸和焦点

输入：顶部两行/动态prompt/footer缩减content，resize、拖拽、collapse和菜单overlay。判据：传入layout应是workspace尺寸；真实键鼠owner保留draft/layout，不用纯geometry通过抵PTY。本轮未执行，只是静态阅读后交给owner的验证要求。

### P10 — 磁盘与历史证据边界

输入：symlink、权限/rename失败、损坏/oversize、独立重启，历史1d7b2结果对照。判据：存储由config/host负责；现有历史不覆盖漂移菜单；所有本轮运行0，不伪造G-STAGE接受。本轮未执行，只是静态阅读后交给owner的验证要求。

## 逐定义索引

下表只作定位与完整性索引，不能替代前文整体算法、状态转换与错误边界。重名方法按impl分开，不按函数名去重。

| 行 | 所属 | 定义 |
| --- | --- | --- |
| 44 | `TabId` | `as_str` |
| 56 | `std::fmt::Display for TabId` | `fmt` |
| 89 | `PaneId` | `as_str` |
| 113 | `PaneId` | `is_optional` |
| 119 | `std::fmt::Display for PaneId` | `fmt` |
| 149 | `PersistedTabLayout` | `from_model` |
| 158 | `PersistedTabLayout` | `apply_to_model` |
| 187 | `Default for LayoutPreferences` | `default` |
| 221 | `LayoutPreferences` | `validate` |
| 249 | `LayoutPreferences` | `from_json_bytes` |
| 256 | `LayoutPreferences` | `from_json_bytes_with_migration` |
| 272 | `LayoutPreferences` | `to_json_bytes` |
| 287 | `LayoutPreferences` | `tab_state` |
| 301 | `LayoutPreferences` | `model_for` |
| 312 | `LayoutPreferences` | `set_model` |
| 334 | `LayoutPreferences` | `reset_tab` |
| 347 | `LayoutPreferences` | `reset_profile` |
| 355 | `LayoutPreferences` | `migrate_value` |
| 379 | `module` | `validate_tab_state` |
| 427 | `module` | `layout_profile_key` |
| 433 | `module` | `validate_layout_profile_name` |
| 458 | `Breakpoint` | `for_size` |
| 472 | `Breakpoint` | `for_width` |
| 485 | `Viewport` | `new` |
| 501 | `PaneRect` | `new` |
| 510 | `PaneRect` | `is_empty` |
| 514 | `PaneRect` | `right` |
| 518 | `PaneRect` | `bottom` |
| 522 | `PaneRect` | `contains` |
| 526 | `PaneRect` | `intersects` |
| 544 | `MinSize` | `new` |
| 559 | `Column` | `index` |
| 582 | `FocusDirection` | `is_horizontal` |
| 586 | `FocusDirection` | `is_forward` |
| 601 | `Default for ColumnRatios` | `default` |
| 611 | `ColumnRatios` | `new` |
| 631 | `ColumnRatios` | `get` |
| 639 | `ColumnRatios` | `set` |
| 652 | `ColumnRatios` | `bounded` |
| 686 | `ColumnRatios` | `adjust_column` |
| 753 | `PaneSpec` | `new` |
| 782 | `LayoutPreset` | `for_tab` |
| 864 | `LayoutPreset` | `project` |
| 868 | `LayoutPreset` | `goal` |
| 872 | `LayoutPreset` | `learn` |
| 876 | `LayoutPreset` | `review` |
| 880 | `LayoutPreset` | `session` |
| 885 | `module` | `pane` |
| 926 | `LayoutModel` | `new` |
| 937 | `LayoutModel` | `preset` |
| 941 | `LayoutModel` | `with_capabilities` |
| 946 | `LayoutModel` | `set_capabilities` |
| 950 | `LayoutModel` | `set_ratios` |
| 954 | `LayoutModel` | `set_focused` |
| 959 | `LayoutModel` | `focused_pane` |
| 969 | `LayoutModel` | `focusable_panes` |
| 993 | `LayoutModel` | `focus_next` |
| 998 | `LayoutModel` | `focus_previous` |
| 1006 | `LayoutModel` | `focus_direction` |
| 1084 | `LayoutModel` | `focus_cycle` |
| 1104 | `LayoutModel` | `adjust_ratio` |
| 1117 | `LayoutModel` | `adjust_focused_split` |
| 1146 | `LayoutModel` | `reset_layout` |
| 1154 | `LayoutModel` | `reset` |
| 1158 | `LayoutModel` | `set_collapsed` |
| 1166 | `LayoutModel` | `toggle_collapsed` |
| 1175 | `LayoutModel` | `compute` |
| 1179 | `LayoutModel` | `compute_viewport` |
| 1343 | `LayoutModel` | `is_available` |
| 1362 | `PaneState` | `new` |
| 1373 | `PaneState` | `is_available` |
| 1406 | `LayoutSnapshot` | `pane` |
| 1410 | `LayoutSnapshot` | `visible_panes` |
| 1416 | `LayoutSnapshot` | `visible_rects_non_overlapping` |
| 1426 | `module` | `collapse_optional_for_width` |
| 1495 | `module` | `allocate_lengths` |
| 1539 | `module` | `weighted_partition` |

## 精确补丁与接收回退

证据目录`Docs/quality/stage1/ZS1-094/worker-layout-review-3.1.20`保存双份formal字节、逐段read-log、77定义、源0测试清单、外部18测试全文及97断言索引、24输入与8必要调用片段、蓝图/selector/合同、原worker报告和相关历史原件。所有身份通过ready manifest冻结。

master标准report在本轮单独只读检查为absent，master.patch仅新增该文件；worker.patch从封存原报告字节更新本文件。两patch分别在独立临时Git目录先git init，再forward check/apply、reverse check/apply，比较新旧byte/hash并保留无关sentinel，共8步。不会在master或worker根目录试apply。

若接收时master路径已有报告，必须保存精确旧字节再另制基底补丁，不force；若未来采用旧prefix追加模式，也须原prefix逐字节保全。本包按本次absent基底生成，不能对未知现有文件直接应用。撤回只反向这一份报告patch，不重置产品、不删用户会话、不改别项/蓝图/索引。

check_static.py和verify_package.py只验证证据结构、hash、连续覆盖和隔离补丁回放；不执行模型算法、Rust测试或真实行为，不代替master语义G-FILE/G-STAGE。旧309/308及其它ready全部保留。本候选报告闭合后停在ZS1-094，等待主控下一单；整项是否接受及上层120/090是否完成另由master判断。
