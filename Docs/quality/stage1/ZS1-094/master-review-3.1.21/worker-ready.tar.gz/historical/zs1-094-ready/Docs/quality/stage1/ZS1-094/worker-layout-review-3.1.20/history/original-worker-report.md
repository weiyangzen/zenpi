# src/layout.rs — candidate file review

Status: [_] worker candidate; master acceptance pending.
Source path: `src/layout.rs`
Source root: `/Users/wangweiyang/.codex/worktrees/2267/zenpi`
Source SHA256: `218c1b1cb7853da8f5c03b51e09d552f0634efb82284e029cbcfaeb434dac05a`
Source bytes: 54632
Role: Pane layout and persisted layout profiles

## Whole-file behavior

TabId is a legacy internal pane preset, separate from the desired project identity. LayoutModel owns ratios, row weights, focus, collapse and capabilities. It computes wide >=160, standard >=100, compact >=80 and narrow geometries, handles zero size, bounded split ratios and focus movement. Project preset preserves conversation/resources/goal 45/30/25, center Gantt and optional browser/terminal 55/45. LayoutPreferences schema 1 validates <=64 profiles and <=256 KiB serialized input, migrates legacy data and persists preferences without transient capabilities.

## Findings and owner boundaries

No project directory or session ownership belongs in this model. A new workspace identity must not reinterpret TabId::Project/Goal/Learn/Review/Session as separate projects or overwrite saved pane ratios. Source handles narrow/collapsed cases; top bar relocation must account for available height without changing existing geometry.

## Validation and next acceptance

Existing layout and layout_persistence tests verify bounds, non-overlap, focus, profile isolation, legacy recovery and size/symlink handling. Rerun with project strip/picker after wiring; keep one layout profile per stable project ID at the host boundary.

## Coverage evidence

Read scope: entire file, including inline tests where present. Oversized source was read in contiguous line ranges and merged into this one per-file report; no partition substitutes for file coverage. Exact contiguous byte inventory is in `Docs/quality/stage1/ux-chunk-manifest.tsv`; chunks are at most 262144 bytes. Current hashes identify this worker snapshot, including inherited dirty files; they are not claims of a clean HEAD.

This row is proposed in `Docs/quality/stage1/ux-source-manifest.tsv`. It cannot count as accepted coverage until the master registers it in the authoritative manifest and reviews the report. Existing test files are supporting scope proposals, not silent expansion of the authoritative target-owner subset. No source in this report is accepted by this worker.
