# ZS1-094 independent offline candidate

Only formal file: src/layout.rs. Baseline and current bytes identical: 54632B, 1567 lines, SHA256 218c1b1cb7853da8f5c03b51e09d552f0634efb82284e029cbcfaeb434dac05a.
Report: Docs/learn/stage1_pi_mono/targets/zenpi/files/src/layout.rs_learn.md.

Run from any directory:

    python3 <ready>/Docs/quality/stage1/ZS1-094/worker-layout-review-3.1.20/verify_package.py

Verifies every frozen member, both source identities and full continuous reads, 77 definitions, authority snapshot, 24 inputs, 18 external tests read (0 executed), 10 unexecuted experiment groups, and both single-report patches in isolated temporary Git repositories. This performs no product behavior execution, Cargo, PTY, HTTP or G-STAGE acceptance.

master.patch adds only the standard report to the separately checked absent receiving path. worker.patch updates the exact old report preserved under history. Recheck the master baseline before applying; if it exists or differs, preserve its exact bytes and prepare a new baseline patch. Never force or replace an unknown prefix. Reverse only this report for rollback; no repository reset/clean or user-session removal.

Mutable master TUI was captured once at 2026-09-12T11:21:10.831499Z, d2a98934. Subsequent menu changes are outside this frozen context. Prior ready packages remain unchanged. Candidate is not whole-item or directory acceptance; stop after ZS1-094 and await master review.
