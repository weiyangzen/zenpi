"""Read-only package integrity audit, never a product or semantic acceptance run."""
from pathlib import Path, PurePosixPath
import difflib
import hashlib
import json
import re
import sys


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    root = Path(sys.argv[1]).resolve(strict=True)
    expected = sys.argv[2]
    checks = []

    def check(name, okay):
        checks.append(dict(name=name, passed=bool(okay)))
        if not okay:
            raise ValueError(name)

    def read(name):
        part = PurePosixPath(name)
        if part.is_absolute() or '..' in part.parts:
            raise ValueError('unsafe path')
        path = root.joinpath(*part.parts)
        if path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(root):
            raise ValueError('unsafe payload')
        return path.read_bytes()

    def obj(name):
        return json.loads(read(name))

    try:
        check('external manifest digest', sha(read('manifest.json')) == expected)
        listed = set()
        for row in obj('manifest.json')['payload']:
            check('unique '+row['path'], row['path'] not in listed)
            listed.add(row['path'])
            data = read(row['path'])
            check('payload '+row['path'], len(data) == row['bytes'] and sha(data) == row['sha256'])
        actual = {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}
        check('exact inventory', actual == listed | {'manifest.json'})
        source = read('capture/src/layout.rs')
        selector = obj('capture/Docs/execution/active_requirement.json')
        frozen = selector['baseline_files']['ZS1-094']
        check('frozen source identity', len(source) == frozen['bytes'] == 54632 and sha(source) == frozen['sha256'] == '218c1b1cb7853da8f5c03b51e09d552f0634efb82284e029cbcfaeb434dac05a')
        check('authority binding', selector['active'] is True and selector['blueprint_version'] == '3.1.21' and selector['requirement_digest'] == '3456abcbbebbc4e0ab383c319851b0a6e71b19ee9b3c060a6e212f61a89c9d9d' and selector['snapshot_sha256'] == sha(read('capture/Docs/stage_1_v3_pi_mono_blueprint.md')))
        ledger = obj('read-ledger.json')
        lines = source.splitlines(keepends=True)
        end_byte, end_line = 0, 0
        for row in ledger['ranges']:
            data = b''.join(lines[row['start_line']-1:row['end_line']])
            check('contiguous read '+str(row['start_line']), row['start_line'] == end_line+1 and row['start_byte'] == end_byte and row['end_byte'] == end_byte+len(data) and row['sha256'] == sha(data) and row['bytes'] == len(data))
            end_byte, end_line = row['end_byte'], row['end_line']
        check('full source through EOF', end_byte == len(source) and end_line == len(lines) == 1567)
        check('no inline source tests', '#[test]' not in source.decode() and ledger['inline_tests'] == 0)
        context = obj('context-ledger.json')
        tui = read('capture/src/tui.rs')
        check('bounded TUI identity', sha(tui) == context['source_sha256'] and context['source_read_complete'] is False)
        for row in context['ranges']:
            data = b''.join(tui.splitlines(keepends=True)[row['start_line']-1:row['end_line']])
            check('context range '+row['path'], read(row['path']) == data and sha(data) == row['sha256'])
        count = 0
        for row in context['tests']:
            data = read(row['path'])
            check('context tests '+row['path'], row['fully_read'] and row['executed'] == 0 and len(data) == row['bytes'] and sha(data) == row['sha256'] and len(data.splitlines()) == row['lines'])
            count += data.count(b'#[test]')
        check('18 existing context tests, no execution', count == 18 and ledger['context_tests_executed'] == 0 and ledger['source_runs'] == 0)
        owned = obj('ownership.json')
        name = owned['owned_path']
        report = read('candidate/'+name)
        before = read('worker-before/'+name)
        check('one candidate report', {p for p in listed if p.startswith('candidate/')} == {'candidate/'+name})
        check('report identity', sha(report) == owned['candidate']['sha256'] and len(report) == owned['candidate']['bytes'])
        check('before identities', owned['master_before'] is None and sha(before) == owned['worker_before']['sha256'])
        for label, original in [('master',b''), ('worker',before)]:
            for reverse in [False, True]:
                a, b = (report,original) if reverse else (original,report)
                patch = ''.join(difflib.unified_diff(a.decode().splitlines(keepends=True),b.decode().splitlines(keepends=True),fromfile='a/'+name if a else '/dev/null',tofile='b/'+name if b else '/dev/null')).encode()
                check('exact scoped patch '+label+str(reverse), patch == read(label+('-rollback' if reverse else '')+'.patch') and len(patch) < 262144)
        defs = obj('definitions.json')['definitions']
        actual_defs = [dict(line=i,name=m.group(1)) for i,s in enumerate(source.decode().splitlines(),1) if (m:=re.match(r'\s*(?:pub\s+)?(?:const\s+)?fn\s+(\w+)',s))]
        check('77 definition navigation entries', defs == actual_defs and len(defs) == 77)
        for row in defs:
            check('report definition '+str(row['line']), ('| '+str(row['line'])+' |') in report.decode() and ('`'+row['name']+'`') in report.decode())
        check('old094 manifest untouched', sha(read('historical/zs1-094-ready/manifest.json')) == '013e06a06e650f9d17b606021b7c2f444eb43ee806ce5055443a949828375fc5')
        check('report-only counters', owned['product_mutations'] == [] and owned['main_mutations'] == [] and all(owned[k] == 0 for k in ['product_runs','cargo_runs','pty_runs','http_runs','release_runs','old_runner_runs']))
        check('explicit pending and limitations', all(x in report.decode() for x in ['[_]','Master','SessionList','手算','未执行','F2','F3','last_area','workspace_area','needs_migration']))
        check('verifier static review binding', sha(read('verify_packet.py')) == obj('verifier-static-review.json')['sha256'])
        status, error = 'pass', None
    except Exception as exc:
        status, error = 'fail', str(exc)
    result = dict(status=status,passed=sum(x['passed'] for x in checks),failed=sum(not x['passed'] for x in checks),error=error,checks=checks,structural_only=True,semantic_acceptance='Master pending',product_runs=0)
    if error and result['failed'] == 0:
        result['failed'] = 1
    print(json.dumps(result,indent=2))
    return 0 if status == 'pass' else 1


if __name__ == '__main__':
    sys.exit(main())
