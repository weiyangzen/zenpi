from pathlib import Path
import json,hashlib
M=Path('/Users/wangweiyang/GitHub/zenpi');O=Path('.ops/target080-full-3.1.21-20260913-ready');es=json.loads((O/'context-plan.json').read_text())
for rel,ranges in [('src/tui.rs',[(11668,11766),(13315,13370)]),('src/headless.rs',[(774,788),(4272,4292),(4333,4508),(4770,4815)]),('src/core.rs',[(5248,5270)]),('src/tools.rs',[(1000,1067),(1125,1201)])]:
 p=M/rel;b=p.read_bytes();ls=b.splitlines(keepends=True)
 for a,z in ranges:
  z=min(z,len(ls));data=b''.join(ls[a-1:z]);n=f'context/additional/{p.name}.L{a:04d}-{z:04d}.txt';q=O/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(data);es.append({'original':str(p),'whole_identity':{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()},'path':n,'line_start':a,'line_end':z,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'read':False})
(O/'context-plan.json').write_text(json.dumps(es,indent=2)+'\n');print(len(es))
