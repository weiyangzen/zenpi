from pathlib import Path
import json,hashlib,shutil
R=Path('/Users/wangweiyang/.codex/worktrees/38de/zenpi');M=Path('/Users/wangweiyang/GitHub/zenpi');U=Path('/Users/wangweiyang/GitHub/pi-mono');O=R/'.ops/target080-full-3.1.21-20260913-ready'
def ident(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def cp(p,n):
 q=O/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q);return q
es=[]
def part(root,rel,ranges):
 p=root/rel;b=p.read_bytes();ls=b.splitlines(keepends=True)
 for a,z in ranges:
  z=min(z,len(ls));n=f'context/{rel.replace("/","_")}.L{a:04d}-{z:04d}.txt';q=O/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b''.join(ls[a-1:z]));es.append({'original':str(p),'whole_identity':ident(p),'path':n,'line_start':a,'line_end':z,**ident(q),'read':False})
cp(M/'tests/extensions.rs','context/full/tests/extensions.rs');part(M,'tests/extensions.rs',[(1,190)])
part(M,'src/extension_runtime.rs',[(1,240),(241,440),(441,647),(648,744)])
part(M,'src/core.rs',[(646,677),(1237,1261),(2104,2210),(2211,2272),(3353,3388),(3549,3615),(3660,3731),(3980,4026),(4500,4585),(4650,4717),(5170,5247),(5850,5877),(6009,6171)])
part(M,'src/security.rs',[(410,440)]);part(M,'src/main.rs',[(1,20)])
part(U,'packages/coding-agent/src/core/extensions/runner.ts',[(927,1070),(1246,1320)])
rs=[]
for item in ['ZS1-001']:
 p=M/'Docs/learn/stage1_pi_mono/receipts'/f'{item}.master.json';n='context/receipts/'+p.name;cp(p,n);v=json.loads(p.read_text());arts=[]
 for f in v['artifacts']:
  q=cp(M/f['path'],'context/receipt-artifacts/'+f['path']);arts.append({'declared':f,'copy':q.relative_to(O).as_posix(),'observed':ident(q)})
 rs.append({'item_id':item,'original':str(p),'copy':n,**ident(p),'artifacts':arts})
(O/'context-receipts.json').write_text(json.dumps(rs,indent=2)+'\n');(O/'context-plan.json').write_text(json.dumps(es,indent=2)+'\n')
print(json.dumps({'segments':len(es),'lines':sum(e['line_end']-e['line_start']+1 for e in es),'tests':ident(O/'context/full/tests/extensions.rs')}))
