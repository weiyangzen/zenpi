from pathlib import Path
import tarfile,json,hashlib
O=Path('.ops/target080-full-3.1.21-20260913-ready');P=O/'prior/target080-review-3.1.20-ready/files/Docs/quality/stage1/ZS1-080/worker-target-review-3.1.20';rows=[]
choices={'historical080-owner.tar.gz':['files/Docs/quality/stage1/ZS1-080/worker-owner-review/g-stage-main-before-integration.log'],'historical115-selected.tar.gz':['hooks/acceptance-final.json','hooks/acceptance-final.log','pipe/files/Docs/quality/stage1/ZS1-115/worker-pipe-deadline/prescribed-native-final.json','pipe/files/Docs/quality/stage1/ZS1-115/worker-pipe-deadline/prescribed-native-final.log','pipe/files/Docs/quality/stage1/ZS1-115/worker-pipe-deadline/prescribed-final-bounded-concurrency.log']}
for name,members in choices.items():
 with tarfile.open(P/name) as t:
  for member in members:
   with t.extractfile(member) as f:b=f.read()
   n='history-read/'+name.removesuffix('.tar.gz')+'/'+member;q=O/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);rows.append({'archive':str((P/name).relative_to(O)),'member':member,'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'read':False})
(O/'history-read-plan.json').write_text(json.dumps(rows,indent=2)+'\n');print([(r['path'],r['bytes']) for r in rows])
