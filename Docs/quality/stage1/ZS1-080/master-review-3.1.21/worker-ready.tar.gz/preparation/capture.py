from pathlib import Path
import datetime,hashlib,json,shutil,subprocess,difflib
R=Path('/Users/wangweiyang/.codex/worktrees/38de/zenpi');M=Path('/Users/wangweiyang/GitHub/zenpi');O=R/'.ops/target080-full-3.1.21-20260913-ready';O.mkdir()
def ident(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(n,x):
 p=O/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def cp(p,n):
 q=O/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q);return q
p=cp(M/'src/extensions.rs','target/src/extensions.rs');b=p.read_bytes();ls=b.splitlines(keepends=True);cs=[];off=0
for a in range(1,len(ls)+1,250):
 z=min(a+249,len(ls));data=b''.join(ls[a-1:z]);n=f'chunks/extensions.L{a:04d}-{z:04d}.rs';q=O/n;q.parent.mkdir(exist_ok=True);q.write_bytes(data);cs.append({'path':n,'line_start':a,'line_end':z,'byte_start':off,'byte_end':off+len(data),**ident(q),'read':False});off+=len(data)
save('chunk-plan.json',cs)
prior=[]
for n in ['target080-review-3.1.20-ready','extension-resume-startup-audit-ready']:
 p=R/'.ops'/n;shutil.copytree(p,O/'prior'/n);prior.append({'original':str(p),'copy':'prior/'+n,'manifest':ident(p/'manifest.json'),'files':[{'path':q.relative_to(p).as_posix(),**ident(q)} for q in sorted(p.rglob('*')) if q.is_file()]})
save('prior-identities.json',prior)
for rel in ['Docs/execution/active_requirement.json','Docs/stage_1_v3_pi_mono_blueprint.md','Docs/learn/stage1_pi_mono/targets/zenpi/source_manifest.tsv','Docs/learn/stage1_pi_mono/targets/zenpi/file_learn_index.tsv']:cp(M/rel,'authority/'+rel)
owned='Docs/learn/stage1_pi_mono/targets/zenpi/files/src/extensions.rs_learn.md';cp(M/owned,'receiver-base.md') if (M/owned).exists() else (O/'receiver-base.md').write_bytes(b'')
status=subprocess.check_output(['git','status','--short','--untracked-files=all'],cwd=R,text=True).splitlines();status=[x for x in status if not x[3:].startswith('.ops/')]
save('capture.json',{'captured_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'subject':'src/extensions.rs',**ident(O/'target/src/extensions.rs'),'lines':len(ls),'source_read_complete':False,'owned_path':owned,'canonical_exists':(M/owned).exists(),'worker_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'worker_status':status,'worker_files':[{'path':str(R/x[3:]),**ident(R/x[3:])} for x in status if (R/x[3:]).is_file()],'new_product_executions':0})
protected=json.loads((R/'.ops/target077-full-3.1.21-20260913-ready/protected-identities.json').read_text());p=R/'.ops/target077-full-3.1.21-20260913-ready/manifest.json';protected.insert(0,{'path':str(p),**ident(p)});save('protected-identities.json',protected)
old=O/'prior/target080-review-3.1.20-ready/files/Docs/quality/stage1/ZS1-080/worker-target-review-3.1.20'
for label,n in [('baseline','baseline-extensions.rs'),('historical','current-extensions.rs')]:
 q=cp(old/n,'target/'+label+'-extensions.rs');(O/(label+'-to-current.diff')).write_text(''.join(difflib.unified_diff(q.read_text().splitlines(True),b.decode().splitlines(True),fromfile=label+'/src/extensions.rs',tofile='current/src/extensions.rs')))
save('assignment.json',{'item_id':'ZS1-080','authority':'3.1.21','snapshot':'3c01628b900c9078f7c1771f3638cc366b2e295c6fede7cfea191aa0620c5c2d','completed':53,'total':121,'requirement_digest':'3456abcbbebbc4e0ab383c319851b0a6e71b19ee9b3c060a6e212f61a89c9d9d','master_render_repair':'3 failures and tests in progress; excluded from worker reading and execution claims','model_and_effort':'existing task gpt-6-astra/high; no child tasks','allowed_new_product_executions':0,'max_offline_audit_invocations':1})
print(json.dumps({'source':ident(O/'target/src/extensions.rs'),'lines':len(ls),'chunks':len(cs),'prior_files':[len(p['files']) for p in prior],'worker_files':len(status),'owned_exists':(M/owned).exists()}))
