from pathlib import Path
import datetime,difflib,hashlib,json,shutil
R=Path('/Users/wangweiyang/.codex/worktrees/38de/zenpi');W=R/'.ops/stage1-worker/target080-full-3.1.21-20260913';O=R/'.ops/target080-full-3.1.21-20260913-ready'
owned='Docs/learn/stage1_pi_mono/targets/zenpi/files/src/extensions.rs_learn.md'
def identity(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
base=(O/'receiver-base.md').read_text();report=(O/'learn-report.md').read_text()
(O/'forward.patch').write_text(''.join(difflib.unified_diff(base.splitlines(True),report.splitlines(True),fromfile='/dev/null',tofile='b/'+owned)))
(O/'reverse.patch').write_text(''.join(difflib.unified_diff(report.splitlines(True),base.splitlines(True),fromfile='a/'+owned,tofile='/dev/null')))
(O/'preparation').mkdir()
for n in ['capture.py','prepare-context.py','add-context.py','add-registry-context.py','prepare-history.py','finalize-reading.py','freeze.py','run-once.py']:shutil.copyfile(W/n,O/'preparation'/n)
files=[{'path':p.relative_to(O).as_posix(),**identity(p)} for p in sorted(O.rglob('*')) if p.is_file()]
m={'schema_version':'zenpi-target-full-file-evidence/v2','item_id':'ZS1-080','status':'worker candidate; master review pending','owned_paths':[owned],'frozen_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'authority_version':'3.1.21','requirement_digest':'3456abcbbebbc4e0ab383c319851b0a6e71b19ee9b3c060a6e212f61a89c9d9d','assignment_snapshot':'3c01628b900c9078f7c1771f3638cc366b2e295c6fede7cfea191aa0620c5c2d','subject':{'path':'src/extensions.rs','lines':626,**identity(O/'target/src/extensions.rs')},'formal_dependencies':['ZS1-001'],'new_product_executions':0,'offline_audit':'At most one after full frozen script review; logs outside ready','files':files}
with (O/'manifest.json').open('x') as f:json.dump(m,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({'payload_files':len(files),'manifest':identity(O/'manifest.json'),'report':identity(O/'learn-report.md'),'forward':identity(O/'forward.patch'),'reverse':identity(O/'reverse.patch')}))
