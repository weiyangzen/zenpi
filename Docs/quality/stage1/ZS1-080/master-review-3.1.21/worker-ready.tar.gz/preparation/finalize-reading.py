from pathlib import Path
import json,hashlib,csv,re,shutil
O=Path('.ops/target080-full-3.1.21-20260913-ready');R=O.parent.parent

def ident(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(n,x): (O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
cs=json.loads((O/'chunk-plan.json').read_text());es=json.loads((O/'context-plan.json').read_text())
for xs in [cs,es]:
 for i,e in enumerate(xs,1):e.update(order=i,read=True)
s=(O/'target/src/extensions.rs').read_text();ts=(O/'context/full/tests/extensions.rs').read_text();idx=[]
for m in re.finditer(r'#\[test\]\s*fn\s+(?P<name>\w+)',ts):
 idx.append({'name':m['name'],'attribute_line':ts[:m.start()].count('\n')+1,'function_line':ts[:m.start('name')].count('\n')+1,'unix_only':m['name']!='capability_handles_are_scoped_opaque_and_revocable','ignored_helper':False,'read':True,'new_executions':0})
save('test-source-index.json',{'path':'context/full/tests/extensions.rs',**ident(O/'context/full/tests/extensions.rs'),'source_lines':180,'test_declarations':5,'ordinary_tests':5,'ignored_helpers':0,'unix_only':4,'subject_embedded_test_count':0,'new_executions':0,'declarations':idx})
save('definition-index.json',[{'line':i,'declaration':x.strip()} for i,x in enumerate(s.splitlines(),1) if re.match(r'\s*(pub(\([^)]*\))? )?(async )?(fn|struct|enum|const|type|static) ',x)])
q='prior/target080-review-3.1.20-ready/files/Docs/quality/stage1/ZS1-080/worker-target-review-3.1.20/'
names=['prior/target080-review-3.1.20-ready/files/Docs/learn/stage1_pi_mono/targets/zenpi/files/src/extensions.rs_learn.md',q+'README.md']
prefix='prior/extension-resume-startup-audit-ready/'
names += [prefix+x for x in ['index.md','recommendation.json','verified-0.stdout','verified-0.stderr','awk-verified-4.stdout','awk-verified-4.stderr','awk-verified-0.stdout','awk-verified-1.stdout','awk-verified-2.stdout','awk-verified-3.stdout','before.stdout','after.stdout','ux130-resume-test-isolated.log']]
docs=[{'path':n,**ident(O/n),'lines':len((O/n).read_bytes().splitlines()),'read':True,'new_executions':0} for n in names]
hs=json.loads((O/'history-read-plan.json').read_text())
for e in hs:e.update(read=True,new_executions=0)
docs+=hs
save('reading-ledger.json',{'source_full_read_complete':True,'embedded_test_count':0,'new_product_executions':0,'source_read_method':'3 continuous untruncated cat reads 1-250,251-500,501-626 before report; initial plans retained false','external_test_source_full_read_complete':True,'external_test_declarations':5,'chunks':cs,'context_reads':es,'historical_documents':docs,'baseline_full_read_this_task':False,'historical_source_full_read_this_task':False,'baseline_to_current_diff_full_read':True,'historical_to_current_diff_empty':True,'full_runtime_test_suffix_read':False,'render_read':False})
with (O/'chunk_manifest.tsv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=['order','path','line_start','line_end','byte_start','byte_end','bytes','sha256','read'],delimiter='\t');w.writeheader();w.writerows([{k:e[k] for k in w.fieldnames} for e in cs])
(O/'source_manifest.tsv').write_text('source_id\tsource_path\tsource_bytes\tsource_hash\ttarget_artifact\tmapping_mode\tstatus\nZS1-080\tsrc/extensions.rs\t20742\t38a242eff3ec911f4560e3dea3868b742d511205ff0ccab1b622962b41e420ed\tDocs/learn/stage1_pi_mono/targets/zenpi/files/src/extensions.rs_learn.md\tunderstand\t[_]\n')
mapping=[(1,95,'data declarations/default timeout','1'),(96,158,'manifest validation','1'),(159,267,'catalogue paths ordering and bounds','2'),(268,314,'staged registration','3'),(315,357,'process tool invocation','3'),(358,380,'install publication','4'),(381,390,'remove','4'),(391,430,'upgrade rollback limits','4'),(431,450,'disabled state and temp','4'),(451,470,'recursive copy','4'),(471,525,'permissions and lexical helpers','5'),(526,548,'legacy capability data','5'),(549,577,'capability issue','5'),(578,596,'authorize revoke revoke_subject','5'),(597,626,'clock and errors','5')]
save('semantic-map.json',[{'source_path':'src/extensions.rs','line_start':a,'line_end':z,'meaning':what,'report_section':sec,'read':True,'new_product_executions':0} for a,z,what,sec in mapping])
save('route-decision.json',{'target_object':'ZS1-080 src/extensions.rs complete understanding candidate','instrument_objects':['execution-cron-builder','learn-cron-builder understand','continuous source reading ledger','frozen standard-library structural auditor'],'operator_override':{'model':'existing gpt-6-astra','reasoning':'high','source_files':1,'worker_count':1,'new_child_tasks':0,'new_product_executions':0,'max_offline_audit_invocations':1,'write_scope':'private .ops only'},'estimated_parameters':{'source_chunk_lines':250,'context_segments':len(es),'validator':'identity/coverage/patch/archive read-only structural audit'},'rationale':'626 source lines fit3 complete untruncated reads; runtime and real host lifecycle require bounded contexts; no behavior validation authorized','master_state':'[_]','authority_acceptance_owner':'master only'})
save('reading-notes.json',{'new_product_executions':0,'new_audit_invocations_so_far':0,'notes':['Initial broad search included irrelevant historical AGENTS; actual applicable paths contain only an empty ancestor AGENTS.','execution skill display was truncated; missing middle was fully reread; bridge and learn skill/coverage contract read.','A multi-file cat used guessed clamped endpoint names tests184 and upstream1320; those paths did not exist. Actual plan endpoints180 and1286 were then fully read. Other outputs in that call were read.','Old report read1-44,45-84,85-118, not reused as source reading.','No old script, test binary or fixture was executed.']})
save('looper-log.json',{'log_id':'ZS1-080-read-display','grain':'tool','target_object':{'ref':'ZS1-080','desired_movement':'complete source understanding candidate'},'instrument_object':{'ref':'read command endpoint selection/output sizing','observed_effect':'wrong guessed file endpoint caused two read errors; large skill output required bounded reread','change_authority':'evidence_only'},'evidence_refs':['reading-notes.json','context-plan.json','reading-ledger.json'],'outcome':{'master_state':'[_]'},'improvement_suggestions':['Use recorded endpoint filenames and bounded read output.'],'instrument_policy_changed':False})
prot=json.loads((O/'protected-identities.json').read_text())
for n in ['invocation-guard.json','offline.result.json','offline.stdout.json','offline.stderr.log']:
 p=R/'.ops/stage1-worker/target077-full-3.1.21-20260913'/n;prot.append({'path':str(p.resolve()),**ident(p)})
save('protected-identities.json',prot)
(O/'README.md').write_text('''# ZS1-080 frozen report candidate [_]

Only owned report: Docs/learn/stage1_pi_mono/targets/zenpi/files/src/extensions.rs_learn.md. Current20742B/626lines fully read in3 continuous chunks, zero embedded tests. Entire tests/extensions.rs6302B/180lines and5 ordinary tests read.32 context segments and21 historical document/log/receipt views read. Formal dependency001 only. Product executions0; historical60/116 and startup pass/fail are not new runs.

Complete old08019files and startup72files preserved, with103 nested archive members and216 startup build inputs. Source current equals old current; baseline23071B separate. Main report absent; empty receiver-base, forward/reverse touch only report. No patch applied, no canonical or authority changes. Initial read-plan false is historical, completion ledger true. Reading errors and corrected reads retained in reading-notes; no audit used during preparation.

Read entire frozen audit-offline.py and wrapper before the sole permitted offline audit; invoke external work-directory run-once.py at most once. All execution logs/guard/result stay outside frozen ready. Never rerun on failure; never execute historical scripts, product tests or fixtures. Structural success is not semantic acceptance. Main master owns acceptance.077/074/073/072/070,059-062,117 and94 existing non.ops worker files remain protected. After handoff stop.
''')
print(json.dumps({'contexts':len(es),'history_reads':len(docs),'report':ident(O/'learn-report.md'),'ledger':ident(O/'reading-ledger.json'),'startup_inputs':len(json.loads((O/(prefix+'inputs.json')).read_text()))}))
