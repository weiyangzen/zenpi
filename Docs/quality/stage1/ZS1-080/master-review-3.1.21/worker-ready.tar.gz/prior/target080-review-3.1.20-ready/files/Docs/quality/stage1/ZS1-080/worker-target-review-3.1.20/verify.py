#!/usr/bin/env python3
"""Offline single-file080 evidence and reversible Docs packet verification; no behavior runs."""
import argparse,difflib,hashlib,json,re,subprocess,tarfile,tempfile
from pathlib import Path,PurePosixPath
ENTRY='Docs/quality/stage1/ZS1-080/worker-target-review-3.1.20'
REPORT='Docs/learn/stage1_pi_mono/targets/zenpi/files/src/extensions.rs_learn.md'
def sha(b):return hashlib.sha256(b).hexdigest()
def checked(b,f):assert len(b)==f['bytes'] and sha(b)==f['sha256'],f

def archive(e,n,index):
 checked((e/n).read_bytes(),index)
 with tarfile.open(e/n) as t:
  members=t.getmembers();assert len(members)==len(index['members']);assert {m.name for m in members}==set(index['members']);result={}
  for m in members:
   p=PurePosixPath(m.name);assert m.isfile() and not m.issym() and not m.islnk() and not p.is_absolute() and '..' not in p.parts
   b=t.extractfile(m).read();checked(b,index['members'][m.name]);result[m.name]=b
 return result

def verify(root,live=False):
 e=root/ENTRY;coverage=json.loads((e/'read-coverage.json').read_text());expected={
 'baseline-extensions.rs':(23071,685,'9b1879edcfb70e711960092e12060a9137e2aacda6bdc547318e5ccb7510fe39',0),
 'current-extensions.rs':(20742,626,'38a242eff3ec911f4560e3dea3868b742d511205ff0ccab1b622962b41e420ed',0),
 'tests__extensions.rs':(6302,180,'00a3873257e010a9fdd337d8b913fda3f2efe101710c45ae225975ab59c2237d',5)}
 assert {x['path'] for x in coverage['inputs']}==set(expected)
 for f in coverage['inputs']:
  b=(e/f['path']).read_bytes();checked(b,f);ls=b.splitlines(True);assert (len(b),len(ls),sha(b),b.count(b'#[test]'))==expected[f['path']]
  first=1;offset=0
  for c in f['chunks']:
   assert (first,offset)==(c['first_line'],c['byte_start']);raw=b''.join(ls[first-1:c['last_line']]);assert sha(raw)==c['sha256'];offset+=len(raw);first=c['last_line']+1;assert offset==c['byte_end']
  assert offset==len(b) and first==len(ls)+1
 amap=json.loads((e/'assertion-map.json').read_text());ls=(e/'tests__extensions.rs').read_text().splitlines();actual=[]
 for i,s in enumerate(ls):
  if s.strip()=='#[test]':
   j=i+1
   while not re.search(r'fn (\w+)\(',ls[j]):j+=1
   actual.append((re.search(r'fn (\w+)\(',ls[j]).group(1),j+1))
 assert actual==[(t['name'],t['declaration_line']) for t in amap['tests']] and len(actual)==5
 assert all(t['assertions'] for t in amap['tests'])
 idx=json.loads((e/'historical-evidence-index.json').read_text());archives={n:archive(e,n,f) for n,f in idx['archives'].items()}
 old=archives['historical080-owner.tar.gz'];assert sha(old['manifest.json'])==idx['old080_manifest_sha256']=='bee401d15307e83db4eac2a85cd8a66916f2e747e339d89d8e97b06f8f9fbca1';m=json.loads(old['manifest.json'])
 for f in m['files']:
  checked(old['files/'+f['path']],f);assert len(old['base/'+f['path']])==f['base_bytes'] and sha(old['base/'+f['path']])==f['base_sha256'];assert sha(old['patches/'+f['path'].replace('/','__')+'.patch'])==f['patch_sha256']
 assert sha(old['candidate.patch'])==m['patch_sha256'] and len(old['candidate.patch'])==m['patch_bytes'];assert sha(old['run_candidate_probe.py'])==m['runner_sha256']
 preserved=old['files/'+REPORT];checked(preserved,idx['old080_report']);assert len(preserved)==22647 and sha(preserved)=='1edc6316dce1dfc858523dc2b820c88877b901b1de954e076962bec8785bcc7e';assert (root/REPORT).read_bytes().startswith(preserved)
 prefix='files/Docs/quality/stage1/ZS1-080/worker-owner-review/';assert preserved.startswith(old[prefix+'prior-report.md'])
 receipt=json.loads(old[prefix+'g-stage-main-before-integration.json']);assert receipt['exit_code']==1;checked(old[prefix+'g-stage-main-before-integration.log'],receipt);assert not json.loads(old[prefix+'g-stage-main-before-integration.log'])['ok']
 history=archives['historical115-selected.tar.gz'];assert sha(history['original-ready/manifest.json'])==idx['original115_manifest_sha256']=='300d3a1cb9c7c58ecee77a459e6846637bc9354bfdedf2996f10fb1f6bf6a2f4';m=json.loads(history['original-ready/manifest.json'])
 for f in m['files']:
  checked(history['original-ready/files/'+f['path']],f);assert sha(history['original-ready/base/'+f['path']])==f['base_sha256'] and len(history['original-ready/base/'+f['path']])==f['base_bytes'];patch=history['original-ready/patches/'+f['path'].replace('/','__')+'.patch'];assert sha(patch)==f['patch_sha256'] and len(patch)==f['patch_bytes']
 assert history['original-ready/base/src/extensions.rs']==(e/'baseline-extensions.rs').read_bytes();assert history['original-ready/files/src/extensions.rs']==(e/'current-extensions.rs').read_bytes()
 assert sha(history['pipe/manifest.json'])==idx['pipe_manifest_sha256']=='7e2157de5a1fece65b1aba807a0aadb4788e433004b54ff65b75d59b95b60856';pm=json.loads(history['pipe/manifest.json']);lookup={f['path']:f for f in pm['files']}
 for n,b in history.items():
  if n.startswith('pipe/files/'):checked(b,lookup[n[len('pipe/files/'):]])
 prefix='pipe/files/Docs/quality/stage1/ZS1-115/worker-pipe-deadline/'
 for stem,code in [('prescribed-native-final',0),('prescribed-final-bounded-concurrency',101)]:
  receipt=json.loads(history[prefix+stem+'.json']);assert receipt['exit_code']==code;checked(history[prefix+stem+'.log'],receipt)
 receipt=json.loads(history['hooks/acceptance-final.json']);assert receipt['exit_code']==0;checked(history['hooks/acceptance-final.log'],receipt)
 counts=lambda b:[int(n) for n in re.findall(rb'test result: ok\. (\d+) passed;',b)]
 assert counts(history['hooks/acceptance-final.log'])==[8,5,17,30];assert counts(history[prefix+'prescribed-native-final.log'])==[56,8,5,17,30]
 assert b'55 passed; 1 failed; 1 ignored;' in history[prefix+'prescribed-final-bounded-concurrency.log'] and b'fixture never escaped' in history[prefix+'prescribed-final-bounded-concurrency.log']
 summary=json.loads(history[prefix+'final-summary.json']);assert summary['prescribed_and_lib_top_level_passes']==116 and summary['positive_native_scenarios']==12
 ctx=json.loads((e/'dependency-context.json').read_text());deps=archives['dependency-context.tar.gz'];assert set(deps)==set(ctx['files'])
 for n,f in ctx['files'].items():checked(deps[n],f);assert f['captured_at'] and not f['full_read'];assert all(1<=a<=z<=f['lines'] for a,z in f['read_intervals'])
 oldruntime=history['pipe/files/src/extension_runtime.rs'];checked(oldruntime,ctx['historical_pipe_runtime']);runtime=deps['src/extension_runtime.rs'];marker=b'#[cfg(all(test, unix))]\nmod pipe_deadline_tests';prefixbytes=oldruntime[:oldruntime.index(marker)];assert prefixbytes==runtime[:runtime.index(marker)];checked(prefixbytes,ctx['runtime_production_prefix']);assert oldruntime!=runtime
 native=(e/'historical-native-fixture-manifest.json').read_bytes();assert sha(native)==ctx['native_fixture_manifest_sha256']=='5310564998d526a927cba97d6e4853edf4319043bf61978896ac0f2682977a78';nm=json.loads(native);f=next(x for x in nm['files'] if x['path']=='tests/stage1_extension_hooks.rs');checked(deps[f['path']],f);checked(history['original-ready/files/tests/stage1_extension_hooks.rs'],ctx['original_hook_tests']);assert deps[f['path']]!=history['original-ready/files/tests/stage1_extension_hooks.rs']
 startup=archives['historical-startup-selected.tar.gz'];assert sha(startup['manifest.json'])==idx['startup_manifest_sha256'];sm=json.loads(startup['manifest.json']);sl={f['path']:f for f in sm['files']}
 for n,b in startup.items():
  if n!='manifest.json':checked(b,sl[n])
 rec=json.loads(startup['recommendation.json']);assert rec['recommended_patch'] is None and rec['awk_actual_results']==['pass']*4+['fail'] and not rec['product_changes']
 assert b'test result: ok. 1 passed;' in startup['before.stdout'];assert b'test result: FAILED. 0 passed; 1 failed;' in startup['verified-0.stdout'];assert b'CommandTimeout(1000)' in startup['verified-0.stderr']
 for i in range(5):assert (b'test result: ok. 1 passed;' if i<4 else b'test result: FAILED. 0 passed; 1 failed;') in startup[f'awk-verified-{i}.stdout']
 assert b'CommandTimeout(1000)' in startup['awk-verified-4.stderr'] and b'CommandTimeout(1000)' in startup['ux130-resume-test-isolated.log']
 changes=json.loads((e/'change-map.json').read_text());a=(e/'baseline-extensions.rs').read_text().splitlines(True);b=(e/'current-extensions.rs').read_text().splitlines(True);actual=[dict(operation=t,baseline_first=x+1,baseline_last=y,current_first=z+1,current_last=w) for t,x,y,z,w in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes() if t!='equal'];assert changes['baseline_to_current']==actual and changes['historical115_subject_equal']
 assert coverage['new_behavior_runs']==amap['new_behavior_runs']==idx['new_behavior_runs']==0
 if live:
  main=Path('/Users/wangweiyang/GitHub/zenpi')
  for src,dest in [('src/extensions.rs','current-extensions.rs'),('tests/extensions.rs','tests__extensions.rs')]:assert (main/src).read_bytes()==(e/dest).read_bytes(),src+' drift'
 return dict(baseline_lines=685,current_lines=626,inline_tests=0,companion_tests_reviewed=5,old_report_prefix_bytes=22647,archived_files=sum(len(x) for x in archives.values()),historical_original_acceptance_passes=60,historical_pipe_top_level_passes=116,overlapping_passes_not_summed=True,production_runtime_prefix_equal_bytes=len(prefixbytes),historical_failures_retained=['080 missing master receipt','pipe fixture never escaped','B isolated resume startup','native then awk startup failures'],new_behavior_runs=0,live_subject_primary_test_checked=live)

def packet_check(packet):
 m=json.loads((packet/'manifest.json').read_text());files=m['files'];assert len({x['path'] for x in files})==len(files)
 for f in files:
  p=PurePosixPath(f['path']);assert not p.is_absolute() and '..' not in p.parts and p.parts[0]=='Docs' and f['receiver_base']=='absent';checked((packet/'files'/f['path']).read_bytes(),f)
 patch=(packet/'candidate.patch').resolve();checked(patch.read_bytes(),m['patch'])
 with tempfile.TemporaryDirectory(prefix='target080-roundtrip-') as tmp:
  r=Path(tmp)
  def git(*a):subprocess.run(['git','-C',tmp,*a],check=True,capture_output=True,timeout=30)
  git('init','-q');git('apply','--check',str(patch));git('apply',str(patch))
  for f in files:checked((r/f['path']).read_bytes(),f)
  assert {str(x.relative_to(r)) for x in r.rglob('*') if x.is_file() and '.git' not in x.relative_to(r).parts}=={f['path'] for f in files};verify(r)
  git('apply','--reverse','--check',str(patch));git('apply','--reverse',str(patch));assert not any(x.is_file() for x in (r/'Docs').rglob('*'))
 return dict(files=len(files),forward='exact bytes and file set',reverse='all candidate paths absent')

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[5]);p.add_argument('--live',action='store_true');p.add_argument('--packet',type=Path);a=p.parse_args();out=verify(a.root.resolve(),a.live)
 if a.packet:out['packet']=packet_check(a.packet.resolve())
 print(json.dumps(out,indent=2))
if __name__=='__main__':main()
