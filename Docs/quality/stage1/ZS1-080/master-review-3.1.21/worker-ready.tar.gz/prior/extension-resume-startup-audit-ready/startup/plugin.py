#!/usr/bin/python3
import json,sys
r=json.loads(sys.stdin.readline()); p=r['params']; method=r['method']
with open('events','a') as f:
    f.write(json.dumps({'kind':p.get('hook',method),'capability':r['capability']})+'\n')
if method=='initialize': result={'api_version':2,'hooks':p['hooks'],'tools':[t['name'] for t in p['tools']]}
elif method=='tools/call': result={'echo':p['arguments']}
else: result={'action':'continue'}
print(json.dumps({'jsonrpc':'2.0','id':r['id'],'capability':r['capability'],'result':result}))
