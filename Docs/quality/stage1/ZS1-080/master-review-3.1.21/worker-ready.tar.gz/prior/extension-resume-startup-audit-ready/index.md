# Extension resume fixture startup investigation

Status: investigation delivered; no verified test repair is recommended. No product code, 1000ms hook budget, or original resume/lease assertion is changed in the proposed deliverable. The native and awk diffs are rejected experiments, explicitly not integration candidates.

Master requested investigation of `core::extension_resume_commit_tests::rejected_resume_commit_keeps_old_extension_live_until_successful_retry`, after B's isolated run failed in `configure_extensions` with Tool(CommandTimeout(1000)). B's broader log had passed that same test while unrelated pipe-deadline tests failed. Both B logs are retained unchanged, with source attribution. Their commands were not blindly executed.

Baseline is a new read-only current-main snapshot containing 216 build inputs, including all 77 vendor files and the current Cargo patch. This is separate from the earlier pre131 104 packet. The local original unmodified test passed, taking 1.35s for its whole sequence of separately-budgeted hook calls. This must not be reported as a locally reproduced original failure; B's independent failure is the actual original-failure evidence.

## Observations

1. The source starts an executable `plugin.py` with `#!/usr/bin/python3`, one subprocess for each initialize/hook/tool request. `exchange_frame` includes spawn, stdin/stdout, and child exit in the original 1000ms deadline. `configure_extensions` runs before any failed-resume/successful-retry assertion. A startup timeout there therefore prevents the actual test precondition from being established.
2. Direct execution of the exact original script, fixed initialize JSON and minimal PATH environment took 458ms first, then about 68–70ms in five repeats; Popen itself returned in about 1.1–1.3ms. Python `-S` still took about 60ms. These measurements do not support blaming only site customization/imports.
3. Fresh-path first-output measurement was 943ms for Python, followed by 65ms for the same file; native 406ms followed by 3.5ms; awk 200ms followed by 4.4ms. Native fixture timestamps measured only about 0.25ms from native entry to reply in the 406ms run. This points to startup before fixture protocol behavior, not the resume state machine. It does not identify a specific macOS security service, kernel queue, or scheduling cause.
4. A small native fixture preserved original initialization fields, dynamic request ID/capability and argument echo. It initially passed the actual complete resume test, but a subsequent unchanged-assertion run failed at configure_extensions after 1.11s. The retained evidence directory had compiler output/script binary but no events or reply phase log. Native startup is therefore not a verified reliable repair. An earlier direct first native launch also timed out at one second; subsequent identical launches succeeded in 3–11ms.
5. An awk fixture removed both Python and a newly compiled Mach-O image. Actual full resume test runs passed four times, producing all nine real protocol events each. A fifth fresh-fixture run failed at configure_extensions after 1.01s, with no events file and near-zero reported CPU time. Its rare startup failure must not be hidden by quoting only the four passes. The first direct awk launch also exceeded one second before its later successful runs.
6. Python/native/awk protocol outputs were compared for initialize, session hook and tools/call with opaque capability, changed numeric IDs, nested arrays/objects, quotes, slashes, newline and Unicode. Parsed replies are equal for the fixture's declared single tool. This establishes fixture equivalence in the intended scenario, not general implementation of all JSON-RPC extension behavior.

## Preserved contract and limits

Both rejected test-only variants retained `hook_timeout_ms = 1000`. All original operations/assertions from the comment preceding Agent setup through the end of the test are byte-identical; that tail has SHA256 `2131e38447663e19f401604f2b3720ca55cedeca1b6f8aa0b19af592f2e8255c`. Original checks cover old session/sequence/registry identity after a rejected commit, active old lease, initialize/start counts, actual old tool invocation, successful retry, old lease revocation, exactly one close/two start events, checkpoint identity, old registry rejection and new registry success.

No product deadline or retry code was altered. No prewarming/setup execution was inserted into the actual test; native compilation alone occurred during fixture construction. The diagnostics allowed up to three/five seconds to *measure* startup when necessary, but no such timeout was given to the real owner hook test. The actual failed owner runs still fail at 1000ms.

The reliable finding is narrower than a code fix: the flaky assertion is blocked by initial fixture startup, and changing the fixture language alone does not remove the failure. No evidence establishes a defect in resume commit ordering, lease retirement or the 1000ms deadline implementation. A later change could explicitly establish fixture-start readiness before this resume-only scenario, but that changes the setup assumption and must be described as such; it is not included or claimed here. Startup deadline behavior should remain independently tested.

## Evidence map

- `ux130-resume-test-isolated.log`, `ux130-core-tests.log`: B's original failure and broader mixed result, unchanged.
- `before.stdout/stderr`: local original test pass. `after.stdout/stderr`: initial native complete-test pass, superseded as a reliability conclusion by the retained later failure.
- `native-commands.json`, `verified-0.*`, `verified-0/`: measured native candidate failure and artifacts; no events file before failure.
- `awk-commands.json`, `awk-verified-0..4.*` and directories: four full original-assertion passes followed by one failure; no sixth run was performed after the counterexample.
- `startup/timings.json`, `fresh-path-timings.json`, `native-timings.json`, `launch-forms.json`: separate diagnostic timing and exact output data. `native-first-launch.txt` explicitly identifies the direct timeout that was observed in a tool result before the diagnostic script saved timing JSON.
- `startup/protocol-parity.json`, `awk-parity.json`: fixed inputs and parsed output equality, with executable boundary recorded.
- `rejected-native-fixture.patch`, `rejected-awk-fixture.patch`: rejected experiments only. They must not be applied as a validated fix.

The exact concrete OS mechanism behind the startup delay remains unproven. This audit does not claim all extension tests pass or resolve B's separate escaped-pipe failures. No broader test suite was rerun. The work returns to the scheduled 105→106→107 acceptance-support order after delivery.
