#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

typedef struct { const char *p; size_t n; } Slice;
static const char *ws(const char *p, const char *end) {
    while (p < end && isspace((unsigned char)*p)) ++p;
    return p;
}
/* Skip one bounded JSON value; preserve original ID/capability/argument bytes. */
static const char *value_end(const char *p, const char *end) {
    if (p == end) return NULL;
    if (*p == '"') {
        ++p;
        while (p < end) {
            if (*p == '\\') { if (++p == end) return NULL; ++p; }
            else if (*p++ == '"') return p;
        }
        return NULL;
    }
    if (*p == '{' || *p == '[') {
        char close = *p++ == '{' ? '}' : ']';
        while ((p = ws(p, end)) < end) {
            if (*p == close) return p + 1;
            if (*p == ',' || *p == ':') { ++p; continue; }
            p = value_end(p, end);
            if (!p) return NULL;
        }
        return NULL;
    }
    while (p < end && !strchr(",]} \t\r\n", *p)) ++p;
    return p;
}
static Slice member(Slice object, const char *key) {
    Slice missing = {NULL, 0};
    if (!object.p || !object.n || *object.p != '{') return missing;
    const char *end = object.p + object.n;
    const char *p = ws(object.p + 1, end);
    while (p < end && *p != '}') {
        if (*p != '"') return missing;
        const char *key_end = value_end(p, end);
        if (!key_end) return missing;
        int matches = (size_t)(key_end - p) == strlen(key) + 2 &&
                      memcmp(p + 1, key, strlen(key)) == 0;
        p = ws(key_end, end);
        if (p == end || *p++ != ':') return missing;
        p = ws(p, end);
        const char *next = value_end(p, end);
        if (!next || next == p) return missing;
        if (matches) { Slice result = {p, (size_t)(next - p)}; return result; }
        p = ws(next, end);
        if (p < end && *p == ',') p = ws(p + 1, end);
        else break;
    }
    return missing;
}
static void put(FILE *out, Slice value) {
    if (!value.p || fwrite(value.p, 1, value.n, out) != value.n) exit(70);
}
static int is(Slice value, const char *literal) {
    return value.p && value.n == strlen(literal) && memcmp(value.p, literal, value.n) == 0;
}
int main(void) {
    struct timespec started;
    if (clock_gettime(CLOCK_MONOTONIC, &started) != 0) return 71;
    char buffer[65536];
    if (!fgets(buffer, sizeof(buffer), stdin) || !strchr(buffer, '\n')) return 72;
    Slice request = {buffer, strlen(buffer)};
    Slice id = member(request, "id"), capability = member(request, "capability");
    Slice method = member(request, "method"), params = member(request, "params");
    Slice kind = member(params, "hook");
    if (!kind.p) kind = method;
    FILE *events = fopen("events", "a");
    if (!events) return 73;
    fputs("{\"kind\":", events); put(events, kind);
    fputs(",\"capability\":", events); put(events, capability);
    fputs("}\n", events); if (fclose(events) != 0) return 74;
    fputs("{\"jsonrpc\":\"2.0\",\"id\":", stdout); put(stdout, id);
    fputs(",\"capability\":", stdout); put(stdout, capability);
    fputs(",\"result\":", stdout);
    if (is(method, "\"initialize\"")) {
        fputs("{\"api_version\":2,\"hooks\":", stdout); put(stdout, member(params, "hooks"));
        fputs(",\"tools\":[\"fixture_echo\"]}", stdout);
    } else if (is(method, "\"tools/call\"")) {
        fputs("{\"echo\":", stdout); put(stdout, member(params, "arguments")); fputs("}", stdout);
    } else { fputs("{\"action\":\"continue\"}", stdout); }
    fputs("}\n", stdout); if (fflush(stdout) != 0) return 75;
    struct timespec finished;
    if (clock_gettime(CLOCK_MONOTONIC, &finished) != 0) return 76;
    FILE *phases = fopen("native-phases.log", "a");
    if (!phases) return 77;
    fprintf(phases, "pid=%ld native_entry=%lld.%09ld reply=%lld.%09ld\n",
        (long)getpid(), (long long)started.tv_sec, started.tv_nsec,
        (long long)finished.tv_sec, finished.tv_nsec);
    return fclose(phases) == 0 ? 0 : 78;
}
