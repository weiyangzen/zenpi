    }
    Ok(())
}

fn validate_relative_component_path(value: &str) -> Result<(), ExtensionError> {
    let path = Path::new(value);
    if value.is_empty()
        || value.len() > 4096
        || path.is_absolute()
        || path.components().any(|component| {
            matches!(
                component,
                std::path::Component::ParentDir
                    | std::path::Component::RootDir
                    | std::path::Component::Prefix(_)
            )
        })
    {
        return Err(ExtensionError::Invalid(
            "extension executable path is invalid".into(),
        ));
    }
    Ok(())
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum CapabilityScope {
    WorkspaceRead,
    WorkspaceWrite,
    CommandExecution,
    Network,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct CapabilityHandle {
    pub id: String,
    pub subject: String,
    pub scopes: BTreeSet<CapabilityScope>,
    pub expires_at_ms: u64,
}

#[derive(Debug, Default)]
pub struct CapabilityBroker {
    handles: BTreeMap<String, CapabilityHandle>,
    counter: AtomicU64,
}

impl CapabilityBroker {
    pub fn issue(
        &mut self,
        subject: &str,
        scopes: BTreeSet<CapabilityScope>,
        ttl: Duration,
    ) -> Result<CapabilityHandle, ExtensionError> {
        validate_id(subject)?;
        if scopes.is_empty() || ttl.is_zero() || ttl > Duration::from_secs(24 * 60 * 60) {
            return Err(ExtensionError::Invalid(
                "capability scope or lifetime is invalid".into(),
            ));
        }
        let now = now_ms();
        let serial = self.counter.fetch_add(1, Ordering::Relaxed);
        let mut digest = Sha256::new();
        digest.update(b"zenpi-capability-v1\0");
        digest.update(subject.as_bytes());
        digest.update(now.to_le_bytes());
        digest.update(serial.to_le_bytes());
        let handle = CapabilityHandle {
            id: format!("cap_{:x}", digest.finalize()),
            subject: subject.to_owned(),
            scopes,
            expires_at_ms: now.saturating_add(ttl.as_millis().min(u128::from(u64::MAX)) as u64),
        };
        self.handles.insert(handle.id.clone(), handle.clone());
        Ok(handle)
    }

    pub fn authorize(&self, id: &str, subject: &str, scope: CapabilityScope) -> bool {
        self.handles.get(id).is_some_and(|handle| {
            handle.subject == subject
                && handle.expires_at_ms >= now_ms()
                && handle.scopes.contains(&scope)
        })
    }

    pub fn revoke(&mut self, id: &str) -> bool {
        self.handles.remove(id).is_some()
    }

    pub fn revoke_subject(&mut self, subject: &str) -> usize {
        let before = self.handles.len();
        self.handles.retain(|_, handle| handle.subject != subject);
        before - self.handles.len()
    }
}

fn now_ms() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_millis()
        .min(u128::from(u64::MAX)) as u64
}

#[derive(Debug, Error)]
pub enum ExtensionError {
    #[error("extension I/O: {0}")]
    Io(#[from] std::io::Error),
    #[error("extension TOML: {0}")]
    Toml(#[from] toml::de::Error),
    #[error("invalid extension: {0}")]
    Invalid(String),
    #[error("extension path is denied: {0}")]
    Path(PathBuf),
    #[error("extension `{name}` requires API {found}; supported API is {supported}")]
    Incompatible {
        name: String,
        found: u32,
        supported: u32,
    },
    #[error("extension `{0}` is already installed")]
    AlreadyInstalled(String),
    #[error("extension tool: {0}")]
    Tool(String),
}
