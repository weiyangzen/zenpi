            }
            catalog.loaded.insert(
                manifest.name.clone(),
                LoadedExtension {
                    manifest,
                    directory,
                    executable,
                },
            );
            catalog.summaries.push(summary);
        }
        Ok(catalog)
    }

    pub fn summaries(&self) -> &[ExtensionSummary] {
        &self.summaries
    }

    pub fn register_tools(
        &self,
        registry: &mut crate::tools::ToolRegistry,
    ) -> Result<(), ExtensionError> {
        if self
            .loaded
            .values()
            .any(|extension| extension.manifest.api_version == EXTENSION_HOOK_API_VERSION)
        {
            return Err(ExtensionError::Invalid(
                "API 2 extensions require a session runtime".into(),
            ));
        }
        self.register_with_lease(registry, None)
    }

    pub(crate) fn register_with_lease(
        &self,
        registry: &mut crate::tools::ToolRegistry,
        lease: Option<crate::extension_runtime::ExtensionLease>,
    ) -> Result<(), ExtensionError> {
        let mut candidate = registry.clone();
        for extension in self.loaded.values() {
            for tool in &extension.manifest.tools {
                candidate
                    .register_boxed(Box::new(LocalProcessTool {
                        definition: ToolDefinition {
                            name: tool.name.clone(),
                            description: tool.description.clone(),
                            input_schema: tool.input_schema.clone(),
                            side_effect: tool.side_effect,
                        },
                        extension: extension.clone(),
                        lease: lease.clone(),
                    }))
                    .map_err(|error| ExtensionError::Tool(error.to_string()))?;
            }
        }
        *registry = candidate;
        Ok(())
    }
}

#[derive(Debug, Clone)]
struct LocalProcessTool {
    definition: ToolDefinition,
    extension: LoadedExtension,
    lease: Option<crate::extension_runtime::ExtensionLease>,
}

impl Tool for LocalProcessTool {
    fn definition(&self) -> ToolDefinition {
        self.definition.clone()
    }

    fn invoke(
        &self,
        context: &ToolContext,
        arguments: &Map<String, Value>,
    ) -> Result<Value, ToolError> {
        self.invoke_cancellable(context, arguments, &|| false)
    }

    fn invoke_cancellable(
        &self,
        context: &ToolContext,
        arguments: &Map<String, Value>,
        cancelled: &dyn Fn() -> bool,
    ) -> Result<Value, ToolError> {
        if !permission_allows(
            &self.extension.manifest.permissions,
            self.definition.side_effect,
        ) {
            return Err(ToolError::PolicyDenied {
                tool: self.definition.name.clone(),
                side_effect: self.definition.side_effect,
            });
        }
        crate::extension_runtime::process_request(
            &self.extension,
            context.workspace_root(),
            self.lease.as_ref(),
            "tools/call",
            json!({"name":self.definition.name,"arguments":arguments}),
            Duration::from_secs(30),
            cancelled,
        )
    }
}

pub fn install(root: &Path, source: &Path) -> Result<ExtensionSummary, ExtensionError> {
    if !source.is_dir() {
        return Err(ExtensionError::Path(source.to_owned()));
    }
    let text = fs::read_to_string(source.join(EXTENSION_MANIFEST))?;
    let manifest: ExtensionManifest = toml::from_str(&text)?;
    manifest.validate()?;
    fs::create_dir_all(root)?;
    let destination = root.join(&manifest.name);
    let staging = root.join(format!(".{}.installing", manifest.name));
    if destination.exists() || staging.exists() {
        return Err(ExtensionError::AlreadyInstalled(manifest.name));
    }
    copy_tree(source, &staging)?;
    fs::rename(&staging, &destination)?;
    let catalog = ExtensionCatalog::load(root)?;
    catalog
        .summaries
        .into_iter()
        .find(|summary| summary.name == manifest.name)
        .ok_or_else(|| ExtensionError::Invalid("installed extension did not load".into()))
}

pub fn remove(root: &Path, name: &str) -> Result<bool, ExtensionError> {
    validate_id(name)?;
    let path = root.join(name);
    if !path.exists() {
        return Ok(false);
    }
    fs::remove_dir_all(path)?;
    Ok(true)
}

pub fn upgrade(root: &Path, source: &Path) -> Result<ExtensionSummary, ExtensionError> {
    if !source.is_dir() {
        return Err(ExtensionError::Path(source.to_owned()));
    }
    let text = fs::read_to_string(source.join(EXTENSION_MANIFEST))?;
    let manifest: ExtensionManifest = toml::from_str(&text)?;
    manifest.validate()?;
    let destination = root.join(&manifest.name);
    if !destination.is_dir() {
        return Err(ExtensionError::Path(destination));
    }
    let staging = root.join(format!(".{}.upgrading", manifest.name));
    let backup = root.join(format!(".{}.backup", manifest.name));
    if staging.exists() || backup.exists() {
        return Err(ExtensionError::Invalid(
            "a previous extension upgrade needs cleanup".into(),
        ));
    }
    copy_tree(source, &staging)?;
    fs::rename(&destination, &backup)?;
    if let Err(error) = fs::rename(&staging, &destination) {
        let _ = fs::rename(&backup, &destination);
        return Err(error.into());
    }
    let catalog = match ExtensionCatalog::load(root) {
        Ok(catalog) => catalog,
        Err(error) => {
            let _ = fs::remove_dir_all(&destination);
            let _ = fs::rename(&backup, &destination);
            return Err(error);
        }
    };
    fs::remove_dir_all(backup)?;
    catalog
        .summaries
        .into_iter()
        .find(|summary| summary.name == manifest.name)
        .ok_or_else(|| ExtensionError::Invalid("upgraded extension did not load".into()))
}

pub fn set_disabled(root: &Path, name: &str, disabled: bool) -> Result<bool, ExtensionError> {
    validate_id(name)?;
    let path = root.join(name).join(EXTENSION_MANIFEST);
    if !path.is_file() {
        return Err(ExtensionError::Path(path));
    }
    let text = fs::read_to_string(&path)?;
    let mut manifest: ExtensionManifest = toml::from_str(&text)?;
    if manifest.disabled == disabled {
        return Ok(false);
    }
    manifest.disabled = disabled;
    let encoded = toml::to_string_pretty(&manifest)
        .map_err(|error| ExtensionError::Invalid(error.to_string()))?;
    let temporary = path.with_extension("toml.tmp");
    fs::write(&temporary, encoded)?;
    fs::rename(temporary, path)?;
    Ok(true)
}

fn copy_tree(source: &Path, destination: &Path) -> Result<(), ExtensionError> {
    fs::create_dir(destination)?;
    for entry in fs::read_dir(source)? {
        let entry = entry?;
        let metadata = entry.file_type()?;
        let target = destination.join(entry.file_name());
        if metadata.is_symlink() {
            let _ = fs::remove_dir_all(destination);
            return Err(ExtensionError::Path(entry.path()));
        }
        if metadata.is_dir() {
            copy_tree(&entry.path(), &target)?;
        } else if metadata.is_file() {
            fs::copy(entry.path(), target)?;
        }
    }
    Ok(())
}

fn permission_allows(permissions: &ExtensionPermissions, effect: ToolSideEffect) -> bool {
    match effect {
        ToolSideEffect::ReadOnly => permissions.workspace_read,
        ToolSideEffect::WorkspaceWrite => permissions.workspace_write,
        ToolSideEffect::CommandExecution => permissions.command_execution,
    }
}

fn validate_id(value: &str) -> Result<(), ExtensionError> {
    if value.is_empty()
        || value.len() > 128
        || value
            .chars()
            .any(|character| !(character.is_ascii_alphanumeric() || matches!(character, '_' | '-')))
    {
        return Err(ExtensionError::Invalid(format!(
            "invalid identifier `{value}`"
        )));
    }
    Ok(())
}

fn validate_version(value: &str) -> Result<(), ExtensionError> {
    if value.is_empty()
        || value.len() > 64
        || value.chars().any(|character| {
            !(character.is_ascii_alphanumeric() || matches!(character, '.' | '-' | '+'))
        })
    {
        return Err(ExtensionError::Invalid("invalid extension version".into()));
