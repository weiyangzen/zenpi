//! Installable local-process tools and opaque capability handles.

use std::{
    collections::{BTreeMap, BTreeSet},
    fs,
    io::Read,
    path::{Path, PathBuf},
    sync::atomic::{AtomicU64, Ordering},
    time::{Duration, SystemTime, UNIX_EPOCH},
};

use serde::{Deserialize, Serialize};
use serde_json::{Map, Value, json};
use sha2::{Digest, Sha256};
use thiserror::Error;

use crate::tools::{Tool, ToolContext, ToolDefinition, ToolError, ToolSideEffect};

pub const EXTENSION_MANIFEST: &str = "extension.toml";
pub const EXTENSION_API_VERSION: u32 = 1;
pub const EXTENSION_HOOK_API_VERSION: u32 = 2;
pub const MAX_EXTENSION_FRAME_BYTES: usize = 1024 * 1024;

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct ExtensionManifest {
    pub name: String,
    pub version: String,
    pub api_version: u32,
    #[serde(default)]
    pub disabled: bool,
    pub executable: String,
    #[serde(default)]
    pub args: Vec<String>,
    #[serde(default)]
    pub permissions: ExtensionPermissions,
    #[serde(default)]
    pub tools: Vec<ExtensionToolManifest>,
    #[serde(default)]
    pub hooks: Vec<crate::extension_runtime::HookKind>,
    #[serde(default = "default_hook_timeout")]
    pub hook_timeout_ms: u64,
}

fn default_hook_timeout() -> u64 {
    1000
}

#[derive(Debug, Clone, Default, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct ExtensionPermissions {
    #[serde(default)]
    pub workspace_read: bool,
    #[serde(default)]
    pub workspace_write: bool,
    #[serde(default)]
    pub command_execution: bool,
    #[serde(default)]
    pub network: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct ExtensionToolManifest {
    pub name: String,
    pub description: String,
    pub input_schema: Value,
    pub side_effect: ToolSideEffect,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct ExtensionSummary {
    pub name: String,
    pub version: String,
    pub disabled: bool,
    pub compatible: bool,
    pub path: String,
    pub tools: Vec<String>,
    pub permissions: ExtensionPermissions,
}

#[derive(Debug, Clone)]
pub(crate) struct LoadedExtension {
    pub(crate) manifest: ExtensionManifest,
    pub(crate) directory: PathBuf,
    pub(crate) executable: PathBuf,
}

#[derive(Debug, Clone, Default)]
pub struct ExtensionCatalog {
    pub(crate) loaded: BTreeMap<String, LoadedExtension>,
    summaries: Vec<ExtensionSummary>,
}

impl ExtensionManifest {
    fn validate(&self) -> Result<(), ExtensionError> {
        validate_id(&self.name)?;
        validate_version(&self.version)?;
        if !matches!(
            self.api_version,
            EXTENSION_API_VERSION | EXTENSION_HOOK_API_VERSION
        ) {
            return Err(ExtensionError::Incompatible {
                name: self.name.clone(),
                found: self.api_version,
                supported: EXTENSION_HOOK_API_VERSION,
            });
        }
        validate_relative_component_path(&self.executable)?;
        if self.args.len() > 64
            || self
                .args
                .iter()
                .any(|arg| arg.len() > 4096 || arg.contains('\0'))
        {
            return Err(ExtensionError::Invalid("extension args are invalid".into()));
        }
        if (self.tools.is_empty() && self.hooks.is_empty()) || self.tools.len() > 64 {
            return Err(ExtensionError::Invalid(
                "extension must declare hooks or 1 to 64 tools".into(),
            ));
        }
        if (!self.hooks.is_empty() && self.api_version != EXTENSION_HOOK_API_VERSION)
            || self.hooks.len() > 8
            || self.hooks.iter().collect::<BTreeSet<_>>().len() != self.hooks.len()
            || !(1..=1000).contains(&self.hook_timeout_ms)
        {
            return Err(ExtensionError::Invalid(
                "invalid hook version, duplicates or timeout".into(),
            ));
        }
        let mut names = BTreeSet::new();
        for tool in &self.tools {
            validate_id(&tool.name)?;
            let definition = ToolDefinition {
                name: tool.name.clone(),
                description: tool.description.clone(),
                input_schema: tool.input_schema.clone(),
                side_effect: tool.side_effect,
            };
            definition
                .validate()
                .map_err(|error| ExtensionError::Invalid(error.to_string()))?;
            if !names.insert(tool.name.clone()) {
                return Err(ExtensionError::Invalid(format!(
                    "duplicate extension tool `{}`",
                    tool.name
                )));
            }
            if !permission_allows(&self.permissions, tool.side_effect) {
                return Err(ExtensionError::Invalid(format!(
                    "tool `{}` exceeds declared extension permissions",
                    tool.name
                )));
            }
        }
        Ok(())
    }
}

impl ExtensionCatalog {
    pub fn load(root: &Path) -> Result<Self, ExtensionError> {
        if !root.exists() {
            return Ok(Self::default());
        }
        if !root.is_dir() {
            return Err(ExtensionError::Path(root.to_owned()));
        }
        let canonical_root = root.canonicalize()?;
        let mut paths = fs::read_dir(root)?
            .filter_map(Result::ok)
            .map(|entry| entry.path())
            .collect::<Vec<_>>();
        paths.sort();
        let mut catalog = Self::default();
        for path in paths {
            if path
                .file_name()
                .and_then(|name| name.to_str())
                .is_some_and(|name| name.starts_with('.'))
            {
                continue;
            }
            let metadata = fs::symlink_metadata(&path)?;
            if metadata.file_type().is_symlink() || !metadata.is_dir() {
                continue;
            }
            let directory = path.canonicalize()?;
            if !directory.starts_with(&canonical_root) {
                return Err(ExtensionError::Path(path));
            }
            let manifest_path = directory.join(EXTENSION_MANIFEST);
            if !manifest_path.is_file() {
                continue;
            }
            if fs::symlink_metadata(&manifest_path)?
                .file_type()
                .is_symlink()
            {
                return Err(ExtensionError::Path(manifest_path));
            }
            let mut text = String::new();
            fs::File::open(&manifest_path)?
                .take(256 * 1024 + 1)
                .read_to_string(&mut text)?;
            if text.len() > 256 * 1024 {
                return Err(ExtensionError::Invalid(
                    "extension manifest is too large".into(),
                ));
            }
            let manifest: ExtensionManifest = toml::from_str(&text)?;
            let compatible = matches!(
                manifest.api_version,
                EXTENSION_API_VERSION | EXTENSION_HOOK_API_VERSION
            );
            let summary = ExtensionSummary {
                name: manifest.name.clone(),
                version: manifest.version.clone(),
                disabled: manifest.disabled,
                compatible,
                path: directory.display().to_string(),
                tools: manifest
                    .tools
                    .iter()
                    .map(|tool| tool.name.clone())
                    .collect(),
                permissions: manifest.permissions.clone(),
            };
            if manifest.disabled {
                catalog.summaries.push(summary);
                continue;
            }
            manifest.validate()?;
            let executable = directory.join(&manifest.executable);
            let executable = executable
                .canonicalize()
                .map_err(|_| ExtensionError::Path(executable))?;
            if !executable.starts_with(&directory) || !executable.is_file() {
                return Err(ExtensionError::Path(executable));
            }
            if catalog.loaded.contains_key(&manifest.name) {
                return Err(ExtensionError::Invalid(format!(
                    "duplicate extension `{}`",
                    manifest.name
                )));
            }
            if catalog.loaded.len() >= 32 {
                return Err(ExtensionError::Invalid(
                    "at most 32 enabled extensions are allowed".into(),
                ));
