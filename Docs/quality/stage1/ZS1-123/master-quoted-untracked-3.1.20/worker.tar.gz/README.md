# ZS1-123 quoted untracked diff increment
+
+Apply only product.patch to exact src/slash_actions.rs SHA811bde9af190b2e439542c0a89dd8e8a1f76bbcf8eb6aa3ad3b16143447ec30b. Result SHAeb8cd91d6f84ea977454fe69a2304a2ff56ef714b8356e90e51526f5ce1dfcc3. No other product path is patched.
+
+report.md explains the real24-failure counterexample, unchanged readable status and bounded native path decoding, all intermediate failures, final33 top-level test results (one explicitly observes deferred gaps), platform limitation and preserved policies. Both old deferred gaps remain open; this is not full123 acceptance.
+
+verify.py performs static manifest/input/log/boundary/source checks and private exact patch application/reversal. It executes no Cargo or product binary.
+
+replay.py --destination NEW_PATH --mode before|after prepares an isolated build from recorded exact inputs. The default only prepares; --run explicitly opts into native offline Cargo replay with its own CARGO_TARGET_DIR. Before mode replays the original negative matrix and expects exit101; after mode runs the final owner/integration/Clippy/fmt checks. Existing in-process host tests need the archived current README.md and private Git root. All original logs are immutable; new replay receipts stay in the new destination.
+
+The packet includes225 final inputs and18 original run receipts with unedited stdout/stderr, including failed attempts. Final runtime checks bind eb8cd9…; no PTY/HTTP/network/FIFO probe or main checkout action occurred.
+