#!/usr/bin/env python3
"""Prepare exact frozen inputs; execute native offline Cargo only with --run."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import argparse, datetime, json, os, subprocess, time
from verify import ROOT, BEFORE, AFTER, load_inputs, variants, resolve_input, read_json, sha

parser=argparse.ArgumentParser();parser.add_argument('--destination',type=Path,required=True);parser.add_argument('--mode',choices=['before','after'],default='after');parser.add_argument('--run',action='store_true');args=parser.parse_args()
destination=args.destination.resolve();assert not destination.exists(),'destination must be new'
inputs=load_inputs();alternatives=variants()
record_name='negative-current' if args.mode=='before' else 'final-owner-tests'
inventory=read_json(ROOT/'logs'/(record_name+'.inputs.json'))
destination.mkdir(parents=True);build=destination/'build';build.mkdir()
for row in inventory:
    rel=Path(row['path']);assert not rel.is_absolute() and '..' not in rel.parts
    path=build/rel;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(resolve_input(row,inputs,alternatives));path.chmod(inputs[row['path']][1])
digest=sha((build/'src/slash_actions.rs').read_bytes());assert digest==(BEFORE if args.mode=='before' else AFTER)
if args.mode=='after':
    result=subprocess.run(['git','init','--quiet','-b','codex/quoted-untracked-replay'],cwd=build,capture_output=True)
    assert result.returncode==0,result.stderr
preparation={'mode':args.mode,'prepared_inputs':len(inventory),'source_sha256':digest,'source_inventory':str(ROOT/'logs'/(record_name+'.inputs.json')),'runtime_run_requested':args.run,'HOME_preserved':True,'CODEX_HOME_preserved':True,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(destination/'preparation.json').write_text(json.dumps(preparation,indent=2)+'\n')
if args.run:
    env=os.environ.copy();env['CARGO_TARGET_DIR']=str(destination/'cargo-target')
    cargo=['cargo','+stable-aarch64-apple-darwin']
    commands=[(cargo+['test','--offline','--locked','--jobs','2','--test','quoted_untracked_review','--','--nocapture'],101)] if args.mode=='before' else [
        (cargo+['test','--offline','--locked','--jobs','2','--lib','slash_actions::','--','--nocapture'],0),
        (cargo+['test','--offline','--locked','--jobs','2','--test','quoted_untracked_review','--test','slash_actions','--','--nocapture'],0),
        (cargo+['clippy','--offline','--locked','--jobs','2','--lib','--test','slash_actions','--test','quoted_untracked_review','--','-D','warnings'],0),
        (cargo+['fmt','--all','--','--check'],0)]
    for index,(argv,expected) in enumerate(commands):
        start=datetime.datetime.now(datetime.timezone.utc).isoformat();clock=time.monotonic();out=destination/f'{index}.stdout.log';err=destination/f'{index}.stderr.log'
        with out.open('wb') as stdout,err.open('wb') as stderr:result=subprocess.run(argv,cwd=build,env=env,stdout=stdout,stderr=stderr)
        receipt={'argv':argv,'cwd':str(build),'started_at':start,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-clock,'source_sha256':digest,'exit_code':result.returncode,'expected_exit_code':expected,'env_overrides':{'CARGO_TARGET_DIR':env['CARGO_TARGET_DIR']}}
        for label,path in [('stdout',out),('stderr',err)]:receipt[label]={'path':path.name,'bytes':path.stat().st_size,'sha256':sha(path.read_bytes())}
        (destination/f'{index}.run.json').write_text(json.dumps(receipt,indent=2)+'\n');assert result.returncode==expected,receipt
print(json.dumps(preparation,indent=2))
