#!/usr/bin/env python3
"""Static packet verification. Does not run Cargo or product executables."""
from pathlib import Path
import argparse, hashlib, json, subprocess, tarfile, tempfile

ROOT=Path(__file__).resolve().parent
BEFORE='811bde9af190b2e439542c0a89dd8e8a1f76bbcf8eb6aa3ad3b16143447ec30b'
AFTER='eb8cd91d6f84ea977454fe69a2304a2ff56ef714b8356e90e51526f5ce1dfcc3'
sha=lambda data:hashlib.sha256(data).hexdigest()
def read_json(path):return json.loads(path.read_text())
def checked(data,row):
    assert len(data)==row['bytes'] and sha(data)==row['sha256'],row
def load_inputs():
    result={}
    with tarfile.open(ROOT/'build-inputs.tar.gz','r:gz') as archive:
        for member in archive.getmembers():
            path=Path(member.name)
            assert member.isfile() and not path.is_absolute() and '..' not in path.parts
            assert member.name not in result
            result[member.name]=(archive.extractfile(member).read(),member.mode)
    inventory=read_json(ROOT/'final-build-context.json')
    assert len(inventory)==len(result)==225
    for row in inventory:checked(result[row['path']][0],row)
    return result
def variants():
    return {sha(p.read_bytes()):p.read_bytes() for p in [ROOT/'before.rs',ROOT/'after.rs',ROOT/'review-probe.rs',*sorted((ROOT/'variants').glob('*.rs'))]}
def resolve_input(row,inputs,alternatives):
    data=inputs[row['path']][0]
    if sha(data)!=row['sha256']:data=alternatives[row['sha256']]
    checked(data,row)
    return data
def verify(skip_manifest=False):
    if not skip_manifest:
        manifest=read_json(ROOT/'manifest.json');paths=[]
        for row in manifest['files']:
            p=ROOT/row['path'];assert p.resolve().is_relative_to(ROOT)
            checked(p.read_bytes(),row);paths.append(row['path'])
        assert len(paths)==len(set(paths))
        assert set(paths)=={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and p.name!='manifest.json'}
    before=(ROOT/'before.rs').read_bytes();after=(ROOT/'after.rs').read_bytes()
    assert sha(before)==BEFORE and sha(after)==AFTER
    coverage=read_json(ROOT/'read-coverage.json');cursor=0;line=1;lines=before.splitlines(keepends=True)
    for row in coverage['chunks']:
        a,b=row['byte_range'];assert a==cursor and 0<b-a<=256*1024 and row['start_line']==line
        data=b''.join(lines[row['start_line']-1:row['end_line']]);assert data==before[a:b];checked(data,row)
        cursor=b;line=row['end_line']+1
    assert cursor==len(before)==52674 and line==1372 and len(after.splitlines())==1539
    inputs=load_inputs();alternatives=variants();assert inputs['src/slash_actions.rs'][0]==after
    old=read_json(ROOT/'build-context.json');assert len(old)==223
    for row in old:
        if row['path']!='src/slash_actions.rs':checked(inputs[row['path']][0],row)
    checked(inputs['README.md'][0],read_json(ROOT/'context-supplement.json'))
    expected={'negative-current':101,'fixed-same-counterexample':101,'final-inline':101,'final-integration':101,'final-integration-platform-aware':101,'final-fmt':1}
    runs=[]
    for file in sorted((ROOT/'logs').glob('*.run.json')):
        name=file.name.removesuffix('.run.json');record=read_json(file)
        assert record['status']=='finished' and record['exit_code']==expected.get(name,0)
        assert record['source_sha256'] in alternatives
        for label in ['stdout','stderr']:checked((ROOT/'logs'/record[label]['path']).read_bytes(),record[label])
        inventory_path=ROOT/'logs'/(name+'.inputs.json')
        assert sha(inventory_path.read_bytes())==record['inputs_sha256']
        if record['argv'][0]=='cargo' and any(x in record['argv'] for x in ['test','clippy']):
            for row in read_json(inventory_path):resolve_input(row,inputs,alternatives)
        runs.append({'name':name,'exit_code':record['exit_code'],'source_sha256':record['source_sha256']})
    assert len(runs)==18
    assert (ROOT/'logs/negative-current.stdout.log').read_text().count('present=false')==24
    assert (ROOT/'logs/fixed-counterexample.stdout.log').read_text().count('present=true')==42
    assert '17 passed; 0 failed' in (ROOT/'logs/final-owner-tests.stdout.log').read_text()
    final_log=(ROOT/'logs/accepted-integration.stdout.log').read_text()
    assert '5 passed; 0 failed' in final_log and '11 passed; 0 failed' in final_log
    for name in ['final-owner-tests','accepted-integration','final-clippy-complete','final-fmt-complete']:
        assert read_json(ROOT/'logs'/(name+'.run.json'))['source_sha256']==AFTER
    old_text=before.decode();new_text=after.decode()
    boundaries=read_json(ROOT/'preserved-boundaries.json')
    for name,start,end in [('native_path_policy','fn resolve_relative(','fn map_path_error('),('diff_process_and_bounds','fn git_diff_process(','/// Build the same typed queue request'),('legacy_no_head_fallback','        let first = git_diff_process','    // A repository-wide'),('attachments','fn file_looks_binary(','struct GitStatus')]:
        old_end='fn git_status(' if name=='attachments' else end
        a=old_text[old_text.index(start):old_text.index(old_end)]
        b=new_text[new_text.index(start):new_text.index(end)]
        assert a==b and sha(b.encode())==boundaries[name]['sha256']
    start='    let mut command = Command::new("git");'
    a=old_text[old_text.index(start,old_text.index('fn git_status(')):old_text.index('    Ok(bound_status(String::from_utf8_lossy(&bytes).into_owned()))')]
    b=new_text[new_text.index(start,new_text.index('fn git_status(')):new_text.index('    Ok(GitStatus {')]
    assert a==b and sha(b.encode())==boundaries['status_process_stdio_read_kill_wait']['sha256']
    patch=ROOT/'product.patch';assert patch.stat().st_size<256*1024
    assert [s for s in patch.read_text().splitlines() if s.startswith(('--- ','+++ '))]==['--- a/src/slash_actions.rs','+++ b/src/slash_actions.rs']
    with tempfile.TemporaryDirectory(prefix='quoted-untracked-verify-',dir=ROOT.parent) as temporary:
        directory=Path(temporary);(directory/'src').mkdir();(directory/'src/slash_actions.rs').write_bytes(before)
        def git(*args):
            result=subprocess.run(['git',*args],cwd=directory,capture_output=True,text=True)
            assert result.returncode==0,{'argv':args,'stdout':result.stdout,'stderr':result.stderr}
        git('init','--quiet');git('apply','--check',str(patch));git('apply',str(patch))
        assert (directory/'src/slash_actions.rs').read_bytes()==after
        assert [p.name for p in (directory/'src').iterdir()]==['slash_actions.rs']
        git('apply','--reverse','--check',str(patch));git('apply','--reverse',str(patch));assert (directory/'src/slash_actions.rs').read_bytes()==before
    return {'ok':True,'kind':'offline structural checks only','manifest_verified':not skip_manifest,'before_sha256':BEFORE,'after_sha256':AFTER,'patch_sha256':sha(patch.read_bytes()),'patch_exact_apply_reverse':'passed','only_product_path':'src/slash_actions.rs','final_build_inputs':225,'unchanged_initial_inputs':222,'run_receipts_verified':len(runs),'negative_missing_checks':24,'final_top_level_tests':33,'nested_environment_children_excluded_from_total':4,'deferred_gap_observation_tests_in_total':1,'native_non_utf8_inode_case':'EILSEQ unavailable on this filesystem; raw-byte decoder rejection tested','new_runtime_runs_by_verifier':0,'whole_item_123_acceptance':False}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--without-manifest',action='store_true');args=parser.parse_args()
    print(json.dumps(verify(args.without_manifest),indent=2))
