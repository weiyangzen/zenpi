#![cfg(unix)]
use std::{fs, path::Path, process::Command};
use std::os::unix::fs::MetadataExt;
use zenpi::slash_actions::diff_value_at;

fn git(root: &Path, args: &[&str]) -> String {
    let output = Command::new("git").current_dir(root)
        .env_remove("GIT_GLOB_PATHSPECS").env_remove("GIT_ICASE_PATHSPECS")
        .arg("--literal-pathspecs").args(args).output().unwrap();
    assert!(output.status.success(), "{}", String::from_utf8_lossy(&output.stderr));
    String::from_utf8(output.stdout).unwrap()
}

#[test]
fn real_git_quoted_untracked_paths_keep_identity_in_all_scopes() {
    let directory = tempfile::tempdir().unwrap();
    let root = directory.path();
    git(root, &["init", "-q"]);
    git(root, &["config", "user.name", "quoted path fixture"]);
    git(root, &["config", "user.email", "quoted@example.test"]);
    for folder in ["scope[ab]", "scopea", "scope[ab]/note"] {
        fs::create_dir_all(root.join(folder)).unwrap();
        fs::write(root.join(folder).join("seed.txt"), "seed\n").unwrap();
    }
    git(root, &["add", "."]);
    git(root, &["commit", "-qm", "tracked directory seeds"]);
    let names = [r"note\report.txt", "note/report.txt", "space file.txt", "引号 文件.txt", "quote\"name.txt", "square[ab].txt", ":(glob)*.txt"];
    for (index, name) in names.iter().enumerate() {
        fs::write(root.join("scope[ab]").join(name), format!("SELECTED_FILE_{index}\n")).unwrap();
    }
    fs::write(root.join("scopea/neighbor.txt"), "OUTSIDE_SCOPE\n").unwrap();
    assert_ne!(fs::metadata(root.join(r"scope[ab]/note\report.txt")).unwrap().ino(), fs::metadata(root.join("scope[ab]/note/report.txt")).unwrap().ino());
    let mut missing = Vec::new();
    for quote in ["true", "false"] {
        git(root, &["config", "core.quotePath", quote]);
        for (index, name) in names.iter().enumerate() {
            let value = diff_value_at(root, Some(&format!("scope[ab]/{name}"))).unwrap();
            let diff = value["diff"].as_str().unwrap();
            assert!(diff.contains(&format!("+SELECTED_FILE_{index}")), "explicit {name:?}: {value}");
            for other in 0..names.len() {
                if other != index { assert!(!diff.contains(&format!("+SELECTED_FILE_{other}"))); }
            }
        }
        for scope in [Some("scope[ab]"), None, Some(".")] {
            let value = diff_value_at(root, scope).unwrap();
            let diff = value["diff"].as_str().unwrap();
            for (index, name) in names.iter().enumerate() {
                let present = diff.contains(&format!("+SELECTED_FILE_{index}"));
                println!("quotePath={quote} scope={scope:?} name={name:?} present={present}");
                if !present { missing.push(format!("{quote}/{scope:?}/{name:?}")); }
            }
            if scope == Some("scope[ab]") { assert!(!diff.contains("OUTSIDE_SCOPE")); }
            let expected = git(root, &["status", "--porcelain=v1", "--untracked-files=normal", "--", scope.unwrap_or(".")]);
            assert_eq!(value["status"], expected, "readable status changed");
        }
    }
    assert!(missing.is_empty(), "quoted untracked omission: {missing:?}");
}
