
#[cfg(all(test, unix))]
mod diff_identity_tests {
    use super::*;
    use std::os::unix::fs::MetadataExt;

    fn git(root: &Path, args: &[&str]) -> String {
        let output = Command::new("git")
            .current_dir(root)
            .arg("--literal-pathspecs")
            .args(args)
            .output()
            .unwrap();
        assert!(output.status.success(), "git {args:?}: {}", String::from_utf8_lossy(&output.stderr));
        String::from_utf8(output.stdout).unwrap()
    }

    fn repository() -> tempfile::TempDir {
        let root = tempfile::tempdir().unwrap();
        git(root.path(), &["init", "-q"]);
        git(root.path(), &["config", "user.name", "diff identity fixture"]);
        git(root.path(), &["config", "user.email", "diff@example.test"]);
        git(root.path(), &["commit", "--allow-empty", "-qm", "initial"]);
        root
    }

    fn collision(tracked: bool) {
        let directory = repository();
        let root = directory.path();
        let literal = r"note\report.txt";
        let nested = "note/report.txt";
        fs::create_dir(root.join("note")).unwrap();
        fs::write(root.join(literal), "literal before\n").unwrap();
        fs::write(root.join(nested), "directory before\n").unwrap();
        assert_ne!(fs::metadata(root.join(literal)).unwrap().ino(), fs::metadata(root.join(nested)).unwrap().ino());
        if tracked {
            git(root, &["add", "--", literal, nested]);
            git(root, &["commit", "-qm", "two different files"]);
        }
        fs::write(root.join(literal), "EXPECTED_LITERAL_CONTENT\n").unwrap();
        fs::write(root.join(nested), "WRONG_DIRECTORY_CONTENT\n").unwrap();
        let parsed = crate::slash::parse(r"/diff note\\report.txt").unwrap().unwrap();
        let crate::slash::SlashCommand::Diff { path } = parsed else { panic!("expected diff") };
        assert_eq!(path.as_deref(), Some(literal));
        let result = diff_value_at(root, path.as_deref());
        println!("tracked={tracked} literal_inode={} nested_inode={} result={result:?}", fs::metadata(root.join(literal)).unwrap().ino(), fs::metadata(root.join(nested)).unwrap().ino());
        let value = result.unwrap();
        let diff = value["diff"].as_str().unwrap();
        assert!(diff.contains("+EXPECTED_LITERAL_CONTENT"), "{diff}");
        assert!(!diff.contains("WRONG_DIRECTORY_CONTENT"), "{diff}");
        let other = diff_value_at(root, Some(nested)).unwrap();
        assert!(other["diff"].as_str().unwrap().contains("+WRONG_DIRECTORY_CONTENT"));
        assert!(!other["diff"].as_str().unwrap().contains("EXPECTED_LITERAL_CONTENT"));
    }

    #[test]
    fn tracked_backslash_diff_reads_only_selected_file() {
        collision(true);
    }

    #[test]
    fn untracked_backslash_diff_reads_only_selected_file() {
        collision(false);
    }

    fn literal_pathspec(selected: &str, neighbor: &str) {
        let directory = repository();
        let root = directory.path();
        fs::write(root.join(selected), "selected before\n").unwrap();
        fs::write(root.join(neighbor), "neighbor before\n").unwrap();
        git(root, &["add", "--", selected, neighbor]);
        git(root, &["commit", "-qm", "literal pathspec files"]);
        fs::write(root.join(selected), "EXPECTED_EXACT_PATH\n").unwrap();
        fs::write(root.join(neighbor), "WRONG_GLOB_NEIGHBOR\n").unwrap();
        let result = diff_value_at(root, Some(selected));
        println!("selected={selected:?} result={result:?}");
        let value = result.unwrap();
        let diff = value["diff"].as_str().unwrap();
        assert!(diff.contains("+EXPECTED_EXACT_PATH"), "{diff}");
        assert!(!diff.contains("WRONG_GLOB_NEIGHBOR"), "{diff}");
        assert!(!value["status"].as_str().unwrap().contains(neighbor));
    }

    #[test]
    fn bracket_filename_is_not_a_git_glob() {
        literal_pathspec("selected[ab].txt", "selecteda.txt");
    }

    #[test]
    fn magic_filename_is_not_a_git_pathspec_directive() {
        literal_pathspec(":(glob)*.txt", "neighbor.txt");
    }
}
