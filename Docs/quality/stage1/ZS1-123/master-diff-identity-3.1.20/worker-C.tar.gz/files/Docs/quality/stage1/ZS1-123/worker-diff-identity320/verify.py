from pathlib import Path
import difflib,hashlib,json,os,subprocess,sys,tempfile
E=Path(__file__).resolve().parent;R=E.parents[4];sha=lambda b:hashlib.sha256(b).hexdigest();frozen='--frozen' in sys.argv
state=json.loads((E/'baseline-state.json').read_text());ctx=json.loads((E/'build-context.json').read_text());before=(E/'main-before.rs').read_bytes();after=(E/'candidate.rs').read_bytes()
assert sha(before)=='5912f71faa07e7f529b1c9bef875a977873c6a5e152d103e837d0fbac001cd32'
assert sha(after)=='13784372cd5c587b79ef1b726f61caf97a13000de9759aafa8a48f92772b31aa'
assert (R/'src/slash_actions.rs').read_bytes()==after
assert (E/'worker-before.rs').read_bytes()==before
assert (E/'baseline-with-regression.rs').read_bytes()==before+(E/'diff-regression-tests.rs').read_bytes()
a=before.decode();b=after.decode();base_candidate=b.split('\n#[cfg(all(test, unix))]\nmod diff_identity_tests {')[0]
assert base_candidate.endswith(a[a.index('#[cfg(test)]\nmod attachment_identity_tests {'):])
assert a.split('pub fn diff_value_at(')[0]==b.split('pub fn diff_value_at(')[0]
def between(text,start,end):return text[text.index(start):text.index(end)]
for start,end in [('fn file_looks_binary(', 'fn path_display('),('fn mime_for_path(', 'fn git_status('),('fn untracked_paths(', '/// Run a git process with a hard stdout read bound.')]:assert between(a,start,end)==between(b,start,end)
assert a[a.index('fn bound_text('):]==base_candidate[base_candidate.index('fn bound_text('):]
status=between(b,'fn git_status(','fn untracked_paths(').replace('        // An explicit workspace filename is not a glob or pathspec directive.\n','').replace('        .arg("--literal-pathspecs")\n','')
assert status==between(a,'fn git_status(','fn untracked_paths(')
process=between(b,'fn git_diff_process(','fn bound_text(').replace('        .arg("--literal-pathspecs")\n','')
assert process==between(a,'fn git_diff_process(','fn bound_text(')
reads=json.loads((E/'file-read-receipt.json').read_text());parts=[]
for c in reads['consecutive_chunks']:
 part=before[c['byte_start']:c['byte_end']];assert sha(part)==c['sha256'];parts.append(part)
assert b''.join(parts)==before and reads['lines']==1078
for stem,code in [('baseline-regression',101),('candidate-inline',0),('candidate-inline-final',0),('existing-integration',0),('clippy',0),('private-git-init',0),('gstage-main',1)]:
 rec=json.loads((E/(stem+'.json')).read_text());log=(E/(stem+'.log')).read_bytes();assert rec['exit_code']==code and sha(log)==rec['sha256'] and len(log)==rec['bytes'],stem
assert '0 passed; 4 failed' in (E/'baseline-regression.log').read_text()
assert '13 passed; 0 failed' in (E/'candidate-inline-final.log').read_text()
assert '11 passed; 0 failed' in (E/'existing-integration.log').read_text()
assert json.loads((E/'gstage-main.log').read_text())['structural']['ok']
selector=json.loads((E/'active_requirement.json').read_text());assert selector['blueprint_version']=='3.1.20' and selector['requirement_digest']=='8d525b351d066ce9b0487a485337647d47233275782e4f4d154423a623fe1645'
if not frozen:
 assert Path('/Users/wangweiyang/GitHub/zenpi/src/slash_actions.rs').read_bytes()==before
 for p,d in state['prior_ready_files'].items():assert sha((R/p).read_bytes())==d,p
 for p,d in state['tracked_files'].items():
  if p!='src/slash_actions.rs':assert sha((R/p).read_bytes())==d,p
 for row in ctx['files']:
  p=Path(ctx['root'])/row['path'];assert sha(p.read_bytes())==(sha(after) if row['path']=='src/slash_actions.rs' else row['sha256']),row['path']
 assert (Path(ctx['root'])/'.git').is_dir()
 assert os.environ.get('HOME')==state['HOME'] and os.environ.get('CODEX_HOME')==state['CODEX_HOME']
patch=(E/'product.patch').read_bytes();expected=''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/src/slash_actions.rs',tofile='b/src/slash_actions.rs')).encode();assert patch==expected
commands=[]
with tempfile.TemporaryDirectory(prefix='zenpi-diff-identity-patch-') as tmp:
 root=Path(tmp);p=root/'src/slash_actions.rs';p.parent.mkdir();p.write_bytes(before);sentinel=root/'src/core.rs';sentinel.write_bytes(b'owner boundary unchanged\n')
 for args in [['--check'],[],['--reverse','--check'],['--reverse']]:
  result=subprocess.run(['git','apply',*args,str(E/'product.patch')],cwd=root,capture_output=True,timeout=10);assert result.returncode==0,result.stderr;commands.append({'args':args,'exit_code':result.returncode});assert sentinel.read_bytes()==b'owner boundary unchanged\n'
  if args==[]:assert p.read_bytes()==after
 assert p.read_bytes()==before
print(json.dumps({'ok':True,'frozen':frozen,'before_sha256':sha(before),'after_sha256':sha(after),'product_patch_sha256':sha(patch),'patch_commands':commands,'sentinel_unchanged':True,'attachment_fix_and_tests_byte_preserved':True,'other_owner_sections_and_limits_preserved':True,'actual_baseline_regressions_failed':4,'baseline_exit_code':101,'candidate_native_unit_tests':13,'existing_integration_tests':11,'full_product_suite_run':False,'windows_run':False,'prior_ready_files_checked':0 if frozen else len(state['prior_ready_files']),'other_tracked_checked':0 if frozen else len(state['tracked_files'])-1,'private_build_input_count':len(ctx['files']),'acceptance':False},indent=2))
