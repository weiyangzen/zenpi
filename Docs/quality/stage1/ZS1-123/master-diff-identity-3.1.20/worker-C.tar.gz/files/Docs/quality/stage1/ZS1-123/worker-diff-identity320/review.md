# ZS1-123 /diff 路径身份增量（provisional）

四项故障已在真实 Git 中先复现再修复：已跟踪、未跟踪的 Unix 字面反斜杠文件均被替换为另一目录文件；含方括号或 Git magic 前缀的显式文件名会匹配邻近文件。修改仅在 src/slash_actions.rs 及本文件新 inline tests，保留已合入的附件修复和原测试。

## 冻结与读取

主控指定的当前主库版本先复制为 main-before.rs，确认41343字节/1078行/SHA-256 `5912f71faa07e7f529b1c9bef875a977873c6a5e152d103e837d0fbac001cd32`。在任何测试或修改前，以1–280、281–560、561–840、841–1078连续完整阅读全部源码；file-read-receipt.json记录时间相关基线、精确字节范围和块hash。原worker文件也相同，另存worker-before.rs。

必要slash parser上下文实际读了878–904、1080–1105、1901–1960行。tokenizer将反斜杠作为下一字符转义；测试用Rust raw string `/diff note\\report.txt`，先断言parse结果恰为字面名称 `note\report.txt`，再调用diff_value_at。没有将未转义输入得到notereport.txt的夹具错误当作产品故障。

新私有完整主库构建副本 `.ops/stage123-diff320-build` 含229个真实输入，保留完整src/tests/vendor/tools等，清单和捕获稳定性见build-context.json；唯一替换的产品文件是本文件，没有stub模块或裁剪编译架子。独立CARGO_TARGET_DIR为`.ops/stage123-diff320-target`。每次Cargo为native stable-aarch64-apple-darwin、--offline --locked；HOME/CODEX_HOME不变，Git全局/系统配置在测试命令环境中禁用。真实Git初始化、add、commit、diff仅针对新私有测试仓库；为现有integration测试还初始化私有构建副本自己的.git，防止向父工作树发现Git仓库。主库与用户Git未被修改。

## 先失败的实际数据

baseline-regression实际退出101，0 passed / 4 failed；完整日志9929字节，SHA-256 `11dce052b249f2f3363c5f8a6f594ae3fea63906ca6fa668466f2dc6db60f920`。diff-regression-tests.rs为真实原始测试，baseline-with-regression.rs为未修复产品加测试的精确源码，fixture-data.json保留文件内容与名称；真实inode和结果在日志中。

| 案例 | 构造与旧行为 |
|---|---|
| tracked | 两个inode不同的`note\report.txt`与`note/report.txt`均add/commit，再分别写入EXPECTED_LITERAL_CONTENT与WRONG_DIRECTORY_CONTENT。解析输入身份正确，旧diff却仅返回后一文件的hunk；status仍提及前者。 |
| untracked | 在有空初始commit的私有repo中创建同一对不同inode文件，不add。旧no-index分支把Path显示字符串替换成目录路径，返回WRONG_DIRECTORY_CONTENT。 |
| bracket pathspec | commit字面`selected[ab].txt`与`selecteda.txt`，分别修改为EXPECTED_EXACT_PATH与WRONG_GLOB_NEIGHBOR。旧显式diff/status同时包含两者。 |
| magic pathspec | commit字面`:(glob)*.txt`与`neighbor.txt`，再分别修改。旧Git把显式文件名解释成pathspec指令，diff/status包含邻居。 |

这四项均返回accepted=true而内容/范围错误，不是Git不存在、未初始化或输入解析失败。

## 修复内容与边界

untracked显式文件与目录收集分支用Path::new(".").join(relative)构造实际Git参数；tracked、无HEAD的unstaged/cached回退直接传借用的相对Path，通过Command::arg接收OsStr，不经过path_display或有损String转换。所有路径仍经过resolve_relative的workspace与symlink检查。

Git status和diff增加全局--literal-pathspecs，使用户显式文件/目录名按字面匹配；它不能只靠`--`代替，因为`--`阻止选项解析但不关闭pathspec glob/magic。tracked的`--`保留，no-index也显式加入`--`；路径仍作为独立参数，未经过shell。`/diff .`空相对路径转换为Path(".")；无显式path时仍是整个repo范围。目录内untracked数量上限32和diff/status字节上限不变。

第一次修复后的13-test结果已正确读取文件，但实际日志显示JSON path字段仍把Unix反斜杠显示成斜杠，因此额外纠正了已观察到的显示身份问题，并加入path字段断言。path_display只在Windows将分隔符转为正斜杠，Unix保留原字面反斜杠；显示字符串不会重新用于I/O或Git authority。中间版本candidate-before-display.rs和candidate-inline原收据/日志保留，不覆盖它们。

verify.py按精确字节确认：附件构造/大小/摘要/路径校验、完整旧attachment_identity_tests、其他owner、binary读取、untracked_paths、bound_text/bound_status均未变；git_status/git_diff_process除literal参数及注释外保持旧字节。目录收集仍沿用原porcelain引用行跳过规则，没有新增递归或扩大收集范围；显式反斜杠文件不依赖该目录收集规则。本次不处理其它owner或邻近的未实证问题。

## 修复后的实际验证

| 命令收据 | 实际结果 | 日志SHA-256 |
|---|---|---|
| candidate-inline | 中间版本13 passed / 0 failed，rc0；原附件5+新diff8，尚未增加path显示断言 | c581c28e2b6b613bca3581ef2c8c5624f63ec79dca2576fdc9c7b04f29522940 |
| candidate-inline-final | 最终13 passed / 0 failed，rc0；包含原附件5项及新diff8项、正确path显示 | 1b713a5f54b9750e0e0d0e03a8eea5c5944ef6a32fa041773519361f2d6e5b08 |
| existing-integration | 完整tests/slash_actions.rs：11 passed / 0 failed，rc0 | db47ebc94ca149177cd736a5d1128c36abcf9e0f157795acfffd4dfe104126ca |
| clippy | --lib --test slash_actions -- -D warnings，rc0 | 59175afd4db992529ebe856fb93a50b40431a9275f5cfa9a7b73c38c32e8774f |
| integrity-final | 源/旧代码保留/构建上下文/旧ready/单文件正逆patch/sentinel，rc0 | 038a9456550688d900915635f133e52656302d2eacefb3d14f4b3a797a655884 |

新增8项测试包括四个原故障、无HEAD的cached/unstaged两个回退阶段、删除字面反斜杠文件、看似--output选项的文件、字面目录范围与40个untracked文件只纳入32项。实际修复后hunk与status不再包含邻居，两个文件可分别选中。原有11项integration覆盖binary、超长输出截断、脱敏、escape/symlink、tracked/untracked、无HEAD、附件以及进程内headless/TUI dispatch。后两者不等于PTY或主控完整真实入口验收；本轮不运行PTY/HTTP/网络或发布。

Clippy保留vendor/crossterm已有unused_parens依赖警告，未改依赖。Windows专属执行与全产品测试未运行；本机结果只代表native macOS。新diff测试为cfg(test, unix)，Windows显示规则及Path/OsStr语义保留，不冒充Windows实测。

## 精确候选与交接

- exact-before：41343字节/1078行，`5912f71faa07e7f529b1c9bef875a977873c6a5e152d103e837d0fbac001cd32`。
- exact-after：50852字节/1334行，`13784372cd5c587b79ef1b726f61caf97a13000de9759aafa8a48f92772b31aa`。
- 单产品文件product.patch：16554字节，`0828141ec8f2220044e42ea8ebd6a45def25f97d1a52bb2b69113764c05ab4cc`。
- 新证据目录：Docs/quality/stage1/ZS1-123/worker-diff-identity320。旧72个顶层ready包及其它144个tracked文件保持原字节；产品主库保持exact-before。

主库G-STAGE --item ZS1-123真实退出1，structural=true，缺ZS1-123.master.json，失败日志`c5563d7543c41caf4a21da22d17c3b294f453ae24744fbee7440398e77726eaa`保留。这不是本地Git回归失败，也不是验收成功。完成单文件和全包正向/逆向apply-check、实际apply、逐文件hash及无关core.rs sentinel后交新ready。仅为待主控独立整合和真实入口验证的provisional，不声明123或087已验收。
