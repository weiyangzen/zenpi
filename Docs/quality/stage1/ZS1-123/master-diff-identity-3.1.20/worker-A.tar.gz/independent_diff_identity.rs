use std::{fs, path::{Path, PathBuf}, process::Command};
use serde_json::{Value, json};
use zenpi::slash_actions::diff_value_at;

fn git(root: &Path, args: &[&str]) -> String {
    let out = Command::new("git").current_dir(root)
        .env_remove("GIT_GLOB_PATHSPECS").env_remove("GIT_NOGLOB_PATHSPECS")
        .env_remove("GIT_ICASE_PATHSPECS").env_remove("GIT_LITERAL_PATHSPECS")
        .arg("--literal-pathspecs").args(args).output().unwrap();
    let record = json!({"cwd":root,"argv":args,"literal_pathspecs":true,"setup_pathspec_environment_removed":true,
                       "exit":out.status.code(),"stdout":String::from_utf8_lossy(&out.stdout),"stderr":String::from_utf8_lossy(&out.stderr)});
    println!("GIT {record}");
    assert!(out.status.success(), "{record}");
    String::from_utf8(out.stdout).unwrap()
}
fn repository(label: &str, head: bool) -> PathBuf {
    let root = PathBuf::from(std::env::var_os("DIFF_REVIEW_ROOT").expect("private fixture root")).join(label);
    assert!(!root.exists());fs::create_dir_all(&root).unwrap();
    git(&root,&["init","-q"]);
    git(&root,&["config","user.name","independent 123"]);
    git(&root,&["config","user.email","123@example.test"]);
    git(&root,&["config","commit.gpgsign","false"]);
    if head { git(&root,&["commit","--allow-empty","-qm","initial"]); }
    root
}
fn query(root: &Path, raw: &str) -> Value {
    let text = format!("/diff {}", serde_json::to_string(raw).unwrap());
    let parsed = zenpi::slash::parse(&text).unwrap().unwrap();
    let zenpi::slash::SlashCommand::Diff {path} = parsed else {panic!("wrong route")};
    assert_eq!(path.as_deref(),Some(raw));
    let value = diff_value_at(root,path.as_deref());
    println!("QUERY {}",json!({"root":root,"input":text,"parsed_path":path,"result":format!("{value:?}")}));
    let value = value.unwrap();
    assert_eq!(value["path"],raw);
    let encoded = serde_json::to_vec(&value).unwrap();
    assert_eq!(serde_json::from_slice::<Value>(&encoded).unwrap(),value);
    value
}
#[test]
fn native_literal_matrix() {
    let pairs = [(r"a\b.txt","a/b.txt"),("space file.txt","space_neighbor.txt"),
        (":lead.txt","lead.txt"),(":(glob)*.txt","glob-neighbor.txt"),
        ("br[ac].txt","bra.txt"),("(paren).txt","paren.txt"),
        ("--","dash-neighbor.txt"),("--output=SIDE_EFFECT.txt","option-neighbor.txt")];
    for (case,(selected,neighbor)) in pairs.iter().enumerate() {
        for mode in ["tracked","untracked","nohead"] {
            let root=repository(&format!("{mode}-{case}"),mode!="nohead");
            if let Some(parent)=root.join(neighbor).parent() {fs::create_dir_all(parent).unwrap();}
            fs::write(root.join(selected),"SELECTED_BASE\n").unwrap();
            fs::write(root.join(neighbor),"NEIGHBOR_BASE\n").unwrap();
            if mode!="untracked" {
                git(&root,&["add","--",selected,neighbor]);
                if mode=="tracked" {git(&root,&["commit","-qm","base"]);}
            }
            fs::write(root.join(selected),"SELECTED_123_CONTENT\n").unwrap();
            fs::write(root.join(neighbor),"NEIGHBOR_123_CONTENT\n").unwrap();
            let result=query(&root,selected);let diff=result["diff"].as_str().unwrap();
            assert!(diff.contains("+SELECTED_123_CONTENT"),"{result}");
            assert!(!diff.contains("NEIGHBOR_123_CONTENT"),"{result}");
            assert!(!root.join("SIDE_EFFECT.txt").exists());
        }
    }
}
#[test]
fn literal_directories_and_declared_untracked_boundary() {
    let root=repository("directories",true);
    for dir in [r"scope\unit","scope/unit","space dir","space_neighbor",":(glob)dir","dir"] {
        fs::create_dir_all(root.join(dir)).unwrap();
        fs::write(root.join(dir).join("seed.txt"),format!("base {dir}\n")).unwrap();
    }
    git(&root,&["add","--","."]);git(&root,&["commit","-qm","directories"]);
    for (selected,neighbor) in [(r"scope\unit","scope/unit"),("space dir","space_neighbor"),(":(glob)dir","dir")] {
        fs::write(root.join(selected).join("seed.txt"),"SELECTED_DIR_123\n").unwrap();
        fs::write(root.join(neighbor).join("seed.txt"),"NEIGHBOR_DIR_123\n").unwrap();
        let result=query(&root,selected);let diff=result["diff"].as_str().unwrap();
        assert!(diff.contains("+SELECTED_DIR_123"),"{result}");
        assert!(!diff.contains("NEIGHBOR_DIR_123"),"{result}");
        fs::write(root.join(selected).join("new.txt"),"UNTRACKED_DIRECTORY_OBSERVATION\n").unwrap();
        let observed=query(&root,selected);
        println!("DECLARED_COLLECTION_BOUNDARY {}",json!({"path":selected,"includes_new":observed["diff"].as_str().unwrap().contains("UNTRACKED_DIRECTORY_OBSERVATION"),"result":observed}));
    }
    let whole=diff_value_at(&root,None).unwrap();let dot=query(&root,".");
    assert_eq!(whole["diff"],dot["diff"]);
}
#[test]
fn unborn_head_mixed_scope_observation_and_explicit_cached_file() {
    let root=repository("unborn-mixed",false);
    fs::write(root.join("staged.txt"),"STAGED_ONLY_123\n").unwrap();
    fs::write(root.join(r"unstaged\file.txt"),"UNSTAGED_BASE_123\n").unwrap();
    git(&root,&["add","--","."]);
    fs::write(root.join(r"unstaged\file.txt"),"UNSTAGED_CURRENT_123\n").unwrap();
    let staged=query(&root,"staged.txt");assert!(staged["diff"].as_str().unwrap().contains("+STAGED_ONLY_123"));
    let unstaged=query(&root,r"unstaged\file.txt");assert!(unstaged["diff"].as_str().unwrap().contains("+UNSTAGED_CURRENT_123"));
    let whole=diff_value_at(&root,None).unwrap();
    println!("PREEXISTING_UNBORN_SCOPE_OBSERVATION {whole}");
}
#[test]
fn inherited_pathspec_environment_must_not_break_explicit_file() {
    let root=repository("inherited-env",true);
    fs::write(root.join("selected.txt"),"old\n").unwrap();
    fs::write(root.join("neighbor.txt"),"neighbor old\n").unwrap();
    git(&root,&["add","--","."]);git(&root,&["commit","-qm","base"]);
    fs::write(root.join("selected.txt"),"SELECTED_ENV_123\n").unwrap();
    fs::write(root.join("neighbor.txt"),"NEIGHBOR_ENV_123\n").unwrap();
    println!("ENV {}",json!({"glob":std::env::var("GIT_GLOB_PATHSPECS").ok(),"noglob":std::env::var("GIT_NOGLOB_PATHSPECS").ok(),"icase":std::env::var("GIT_ICASE_PATHSPECS").ok()}));
    let value=query(&root,"selected.txt");
    assert!(value["diff"].as_str().unwrap().contains("+SELECTED_ENV_123"));
    assert!(!value["diff"].as_str().unwrap().contains("NEIGHBOR_ENV_123"));
}
