# ZS1-123：对 C native/literal diff 候选的独立反例审查

发现并修补 1 项 P2 回归：C 新增 `--literal-pathspecs` 后，继承 `GIT_GLOB_PATHSPECS=1` 或 `GIT_ICASE_PATHSPECS=1` 的进程连普通 `/diff selected.txt` 都失败。已在 exact Cafter 上分别跑实际 public API 失败；Cbefore 对照成功。此包的 `followup.patch` **只相对 Cafter**，不是替换 C 的原修复。

## 输入与整文件理解

输入 C ready 的 manifest SHA 为 `621a28e50db92d5b68bebfe8528e83ee8a2e96d7997efb1bd55d328cf0050741`，37 个 manifest 文件复制前全部核验。输入完整包冻结在 input-C-ready.tar.gz；C 产品 patch 为 `0828141ec8f2220044e42ea8ebd6a45def25f97d1a52bb2b69113764c05ab4cc`，16554 bytes / 434 lines，已完整阅读。

| 对象 | Bytes / Lines | SHA-256 |
|---|---|---|
| Cbefore / before.rs | 41343 / 1078 | 5912f71faa07e7f529b1c9bef875a977873c6a5e152d103e837d0fbac001cd32 |
| Cafter / candidate.rs | 50852 / 1334 | 13784372cd5c587b79ef1b726f61caf97a13000de9759aafa8a48f92772b31aa |
| 本次 after.rs | 52674 / 1371 | 811bde9af190b2e439542c0a89dd8e8a1f76bbcf8eb6aa3ad3b16143447ec30b |
| followup.patch | 2820 bytes | 64b9b2cd826a3b988d4bf6fa69bbdfc506aae912c36bb43f81ed9733d27fa9cf |

candidate.rs 按 1–350、351–700、701–1050、1051–1334 连续完整读完，无截断；full-read.json 绑定每块。语义理解如下：

- 1–350：model/resource/队列 owner 分类；diff 先以 canonical workspace 解析并拒绝 escape/symlink，再做 binary 检查及 git status；显式 untracked 用 no-index，tracked 用 HEAD，无 HEAD 保留既有 fallback。新的原生 Path/OsStr 参数避免把 Unix backslash 变成 separator；`--` 保护参数边界，literal 模式另行保护 pathspec。
- 351–700：目录 untracked 的有限拼接、stdout/status/脱敏界限、JSON path 投影；附件仍以原生相对 String 保留 I/O 身份，并在 size/hash/staging/admission 多层校验。resolve_relative 和 MIME/摘要没有随本次增量改变。问题入口是两个 Git 子进程的环境：literal 模式并不会自动清除继承的其它 pathspec 模式。
- 701–1050：Git stdout cap/kill/wait、porcelain untracked 收集（保留跳过引号行的旧规则）、文本截断和 typed queue/tree/output 请求；原附件测试覆盖边界、symlink、不同真实 inode、JSON 与 admission 材料化。
- 1051–1334：附件端到端断言的末段与 C 的 8 个 diff 回归。C 的普通环境案例能证明文件身份修复，但未覆盖继承的 glob/icase 环境。目录引号收集和无 HEAD 的整体混合投影是旧边界，不能因本单性能/身份目标擅自扩大。

必要 parser 片段沿 C 的冻结 slash-parser-context.txt/hash 使用：tokenizer 在引号内也把反斜杠当作转义。独立测试先用 JSON string quoting 形成真实 `/diff ...` 文本，再断言 parser 得到准确原生路径；没有把输入转义错误当成 Git 缺陷。编译使用 C 私有冻结副本的 229 个完整输入，仅替换本产品文件；额外 integration probe 是私有审查证据，不是另一产品文件的补丁。

## P2 实际反例与最小修补

`candidate-glob-env`、`candidate-icase-env` 都在 exact Cafter 上运行同一个 public `diff_value_at` 测试：各 0 passed / 1 failed、Cargo exit 101，Git status 返回 128。测试仓库先用独立、清除该变量的 setup 命令建立两个普通 tracked 文件，再让被测 API 原样继承变量，避免“夹具 git init/add 失败”混淆产品失败。

额外真实 Git 命令保留在 git-env-observation.json：`git --literal-pathspecs status --porcelain=v1 -- selected.txt` 的 glob/icase 环境分别返回 128，stderr 都为 `global 'literal' pathspec setting is incompatible with all other global pathspec settings`。相同命令仅设 NOGLOB 则返回 0，因此没有清理这个未复现冲突的变量。

`precandidate-env-control` 在 Cbefore、同时继承 glob 和 icase 时返回正确 SELECTED_ENV_123 hunk，1/1、exit 0；这证明是 C 的新增 literal 模式所引入，而不是缺 Git、无 HEAD、构造路径或本机权限失败。

修补仅在 git_status / git_diff_process 两处 Command 上 `env_remove(GIT_GLOB_PATHSPECS)`、`env_remove(GIT_ICASE_PATHSPECS)`，保留 `--literal-pathspecs`、原生 Path、`--`、所有原路径政策和界限。没有修改父进程环境、Git 全局配置、目录递归或其它 owner。另在本文件 C 的测试 helper 中隔离 fixture setup 环境，新增一个测试在两个独立子进程内分别设置冲突变量，执行真实已有的 tracked backslash identity 测试；没有不安全的进程全局 env mutation 或新 ignore。

## 有限矩阵与附件回归

- Cafter 默认环境独立矩阵 4/4：8 组文件名称 × tracked/untracked/noHEAD 三种状态，共 24 个文件情景；包含 Unix literal backslash 与真实目录 counterpart、空格、前导冒号、`:(glob)*.txt`、方括号、圆括号、文件名 `--`、`--output=SIDE_EFFECT.txt`。断言真实 parser 路径、对应 hunk、没有邻居 hunk、JSON round-trip/path 和没有 option side effect 文件。
- 另验证三个目录的 tracked 范围：literal backslash、空格、magic-looking 目录，各自与不同真实目录内容区分；`/diff .` 与无显式 path 等价；无 HEAD 显式 cached / unstaged 路径均正确。
- 修补后同时继承 glob+icase，完整独立矩阵 4/4；文件内测试 14/14（含 5 个原附件测试、8 个 C diff 测试、新增环境回归，后者另执行两个 child case）；既有 tests/slash_actions.rs 11/11。
- Clippy `--lib --test slash_actions --test independent_diff_identity -- -D warnings` 退出 0；rustfmt check 0。保持 vendor/crossterm 既有 unused_parens 依赖警告，没有修改依赖。

附件构造、路径校验、size/hash helper 从 Cbefore 到 Cafter 再到本次 after 逐字一致；原附件 identity tests 与 Cafter 逐字一致，verify.py 直接断言。原真实 inode、pending reference、JSON path、size/SHA、admission metadata 和 journal 不泄露 payload 的断言全部保留且实际运行通过。

## 不能误记成新通过的旧缺口

unchanged-policy-observations.json 保留这些实际结果，以下不是断言“功能完整”的通过项：

1. 已跟踪目录有普通 seed 后，新增未跟踪文件：`scope\unit/new.txt` 与 `space dir/new.txt` 的 Git status 为 quoted 路径，目录汇总没有包含新增 hunk；`:(glob)dir/new.txt` 的 unquoted 路径则被包含。C review 已明确沿用原 quoted 行跳过规则，本次未改 untracked_paths、未开启递归或扩宽其收集政策。显式文件请求仍可工作。
2. 无 HEAD 的整仓同时有 staged-only 文件和另一个 unstaged 文件时，结果只显示 unstaged 部分，staged-only 未纳入；显式请求 staged-only 文件正常。此 fallback 选择逻辑从 Cbefore 就存在，本次未改，不将其描述成“全部 staged/unstaged 组合已覆盖”。若主控需要改变整仓聚合语义，应另行确定范围。

## 重放与精确边界

每轮完整 argv/cwd/环境差异/时间/退出码/日志在 *.run.json、*.log；13 轮均绑定实际产品源，失败未覆盖。所有实际 Git setup 命令及 public API JSON 记录在 matrix/env 日志；普通仓库保存在 git-fixtures.tar.gz。native rustc 1.94.0、Apple Git 2.50.1；Cargo 独立 target123-independent-review-3.1.20/cargo-target，所有 Cargo 都 offline/locked。HOME/CODEX_HOME 不变，测试禁用 Git 全局/系统配置，没有网络、HTTP、PTY、全 suite 或 Windows 实测。

build-context.tar.gz 是 229 个完整冻结输入加独立审查测试；原有其它 228 输入哈希未变。本任务只在新私有目录工作，没有产品 commit、没有写主库/C ready/任何既有 ready。主控关于 126 PTY termios ENOTTY 的新反馈不改变本任务，也没有回写旧 126 包。

`python3 verify.py` 完全离线：核验 C 包 37 文件、源/日志/构建上下文/附件保留；在新临时 Git 仓库先 C-product.patch 把 5912…→1378…，再 followup.patch 把 1378…→811b…，逐步正向 --check/apply，逆向 --check/apply 回到每个 exact hash，并确认无关 binary sentinel 和最终干净 diff。主控应先合入 C，再应用本次 followup；本包不接受 ZS1-123 或任何整体 gate。
