"""Offline exact C-input + follow-up verification; never edits a live checkout."""
from pathlib import Path
import argparse,hashlib,json,subprocess,tarfile,tempfile
P=Path(__file__).resolve().parent
H=lambda d:hashlib.sha256(d).hexdigest()
def verify():
 manifest=P/'manifest.json'
 if manifest.exists():
  for r in json.loads(manifest.read_text())['files']:
   d=(P/r['path']).read_bytes();assert H(d)==r['sha256'] and len(d)==r['bytes'],r['path']
 names={'before.rs':'5912f71faa07e7f529b1c9bef875a977873c6a5e152d103e837d0fbac001cd32','candidate.rs':'13784372cd5c587b79ef1b726f61caf97a13000de9759aafa8a48f92772b31aa','after.rs':'811bde9af190b2e439542c0a89dd8e8a1f76bbcf8eb6aa3ad3b16143447ec30b','C-product.patch':'0828141ec8f2220044e42ea8ebd6a45def25f97d1a52bb2b69113764c05ab4cc','followup.patch':'64b9b2cd826a3b988d4bf6fa69bbdfc506aae912c36bb43f81ed9733d27fa9cf'}
 for n,h in names.items():assert H((P/n).read_bytes())==h,n
 a=(P/'candidate.rs').read_text();b=(P/'after.rs').read_text();old=(P/'before.rs').read_text()
 block='''        // The owner selects literal paths, independently of inherited Git
        // glob/case modes, which Git rejects when combined with literal mode.
        .env_remove("GIT_GLOB_PATHSPECS")
        .env_remove("GIT_ICASE_PATHSPECS")
'''
 boundary='#[cfg(test)]\nmod attachment_identity_tests'
 assert b.split(boundary)[0].count(block)==2 and b.split(boundary)[0].replace(block,'')==a.split(boundary)[0]
 end='#[cfg(all(test, unix))]\nmod diff_identity_tests'
 assert a[a.index(boundary):a.index(end)]==b[b.index(boundary):b.index(end)]
 for start,finish in [('pub fn attach_value(', 'fn path_display('),('fn untracked_paths(', 'fn git_diff_process(')]:
  assert old[old.index(start):old.index(finish)]==a[a.index(start):a.index(finish)]==b[b.index(start):b.index(finish)]
 lines=a.encode().splitlines(keepends=True);at=1
 for r in json.loads((P/'full-read.json').read_text()):
  assert r['first']==at and r['fully_read'];d=b''.join(lines[at-1:r['last']]);assert len(d)==r['bytes']<=262144 and H(d)==r['sha256'];at=r['last']+1
 assert at==1335
 with tarfile.open(P/'input-C-ready.tar.gz','r:gz') as t:
  def read(n):return t.extractfile('C-ready/'+n).read()
  raw=read('manifest.json');assert H(raw)=='621a28e50db92d5b68bebfe8528e83ee8a2e96d7997efb1bd55d328cf0050741'
  cm=json.loads(raw)
  for r in cm['files']:assert H(read('files/'+r['path']))==r['sha256']
 oldctx={r['path']:r for r in json.loads((P/'build-context.json').read_text())['files']}
 ctx=json.loads((P/'final-build-context.json').read_text())['files']
 with tarfile.open(P/'build-context.tar.gz','r:gz') as t:
  assert len(t.getmembers())==len(ctx)==230
  for r in ctx:
   d=t.extractfile(r['path']).read();assert len(d)==r['bytes'] and H(d)==r['sha256']
   if r['path']=='src/slash_actions.rs':assert d==b.encode()
   elif r['path']=='tests/independent_diff_identity.rs':assert d==(P/'independent_diff_identity.rs').read_bytes()
   else:assert r==oldctx[r['path']]
 for n,source in json.loads((P/'run-source-bindings.json').read_text()).items():
  r=json.loads((P/n).read_text());assert r['status']=='finished' and H((P/source).read_bytes())==r['source_sha256']
  d=(P/r['log']).read_bytes();assert H(d)==r['sha256'] and len(d)==r['bytes']
  if 'cargo' in r['argv']:assert '--offline' in r['argv'] and '--locked' in r['argv'] and '+stable-aarch64-apple-darwin' in r['argv']
 for n,code in [('candidate-glob-env',101),('candidate-icase-env',101),('precandidate-env-control',0),('fixed-matrix',0),('fixed-inline',0),('existing-integration',0),('clippy',0),('fmt-check',0)]:
  assert json.loads((P/(n+'.run.json')).read_text())['exit_code']==code
 commands=[]
 with tempfile.TemporaryDirectory(prefix='zs123-independent-apply-') as tmp:
  root=Path(tmp);(root/'src').mkdir();target=root/'src/slash_actions.rs';target.write_bytes((P/'before.rs').read_bytes());sentinel=root/'unrelated.bin';sentinel.write_bytes(b'123\0UNRELATED\xff\n')
  def run(argv):
   p=subprocess.run(argv,cwd=root,capture_output=True,text=True);commands.append({'argv':argv,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr});assert p.returncode==0,commands[-1]
  run(['git','init','-q']);run(['git','add','src/slash_actions.rs','unrelated.bin'])
  for patch,expected in [('C-product.patch','candidate.rs'),('followup.patch','after.rs')]:
   name=str((P/patch).resolve());run(['git','apply','--check',name]);run(['git','apply',name]);assert target.read_bytes()==(P/expected).read_bytes()
  for patch,expected in [('followup.patch','candidate.rs'),('C-product.patch','before.rs')]:
   name=str((P/patch).resolve());run(['git','apply','--reverse','--check',name]);run(['git','apply','--reverse',name]);assert target.read_bytes()==(P/expected).read_bytes()
  assert sentinel.read_bytes()==b'123\0UNRELATED\xff\n';run(['git','diff','--exit-code'])
 return {'status':'passed','manifest_checked':manifest.exists(),'C_files_verified':37,'full_read_lines':1334,'build_inputs':230,'unchanged_original_other_inputs':228,'followup_after_sha256':H(b.encode()),'commands':commands,'sentinel_unchanged':True}
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--receipt');args=parser.parse_args();result=verify()
 if args.receipt:Path(args.receipt).write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result,indent=2))
