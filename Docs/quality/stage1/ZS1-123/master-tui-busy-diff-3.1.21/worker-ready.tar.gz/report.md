# ZS1-123 · 忙时本地 diff/review 私有候选

本候选修复正式 TUI 在 provider 忙时禁用 `/diff`、`/review`，以及无法借用 Agent 时误用进程 cwd 的问题。最终产品补丁仅修改 `src/tui.rs`、`src/slash_actions.rs`。主库未修改，123 仍未接受；这是 123 的一个具体产品差距，不是 123 全项完成，也不代替 C 的 306 源文件复核。`/review` 仍是本地 Diff 别名，不是 Codex 模型 review 全功能。

## 精确基线与最终候选

要求为 3.1.21；requirement `3456abcbbebbc4e0ab383c319851b0a6e71b19ee9b3c060a6e212f61a89c9d9d`，baseline snapshot `92b06c4b1dcdca7614d226ce5f41205646a9e63967789d2b6ed4ee272d240884`，run `zenpi-stage1-20260911`。

| 对象 | SHA-256 |
|---|---|
| 原正式 release，6073504 B | d0ccf6f5d13dc0e04abe489335bc66be7cee3d0014501b4eb42bc9514dc3c05f |
| 原 TUI | 994215c7ca6cc471bb35247a04460d6c5ef52192999e4b5585ea1c818a429578 |
| 原 slash_actions | e8635a418ccd613ef0587695ee9318d05e679be202494c0f04eb04651c12184e |
| 最终 TUI，638305 B | 0deb8e0e13cfdad0aa00e07d79caf573e9aa36095a9bcefb4219ed8f70936557 |
| 最终 slash_actions，75023 B | 3ff4bfdcfd70e8321ab2ccb1b3b43830a4753bd4f4bcf708e0166c4ac3b44eb1 |
| 最终 release，6093328 B | a15a595e96629695db6edccce367823ce2a551b5d5e58baf6fb7a65db09e85e6 |
| 主控新增回归原样保留 | f2f1d037e8f075c40000ffc0b8d83035b67ccff6b30cfa80ed26965e98b9b1e8 |

`initial-inputs.json` 记录 225 个准入构建输入；最终仅以上两个源码变化，223 个其余输入未变。`final-input-audit.json` 显示主库这 225 个文件全未漂移。初始源码复制自当时主库，未拿旧工作树产品替代基线。完整阅读了主控新回归、1644 行 slash_actions（含原内部测试）、原 tests/slash_actions.rs，以及所改 TUI command_available、完整 slash dispatcher、完整 run_async_with_profile 和必要项目/草稿/消息/会话函数。具体范围及字节身份见 `reading-ledger.json`。未声称完整理解整份 TUI 文件或未读取的其他模块。

主控后续明确确认 slash_actions 在 123 owned_paths 内并允许最小可取消入口。authority-initial 是构建准备阶段复制的权威快照，非冒称任务开始瞬间；authority-final 是封装前主库快照。四个权威键和 123/正式依赖相关行单独比对，全文件保留；Gantt/无关行变化不用于推翻或冒充本项验收。

## 行为和所有权

- 忙时菜单允许 diff/review；正式路由在任何 Agent try_lock 之前交给单独本地 host，实际提交保持同一合同。未扩大 attach/model 的忙时权限。
- 准入冻结稳定 project、绝对 cwd、session path、session ID、项目草稿 generation；生产入口缺少正确项目/会话时明确报错，不回落进程 cwd。
- 一个工作线程、一个在途任务、容量 1 命令/回复通道，无排队扩张。第二个本地 diff 明确拒绝并恢复原提交；已有 provider 可继续运行。
- 结果投给原 project/session；切换可见项目不改变结果归属；会话/项目 generation 已替换则取消并丢弃结果。未切回 UI 来投递后台结果，因此不修改可见项目的草稿、布局或焦点。
- Ctrl-C 或 `/cancel` 优先取消当前项目的本地检查。取消位可抑制已完成但未投递的成功；轮询回收后槽位可复用。关闭断开有界通道、置取消位并 join，不分离线程。
- 同步 `dispatch_slash_command` 优先选中项目元数据；没有任何 tab 元数据的旧嵌入调用者仍可显式传入 Agent 的工作区。没有两种明确上下文之一就失败。生产 TUI 不使用该同步 Diff 分支。
- 失败恢复仅适用于同一项目/会话且 epoch 未变化的原草稿；后续输入（包括输入后清空）优先。后台结果只追加有界消息，不改 BentoBox。

## 可取消读取边界

原 `diff_value_at` 调用者仍走原同步 Git 路径，原路径/输出合同保留。新入口共享同一 diff 构造、路径拒绝和脱敏逻辑，在路径步骤、文件读取前后、status 每行及 Git 输出读取间检查取消。

新入口在 Unix 为每个 Git 子进程建独立 process group，stdin 空、stderr 丢弃，stdout 非阻塞读取。操作 deadline 30 秒；status 32 KiB、patch 64 KiB、untracked 32 文件沿用原上限。RAII 在成功、取消、超限、错误、管道关闭但子进程未退出等路径终止该组并 wait 直接子进程。未通过后台读取线程掩盖阻塞。显式文件的二进制前缀读取最多 8 KiB，Unix 控制路径 O_NONBLOCK/O_NOFOLLOW，并核验打开对象为普通文件。

限制：本候选实际验证平台是 macOS arm64，Rust 1.94.0；新可取消入口在非 Unix 明确返回不支持，不宣称 Windows 可用。内核文件系统调用本身不能被合作式取消抢占，极端挂死的文件系统可能延迟返回/join；30 秒是检查点/Git 等待的 deadline，不是任意内核 I/O 的硬实时保证。同步嵌入入口仍同步，不承诺其终端响应能力。

## 实测结果

主控原 tests/tui_busy_diff.rs：1 pass / 2 fail，日志原样在 baseline/master-regression-before.log。

最终对应 Rust 检查 42 pass：

| 检查 | 结果 | 证据 |
|---|---|---|
| LocalDiffHost 归属/草稿/会话/容量/取消/join | 5 pass | host-tests-v4.log |
| slash_actions 路径、附件、差异语义及新取消读取 | 23 pass | slash-tests-v1.log，所测 slash_actions SHA 与最终完全相同 |
| 原样 slash_actions 集成回归 | 11 pass | integration-tests-v2.log |
| 主控新 busy diff 回归原样 | 3 pass | integration-tests-v2.log |

原正式 CLI 的独立 PTY before-v2 为 6 pass / 3 fail：process cwd A、选中 B，真实 provider 首 delta 后门控，diff/review 不执行 B 本地读取，路径拒绝也被忙时白名单挡住。HTTP 请求数 1，切项目、布局、原草稿、退出均正常。

最终 release 的 `pty-after-final` 同样 9 个判据全部通过：diff/review 本地读取 B、拒绝父目录逃逸、HTTP 仍只有 1 次、原项目/布局/草稿保持、provider 忙时可切换项目、正常退出恢复终端。

`pty-slow-after-final` 10 个判据全部通过：实际 PATH 中的受控 Git 包装进程在 stdout 前门控，provider 也在首 delta 后门控；终端继续处理输入和项目切换。解除第一份 Git 门控后结果仅进入原 B/session，A/B 草稿和布局不变。第二份仍门控的 Git 被 Ctrl-C 取消并回收，无迟到成功、无额外 provider 调用、槽位可重用。provider 完成后第三份 Git 仍门控，正常 `/quit` 回收并退出，无夹具释放门控才能退出的伪成功。此次取消 0.1117695 秒、正常退出 0.633980334 秒，仅是本夹具观察值，不是全局性能预算结果。

全部 PTY 原始字节、重建屏幕、HTTP 请求、checkpoint/session/项目夹具和慢 Git PID/参数记录均保留。未运行全量生产预算、未预热主库 release、未执行旧封存 runner、未修改 HOME/CODEX_HOME、未新增 task/subagent。

## 失败和版本链

所有失败见 `failures.md`，不覆盖、不归零：初始 PTY StopIteration；缺失 x86_64 rustfmt/rustc 工具链；新增测试迭代器 API 编译错误及对应源码；初版 after 角色大小写断言失败。初版 after 原始回执已正确读取 B，离线对 before/after 使用实际 Serde `System/Error` 重判，分别 6/3、9/0；没有用该离线复核替换原失败文件。最终兼容性调整后实际重建最终 binary 并各运行一次新的基础/慢 Git PTY，均通过。`tested-v1` 与最终源码/二进制明确分开，不混用证据。

初版曾给 tests/slash_actions.rs 添加 tab metadata；最终为保留显式 Agent 的嵌入调用合同，恢复该测试文件全部原字节，仅在同步缺省元数据场景使用显式 Agent 工作区。主控新测试同样原样携带，不在产品补丁新增/替换测试文件。产品测试新增在两个已授权源文件的内部测试模块。

## 交付与回滚

`candidate.patch` 是对所列精确原字节的双文件补丁，`baseline/` 和 `candidate/` 提供完整对照与构建源码。只供主控逐文件复核后集成，工作线程未向主库 apply。回滚即逆向该两文件补丁；不触及会话、项目状态或布局。

`verify_portable.py` 只核验本包文件哈希、两文件补丁的精确生成、原样回归、测试/PTY结果与权威作用域，不执行 Cargo、CLI、HTTP、PTY、Git、旧脚本或产品预算。可从任意 cwd 调用，参数为包目录。冻结后运行一次，结果单独保存在包外；该核验不是产品实测的替代品。
