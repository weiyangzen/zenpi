"""New ZS1-123 real PTY/HTTP probe. Never invokes a historical runner."""
import sys, os, json, time, threading, hashlib, subprocess, traceback
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pty_helpers import Terminal, drain, screen_text
binary=Path(sys.argv[1]).resolve(); out=Path(sys.argv[2]).resolve();out.mkdir()
root=out/'fixture';config=root/'config'; a=root/'initial';b=root/'second'
for p in [config,a,b,root/'sessions']:p.mkdir(parents=True)
for p,marker in [(a,'FIRST_PROJECT_ONLY'),(b,'SECOND_PROJECT_ONLY')]:
 subprocess.run(['/usr/bin/git','init','--quiet',str(p)],check=True)
 (p/'note.txt').write_text(marker+'\n')
(root/'outside.txt').write_text('OUTSIDE_PROJECT\n')
finish=threading.Event();first=threading.Event(); requests=[]
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def do_POST(self):
  body=json.loads(self.rfile.read(int(self.headers['Content-Length'])));requests.append(body)
  self.send_response(200);self.send_header('Content-Type','text/event-stream');self.end_headers()
  def emit(delta,reason=None):
   self.wfile.write(('data: '+json.dumps({'id':'busy-fixture','model':body['model'],'choices':[{'index':0,'delta':delta,'finish_reason':reason}]})+'\n\n').encode());self.wfile.flush()
  try:
   emit({'role':'assistant','content':'PROVIDER_FIRST_DELTA '});first.set()
   while not finish.wait(.1):
    self.wfile.write(b': provider gate\n\n');self.wfile.flush()
   emit({'content':'PROVIDER_FINISHED'},'stop');self.wfile.write(b'data: [DONE]\n\n');self.wfile.flush()
  except (BrokenPipeError,ConnectionResetError):pass
server=ThreadingHTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever);thread.start()
(config/'config.toml').write_text(f'backend="openai"\nmodel="gpt-4.1"\nbase_url="http://127.0.0.1:{server.server_port}/v1"\nwire_api="chat"\nrequires_openai_auth=false\nmax_retries=0\n')
(config/'auth.json').write_text('{"OPENAI_API_KEY":"busy-local-fixture"}');(config/'auth.json').chmod(0o600)
env={k:v for k,v in os.environ.items() if not k.startswith(('ZENPI_','OPENAI_')) and k.lower() not in ('http_proxy','https_proxy','all_proxy','no_proxy')};env.update(ZENPI_HOME=str(config),TERM='xterm-256color')
checks={};result={'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'checks':checks,'scope':'ZS1-123 local Diff alias, no model review claim'};t=None
checkpoint=config/'project-tabs.json'
def saved():return json.loads(checkpoint.read_text())
def row(p):return next(v for v in saved()['project_state'] if v['metadata']['cwd']==str(p.resolve()))
def msgs(p):return row(p)['messages']
def inspect(alias,path):
 t.clear_input(); before=len(msgs(b));t.command('/'+alias+' '+path)
 deadline=time.monotonic()+2
 while time.monotonic()<deadline:
  drain(t.fd,t.output,.02)
  if any(v['text'].startswith('diff ') or v['role']=='Error' for v in msgs(b)[before:]):break
 new=msgs(b)[before:];(out/(alias+'-'+path.replace('/','_')+'.json')).write_text(json.dumps(new,indent=2))
 return new
try:
 t=Terminal(binary,root,env);t.folder(b);t.wait(lambda:any(v['metadata']['cwd']==str(b.resolve()) and v['name']==saved()['projects'][saved()['active']] for v in saved()['project_state']))
 layout=row(b)['layout'];owner=row(b)['metadata'];t.command('HOLD_BUSY_PROVIDER');t.expect(b'PROVIDER_FIRST_DELTA');assert first.is_set() and not finish.is_set()
 checks['provider_gate_after_real_first_delta']=True
 for alias in ['diff','review']:
  new=inspect(alias,'note.txt');checks[alias+'_reads_selected_B_while_busy']=any(v['role']=='System' and '+SECOND_PROJECT_ONLY' in v['text'] for v in new) and not any('FIRST_PROJECT_ONLY' in v['text'] for v in new)
 new=inspect('diff','../outside.txt');checks['escape_rejected_without_data']=any(v['role']=='Error' and 'path denied' in v['text'] for v in new) and not any('OUTSIDE_PROJECT' in v['text'] for v in new)
 checks['no_extra_provider_call']=len(requests)==1
 checks['selected_owner_and_layout_unchanged']=row(b)['metadata']==owner and row(b)['layout']==layout
 t.clear_input();t.write('draft remains 中文'.encode());t.wait(lambda:t.draft()=='draft remains 中文')
 t.folder(a);t.wait(lambda:row(a)['name']==saved()['projects'][saved()['active']]);checks['keyboard_project_switch_while_busy']=True
 checks['background_draft_retained']=row(b)['draft']['input']=='draft remains 中文'
 finish.set();t.wait(lambda:'PROVIDER_FINISHED' in json.dumps(msgs(b)))
 t.close(preserve_draft=True);checks['normal_exit_restores_terminal']=True
 result['status']='passed' if all(checks.values()) else 'failed'
except BaseException as e:
 result.update(status='fixture_failed',error=repr(e),traceback=traceback.format_exc());print(result['traceback'])
finally:
 finish.set()
 if t:
  t.cleanup();(out/'pty.log').write_bytes(bytes(t.output));(out/'screen.txt').write_bytes(screen_text(bytes(t.output)))
 server.shutdown();server.server_close();thread.join()
 (out/'http.json').write_text(json.dumps(requests,indent=2));(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result,indent=2))
