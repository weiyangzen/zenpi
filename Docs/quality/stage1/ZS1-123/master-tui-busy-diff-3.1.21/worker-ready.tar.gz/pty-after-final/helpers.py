import os, pty, select, signal, struct, termios, time, fcntl, re, unicodedata, json
from pathlib import Path
def drain(fd: int, out: bytearray, timeout: float = 0.1) -> None:
    ready, _, _ = select.select([fd], [], [], timeout)
    if not ready:
        return
    try:
        out.extend(os.read(fd, 65536))
    except OSError:
        pass


def visible(data: bytes) -> bytes:
    # Enough ANSI removal for redraw-oriented assertions; no terminal
    # emulator is needed for this smoke.
    import re

    return re.sub(rb"\x1b(?:\[[0-?]*[ -/]*[@-~]|\][^\a]*(?:\a|\x1b\\))", b"", data)


def wait_text(fd: int, out: bytearray, needle: bytes, deadline: float) -> None:
    while time.monotonic() < deadline:
        drain(fd, out, 0.05)
        if needle.lower() in visible(bytes(out)).lower():
            return
    raise AssertionError(f"missing {needle!r}; tail={visible(bytes(out))[-8000:]!r}")


def send(fd: int, payload: bytes) -> None:
    os.write(fd, payload)
def screen_text(data,width=140,height=40,left_only=False):
    """Reconstruct the cursor-addressed cells Ratatui writes over a real PTY.

    Support CSI cursor/erase and OSC controls, including wide Unicode cells;
    styles do not change text. This is an assertion aid, not a replacement UI.
    """
    rows=[[' ']*width for _ in range(height)];x=y=0;i=0
    text=data.decode('utf-8',errors='replace')
    while i<len(text):
        char=text[i]
        if char=='\x1b':
            match=re.match(r'\x1b\[([0-?]*)([ -/]*)([@-~])',text[i:])
            if match:
                raw,_,command=match.groups();i+=len(match.group());parts=raw.lstrip('?').split(';');values=[int(p) if p.isdigit() else 0 for p in parts];n=values[0] or 1
                if command in 'Hf':y=max(0,min(height-1,n-1));x=max(0,min(width-1,(values[1] if len(values)>1 and values[1] else 1)-1))
                elif command=='G':x=max(0,min(width-1,n-1))
                elif command=='d':y=max(0,min(height-1,n-1))
                elif command=='A':y=max(0,y-n)
                elif command=='B':y=min(height-1,y+n)
                elif command=='C':x=min(width-1,x+n)
                elif command=='D':x=max(0,x-n)
                elif command=='J' and values[0] in (2,3):rows=[[' ']*width for _ in range(height)]
                elif command=='K':
                    start,end=(0,width) if values[0]==2 else ((0,x+1) if values[0]==1 else (x,width));rows[y][start:end]=[' ']*(end-start)
                elif command=='h' and raw=='?1049':rows=[[' ']*width for _ in range(height)];x=y=0
                continue
            match=re.match(r'\x1b\][^\a]*(?:\a|\x1b\\)',text[i:])
            if match:i+=len(match.group());continue
            i+=2;continue
        if char=='\r':x=0
        elif char=='\n':y=min(height-1,y+1)
        elif char=='\b':x=max(0,x-1)
        elif ord(char)>=32:
            cells=0 if unicodedata.combining(char) else (2 if unicodedata.east_asian_width(char) in ('W','F') else 1)
            if cells==0 and x>0:rows[y][x-1]+=char
            elif cells and x<width:
                rows[y][x]=char
                if cells==2 and x+1<width:rows[y][x+1]=''
                x+=cells
        i+=1
    return '\n'.join(''.join(row[:56] if left_only else row) for row in rows).encode()

class Terminal:
    def __init__(self,binary,root,env):
        self.output=bytearray();self.fd=None;self.pid=None
        self.checkpoint=Path(env['ZENPI_HOME'])/'project-tabs.json'
        pid,fd=pty.fork()
        if pid==0:
            os.chdir(root/'initial')
            os.execve(str(binary),[str(binary),'--mode','tui','--backend','openai','--session',str(root/'sessions/initial.jsonl')],env)
        self.pid,self.fd=pid,fd
        fcntl.ioctl(fd,termios.TIOCSWINSZ,struct.pack('HHHH',40,140,0,0))
        self.expect(b'Prompt')
    def expect(self,text,timeout=12,start=0):
        deadline=time.monotonic()+timeout
        while time.monotonic()<deadline:
            drain(self.fd,self.output,.05)
            normalize=lambda value: ''.join(c for c in value.decode(errors='replace').lower() if not c.isspace() and c not in '│─┌┐└┘●').encode()
            if any(normalize(text) in normalize(screen_text(bytes(self.output),left_only=left)) for left in (False,True)):return
        raise AssertionError(f'missing {text!r}: {screen_text(bytes(self.output)).decode(errors="replace")}')
    def wait(self,predicate,timeout=12):
        deadline=time.monotonic()+timeout
        while time.monotonic()<deadline:
            drain(self.fd,self.output,.05)
            try:
                value=predicate()
                if value:return value
            except (FileNotFoundError,json.JSONDecodeError):pass
        raise AssertionError(f'condition timed out: {visible(bytes(self.output[-7000:]))!r}')
    def write(self,data):send(self.fd,data)
    def draft(self):
        value=json.loads(self.checkpoint.read_text())
        active=value['projects'][value['active']]
        return next(row['draft']['input'] for row in value['project_state'] if row['name']==active)
    def clear_input(self):
        # Composer Ctrl-U is logical-line kill. Explicitly visit buffer start
        # and kill each visible line plus its LF; hidden fold LFs only add no-ops.
        # Picker/filter fields retain their own single-line Ctrl-U semantics.
        count = 2 * self.draft().count('\n') + 1
        self.write(b'\x1b[1;5H' + b'\x0b' * count)
        self.wait(lambda: self.draft() == '')
    def cancel_picker(self):
        self.write(b'\x1b')
        deadline=time.monotonic()+0.2
        while time.monotonic()<deadline:drain(self.fd,self.output,.02)
    def folder(self,path,mouse=True):
        mark=len(self.output)
        self.write(b'\x1b[<0;139;1M\x1b[<0;139;1m' if mouse else b'\x14')
        self.expect(b'Open project folder',start=mark)
        self.write(b'\x15\x1b[200~'+str(path).encode()+b'\x1b[201~\r')
    def type_text(self,text):
        # Model separate physical keystrokes when a scenario tests live menus.
        for char in text:
            self.write(char.encode())
            deadline=time.monotonic()+0.035
            while time.monotonic()<deadline:drain(self.fd,self.output,.005)
    def deliberate_enter(self):
        # Ordinary bytes written in one batch are paste-like. A command helper
        # models the later deliberate Enter, after the 120ms paste window.
        deadline=time.monotonic()+0.15
        while time.monotonic()<deadline:drain(self.fd,self.output,.01)
        self.write(b'\r')
    def command(self,text,expect=None):
        mark=len(self.output);self.write(text.encode())
        self.wait(lambda:self.draft().endswith(text))
        self.deliberate_enter()
        if expect:self.expect(expect,start=mark)
    def shell(self,command):
        mark=len(self.output);self.write(('!'+command).encode())
        self.wait(lambda:self.draft().endswith('!'+command))
        self.deliberate_enter()
        self.wait(lambda:b'Approvalrequired' in b''.join(screen_text(bytes(self.output)).splitlines()[1].split()))
        self.write(b'y\r')
        self.wait(lambda:b'Approvalrequired' not in b''.join(screen_text(bytes(self.output)).splitlines()[1].split()))
    def close(self,preserve_draft=False):
        if self.pid is None:return
        if preserve_draft:os.kill(self.pid,signal.SIGTERM)
        else:
            self.clear_input()
            self.write(b'/quit')
            self.wait(lambda:self.draft()=='/quit')
            self.deliberate_enter()
        deadline=time.monotonic()+8
        while time.monotonic()<deadline:
            drain(self.fd,self.output,.05)
            waited,status=os.waitpid(self.pid,os.WNOHANG)
            if waited:
                self.pid=None;os.close(self.fd)
                assert os.WIFEXITED(status) and os.WEXITSTATUS(status)==0,status
                assert b'\x1b[?1049l' in self.output,'alternate screen not restored'
                return
        raise AssertionError('TUI did not exit')
    def cleanup(self):
        if self.pid:
            # Closing the master first releases pending terminal output on
            # macOS. A blocking wait with the master open can hang teardown.
            os.close(self.fd);self.fd=None
            try:os.kill(self.pid,signal.SIGKILL)
            except ProcessLookupError:pass
            deadline=time.monotonic()+3
            while time.monotonic()<deadline:
                try:
                    if os.waitpid(self.pid,os.WNOHANG)[0]:self.pid=None;return
                except ChildProcessError:self.pid=None;return
                time.sleep(.01)
