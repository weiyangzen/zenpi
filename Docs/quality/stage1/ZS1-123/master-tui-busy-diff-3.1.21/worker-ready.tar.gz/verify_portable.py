#!/usr/bin/env python3
"""Only bounded offline package checks. Does not execute any product/runner."""
from pathlib import Path
import sys,json,hashlib,difflib,re
root=Path(sys.argv[1]).resolve();checks=[]
def check(name,ok):checks.append({'name':name,'passed':bool(ok)})
def read(name):return (root/name).read_bytes()
def js(name):return json.loads(read(name))
def sha(data):return hashlib.sha256(data).hexdigest()
m=js('manifest.json'); paths=[]
for f in m['artifacts']:
 p=f['path'];paths.append(p)
 check('artifact:'+p,not Path(p).is_absolute() and '..' not in Path(p).parts and not (root/p).is_symlink() and len(read(p))==f['bytes'] and sha(read(p))==f['sha256'])
check('exact inventory',sorted(paths)==sorted(str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p.name!='manifest.json') and len(paths)==len(set(paths)))
ident=js('candidate-identities-final.json')
check('only authorized two-file patch',{v['path'] for v in ident}=={'src/tui.rs','src/slash_actions.rs'})
patch=''
for f in ident:
 name=f['path'];a=read('baseline/'+name);b=read('candidate/'+name)
 check(name+' exact identities',sha(a)==f['before'] and sha(b)==f['after'] and len(b)==f['bytes'])
 patch+=''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='a/'+name,tofile='b/'+name))
check('patch exact forward/reverse source pair',patch.encode()==read('candidate.patch'))
check('original test preserved',read('candidate/tests/slash_actions.rs')==read('baseline/tests/slash_actions.rs'))
check('master regression preserved',sha(read('candidate/tests/tui_busy_diff.rs'))=='f2f1d037e8f075c40000ffc0b8d83035b67ccff6b30cfa80ed26965e98b9b1e8')
for f in js('initial-inputs.json')['files']:
 if f['path'] not in {'src/tui.rs','src/slash_actions.rs'}:
  check('unchanged input:'+f['path'],sha(read('candidate/'+f['path']))==f['sha256'])
check('main input observation',js('final-input-audit.json')['main_changed_since_source_capture']==[])
check('baseline executable',sha(read('baseline/zenpi-release'))=='d0ccf6f5d13dc0e04abe489335bc66be7cee3d0014501b4eb42bc9514dc3c05f')
binary=js('binary-final.json');check('final executable',sha(read(binary['path']))==binary['sha256'])
for file,needle in [('host-tests-v4.log','5 passed; 0 failed'),('slash-tests-v1.log','23 passed; 0 failed'),('integration-tests-v2.log','11 passed; 0 failed'),('integration-tests-v2.log','3 passed; 0 failed')]:check(file+':'+needle,needle in read(file).decode())
check('slash tests reused exact source',read('tested-v1/src/slash_actions.rs')==read('candidate/src/slash_actions.rs'))
for name,count in [('pty-after-final',9),('pty-slow-after-final',10)]:
 v=js(name+'/result.json');check(name,v['status']=='passed' and len(v['checks'])==count and all(v['checks'].values()) and v['binary_sha256']==binary['sha256'])
 check(name+' one HTTP',len(js(name+'/http.json'))==1)
 slow=name.startswith('pty-slow')
 if slow:
  pids=[json.loads(v) for v in read(name+'/fixture/git-pids.jsonl').decode().splitlines()]
  check('three controlled Git processes bound to B',len(pids)==3 and len({p['pid'] for p in pids})==3 and all(p['cwd'].endswith('/second') for p in pids))
v=js('pty-before-v2/result.json');check('real before retained',v['status']=='failed' and sum(v['checks'].values())==6 and len(v['checks'])==9)
check('fixture failure retained','StopIteration' in js('pty-before/result.json')['error'])
check('compile failure retained','error[E0599]' in read('host-tests-v2.log').decode())
check('initial after failure retained',js('pty-after/result.json')['status']=='failed' and js('pty-after/offline-review.json')['status']=='passed')
check('master original 1/2 retained','1 passed; 2 failed' in read('baseline/master-regression-before.log').decode())
for alias in ['diff','review']:
 check('final '+alias+' B receipt',any(v['role']=='System' and '+SECOND_PROJECT_ONLY' in v['text'] and 'FIRST_PROJECT_ONLY' not in v['text'] for v in js('pty-after-final/'+alias+'-note.txt.json')))
keys=['blueprint_version','requirement_digest','baseline_snapshot_sha256','run_id']
a=js('authority-initial/Docs/execution/active_requirement.json');b=js('authority-final/Docs/execution/active_requirement.json')
for k in keys:check('authority '+k,a[k]==b[k]==m[k])
items=['123','107','113','306','307','084','133']
for item in items:
 def row(folder):return next(v for v in read(folder+'/Docs/stage_1_v3_pi_mono_blueprint.md').decode().splitlines() if re.match(r'^- \[[ x]\] \*\*ZS1-'+item+r'\*\*',v))
 check('scoped blueprint row '+item,row('authority-initial')==row('authority-final'))
check('123 remains pending','- [ ] **ZS1-123**' in read('authority-final/Docs/stage_1_v3_pi_mono_blueprint.md').decode())
for v in js('old-ready-observation.json'):check('old manifest observation '+v['path'].split('/')[-2],v['matches'] and v['expected']==v['sha256'])
failed=[v for v in checks if not v['passed']]
print(json.dumps({'status':'passed' if not failed else 'failed','checks':checks,'passed':len(checks)-len(failed),'failed':len(failed),'manifest_sha256':sha(read('manifest.json')),'scope':'offline only; no main workspace, product, CLI, HTTP, PTY, Cargo or old runner execution'},indent=2))
sys.exit(bool(failed))
