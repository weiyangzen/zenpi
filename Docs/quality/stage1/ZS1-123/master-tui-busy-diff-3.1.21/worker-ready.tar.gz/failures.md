# Preserved failures and corrections

- Master regression original: 1 pass / 2 fail; unchanged copied before.log.
- pty-before: fixture StopIteration before any product checks because the project row was polled without waiting for its initial existence. Kept full original runner/helper/result/PTY. pty-before-v2 uses safe existence predicate; same product assertions, 6 pass / 3 fail.
- Default rustfmt/cargo x86_64 toolchain unavailable on this host (tool stdout and host-tests-v1.log). Selected already installed stable-aarch64-apple-darwin explicitly; no global toolchain/config/env mutation.
- host-tests-v2.log: seven compiler errors in newly appended tests (messages() returns an Iterator, not VecDeque). Corresponding tui/slash_actions source snapshots retained in compile-v2-sources. Fixed tests to use Iterator::any/last; host-tests-v3: 5 pass. No product thresholds changed.
- Broad batched reading tool outputs twice clipped small unrelated dispatcher sections; reread missing context in bounded calls. These are read transport truncations, not full-reading evidence or product failures.

- pty-after initial runner marked 3 false despite complete successful B diffs and path error in captured receipts: fixture compared lowercase role strings, but TuiMessage serializes `System`/`Error`. No runtime rerun. Separately retained offline-review.json applies the same corrected role predicate to before and after captured receipts: before 6/3, after 9/0. Original runner and failing result remain untouched.

- Final compatibility review restored the unmodified tests/slash_actions.rs fixture and preserved explicitly supplied Agent workspace for synchronous embedders lacking tab metadata. TUI metadata remains authoritative and production local worker does not borrow Agent. The already tested v1 source/binary and original integration test setup change are retained in tested-v1. Final source is retested under new outputs.
