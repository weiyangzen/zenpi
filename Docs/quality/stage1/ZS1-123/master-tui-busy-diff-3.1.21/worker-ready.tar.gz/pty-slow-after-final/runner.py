"""New ZS1-123 real PTY/HTTP probe. Never invokes a historical runner."""
import sys, os, json, time, threading, hashlib, subprocess, traceback
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pty_helpers import Terminal, drain, screen_text
binary=Path(sys.argv[1]).resolve(); out=Path(sys.argv[2]).resolve();out.mkdir()
root=out/'fixture';config=root/'config'; a=root/'initial';b=root/'second'
for p in [config,a,b,root/'sessions']:p.mkdir(parents=True)
for p,marker in [(a,'FIRST_PROJECT_ONLY'),(b,'SECOND_PROJECT_ONLY')]:
 subprocess.run(['/usr/bin/git','init','--quiet',str(p)],check=True)
 (p/'note.txt').write_text(marker+'\n')
(root/'outside.txt').write_text('OUTSIDE_PROJECT\n')
finish=threading.Event();first=threading.Event(); requests=[]
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def do_POST(self):
  body=json.loads(self.rfile.read(int(self.headers['Content-Length'])));requests.append(body)
  self.send_response(200);self.send_header('Content-Type','text/event-stream');self.end_headers()
  def emit(delta,reason=None):
   self.wfile.write(('data: '+json.dumps({'id':'busy-fixture','model':body['model'],'choices':[{'index':0,'delta':delta,'finish_reason':reason}]})+'\n\n').encode());self.wfile.flush()
  try:
   emit({'role':'assistant','content':'PROVIDER_FIRST_DELTA '});first.set()
   while not finish.wait(.1):
    self.wfile.write(b': provider gate\n\n');self.wfile.flush()
   emit({'content':'PROVIDER_FINISHED'},'stop');self.wfile.write(b'data: [DONE]\n\n');self.wfile.flush()
  except (BrokenPipeError,ConnectionResetError):pass
server=ThreadingHTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever);thread.start()
(config/'config.toml').write_text(f'backend="openai"\nmodel="gpt-4.1"\nbase_url="http://127.0.0.1:{server.server_port}/v1"\nwire_api="chat"\nrequires_openai_auth=false\nmax_retries=0\n')
(config/'auth.json').write_text('{"OPENAI_API_KEY":"busy-local-fixture"}');(config/'auth.json').chmod(0o600)
env={k:v for k,v in os.environ.items() if not k.startswith(('ZENPI_','OPENAI_')) and k.lower() not in ('http_proxy','https_proxy','all_proxy','no_proxy')};env.update(ZENPI_HOME=str(config),TERM='xterm-256color')
checks={};result={'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'checks':checks,'scope':'ZS1-123 local Diff alias, no model review claim'};t=None
checkpoint=config/'project-tabs.json'
def saved():return json.loads(checkpoint.read_text())
def row(p):return next(v for v in saved()['project_state'] if v['metadata']['cwd']==str(p.resolve()))
def msgs(p):return row(p)['messages']
def inspect(alias,path):
 t.clear_input(); before=len(msgs(b));t.command('/'+alias+' '+path)
 deadline=time.monotonic()+2
 while time.monotonic()<deadline:
  drain(t.fd,t.output,.02)
  if len(msgs(b))>before+1:break
 new=msgs(b)[before:];(out/(alias+'-'+path.replace('/','_')+'.json')).write_text(json.dumps(new,indent=2))
 return new
bin_dir=root/'bin';bin_dir.mkdir(); gate=root/'git.gate';pids=root/'git-pids.jsonl'
shim=bin_dir/'git'
shim.write_text('#!/usr/bin/env python3\nimport os,time,json\nfrom pathlib import Path\ngate=Path('+repr(str(gate))+')\nif gate.exists():\n with open('+repr(str(pids))+',"a") as f:f.write(json.dumps({"pid":os.getpid(),"cwd":os.getcwd(),"args":os.sys.argv[1:]})+"\\n")\n while gate.exists():time.sleep(.01)\nos.execv("/usr/bin/git",["/usr/bin/git"]+os.sys.argv[1:])\n');shim.chmod(0o700)
env['PATH']=str(bin_dir)+os.pathsep+env['PATH']
def pid_rows():return [json.loads(v) for v in pids.read_text().splitlines()] if pids.exists() else []
def pid_gone(pid):
 try:os.kill(pid,0);return False
 except ProcessLookupError:return True
try:
 t=Terminal(binary,root,env);t.folder(b);t.wait(lambda:any(v['metadata']['cwd']==str(b.resolve()) and v['name']==saved()['projects'][saved()['active']] for v in saved()['project_state']))
 t.command('HOLD_BUSY_PROVIDER');t.expect(b'PROVIDER_FIRST_DELTA');assert first.is_set() and not finish.is_set()
 owner=row(b)['metadata'];layout=row(b)['layout'];session_cursor=saved()['session_cursors'][row(b)['name']]['session_id']
 # Stall the actual Git executable before it emits stdout; TUI must still
 # checkpoint keyboard input and change projects, with provider gate closed.
 gate.touch();t.command('/diff note.txt');t.wait(lambda:len(pid_rows())==1)
 pid=pid_rows()[-1]['pid'];t.write('new B draft'.encode());t.wait(lambda:t.draft()=='new B draft',timeout=2)
 checks['keyboard_checkpoint_while_git_and_provider_are_stalled']=True
 t.folder(a);t.wait(lambda:row(a)['name']==saved()['projects'][saved()['active']],timeout=2)
 t.write(b'new A draft');t.wait(lambda:t.draft()=='new A draft');layout_a=row(a)['layout']
 gate.unlink();t.wait(lambda:any('+SECOND_PROJECT_ONLY' in v['text'] for v in msgs(b)))
 checks['late_result_only_in_original_B_session']=not any('SECOND_PROJECT_ONLY' in v['text'] for v in msgs(a)) and row(b)['metadata']==owner and saved()['session_cursors'][row(b)['name']]['session_id']==session_cursor
 checks['both_drafts_and_layouts_preserved']=row(a)['draft']['input']=='new A draft' and row(b)['draft']['input']=='new B draft' and row(a)['layout']==layout_a and row(b)['layout']==layout
 t.wait(lambda:pid_gone(pid));checks['completed_git_reaped']=True
 t.folder(b);t.wait(lambda:row(b)['name']==saved()['projects'][saved()['active']]);t.clear_input()
 count=sum('+SECOND_PROJECT_ONLY' in v['text'] for v in msgs(b));gate.touch();t.command('/review note.txt');t.wait(lambda:len(pid_rows())==2)
 pid=pid_rows()[-1]['pid'];start=time.monotonic();t.write(b'\x03')
 t.wait(lambda:pid_gone(pid),timeout=2);t.wait(lambda:any(v['text']=='Local diff cancelled' for v in msgs(b)),timeout=2)
 result['keyboard_cancel_seconds']=time.monotonic()-start
 checks['cancel_reaps_stalled_git_without_opening_gate']=gate.exists() and pid_gone(pid)
 checks['cancel_does_not_cancel_or_reissue_provider']=len(requests)==1 and not finish.is_set()
 checks['cancel_suppresses_late_success']=sum('+SECOND_PROJECT_ONLY' in v['text'] for v in msgs(b))==count
 gate.unlink();t.clear_input();t.command('/review note.txt');t.wait(lambda:sum('+SECOND_PROJECT_ONLY' in v['text'] for v in msgs(b))==count+1)
 checks['slot_reusable_after_cancel']=True
 # Provider completes while local Git remains gated on the last operation;
 # normal /quit must close and join inspection without a fixture release.
 finish.set();t.wait(lambda:'PROVIDER_FINISHED' in json.dumps(msgs(b)))
 t.clear_input();gate.touch();t.command('/diff note.txt');t.wait(lambda:len(pid_rows())==3)
 pid=pid_rows()[-1]['pid'];start=time.monotonic();t.close();result['quit_seconds']=time.monotonic()-start
 checks['normal_quit_reaps_git_without_opening_gate']=gate.exists() and pid_gone(pid)
 checks['exactly_one_provider_request']=len(requests)==1
 result['status']='passed' if all(checks.values()) else 'failed'
except BaseException as e:
 result.update(status='fixture_failed',error=repr(e),traceback=traceback.format_exc());print(result['traceback'])
finally:
 finish.set()
 if gate.exists():gate.unlink()
 if t:
  t.cleanup();(out/'pty.log').write_bytes(bytes(t.output));(out/'screen.txt').write_bytes(screen_text(bytes(t.output)))
 server.shutdown();server.server_close();thread.join()
 (out/'http.json').write_text(json.dumps(requests,indent=2));(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result,indent=2))
