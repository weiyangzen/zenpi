from pathlib import Path
import subprocess,json,datetime,time,hashlib,sys,os
p=Path(__file__).resolve().parent
name=sys.argv[1];argv=sys.argv[2:];assert argv
stdout=p/(name+'.stdout.log');stderr=p/(name+'.stderr.log');receipt=p/(name+'.run.json')
assert not any(x.exists() for x in (stdout,stderr,receipt))
env=os.environ.copy();env['CARGO_TARGET_DIR']=str(p/'cargo-target')
sha=lambda data:hashlib.sha256(data).hexdigest()
inventory=[{'path':x.relative_to(p/'build').as_posix(),'bytes':x.stat().st_size,'sha256':sha(x.read_bytes())} for x in sorted((p/'build').rglob('*')) if x.is_file() and '.git' not in x.relative_to(p/'build').parts]
blobs=p/'blobs';blobs.mkdir(exist_ok=True)
for row in inventory:
    dest=blobs/row['sha256']
    if not dest.exists():dest.write_bytes((p/'build'/row['path']).read_bytes())
binding=p/(name+'.inputs.json');binding.write_text(json.dumps(inventory,indent=2)+'\n')
m={'argv':argv,'cwd':str(p/'build'),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'env_overrides':{'CARGO_TARGET_DIR':env['CARGO_TARGET_DIR']},'HOME_preserved':True,'CODEX_HOME_preserved':True,'source_sha256':sha((p/'build/src/slash_actions.rs').read_bytes()),'inputs_sha256':sha(binding.read_bytes()),'status':'running'};receipt.write_text(json.dumps(m,indent=2)+'\n');start=time.monotonic()
with stdout.open('wb') as out,stderr.open('wb') as err:result=subprocess.run(argv,cwd=p/'build',env=env,stdout=out,stderr=err)
m.update(exit_code=result.returncode,elapsed_seconds=time.monotonic()-start,ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='finished')
for label,path in [('stdout',stdout),('stderr',stderr)]:m[label]={'path':path.name,'bytes':path.stat().st_size,'sha256':sha(path.read_bytes())}
receipt.write_text(json.dumps(m,indent=2)+'\n');print(json.dumps(m,indent=2));sys.exit(result.returncode)
