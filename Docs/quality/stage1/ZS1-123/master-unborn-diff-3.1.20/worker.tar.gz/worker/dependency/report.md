# ZS1-123 · 新未跟踪目录逐文件 diff · 3.1.20 独立候选

本增量修复 `/diff`、`/diff .` 和目录 `/diff` 对整个新未跟踪目录的子文件遗漏。唯一产品路径是 `src/slash_actions.rs`。生产逻辑只把现有 Git status 的 `--untracked-files=normal` 改为 `--untracked-files=all`，并增加解释注释；其余生产字节完全保持。Git 自身列举文件并应用 ignore 规则，没有自行遍历目录，也没有新增进程。

这是依赖上一候选的增量，不是主库当前文件的补丁，也不是整项 123 验收。主控说明上一候选尚未合入；集成顺序必须先将前包合到 eb8，再应用本包。无 HEAD 混合 staged-only/unstaged 的聚合遗漏按授权留待下一增量。

## 精确身份与依赖

| 对象 | 身份 |
|---|---|
| 前置包 | `../target123-quoted-untracked-3.1.20-ready` |
| 前置 manifest SHA256 | `f95b3ef3fc4070205216ec1262d160650486352a862312cdf7a1b582ce17ac13` |
| 本包 before | `eb8cd91d6f84ea977454fe69a2304a2ff56ef714b8356e90e51526f5ce1dfcc3`，58,927 bytes / 1,539 lines |
| 本包 after | `7006078ff6a612b1d7a3cde59965e629919444ff0fb51034f5e86c7dca239831`，61,231 bytes / 1,595 lines |
| product.patch | `11a98c43660ff9745ec1562404899440814bed70deec27b129648275748efa79`，3,315 bytes |
| 产品变更范围 | 仅 `src/slash_actions.rs` |
| requirement digest | `8d525b351d066ce9b0487a485337647d47233275782e4f4d154423a623fe1645`，仅记录，未写 authority |

主控允许精确复用上一轮对 811b 完整 owner 的连续阅读，以及 811b→eb8 完整补丁的理解。本轮再次读完整依赖补丁，并重读当前 diff/status/decoder/process/cap 段及相关测试，再逐处检查最终三个 diff hunk。`dependency/` 保存原始阅读链材料，`read-coverage.json` 明示复用范围。离线 verifier 对生产段做全字节等价检查，不只比较若干挑选片段。

## 真实反例 → 最小修复

新的私有真实 Git fixture 在根目录提交 `seed`，随后创建完全没有 tracked seed 的多层新目录和 11 个不同内容的普通文件。文件身份覆盖空格、引号、中文、字面 Unix 反斜杠、`[ab]`、`:(glob)*`。反斜杠文件/真实子目录文件、bracket 文件/普通相邻文件、反斜杠目录/真实目录三组都实际断言 inode 不同。

在精确 eb8 上，`negative-current` 首次执行 exit 101：两种 `core.quotePath` × 九种聚合 scope × 十一个文件，共 198 项正负身份判断，其中 72 项本应出现的内容全部遗漏。22 次显式文件 review 成功，并对其余十个内容逐一断言不出现。18 次 status 与期望逐文件输出不同。原始日志完整保留。

只修改一个 Git 参数后，在相同私有测试文件的原始字节、相同完整依赖输入上，`fixed-counterexample` exit 0，198 项身份判断缺失归零、22 次显式 review 通过、18 次 status mismatch 归零。该中间 owner SHA 为 `0fa95fa3516c5422590f133399b10be07e5e1f8813a35cdf3e34b61c0434f837`，输入 blob 可精确恢复。之后添加 owner 回归测试、解释注释，并适配已有测试的 status oracle，格式化后形成最终 7006078。

## 行为、展示与边界

新目录现在按文件列入可读 porcelain-v1 status，而非一条 `?? directory/`。保留 Git 的引号编码、换行格式和原有文本脱敏。展示粒度有意变化：用户能查看新目录内普通文件的改动；原来的 normal 折叠不再作为最终策略。status 仍最多 32 KiB，diff 仍最多 64 KiB，并保留原截断标记。

路径选择仍从原始有界字节严格解码，不能从 lossy 展示文本重建路径。只接受完整换行结束的 `??` 记录；截断末条记录不能选择同名前缀文件。rename/copy 仍仅展示，不作为 untracked 候选。严格 UTF-8 及 Git C 引号/八进制解码、原生 Path 参数、literal pathspec、Command 局部清理 GIT_GLOB_PATHSPECS/GIT_ICASE_PATHSPECS 都保持。既有 owner 的 256 字节解码与无效 UTF-8/不完整记录拒绝测试再次执行通过。

原有 resolve_relative 的长度、控制字符、父目录、绝对路径、symlink component、canonical workspace 与 scope 策略不变。仍在完成验证后最多受理 32 个文件；被拒绝的 control/symlink 不占名额。Git 使用相同的 pathspec scope，解析器仍做 scope 检查。ignore 文件和 ignore 目录由 Git 排除。

所有 stdout 读取上限、stderr 丢弃、截断后 kill/wait、diff 合并、binary 显式分支及无 HEAD fallback 的生产代码均字节不变。此变更没有为 Git 的目录扫描引入新的时间预算：Git all 模式需扫描新目录以列举其子文件，原有读取/受理上限约束返回的数据和后续 diff 数量，不等于对底层文件系统扫描耗时提供硬上限。到达 32 文件上限之后仍沿用原行为，只 review 已受理前缀；更后的文件可显式选择。较多展开记录可能更早触及 status 上限，截断标记保留。

## 最终实际验证

所有最终运行都绑定 after `7006078…`，原生 `stable-aarch64-apple-darwin`，Cargo 使用 `--offline --locked --jobs 2` 和本轮独立 `CARGO_TARGET_DIR`，HOME/CODEX_HOME 未改变。Rust 1.94.0 / Git 2.50.1 (Apple Git-155) 版本原始回执在 logs。

| 运行 | 结果 |
|---|---|
| final-owner | `slash_actions::` owner 18/18，其中 1 项新增真实 Git 新目录回归 |
| final-integration / slash_actions | 既有集成 11/11 |
| final-integration / quoted_untracked_review | 前包私有审查适配后 5/5 |
| final-integration / untracked_directories_review | 本轮私有审查 5/5 |
| final-clippy | lib + 三个上述测试目标，`-D warnings`，exit 0 |
| final-fmt | `cargo fmt --all -- --check`，exit 0 |

共 **39 个顶层测试**。另有 **6 次环境变量子执行**：既有 tracked owner 两次、quoted 私有审查两次、新目录私有审查两次，分别在 Command 局部设置冲突 Git 环境变量；不重复计入 39。39 中有一项包含延期无 HEAD 缺口的观察断言，其通过不表示该缺口已修复。

新审查实际覆盖：

- 11 个原生文件 × 九个聚合 scope × 两种 quotePath 的 198 项身份判断，含应出现与不得跨 scope 出现的内容；22 次显式 review；逐文件 status 与真实 Git 输出一致。
- 多层新目录的 ignore 文件、ignore 目录、控制字符目录及文件、指向外部的文件/目录 symlink、指向内部文件的 symlink；有效内容正例以及拒绝显式选择负例。
- 至少 40 个 control 文件先排序、symlink 在前，然后 40 个合法 quoted 文件；三种 aggregate scope 都正好受理 32 个合法文件，31 存在、32–39 不出现，拒绝文件不能耗尽 32 个名额。
- 180 个长名字文件在新目录中：真实 all 输出超过 32 KiB，normal 对照只有一条目录记录。三种 scope 的 status 都带截断标记且不超 32 KiB，diff 中仍精确 32 个合法文件且不超 64 KiB。
- 新多层目录下的 quoted 中文大文件，内容为 128 KiB；全仓、`.`、目录、显式文件四种选择都 changed=true、truncated=true，diff 不超 64 KiB 且带截断标记。
- 上一包的 bracket/magic/反斜杠、rename、无效 UTF-8、路径拒绝、字节解析和上限测试再次执行。

前包私有审查中“新目录遗漏仍存在”的旧观察断言已正向改为内容必须出现，并把名称/打印说明改成新目录回归通过、仅无 HEAD 缺口保留；status oracle 从 normal 改为 all。`review-adaptation.patch` 显示全部适配。没有删除无 HEAD 的 staged-only 不出现断言，也没有改产品 resolver 或放宽其他断言。

这个 Mac 文件系统对真实非 UTF-8 文件名创建返回 EILSEQ，所以该实际 inode 分支再次明确报告 unavailable。严格原始字节解码拒绝及真实 U+FFFD 邻居仍实际测试；不声称创建了 OS 不允许的文件。既有 vendor crossterm unused_parens 警告保留在 stderr，本轮未改 vendor。

9 份运行回执完整保留：negative-current（唯一 exit 101，真实产品反例）、fixed-counterexample、format、final-owner、final-integration、final-clippy、final-fmt、rust-version、git-version。其余 exit 0。本轮没有丢弃或覆盖中间失败。未执行 PTY、HTTP、网络、FIFO；没有运行 CLI 交互验收，没有整项 123 验收结论。

## 完整私有输入与工作区边界

使用前包 after 回放准备模式恢复 225 个精确源文件/依赖/支持输入及私有 Git root。本轮增加 `tests/untracked_directories_review.rs`，修改唯一产品 owner，以及前包私有 quoted 审查的明确适配，共 226 个最终输入；225 个继承输入中 223 个字节保持。根 README 与旧集成需要的 Git root 从前包完整构建继承，没有桩函数或删编 owner。新 negative 时 owner 恰为 eb8，全部 226 输入可恢复。

`build-inputs.tar.gz` 包含最终 226 文件及原 mode。`blobs/` 保存各次运行输入的内容寻址字节，包括初始失败、仅一参数修复、格式化前和最终版本；每次 `logs/*.inputs.json` 全量列出路径/大小/hash，并由对应回执绑定。每份 stdout/stderr 的大小/hash、运行起止时间、命令和环境覆盖值也由回执绑定。`binary-identities.json` 记录最终编译产物身份；编译出的 CLI 未作为执行证据。

本轮只写新私有 `.ops` 目录和新 ready。before/after boundary 完全相等：worker HEAD 仍 `4dbd330d0a8cf58576109713f774969babd499ed`、94 条非 .ops 状态记录不变；主库 owner 哈希仍为捕获值，前 quoted/env/073/022 ready manifest 均不变。没有提交、暂存、主库写入、authority 更新、任务创建或 subagent。

## 离线审查与回放

`python3 verify.py` 只校验 manifest、所有 payload、9 次运行的完整输入 blob/原始日志、最终构建 archive、精确产品补丁正向和反向、生产段等价、边界记录及计数，不执行 Cargo 或产品。

`python3 replay.py --destination NEW_DIRECTORY --mode before` 恢复初始真实反例的 226 个精确输入；`--mode after` 恢复最终 226 个输入。默认只准备并初始化独立 Git root。加 `--run` 才使用独立 target 执行授权模式的原生离线 Cargo：before 预期唯一反例 exit 101，after 执行 owner/三组集成/Clippy/fmt，预期 exit 0。请使用全新 destination，避免覆盖。

准备模式及离线 verifier 的实际执行结果见 `offline-checks/`；最终封存 manifest 的独立验证回执保存在相邻私有 work 目录，不回写已封存包。准备模式没有再次执行 Cargo。主控仍需独立集成与验收。
