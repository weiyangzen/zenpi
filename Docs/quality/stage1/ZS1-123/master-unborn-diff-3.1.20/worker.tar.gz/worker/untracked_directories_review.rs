#![cfg(unix)]
use std::os::unix::fs::{MetadataExt, symlink};
use std::{fs, path::Path, process::Command};
use zenpi::slash_actions::{MAX_SLASH_DIFF_BYTES, MAX_STATUS_BYTES, diff_value_at};

fn git(root: &Path, args: &[&str]) -> String {
    let output = Command::new("git")
        .current_dir(root)
        .env_remove("GIT_GLOB_PATHSPECS")
        .env_remove("GIT_ICASE_PATHSPECS")
        .arg("--literal-pathspecs")
        .args(args)
        .output()
        .unwrap();
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
    String::from_utf8(output.stdout).unwrap()
}
fn repository() -> tempfile::TempDir {
    let d = tempfile::tempdir().unwrap();
    let root = d.path();
    git(root, &["init", "-q"]);
    git(root, &["config", "user.name", "directory fixture"]);
    git(root, &["config", "user.email", "directory@example.test"]);
    fs::write(root.join("seed"), "TRACKED_SEED\n").unwrap();
    git(root, &["add", "seed"]);
    git(root, &["commit", "-qm", "seed"]);
    d
}
fn put(root: &Path, name: &str, text: &str) {
    let path = root.join(name);
    fs::create_dir_all(path.parent().unwrap()).unwrap();
    fs::write(path, text).unwrap();
}

#[test]
fn completely_new_directories_are_reviewed_in_every_literal_scope() {
    let d = repository();
    let root = d.path();
    let names = [
        "scope[ab]/deep/space dir/space file.txt",
        "scope[ab]/deep/引号\" 目录/中文\" 文件.txt",
        r"scope[ab]/note\file.txt",
        "scope[ab]/note/file.txt",
        "scope[ab]/square[ab].txt",
        "scope[ab]/squarea.txt",
        "scope[ab]/:(glob)*.txt",
        "scopea/neighbor.txt",
        ":(glob)*/deep/file.txt",
        r"native\directory/deep/file.txt",
        "native/directory/deep/file.txt",
    ];
    for (i, name) in names.iter().enumerate() {
        put(root, name, &format!("DIRECTORY_FILE_{i:02}\n"));
    }
    for (left, right) in [(2, 3), (4, 5), (9, 10)] {
        assert_ne!(
            fs::metadata(root.join(names[left])).unwrap().ino(),
            fs::metadata(root.join(names[right])).unwrap().ino()
        );
    }
    let mut missing = Vec::new();
    let mut display_mismatches = 0;
    let mut checks = 0;
    for quote in ["true", "false"] {
        git(root, &["config", "core.quotePath", quote]);
        for (i, name) in names.iter().enumerate() {
            let value = diff_value_at(root, Some(name)).unwrap();
            let diff = value["diff"].as_str().unwrap();
            for other in 0..names.len() {
                assert_eq!(
                    diff.contains(&format!("+DIRECTORY_FILE_{other:02}")),
                    i == other,
                    "explicit {name}: {value}"
                );
            }
        }
        for scope in [
            None,
            Some("."),
            Some("scope[ab]"),
            Some("scope[ab]/deep"),
            Some("scope[ab]/deep/引号\" 目录"),
            Some("scopea"),
            Some(":(glob)*"),
            Some(r"native\directory"),
            Some("native/directory"),
        ] {
            let value = diff_value_at(root, scope).unwrap();
            let diff = value["diff"].as_str().unwrap();
            for (i, name) in names.iter().enumerate() {
                let selected = scope.is_none_or(|s| s == "." || Path::new(name).starts_with(s));
                let present = diff.contains(&format!("+DIRECTORY_FILE_{i:02}"));
                checks += 1;
                println!(
                    "quotePath={quote} scope={scope:?} name={name:?} selected={selected} present={present}"
                );
                if selected && !present {
                    missing.push(format!("{quote}/{scope:?}/{name}"));
                }
                if !selected {
                    assert!(!present, "cross-scope file: {value}");
                }
            }
            let expected = git(
                root,
                &[
                    "status",
                    "--porcelain=v1",
                    "--untracked-files=all",
                    "--",
                    scope.unwrap_or("."),
                ],
            );
            if value["status"] != expected {
                display_mismatches += 1;
            }
        }
    }
    println!(
        "aggregate_identity_checks={checks} explicit_reviews=22 missing={} status_mismatches={display_mismatches}",
        missing.len()
    );
    assert!(missing.is_empty(), "new-directory omissions: {missing:?}");
    assert_eq!(
        display_mismatches, 0,
        "status must remain readable, now with per-file granularity"
    );
}

#[test]
fn nested_discovery_respects_ignore_symlink_control_and_scope() {
    let d = repository();
    let root = d.path();
    let outside = tempfile::tempdir().unwrap();
    fs::write(root.join(".gitignore"), "*.ignored\nignored-dir/\n").unwrap();
    git(root, &["add", ".gitignore"]);
    git(root, &["commit", "-qm", "ignore fixture"]);
    put(root, "scope[ab]/new/deep/allowed file", "ALLOWED_NESTED\n");
    put(root, "scopea/new/deep/other", "OUTSIDE_SCOPE_MARKER\n");
    put(
        root,
        "scope[ab]/new/deep/a.ignored",
        "IGNORED_FILE_MARKER\n",
    );
    put(
        root,
        "scope[ab]/ignored-dir/deep/file",
        "IGNORED_DIRECTORY_MARKER\n",
    );
    put(
        root,
        "scope[ab]/new/line\ncontrol/file",
        "CONTROL_DIRECTORY_MARKER\n",
    );
    put(
        root,
        "scope[ab]/new/deep/line\tfile",
        "CONTROL_FILE_MARKER\n",
    );
    put(outside.path(), "secret", "SYMLINK_MARKER\n");
    symlink(outside.path(), root.join("scope[ab]/new/linked-dir")).unwrap();
    symlink(
        outside.path().join("secret"),
        root.join("scope[ab]/new/deep/linked-file"),
    )
    .unwrap();
    symlink(
        root.join("scope[ab]/new/deep/allowed file"),
        root.join("scope[ab]/new/inside-link"),
    )
    .unwrap();
    for scope in [None, Some("."), Some("scope[ab]"), Some("scope[ab]/new")] {
        let value = diff_value_at(root, scope).unwrap();
        let diff = value["diff"].as_str().unwrap();
        assert!(diff.contains("+ALLOWED_NESTED"), "{value}");
        assert_eq!(diff.matches("+ALLOWED_NESTED").count(), 1);
        for denied in [
            "IGNORED_FILE_MARKER",
            "IGNORED_DIRECTORY_MARKER",
            "CONTROL_DIRECTORY_MARKER",
            "CONTROL_FILE_MARKER",
            "SYMLINK_MARKER",
        ] {
            assert!(!diff.contains(denied), "{value}");
        }
        if scope.is_some_and(|s| s != ".") {
            assert!(!diff.contains("OUTSIDE_SCOPE_MARKER"));
        }
        let status = value["status"].as_str().unwrap();
        assert!(!status.contains("a.ignored") && !status.contains("ignored-dir"));
    }
    for denied in [
        "scope[ab]/new/linked-dir/secret",
        "scope[ab]/new/deep/linked-file",
        "scope[ab]/new/inside-link",
        "scope[ab]/new/line\ncontrol/file",
        "scope[ab]/new/deep/line\tfile",
        "../secret",
    ] {
        assert!(diff_value_at(root, Some(denied)).is_err(), "{denied:?}");
    }
}

#[test]
fn nested_discovery_accepts_only_32_valid_files() {
    let d = repository();
    let root = d.path();
    let outside = tempfile::tempdir().unwrap();
    put(outside.path(), "secret", "FORBIDDEN_LINK\n");
    // Rejected entries sort before valid files, so the cap must apply after validation.
    for i in 0..40 {
        put(
            root,
            &format!("new directory/a{i:02}\ncontrol"),
            "FORBIDDEN_CONTROL\n",
        );
    }
    symlink(outside.path(), root.join("new directory/b-linked-dir")).unwrap();
    for i in 0..40 {
        put(
            root,
            &format!("new directory/z deep/file {i:02}\".txt"),
            &format!("VALID_NESTED_{i:02}\n"),
        );
    }
    for scope in [None, Some("."), Some("new directory")] {
        let value = diff_value_at(root, scope).unwrap();
        let diff = value["diff"].as_str().unwrap();
        assert_eq!(diff.matches("diff --git ").count(), 32, "{value}");
        for i in 0..40 {
            assert_eq!(diff.contains(&format!("+VALID_NESTED_{i:02}")), i < 32);
        }
        assert!(!diff.contains("FORBIDDEN"));
        assert!(diff.len() <= MAX_SLASH_DIFF_BYTES);
        let status = value["status"].as_str().unwrap();
        assert!(status.contains("39") && status.len() <= MAX_STATUS_BYTES);
    }
}

#[test]
fn expanded_status_and_nested_diff_still_have_hard_byte_caps() {
    let d = repository();
    let root = d.path();
    for i in 0..180 {
        put(
            root,
            &format!("new directory/deep/file {i:03} {}", "q".repeat(220)),
            &format!("STATUS_CAP_FILE_{i:03}\n"),
        );
    }
    let raw = git(root, &["status", "--porcelain=v1", "--untracked-files=all"]);
    assert!(raw.len() > MAX_STATUS_BYTES);
    let normal = git(
        root,
        &["status", "--porcelain=v1", "--untracked-files=normal"],
    );
    assert_eq!(normal.lines().count(), 1);
    for scope in [None, Some("."), Some("new directory")] {
        let value = diff_value_at(root, scope).unwrap();
        let status = value["status"].as_str().unwrap();
        let diff = value["diff"].as_str().unwrap();
        assert!(status.len() <= MAX_STATUS_BYTES && status.ends_with("[diff truncated]"));
        assert_eq!(diff.matches("diff --git ").count(), 32);
        assert!(diff.contains("+STATUS_CAP_FILE_031") && !diff.contains("+STATUS_CAP_FILE_032"));
        assert!(diff.len() <= MAX_SLASH_DIFF_BYTES);
    }
    let large = repository();
    put(
        large.path(),
        "new large/deep/quoted\" 中文.txt",
        &"x".repeat(MAX_SLASH_DIFF_BYTES * 2),
    );
    for scope in [
        None,
        Some("."),
        Some("new large"),
        Some("new large/deep/quoted\" 中文.txt"),
    ] {
        let value = diff_value_at(large.path(), scope).unwrap();
        assert_eq!(value["changed"], true);
        assert_eq!(value["truncated"], true);
        let diff = value["diff"].as_str().unwrap();
        assert!(diff.len() <= MAX_SLASH_DIFF_BYTES && diff.ends_with("[diff truncated]"));
    }
}

#[test]
fn inherited_git_modes_do_not_change_nested_literal_identity() {
    for variable in ["GIT_GLOB_PATHSPECS", "GIT_ICASE_PATHSPECS"] {
        let output = Command::new(std::env::current_exe().unwrap())
            .env(variable, "1")
            .args([
                "--exact",
                "completely_new_directories_are_reviewed_in_every_literal_scope",
                "--nocapture",
            ])
            .output()
            .unwrap();
        println!(
            "{variable} child={}\n{}\n{}",
            output.status,
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
        assert!(output.status.success());
        assert!(String::from_utf8_lossy(&output.stdout).contains("1 passed"));
    }
}
