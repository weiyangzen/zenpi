# ZS1-123 · 无 HEAD 工作树视图及空文件审查 · 3.1.20

修复无 HEAD 仓库混合 staged-only/unstaged 时遗漏 staged-only 内容的问题。采用与现有有 HEAD 分支一致的单一视图：**基准树 → 当前工作树**；尚无提交时，基准树为空树。相同文件不会拼接两段不同来源的补丁，中间 index 内容不作为另一份正文展示。status 仍显示 index/worktree 两列状态。

空未跟踪普通文件的疑似 exit 0 问题未复现：真实 Git 及当前 owner 在 SHA-1/SHA-256、有/无 HEAD 情况均成功展示其创建元数据，Git `/dev/null` no-index 返回 1。因此该分支没有产品改动，也没有放宽 exit status 接受规则。

本包仅产品路径 `src/slash_actions.rs`，是基于上一封存 after 700 的独立增量；不是整项 123 验收。本轮没有主库、authority 或旧 ready 写入。

## 精确依赖

| 对象 | SHA256 / 大小 |
|---|---|
| 前置 ready | `../target123-untracked-directories-3.1.20-ready` |
| 前置 manifest | `ff518bb7cf8213e980f91cfd82d9e2be479bbc473c03c1726774e487e3cf51ed` |
| before.rs | `7006078ff6a612b1d7a3cde59965e629919444ff0fb51034f5e86c7dca239831`，61,231 bytes / 1,595 lines |
| after.rs | `e8635a418ccd613ef0587695ee9318d05e679be202494c0f04eb04651c12184e`，63,692 bytes / 1,644 lines |
| product.patch | `85269e12b6f00aa7623ea03ff4490f166f71dbe21e73237ef68e6f12b56e35be`，5,963 bytes |
| requirement digest | `8d525b351d066ce9b0487a485337647d47233275782e4f4d154423a623fe1645`，只记录未更新 |

请先确认 owner 精确为 before 700，再应用补丁。工作私有路径是 `.ops/stage1-worker/target123-unborn-empty-3.1.20`。主控消息发送时描述主库尚为 eb8；本轮实际只读捕获时主库已为 700，结束仍为同一 700，见 boundary 记录。本轮构建来自封存包回放，与主库状态变化无关。

## 决策与产品行为

旧 fallback 在 `diff HEAD` 返回未截断的 128 后先运行 index→worktree diff；只有它为空才取 cached diff。只要任意 unstaged patch 非空，其他 staged-only 文件就被遗漏，同文件也展示 index 中间态→worktree，而不是既有有 HEAD 分支的基准→worktree。

新 fallback 用同一个有界 Git process helper 执行 `git hash-object -t tree -- /dev/null`，不带 `-w`，不写对象，不读取继承 stdin。由当前 Git 计算空树 ID，适配 SHA-1 的 40 位和 SHA-256 的 64 位；返回必须 status 0、未截断、长度 40/64 且全为 ASCII 十六进制，否则拒绝。然后执行 `git diff EMPTY_TREE`，保持既有 no-ext-diff、no-textconv、no-color、unified=3、原生路径和 literal pathspec。

原 `HEAD` 128/未截断触发条件保持；有 HEAD 的正常分支不变。只改了此 fallback 的生产逻辑及 public API 语义说明。普通单次混合场景比原先的 HEAD+unstaged 多一次短 hash 查询；与原先 HEAD+unstaged+cached 的路径相比进程数相同。所有新增查询仍经过原 bounded stdout、stderr 丢弃、kill/wait helper；没有引入遍历、文件全量读取或对象写入。

| 情况 | 统一视图的预期 |
|---|---|
| 仅 staged 新内容，工作树未改 | 从空树增加当前文件内容 |
| 仅 unstaged（intent-to-add） | 从空树增加当前工作树内容 |
| 不同文件 mixed | staged-only 与另一个文件的最终 worktree 内容都出现 |
| 同文件 stage 后再编辑 | 只出现最终内容；不拼接 index 中间态补丁 |
| stage 后删除 | 相对空基准没有净变化；diff 空，status 的 AD 等状态仍保留 |
| stage 后 git mv，再编辑 | 最终新路径和最终内容出现 |
| stage 后工作树 rename，未再次 add | 原位置相对空基准无净变化；新位置按既有 untracked synthetic diff 展示 |
| 空 untracked 文件 | metadata-only 新文件 patch，changed=true；聚合正常继续 |

对有 HEAD 分支，原本 `git diff HEAD` 也不会把 index 中间内容作为独立正文。本选择与之对齐，而不是以省略 staged 检查掩盖遗漏。现有 status 文本保留可读 porcelain 的两列 index/worktree 信息，先前新目录 all 模式不变。

## 原样负例与相同输入复验

`negative-current` 在完整 before 700 上实际运行新私有测试，exit 101：4 项中 2 通过、2 失败。

- 364 次无 HEAD 与真实空初始提交仓库的完整 diff/changed 对照，有 208 次不一致。测试对七类编辑状态、两种 Git 对象格式、两种 quotePath、全仓/`.`/两个目录及各显式文件 scope 做对照；status 对照一致。错误完整正文保存在 411,617 bytes 原始 stdout，未裁剪归档。
- 无 HEAD mixed 大文件场景在 `+STAGED_POSITIVE` 断言失败，证明截断相关场景同样在输出前漏掉 staged-only 文件。
- 空 untracked 普通文件测试通过，普通 Git 错误拒绝测试通过。

最小 fallback 替换后，`fixed-counterexample` 用完全相同的私有测试文件及其余所有编译输入重跑：4/4，364 次对照不一致归零。两次运行唯一不同输入是 `src/slash_actions.rs`，离线 verifier 对完整输入清单断言这一点。中间修复 owner hash 为 `f61b44cd091a777c6be8f626d313d851c3d3a0966b9f6715999484f346f469f3`。

随后添加同 owner 回归及 API 注释，更新既有私有“遗漏仍存在”的观察为必须出现，并加强新 fixture：unstaged-only 场景的 scope 外正对照也使用 intent-to-add，保证该整个仓库没有实际 staged 内容；新增两次环境子执行。没有删除 staged-only 检查。格式化后形成最终 e863。

## 实际验证范围

全部最终运行绑定 after e863，原生 Rust 1.94.0 `stable-aarch64-apple-darwin`，Git 2.50.1 (Apple Git-155)。Cargo 均 `--offline --locked --jobs 2`，新独立 target；HOME/CODEX_HOME 未改。

| 最终运行 | 实际结果 |
|---|---|
| final-owner | `slash_actions::` 19/19，包括新增单基准 mixed/delete/rename/empty owner 回归 |
| final-integration / slash_actions | 既有集成 11/11 |
| final-integration / quoted_untracked_review | 5/5，旧无 HEAD 缺口观察现为内容必须出现 |
| final-integration / untracked_directories_review | 5/5，新目录、scope、ignore、安全与上限回归 |
| final-integration / unborn_diff_review | 5/5，新无 HEAD/空文件/错误/上限/env 审查 |
| final-clippy | lib + 四个测试目标，`-D warnings`，exit 0 |
| final-fmt | `cargo fmt --all -- --check`，exit 0 |

共 **45 个顶层测试**，另有 **8 次环境变量子执行**不重复计数。此包不再包含“保留无 HEAD 遗漏即通过”的观察断言。既有 vendor crossterm unused_parens 警告仍保留在 stderr，未修改 vendor。

新审查的 364 次对照覆盖七类状态：staged-only、intent-to-add unstaged-only、两个不同文件 mixed、同文件 stage 后再编辑、stage 后删除、stage 后 Git rename、stage 后工作树 rename。每类创建空白、引号、中文、Unix 字面反斜杠、真实子目录、bracket、magic 文件路径，另有相邻 scope 正对照。实际检查反斜杠文件和子目录文件的 inode 不同。两种 quotePath × SHA-1/SHA-256 都按全仓、`.`、目录、显式 scope 对照已有有 HEAD owner 的完整 patch 与 changed 值，而非只查某一边非空。

无 HEAD mixed 大文件正例确保 staged-only 和最终 worktree 都出现，index 中间内容不出现，64 KiB 截断标记与 truncated=true 保留。无 HEAD 新目录 180 长名文件触发 32 KiB status 截断，diff 仍精确受理 32 个文件。前包完整测试重新验证合法文件上限在 control/symlink 拒绝后计数、ignore、不跨 scope、quoted/非 UTF-8 解码拒绝、原生路径及环境清理。

新增环境子执行在 Command 局部分别设置 GIT_GLOB_PATHSPECS/GIT_ICASE_PATHSPECS，再跑真实有/无 HEAD 空文件审查，验证新的空树发现进程也走既有清理路径。没有全局 env 修改。

## 空文件核实结论与错误边界

`git-semantics.json` 保存有限原生 Git 探针，`git-empty-tree-command.json` 保存正式 hash 参数在两种对象格式下的实际返回。新私有空文件测试在 SHA-1/SHA-256 × 有/无 HEAD 的四类仓库中，每类创建两个 quoted/literal-backslash 空文件和一个非空正对照。原生 no-index 共八次返回 1，含 new file mode 和空 blob index；owner 在全仓、`.`、目录、两种显式空文件 scope 均成功，聚合精确三段；另外四类仓库各 40 个空文件，目录 review 精确 32 段元数据。

因此没有依据把原聚合 `section_status == 1` 放宽到 0；原普通错误拒绝与 no-index 状态处理生产字节保持。真实非仓库和损坏 index 的 owner 请求均返回错误，没有成功空 review。原始探针亦保存缺失 no-index operand 的 Git stderr/exit 1；本轮未引入 post-validation 文件消失竞态测试，不把上述有限错误案例宣称为所有 Git 错误类别的完整验证。

本机文件系统对非 UTF-8 inode 创建仍返回 EILSEQ，继承测试明确报告该 native-file 分支 unavailable；原始字节解码拒绝和有效 U+FFFD 邻居实际通过。没有声称创建 OS 拒绝的路径。

## 保持的边界与完整理解

除 public API 注释和旧 fallback 内部外，所有生产字节都与 before 相等。verifier 对生产段屏蔽仅这两个已完整审查范围，比较其余全部字节，因此涵盖：新目录 all、quoted/UTF-8 拒绝、原生 literal 路径、env_remove、resolve_relative 的 workspace/symlink/control/长度策略、ignore/scope、32 untracked 受理、32 KiB status、64 KiB diff、status 展示/脱敏、binary 分支、synthetic no-index 状态规则、stdout/stderr/read/kill/wait、attachments。

全 owner 理解按主控明确授权复用原完整 owner + 完整补丁链：`dependency/` 和 `dependency/prior-chain/` 保存 811b 连续阅读及后续 eb8、700 的完整补丁。当前 700 diff/status/parser/process/caps 与原 unborn 测试再次阅读，最终四个 hunk 全部逐处审查；`read-coverage.json` 给出范围。没有以测试替代 owner 理解。

原字节预算限制输出内存与后续受理数量，不是 Git 扫描底层文件系统耗时的硬预算；新 hash 查询只读 `/dev/null` 并复用原进程上限。没有 PTY、HTTP、网络、FIFO、CLI 交互执行，没有桩函数或缩减编译 owner。

## 输入、运行与边界证据

从前包精确恢复 226 个构建输入，新增 `tests/unborn_diff_review.rs` 后为 **227**。继承输入中仅产品 owner 和旧 quoted 私有审查的三处正向预期/名称/说明适配发生变化，其余 **224** 字节不变。`review-adaptation.patch` 展示该适配；没有修改既有 tests/slash_actions.rs 或 untracked_directories_review.rs。

`build-inputs.tar.gz` 保存最终 227 输入与 mode。`blobs/` + 每次 `logs/*.inputs.json` 可恢复原失败、首个修复、格式化前、最终的精确全部输入。9 份不可覆盖运行回执：negative-current、fixed-counterexample、format、final-owner、final-integration、final-clippy、final-fmt、rust-version、git-version；唯一非零为预期的原始反例 exit 101。每份包含命令、时间、source hash、完整 inputs hash、stdout/stderr 大小/hash。两份 Git 探针另存原始输出。编译产物身份保存于 binary-identities，编译出的 CLI 没有作为执行验收。

本轮只写新的私有 `.ops` 与此新 ready。boundary-before/after 完全相等：worker HEAD 仍 4dbd330d0a8cf58576109713f774969babd499ed，94 条非 .ops 状态不变；主库 owner 捕获为 700，结束仍为 700；先前 directories/quoted/env/073/022 ready manifest 均不变。没有 stage/commit、authority 更新、主库修改、任务创建或 subagent。

## 离线验收与回放

`python3 verify.py` 实际只做 manifest/payload、9 运行回执及所有输入/日志、最终 archive、正反向精确补丁、生产边界和测试计数验证，不执行 Cargo 或产品。

`python3 replay.py --destination NEW --mode before|after` 默认只恢复精确 227 输入并建立独立 Git root。before 使用原四测试反例版本；after 使用最终版本。加 `--run` 才执行原生离线 Cargo，before 预期 2 pass/2 fail、exit 101；after 执行 owner/四组集成/Clippy/fmt，预期 exit 0。两种准备模式的实际回执见 offline-checks；准备阶段没有重跑 Cargo。

最终封存 manifest 的独立验证回执位于相邻私有 work 的 verification-sealed.receipt.json，不回写已封存包。交付后停止，留主控独立集成。
