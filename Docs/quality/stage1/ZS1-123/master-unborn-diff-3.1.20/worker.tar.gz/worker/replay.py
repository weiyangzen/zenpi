#!/usr/bin/env python3
"""Prepare the exact negative or final snapshot. --run explicitly executes offline Cargo."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import argparse,datetime,json,os,subprocess,tarfile,time
from verify import ROOT, BEFORE, AFTER, sha, read_json, safe, verify
parser=argparse.ArgumentParser(); parser.add_argument('--destination',type=Path,required=True);parser.add_argument('--mode',choices=['before','after'],default='after');parser.add_argument('--run',action='store_true');args=parser.parse_args()
verify()
destination=args.destination.resolve();assert not destination.exists(),'destination must be new'
build=destination/'build';build.mkdir(parents=True)
with tarfile.open(ROOT/'build-inputs.tar.gz','r:gz') as archive: modes={m.name:m.mode for m in archive.getmembers()}
stem='negative-current' if args.mode=='before' else 'final-owner'; rows=read_json(ROOT/'logs'/(stem+'.inputs.json'))
for row in rows:
    path=build/safe(row['path']);path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes((ROOT/'blobs'/row['sha256']).read_bytes());path.chmod(modes[row['path']])
result=subprocess.run(['git','init','--quiet','-b','codex/unborn-diff-replay'],cwd=build,capture_output=True);assert result.returncode==0,result.stderr
expected=BEFORE if args.mode=='before' else AFTER
assert sha((build/'src/slash_actions.rs').read_bytes())==expected
preparation={'mode':args.mode,'prepared_inputs':len(rows),'source_sha256':expected,'runtime_run_requested':args.run,'HOME_preserved':True,'CODEX_HOME_preserved':True,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(destination/'preparation.json').write_text(json.dumps(preparation,indent=2)+'\n')
if args.run:
    env=os.environ.copy();env['CARGO_TARGET_DIR']=str(destination/'cargo-target')
    cargo=['cargo','+stable-aarch64-apple-darwin']
    commands=[(cargo+['test','--offline','--locked','--jobs','2','--test','unborn_diff_review','--','--nocapture'],101)] if args.mode=='before' else [
        (cargo+['test','--offline','--locked','--jobs','2','--lib','slash_actions::','--','--nocapture'],0),
        (cargo+['test','--offline','--locked','--jobs','2','--test','slash_actions','--test','quoted_untracked_review','--test','untracked_directories_review','--test','unborn_diff_review','--','--nocapture'],0),
        (cargo+['clippy','--offline','--locked','--jobs','2','--lib','--test','slash_actions','--test','quoted_untracked_review','--test','untracked_directories_review','--test','unborn_diff_review','--','-D','warnings'],0),
        (cargo+['fmt','--all','--','--check'],0)]
    for i,(argv,exit_code) in enumerate(commands):
        start=datetime.datetime.now(datetime.timezone.utc).isoformat();clock=time.monotonic();out=destination/f'{i}.stdout.log';err=destination/f'{i}.stderr.log'
        with out.open('wb') as stdout,err.open('wb') as stderr: result=subprocess.run(argv,cwd=build,env=env,stdout=stdout,stderr=stderr)
        receipt={'argv':argv,'cwd':str(build),'source_sha256':expected,'started_at':start,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-clock,'exit_code':result.returncode,'expected_exit_code':exit_code,'env_overrides':{'CARGO_TARGET_DIR':env['CARGO_TARGET_DIR']}}
        for kind,path in [('stdout',out),('stderr',err)]:receipt[kind]={'path':path.name,'bytes':path.stat().st_size,'sha256':sha(path.read_bytes())}
        (destination/f'{i}.run.json').write_text(json.dumps(receipt,indent=2)+'\n');assert result.returncode==exit_code,receipt
print(json.dumps(preparation,indent=2))
