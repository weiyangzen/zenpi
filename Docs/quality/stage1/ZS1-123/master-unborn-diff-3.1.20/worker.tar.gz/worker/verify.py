#!/usr/bin/env python3
"""Verify frozen inputs, logs and exact patch without executing Cargo/product code."""
import sys
sys.dont_write_bytecode = True
from pathlib import Path
import hashlib, json, subprocess, tarfile, tempfile
ROOT = Path(__file__).resolve().parent
BEFORE = '7006078ff6a612b1d7a3cde59965e629919444ff0fb51034f5e86c7dca239831'
AFTER = 'e8635a418ccd613ef0587695ee9318d05e679be202494c0f04eb04651c12184e'
def sha(data): return hashlib.sha256(data).hexdigest()
def read_json(path): return json.loads(path.read_text())
def safe(rel):
    p = Path(rel)
    assert not p.is_absolute() and '..' not in p.parts
    return p

def verify():
    manifest = read_json(ROOT/'manifest.json')
    expected = set()
    for row in manifest['files']:
        path = ROOT/safe(row['path']); assert path.is_file() and not path.is_symlink()
        assert len(path.read_bytes()) == row['bytes'] and sha(path.read_bytes()) == row['sha256'], str(path)
        expected.add(row['path'])
    actual = {x.relative_to(ROOT).as_posix() for x in ROOT.rglob('*') if x.is_file() and x.name != 'manifest.json'}
    # The copied dependency manifest is itself a checked payload.
    actual.update(x.relative_to(ROOT).as_posix() for x in (ROOT/'dependency').rglob('manifest.json'))
    assert expected == actual, (expected-actual, actual-expected)
    before = (ROOT/'before.rs').read_bytes(); after = (ROOT/'after.rs').read_bytes()
    assert sha(before) == BEFORE and sha(after) == AFTER
    def unchanged_production(data):
        text=data.split(b'#[cfg(test)]')[0]
        start=text.index(b'/// Inspect the pending changes')
        end=text.index(b'pub fn diff_value(',start)
        text=text[:start]+b'REVIEWED_API_DOC\n'+text[end:]
        start=text.index(b'        if first.1 == 128 && !first.2 {')
        end=text.index(b'\n        } else {\n            first\n',start)
        return text[:start]+b'REVIEWED_UNBORN_FALLBACK'+text[end:]
    assert unchanged_production(before)==unchanged_production(after), 'unexpected production delta outside documented fallback'
    assert b'["hash-object", "-t", "tree", "--", "/dev/null"]' in after
    assert b'--untracked-files=all' in after
    runs = []
    for receipt in sorted((ROOT/'logs').glob('*.run.json')):
        run = read_json(receipt); assert run['status'] == 'finished'
        stem = receipt.name.removesuffix('.run.json')
        inventory_path = ROOT/'logs'/(stem+'.inputs.json')
        assert sha(inventory_path.read_bytes()) == run['inputs_sha256']
        inventory = read_json(inventory_path)
        for row in inventory:
            safe(row['path']); blob = ROOT/'blobs'/row['sha256']
            data = blob.read_bytes(); assert len(data) == row['bytes'] and sha(data) == row['sha256']
        owner = next(x for x in inventory if x['path'] == 'src/slash_actions.rs')
        assert owner['sha256'] == run['source_sha256']
        for kind in ['stdout','stderr']:
            row=run[kind]; data=(ROOT/'logs'/safe(row['path'])).read_bytes()
            assert len(data)==row['bytes'] and sha(data)==row['sha256']
        assert run['exit_code'] == (101 if stem == 'negative-current' else 0), run
        if stem.startswith('final-'): assert run['source_sha256']==AFTER
        runs.append(stem)
    for required in ['negative-current','fixed-counterexample','final-owner','final-integration','final-clippy','final-fmt']:
        assert required in runs
    neg=(ROOT/'logs/negative-current.stdout.log').read_text()
    fixed=(ROOT/'logs/fixed-counterexample.stdout.log').read_text()
    assert 'empty_baseline_comparisons=364 mismatches=208' in neg
    assert 'empty_baseline_comparisons=364 mismatches=0' in fixed
    assert 'test result: FAILED. 2 passed; 2 failed;' in neg
    assert 'test result: ok. 4 passed;' in fixed
    assert neg.count('empty no-index format=') == 8
    negative_inputs={x['path']:x['sha256'] for x in read_json(ROOT/'logs/negative-current.inputs.json')}
    fixed_inputs={x['path']:x['sha256'] for x in read_json(ROOT/'logs/fixed-counterexample.inputs.json')}
    assert negative_inputs.keys()==fixed_inputs.keys()
    assert [x for x in negative_inputs if negative_inputs[x]!=fixed_inputs[x]]==['src/slash_actions.rs']
    assert 'test result: ok. 19 passed;' in (ROOT/'logs/final-owner.stdout.log').read_text()
    integration=(ROOT/'logs/final-integration.stdout.log').read_text()
    assert integration.count('test result: ok. 5 passed;')==3 and 'test result: ok. 11 passed;' in integration
    final = read_json(ROOT/'logs/final-owner.inputs.json')
    with tarfile.open(ROOT/'build-inputs.tar.gz','r:gz') as archive:
        members=archive.getmembers(); assert len(members)==len(final)
        archived={}
        for member in members:
            safe(member.name); assert member.isfile()
            data=archive.extractfile(member).read(); archived[member.name]=(sha(data),len(data))
        assert archived=={x['path']:(x['sha256'],x['bytes']) for x in final}
    initial=read_json(ROOT/'initial-inputs.json')
    assert isinstance(initial,list)
    old={x['path']:x['sha256'] for x in initial}; new={x['path']:x['sha256'] for x in final}
    changed=[x for x in old if old[x] != new[x]]
    assert sorted(changed)==['src/slash_actions.rs','tests/quoted_untracked_review.rs']
    assert set(new)-set(old)=={'tests/unborn_diff_review.rs'}
    with tempfile.TemporaryDirectory(prefix='zenpi-directories-patch-') as directory:
        work=Path(directory); (work/'src').mkdir();(work/'src/slash_actions.rs').write_bytes(before)
        for argv in [['git','init','--quiet'],['git','apply','--check',str(ROOT/'product.patch')],['git','apply',str(ROOT/'product.patch')]]:
            result=subprocess.run(argv,cwd=work,capture_output=True);assert result.returncode==0,result.stderr
        assert (work/'src/slash_actions.rs').read_bytes()==after
        result=subprocess.run(['git','apply','--reverse',str(ROOT/'product.patch')],cwd=work,capture_output=True);assert result.returncode==0,result.stderr
        assert (work/'src/slash_actions.rs').read_bytes()==before
    boundary_before=read_json(ROOT/'boundary-before.json'); boundary_after=read_json(ROOT/'boundary-after.json')
    assert boundary_before==boundary_after
    return {'ok':True,'kind':'offline structural checks only','before_sha256':BEFORE,'after_sha256':AFTER,'manifest_sha256':sha((ROOT/'manifest.json').read_bytes()),'patch_exact_apply_reverse':'passed','only_production_change':'unborn empty-tree-to-worktree fallback plus API documentation','runtime_receipts_verified':len(runs),'final_inputs':len(final),'inherited_unchanged_inputs':len(initial)-len(changed),'top_level_tests':45,'nested_env_children_excluded':8,'unborn_gap_observation_in_total':0,'new_product_executions':0,'whole_item_123_acceptance':False}
if __name__=='__main__': print(json.dumps(verify(),indent=2))
