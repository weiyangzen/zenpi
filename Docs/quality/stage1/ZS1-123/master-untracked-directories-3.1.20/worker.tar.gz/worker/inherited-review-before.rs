#![cfg(unix)]
use std::os::unix::fs::MetadataExt;
use std::{fs, path::Path, process::Command};
use zenpi::slash_actions::diff_value_at;

fn git(root: &Path, args: &[&str]) -> String {
    let output = Command::new("git")
        .current_dir(root)
        .env_remove("GIT_GLOB_PATHSPECS")
        .env_remove("GIT_ICASE_PATHSPECS")
        .arg("--literal-pathspecs")
        .args(args)
        .output()
        .unwrap();
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
    String::from_utf8(output.stdout).unwrap()
}

#[test]
fn real_git_quoted_untracked_paths_keep_identity_in_all_scopes() {
    let directory = tempfile::tempdir().unwrap();
    let root = directory.path();
    git(root, &["init", "-q"]);
    git(root, &["config", "user.name", "quoted path fixture"]);
    git(root, &["config", "user.email", "quoted@example.test"]);
    for folder in ["scope[ab]", "scopea", "scope[ab]/note"] {
        fs::create_dir_all(root.join(folder)).unwrap();
        fs::write(root.join(folder).join("seed.txt"), "seed\n").unwrap();
    }
    git(root, &["add", "."]);
    git(root, &["commit", "-qm", "tracked directory seeds"]);
    let names = [
        r"note\report.txt",
        "note/report.txt",
        "space file.txt",
        "引号 文件.txt",
        "quote\"name.txt",
        "square[ab].txt",
        ":(glob)*.txt",
    ];
    for (index, name) in names.iter().enumerate() {
        fs::write(
            root.join("scope[ab]").join(name),
            format!("SELECTED_FILE_{index}\n"),
        )
        .unwrap();
    }
    fs::write(root.join("scopea/neighbor.txt"), "OUTSIDE_SCOPE\n").unwrap();
    assert_ne!(
        fs::metadata(root.join(r"scope[ab]/note\report.txt"))
            .unwrap()
            .ino(),
        fs::metadata(root.join("scope[ab]/note/report.txt"))
            .unwrap()
            .ino()
    );
    let mut missing = Vec::new();
    for quote in ["true", "false"] {
        git(root, &["config", "core.quotePath", quote]);
        for (index, name) in names.iter().enumerate() {
            let value = diff_value_at(root, Some(&format!("scope[ab]/{name}"))).unwrap();
            let diff = value["diff"].as_str().unwrap();
            assert!(
                diff.contains(&format!("+SELECTED_FILE_{index}")),
                "explicit {name:?}: {value}"
            );
            for other in 0..names.len() {
                if other != index {
                    assert!(!diff.contains(&format!("+SELECTED_FILE_{other}")));
                }
            }
        }
        for scope in [Some("scope[ab]"), None, Some(".")] {
            let value = diff_value_at(root, scope).unwrap();
            let diff = value["diff"].as_str().unwrap();
            for (index, name) in names.iter().enumerate() {
                let present = diff.contains(&format!("+SELECTED_FILE_{index}"));
                println!("quotePath={quote} scope={scope:?} name={name:?} present={present}");
                if !present {
                    missing.push(format!("{quote}/{scope:?}/{name:?}"));
                }
            }
            if scope == Some("scope[ab]") {
                assert!(!diff.contains("OUTSIDE_SCOPE"));
            }
            let expected = git(
                root,
                &[
                    "status",
                    "--porcelain=v1",
                    "--untracked-files=normal",
                    "--",
                    scope.unwrap_or("."),
                ],
            );
            assert_eq!(value["status"], expected, "readable status changed");
        }
    }
    assert!(missing.is_empty(), "quoted untracked omission: {missing:?}");
}

fn repository() -> tempfile::TempDir {
    let directory = tempfile::tempdir().unwrap();
    let root = directory.path();
    git(root, &["init", "-q"]);
    git(root, &["config", "user.name", "quoted bounds fixture"]);
    git(root, &["config", "user.email", "bounds@example.test"]);
    git(root, &["commit", "--allow-empty", "-qm", "initial"]);
    directory
}

#[test]
fn quoted_untracked_count_status_and_diff_caps_remain_bounded() {
    use zenpi::slash_actions::{MAX_SLASH_DIFF_BYTES, MAX_STATUS_BYTES};
    let directory = repository();
    let root = directory.path();
    for index in 0..40 {
        fs::write(
            root.join(format!("file {index:02}\".txt")),
            format!("QUOTED_BOUND_{index:02}\n"),
        )
        .unwrap();
    }
    let value = diff_value_at(root, None).unwrap();
    let diff = value["diff"].as_str().unwrap();
    assert_eq!(diff.matches("diff --git ").count(), 32);
    assert!(diff.contains("+QUOTED_BOUND_31"));
    assert!(!diff.contains("+QUOTED_BOUND_32"));
    assert!(diff.len() <= MAX_SLASH_DIFF_BYTES);
    assert!(value["status"].as_str().unwrap().len() <= MAX_STATUS_BYTES);

    let many = repository();
    for index in 0..180 {
        fs::write(
            many.path()
                .join(format!("file {index:03} {}", "q".repeat(220))),
            "bounded\n",
        )
        .unwrap();
    }
    let value = diff_value_at(many.path(), None).unwrap();
    let status = value["status"].as_str().unwrap();
    assert!(status.len() <= MAX_STATUS_BYTES && status.ends_with("[diff truncated]"));
    assert_eq!(
        value["diff"]
            .as_str()
            .unwrap()
            .matches("diff --git ")
            .count(),
        32
    );

    let large = repository();
    fs::write(
        large.path().join("quoted large.txt"),
        "x".repeat(MAX_SLASH_DIFF_BYTES * 2),
    )
    .unwrap();
    let value = diff_value_at(large.path(), None).unwrap();
    assert_eq!(value["changed"], true);
    assert_eq!(value["truncated"], true);
    assert!(value["diff"].as_str().unwrap().len() <= MAX_SLASH_DIFF_BYTES);
}

#[test]
fn real_git_renames_and_unrepresentable_paths_cannot_alias_untracked_files() {
    use std::ffi::OsString;
    use std::os::unix::{ffi::OsStringExt, fs::symlink};
    let directory = repository();
    let root = directory.path();
    fs::write(root.join("old name"), "TRACKED_RENAME\n").unwrap();
    git(root, &["add", "."]);
    git(root, &["commit", "-qm", "rename source"]);
    git(root, &["mv", "old name", "renamed\" file"]);
    fs::write(root.join("normal file"), "NORMAL_ALLOWED\n").unwrap();
    fs::write(root.join("line\nname"), "CONTROL_MUST_NOT_BE_READ\n").unwrap();
    fs::write(root.join("bad�"), "VALID_UTF8_NEIGHBOR\n").unwrap();
    match fs::write(
        root.join(OsString::from_vec(b"bad\xff".to_vec())),
        "INVALID_BYTES_MUST_NOT_BE_READ\n",
    ) {
        Ok(()) => println!("Native non-UTF-8 filename created: live Git identity check enabled"),
        Err(error) if error.raw_os_error() == Some(libc::EILSEQ) => {
            println!(
                "Filesystem rejects non-UTF-8 filenames with EILSEQ; native-file case unavailable, raw-byte decoder rejection is covered by the owner test"
            );
        }
        Err(error) => panic!("unexpected non-UTF-8 fixture error: {error}"),
    }
    let outside = tempfile::tempdir().unwrap();
    fs::write(outside.path().join("outside"), "SYMLINK_MUST_NOT_BE_READ\n").unwrap();
    symlink(outside.path().join("outside"), root.join("linked file")).unwrap();
    symlink(outside.path(), root.join("linked directory")).unwrap();
    for quote in ["true", "false"] {
        git(root, &["config", "core.quotePath", quote]);
        let value = diff_value_at(root, None).unwrap();
        let diff = value["diff"].as_str().unwrap();
        assert!(diff.contains("+NORMAL_ALLOWED"));
        assert_eq!(diff.matches("+VALID_UTF8_NEIGHBOR").count(), 1);
        for forbidden in [
            "CONTROL_MUST_NOT_BE_READ",
            "INVALID_BYTES_MUST_NOT_BE_READ",
            "SYMLINK_MUST_NOT_BE_READ",
        ] {
            assert!(!diff.contains(forbidden), "{quote}: {value}");
        }
        assert!(value["status"].as_str().unwrap().contains("R  "));
        assert!(value["status"].as_str().unwrap().contains(" -> "));
    }
    for denied in [
        "line\nname",
        "linked file",
        "linked directory/outside",
        "../outside",
    ] {
        assert!(diff_value_at(root, Some(denied)).is_err());
    }
}

#[test]
fn command_local_env_cleaning_also_applies_to_quoted_untracked_discovery() {
    for variable in ["GIT_GLOB_PATHSPECS", "GIT_ICASE_PATHSPECS"] {
        let output = Command::new(std::env::current_exe().unwrap())
            .env(variable, "1")
            .args([
                "--exact",
                "real_git_quoted_untracked_paths_keep_identity_in_all_scopes",
                "--nocapture",
            ])
            .output()
            .unwrap();
        println!(
            "{variable} child={}\n{}\n{}",
            output.status,
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
        assert!(output.status.success());
        assert!(String::from_utf8_lossy(&output.stdout).contains("1 passed"));
    }
}

#[test]
fn adjacent_untracked_recursion_and_unborn_mixed_diff_gaps_remain_explicit() {
    let directory = repository();
    let root = directory.path();
    fs::create_dir(root.join("new directory")).unwrap();
    fs::write(root.join("new directory/file"), "RECURSION_GAP\n").unwrap();
    let value = diff_value_at(root, None).unwrap();
    assert!(value["status"].as_str().unwrap().contains("new directory"));
    assert!(!value["diff"].as_str().unwrap().contains("RECURSION_GAP"));
    assert!(
        diff_value_at(root, Some("new directory/file")).unwrap()["diff"]
            .as_str()
            .unwrap()
            .contains("+RECURSION_GAP")
    );
    let unborn = tempfile::tempdir().unwrap();
    let root = unborn.path();
    git(root, &["init", "-q"]);
    fs::write(root.join("staged-only"), "STAGED_ONLY_GAP\n").unwrap();
    fs::write(root.join("mixed"), "before\n").unwrap();
    git(root, &["add", "."]);
    fs::write(root.join("mixed"), "UNSTAGED_VISIBLE\n").unwrap();
    let value = diff_value_at(root, None).unwrap();
    assert!(
        value["diff"]
            .as_str()
            .unwrap()
            .contains("+UNSTAGED_VISIBLE")
    );
    assert!(!value["diff"].as_str().unwrap().contains("STAGED_ONLY_GAP"));
    println!(
        "Remaining scope gaps observed: collapsed untracked directory and unborn mixed staged-only omission"
    );
}
