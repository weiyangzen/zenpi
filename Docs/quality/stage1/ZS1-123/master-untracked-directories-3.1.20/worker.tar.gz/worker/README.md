# ZS1-123 新未跟踪目录 diff 候选

先读 `report.md`。此包只适用于前置 quoted-untracked 候选的 after **eb8cd91d…**，不能直接应用到尚未包含前置包的主库。唯一产品文件是 `src/slash_actions.rs`，最终 after **7006078f…**。

- `product.patch`：仅产品补丁；新增目录通过 Git all 模式展开，可读 status 展示粒度改为逐文件。
- `before.rs` / `after.rs`：精确完整 owner。
- `report.md` / `read-coverage.json` / `dependency/`：审查、限制、全 owner 理解链。
- `logs/` / `blobs/` / `build-inputs.tar.gz`：9 次原始运行与完整输入，可独立重建。
- `review-adaptation.patch`：前包私有审查的必要预期调整，不属于产品补丁。
- `verify.py`：纯离线结构、hash、正反补丁验证，不执行产品。
- `replay.py --destination NEW --mode before|after`：默认仅准备；显式 `--run` 才执行原生离线 Cargo。

39 个顶层测试通过，6 次环境子执行不重复计数。Clippy/fmt 通过。无 HEAD 混合 staged-only/unstaged 缺口仍保留；没有整项 123 验收、PTY 或网络执行。工作区与主库未修改，旧 ready 保持封存。
