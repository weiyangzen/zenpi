# ZS1-123 文件补全可见状态修复候选

完成本次有界修复；不宣称整个123接受。仅改 `src/tui.rs`、`tests/tui_command_palette.rs`。主库与用户原worktree保持只读，所有实现、运行和证据均来自新的私有采集。

原实现 `complete_file_query`只返回Vec：2048条目录扫描上限、150ms软截止、128条显示裁剪没有传出原因；空结果不画菜单，同query不自动重扫。原有query比较包含root/input/prefix/path，主循环另有active job id检查，本次没有发现或假定原实现跨项目迟到污染。

现在返回`FileCompletionResult`，分别携带`scan=Complete/EntryLimit/TimeLimit`与`display_limited`。菜单说明Partial results及对应原因，并引导缩小路径/文件名前缀。仅完整扫描的空结果说“No matching files in this directory”；提前停止则说“No matches in scanned entries”，不会把未扫描文件说成不存在。结果、source详情和选中项统一通过原query/root身份比较。原last_file_query调度不变，不增加后台无限重试或快捷键；修改路径/前缀沿现有流程发新query。

保留2048 take、150ms严格大于时才停止、128 truncate；不做第2049条探测。因此恰好2048条也记录EntryLimit——达到上限时无法证明枚举已耗尽，不宣称一定还有文件。150ms仍是合作式软截止，不能中断阻塞的文件系统调用。结束发布前额外复查cancel。没有改变root/父路径/symlink约束、排序、目录选择、BentoBox、Super/Ctrl-G、预算、依赖或全局键盘协议。

## 实际验证与失败保留

- **before真实失败**：只加两条可见回归，原tui.rs保持639010B / b15661a160a855ef974e82dfb40a63c8d0c5777623cd553d1d4cf2069d8b59a1。原实现运行exit101：1原有例通过，两条新增例分别因缺少Partial results和完整空结果提示失败；完整stdout/stderr及原回归源码保留在`logs/before.*`和`before/regression-tests.rs`。未先改实现再伪造失败。原before测试可执行文件未单独留hash；证据绑定当时完整输入/测试、编译日志和实际失败输出，不冒充保留了该历史二进制。
- **fix定向**：lib3通过（含2新增及原Unicode例）；palette5通过（含4新增及原cwd/stale例）。真实文件系统；私有clock参数仅在单元测试确定性驱动150/151ms，生产仍Instant.elapsed。验证2048/2049、128/129、完整空与部分空、预取消与最后发布前取消，不依赖墙钟抢跑。
- **现有四组完整回归**：BentoBox16、command_palette21、composer51、project_workspace11，共99通过。与定向有重叠，不累加为107个独立测试。包含刚合入Super/Ctrl-G、路径/Unicode/paste、顶栏+与目录选择；`tests/tui_composer.rs`保持52941B / 30d9b19bc250409bac1e4254b7237f11cf8de625913d55b669a044665e89d7c1。
- **clippy**：native ARM、locked/offline，`--lib --test tui_command_palette -- -D warnings` exit0。vendor/crossterm原有括号warning仍在stderr，未修改依赖或以“无warning”掩盖。
- **新真实PTY恰好一次**：`pty_completion_probe.py`无旧runner imports，不执行旧runner。新私有目录/配置、原生ARM debug二进制、真实输入/后台补全/渲染/Tab/Esc/quit。11项通过；Partial及引导文字实际可见，补足199前缀后Partial消失，Tab选择文件而不提交；完整空提示和Esc保留draft；正常退出、回收进程、恢复alternate screen。HTTP观察器拒绝任何请求且计数0，journal turn计数0。`pty-evidence/terminal.raw`与四份真实文本screen projection保留；投影解释cursor/erase，不能等同像素截图或全终端仿真。运行过的50,844,072B Mach-O arm64文件原样保存在`bin/zenpi`，不要为offline校验运行它。

所有Cargo运行使用已安装的`stable-aarch64-apple-darwin`、`--locked --offline`和新独立`.ops/zs1-123-file-completion321-target`。最初只读`rustc -vV`因默认指向不可用stable-x86_64失败，随后明确选ARM，没有下载或安装工具链。没有release/预算/prewarm/FIFO/DTrace/131测试、旧probe、真实模型服务或subagent。唯一HTTP监听仅为新PTY的本机零请求观察器。

## 输入、阅读、补丁与边界

`initial-inputs.json`绑定当前main新复制的202个构建输入，`project/`保存构建过的完整私有输入。`scope-observation.json`确认只有2个owned文件改变，main当时202输入均未漂移。`before/`保留两文件原文、composer以及Cargo双文件；`candidate.patch`是针对上述精确新main字节的补丁，约21KiB，禁止覆盖不同基线。无需更改Cargo.lock/Cargo.toml或测试composer文件。

`reading-ranges.json`记录实际相关完整代码范围及调用点，不声称完整阅读647684B tui.rs。已读Query/Result/扫描、state保存和project reset/query root、query构建/application、slash choices/selection/render/mouse/键盘交互、后台job与last query轮询、所有生产与测试调用方；tests/tui_command_palette原文件全文已读，composer相关caller有界阅读。搜索首次误含Docs归档导致截断，后来只查当前src/tests并补齐范围；未把归档扫描命中计作新行为证据。

API返回类型现在是FileCompletionResult，外部调用方若以前直接使用Vec须改为`.entries`；仓库所有调用点已适配/编译验证。两条状态提示不是候选行，mouse不得选择提示，Tab仍选实际高亮文件。极窄/极矮终端沿现有裁剪/可用空间策略，未证明每个终端尺寸都能同时显示所有提示文字。扫描状态只描述那次有限枚举，不承诺文件随后不变化，也不保证缩小同目录前缀就一定能覆盖被上限跳过的成员；可进一步缩小目录路径或手工给出已知路径。

`run-receipts.json`列实际命令、exit与日志hash；`chunk_manifest.tsv`仅分块大输入身份，阅读覆盖独立列出。完整ready冻结后只运行一次新的纯Python portable，stdout/stderr/run元数据全部外置。它检查payload、输入保护、补丁、运行证据和二进制绑定，不重跑Cargo/PTY，也不认证语义或整个123。结果以包外回执为准，不在冻结后改写本README。

主控需独立审查并在这两个精确main基线上应用补丁，再决定自己的集成验证和123状态。回滚仅撤本次两个文件差异，保留122、所有旧ready/失败与其它用户工作。交付后B停止。
