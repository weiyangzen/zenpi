"""Read-only offline verification; never import archived code or execute any product."""
from pathlib import Path
import argparse, difflib, hashlib, json, sys
def sha(b):return hashlib.sha256(b).hexdigest()
checks=[]
def check(name,ok):checks.append({'name':name,'ok':bool(ok)})
def verify(root):
 root=root.resolve()
 def raw(p):
  q=(root/p).resolve()
  if not q.is_relative_to(root):raise ValueError('outside packet')
  return q.read_bytes()
 def data(p):return json.loads(raw(p))
 m=data('manifest.json')
 paths=sorted(str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p!=root/'manifest.json')
 check('exact payload',paths==sorted(x['path'] for x in m['payload']))
 check('payload totals',len(paths)==m['payload_files'] and sum(x['bytes'] for x in m['payload'])==m['payload_bytes'])
 for r in m['payload']:
  b=raw(r['path']);check('payload:'+r['path'],len(b)==r['bytes'] and sha(b)==r['sha256'])
 inputs=data('initial-inputs.json')['files'];obs=data('scope-observation.json')
 owned=['src/tui.rs','tests/tui_command_palette.rs']
 check('only authorized files',m['owned_paths']==owned and sorted(x['path'] for x in obs['changed_inputs'])==owned)
 actual=sorted(str(p.relative_to(root/'project')) for p in (root/'project').rglob('*') if p.is_file())
 check('project input path set',actual==sorted(r['path'] for r in inputs))
 for r in inputs:
  b=raw(('before/' if r['path'] in owned else 'project/')+r['path'])
  check('captured or protected input:'+r['path'],len(b)==r['bytes'] and sha(b)==r['sha256'])
 check('master122 composer exact',len(raw('project/tests/tui_composer.rs'))==52941 and sha(raw('project/tests/tui_composer.rs'))=='30d9b19bc250409bac1e4254b7237f11cf8de625913d55b669a044665e89d7c1')
 check('master122 tui exact baseline',len(raw('before/src/tui.rs'))==639010 and sha(raw('before/src/tui.rs'))=='b15661a160a855ef974e82dfb40a63c8d0c5777623cd553d1d4cf2069d8b59a1')
 patch=''
 for f in owned:
  patch+=''.join(difflib.unified_diff(raw('before/'+f).decode().splitlines(True),raw('project/'+f).decode().splitlines(True),fromfile='a/'+f,tofile='b/'+f))
 check('exact two-file patch',raw('candidate.patch')==patch.encode() and len(patch.encode())<256*1024)
 check('no initial main drift',obs['main_drift_from_captured_inputs']==[])
 runs=data('run-receipts.json')
 check('four actual Cargo records',[(x['name'],x['exit']) for x in runs]==[('before',101),('fix-targeted',0),('regression',0),('clippy',0)])
 for r in runs:
  check('native locked offline:'+r['name'],r['env']['RUSTUP_TOOLCHAIN']=='stable-aarch64-apple-darwin' and '--locked' in r['argv'] and '--offline' in r['argv'] and r['env']['CARGO_TARGET_DIR'].endswith('zs1-123-file-completion321-target'))
  for l in r['logs']:
   b=raw(l['path']);check('run log:'+l['path'],sha(b)==l['sha256'] and len(b)==l['bytes'])
 before=raw('logs/before.stdout').decode()
 check('real failing assertions preserved','1 passed; 2 failed' in before and 'file_completion_partial_menu_explains_hidden_matches' in before and 'file_completion_complete_empty_menu_reports_only_this_directory' in before)
 regression=raw('logs/regression.stdout').decode()
 for count in [16,21,51,11]:check('regression:'+str(count),f'{count} passed; 0 failed' in regression)
 targeted=raw('logs/fix-targeted.stdout').decode()
 check('targeted results','3 passed; 0 failed' in targeted and '5 passed; 0 failed' in targeted)
 pty=data('pty-evidence/result.json')
 check('PTY actual11 all pass',pty['ok'] and len(pty['checks'])==11 and all(pty['checks'].values()))
 check('PTY zero requests',pty['http_requests']==[] and pty['checks']['no_provider_turn_submitted'])
 check('PTY byte-identical executable',sha(raw('bin/zenpi'))==pty['binary_sha256'])
 check('ARM64 Mach-O',raw('bin/zenpi')[:8]==bytes.fromhex('cffaedfe0c000001'))
 check('terminal restoration',b'\x1b[?1049l' in raw('pty-evidence/terminal.raw'))
 for name in ['partial','narrowed','complete-empty','dismissed']:
  s=raw('pty-evidence/'+name+'.screen.txt').decode()
  check('PTY screen:'+name,('Partial results' in s if name=='partial' else 'Partial results' not in s))
 check('actual empty display','No matching files in this directory' in raw('pty-evidence/complete-empty.screen.txt').decode())
 for r in data('reading-ranges.json'):
  lines=raw(r['snapshot']).splitlines(keepends=True);a,b=r['start_line'],r['end_line'];part=b''.join(lines[a-1:b])
  check('reading range:'+r['id'],1<=a<=b<=len(lines) and len(part)==r['bytes'] and sha(part)==r['sha256'])
 chunksets={}
 for line in raw('chunk_manifest.tsv').decode().splitlines()[1:]:
  p,a,b,h=line.split('\t');a=int(a);b=int(b)
  check('input chunk:'+p+':'+str(a),0<=a<b<=len(raw(p)) and b-a<=256*1024 and sha(raw(p)[a:b])==h)
  chunksets.setdefault(p,[]).append((a,b))
 for p,ranges in chunksets.items():
  check('input chunk union:'+p,ranges[0][0]==0 and ranges[-1][1]==len(raw(p)) and all(x[1]==y[0] for x,y in zip(ranges,ranges[1:])))
 selector=data('authority/Docs/execution/active_requirement.json')
 check('authority3.1.21',selector['blueprint_version']=='3.1.21' and selector['requirement_digest']==m['requirement_digest'] and selector['baseline_snapshot_sha256']==m['baseline_snapshot_sha256'] and selector['run_id']==m['run_id'])
 check('whole item remains unaccepted',m['master_accepted'] is False and m['whole_123_accepted'] is False)
 return {'item':'ZS1-123','candidate':'file-completion-status','packet_ok':all(x['ok'] for x in checks),'checks_count':len(checks),'passed':sum(x['ok'] for x in checks),'failed':sum(not x['ok'] for x in checks),'checks':checks,'new_runtime_executions_by_verifier':0,'whole_123_accepted':False,'cwd':str(Path.cwd())}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent);args=p.parse_args()
 try:r=verify(args.root)
 except Exception as e:r={'packet_ok':False,'error':repr(e),'checks_count':len(checks),'checks':checks}
 print(json.dumps(r,ensure_ascii=False,indent=2));sys.exit(0 if r['packet_ok'] else 1)
