import {it,expect,afterAll} from 'vitest';
import {writeFileSync} from 'node:fs';
import {prepareCompaction,compactWithRequest} from './source/packages/agent/src/harness/compaction/compaction.ts';
import {prepareBranchEntries,generateBranchSummaryWithRequest} from './source/packages/agent/src/harness/compaction/branch-summarization.ts';
import {computeFileLists} from './source/packages/agent/src/harness/compaction/utils.ts';
import {buildSessionContext} from './source/packages/agent/src/harness/session/context.ts';
import {BACKGROUND_CONTEXT as bg,withAbortSignal} from './source/packages/agent/src/harness/context.ts';
import {getOrThrow} from './source/packages/agent/src/harness/types.ts';
const records:any[]=[];
const usage={input:2,output:3,cacheRead:0,cacheWrite:0,totalTokens:5,cost:{input:0,output:0,cacheRead:0,cacheWrite:0,total:0}};
const model:any={id:'fixture',provider:'fixture',api:'fixture',reasoning:false,maxTokens:1000,contextWindow:5000};
const user=(text:string):any=>({role:'user',content:[{type:'text',text}],timestamp:1});
const answer=(text:string,stopReason='stop'):any=>({role:'assistant',content:[{type:'text',text}],api:'fixture',provider:'fixture',model:'fixture',usage,stopReason,timestamp:2});
const entries=(ms:any[]):any[]=>ms.map((message,i)=>({type:'message',id:'m'+i,parentId:i?'m'+(i-1):null,seq:i,timestamp:i,message}));
const settings={enabled:true,reserveTokens:100,keepRecentTokens:1};
const cp=(result:any):any=>({type:'compaction',id:'cp',parentId:null,seq:10,timestamp:10,...result});
afterAll(()=>writeFileSync(process.env.DIR_OBSERVATIONS! ,JSON.stringify(records,null,2)+'\n'));

it('D050-01 branch collector and shared utils feed summary text into compaction and session projection',async()=>{
 const call={...answer(''),content:[{type:'toolCall',id:'write',name:'write',arguments:{path:'shared.ts'}}],stopReason:'toolUse'};
 const source=entries([user('branch goal'),call,{role:'toolResult',toolName:'write',toolCallId:'write',content:[{type:'text',text:'FAILED_WRITE_MARKER'}],isError:true,timestamp:3}]);
 const before=JSON.stringify(source);const prep=prepareBranchEntries(source,10000);
 expect(computeFileLists(prep.fileOps)).toEqual({readFiles:[],modifiedFiles:['shared.ts']});
 let branchPrompt='';
 const branch=getOrThrow(await generateBranchSummaryWithRequest(prep,{},async(context:any,options:any)=>{
  branchPrompt=context.messages[0].content[0].text;expect(options.signal).toBe(bg.abortSignal);return answer('BRANCH_PENDING_ITEM');
 },bg));
 expect(branchPrompt).toContain('write(path="shared.ts")');expect(branchPrompt).not.toContain('FAILED_WRITE_MARKER');
 expect(branch.summary).toContain('<modified-files>\nshared.ts\n</modified-files>');
 const branchEntry:any={type:'branch_summary',id:'branch',parentId:null,seq:0,timestamp:0,fromId:'old',summary:branch.summary,details:{readFiles:branch.readFiles,modifiedFiles:branch.modifiedFiles}};
 const path=[branchEntry,...entries([user('new task'),answer('retained answer')])];
 const p=getOrThrow(prepareCompaction(path,settings))!;const prompts:string[]=[];
 const result=getOrThrow(await compactWithRequest(p,{model},async(context:any)=>{prompts.push(context.messages[0].content[0].text);return answer('COMPACT_PENDING_ITEM');},bg));
 expect(prompts.join('\n')).toContain('BRANCH_PENDING_ITEM');expect(prompts.join('\n')).toContain('shared.ts');
 // Branch file tags survive in prompt text, They are not imported into compaction's typed details.
 expect(result.details).toEqual({readFiles:[],modifiedFiles:[]});
 const projected=await buildSessionContext([cp(result)],undefined,bg);
 expect(projected[0].role).toBe('compactionSummary');expect(JSON.stringify(projected)).toContain('COMPACT_PENDING_ITEM');
 expect(JSON.stringify(source)).toBe(before);
 records.push({case:'D050-01',branchPrompt,branch,result,prompts,projected,failedToolIntentRecorded:true,branchTypedDetailsNotCarriedIntoCompaction:true});
});

it('D050-02 compaction result roundtrip rebuilds latest summary tail and filters failed assistants',async()=>{
 const previous:any={type:'compaction',id:'oldcp',parentId:null,seq:0,timestamp:0,summary:'OLD_PENDING',tokensBefore:900,retainedTail:[user('retained old task'),answer('completed old task')],details:{readFiles:['read.md'],modifiedFiles:['changed.ts']}};
 const path=[...entries([user('stale ancestor')]),previous,...entries([user('new goal'),answer('new answer')])];
 const before=JSON.stringify(path);const p=getOrThrow(prepareCompaction(path,settings))!;const prompts:string[]=[];
 const result=getOrThrow(await compactWithRequest(p,{model},async(context:any)=>{prompts.push(context.messages[0].content[0].text);return answer('NEW_SUMMARY');},bg));
 expect(prompts.join('\n')).toContain('OLD_PENDING');
 expect(result.details).toEqual({readFiles:['read.md'],modifiedFiles:['changed.ts']});
 const committed=[...path,cp(result),...entries([answer('FAILED','error'),answer('CANCELLED','aborted'),answer('DEFERRED','deferred'),user('after checkpoint')])];
 const restored=JSON.parse(JSON.stringify(committed));
 const projected=await buildSessionContext(restored,undefined,bg);
 expect(projected.map((m:any)=>m.role)).toEqual(['compactionSummary','assistant','user']);
 expect(JSON.stringify(projected)).not.toMatch(/stale ancestor|FAILED|CANCELLED|DEFERRED/);
 expect(JSON.stringify(projected)).toContain('after checkpoint');
 expect(JSON.stringify(path)).toBe(before);
 records.push({case:'D050-02',prompts,result,projected,roundtrip:'JSON fixture; no upstream journal or OS restart'});
});

for(const reason of ['error','aborted']) it('D050-03/04 split summary '+reason+' prevents result publication and preserves input projection',async()=>{
 const source=entries([user('history'),answer('history done'),user('prefix'),answer('tail')]);
 const p=getOrThrow(prepareCompaction(source,settings))!;expect(p.isSplitTurn).toBe(true);
 const before=await buildSessionContext(source,undefined,bg);const serialized=JSON.stringify(source);
 const controller=new AbortController();const context=withAbortSignal(controller.signal,bg);const events:string[]=[];
 const failed=await compactWithRequest(p,{model},async(_request:any,options:any)=>{
  expect(options.signal).toBe(controller.signal);events.push(events.length?'prefix':'history');
  if(events.length===1)return answer('history summary');
  if(reason==='aborted')controller.abort();
  return answer('',reason);
 },context);
 expect(failed.ok).toBe(false);expect(events).toEqual(['history','prefix']);
 expect(JSON.stringify(source)).toBe(serialized);expect(await buildSessionContext(source,undefined,bg)).toEqual(before);
 records.push({case:'D050-03/04',reason,events,result:failed,projectionUnchanged:true});
});

it('D050-05 thrown request crosses both summary wrappers without a partial result',async()=>{
 const source=entries([user('task'),answer('answer')]);const before=JSON.stringify(source);
 const boom=new Error('REQUEST_THROWN');const request:any=async()=>{throw boom;};
 await expect(compactWithRequest(getOrThrow(prepareCompaction(source,settings))!,{model},request,bg)).rejects.toBe(boom);
 await expect(generateBranchSummaryWithRequest(prepareBranchEntries(source),{},request,bg)).rejects.toBe(boom);
 expect(JSON.stringify(source)).toBe(before);records.push({case:'D050-05',propagated:true,sourceUnchanged:true});
});

