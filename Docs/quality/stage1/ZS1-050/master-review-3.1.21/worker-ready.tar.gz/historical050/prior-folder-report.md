# ZS1-050 — packages/agent/src/harness/compaction

Candidate: [_]. Requirement binding: 3.1.6 / 7b0e7e379ccb80956d3df4e6207f530464283fb684b421668f72fd445720e676. Directory synthesis is separate from source-file acceptance and product ZS1-103/104 acceptance.

The frozen immediate-child set contains exactly one file: ZS1-012 / `compaction.ts`, SHA-256 `6e7aec0d27cb566f8f85f7dd13850eda98f5ddf7e78f9a919fb3dd03c3ea3a8a`, 27,410 bytes / 865 lines at pi-mono `bbb61e34aaf231639fdaaad1adbd757947034eac`. It has no frozen immediate child directories. The master per-file report at `Docs/learn/stage1_pi_mono/files/packages/agent/src/harness/compaction/compaction.ts_learn.md` was inspected; the worker independently reread all source lines in contiguous ranges 1–440 and 441–865. The presence of unfrozen neighboring utilities does not extend this closure.

## Immediate-child integration

The module's exports form one sequence: estimate current context from valid provider usage plus trailing heuristics; decide whether the model window minus reserve is exceeded; prepare immutable history/prefix/tail slices with previous-summary and file-operation state; call the caller-owned request function; combine actual usage and file lists into a result for the host to commit. No sibling in the frozen child set owns persistence. Imports from `utils.ts`, session/context, model/retry, and usage modules are external call boundaries, not independently audited children in this report.

Data flows from session ancestry and prior compaction into `CompactionPreparation`; only `CompactResult` can become the host's new entry. The retained tail and its prior-summary update are coupled. History and optional split-prefix requests are sequential, and either aborted/error response stops the result. The host owns the cancellation boundary before publishing; the source itself cannot guarantee atomic journal commit.

Stage 1 intentionally strengthens two behaviors: complete user/tool turns cannot be split, and empty/length/truncated summaries are rejected. The source's character/image accounting is approximate; Rust must use selected-model metadata and explicitly label conservative estimates. Previous goals, constraints, decisions, blockers, pending work and file facts must survive iterative summary updates, while unresolved tools remain in retained context with explicit provenance.

## Target integration and evidence boundary

ZS1-103 supplies source/branch/tip hashes, complete-turn cuts, retained IDs, file lists, unresolved-call records and append-only checkpoint validation in `src/context.rs` and `src/session.rs`. ZS1-104 must invoke the actual configured backend under the existing budget/cancel owner, validate summary and usage, atomically commit, and use that checkpoint in the next and restarted provider context. A digest/count checkpoint is historical compatibility data, not a semantic substitute.

File report closure: one required immediate file report was found and read; its hash matches the independently read source. Directory closure does not mark that file accepted. Root/controller G-DIR and actual source/backend/independent-process product validators remain separate acceptance gates. No parent harness directory or entire source tree is declared complete here.

## Completed worker product linkage (candidate only)

104 now connects this flow through Agent, existing BudgetLedger/InputPump, actual backend HTTP, operation-correlated checkpoint append and restarted provider context. The independent product evidence is `Docs/quality/stage1/ZS1-104/worker-owner/review.md`; its 12 actual-HTTP/process cases do not automatically accept this directory or its child source file. 105/106 branch selection remains subsequent owner work.
