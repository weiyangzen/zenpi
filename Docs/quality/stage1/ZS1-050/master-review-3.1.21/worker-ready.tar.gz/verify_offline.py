"""Read/hash/JSON/patch checks only. Never executes historical runners or tests."""
from pathlib import Path
import csv
import difflib
import hashlib
import json
import sys

root = Path(sys.argv[1]).resolve()
master = Path('/Users/wangweiyang/GitHub/zenpi')
upstream = Path('/Users/wangweiyang/GitHub/pi-mono')
worker = Path('/Users/wangweiyang/.codex/worktrees/2267/zenpi')
checks = []

def load(path):
    return json.loads(path.read_text())

def identity(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def check(name, condition, detail=None):
    checks.append({'name': name, 'passed': bool(condition), 'detail': detail})

def matches(path, row):
    return identity(path) == {k: row[k] for k in ('bytes', 'sha256')}

capture = load(root / 'capture.json')
old = root / 'historical050'
om = load(old / 'manifest.json')
check('old manifest identity', matches(old / 'manifest.json', capture['old050']['manifest']))
check('old 55 payloads intact', len(om['files']) == 55 and all(matches(old / r['path'], r) for r in om['files']))
check('old exact 56-file set', {str(p.relative_to(old)) for p in old.rglob('*') if p.is_file()} == {'manifest.json'} | {r['path'] for r in om['files']})
sources = load(old / 'source-inventory.json')
check('27 original source identities current', len(sources) == 27 and all(matches(old / 'source' / r['path'], r) and matches(upstream / r['path'], r) for r in sources))
directory = 'packages/agent/src/harness/compaction'
check('three direct files and no subdirectory', sorted(p.name for p in (upstream / directory).iterdir()) == sorted(r['name'] for r in capture['direct_entries']) and all(p.is_file() for p in (upstream / directory).iterdir()))
check('three current source copies', all(matches(root / 'current-source' / directory / r['name'], r) and matches(upstream / directory / r['name'], r) for r in capture['direct_entries']))
receipt = load(root / 'dependency012/receipt.json')
check('current accepted master012 receipt identity', matches(root / 'dependency012/receipt.json', capture['dependency012_receipt']) and matches(master / 'Docs/learn/stage1_pi_mono/receipts/ZS1-012.master.json', capture['dependency012_receipt']))
check('69 dependency artifact identities', len(receipt['artifacts']) == 69 and all(matches(root / 'dependency012' / r['path'], r) and matches(master / r['path'], r) for r in receipt['artifacts']))
check('012 acceptance and complete source reading chain', receipt['complete'] and receipt['manual_review']['decision'] == 'accepted' and receipt['role'] == 'master' and receipt['read_ranges'] == [[0, 27410]] and receipt['source_hash'] == capture['direct_entries'][1]['sha256'])
before = load(root / 'authority/Docs/execution/active_requirement.json')
after = load(root / 'authority-final/Docs/execution/active_requirement.json')
check('3.1.21 binding unchanged except snapshot', all(before[k] == after[k] for k in before if k != 'snapshot_sha256') and after['requirement_digest'] == receipt['requirement_digest'] == capture['requirement_digest'] and after['baseline_snapshot_sha256'] == receipt['baseline_snapshot_sha256'] == capture['baseline_snapshot_sha256'])
check('final selector still current', identity(root / 'authority-final/Docs/execution/active_requirement.json') == identity(master / 'Docs/execution/active_requirement.json'))
bp_before = (root / 'authority/Docs/stage_1_v3_pi_mono_blueprint.md').read_text()
bp_after = (root / 'authority-final/Docs/stage_1_v3_pi_mono_blueprint.md').read_text()
def item(text, number):
    return next(line for line in text.splitlines() if f'**ZS1-{number}**' in line)
check('012 050 054 records unchanged', all(item(bp_before,n) == item(bp_after,n) for n in ['012','050','054']) and item(bp_after,'012').startswith('- [x]') and item(bp_after,'050').startswith('- [ ]') and item(bp_after,'054').startswith('- [ ]'))
def rows(name):
    with (root / 'authority/Docs/learn/stage1_pi_mono' / name).open() as f:
        return list(csv.DictReader(f, delimiter='\t'))
direct = [r for r in rows('source_manifest.tsv') if str(Path(r['source_path']).parent) == directory]
folder = [r for r in rows('folder_learn_index.tsv') if r['folder_path'] == directory]
check('frozen direct inventory only012 and closure050', len(direct) == 1 and direct[0]['item_id'] == 'ZS1-012' and direct[0]['status'] == '[x]' and len(folder) == 1 and folder[0]['depends'] == 'ZS1-012')
contexts = load(root / 'current-context-inventory.json')
check('ten captured current context files', len(contexts) == 10 and all(matches(root / r['copy'], r) and matches(Path(r['origin']), r) for r in contexts))
a = (old / 'initial-fixture-failure/directory.test.ts').read_text()
b = (old / 'directory.test.ts').read_text()
check('only signal/context fixture correction', a.count('withAbortSignal(bg,controller.signal)') == 1 and a.replace('withAbortSignal(bg,controller.signal)', 'withAbortSignal(controller.signal,bg)') == b)
patch = ''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='initial-fixture-failure/directory.test.ts',tofile='directory.test.ts'))
check('frozen correction patch exact', (root / 'historical-fixture-correction.patch').read_text() == patch)
initial = load(old / 'initial-fixture-failure/test-results.json')
final = load(old / 'test-results.json')
check('historical failure3pass2fail then5pass', initial['numPassedTests'] == 3 and initial['numFailedTests'] == 2 and final['numPassedTests'] == 5 and final['numFailedTests'] == 0 and final['numPendingTests'] == final['numTodoTests'] == 0 and load(old / 'validation.json')['exit_code'] == 0)
failed = [r for r in initial['testResults'][0]['assertionResults'] if r['status'] == 'failed']
check('both fixture errors parent.value', len(failed) == 2 and all('this[#parent].value is not a function' in '\n'.join(r['failureMessages']) for r in failed))
observations = load(old / 'observations.json')
check('five historical observations scope', len(observations) == 5 and observations[0]['branchTypedDetailsNotCarriedIntoCompaction'] and observations[0]['result']['details'] == {'readFiles':[], 'modifiedFiles':[]} and observations[1]['roundtrip'] == 'JSON fixture; no upstream journal or OS restart' and all(r['projectionUnchanged'] for r in observations[2:4]) and observations[4]['propagated'])
actual = load(root / 'dependency012/Docs/quality/stage1/ZS1-012/master-review-3.1.19/actual-replay/test-results.json')
check('historical master37 in three files', actual['numPassedTests'] == 37 and actual['numFailedTests'] == 0 and len(actual['testResults']) == 3 and sorted(len(r['assertionResults']) for r in actual['testResults']) == [2,13,22])
protected = load(root / 'old-ready-inventory.json')
changed = [p for p, row in protected.items() if not matches(Path(p) if Path(p).is_absolute() else worker / p, row)]
check('4432 previous ready files unchanged', len(protected) == 4432 and not changed, changed)
candidate = 'Docs/learn/stage1_pi_mono/packages/agent/src/harness/compaction/current_folder_learn.md'
check('only one candidate artifact', [str(p.relative_to(root / 'files')) for p in (root / 'files').rglob('*') if p.is_file()] == [candidate])
check('historical report verbatim suffix', (root / 'files' / candidate).read_bytes().endswith((old / 'current_folder_learn.md').read_bytes()))
if (root / 'manifest.json').exists():
    manifest = load(root / 'manifest.json')
    check('ready manifest payload identities', all(matches(root / r['path'], r) for r in manifest['files']))
    check('ready exact artifact set', {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()} == {'manifest.json'} | {r['path'] for r in manifest['files']})
result = {'schema_version':'zs1-050-offline-review/v1', 'root':str(root), 'passed':all(c['passed'] for c in checks), 'checks':checks, 'runtime_executions_this_round':0, 'candidate':identity(root / 'files' / candidate), 'historical_test_counts':{'050':5,'012_master':37}, 'note':'Read/hash/JSON/patch audit, not runtime or product tests; semantic review is in candidate report.'}
print(json.dumps(result, indent=2))
sys.exit(0 if result['passed'] else 1)
