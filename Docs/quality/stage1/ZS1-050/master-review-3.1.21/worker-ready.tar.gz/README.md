# ZS1-050 / 3.1.21 private candidate

The sole integration candidate is files/Docs/learn/stage1_pi_mono/packages/agent/src/harness/compaction/current_folder_learn.md. Master acceptance and G-STAGE --item ZS1-050 remain pending. Do not accept 054 or ancestors from this package.

historical050 is the original 55-payload plus manifest package, unchanged. dependency012 contains the exact accepted receipt and its 69 artifacts. current-source contains all three physical direct files; only compaction.ts is in scope. current-context contains bounded-review support snapshots, not whole-file acceptance. authority and authority-final preserve the checkbox/snapshot refresh. reading-ledger distinguishes new reading from the complete 012 reuse chain.

No old run.sh, npm, Vitest, product, TUI or budget command was run in this review. Do not run historical scripts. verify_offline.py uses Python standard library for read/hash/JSON/patch checks only. Its live-origin checks are intentionally sensitive to subsequent master changes; offline-audit.json records the actual capture-time result. The manifest inventories the frozen package. Postfreeze verification is kept outside the ready directory.

The previous 3.1.17 provisional report and both initial 3pass/2fail and corrected 5pass results are preserved. The only historical fixture change was withAbortSignal argument order. Current 012 acceptance is separately bound to 3.1.21; its 37 master tests are reused historical evidence.
