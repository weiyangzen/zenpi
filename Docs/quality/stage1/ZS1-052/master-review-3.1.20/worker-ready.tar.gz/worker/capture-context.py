from pathlib import Path
import json,hashlib
p=Path(__file__).resolve().parent;main=Path('/Users/wangweiyang/GitHub/zenpi');pi=Path('/Users/wangweiyang/GitHub/pi-mono');sha=lambda b:hashlib.sha256(b).hexdigest();refs=[]
plans=[('source','types.ts',[(409,515),(1015,1084),(1588,1797)]),('source','runner.ts',[(270,490),(590,650),(723,1286)]),('source','loader.ts',[(177,306),(430,483),(527,649)]),('source','wrapper.ts',[(1,45)]),('source','index.ts',[(1,193)]),('pi','packages/coding-agent/src/core/tools/tool-definition-wrapper.ts',[(1,47)]),('pi','packages/coding-agent/src/core/agent-session.ts',[(482,536),(875,901),(2528,2700),(2841,2875)]),('target','src/extension_runtime.rs',[(35,90),(203,426),(641,685)]),('target','src/core.rs',[(2104,2210),(4500,4580),(4678,4725)]),('target','src/extensions.rs',[(269,311)])]
for scope,rel,ranges in plans:
 origin=p/'source'/rel if scope=='source' else (pi if scope=='pi' else main)/rel;b=origin.read_bytes();lines=b.splitlines(keepends=True);dest=p/'context-full'/scope/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
 for first,last in ranges:
  assert last<=len(lines),(rel,len(lines),last)
  data=b''.join(lines[first-1:last]);file=f'{len(refs)+1:02}-{Path(rel).name}-{first}-{last}.txt';fragment=p/'context'/file;fragment.parent.mkdir(exist_ok=True);fragment.write_bytes(data);refs.append({'id':f'R{len(refs)+1:02}','scope':scope,'source_path':str(origin),'full_snapshot':dest.relative_to(p).as_posix(),'file_sha256':sha(b),'lines':[first,last],'byte_range':[sum(map(len,lines[:first-1])),sum(map(len,lines[:last]))],'fragment':fragment.relative_to(p).as_posix(),'bytes':len(data),'sha256':sha(data),'acceptance':'formal subject connection context; existing child acceptance only' if scope=='source' and rel in ['types.ts','runner.ts'] else 'context-only, no file acceptance'})
(p/'context-index.json').write_text(json.dumps(refs,indent=2)+'\n')
old=p/'history/old-ready';base='Docs/learn/stage1_pi_mono/packages/coding-agent/src/core/extensions/current_folder_learn.md';paths=[old/'base'/base,old/'files/Docs/quality/stage1/ZS1-052/worker-directory-review/prior052-report.md',old/'files'/base];historical=[]
for x in paths:
 if x.exists():historical.append({'path':x.relative_to(p).as_posix(),'bytes':x.stat().st_size,'sha256':sha(x.read_bytes())})
(p/'history-prefixes.json').write_text(json.dumps(historical,indent=2)+'\n');drift=[]
for name in ['index.ts','loader.ts','runner.ts','types.ts','wrapper.ts']:
 f=old/'files/Docs/quality/stage1/ZS1-052/worker-directory-review/snapshots/pi/packages/coding-agent/src/core/extensions'/name;n=p/'source'/name;drift.append({'path':name,'old_sha256':sha(f.read_bytes()),'current_sha256':sha(n.read_bytes()),'source_changed':f.read_bytes()!=n.read_bytes()})
for item in ['022','023']:
 f=old/f'files/Docs/quality/stage1/ZS1-052/worker-directory-review/original-evidence/{item}/file-report.md';n=p/'children'/item/'canonical.md';drift.append({'child_report':item,'old_sha256':sha(f.read_bytes()),'old_bytes':f.stat().st_size,'current_sha256':sha(n.read_bytes()),'current_bytes':n.stat().st_size,'changed':f.read_bytes()!=n.read_bytes()})
(p/'drift.json').write_text(json.dumps(drift,indent=2)+'\n');print(json.dumps({'contexts':len(refs),'historical':historical,'drift':drift},indent=2))
