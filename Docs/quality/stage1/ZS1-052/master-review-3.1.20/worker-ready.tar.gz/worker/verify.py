#!/usr/bin/env python3
"""Offline integrity + reversible report checks. Never execute product/probe/receipt commands."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import csv,hashlib,json,subprocess,tempfile
ROOT=Path(__file__).resolve().parent
REL='Docs/learn/stage1_pi_mono/packages/coding-agent/src/core/extensions/current_folder_learn.md'
DIGEST='8d525b351d066ce9b0487a485337647d47233275782e4f4d154423a623fe1645'
def sha(b): return hashlib.sha256(b).hexdigest()
def read(p): return json.loads(p.read_text())
def safe(s):
 p=Path(s);assert not p.is_absolute() and '..' not in p.parts;return p

def verify():
 m=read(ROOT/'manifest.json'); listed=set()
 for row in m['files']:
  p=ROOT/safe(row['path']);assert p.is_file() and not p.is_symlink();b=p.read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256'],p;listed.add(row['path'])
 actual={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and p!=ROOT/'manifest.json'};assert actual==listed
 capture=read(ROOT/'capture.json');assert capture['canonical_absent']
 bp=(ROOT/'authority/Docs/stage_1_v3_pi_mono_blueprint.md').read_text();assert sha(bp.encode())==capture['blueprint_sha256']
 for item in ['022','023']:assert '- [x] **ZS1-'+item+'**' in bp
 directory_line=next(x for x in bp.splitlines() if x.startswith('- [ ] **ZS1-052**'));assert 'Depends: ZS1-022,ZS1-023' in directory_line and REL in directory_line
 rows=list(csv.DictReader((ROOT/'authority/Docs/learn/stage1_pi_mono/folder_learn_index.tsv').open(),delimiter='\t'));row=next(x for x in rows if x['item_id']=='ZS1-052');assert row['depends']=='ZS1-022,ZS1-023' and row['folder_artifact']==REL
 inventory=read(ROOT/'directory-listing.json');assert {x['name'] for x in inventory}=={'index.ts','loader.ts','runner.ts','types.ts','wrapper.ts'};assert all(x['kind']=='file' for x in inventory);assert {x['name'] for x in inventory if x['selected']}=={'types.ts','runner.ts'}
 for row in inventory:
  b=(ROOT/'source'/row['name']).read_bytes();assert sha(b)==row['sha256'] and len(b)==row['bytes'] and b.count(b'\n')==row['lines']
 child_refs=0
 for item,name in [('022','types.ts'),('023','runner.ts')]:
  folder=ROOT/'children'/item;receipt=read(folder/'master-receipt.json');assert receipt['role']=='master' and receipt['complete'] and receipt['manual_review']['decision']=='accepted' and receipt['requirement_digest']==DIGEST
  assert receipt['source_hash']==sha((ROOT/'source'/name).read_bytes());assert receipt['item_id']=='ZS1-'+item
  cursor=0
  for a,b in receipt['read_ranges']:assert a==cursor and b>a;cursor=b
  assert cursor==(ROOT/'source'/name).stat().st_size
  for rec in receipt['artifacts']:
   safe(rec['path']);file=folder/'canonical.md' if rec['path'].endswith(name+'_learn.md') else folder/'publication'/Path(rec['path']).name
   data=file.read_bytes();assert len(data)==rec['bytes'] and sha(data)==rec['sha256'],file;child_refs+=1
  assert sha((folder/'canonical.md').read_bytes())==capture['children'][item]['sha256']
 old=ROOT/'history/old-ready';assert sha((old/'manifest.json').read_bytes())==capture['old_ready_manifest_sha256'];old_manifest=read(old/'manifest.json')
 for rec in old_manifest['files']:
  data=(old/'files'/safe(rec['path'])).read_bytes();assert len(data)==rec['bytes'] and sha(data)==rec['sha256']
 history=(old/'files'/REL).read_bytes();prior=(old/'files/Docs/quality/stage1/ZS1-052/worker-directory-review/prior052-report.md').read_bytes();report=(ROOT/'report.md').read_bytes()
 assert len(history)==12934 and len(prior)==4209 and history.startswith(prior) and report==history+(ROOT/'append.md').read_bytes()
 assert sha(report)==m['report_sha256']
 contexts=read(ROOT/'context-index.json')
 for rec in contexts:
  data=(ROOT/safe(rec['full_snapshot'])).read_bytes();assert sha(data)==rec['file_sha256'];lines=data.splitlines(keepends=True);a,b=rec['lines'];fragment=b''.join(lines[a-1:b]);lo,hi=rec['byte_range'];assert fragment==data[lo:hi]==(ROOT/safe(rec['fragment'])).read_bytes();assert len(fragment)==rec['bytes'] and sha(fragment)==rec['sha256']
 for name in ['gstage','gstage-final']:
  run=read(ROOT/(name+'.run.json'));assert run['exit_code']==1
  for key in ['stdout','stderr']:
   row=run[key];data=(ROOT/safe(row['path'])).read_bytes();assert len(data)==row['bytes'] and sha(data)==row['sha256']
 gate=read(ROOT/'gstage-final.stdout.json');assert gate['structural']['ok'] and not gate['semantic_manual']['verified_by_checker'];assert len(gate['errors'])==1 and 'ZS1-052.master.json' in gate['errors'][0]
 assert 'ModuleNotFoundError' in (ROOT/'gstage.stderr.log').read_text()
 git_ops=0
 for patch,base in [('create-report.patch',None),('append-report.patch',history)]:
  with tempfile.TemporaryDirectory(prefix='zenpi-052-report-') as temp:
   work=Path(temp);f=work/REL;f.parent.mkdir(parents=True);sentinel=work/'unrelated.bin';sentinel.write_bytes(b'\x00keep\xff')
   if base is not None:f.write_bytes(base)
   for argv in [['git','init','--quiet'],['git','apply','--check',str(ROOT/patch)],['git','apply',str(ROOT/patch)]]:
    result=subprocess.run(argv,cwd=work,capture_output=True);assert result.returncode==0,result.stderr;git_ops+=1
   assert f.read_bytes()==report
   for argv in [['git','apply','--reverse','--check',str(ROOT/patch)],['git','apply','--reverse',str(ROOT/patch)]]:
    result=subprocess.run(argv,cwd=work,capture_output=True);assert result.returncode==0,result.stderr;git_ops+=1
   assert (not f.exists()) if base is None else f.read_bytes()==base
   assert sentinel.read_bytes()==b'\x00keep\xff'
 return {'ok':True,'kind':'offline structural/integrity only','payload_files':len(listed),'manifest_sha256':sha((ROOT/'manifest.json').read_bytes()),'report_sha256':sha(report),'report_bytes':len(report),'historical_prefix_bytes':[4209,12934],'formal_children':['ZS1-022','ZS1-023'],'child_receipt_artifacts_verified':child_refs,'context_only_direct_files':['index.ts','loader.ts','wrapper.ts'],'direct_subdirectories':0,'context_fragments':len(contexts),'scratch_git_operations':git_ops,'gstage_exit':1,'gstage_only_error':'missing ZS1-052 master receipt','semantic_verified_by_checker':False,'directory_accepted':False,'new_runtime_product_executions':0}
if __name__=='__main__': print(json.dumps(verify(),indent=2))
