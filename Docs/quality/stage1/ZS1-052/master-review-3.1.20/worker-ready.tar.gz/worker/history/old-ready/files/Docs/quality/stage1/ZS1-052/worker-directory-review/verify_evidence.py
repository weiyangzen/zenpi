from pathlib import Path
import json,hashlib
r=Path.cwd();e=r/'Docs/quality/stage1/ZS1-052/worker-directory-review';sha=lambda b:hashlib.sha256(b).hexdigest();j=json.loads((e/'inventory.json').read_text());p=Path('/Users/wangweiyang/GitHub/pi-mono')/j['folder'];assert len(j['entries'])==5 and all(x['kind']=='file' for x in j['entries']);assert sorted(x.name for x in p.iterdir())==[x['name'] for x in j['entries']]
for x in j['entries']:assert sha((p/x['name']).read_bytes())==x['sha256']
for x in j['snapshots']:assert sha((r/x['snapshot']).read_bytes())==x['sha256']
for x in j['dependencies']:
 for a in x.get('frozen_packages',[]):assert sha(Path(a['path']).read_bytes())==a['sha256']
for x in json.loads((e/'original-evidence.json').read_text()):assert sha(Path(x['copy']).read_bytes())==x['sha256']
for x in json.loads((e/'target-evidence-references.json').read_text()):assert sha(Path(x['path']).read_bytes())==x['sha256']
x=json.loads((e/'prior052-reference.json').read_text());assert sha(Path(x['old_frozen_path']).read_bytes())==x['sha256'];old=(e/'prior052-report.md').read_bytes();assert sha(old)==x['sha256'];assert (r/'Docs/learn/stage1_pi_mono/packages/coding-agent/src/core/extensions/current_folder_learn.md').read_bytes()==old+b'\n'+(e/'supplement-report.md').read_bytes()
x=json.loads((e/'source-combination.json').read_text());assert x['exit_code']==0 and sha(Path(x['output']).read_bytes())==x['sha256'];out=json.loads(Path(x['output']).read_text());assert out['tests']==9 and all(c['status']=='pass' for c in out['records'])
print('PASS:5 direct files/0 dirs; source hashes,022/023 and target frozen references,old052 report immutable prefix,9 actual source combination cases;provisional')
