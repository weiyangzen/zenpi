# ZS1-052 — packages/coding-agent/src/core/extensions

Worker candidate: [_], provisional. 022/023 are independently written candidates, not accepted [x]; therefore this integration report does not pass G-DIR acceptance yet. Source subset contains only types.ts and runner.ts. Other direct files below were fully read as context and are not promoted to extra final per-file artifacts. No direct subdirectories exist.

## Direct inventory

- `index.ts`: 4204 B / 193 lines, `3502526cb694e66e79b729a72956dd8be4be4556c8c60c3a0b534ac3bf7ad1ce`; context-only direct dependency.
- `loader.ts`: 25877 B / 809 lines, `c96284a217cd4e2eee8d7335a7c25b106135968c716ce39834b4714f5ff8f771`; context-only direct dependency.
- `runner.ts`: 39774 B / 1286 lines, `6d5101ab0551c2ddd904a8089cc221b3c448fcfe36c27e36da02cdacc869c084`; selected candidate file.
- `types.ts`: 63623 B / 1797 lines, `96e20f8038027f0b0172f311b6b9d9ddf42123b2f5b2a018f533af026fd3371e`; selected candidate file.
- `wrapper.ts`: 1832 B / 45 lines, `c89397e268ccf27aa465fa1307fdbe324a3457966803e3fc6ec4d982ae2d379d`; context-only direct dependency.

## Verified calls, state and errors

index.ts is a pure barrel of loader/runner/types/wrapper exports (fully read). loader.ts (809 lines, read 1–300/301–580/581–809) uses jiti with virtual bundles or aliases, checks factory exports and caches by cwd+generation. Runtime begins with throwing action stubs, guarded API methods, idempotent invalidation and tracked event-bus unsubscriptions. Per-extension load stages flag defaults/provider changes, commits after factory success and discards subscriptions on failure. Runtime registration is immediate after bind. Individual load errors collect while later paths continue. Discovery scans direct TS/JS or one-level index/package manifest entries, then project→global→explicit paths with resolved-path deduplication. No recursion beyond one level; source symlinks are followed for candidate resolution. This loading model is context only, not a target requirement to embed jiti.

runner.ts consumes loaded handler maps/tools and binds host actions; wrapper.ts fully read (43 lines) adapts registered tools to guarded current context, compares active tool lists before/after execution and reports additions only when no previous tool was removed. Interception itself belongs to AgentSession/agent-core, not wrapper. Context and result transformations are serial; tool-call block wins and exceptions propagate, other emitters generally catch and notify. Loader invalidation tears down bus subscriptions; runner context checks prevent captured old APIs after session replacement. No evidence of a subprocess kill/reap guarantee exists in this source directory.

## Target integration

115 will negotiate a subprocess manifest, serialize typed hook events, bound request/result/time, revoke a host-owned session-generation lease and join/reap all owned work. Tool dispatch must use existing schema/path/approval/policy owners after rewrite. Canonical native provider history remains immutable. Failed reload stages an entire replacement before publication; old capability revocation is only after success. Actual positive/negative/cancel/restart validators remain the implementation item's responsibility. Directory review never accepts parent core or unselected siblings.

## Candidate validation follow-up

115 actual owner candidate evidence is in `Docs/quality/stage1/ZS1-115/worker-hooks`: real HTTP and production JSONL exercise input chaining, typed results, lifecycle, schema/path/approval/policy revalidation, bad replies, kill/reap cancellation and new-process lease identity. `extensions-input-event.test.ts` was additionally read completely (125 lines): source continue/transform/handled, image preservation/replacement, chaining, source/streaming behavior and exception isolation. It was not executed. Target intentionally supports continue/transform text only; no handled/images or transcript replacement API. Input/context failure aborts that admission/request without publishing partial output; lifecycle/after-result failures keep owner state. The directory remains provisional until main accepts its independent child file reports.
