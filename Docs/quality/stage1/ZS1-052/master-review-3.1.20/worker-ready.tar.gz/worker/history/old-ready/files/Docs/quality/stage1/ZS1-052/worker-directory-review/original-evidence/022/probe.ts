import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import * as source from '/Users/wangweiyang/GitHub/pi-mono/packages/coding-agent/src/core/extensions/types.ts';
const path='/Users/wangweiyang/GitHub/pi-mono/packages/coding-agent/src/core/extensions/types.ts';
const hash=createHash('sha256').update(readFileSync(path)).digest('hex');
assert.equal(hash,'96e20f8038027f0b0172f311b6b9d9ddf42123b2f5b2a018f533af026fd3371e');
const records:any[]=[];
async function check(name:string,run:()=>unknown){await run();records.push({name,status:'pass'});}
await check('defineTool returns exact definition and preserves executable handler and mutable state',async()=>{
 const state={calls:0};const definition={name:'sample',parameters:{type:'object'},description:'sample',execute:async()=>{state.calls++;return {content:[{type:'text',text:'result'}],details:state};}};
 const actual=source.defineTool(definition as any);assert.equal(actual,definition);assert.equal(actual.execute,definition.execute);const result=await (actual.execute as any)();assert.equal(result.details,state);assert.equal(state.calls,1);
 definition.description='updated';assert.equal(actual.description,'updated');
});
await check('defineTool does not add runtime schema validation',()=>{const invalid={name:'',parameters:null,execute:null};assert.equal(source.defineTool(invalid as any),invalid);});
const guards=[['bash',source.isBashToolResult],['powershell',source.isPowerShellToolResult],['read',source.isReadToolResult],['edit',source.isEditToolResult],['write',source.isWriteToolResult],['grep',source.isGrepToolResult],['find',source.isFindToolResult],['ls',source.isLsToolResult]] as const;
for(const [name,guard]of guards){await check(`${name} result guard discriminates by toolName and preserves the original result`,()=>{
 const details={retained:true};const event={type:'tool_result',toolName:name,toolCallId:'id',input:{path:'x'},content:[{type:'text',text:'body'}],isError:true,details};const before=JSON.stringify(event);assert.equal(guard(event as any),true);assert.equal(event.details,details);assert.equal(JSON.stringify(event),before);for(const other of ['custom','wrong',...guards.map(([n])=>n).filter(n=>n!==name)])assert.equal(guard({...event,toolName:other} as any),false);
});}
await check('tool-call discriminator handles built-ins and generic custom names without rewriting input',()=>{
 for(const name of [...guards.map(([name])=>name),'custom_tool']) {const input={nested:{unchanged:true}};const event={type:'tool_call',toolName:name,toolCallId:'id',input};assert.equal(source.isToolCallEventType(name as any,event as any),true);assert.equal(source.isToolCallEventType('not-the-tool',event as any),false);assert.equal(event.input,input);}
});
await check('type guards are not structural runtime validators and do not authorize calls',()=>{assert.equal(source.isReadToolResult({toolName:'read'} as any),true);assert.equal(source.isToolCallEventType('bash',{toolName:'bash',input:'malformed'} as any),true);assert.equal(source.isBashToolResult({toolName:'BASH'} as any),false);});
console.log(JSON.stringify({item:'ZS1-022',source_path:path,source_sha256:hash,execution:'actual unchanged source module imported by Bun; no mocks; no TS typechecker claim',tests:records.length,records},null,2));
