# ZS1-052 — packages/coding-agent/src/core/extensions

Worker candidate: [_], provisional. 022/023 are independently written candidates, not accepted [x]; therefore this integration report does not pass G-DIR acceptance yet. Source subset contains only types.ts and runner.ts. Other direct files below were fully read as context and are not promoted to extra final per-file artifacts. No direct subdirectories exist.

## Direct inventory

- `index.ts`: 4204 B / 193 lines, `3502526cb694e66e79b729a72956dd8be4be4556c8c60c3a0b534ac3bf7ad1ce`; context-only direct dependency.
- `loader.ts`: 25877 B / 809 lines, `c96284a217cd4e2eee8d7335a7c25b106135968c716ce39834b4714f5ff8f771`; context-only direct dependency.
- `runner.ts`: 39774 B / 1286 lines, `6d5101ab0551c2ddd904a8089cc221b3c448fcfe36c27e36da02cdacc869c084`; selected candidate file.
- `types.ts`: 63623 B / 1797 lines, `96e20f8038027f0b0172f311b6b9d9ddf42123b2f5b2a018f533af026fd3371e`; selected candidate file.
- `wrapper.ts`: 1832 B / 45 lines, `c89397e268ccf27aa465fa1307fdbe324a3457966803e3fc6ec4d982ae2d379d`; context-only direct dependency.

## Verified calls, state and errors

index.ts is a pure barrel of loader/runner/types/wrapper exports (fully read). loader.ts (809 lines, read 1–300/301–580/581–809) uses jiti with virtual bundles or aliases, checks factory exports and caches by cwd+generation. Runtime begins with throwing action stubs, guarded API methods, idempotent invalidation and tracked event-bus unsubscriptions. Per-extension load stages flag defaults/provider changes, commits after factory success and discards subscriptions on failure. Runtime registration is immediate after bind. Individual load errors collect while later paths continue. Discovery scans direct TS/JS or one-level index/package manifest entries, then project→global→explicit paths with resolved-path deduplication. No recursion beyond one level; source symlinks are followed for candidate resolution. This loading model is context only, not a target requirement to embed jiti.

runner.ts consumes loaded handler maps/tools and binds host actions; wrapper.ts fully read (43 lines) adapts registered tools to guarded current context, compares active tool lists before/after execution and reports additions only when no previous tool was removed. Interception itself belongs to AgentSession/agent-core, not wrapper. Context and result transformations are serial; tool-call block wins and exceptions propagate, other emitters generally catch and notify. Loader invalidation tears down bus subscriptions; runner context checks prevent captured old APIs after session replacement. No evidence of a subprocess kill/reap guarantee exists in this source directory.

## Target integration

115 will negotiate a subprocess manifest, serialize typed hook events, bound request/result/time, revoke a host-owned session-generation lease and join/reap all owned work. Tool dispatch must use existing schema/path/approval/policy owners after rewrite. Canonical native provider history remains immutable. Failed reload stages an entire replacement before publication; old capability revocation is only after success. Actual positive/negative/cancel/restart validators remain the implementation item's responsibility. Directory review never accepts parent core or unselected siblings.

## Candidate validation follow-up

115 actual owner candidate evidence is in `Docs/quality/stage1/ZS1-115/worker-hooks`: real HTTP and production JSONL exercise input chaining, typed results, lifecycle, schema/path/approval/policy revalidation, bad replies, kill/reap cancellation and new-process lease identity. `extensions-input-event.test.ts` was additionally read completely (125 lines): source continue/transform/handled, image preservation/replacement, chaining, source/streaming behavior and exception isolation. It was not executed. Target intentionally supports continue/transform text only; no handled/images or transcript replacement API. Input/context failure aborts that admission/request without publishing partial output; lifecycle/after-result failures keep owner state. The directory remains provisional until main accepts its independent child file reports.

# ZS1-052 独立现状补充 [_]

Authority 3.1.18，requirement_digest `cb96a3db9b57ea0d9d3ad43f0be954129aabf69bc5d438210a14b674a4a8af85`。按主控明确要求，在055→059→062依次独立冻结后执行本补充。旧052报告4209B、SHA `1fab8fd0dc7b1fc91db8277eeb2d84d9643bc75340ec0d2284842d486d2d771f`仍原样位于extension115-ready/reports；prior052-report.md保存相同副本。当前交付目录报告只在旧内容后追加本补充，不回写旧包。旧报告中的未来时态和“未执行source test”属于历史时点，不能当作当前状态。022/023及052主控master receipt仍缺失，provisional不变，没有继承或新增接受标记。

## 子集、原报告与新增证据的区分

冻结子集仅types.ts（022，63623B/1797行，SHA96e20f8038027f0b0172f311b6b9d9ddf42123b2f5b2a018f533af026fd3371e）和runner.ts（023，39774B/1286行，SHA6d5101ab0551c2ddd904a8089cc221b3c448fcfe36c27e36da02cdacc869c084）。直属共5文件、0目录；index.ts4204B/193行、loader.ts25877B/809行、wrapper.ts1832B/45行全部context-only。旧正文一次写wrapper为43行是笔误，旧inventory45行正确；本补充不通过改这个数字新增覆盖。inventory.json逐个scope/hash；没有未申报递归目录。

022后来真实源码测试12场景已实际调用defineTool与全部运行时判别函数：defineTool原对象/handler不变，guard只按toolName判断，畸形对象也可能匹配，均不是schema验证或授权。023后来真实Runner测试20场景覆盖输入/上下文/工具/生命周期、错误分类、guarded context、注册分派及UI提示深度；唯一mock import为theme常量。完整两份原报告及原probe/日志/收据在original-evidence。023的较早18场景日志保留，不与最后20场景相加；没有把Bun擦除类型当tsc，未跑完整upstream/UI。

本轮新增9个组合场景调用实际types.defineTool、Runner和context-only wrapper/tool-definition-wrapper。handler、runtime/actions/model/session输入是显式fixture，唯一模块mock仍是theme；没有mock上述被验证实现。不是AgentSession、loader、jiti或事件总线真实运行。source-combination.log SHA `776aac850c297f902877203e000b133e40ba43129f7f57fd150808923f0a31c4`，9/9通过。

## 目录实际连接

index是loader/runner/types/wrapper导出barrel；type-only导出不运行接口。loader为每个扩展构造handlers/tools等Map，以jiti加载factory（源码/打包/Node发行方式选择不同alias），缓存受cwd+generation控制。factory执行阶段暂存flag默认和provider变更，成功后commit；失败discard本次subscriptions/pending。createExtensionRuntime开始为抛错action stubs，Runner.bindCore注入真实actions并刷新provider队列。API通过runtime.assertActive拒绝已失效作用域。目录发现按project→global→显式路径，resolved-path去重，单层TS/JS/index/manifest入口；source允许部分符号链接候选，不能直接复用为目标的路径安全规则。本轮重读上述连接代码；旧报告已有loader全文件阅读。本轮没有执行loader的模块缓存/失败回滚/订阅清理，故这些仍只是context-only源码观察。

Runner按加载的扩展顺序、每个handler注册顺序串行执行。types为参数/结果约定，Runner实际决定input/context一般catch继续、tool_call抛错传播/block短路、tool_result合并且隔离单个异常。wrapRegisteredTool只创建当前guarded context、调用真实definition.execute、前后比较active tools；它不发tool_call/tool_result。读取AgentSession._installAgentToolHooks确认拦截由Agent.beforeToolCall/afterToolCall调用Runner，回调执行时读取当前_extensionRunner；reload可替换runner。外部AgentSession及tool-definition-wrapper仅连接上下文，不扩冻结文件集合，也没有在本次测试中执行完整AgentSession。

## 九个真实组合结果与状态边界

| 场景 | 实际结果 | 责任解释 |
| --- | --- | --- |
| before→defineTool/wrapper→after | before把string参数改成123，execute实际收到123；更新回调执行；新增tool被标注；after details合并 | 源hook后无schema复验；fixture显式串起宿主调用顺序，不假称wrapper自动拦截 |
| 只执行wrapper | before/after计数均0 | 拦截责任在宿主/AgentSession连接 |
| preabort且tool忽略signal | signal同一对象、已aborted，execute仍运行并返回 | wrapper只传信号，不强制终止 |
| cooperative preabort | tool调用throwIfAborted，执行副作用前抛错，wrapper传播 | 合作式取消是tool实现责任 |
| 调用前invalidate | getActiveTools guard报错，execute不运行 | stale检查在实际入口生效 |
| await期间invalidate | tool恢复后已执行一次副作用，wrapper读取activeAfter时拒绝结果；捕获ctx属性也抛stale | 拒绝结果不等于撤销副作用，不证明进程kill/reap |
| 同时移除旧tool并新增tool | wrapper返回原result对象，不附加新增names | additions只有旧集合全部保留才发布 |
| before_tool异常→执行 | 显式await拦截时异常阻止execute | 需要宿主遵守拦截调用顺序 |
| shutdown异常→invalidate | 第一handler抛错，第二仍运行，记录错误；ctx仍可读直到显式invalidate | terminal事件不是自动回收；runtime invalidation只执行一次 |

这些9例与023旧20例部分语义重叠，不总计为41种覆盖。没有外部工具副作用，场景计数使用内存变量；不宣称OS进程、持久化失败、并发加载、消息总线退订异常或完整重载恢复已执行。源码ctx属性有guard，但in-process闭包、已开始的异步工作和引用并不会凭类型声明被撤销。

## 当前目标的实际映射与已执行证据范围

| 当前目标连接 | 本次源码确认 | 与Pi组合差异 |
| --- | --- | --- |
| extensions.rs ExtensionCatalog::load/register_with_lease | TOML API1/2、路径/manifest界限、有序目录、声明工具 | 原生可执行扩展，非jiti/JS closure；拒绝目录/manifest符号链接等独立规则 |
| extension_runtime.rs prepare/chain/input/context/before_tool/after_tool | HookKind是有限集合；请求/结果typed JSON，chain边界2s，hook64KiB | 无源UI/provider任意mutation/handled-images/transcript替换全兼容承诺 |
| core.rs prepare_extensions/configure_extensions/publish_extensions | idle、非worker前提；先candidate+registry；取消检查和journal写入后发布，旧runtime.close在替换时执行 | 失败准备保留旧集合，源factory阶段partial commit不能直接视为同等事务 |
| core.rs工具执行链 | 原policy/schema检查→before_tool→validate_hook_call复验→prepare_tool审批/策略执行；only Success进入after_tool | 不接受source已演示的number参数绕过；after不能把拒绝/失败变成功 |
| extension_runtime.rs process_request/exchange_frame | spawn前后取消/lease检查，request ID与capability完整匹配；Unix supervisor持有非阻塞stdin/stdout、期限/字节界限、OwnedChild回收 | 超出in-process signal转交；不依赖逃逸后代关闭pipe；非Unixfail-closed |
| close/Drop与ExtensionLease | close先revoke旧lease，再用私有单次closing lease通知，随后撤销；重复close不再执行 | 与source shutdown emit不invalidate的实测差异明确；能力不是可反序列化授予的authority |

当前target snapshot及SHA在inventory；core仅读取上述连接区段，不借snapshot文件大小声称全core复核。115原包与native fixture/pipe/轻量管道fixture修复包manifest/hash在target-evidence-references.json。历史17工具hook场景和12真实管道场景归属于对应115证据；后者timeout/cancel/revoke/unwind及setsid持有端点的测试结果不是本052新执行。主控已通知115夹具修复合入，报告依旧以冻结证据原source/时间边界为准，不把主控当前220总通过数搬来作本目录覆盖。主控接受/预算、非Unix、真正OS隔离、取消前已发生副作用可回滚均不由此报告证明。

## 门禁、原件保留、回滚

独立verifier校验5直属文件/0目录、selected和context源SHA、022/023manifest、原证据、旧052原件以及9场景执行收据；哈希校验不是行为测试。G-STAGE只读主仓按3.1.18运行，缺052master时保留exit1，机器结构不授予语义接受。补充冻结包单独前向apply/hash及reverse恢复验证。主仓尚无052报告，因此交付为新文件，内容含逐字节历史前缀及本补充；不改extension115-ready中的原件。回滚仅撤回新052报告/本次证据；不得递归删除022/023、改旧包或回滚已合入115产品代码。
