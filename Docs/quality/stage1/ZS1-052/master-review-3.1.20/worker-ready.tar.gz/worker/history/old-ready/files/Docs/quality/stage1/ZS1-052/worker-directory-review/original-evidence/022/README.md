# ZS1-022 source behavior supplement [_]

Authority 3.1.11 / cefbe4a1753cbaa07857ed2db5934aa5f1a778670d00cffa6ab87d7942a43713; 115 obligation unchanged. The frozen 115 package and its reports remain byte-identical.

`bun probe.ts` imports the actual unchanged source types.ts by absolute path and verifies SHA 96e20f8038027f0b0172f311b6b9d9ddf42123b2f5b2a018f533af026fd3371e. No mocked dependency is used: this module's imports are type-only. Twelve executable scenarios pass, covering every runtime-exported function: defineTool identity/handler execution/shared mutable state; absence of runtime validation; all eight tool-result discriminators across positive and wrong-name cases; built-in/custom tool-call discrimination without mutation; and malformed-shaped objects proving these predicates inspect names and do not authorize calls.

This is behavior execution, not an exported-symbol or schema count. The log lists assertions by observed behavior; failures throw and make the command nonzero. It does not claim TypeScript static typechecking, upstream Vitest execution, or runtime behavior for erased interfaces. Input/context/session/tool interface consumption belongs to the independently executed ZS1-023 supplement next in order.

Mapping: source type predicates and defineTool provide shape convenience, not runtime validation. Target 115 deliberately adds typed JSON result decoding and schema/path/approval checks; source's malformed-shaped positive predicate is a demonstrated reason those gates cannot rely on type guards. Wider UI/provider interfaces remain explicitly outside the native subprocess API. Master still reviews the complete 022 file report before acceptance. HOME/CODEX_HOME preserved; exact command/time/output SHA in source-types.json.
