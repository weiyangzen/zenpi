import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {mock} from 'bun:test';
const path='/Users/wangweiyang/GitHub/pi-mono/packages/coding-agent/src/core/extensions/runner.ts';
const hash=createHash('sha256').update(readFileSync(path)).digest('hex');assert.equal(hash,'6d5101ab0551c2ddd904a8089cc221b3c448fcfe36c27e36da02cdacc869c084');
// The only runtime module dependency is theme; UI rendering is not under test.
mock.module('/Users/wangweiyang/GitHub/pi-mono/packages/coding-agent/src/modes/interactive/theme/theme.ts',()=>({theme:{fixture:true}}));
const {ExtensionRunner,emitSessionShutdownEvent,emitProjectTrustEvent}=await import(path);
const records:any[]=[];async function check(name:string,run:()=>unknown){await run();records.push({name,status:'pass'});}
function extension(name:string,handlers:Record<string,any[]>={}){return {path:name,resolvedPath:name,sourceInfo:{path:name,source:'fixture'},handlers:new Map(Object.entries(handlers)),tools:new Map(),flags:new Map(),commands:new Map(),shortcuts:new Map(),messageRenderers:new Map(),entryRenderers:new Map()};}
function fixture(exts:any[]=[]){let invalidations=0;const runtime:any={flagValues:new Map(),pendingProviderRegistrations:[],pendingNativeProviderRegistrations:[],invalidate:()=>invalidations++};const registry:any={registerProvider:()=>{},unregisterProvider:()=>{}};const runner=new ExtensionRunner(exts,runtime,'/fixture',{},registry);return {runner,runtime,registry,invalidations:()=>invalidations};}
const actions:any={sendMessage:()=>{},sendUserMessage:()=>{},appendEntry:()=>{},setSessionName:()=>{},getSessionName:()=>undefined,setLabel:()=>{},getActiveTools:()=>['read'],getAllTools:()=>[],setActiveTools:()=>{},refreshTools:()=>{},getCommands:()=>[],setModel:async()=>true,getThinkingLevel:()=> 'high',setThinkingLevel:()=>{}};
const context:any={getModel:()=>({id:'model'}),getScopedModels:()=>[],isIdle:()=>true,isProjectTrusted:()=>true,getSignal:()=>undefined,abort:()=>{},hasPendingMessages:()=>false,shutdown:()=>{},getContextUsage:()=>undefined,compact:()=>{},getSystemPrompt:()=> 'base'};

const {defineTool}=await import('/Users/wangweiyang/GitHub/pi-mono/packages/coding-agent/src/core/extensions/types.ts');
const {wrapRegisteredTool}=await import('/Users/wangweiyang/GitHub/pi-mono/packages/coding-agent/src/core/extensions/wrapper.ts');
function bound(exts:any[]=[]){const f=fixture(exts);let active=['read'];f.runner.bindCore({...actions,getActiveTools:()=>active,setActiveTools:(a:any)=>{active=a;}},context);return {...f,setActive:(a:string[])=>{active=a;}};}
function tool(f:any,execute:any){const definition=defineTool({name:'sample',label:'sample',description:'fixture',parameters:{type:'object',properties:{path:{type:'string'}}},execute} as any);return wrapRegisteredTool({definition,sourceInfo:{path:'fixture'}} as any,f.runner);}
await check('actual types defineTool and runner hook mutation reach actual wrapper execute without revalidation, then result merge',async()=>{
 const order:string[]=[];let f:any;f=bound([extension('a',{tool_call:[(e:any)=>{order.push('before');e.input.path=123;}],tool_result:[()=>{order.push('after');return {details:{hooked:true}};}]})]);
 const t=tool(f,async(id:any,params:any,signal:any,update:any,ctx:any)=>{order.push('execute');assert.equal(params.path,123);assert.equal(ctx.cwd,'/fixture');update({content:[{type:'text',text:'partial'}]});f.setActive(['read','added']);return {content:[{type:'text',text:'ok'}],details:{hooked:false}};});
 const event:any={type:'tool_call',toolName:'sample',toolCallId:'one',input:{path:'safe'}};assert.equal(await f.runner.emitToolCall(event),undefined);
 const updates:any[]=[];const result=await t.execute('one',event.input,new AbortController().signal,(u:any)=>updates.push(u));assert.deepEqual(result.addedToolNames,['added']);assert.equal(updates.length,1);
 const after=await f.runner.emitToolResult({...event,type:'tool_result',content:result.content,details:result.details,isError:false});assert.deepEqual(after.details,{hooked:true});assert.deepEqual(order,['before','execute','after']);
});
await check('wrapper alone does not call before or after interception handlers',async()=>{
 let calls=0;const f=bound([extension('a',{tool_call:[()=>calls++],tool_result:[()=>calls++]})]);const t=tool(f,async()=>({content:[],details:{}}));await t.execute('id',{},undefined,undefined);assert.equal(calls,0);
});
await check('preaborted signal is forwarded; signal-ignoring tool still executes',async()=>{
 const f=bound();const c=new AbortController();c.abort();let executed=0;const t=tool(f,async(_id:any,_p:any,signal:any)=>{assert.equal(signal,c.signal);assert.equal(signal.aborted,true);executed++;return {content:[],details:{}};});await t.execute('id',{},c.signal,undefined);assert.equal(executed,1);
});
await check('cooperative preabort rejects from actual tool and wrapper propagates error',async()=>{
 const f=bound();const c=new AbortController();c.abort(new Error('cooperative abort'));let effect=false;const t=tool(f,async(_id:any,_p:any,signal:any)=>{signal.throwIfAborted();effect=true;return {content:[],details:{}};});await assert.rejects(t.execute('id',{},c.signal,undefined),/cooperative abort/);assert.equal(effect,false);
});
await check('invalidation before wrapped call blocks execution through active tool guard',async()=>{
 const f=bound();let executed=false;const t=tool(f,async()=>{executed=true;return {content:[],details:{}};});f.runner.invalidate('stale before');await assert.rejects(t.execute('id',{},undefined,undefined),/stale before/);assert.equal(executed,false);
});
await check('invalidation while tool awaits rejects post-execution result but cannot undo already run side effect',async()=>{
 const f=bound();let release!:()=>void;const gate=new Promise<void>(r=>release=r);let entered!:()=>void;const started=new Promise<void>(r=>entered=r);let captured:any;let effect=0;
 const t=tool(f,async(_id:any,_p:any,_s:any,_u:any,ctx:any)=>{captured=ctx;entered();await gate;effect++;return {content:[],details:{}};});const pending=t.execute('id',{},undefined,undefined);await started;f.runner.invalidate('stale during');release();await assert.rejects(pending,/stale during/);assert.equal(effect,1);assert.throws(()=>captured.cwd,/stale during/);
});
await check('tool removal suppresses added-tool annotation even when a new tool appears',async()=>{
 const f=bound();const result={content:[],details:{}};const t=tool(f,async()=>{f.setActive(['new']);return result;});assert.strictEqual(await t.execute('id',{},undefined,undefined),result);
});
await check('before-tool exception prevents execution only when host awaits interception',async()=>{
 let executed=false;const f=bound([extension('a',{tool_call:[()=>{throw Error('hook deny');}]})]);const t=tool(f,async()=>{executed=true;return {content:[],details:{}};});
 await assert.rejects((async()=>{await f.runner.emitToolCall({type:'tool_call',toolName:'sample',toolCallId:'id',input:{}});return t.execute('id',{},undefined,undefined);})(),/hook deny/);assert.equal(executed,false);
});
await check('shutdown emission isolates handler error but does not itself invalidate runner; explicit invalidation remains required',async()=>{
 const order:string[]=[];const f=bound([extension('a',{session_shutdown:[()=>{order.push('first');throw Error('shutdown error');}]}),extension('b',{session_shutdown:[()=>order.push('second')]})]);const errors:any[]=[];f.runner.onError((e:any)=>errors.push(e));const ctx=f.runner.createContext();await emitSessionShutdownEvent(f.runner,{type:'session_shutdown',reason:'quit'});assert.deepEqual(order,['first','second']);assert.equal(errors.length,1);assert.equal(ctx.cwd,'/fixture');assert.equal(f.invalidations(),0);f.runner.invalidate('closed');assert.throws(()=>ctx.cwd,/closed/);assert.equal(f.invalidations(),1);
});
assert.equal(createHash('sha256').update(readFileSync(path)).digest('hex'),hash);
console.log(JSON.stringify({item:'ZS1-052',tests:records.length,records,execution:'actual unchanged types/runner/wrapper/tool-definition-wrapper; only theme import mocked; explicit host/runtime/definition callback fixtures; no AgentSession or loader execution'},null,2));
