# ZS1-052 extensions 目录独立补充

先读 report.md 最后的3.1.20补充。正式直接子项只限已接受022 types和023 runner；index/loader/wrapper为context-only，零子目录。

- create-report.patch：主库canonical absent时创建唯一报告。
- append-report.patch：接收方恰有旧12,934B前缀时使用；与create互斥，输出相同。
- history/old-ready：旧052完整包，历史4,209B和12,934B前缀原样保留，不执行旧probe。
- children/：当前两个已接受canonical、master receipt及完整publication。
- directory-listing.json / context-index.json / drift.json：目录闭包、23个精确上下文与版本漂移。
- gstage-final.*：实际G-STAGE结构通过、因缺052 master receipt退出1；首次辅助模块缺失也保留。
- verify.py：离线完整性、child引用、历史前缀、精确正反补丁验证；不运行产品或receipt命令。

本轮Cargo/Node/PTY/HTTP/network/product/FIFO全部0；不写主库/Pi/authority/claims/status/旧ready。目录语义仍需主控独立接受，子项[x]不自动接受052。
