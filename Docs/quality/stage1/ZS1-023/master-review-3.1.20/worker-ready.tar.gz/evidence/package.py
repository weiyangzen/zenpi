from pathlib import Path
import json,hashlib,difflib,shutil
W=Path(__file__).resolve().parent;R=W.parent/'zs1-023-ready';assert not R.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
g=json.loads((W/'gfile.json').read_text());rel=g['report_path'];report=(W/'report.md').read_bytes();assert sha(report)==g['report_sha256']
for root in [W.parent.parent,Path('/Users/wangweiyang/GitHub/zenpi')]:assert not (root/rel).exists()
p=R/rel;p.parent.mkdir(parents=True);p.write_bytes(report)
(R/'candidate.patch').write_text(''.join(difflib.unified_diff([],report.decode().splitlines(True),fromfile='/dev/null',tofile='b/'+rel)))
for file in W.rglob('*'):
 if not file.is_file() or file.name in ['report.md','verify.py']:continue
 dest=R/'evidence'/file.relative_to(W);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(file,dest)
shutil.copyfile(W/'verify.py',R/'verify.py')
checked=[]
for name,digest in {
 'zs1-018-ready':'e7047e64ee2a3a2b67cfdeab755ba546272a4e6aa648e0293695fc461568e60a',
 'zs1-028-ready':'949e09c6a9eb57b22155646d2abb02586169b29194873b5d7a168d827d84b914',
 'zs1-021-ready':'7b99f22d8fac82d093b60d1404796161e68053becbe9a112329529836259da46',
 'zs1-125-render-tail-ready':'822b201ac8e8f3f5bb4172599ac42c807addbba69c13362d24c26576d36f9581',
 'zs1-125-tail-wiring-ready':'492042afb6a11f28fb6527a4b709e800bd0d3fff247798e229c3637eeae90c4d',
}.items():
 root=W.parent/name;mp=root/'manifest.json';assert sha(mp.read_bytes())==digest;items=json.loads(mp.read_text())['artifacts']
 for path,rec in items.items():
  b=(root/path).read_bytes();assert sha(b)==rec['sha256'] and len(b)==rec['bytes']
 checked.append({'ready':str(root),'manifest_sha256':digest,'artifacts':len(items),'all_exact':True})
(R/'evidence/prior-ready-preservation.json').write_text(json.dumps(checked,indent=2)+'\n')
(R/'README.md').write_text(f"""# ZS1-023 single-file ready

provisional；learn_mode: understand。唯一源runner.ts完整1286行/39774字节，SHA256 {g['source_sha256']}；标准报告 {rel}，{len(report)}字节，SHA256 {g['report_sha256']}。

先检索自身既有完整报告，master/worker标准路径before均absent；candidate.patch仅新增该报告。六段源全文阅读，47个方法/getter签名辅助核对无缺名，顶层类型/函数与noOp UI另有完整说明；符号核对不替代语义验收。19个有界上下文记录完整source hash、行/字节和片段hash，G-FILE时当前输入均无漂移，不计目标整文件验收。

报告覆盖全部dispatch合并/短路/异常、tool/flags/shortcut/command aliases/renderers查询、provider注册、trust、UI prompt计数、ctx闭包与stale撤销。关键差异：tool_call异常直接传播，error listener自身可破坏其它事件隔离；headers仅原地mutation；撤销是stale字符串guard，不是统一generation/dispatch中止。目标lease、typed hooks、候选发布与skills边界仅按精确片段映射。

G-FILE字节结构辅助通过；G-STAGE实际exit1、structural.ok=true，唯一错误缺ZS1-023.master.json，semantic/manual pending。未制造master receipt。读取中的两个错误可选文件名与一次非正式模板输出截断记录在read-observations/command-observations，未损害源六段全文覆盖。Node/Cargo/PTY/HTTP/网络及产品测试运行均0；只读测试不作为通过回执，echo_agent片段不作为生产G-HOST证据。

018/021/028及两份125 ready的240个artifacts和5个manifest精确保留。主库、源库、产品、状态、旧ready、022报告、052目录和调度器无写入，无新任务/subagent。verify.py只验证本包hash/范围及临时git正反check/apply/精确字节/sentinel；实际replay结果在本包外zs1-023-work/offline-verification.json。完成后停止，待master独立复核。
""")
m={'item':'ZS1-023','source_id':'SRC-0908','scope':'one complete source-file understand report; bounded target context only','complete':False,'master_accepted':False,'product_changes':False,'report_path':rel,'report_sha256':g['report_sha256'],'source_sha256':g['source_sha256'],'source_bytes':39774,'source_lines':1286,'before_master':'absent','before_worker':'absent','source_tests_run':0,'target_tests_run':0,'cargo_runs':0,'pty_runs':0,'http_runs':0,'network_runs':0,'gstage_exit_code':1,'gstage_structural_ok':True,'master_receipt':'missing; not fabricated'}
m['artifacts']={str(p.relative_to(R)):{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(R.rglob('*')) if p.is_file()}
(R/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
print(json.dumps({'ready':str(R),'artifacts':len(m['artifacts']),'manifest_sha256':sha((R/'manifest.json').read_bytes()),'report_sha256':g['report_sha256'],'patch_sha256':sha((R/'candidate.patch').read_bytes()),'README_sha256':sha((R/'README.md').read_bytes())},indent=2))
