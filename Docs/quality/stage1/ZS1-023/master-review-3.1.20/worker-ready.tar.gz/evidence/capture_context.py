from pathlib import Path
import json,hashlib,datetime
W=Path(__file__).resolve().parent
M=Path('/Users/wangweiyang/GitHub/zenpi');S=Path('/Users/wangweiyang/GitHub/pi-mono')
specs=[
 ('T1',M,'src/extension_runtime.rs',35,90),('T2',M,'src/extension_runtime.rs',203,344),('T3',M,'src/extension_runtime.rs',345,426),
 ('T4',M,'src/core.rs',2104,2210),('T5',M,'src/extensions.rs',269,311),('T6',M,'src/skills.rs',281,317),
 ('T7',M,'tests/stage1_extension_hooks.rs',515,542),('T8',M,'tests/stage1_extension_hooks.rs',936,953),
 ('C1',S,'packages/coding-agent/src/core/extensions/loader.ts',178,235),
 ('C2',S,'packages/coding-agent/src/core/extensions/types.ts',1125,1188),
 ('C3',S,'packages/coding-agent/src/core/agent-session.ts',482,536),
 ('C4',S,'packages/coding-agent/src/core/agent-session.ts',2841,2868),
 ('S1',S,'packages/coding-agent/test/extensions-runner.test.ts',122,158),
 ('S2',S,'packages/coding-agent/test/extensions-runner.test.ts',236,281),
 ('S3',S,'packages/coding-agent/test/extensions-runner.test.ts',419,454),
 ('S4',S,'packages/coding-agent/test/extensions-runner.test.ts',502,527),
 ('S5',S,'packages/coding-agent/test/extensions-runner.test.ts',763,804),
 ('S6',S,'packages/coding-agent/test/extensions-runner.test.ts',854,896),
 ('S7',S,'packages/coding-agent/test/extensions-runner.test.ts',1012,1060),
]
refs=[]
for ident,root,rel,start,end in specs:
 p=root/rel;b=p.read_bytes();lines=b.splitlines(keepends=True);assert end<=len(lines)
 lo=sum(map(len,lines[:start-1]));hi=sum(map(len,lines[:end]));part=b[lo:hi]
 name='excerpts/'+ident+'-'+p.name+'.txt';q=W/name;q.parent.mkdir(exist_ok=True);q.write_bytes(part)
 refs.append(dict(id=ident,source=str(p),source_sha256=hashlib.sha256(b).hexdigest(),source_bytes=len(b),start_line=start,end_line=end,start_byte=lo,end_byte=hi,excerpt=name,bytes=len(part),sha256=hashlib.sha256(part).hexdigest(),scope='bounded context only; no whole-file acceptance'))
(W/'context-references.json').write_text(json.dumps({'captured_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'references':refs},indent=2)+'\n')
print(json.dumps(refs,indent=2))
