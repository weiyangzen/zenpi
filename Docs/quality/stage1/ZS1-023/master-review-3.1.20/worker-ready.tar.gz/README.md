# ZS1-023 single-file ready

provisional；learn_mode: understand。唯一源runner.ts完整1286行/39774字节，SHA256 6d5101ab0551c2ddd904a8089cc221b3c448fcfe36c27e36da02cdacc869c084；标准报告 Docs/learn/stage1_pi_mono/files/packages/coding-agent/src/core/extensions/runner.ts_learn.md，35549字节，SHA256 4b6aa687510ec08d24a8c4cb9ccea83150210accb9db66ebd7d8076860794e57。

先检索自身既有完整报告，master/worker标准路径before均absent；candidate.patch仅新增该报告。六段源全文阅读，47个方法/getter签名辅助核对无缺名，顶层类型/函数与noOp UI另有完整说明；符号核对不替代语义验收。19个有界上下文记录完整source hash、行/字节和片段hash，G-FILE时当前输入均无漂移，不计目标整文件验收。

报告覆盖全部dispatch合并/短路/异常、tool/flags/shortcut/command aliases/renderers查询、provider注册、trust、UI prompt计数、ctx闭包与stale撤销。关键差异：tool_call异常直接传播，error listener自身可破坏其它事件隔离；headers仅原地mutation；撤销是stale字符串guard，不是统一generation/dispatch中止。目标lease、typed hooks、候选发布与skills边界仅按精确片段映射。

G-FILE字节结构辅助通过；G-STAGE实际exit1、structural.ok=true，唯一错误缺ZS1-023.master.json，semantic/manual pending。未制造master receipt。读取中的两个错误可选文件名与一次非正式模板输出截断记录在read-observations/command-observations，未损害源六段全文覆盖。Node/Cargo/PTY/HTTP/网络及产品测试运行均0；只读测试不作为通过回执，echo_agent片段不作为生产G-HOST证据。

018/021/028及两份125 ready的240个artifacts和5个manifest精确保留。主库、源库、产品、状态、旧ready、022报告、052目录和调度器无写入，无新任务/subagent。verify.py只验证本包hash/范围及临时git正反check/apply/精确字节/sentinel；实际replay结果在本包外zs1-023-work/offline-verification.json。完成后停止，待master独立复核。
