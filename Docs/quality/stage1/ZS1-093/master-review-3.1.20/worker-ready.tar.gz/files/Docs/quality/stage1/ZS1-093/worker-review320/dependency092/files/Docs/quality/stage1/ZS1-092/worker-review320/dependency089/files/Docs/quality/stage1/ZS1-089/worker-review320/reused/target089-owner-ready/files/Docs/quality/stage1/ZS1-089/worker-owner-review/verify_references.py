from pathlib import Path
import hashlib,json,re
R=Path(__file__).resolve().parents[5];E=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((E/'input-manifest.json').read_text());refs=json.loads((E/'references.json').read_text())
for r in refs:
 d=Path(r['path']).read_bytes();assert len(d)==r['bytes'] and sha(d)==r['sha256']
for k in ['current','original_frozen']:
 r=m[k];d=(R/r['path']).read_bytes();assert len(d)==r['bytes'] and len(d.splitlines())==r['lines'] and sha(d)==r['sha256']
d=(E/'current-ci.yml').read_bytes();assert d==(E/'original-ci.yml').read_bytes()==Path(m['main_source_at_capture']).read_bytes()==(R/'.ops/target089-base/current-ci.yml').read_bytes();c=m['ordered_read_chunks'][0];assert c['byte_start']==0 and c['byte_end']==len(d) and c['sha256']==sha(d)
steps=json.loads((E/'step-index.json').read_text());assert len(steps)==16;assert all(d.decode().splitlines()[r['line']-1].strip()=='- name: '+r['name'] for r in steps)
context=json.loads((E/'script-context.json').read_text())
for r in context:
 p=Path(r['path']);assert p.is_file()
 # These excerpts are captured dependency context, not siblingacceptance.
 assert all(e['first_line']<=e['last_line'] for e in r['excerpts'])
r=json.loads((E/'archive-gate-counterexample.json').read_text());log=Path(r['output']).read_bytes();assert r['exit_code']==0 and sha(log)==r['sha256'] and len(log)==r['bytes'] and r['HOME_preserved'] and r['CODEX_HOME_preserved']
rows=[json.loads(s) for s in log.decode().splitlines() if s.startswith('{"case"')];assert len(rows)==3 and [x['gate_exit_code'] for x in rows]==[0,1,0] and rows[2]['independent_tar_exit_code']!=0
report=(R/m['report']).read_text();assert m['current']['sha256'] in report and r['sha256'] in report
print(json.dumps({'status':'pass','full_source_lines':77,'source_bytes':len(d),'baseline_equals_current':True,'ordered_steps':len(steps),'script_entry_contexts':len(context),'references':len(refs),'actual_local_gate_cases':3,'hosted_CI_runs':0,'workflow_modified':False,'meaning':'Integrity+localcounterexample, notCI/masteracceptance'},indent=2))
