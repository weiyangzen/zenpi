#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct SemanticCheckpoint {
    pub schema_version: u16,
    pub source: CheckpointSource,
    /// Exclusive end of the summarized prefix; always a whole-turn boundary.
    pub source_end: usize,
    pub covered_sha256: String,
    pub retained_ids: Vec<String>,
    pub read_files: Vec<String>,
    pub modified_files: Vec<String>,
    pub unresolved_calls: Vec<UnresolvedContextCall>,
    pub summary: String,
    pub summary_sha256: String,
    pub summary_provider: String,
    pub summary_model: String,
    pub summary_usage: crate::backend::Usage,
}

/// Immutable preparation. Finalization repeats validation against the journal,
/// so a request that raced a new turn cannot publish a stale checkpoint.
#[derive(Debug, Clone)]
pub struct SemanticCompactionPlan {
    checkpoint: SemanticCheckpoint,
}

fn context_digest(turns: &[Turn]) -> Result<String, ContextError> {
    let bytes = serde_json::to_vec(turns).map_err(|e| ContextError::Encoding(e.to_string()))?;
    Ok(format!("{:x}", Sha256::digest(bytes)))
}

fn valid_context_id(value: &str) -> bool {
    !value.trim().is_empty()
        && value.len() <= crate::protocol::MAX_ID_BYTES
        && !value.chars().any(char::is_control)
}

fn failed_context_assistant(turn: &Turn) -> bool {
    if turn.role != TurnRole::Assistant {
        return false;
    }
    let Some(metadata) = &turn.metadata else {
        return false;
    };
    ["stop_reason", "stopReason", "finish_reason"]
        .iter()
        .any(|key| {
            matches!(
                metadata[*key].as_str(),
                Some("error" | "aborted" | "deferred" | "cancelled")
            )
        })
        || metadata["annotations"]
            .as_array()
            .is_some_and(|annotations| {
                annotations.iter().any(|a| {
                    matches!(
                        a["finish_reason"].as_str(),
                        Some("error" | "aborted" | "deferred" | "cancelled")
                    )
                })
            })
}

/// Validate a full ancestry and a proposed cut without looking at model text.
/// Calls are keyed by user-turn ID as providers may reuse call IDs in later turns.
fn checkpoint_skeleton(
    turns: &[Turn],
    session_id: &str,
    branch_id: &str,
    end: usize,
) -> Result<SemanticCheckpoint, ContextError> {
    use std::collections::{BTreeMap, BTreeSet};
    if !valid_context_id(session_id)
        || !valid_context_id(branch_id)
        || end == 0
        || end >= turns.len()
        || !whole_turn_start(&turns[end])
        || turns[..end].iter().any(has_opaque_provider_state)
        || !turns[..end]
            .iter()
            .any(|turn| turn.role != TurnRole::System)
    {
        return Err(ContextError::InvalidCheckpoint);
    }
    let mut ids = BTreeSet::new();
    let mut calls = BTreeMap::<(String, String), (usize, String, Option<usize>, bool)>::new();
    let mut paths = BTreeMap::new();
    let mut reads = BTreeSet::new();
    let mut writes = BTreeSet::new();
    for (index, turn) in turns.iter().enumerate() {
        if !valid_context_id(&turn.id)
            || ids.contains(&turn.id)
            || turn.parent_id.as_ref().is_some_and(|id| !ids.contains(id))
        {
            return Err(ContextError::InvalidCheckpoint);
        }
        ids.insert(turn.id.clone());
        let Some(meta) = turn.metadata.as_ref() else {
            if turn.role == TurnRole::Tool {
                return Err(ContextError::InvalidCheckpoint);
            }
            continue;
        };
        if let Some(raw) = meta.get("tool_calls") {
            if turn.role != TurnRole::Assistant || failed_context_assistant(turn) {
                return Err(ContextError::InvalidCheckpoint);
            }
            let parent = turn
                .parent_id
                .as_ref()
                .ok_or(ContextError::InvalidCheckpoint)?;
            for call in raw.as_array().ok_or(ContextError::InvalidCheckpoint)? {
                let id = call["id"]
                    .as_str()
                    .filter(|s| valid_context_id(s))
                    .ok_or(ContextError::InvalidCheckpoint)?;
                let name = call["name"]
                    .as_str()
                    .filter(|s| valid_context_id(s))
                    .ok_or(ContextError::InvalidCheckpoint)?;
                if !call["arguments"].is_object()
                    || calls
                        .insert(
                            (parent.clone(), id.into()),
                            (index, name.into(), None, false),
                        )
                        .is_some()
                {
                    return Err(ContextError::InvalidCheckpoint);
                }
                if let Some(path) = call["arguments"]["path"].as_str() {
                    paths.insert((parent.clone(), id.to_owned()), path.to_owned());
                }
            }
        }
        if turn.role == TurnRole::Tool {
            let parent = turn
                .parent_id
                .as_ref()
                .ok_or(ContextError::InvalidCheckpoint)?;
            let id = meta["tool_call_id"]
                .as_str()
                .ok_or(ContextError::InvalidCheckpoint)?;
            let call = calls
                .get_mut(&(parent.clone(), id.into()))
                .ok_or(ContextError::InvalidCheckpoint)?;
            if call.2.is_some() || meta["tool_name"].as_str().is_some_and(|n| n != call.1) {
                return Err(ContextError::InvalidCheckpoint);
            }
            call.2 = Some(index);
            call.3 = meta["outcome"] == "unknown_outcome";
            if index < end
                && meta["outcome"] == "succeeded"
                && let Some(path) = paths.get(&(parent.clone(), id.to_owned()))
            {
                if matches!(
                    call.1.as_str(),
                    "read_file" | "list_directory" | "search_text"
                ) {
                    reads.insert(path.clone());
                }
                if matches!(call.1.as_str(), "write_file" | "edit_file") {
                    writes.insert(path.clone());
                }
            }
        }
    }
    let mut unresolved = Vec::new();
    for ((turn_id, call_id), (start, tool, result, unknown)) in calls {
        if start < end && (result.is_none_or(|index| index >= end) || unknown) {
            return Err(ContextError::InvalidCheckpoint);
        }
        if result.is_none() || unknown {
            unresolved.push(UnresolvedContextCall {
                turn_id,
                call_id,
                tool,
            });
        }
    }
    Ok(SemanticCheckpoint {
        schema_version: SEMANTIC_CHECKPOINT_VERSION,
        source: CheckpointSource {
            session_id: session_id.into(),
            branch_id: branch_id.into(),
            tip_id: turns.last().unwrap().id.clone(),
            records: turns.len(),
            sha256: context_digest(turns)?,
        },
        source_end: end,
        covered_sha256: context_digest(&turns[..end])?,
        retained_ids: turns[end..].iter().map(|t| t.id.clone()).collect(),
        read_files: reads.into_iter().collect(),
        modified_files: writes.into_iter().collect(),
        unresolved_calls: unresolved,
        summary: String::new(),
        summary_sha256: String::new(),
        summary_provider: String::new(),
        summary_model: String::new(),
        summary_usage: crate::backend::Usage::default(),
    })
}

pub fn prepare_semantic_compaction(
    turns: &[Turn],
    session_id: &str,
    branch_id: &str,
    keep_recent_tokens: u64,
    cancelled: &dyn Fn() -> bool,
) -> Result<SemanticCompactionPlan, ContextError> {
    if cancelled() {
        return Err(ContextError::Cancelled);
    }
    // Retain at least the latest user turn, expanding backwards to the desired
    // tail size. Never split an assistant call from any of its tool results.
    for end in (1..turns.len())
        .rev()
        .filter(|i| whole_turn_start(&turns[*i]))
    {
        if cancelled() {
            return Err(ContextError::Cancelled);
        }
        if estimate_tokens(&turns[end..]).input_tokens >= keep_recent_tokens
            && let Ok(checkpoint) = checkpoint_skeleton(turns, session_id, branch_id, end)
        {
            return Ok(SemanticCompactionPlan { checkpoint });
        }
    }
    Err(ContextError::InvalidCheckpoint)
}

impl SemanticCompactionPlan {
    pub fn source_end(&self) -> usize {
        self.checkpoint.source_end
    }
    pub fn source(&self) -> &CheckpointSource {
        &self.checkpoint.source
    }

    /// The host supplies actual provider usage; generating the summary belongs
    /// to the same budget/cancellation owner as other provider requests.
    // Preserve the public 103 API: source, provider usage, budget and cancellation
    // are deliberately independent owner inputs, not an unchecked option bag.
    #[allow(clippy::too_many_arguments)]
    pub fn finalize(
        &self,
        turns: &[Turn],
        summary: String,
        provider: String,
        model: String,
        usage: crate::backend::Usage,
        budget: ContextBudget,
        cancelled: &dyn Fn() -> bool,
    ) -> Result<SemanticCheckpoint, ContextError> {
        if cancelled() {
            return Err(ContextError::Cancelled);
        }
        let mut checkpoint = checkpoint_skeleton(
            turns,
            &self.checkpoint.source.session_id,
            &self.checkpoint.source.branch_id,
            self.checkpoint.source_end,
        )?;
        if checkpoint != self.checkpoint {
            return Err(ContextError::InvalidCheckpoint);
        }
        checkpoint.summary_sha256 = format!("{:x}", Sha256::digest(summary.as_bytes()));
        checkpoint.summary = summary;
        checkpoint.summary_provider = provider;
        checkpoint.summary_model = model;
        checkpoint.summary_usage = usage;
        restore_semantic_checkpoint(
            turns,
            &checkpoint,
            &checkpoint.source.session_id,
            &checkpoint.source.branch_id,
            budget,
        )?;
        if cancelled() {
            return Err(ContextError::Cancelled);
        }
        Ok(checkpoint)
    }
}

/// Restore only the matching branch and immutable source prefix; additional
/// turns appended after the checkpoint are retained without a second request.
pub fn restore_semantic_checkpoint(
    turns: &[Turn],
    checkpoint: &SemanticCheckpoint,
    session_id: &str,
    branch_id: &str,
    budget: ContextBudget,
) -> Result<Vec<Turn>, ContextError> {
    if budget.max_tokens <= budget.reserved_output_tokens {
        return Err(ContextError::InvalidBudget);
    }
    if checkpoint.schema_version != SEMANTIC_CHECKPOINT_VERSION
        || checkpoint.source.session_id != session_id
