//! Deterministic context accounting and compaction.

use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

use crate::core::{Turn, TurnRole};

pub const DEFAULT_CONTEXT_TOKEN_BUDGET: u64 = 128_000;
pub const DEFAULT_RESERVED_OUTPUT_TOKENS: u64 = 8_192;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct ContextBudget {
    pub max_tokens: u64,
    pub reserved_output_tokens: u64,
}

impl Default for ContextBudget {
    fn default() -> Self {
        Self {
            max_tokens: DEFAULT_CONTEXT_TOKEN_BUDGET,
            reserved_output_tokens: DEFAULT_RESERVED_OUTPUT_TOKENS,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct TokenEstimate {
    pub input_tokens: u64,
    pub approximate: bool,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct CompactionCheckpoint {
    pub source_start: usize,
    pub source_end: usize,
    pub source_sha256: String,
    pub summary: String,
    pub estimated_tokens_before: u64,
    pub estimated_tokens_after: u64,
}

#[derive(Debug, Clone, PartialEq)]
pub struct PreparedContext {
    pub turns: Vec<Turn>,
    pub checkpoint: Option<CompactionCheckpoint>,
    pub estimate: TokenEstimate,
}

pub fn estimate_tokens(turns: &[Turn]) -> TokenEstimate {
    let bytes = turns.iter().fold(0_u64, |total, turn| {
        let metadata = turn.metadata.as_ref().map_or(0, |value| {
            serde_json::to_vec(value).map_or(u64::MAX, |data| data.len() as u64)
        });
        total
            .saturating_add(turn.content.len() as u64)
            .saturating_add(16)
            .saturating_add(metadata)
    });
    TokenEstimate {
        input_tokens: bytes.div_ceil(4),
        approximate: true,
    }
}

/// Opaque protocol state must remain byte-for-byte available to its adapter.
/// Native signatures live inside blocks, not just a top-level signature field.
pub fn has_opaque_provider_state(turn: &Turn) -> bool {
    turn.metadata.as_ref().is_some_and(|metadata| {
        metadata.get("signature").is_some()
            || metadata.get("thinking_signature").is_some()
            || metadata["annotations"]
                .as_array()
                .is_some_and(|annotations| {
                    annotations.iter().any(|item| {
                        item["type"] == "native_history" || item.get("signature").is_some()
                    })
                })
    })
}

fn whole_turn_start(turn: &Turn) -> bool {
    turn.role == TurnRole::User
        && (turn.parent_id.is_none()
            || turn
                .metadata
                .as_ref()
                .is_some_and(|m| m["steer"]["strategy"] == "cancel_reissue"))
}

/// Keep system records and the newest conversational suffix. Older records
/// become a deterministic digest summary, so replay of the same journal yields
/// byte-identical provider input without another model call.
pub fn prepare_context(
    turns: &[Turn],
    budget: ContextBudget,
    cancelled: &dyn Fn() -> bool,
) -> Result<PreparedContext, ContextError> {
    if budget.max_tokens <= budget.reserved_output_tokens {
        return Err(ContextError::InvalidBudget);
    }
    let available = budget.max_tokens - budget.reserved_output_tokens;
    let before = estimate_tokens(turns);
    if before.input_tokens <= available {
        return Ok(PreparedContext {
            turns: turns.to_vec(),
            checkpoint: None,
            estimate: before,
        });
    }
    if cancelled() {
        return Err(ContextError::Cancelled);
    }
    let protected_system = turns
        .iter()
        .filter(|turn| turn.role == TurnRole::System)
        .cloned()
        .collect::<Vec<_>>();
    let mut suffix = Vec::new();
    let suffix_budget = available.saturating_mul(3) / 4;
    for turn in turns.iter().rev() {
        if turn.role == TurnRole::System {
            continue;
        }
        suffix.push(turn.clone());
        suffix.reverse();
        let estimate = estimate_tokens(&suffix).input_tokens;
        suffix.reverse();
        if estimate > suffix_budget && suffix.len() > 1 {
            suffix.pop();
            break;
        }
    }
    suffix.reverse();
    let kept_start = suffix
        .first()
        .and_then(|first| turns.iter().position(|turn| turn.id == first.id))
        .unwrap_or(turns.len());
    if kept_start == 0 {
        return Err(ContextError::BudgetExceeded {
            estimated: before.input_tokens,
            available,
        });
    }
    let compacted = &turns[..kept_start];
    let serialized =
        serde_json::to_vec(compacted).map_err(|error| ContextError::Encoding(error.to_string()))?;
    let digest = format!("{:x}", Sha256::digest(&serialized));
    let roles = compacted.iter().fold([0_usize; 4], |mut counts, turn| {
        counts[match turn.role {
            TurnRole::System => 0,
            TurnRole::User => 1,
            TurnRole::Assistant => 2,
            TurnRole::Tool => 3,
        }] += 1;
        counts
    });
    let summary = format!(
        "Compacted context checkpoint: {} records (system={}, user={}, assistant={}, tool={}), sha256={digest}.",
        compacted.len(),
        roles[0],
        roles[1],
        roles[2],
        roles[3]
    );
    let mut summary_turn = Turn::new(format!("context-{digest:.16}"), TurnRole::System, &summary);
    summary_turn.created_at_ms = compacted.last().map_or(0, |turn| turn.created_at_ms);
    summary_turn.metadata = Some(serde_json::json!({
        "context_checkpoint": {
            "source_start": 0,
            "source_end": kept_start,
            "source_sha256": digest,
        }
    }));
    let mut prepared = protected_system;
    prepared.push(summary_turn);
    prepared.extend(suffix);
    let after = estimate_tokens(&prepared);
    if after.input_tokens > available {
        return Err(ContextError::BudgetExceeded {
            estimated: after.input_tokens,
            available,
        });
    }
    Ok(PreparedContext {
        turns: prepared,
        checkpoint: Some(CompactionCheckpoint {
            source_start: 0,
            source_end: kept_start,
            source_sha256: digest,
            summary,
            estimated_tokens_before: before.input_tokens,
            estimated_tokens_after: after.input_tokens,
        }),
        estimate: after,
    })
}

/// Reconstruct a previously recorded deterministic checkpoint without asking
/// the provider for a summary.  This is used by `/compact` markers after a
/// process restart; a malformed or stale marker is rejected rather than being
/// treated as an authoritative context replacement.
pub fn restore_checkpoint(
    turns: &[Turn],
    checkpoint: &CompactionCheckpoint,
) -> Result<Vec<Turn>, ContextError> {
    if checkpoint.source_start != 0
        || checkpoint.source_end == 0
        || checkpoint.source_end > turns.len()
    {
        return Err(ContextError::InvalidCheckpoint);
    }
    let compacted = &turns[checkpoint.source_start..checkpoint.source_end];
    let serialized =
        serde_json::to_vec(compacted).map_err(|error| ContextError::Encoding(error.to_string()))?;
    let digest = format!("{:x}", Sha256::digest(&serialized));
    if digest != checkpoint.source_sha256 {
        return Err(ContextError::InvalidCheckpoint);
    }
    let roles = compacted.iter().fold([0_usize; 4], |mut counts, turn| {
        counts[match turn.role {
            TurnRole::System => 0,
            TurnRole::User => 1,
            TurnRole::Assistant => 2,
            TurnRole::Tool => 3,
        }] += 1;
        counts
    });
    let summary = format!(
        "Compacted context checkpoint: {} records (system={}, user={}, assistant={}, tool={}), sha256={digest}.",
        compacted.len(),
        roles[0],
        roles[1],
        roles[2],
        roles[3]
    );
    if summary != checkpoint.summary {
        return Err(ContextError::InvalidCheckpoint);
    }
    let protected_system = turns
        .iter()
        .filter(|turn| turn.role == TurnRole::System)
        .cloned()
        .collect::<Vec<_>>();
    let suffix = turns[checkpoint.source_end..]
        .iter()
        .filter(|turn| turn.role != TurnRole::System)
        .cloned()
        .collect::<Vec<_>>();
    let mut summary_turn = Turn::new(format!("context-{digest:.16}"), TurnRole::System, &summary);
    summary_turn.created_at_ms = compacted.last().map_or(0, |turn| turn.created_at_ms);
    summary_turn.metadata = Some(serde_json::json!({
        "context_checkpoint": {
            "source_start": checkpoint.source_start,
            "source_end": checkpoint.source_end,
            "source_sha256": digest,
        }
    }));
    let mut prepared = protected_system;
    prepared.push(summary_turn);
    prepared.extend(suffix);
    Ok(prepared)
}

#[derive(Debug, thiserror::Error)]
pub enum ContextError {
    #[error("context budget must reserve fewer tokens than its maximum")]
    InvalidBudget,
    #[error("context preparation was cancelled")]
    Cancelled,
    #[error("context needs approximately {estimated} tokens but only {available} are available")]
    BudgetExceeded { estimated: u64, available: u64 },
    #[error("context encoding failed: {0}")]
    Encoding(String),
    #[error("context checkpoint is invalid or stale")]
    InvalidCheckpoint,
}

/// Version 2 stores a provider-generated summary separately from legacy digest
/// checkpoints. A caller must supply the selected branch's complete ancestry.
pub const SEMANTIC_CHECKPOINT_VERSION: u16 = 2;
pub const MAX_SUMMARY_BYTES: usize = 64 * 1024;

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CheckpointSource {
    pub session_id: String,
    pub branch_id: String,
    pub tip_id: String,
    pub records: usize,
    pub sha256: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct UnresolvedContextCall {
    pub turn_id: String,
    pub call_id: String,
    pub tool: String,
}

