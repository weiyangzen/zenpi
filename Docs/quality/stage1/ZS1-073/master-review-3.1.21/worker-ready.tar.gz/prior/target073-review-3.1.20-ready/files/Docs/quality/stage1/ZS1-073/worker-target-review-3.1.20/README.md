# ZS1-073 3.1.20 单文件复核候选

唯一学习对象 src/context.rs。canonical report 原 12667 字节完整保留并附加本轮复核；baseline/current 两份完整顺读，当前与旧实测对象同 hash。两个版本内联测试均为0，外部历史断言见 assertion-review.md。

historical-target073-ready.tar.gz 完整保留旧 authority 3.1.16、18 payload（含 reuse 子目录）、实际命令/日志以及139输入闭包。29项顶层通过只是历史结果，2个子进程 helper 不加总；本轮未跑 Cargo/HTTP/PTY，也未重验当前依赖闭包。源快照放在 Docs 下仅供阅读。

离线核验：在仓库根目录运行 `python3 Docs/quality/stage1/ZS1-073/worker-target-review-3.1.20/verify.py`；可加 `--live` 只核对主控 context.rs 当前字节；可加 `--packet <ready绝对目录>` 核验 payload/patch 并在临时 git 仓库放入已核验的主控原报告，验证精确应用与逆向恢复。脚本不导入产品、不运行 Rust 或网络。

candidate.patch 以主控原3036字节报告（SHA 08f9dc2204499b1431e049bb6e42c5677a24eb4934f4c3672cf3f17063b5219b）与新证据路径不存在为基底；worker commit 则是已有报告的追加与新证据目录，两种基底不可混用。接受与回退由主控按实际路径基底核验，不修改 ledger、authority、主控回执或产品代码。
