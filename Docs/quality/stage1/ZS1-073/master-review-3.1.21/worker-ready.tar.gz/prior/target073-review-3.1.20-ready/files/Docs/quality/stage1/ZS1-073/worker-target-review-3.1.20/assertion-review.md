# 073 历史外部测试实际断言索引

本轮基线246行、当前807行均完整读完，文件内没有测试模块/内联测试，内联断言数0。以下是从原 replay-inputs.tar.gz 中读取的四个外部测试源；仅用于解释073历史证据，不启动新测试、不构成其它文件学习。完整原源和原命令/日志保存在归档，机器索引给出每个测试源 hash 与完整函数名。下表简称均可与该索引对应。

## tests/context.rs：4项顶层通过

| 测试名 | 实际断言及限度 |
|---|---|
| token_estimate_is_explicitly_approximate | approximate=true 且估算>0；没有与供应商 tokenizer 比较 |
| compaction_is_deterministic_and_keeps_newest_turns | 同输入两次 checkpoint/turns 完全相同、产生checkpoint、最后ID不变、估算<=1200 |
| cancellation_during_needed_compaction_preserves_source | 需压缩且取消时是 ContextError::Cancelled，source与clone相同；不覆盖fit路径取消 |
| restoring_a_checkpoint_rejects_changed_source_records | 改source[0]文本后 legacy restore 返回 InvalidCheckpoint |

## tests/stage1_context_checkpoint.rs：8项顶层通过，1个helper不加总

| 测试名 | 实际断言及限度 |
|---|---|
| whole_turn_cut_keeps_multi_call_pairs_files_and_source_identity | schema=2、cut=6、tail=[u2]、read=[constraints.txt]、modified=[output.txt]、unresolved空；恢复role为System/System/User、首s、摘要含Unicode、末u2 |
| changed_source_cut_tail_parent_summary_and_branch_are_rejected | 分别改cut/tail/covered hash/summary/tip/branch/version七字段均拒绝；改覆盖文本、missing parent、移走工具result、other session也拒绝 |
| unresolved_tool_results_stay_in_tail_and_failed_assistants_are_not_projected | pending call列在unresolved且parent=u2；恢复保留pending、过滤aborted；追加u3后仍cut=6，不能越过未完成call |
| failed_writes_are_not_reported_as_modified_and_unknown_prefix_is_not_compacted | denied write令modified空；将其改unknown_outcome后prepare失败 |
| cancellation_empty_summary_and_budget_failure_leave_existing_checkpoint_unchanged | 首次append=true；取消append报错且文件字节不变；重复append=false；prepare取消返回Cancelled；空summary finalize失败；1token可用预算restore失败；latest checkpoint与原始一致且文件字节不变 |
| stale_preparation_and_duplicate_result_rejected | prepare后追加a2导致finalize拒绝；同call第二result（不同record ID）导致prepare拒绝 |
| durable_checkpoint_survives_a_new_process_and_retains_appended_turns | 持久化后加a2、关闭并以current_exe启动ignored helper；退出成功且stdout含1 passed。helper实际恢复摘要含Unicode且末ID=a2；父1项，helper不额外加总 |
| legacy_digest_checkpoint_remains_readable_without_becoming_semantic | legacy JSON反序列化为SemanticCheckpoint失败；legacy restore仍成功 |

## tests/stage1_semantic_compaction.rs：12项顶层通过，1个helper不加总

共同 fixture 走真实 OpenAiCompatibleBackend / loopback HTTP / 临时 SessionStore；HTTP解析要求POST指定path、非零读取、header阶段<256KiB，读取完整content-length JSON；summary wire要求purpose、max_completion_tokens=1000、无工具、无response_format、system含do not continue。good_summary以硬编码内容回传，先断言请求含BentoBox约束及verify restart。它验证已知fixture约束传递，不证明开放模型摘要质量。所有下列时间边界属于旧测试，不是本轮性能结果。

| 测试名 | 实际断言及限度 |
|---|---|
| real_http_summary_preserves_constraints_files_usage_and_iterative_restart | 第一次previous=null，第二次previous含约束且new_records不含old-0；延续wire含约束/待办/中文路径、无旧长历史；report.compacted且legacy checkpoint=None；usage.output=130/provider=fixture/read/modified精确；第二cut增大；重开checkpoint相同；reserved cost=12000、2个response事件、首usage估价470、HTTP总数3 |
| actual_http_invalid_summary_never_replaces_previous_checkpoint | 11个分支：empty/json/missing_usage/missing_input_usage/length/over_output/file_loss/refusal/tool_call/over_input/over_cost。先建有效checkpoint再追加，第二compact必须失败；当前与重开后的checkpoint均保持旧值，每分支HTTP总数2。11分支归入1顶层测试，不能计11项 |
| quota_cost_unknown_price_and_oversized_source_fail_before_http | cost/unknown price/network/input/output/source六分支均compact错误、checkpoint=None、HTTP数0；fixture若被调用panic。成本价格和资源限额为旧host闭包能力，不是context本身实现 |
| http_cancellation_retains_valid_checkpoint_and_does_not_retry | 第二summary HTTP设置取消位；compact错误、原checkpoint保留、HTTP总数2 |
| native_state_is_pinned_counted_and_branch_bound | 恢复native Turn与原值完全相同，other-branch失败；签名增至20000字符的metadata估算>5000 |
| separate_process_commit_and_reopen_use_semantic_context_on_real_wire | compact/resume两个真实子进程退出成功；resume输入文件手工截到semantic_checkpoint事件，明确found；wire含约束/待办、不含semantic_checkpoint元数据，HTTP数2。此处是人工构造commit边界文件，不是一次fsync中途kill实验 |
| unknown_tool_result_stays_in_retained_tail_and_summary_does_not_claim_success | summary request unresolved首call ID为unknown-call；checkpoint unresolved=1、modified不含unconfirmed.txt；恢复保留原call与unknown result两个完整Turn。good_summary仍为fixture，不能扩大为任意模型绝不虚报 |
| actual_http_prepare_services_late_steer_and_consumes_it_once | 阻塞summary期间port.is_preparing=true；enqueue ticket在有界轮询中reply Ok；放行后owner join成功；延续wire的late requirement出现1次、HTTP总数2、queue恢复Applied、history文本仅1条、events不泄露critical_facts |
| async_headless_manual_compact_remains_responsive_and_cancellable_during_http | UnixStream pair驱动run_async_streams，HTTP阻塞时5秒内先拿到status response，再cancel得到compact response success=false；放行并join，输出无critical_facts、HTTP仅1、重开checkpoint=None。不是PTY/真实TUI实验；没有断言status response.success |
| summary_http_failure_does_not_use_configured_automatic_retries | backend虽设3次retry，503 handler只允许n=0；compact失败、HTTP=1、无checkpoint、恢复ledger.network_requests=1 |
| opaque_state_before_every_cut_fails_without_losing_history_or_starting_http | 首记录native_history钉住全部cut；compact失败，history==原始、无checkpoint、HTTP为空 |
| killed_summary_process_preserves_previous_commit_and_requires_explicit_recovery | 已有checkpoint，第二HTTP开始后kill子进程并wait，退出非成功；重开保留旧checkpoint、recovery非空、普通process拒绝，HTTP总数2；未断言自动恢复成功，也不是真实外部模型 |

semantic_process_helper 被父测试作为 compact/interrupted/resume 启动；compact调用真实compact后exit(0)；interrupted若未在commit前被父终止会panic；resume断言已有checkpoint、operation recovery空并process。helper在顶层listing标ignored，嵌套通过输出或被kill均不添加到29的分母。

## tests/target073_review_probe.rs：5项顶层通过

| 测试名 | 实际断言及限度 |
|---|---|
| fitting_legacy_context_does_not_consult_cancellation_and_metadata_is_counted | 加4000字符metadata后estimate至少加1000；fit返回源turns且cancel谓词调用次数严格0，即使它会返回true |
| legacy_cut_can_split_parent_context_and_restore_has_no_budget_gate | budget500样例cut=1；投影有parent=u1却无id=u1；两项estimated改0并追加100000字符User后restore成功且estimate>500 |
| low_level_finalize_can_persist_plain_summary_without_completion_validation | finalize接受普通非JSON+默认usage；严格validator对Completion::text报错；真实append/关闭/重开恢复同文本，total_tokens=0。只证明低层API，未证明生产调用链绕过validator |
| context_call_parent_must_exist_but_is_not_required_to_have_user_role | call/result共同指向更早System，prepare/finalize成功，read_files恰为owned.txt |
| summary_completion_validation_accepts_deferred_annotation_but_rejects_length | 合法九段JSON、usage10/20/30、output limit100，finish_reason=deferred成功、仅换length即错误 |

原 test-command.json 与 stdout 给出的4+8+12+5=29顶层通过、0失败一致。负向错误断言不等同失败日志；归档完整保留stdout/stderr，未删减失败或ignored行。本轮新增行为运行0，当前context同hash，当前完整宿主/工具链闭包未复跑。
