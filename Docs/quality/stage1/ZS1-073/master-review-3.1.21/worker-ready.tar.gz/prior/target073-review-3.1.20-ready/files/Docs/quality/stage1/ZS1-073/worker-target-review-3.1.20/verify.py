#!/usr/bin/env python3
"""ZS1-073 offline identity/read coverage and reversible Docs patch verification."""
import argparse, difflib, re, gzip, hashlib, io, json, subprocess, tarfile, tempfile
from pathlib import Path, PurePosixPath
REPORT = 'Docs/learn/stage1_pi_mono/targets/zenpi/files/src/context.rs_learn.md'
ENTRY = 'Docs/quality/stage1/ZS1-073/worker-target-review-3.1.20'
OLD = '5b0224277186c3b550dfad642a404407f68c1f517e25d1b883f1fa15ecac8337'
def sha(b): return hashlib.sha256(b).hexdigest()
def checked(b, f):
    assert len(b) == f['bytes'] and sha(b) == f['sha256'], f.get('path', f)
def read(t, name):
    m = t.getmember(name)
    assert m.isfile() and not m.issym() and not m.islnk(), name
    return t.extractfile(m).read()
def verify(root, live=False):
    e = root / ENTRY
    with tarfile.open(e / 'historical-target073-ready.tar.gz') as t:
        mb = read(t, 'manifest.json'); assert sha(mb) == OLD
        manifest = json.loads(mb); assert len(manifest['files']) == 18
        for f in manifest['files']: checked(read(t, f['path']), f)
        prior = read(t, 'learn-report.md'); assert len(prior) == 12667
        report = (root / REPORT).read_bytes(); assert report.startswith(prior) and len(report) > len(prior)
        base = read(t, 'prior-report.md')
        assert (e / 'receiver-base-report.md').read_bytes() == base and base in report
        baseline = gzip.decompress(read(t, 'baseline-context.rs.gz'))
        historical = gzip.decompress(read(t, 'context.rs.gz'))
        current = (e / 'current-context.rs').read_bytes()
        assert (e / 'baseline-context.rs').read_bytes() == baseline
        assert (e / 'historical-context.rs').read_bytes() == historical
        checked(historical, manifest['subject']); assert current == historical
        assert sha(current) == '256d9ac1657e272ba61ebfbc242ece2970ed0607f3ebb1583b1711f18b7bf229'
        inventory = {f['path']:f for f in json.loads(read(t, 'replay-input-inventory.json'))}
        assert len(inventory) == 139
        with tarfile.open(fileobj=io.BytesIO(read(t, 'replay-inputs.tar.gz'))) as archive:
            assert len(archive.getmembers()) == 139
            assert {m.name for m in archive.getmembers()} == set(inventory)
            for name, f in inventory.items(): checked(read(archive, name), f)
        cmd = json.loads(read(t, 'test-command.json'))
        assert cmd['exit_code'] == 0 and cmd['passed'] == 29 and cmd['failed'] == 0
        assert cmd['ignored_helpers'] == 2 and cmd['unchanged_base_inputs'] == 138
        log = read(t, 'tests.stdout.log').decode()
        for n in (4,8,12,5): assert f'test result: ok. {n} passed; 0 failed;' in log
        index = json.loads((e / 'historical-test-index.json').read_text())
        assert index['distinct_top_level'] == 29 and index['new_behavior_runs'] == 0
        with tarfile.open(fileobj=io.BytesIO(read(t, 'replay-inputs.tar.gz'))) as archive:
            count = 0
            for f in index['tests']:
                b = read(archive, f['path']); checked(b, f)
                titles = re.findall(r'#\[test\]\s*(?:#\[ignore[^\n]*\]\s*)?fn (\w+)', b.decode())
                assert titles == f['titles']; count += len(titles)
            assert count == 31
    coverage = json.loads((e / 'read-coverage.json').read_text())
    assert len(coverage['inputs']) == 2
    for f in coverage['inputs']:
        raw = (e / (f['identity'] + '-context.rs')).read_bytes(); checked(raw, f)
        lines = raw.splitlines(keepends=True); assert len(lines) == f['lines']
        first, offset = 1, 0
        for c in f['chunks']:
            assert c['first_line'] == first and c['byte_start'] == offset
            b = b''.join(lines[first-1:c['last_line']]); assert sha(b) == c['sha256']
            offset += len(b); first = c['last_line'] + 1
            assert c['byte_end'] == offset
        assert offset == len(raw) and first == len(lines) + 1
    for raw in (baseline, current):
        assert b'#[test]' not in raw and b'#[cfg(test)]' not in raw
    assert sha(baseline) == 'bc4ce7999a0f4d162effece8c6f839aca3a230e97675a1d7908fca5d6a7fe909'
    if live: assert Path('/Users/wangweiyang/GitHub/zenpi/src/context.rs').read_bytes() == current, 'live context drift'
    return {'old_payloads':18, 'historical_archive_inputs':139, 'old_report_prefix_bytes':12667,
            'baseline_lines':246, 'current_lines':807, 'historical_top_level_passed':29,
            'current_same_as_historical':True, 'new_behavior_runs':0, 'live_subject_checked':live}
def packet_check(packet):
    m = json.loads((packet / 'manifest.json').read_text()); files = m['files']
    assert len({f['path'] for f in files}) == len(files)
    for f in files:
        p = PurePosixPath(f['path'])
        assert not p.is_absolute() and '..' not in p.parts and p.parts[0] == 'Docs'
        checked((packet / 'files' / f['path']).read_bytes(), f)
    patch = packet / 'candidate.patch'; checked(patch.read_bytes(), m['patch'])
    with tempfile.TemporaryDirectory(prefix='target073-patch-') as tmp:
        target = Path(tmp)
        def git(*args): subprocess.run(['git','-C',tmp,*args],check=True,capture_output=True,timeout=30)
        git('init','-q')
        base = (packet / 'files' / ENTRY / 'receiver-base-report.md').read_bytes()
        checked(base, m['receiver_report_base'])
        (target / REPORT).parent.mkdir(parents=True, exist_ok=True)
        (target / REPORT).write_bytes(base)
        git('apply','--check',str(patch)); git('apply',str(patch))
        for f in files: checked((target / f['path']).read_bytes(), f)
        found = {str(p.relative_to(target)) for p in target.rglob('*') if p.is_file() and '.git' not in p.relative_to(target).parts}
        assert found == {f['path'] for f in files}
        verify(target)
        git('apply','--reverse','--check',str(patch)); git('apply','--reverse',str(patch))
        assert (target / REPORT).read_bytes() == base
        assert all(not (target / f['path']).exists() for f in files if f['path'] != REPORT)
    return {'files':len(files),'forward':'exact final bytes','reverse':'exact original 3036-byte report restored; new evidence removed'}
def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[5]); p.add_argument('--live',action='store_true'); p.add_argument('--packet',type=Path)
    a = p.parse_args(); out = verify(a.root.resolve(),a.live)
    if a.packet: out['packet'] = packet_check(a.packet.resolve())
    print(json.dumps(out,indent=2))
if __name__ == '__main__': main()
