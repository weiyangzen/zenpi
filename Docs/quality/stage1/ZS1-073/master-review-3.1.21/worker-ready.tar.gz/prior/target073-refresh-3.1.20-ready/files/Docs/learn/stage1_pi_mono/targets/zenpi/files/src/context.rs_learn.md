# ZS1-073 — src/context.rs 完整 owner 复核

状态：[_] 当前hash阅读/行为候选，主控未接受。Authority3.1.16；requirement digest `c0262492bc6e3b4d5f56b35bedc7c1d1658854df11c4a975eb612a514cceef8f`。

Subject为主控只读快照，807行/30013字节/SHA256 `256d9ac1657e272ba61ebfbc242ece2970ed0607f3ebb1583b1711f18b7bf229`。全文按1–290、291–570、571–807逐行读取，完整字节并集[0,30013)，见read-coverage.json。本次没有产品修改。

已有主控073报告仅对应246行/8199字节/hash `bc4ce7999a0f4d162effece8c6f839aca3a230e97675a1d7908fca5d6a7fe909`，已在旧input-host-before快照找到完全一致文件并冻结。另核验冻结ZS1-104候选的context.rs原字节与当前subject完全相同；只复用该历史身份/设计背景，仍重新完整读807行并执行当前上下文测试。旧包authority3.1.6保持不变，不回写成当前版本。

## 职责与来源关系

context是纯准备/校验/投影层：估算上下文、构造legacy digest checkpoint、选择semantic完整turn切点、验证source/summary、组装摘要请求与恢复后的provider输入。它本身没有网络、journal写入、费用结算、provider重试、模型选择或operation recovery owner。生成summary、持久化与取消/预算生命周期在core/session/backend/governance。

对照冻结pi compaction源项012：增量请求携带previous_summary与新覆盖records；保留新近完整turn，不把未完成或unknown工具结果压成成功；从真实工具结果提取文件操作信息。Zenpi另加入source session/branch/hash、usage与严格JSON sections等本地owner约束。旧digest只保存数量和hash，不保存语义；生产core的context_source_for_provider明确在没有semantic checkpoint时返回完整selected history，不用旧digest替代事实。这是本次实际定位的调用路径，不能把legacy helper的弱约束当成当前provider自动压缩的全部实现。

## 全部类型、函数及分支

| 行 | 职责与分支 | owner/限制 |
|---|---|---|
| 1–47 | 默认budget128000/reserved8192；ContextBudget、TokenEstimate、legacy CompactionCheckpoint、PreparedContext | legacy checkpoint无schema/session/branch；估算一律approximate |
| 49–63 | estimate_tokens | 每turn content UTF-8字节+16+序列化metadata字节，saturating累加后ceil/4；metadata编码失败按MAX保守估算；不单独计ID/parent/timestamp/外部attachment实体 |
| 65–88 | has_opaque_provider_state、whole_turn_start | 识别顶层signature/thinking_signature或annotations native_history/signature；presence即保护（并非递归任意key扫描）。完整turn起点是无parent User，或metadata steer.strategy=cancel_reissue的User |
| 90–112 | prepare_context入口 | max<=reserve InvalidBudget；已fit直接clone返回，无checkpoint且不调用cancel；只有需压缩才检查一次cancel |
| 113–143 | legacy保留选择 | 所有System单独保留；逆扫非System，目标3/4 available，至少尝试最新一条；按首个保留ID找原位置；kept_start0报预算不足；不验证ID唯一、完整turn或工具配对 |
| 144–196 | legacy摘要/预算 | JSON hash覆盖prefix；数四种role生成固定count+SHA文本；summary ID取digest前16位，时间取prefix最后turn；protected system+summary+suffix再估算，超budget失败，否则返回六字段marker |
| 198–262 | restore_checkpoint | source_start须0、end非0且<=turns.len；prefix hash和固定summary文本必须相同；重组所有System+summary+非System suffix；不验证估算字段、不含restore budget/cancel参数 |
| 264–276 | ContextError | InvalidBudget/Cancelled/BudgetExceeded/Encoding/InvalidCheckpoint，纯typed错误无session副作用 |
| 278–325 | semantic version2、64KiB上限、CheckpointSource、UnresolvedContextCall、SemanticCheckpoint、Plan | source完整session/branch/tip/records/hash；covered hash、retained IDs、文件集、未完成call、summary hash/provider/model/usage；Plan字段私有不可外部随意构造 |
| 327–363 | context_digest、valid_context_id、failed_context_assistant | 整turn JSON含metadata/时间等；ID非空<=128B无control，但允许首尾非全空白；失败assistant识别顶层三种stop键及annotations.finish_reason的error/aborted/deferred/cancelled |
| 365–385 | checkpoint_skeleton切点前置 | session/branch合法；end在1..len且对应whole-turn User；覆盖prefix不得有opaque state，并须含非System记录 |
| 386–435 | ancestry/assistant calls扫描 | ID合法唯一；parent若有须在更早ID集合；Tool无metadata拒绝；tool_calls只能在非failed Assistant，需parent、数组、合法call/name、object arguments；(parent,call_id)唯一；抓取arguments.path字符串 |
| 437–467 | tool结果配对与路径集合 | Tool需parent/call ID并能匹配更早call；重复result或显式tool_name不匹配拒绝；记录result索引与unknown_outcome；仅prefix succeeded的read_file/list_directory/search_text路径计read，write_file/edit_file计modified；两个BTreeSet独立、排序去重、不canonicalize文件系统 |
| 469–503 | cut安全与skeleton输出 | prefix call若无结果、结果跨cut、或unknown则拒绝；tail未解决/unknown列入unresolved；source hash绑定完整原输入，covered hash绑定prefix，tail IDs按源顺序保存；summary字段初始空 |
| 505–531 | prepare_semantic_compaction | 入口cancel、每个候选cut前cancel；从最近User起点逆向找尾部estimate>=keep_recent_tokens且skeleton合法的第一个cut；无可用cut统一InvalidCheckpoint；没有可压prefix时不制造假summary |
| 533–585 | Plan accessors/finalize | 暴露source/end只读；先cancel、重建skeleton并要求全结构相同以拒stale；设置summary/hash/provider/model/usage后调用restore验证预算与source，最后再cancel；不调用严格completion JSON校验 |
| 587–625 | restore_semantic_checkpoint基本验证 | budget有效、version2、真实session/branch匹配、source.records不超过当前len；summary非空<=64KiB、provider/model ID合法、summary hash相同；按原records重建全部skeleton后与持久checkpoint逐字段相等 |
| 626–658 | 增量恢复/投影预算 | 全当前ancestry再skeleton校验，允许合法追加记录；保留覆盖prefix的System，插入summary System，append保留尾部但过滤failed assistant；summary ID用hash前24位，时间prefix末尾；重新估算超budget拒绝 |
| 660–676 | SemanticSummary及SUMMARY_INSTRUCTIONS | 9个必需数组，deny_unknown_fields；instructions要求只总结数据、保留要求/未完成工作/文件、不得把unknown写成完成；这是模型指令，不是语义真实性证明 |
| 678–725 | summary_request_data | 当前skeleton必须仍等于plan；previous有值先恢复验证，要求previous.end严格早于新cut；只发送新覆盖区间且过滤failed assistants；previous summary作为字符串字段，真实文件集/未解决对象由plan提供；无previous从0起 |
| 727–767 | validate_summary_completion外层 | usage必需且输入/输出>0，output<=limit，sum不可溢出且total>=sum；拒refusal、tool calls、空/超长内容；annotations truncated或指定失败/length状态拒绝 |
| 768–807 | completion结构校验与规范序列化 | 严格解析全部sections；六种语义section不能全空；八种字符串数组每个<=64条、每条非空<=4096B且无NUL；read/modified/unresolved必须逐项精确等于plan；最终重新serde编码并返回实际usage |

## 算法、边界和数据可信度

semantic切点保证至少保留新近User整个suffix，且不能把assistant call与result拆到两边；unknown或未返回的prefix call禁止覆盖。call ID按(parent turn ID,call ID)关联，允许不同turn复用同call ID。prefix System不被摘要替换，opaque原生签名状态不能进入被覆盖prefix。恢复先验证旧source原字节，再校验追加记录，因此不是仅凭summary文本或客户端retained_ids信任裁剪。

当前skeleton只检查parent ID存在，没有检查该parent的role一定User，也不访问session tree的真实branch选择；后者来自调用者传入完整selected ancestry和session owner。文件列表只从成功tool结果与call arguments提取，既不读真实文件，也不能从模型自由文本判断副作用完成。read和modified可以同时包含同一路径，不能误写成后者自动从前者去除。

finalize/restore是version2 checkpoint的数据完整性层；validate_summary_completion是生产生成结果的更严格层。core当前先调用严格validator，再finalize，再append_semantic_checkpoint_for_operation；session的低层append只调用restore校验而非completion validator。保留103公共低层API意味着通过finalize或session写入并不能反推summary曾有合法结构/真实provider usage。usage本身仍是调用方/adapter给的数据，校验不能证明供应商实际计费。合法section结构也不保证摘要事实正确；HTTP fixtures只验证已知测试约束确实保留。

Cancellation的检查点是有限的：legacy fit零次、legacy需压缩入口一次；semantic规划入口及候选cut之间、finalize开始/结束。大skeleton循环与哈希内部没有逐记录cancel；prepare在多次候选失败时重复扫描/估算与hash，也没有固定常数耗时保证。没有将此静态事实冒称实际性能基准或取消延迟故障。

## 本次实际证据

未修改product的快照执行：context4 + stage1_context_checkpoint8 + stage1_semantic_compaction12 + 新probe5 =29个顶层通过、0失败；2个独立进程helper在各自顶层listing标ignored，父测试启动输出不重复计数。semantic套件用真实loopback HTTP、临时journal、取消、被终止的独立进程与重开；没有外部模型调用或真实模型质量评估。全部源/既有测试输入hash与只读快照一致，仅新增独立review probe。

五个新观察：

1. 已fit的legacy context即使传入总返回true的cancel函数也成功，实际调用次数0；4000字节metadata使估算增加至少1000 token单位，证明当前已修正旧基线“完全不计metadata”的缺口。
2. legacy预算500的实际样例cut=1，只覆盖u1，但返回的assistant/tool仍parent=u1，而u1本体已被count摘要替换；它不保证完整turn ancestry。改checkpoint两项estimated计数为0仍可restore；再追加10万字节User，restore仍成功且超过原预算。源码和实测一致，不能给legacy restore添加不存在的预算保证。
3. 低层plan.finalize接受非JSON普通summary和Usage::default()；真实SessionStore.append_semantic_checkpoint写入后，重开仍得到该summary且usage.total=0。相同Completion::text直接过严格validator会失败。该探针证明层次差异，不宣称生产Agent绕过了validator。
4. Assistant与Tool共同指向更早的System ID，call/result其余字段有效时，skeleton接受并报告read_files。parent存在与“是User turn”不是同一约束；真实core正常生成的parent路径不能替代这项静态/实测边界。
5. 内容、sections和usage均有效的Completion，annotations.finish_reason=deferred能过严格validator；改为length则拒绝。failed_context_assistant把deferred列为失败，但summary completion黑名单没有它。探针只通过自建Completion证明本层行为，没有证明任何外部provider能产生同样完整成功payload。

现有8个checkpoint测试另证明multi-call完整配对、source/cut/tail/summary/branch篡改拒绝、未解决call保留tail、failed write不计modified、unknown prefix不可压缩、cancel/budget/stale/duplicate result拒绝、独立进程durable checkpoint及legacy兼容。12个semantic测试另覆盖真实HTTP结构化summary、迭代restart、截断/坏summary不替换旧checkpoint、额度/价格/源上限在HTTP前拒绝、取消不自动重试、native state计入并保留、分支绑定、late steer准备边界、headless手动compact响应取消、被kill后未知operation恢复。

## 后续定位与交付边界

当前生产core有严格validator顺序证据，legacy弱约束与低层finalize宽松性均按兼容API记录，不在阅读任务中擅自升级/改写历史checkpoint。deferred黑名单不一致与parent role约束缺口具备最小实际样例，可由主控结合backend/session契约决定是否修复；本次未修改产品、ledger、接受状态或104等旧包。073全文已覆盖，不把core/session/backend依赖定位充当其对应文件的完整接受。


---

## 3.1.20 单文件复核补充（旧报告原字节保留）

本节为 ZS1-073 worker 候选，authority `3.1.20`，requirement digest `8d525b351d066ce9b0487a485337647d47233275782e4f4d154423a623fe1645`。前 12667 字节完全保留，SHA-256 `cc48dfbf84a5f4da7e8b894d9a82b8c4abd3ea466a7cd9f39b0564470871d57b`；前文“本次实际证据”“新 probe”“core 当前”等措辞均属于原 3.1.16 历史记录，不代表本轮重新运行或重新检查当前宿主。旧 authority、原结论和旧日志没有改写。

本轮只完整学习 `src/context.rs`，未改产品、未跑 Cargo/PTY/HTTP。基线完整顺读 1–246 行，8199 字节，SHA-256 `bc4ce7999a0f4d162effece8c6f839aca3a230e97675a1d7908fca5d6a7fe909`。当前完整顺读 1–290、291–570、571–807 行，30013 字节，SHA-256 `256d9ac1657e272ba61ebfbc242ece2970ed0607f3ebb1583b1711f18b7bf229`；与旧实测对象逐字节相同。新 read-coverage.json 记录每段字节范围与 hash，两个文件均无遗漏。冻结基线身份没有被扩展后的当前文件替代。

### 基线与当前的完整关系

| 基线范围 | 当前范围 | 本轮确认的行为与变化 |
|---|---|---|
| 1–47 | 1–47 | 四种公开数据结构与默认 128000/8192 预算一致；TokenEstimate 明示 approximate，legacy marker 保存覆盖范围、digest、count 文本和前后估算 |
| 49–58 | 49–63 | 原估算只将 content.len()+16 用 usize 求和再 ceil/4；当前增加 JSON metadata 字节并以 u64 saturating_add 累加，编码失败取 MAX。仍不是供应商 tokenizer，ID/parent/time 和外部实体没有单独计入 |
| 无 | 65–88 | 新增 opaque-state 检测与 whole-turn User 判定，供 semantic 路径使用；legacy 路径没有获得这些保护 |
| 60–174 | 90–196 | legacy 核心算法仍为 System 全保留、非 System 逆扫后缀、3/4 可用预算、计数摘要、最终预算；当前只因 estimate 变化而改变实际切点/是否 fit |
| 175–232 | 198–262 | legacy restore 验 prefix digest 和固定摘要后投影；无预算、cancel、session/branch、parent/tool 配对验证；estimated 字段没有成为约束 |
| 234–246 | 264–276 | 五种 ContextError 不变 |
| 无 | 278–807 | 新增 semantic version2 的身份绑定、完整 turn 切点、call/result 检查、文件集合、prepare/finalize/restore、增量请求及严格 Completion 校验；前文全函数表逐段重新核对，无遗漏 |

基线和当前源文件都没有 `#[test]`、`#[cfg(test)]` 或内联测试模块，实际内联测试数均为 **0**。不能将外部 integration tests 或 review probes 写成该文件内联断言。为交代已有实测，另对历史包中的四个外部测试源查看真实断言，逐项列于 assertion-review.md；这些读取只服务于 073 的证据解释，不构成第二文件学习或接受。

### 当前完整运行路径、预算与取消

`prepare_context` 先拒 max<=reserve；fit 时直接返回所有 turns、None checkpoint，即使 cancel 为 true 也不调用它。需要压缩才查一次 cancel。所有 System 保留；倒序尝试非 System 的最新后缀，至少尝试一条，超过 suffix 目标且多于一条则撤回最后加入的较旧条目。首个保留 ID 的首次原位置成为 cut，重复 ID 不被此层拒绝；cut=0 报 BudgetExceeded。prefix JSON hash 与角色数生成固定文本，摘要 turn ID 为 digest 前16字符、timestamp 为 prefix 最后记录；最终按当前 metadata 估算再做预算。该计数文本不能保存旧事实，也不保证完整 User/Assistant/Tool 组。

`restore_checkpoint` 要求 start=0、0<end<=len，只验证覆盖 prefix 的 JSON hash 与固定 count 文本，返回所有当前 System、摘要、剩余非 System。没有“原预算仍满足”的承诺，合法追加也未被计入 checkpoint 的原估算字段验证。它接收只读 slices，不写 journal，失败也不修改输入。

semantic prepare 的 `keep_recent_tokens` 是保留尾部的最低估算目标，不是输入上限；从最近完整 User 起点向前找第一个 tail estimate>=目标且 skeleton 合法的 cut。User 无 parent，或 User 带 `steer.strategy=cancel_reissue`，才是起点；metadata 值本身不构成已授权 steer 的证明。无切点统一 InvalidCheckpoint。prepare 没有 ContextBudget 参数，真正的 provider 输入上限在 finalize 调用 restore 以及后续 restore 中检查。

prepare 入口和各候选之间查 cancel；finalize 开始与完成验证后查 cancel。估算、JSON 编码、哈希、全 ancestry skeleton 内部没有逐记录取消，restore/request-data/Completion validator 没有 cancel 参数。多个候选可重复全量扫描；本轮没有测耗时、内存或取消延迟，也不能承诺主控真实 TUI 不会阻塞。

### 当前输入、call/result 与 checkpoint 边界

CheckpointSource 绑定 session/branch/tip/records/完整输入 JSON SHA；covered_sha256 单独绑定 prefix，retained_ids 保留原顺序；所有 Turn ID 必须非全空白、字节不超协议上限、无 control、唯一，parent 若有必须早于当前。session/branch 必须同样合法；这不自行选择真实 session tree 分支。工具 call 需非失败 Assistant、有 parent、数组中合法 ID/name 和 object arguments，按 (parent, call_id) 唯一。Tool 需 metadata、parent 和匹配更早 call，拒第二 result、显式不匹配 tool_name。省略/非字符串 tool_name 并未被强制拒绝；非 unknown 的任意 outcome 不会被当作 unknown，只有明确 succeeded 才计文件成功集合。parent 存在并不保证该 parent 的角色为 User。

prefix 含 opaque metadata 时不可覆盖：顶层 signature/thinking_signature 的存在，或 annotations 中 native_history/signature 的存在即触发；不是递归扫描所有可能供应商字段。prefix 必须含非 System 且 cut 对应完整 User；prefix 中 call 缺 result、result 跨 cut 或 unknown 均拒绝。tail 的无结果或 unknown 进入 unresolved_calls；该集合按 BTreeMap 键顺序生成。成功 prefix 的 read_file/list_directory/search_text 计 read，write_file/edit_file 计 modified，路径来自 arguments.path 字符串并分别排序去重；不读写文件、不 canonicalize、不校验真实副作用，同一路径可同时在两表中。

finalize 从只读 plan 重建 skeleton，要求完整相等，拒绝任何 source 变化后设置摘要、hash、provider/model、usage，并以 restore 校验 budget。restore 先用原 source.records 重建并逐字段对齐，再校验含新增记录的当前 ancestry；匹配的追加记录得以保留。投影为覆盖 prefix 的 System、semantic 摘要 System、tail（过滤失败 Assistant）；摘要 ID 取 SHA 前24字符，timestamp 为覆盖末记录。failed Assistant 识别顶层 stop_reason/stopReason/finish_reason，或 annotations.finish_reason 的 error/aborted/deferred/cancelled；带 tool_calls 的失败 Assistant 会先在 skeleton 被拒，不能仅凭过滤承诺任意坏历史都能恢复。

### 摘要请求与可信度

summary_request_data 必须对应未变化的 plan；若有 previous checkpoint，先恢复验证身份与完整性，再要求旧 end 严格小于新 end。请求以字符串 previous_summary 加仅新覆盖 records（含 id/parent/role/content/metadata，过滤 failed Assistant），并附 plan 的 read/modified/unresolved 事实。不是把原 journal 改写成摘要，也不在此函数发 HTTP。previous restore 使用 MAX budget 仅为完整性检查，不代表真实请求预算已批准。

严格 Completion validator 拒 refusal、tool calls、空或超过64KiB内容；必须有 usage，input/output 正数、output<=limit、加法无溢出且 total>=input+output；annotations truncated=true 或 length/max_tokens/error/aborted/cancelled/incomplete 被拒。**deferred 不在该名单**，与 failed Assistant 过滤规则不同；未知其它状态也不是默认拒绝。随后严格解析九个必需数组、拒未知键；六种语义内容不能全空，八种字符串列表各<=64条、每条非空、<=4096字节且无NUL，三个文件/未解决集合必须精确等于 plan，最终规范 JSON 编码。它不能证明摘要语义忠实、usage 为供应商实际计费，SUMMARY_INSTRUCTIONS 也仅是生成约束。

低层 finalize/restore 不调用严格 validator，非空非 JSON 文本与零 usage 可以通过低层并在旧 SessionStore 实测中持久化。前文记录的 core 先 validate→finalize→append 顺序属于旧闭包；本轮未重读或测试当前 core/session/backend/TUI，不据此替当前宿主签署“无法绕过”结论。

### 历史证据归属与本轮结果

旧 `.ops/target073-ready/manifest.json` SHA-256 为 `5b0224277186c3b550dfad642a404407f68c1f517e25d1b883f1fa15ecac8337`。完整归档保留 manifest 及18项 payload，包括嵌套 reuse/104-manifest.json；旧 104 authority 和旧报告均原样保留。内部 replay-inputs.tar.gz 的139个输入逐项核验，包含138个原快照输入及1个 probe；其测试对象 context.rs 与当前相同，但这不证明其余当前产品闭包相同。

旧命令返回0；4 context +8 checkpoint +12 semantic +5 probe =29项顶层通过、0失败，另2个 helper 标 ignored，由父测试启动且不加总。负向样例所期望的 Err/取消/拒绝属于通过断言，不是被隐藏的失败。旧日志中的 HTTP、临时 journal、子进程 kill/reopen 都是历史真实执行；没有外部模型质量实验。本轮仅离线 hash/归档/read coverage/文档补丁校验，**新增行为运行数0**。工具链和命令保存在原包，未重新执行，也没有把本轮静态检查改名为新的行为通过。

### 主控真实 TUI / 新会话任务的最小待验判据

以下是建议主控用其已授权宿主工作检验的边界，不是本轮新增通过或额外执行要求：

1. 同时改变历史或切换新会话/分支后，让旧摘要返回；主控应确认 finalize/提交拒绝 stale 身份，旧 checkpoint 不被替换，摘要不落入新会话。仅 context hash 相同不足以证明当前 owner 接线正确。
2. provider 摘要期间取消应保持原有效 checkpoint；待真实工作释放前不得用界面 Closed 或运行器 deadline 当作副作用已停。context 只提供有限检查点；需要当前 owner 生命周期证据。
3. 若主控决定摘要 `deferred` 必须失败，最小判据是相同合法 JSON/usage 仅改变 deferred/正常 finish 状态，分别拒绝/接受且失败不替换 checkpoint。旧探针现在断言 deferred 成功，不能在改修后原样计为新要求的通过。
4. 若契约要求 call parent 必须 User，最小判据是同组 call/result 指向更早 System 拒绝，改指合法 User 接受；当前本层实际接受 System，须由主控决定契约与修复，阅读任务不擅自改产品。
5. 真实宿主必须完成严格 validator 后才发布摘要 checkpoint；普通文本/零 usage 的低层 API 接受不能作为宿主成功证据。旧 history 与当前 context 同 hash 仅支持本文件行为归属，不替代当前调用链检查。

本补包的职责是使 073 的基线、当前完整实现、旧实测和待验边界可复核。G-FILE/G-STAGE、master receipt 与清单接受状态均由主控决定，本文不签署接受。


---

## 主控原基线报告逐字节保留副本

以下3036字节为主控接收基底原文，SHA-256 `08f9dc2204499b1431e049bb6e42c5677a24eb4934f4c3672cf3f17063b5219b`；与旧包 prior-report.md 完全一致。另以 receiver-base-report.md 单独保留，逆向应用必须恢复该原文。其“Current”语句属于原基线报告的历史语境。

# ZS1-073 — zenpi src/context.rs baseline

Frozen target: `src/context.rs`, 8199 bytes, SHA256 `bc4ce7999a0f4d162effece8c6f839aca3a230e97675a1d7908fca5d6a7fe909`.
Controller read all 246 baseline lines before editing the file for ZS1-103. New implementation is a separate candidate and does not replace this baseline identity.

`ContextBudget` exposes max and reserved output tokens with 128000/8192 defaults. `TokenEstimate` marks all estimates approximate. `CompactionCheckpoint` is an unversioned six-field digest record; `PreparedContext` returns turns, optional checkpoint and estimate. `estimate_tokens` counts content bytes plus 16 bytes per turn, divides by four and rounds up; it omits tool metadata and attachments, a budget gap for ZS1-104/107.

`prepare_context` rejects max <= reserve, returns unchanged turns when within budget, and checks cancellation only when compaction is needed. It preserves all system records, walks backward through non-system messages using three quarters of the available input budget, and finds the retained start by first matching ID. It does not validate duplicate IDs, complete user turns or tool call/result pairs. The discarded prefix is JSON-hashed and represented by role counts and SHA, not semantic information. The system summary timestamp is the prefix's last timestamp and its metadata identifies the covered range. It re-estimates assembled system+summary+suffix and refuses if still over budget. Source input is not mutated and no backend or journal is called.

`restore_checkpoint` checks a zero-based nonempty range within current turns, recomputes the prefix digest and exact count-summary string, then rebuilds protected systems, deterministic summary and non-system suffix. It rejects changed prefix bytes, but has no session/branch ID, retained IDs, summary version, provider usage, unresolved tool state or restore-time budget check. All errors are typed as invalid budget, cancelled, budget exceeded, encoding or invalid checkpoint.

All baseline branches are in this file's scope. `tests/context.rs` covers approximate estimates, deterministic suffix retention, cancellation and changed-source rejection. Current core explicit/automatic compaction and restart restoration consume this API, so removing or relabeling legacy records would break compatibility. ZS1-103 therefore adds a distinct v2 semantic schema and validated journal APIs; ZS1-104 must replace production generation/context selection with actual semantic summaries. Existing digest output must never be presented as preserved user constraints.

Source relationships: SRC-0121 provides preparation, generation and iterative-summary behavior; SRC-0156 provides latest-compaction/tail projection. The new `stage1_context_checkpoint` tests validate actual journal persistence and fresh-process restore, plus complete tool pairs, stale plans, source/branch mismatches and cancellation. Full production selection and semantic quality remain unaccepted. No directory acceptance is implied by this file report.

---

## 2026-09-12 再次刷新：完整源文件不变，补绑定当前调用者与源差异

本节是最新 worker understand 记录，前 **27,482 字节**保持原样，SHA256 `80e0eed1be1be173bfef61d666e1125694d91180bf183e60af7550b069fef071`。该前缀来自完整 `.ops/target073-review-3.1.20-ready`，其 manifest SHA256 `c934a5627654ad5e622a213e420b5fba9d44dd8bc52ef33df2b1ab538121bb87`，13 个 files payload 和独立 candidate.patch 均校验后原样归档。前缀包含更早 3.1.16 报告及主控原基线报告，它们的“本次”“current”“新 probe”“当前未重读”等均属于各自历史时点。本节不改旧 authority、断言、运行日志或接受状态。

唯一当前文件是 `src/context.rs`，**30,013 B /807 行**，SHA256 `256d9ac1657e272ba61ebfbc242ece2970ed0607f3ebb1583b1711f18b7bf229`；冻结基线 **8,199 B /246 行**，SHA256 `bc4ce7999a0f4d162effece8c6f839aca3a230e97675a1d7908fca5d6a7fe909`。当前与前一次完整报告、历史实测 context.rs 逐字节一致，**没有本文件源码 delta**。本轮仍完整连续读基线1–246、当前1–290/291–570/571–807；`read-coverage.json`绑定全部字节及所有常量、类型、impl、函数的定位。库存/哈希只是覆盖交叉检查，语义依据是完整阅读及下述具体合同。

捕获时 authority3.1.20、requirement digest `8d525b351d066ce9b0487a485337647d47233275782e4f4d154423a623fe1645`、snapshot `20e38b23c6550422c993cc241f9ffa9daeb4443e6d4f050fdd370ba6d54268f9`。主控说明089可能仅改变 checkbox/snapshot；`authority.json`保存起点，`boundary-after.json`另记录结束时实际值，不能把同一 requirement 下的两次 snapshot 混写成同一时点。未修改 main、产品、blueprint、claims、selector、旧 ready 或已有 canonical 报告。

### 全文件合同复核与可执行判据

前缀中的完整函数/分支表对同 hash 仍适用。下表补齐当前语义归属、可执行验证判据和证据层次。所有“判据”均为明确输入/动作/观察，不是本轮执行；旧29顶层通过只按历史记录引用。本文件基线和当前都没有内联测试，数量均为0。

| 范围 / 所有定义族 | 完整边界与当前理解 | 行为判据及证据归属 |
| --- | --- | --- |
| 1–47 imports、两个默认常量、ContextBudget/default、TokenEstimate、CompactionCheckpoint、PreparedContext | 默认max128000、reserve8192；估算显式 approximate；legacy marker六字段无version/session/branch；PreparedContext持有投影副本，不改变输入。serde派生并不使所有结构都拒未知字段；semantic下述特定结构另有deny_unknown_fields。 | 默认预算和返回副本应符合字段；更改返回副本不能改只读source。旧context deterministic/estimate用例相关；常量和类型完整读，无新编译或序列化执行。 |
| 49–63 estimate_tokens | UTF-8 content字节、每条16和metadata JSON字节以u64 saturating相加，ceil/4。metadata编码失败使用MAX；不单算ID/parent/time，也不加载外部图片文件。基线只以usize累加content+16，不计metadata，最终try_from才处理转换。 | 空输入0；非ASCII按字节；同content增加4000字节metadata应显著增加估算，approximate始终true。历史probe验证metadata增量；没有真实tokenizer精度实验，MAX饱和路径是静态分支。 |
| 65–88 has_opaque_provider_state、whole_turn_start | 顶层signature/thinking_signature键存在即保护（即便值null）；annotations需数组，元素type等于native_history或存在signature键。并非任意“native_history键存在”、也非递归扫描。User且无parent，或其steer.strategy精确为cancel_reissue才是semantic起点。 | 比较signature:null、annotations native_history、无关嵌套signature；只允许指定形状触发。把带parent User从普通metadata改cancel_reissue后才可成为cut候选。此谓词不验证steer权限；旧native用例只证明其实际样本。 |
| 90–196 prepare_context | 先拒max<=reserve，再fit直返且不查cancel；超预算只查一次cancel。System全部独立保留；倒扫非System后缀目标available.saturating_mul(3)/4，至少尝试最新条；第一保留ID在原slice的首次位置决定cut，未拒重复ID。cut0失败；prefix JSON SHA与四角色计数构成固定摘要；ID截16hash、时间prefix末条。System+summary+suffix最终重估超限则失败。 | fit+true取消谓词的调用次数仍0；超预算+true应Cancelled且source不变；相同历史生成相同checkpoint。构造最新大消息/System过多使最终预算失败。历史4项context及5probe覆盖主要路径，未据此承诺所有溢出边界已实测。 |
| 198–262 restore_checkpoint | 仅要求start0、非空范围且end<=len；重算prefix hash及精确count文本；返所有System+摘要+非System尾部。estimated before/after不被检验，无预算/cancel/branch参数；输入source不变。 | 篡改prefix/summary应InvalidCheckpoint；只改estimated字段不应因此拒绝；追加很大尾部仍可restore。历史probe已记录可分裂parent组和恢复超旧budget，兼容helper不能冒称语义保真。 |
| 264–325 ContextError、version2/64KiB、CheckpointSource、UnresolvedContextCall、SemanticCheckpoint、Plan | 五错误类型保留；semantic三个公开持久结构deny_unknown_fields；Source绑定session/branch/tip/records/完整SHA，checkpoint另存cut/covered SHA/tail IDs/文件/未完成call/summary身份与usage。Plan checkpoint私有，仅经prepare构造并只读访问。 | legacy JSON不能直接当version2，篡改source/cut/tail/hash/version应拒绝；不能从外部随意填私有plan。旧checkpoint八测试相关。Usage引用外部结构，不能把外层deny_unknown_fields扩写成所有嵌套值的保证。 |
| 327–363 context_digest、valid_context_id、failed_context_assistant | digest是完整Turn JSON，含未被token estimate单算的ID/parent/time/metadata。合法ID非全空白、<=protocol128B、无control；允许周边空格。failed只作用Assistant，读顶层三种stop字段及annotations.finish_reason；error/aborted/deferred/cancelled为失败。 | 同content改timestamp仍应使source hash变化；全空/control/超128B ID应拒；带普通周边空格并非必拒；非Assistant同样错误metadata不按此函数过滤。此处是完整分支阅读与判据，无新增runtime结果。 |
| 365–435 checkpoint_skeleton前半 | session/branch合法，0<end<len，end指完整User，prefix有非System且无opaque。全ancestry ID合法唯一，parent如有须已经出现。Tool无metadata拒；有tool_calls字段必须为非failed Assistant、有parent、数组且每call ID/name合法/args object，同(parent,callID)唯一，记录可选path字符串。 | 改parent为不存在/晚出现、重复记录ID、重复同组call、bad args或failed Assistant带tool_calls均拒；跨不同parent可复用callID。历史probe证明parent可以是更早System，本层“存在”不等于“角色User”。 |
| 437–503 skeleton后半与完整输出 | Tool parent/call_id须匹配已见call，拒重复result及可解析字符串tool_name不匹配；省略/非字符串tool_name不强制拒。只有outcome精确unknown_outcome标unknown；只有prefix succeeded结果及path才纳入成功文件集，read_file/list_directory/search_text→reads，write_file/edit_file→writes。prefix call未回/跨cut/unknown拒；tail未回/unknown列入unresolved；BTree容器排序、去重，两文件集合独立。 | 一次call配多个result拒；结果跨cut拒；denied写不计modified；unknown前缀不能压，tail保留未知对象；同path读写同时存在两表。历史pair/unknown/failed_write样本相关。不查磁盘真实效果，未知其它outcome不自动等价unknown。 |
| 505–531 prepare_semantic_compaction | 入口及每候选前查cancel；从最新完整User切点倒退，tail估算达到keep_recent_tokens下限且skeleton成功才选。该参数不是上限；无ContextBudget参数。无候选或各skeleton失败统一InvalidCheckpoint，skeleton的具体失败未作为细化错误返回。 | 太大的keep_recent_tokens可使无可压候选；仅最后完整turn保留阈值满足时选择最靠后合法cut；cancel在入口/候选检查可中止。没有候选内逐记录响应上限；旧样例非全规模性能证明。 |
| 533–585 source_end/source/finalize | getters只读。finalize入口cancel，按原session/branch/end重建整个skeleton并严格相等，拒prepare后源变化；填summary SHA/provider/model/usage，再restore验证预算及checkpoint，最后再cancel。低层finalize不调用严格Completion validator。 | prepare后追加/修改一条再finalize应stale；空summary/非法provider或model/超64KiB/预算不足拒；普通非JSON文本+零usage仍可低层接受。历史probe实测该层差异；不证明生产Agent可绕过严格检查。 |
| 587–658 restore_semantic_checkpoint | 先有效预算，再version/session/branch/records/非空且<=64KiB summary/合法provider与model/hash；按原records重建skeleton并逐字段比较，再对全部当前ancestry重验，允许合法追加。保留prefix System，插入hash前24位命名的summary System，附source/文件/未完成元数据，append过滤failed Assistant的tail，重估最终budget。 | 原source变动、另branch/session、删原记录、篡改retained_ids/summary拒；合法新记录继续保留，坏新parent/result拒；tail failed Assistant不投影。恢复追加后checkpoint元数据仍属于生成时快照，不能误称unresolved列表实时刷新；tail真实记录保留新结果。 |
| 660–676 SemanticSummary、SUMMARY_INSTRUCTIONS | 九个必需数组：六语义字符串组、read_files、modified_files、unresolved_tools；严格未知字段拒绝。指令要求总结数据、不继续其任务、不把unknown写成完成，但只是模型提示。 | 缺任一组/未知键/结构非JSON应拒；合法结构不能证明事实忠实或防止所有模型误述。历史fixture只验证已知约束传递，非外部模型质量测评。 |
| 678–725 summary_request_data | 重建plan精确匹配；previous存在时用MAX预算restore作完整性校验，并要求旧end严格小于新end。发送previous_summary字符串和新覆盖records，后者含id/parent/role/content/metadata且过滤failed Assistant；附当前plan文件/未完成对象，不发HTTP、不改journal。 | 首轮previous=null；下一轮仅新增覆盖片段；旧end>=新end、跨branch/stale previous应拒。历史迭代HTTP样例相关；MAX用于检查不能当真实请求预算批准，实际请求还含system/prompt等开销。 |
| 727–807 validate_summary_completion | usage必需，input/output>0，output<=limit，input+output checked不溢出、total>=sum；拒任何Some refusal、tool calls、空/超64KiB、annotations truncated或length/max_tokens/error/aborted/cancelled/incomplete；deferred及其它未知状态不在黑名单。严格九段JSON，六语义组不能全空，八字符串组每组<=64、每条非空<=4096B无NUL；read/modified/unresolved须与plan逐项且顺序相同；规范JSON输出并返usage。 | 同合法payload仅换length应拒、deferred当前可过；改文件排序/漏未完成对象/输出超limit/usage和溢出/额外字段应拒。历史completion probe及invalid-summary套件有真实样例；校验不证明供应商计费或摘要语义。本层没有请求input上限参数，需core另查。 |

上述所有函数只读输入并计算返回值。错误不在本文件写journal、结算成本、重试网络或切换会话。取消只在已列位置发生；restore、request-data、strict validator都无cancel参数。大JSON分配/哈希、整ancestry扫描及多cut重复计算没有逐记录取消或固定时间上限；本轮未测性能，不签署当前TUI响应性。legacy路径的计数摘要与semantic version2并存，不能删除或误标历史marker以“消除”差异。

### 与 pi 源合同的精确差异

本轮源上下文是 `packages/agent/src/harness/compaction/compaction.ts` hash `6e7aec0d27cb566f8f85f7dd13850eda98f5ddf7e78f9a919fb3dd03c3ea3a8a`及utils.ts的1–65行；只复核列明片段，不接受012、utils或目录。前缀“对照源”应按以下限定理解：

* **估算和预算来源不同。** pi estimateContextTokens在有末次assistant usage时，用其usage加后续heuristic；usage总量可包含cacheRead/cacheWrite。无usage则按不同message内容估算，图片每块估4800字符，thinking/toolCall/自定义/工具结果/bash/分支摘要各有分支，字符计数除4。zenpi当前函数从所有Turn UTF-8字节+固定16+metadata JSON估算，没有供应商usage作为历史锚点，也无独立图片估算。pi设置enabled/reserve16384/keepRecent20000，shouldCompact检查开关及window-reserve；zenpi本文件的默认128000/8192和keep_recent下限不等同这些控制，当前core决定是否生成和输入/输出预算。
* **切分能力不同。** pi允许user、assistant及若干用户可见entry作为有效切点，排除toolResult；非User切点可回溯turnStart并标isSplitTurn，prepare生成history、turnPrefix和retainedTail；compact可分别生成历史/turn-prefix摘要再合并。zenpi只在whole_turn_start所允许的User边界切，且额外校验完整call/result/unknown配对。它没有source的split-turn二段生成模式；更保守切点意味着某些大单turn无法在本层压缩，不能声称全面复刻源分段能力。
* **增量保留载体不同。** pi从上一compaction.retainedTail构造虚拟entry，追加之后的path entries，携带previousSummary；zenpi始终绑定完整原ancestry和source hash，previous summary作为独立字符串，传新覆盖原records，tail由原journal恢复。双方有迭代摘要概念，不能交换持久schema。
* **文件列表含义不同，不能从名称推等价。** pi utils.extractFileOpsFromMessage读取Assistant的read/write/edit **toolCall** path，并不在该函数核对成功toolResult；computeFileLists将written+edited合并为modified，再从read排除modified。zenpi读取匹配工具结果、仅明确succeeded才计prefix文件，且read/modified独立，可重叠。前缀关于“从真实工具结果提取”描述的是zenpi当前约束，不能扩大为这两个pi函数的契约。
* **生成与校验层不同。** pi生成函数通过注入request执行请求，输出上限为0.8×reserve并受model.maxTokens约束，可加入customInstructions/thinking，选更新或初次提示；对aborted/error返回typed错误，成功提取文本+usage，再格式化文件列表。zenpi context.rs不调用request；要求九段严格JSON与更强source/usage/集合一致性，source文本summary不能直接视为合格zenpi Completion。两者均不能凭格式校验保证自然语言摘要事实正确。

这些是对实际片段的静态比较，不是源测试运行，也不把源片段结构提取算成整源文件understand。

### 当前宿主接线：新增静态观察

当前core hash `52311b129c0bb467abac36de216f5bc97bf3c4c42d03dcd6170a717339c2a869`，session hash `8fb3ff2c387b13d34d8bbe4533bb2b0a81b5e546f5e03216b74b5cf2c61c9a2b`。protocol128B ID常量、backend Usage/Completion和core Turn的定义另有hash片段。完整hash/行范围见context-index.json，均只用于本073映射。

core1749–1808先对当前provider投影估算，fit直接返回；超限时取selected_history、session/branch及previous checkpoint，keep_tokens取可用输入的一半，经InputPump准备plan，再生成request data和模型描述，summary output_limit是实际request reserve与4096的较小值。context只负责其中的纯函数，不把InputPump/预算账本/网络归成本文件能力。

core1962–2025在返回后再次检查cancel和实际input usage+output_limit是否超过request max，依次 **validate_summary_completion→finalize(重新selected_history)→append_semantic_checkpoint_for_operation→restore**。这次是当前hash的可见调用顺序，补充前文仅历史host观察；它不是新runtime通过，也不声称搜索已排除所有其它入口。core4894–4922只在存在semantic checkpoint时恢复provider投影，否则用完整selected history，不把legacy count/digest当语义替代。

session1225–1290公共append可不带operation；带operation时须有未完成Compaction marker。append先cancel，再取selected_tree_turns/branch，要求当前source.records完全等于selected长度、branch匹配，调用restore；相同完整event返回false，否则再cancel后append_event。对比restore允许追加记录，**提交时source必须仍是精确当前长度**，两者职责不同。低层append仍不调用strict Completion validator，因此plain summary/零usage的历史例证不能改写为“所有session写入都强校验模型响应”。session1343–1387片段按checkpoint tip查tree ancestry、确认深度并restore，再筛选所选branch和tip可见性；最终按当前turns/budget恢复。真实持久化/重启/operation恢复不由本073接受。

### 历史实际、本轮实际与门禁

历史3.1.16运行是4 context+8 checkpoint+12 semantic+5 review probe=**29个顶层通过、0失败**，另2个ignored子进程helper不增加分母；历史HTTP/独立进程/取消/kill场景的限度详见原包assertion-review.md及原日志。本轮读了其断言索引并完整保全归档、嵌套manifest和原输入；context同hash仅支持本文件身份，不证明当前完整依赖闭包相同。当前新增Cargo/Node/PTY/HTTP/网络/产品运行数均为0，未重放历史脚本。

本轮实际仅为连续完整阅读、旧包/源/前缀/归档/上下文hash核验、报告补丁的私有正向应用和反向恢复。`verify.py`不启动旧replay脚本，只用Python标准库读取证据和Git在临时私有目录检查两个互斥报告补丁；结构通过不是G-FILE语义通过，也不是G-STAGE --item ZS1-073执行。主控仍独立审查完整报告，绑定实际snapshot/集成revision并运行规定门禁，不生成伪造worker/master接受回执。

唯一交付路径仍为 `Docs/learn/stage1_pi_mono/targets/zenpi/files/src/context.rs_learn.md`。工作区当前是27,482字节完整旧报告，使用append-report.patch；主库捕获时仍是3,036字节原基线报告、hash `08f9dc2204499b1431e049bb6e42c5677a24eb4934f4c3672cf3f17063b5219b`，使用report-from-main.patch。两补丁得到同一新全文，原主库3,036字节已经完整保存在旧报告前缀的“主控原基线报告逐字节保留副本”中，并另存receiver-base.md；不能把任意其它接收状态当作该精确基底强行覆盖。所有旧ready保持不变；本轮完成一次交付后停止等待。
