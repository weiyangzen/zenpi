# ZS1-073 refreshed single-file understand candidate

Sole canonical deliverable: `files/Docs/learn/stage1_pi_mono/targets/zenpi/files/src/context.rs_learn.md`.
Its first27,482 bytes preserve the previous complete report exactly; the current appendix binds current context observations, full contract criteria and source differences. No context.rs source delta exists.

Choose one exact-input patch: `report-from-main.patch` for the captured3,036-byte main baseline report, or `append-report.patch` for the existing27,482-byte complete report. Both yield identical bytes; reconcile any other state before integration. The original main baseline report remains verbatim at the end of the preserved historical prefix and in receiver-base.md.

`history/prior-ready.tar.gz` preserves the complete prior ready including its original large evidence patch. That old patch is archival only; neither current report patch writes historical evidence directories or any product file. Nested historical runtime scripts must not be confused with current execution; none was run.

Run `python3 verify.py`: standard-library archive/hash/coverage checks plus Git apply/reverse in new private temporary directories. No Cargo/Node/PTY/HTTP/network or product execution. Master still owns G-FILE semantic review and G-STAGE --item ZS1-073. `authority.json` is the start-time authority; `boundary-after.json` records later snapshot changes separately.
