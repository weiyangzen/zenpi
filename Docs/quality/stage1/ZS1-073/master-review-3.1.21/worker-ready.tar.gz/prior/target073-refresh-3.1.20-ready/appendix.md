
---

## 2026-09-12 再次刷新：完整源文件不变，补绑定当前调用者与源差异

本节是最新 worker understand 记录，前 **27,482 字节**保持原样，SHA256 `80e0eed1be1be173bfef61d666e1125694d91180bf183e60af7550b069fef071`。该前缀来自完整 `.ops/target073-review-3.1.20-ready`，其 manifest SHA256 `c934a5627654ad5e622a213e420b5fba9d44dd8bc52ef33df2b1ab538121bb87`，13 个 files payload 和独立 candidate.patch 均校验后原样归档。前缀包含更早 3.1.16 报告及主控原基线报告，它们的“本次”“current”“新 probe”“当前未重读”等均属于各自历史时点。本节不改旧 authority、断言、运行日志或接受状态。

唯一当前文件是 `src/context.rs`，**30,013 B /807 行**，SHA256 `256d9ac1657e272ba61ebfbc242ece2970ed0607f3ebb1583b1711f18b7bf229`；冻结基线 **8,199 B /246 行**，SHA256 `bc4ce7999a0f4d162effece8c6f839aca3a230e97675a1d7908fca5d6a7fe909`。当前与前一次完整报告、历史实测 context.rs 逐字节一致，**没有本文件源码 delta**。本轮仍完整连续读基线1–246、当前1–290/291–570/571–807；`read-coverage.json`绑定全部字节及所有常量、类型、impl、函数的定位。库存/哈希只是覆盖交叉检查，语义依据是完整阅读及下述具体合同。

捕获时 authority3.1.20、requirement digest `8d525b351d066ce9b0487a485337647d47233275782e4f4d154423a623fe1645`、snapshot `20e38b23c6550422c993cc241f9ffa9daeb4443e6d4f050fdd370ba6d54268f9`。主控说明089可能仅改变 checkbox/snapshot；`authority.json`保存起点，`boundary-after.json`另记录结束时实际值，不能把同一 requirement 下的两次 snapshot 混写成同一时点。未修改 main、产品、blueprint、claims、selector、旧 ready 或已有 canonical 报告。

### 全文件合同复核与可执行判据

前缀中的完整函数/分支表对同 hash 仍适用。下表补齐当前语义归属、可执行验证判据和证据层次。所有“判据”均为明确输入/动作/观察，不是本轮执行；旧29顶层通过只按历史记录引用。本文件基线和当前都没有内联测试，数量均为0。

| 范围 / 所有定义族 | 完整边界与当前理解 | 行为判据及证据归属 |
| --- | --- | --- |
| 1–47 imports、两个默认常量、ContextBudget/default、TokenEstimate、CompactionCheckpoint、PreparedContext | 默认max128000、reserve8192；估算显式 approximate；legacy marker六字段无version/session/branch；PreparedContext持有投影副本，不改变输入。serde派生并不使所有结构都拒未知字段；semantic下述特定结构另有deny_unknown_fields。 | 默认预算和返回副本应符合字段；更改返回副本不能改只读source。旧context deterministic/estimate用例相关；常量和类型完整读，无新编译或序列化执行。 |
| 49–63 estimate_tokens | UTF-8 content字节、每条16和metadata JSON字节以u64 saturating相加，ceil/4。metadata编码失败使用MAX；不单算ID/parent/time，也不加载外部图片文件。基线只以usize累加content+16，不计metadata，最终try_from才处理转换。 | 空输入0；非ASCII按字节；同content增加4000字节metadata应显著增加估算，approximate始终true。历史probe验证metadata增量；没有真实tokenizer精度实验，MAX饱和路径是静态分支。 |
| 65–88 has_opaque_provider_state、whole_turn_start | 顶层signature/thinking_signature键存在即保护（即便值null）；annotations需数组，元素type等于native_history或存在signature键。并非任意“native_history键存在”、也非递归扫描。User且无parent，或其steer.strategy精确为cancel_reissue才是semantic起点。 | 比较signature:null、annotations native_history、无关嵌套signature；只允许指定形状触发。把带parent User从普通metadata改cancel_reissue后才可成为cut候选。此谓词不验证steer权限；旧native用例只证明其实际样本。 |
| 90–196 prepare_context | 先拒max<=reserve，再fit直返且不查cancel；超预算只查一次cancel。System全部独立保留；倒扫非System后缀目标available.saturating_mul(3)/4，至少尝试最新条；第一保留ID在原slice的首次位置决定cut，未拒重复ID。cut0失败；prefix JSON SHA与四角色计数构成固定摘要；ID截16hash、时间prefix末条。System+summary+suffix最终重估超限则失败。 | fit+true取消谓词的调用次数仍0；超预算+true应Cancelled且source不变；相同历史生成相同checkpoint。构造最新大消息/System过多使最终预算失败。历史4项context及5probe覆盖主要路径，未据此承诺所有溢出边界已实测。 |
| 198–262 restore_checkpoint | 仅要求start0、非空范围且end<=len；重算prefix hash及精确count文本；返所有System+摘要+非System尾部。estimated before/after不被检验，无预算/cancel/branch参数；输入source不变。 | 篡改prefix/summary应InvalidCheckpoint；只改estimated字段不应因此拒绝；追加很大尾部仍可restore。历史probe已记录可分裂parent组和恢复超旧budget，兼容helper不能冒称语义保真。 |
| 264–325 ContextError、version2/64KiB、CheckpointSource、UnresolvedContextCall、SemanticCheckpoint、Plan | 五错误类型保留；semantic三个公开持久结构deny_unknown_fields；Source绑定session/branch/tip/records/完整SHA，checkpoint另存cut/covered SHA/tail IDs/文件/未完成call/summary身份与usage。Plan checkpoint私有，仅经prepare构造并只读访问。 | legacy JSON不能直接当version2，篡改source/cut/tail/hash/version应拒绝；不能从外部随意填私有plan。旧checkpoint八测试相关。Usage引用外部结构，不能把外层deny_unknown_fields扩写成所有嵌套值的保证。 |
| 327–363 context_digest、valid_context_id、failed_context_assistant | digest是完整Turn JSON，含未被token estimate单算的ID/parent/time/metadata。合法ID非全空白、<=protocol128B、无control；允许周边空格。failed只作用Assistant，读顶层三种stop字段及annotations.finish_reason；error/aborted/deferred/cancelled为失败。 | 同content改timestamp仍应使source hash变化；全空/control/超128B ID应拒；带普通周边空格并非必拒；非Assistant同样错误metadata不按此函数过滤。此处是完整分支阅读与判据，无新增runtime结果。 |
| 365–435 checkpoint_skeleton前半 | session/branch合法，0<end<len，end指完整User，prefix有非System且无opaque。全ancestry ID合法唯一，parent如有须已经出现。Tool无metadata拒；有tool_calls字段必须为非failed Assistant、有parent、数组且每call ID/name合法/args object，同(parent,callID)唯一，记录可选path字符串。 | 改parent为不存在/晚出现、重复记录ID、重复同组call、bad args或failed Assistant带tool_calls均拒；跨不同parent可复用callID。历史probe证明parent可以是更早System，本层“存在”不等于“角色User”。 |
| 437–503 skeleton后半与完整输出 | Tool parent/call_id须匹配已见call，拒重复result及可解析字符串tool_name不匹配；省略/非字符串tool_name不强制拒。只有outcome精确unknown_outcome标unknown；只有prefix succeeded结果及path才纳入成功文件集，read_file/list_directory/search_text→reads，write_file/edit_file→writes。prefix call未回/跨cut/unknown拒；tail未回/unknown列入unresolved；BTree容器排序、去重，两文件集合独立。 | 一次call配多个result拒；结果跨cut拒；denied写不计modified；unknown前缀不能压，tail保留未知对象；同path读写同时存在两表。历史pair/unknown/failed_write样本相关。不查磁盘真实效果，未知其它outcome不自动等价unknown。 |
| 505–531 prepare_semantic_compaction | 入口及每候选前查cancel；从最新完整User切点倒退，tail估算达到keep_recent_tokens下限且skeleton成功才选。该参数不是上限；无ContextBudget参数。无候选或各skeleton失败统一InvalidCheckpoint，skeleton的具体失败未作为细化错误返回。 | 太大的keep_recent_tokens可使无可压候选；仅最后完整turn保留阈值满足时选择最靠后合法cut；cancel在入口/候选检查可中止。没有候选内逐记录响应上限；旧样例非全规模性能证明。 |
| 533–585 source_end/source/finalize | getters只读。finalize入口cancel，按原session/branch/end重建整个skeleton并严格相等，拒prepare后源变化；填summary SHA/provider/model/usage，再restore验证预算及checkpoint，最后再cancel。低层finalize不调用严格Completion validator。 | prepare后追加/修改一条再finalize应stale；空summary/非法provider或model/超64KiB/预算不足拒；普通非JSON文本+零usage仍可低层接受。历史probe实测该层差异；不证明生产Agent可绕过严格检查。 |
| 587–658 restore_semantic_checkpoint | 先有效预算，再version/session/branch/records/非空且<=64KiB summary/合法provider与model/hash；按原records重建skeleton并逐字段比较，再对全部当前ancestry重验，允许合法追加。保留prefix System，插入hash前24位命名的summary System，附source/文件/未完成元数据，append过滤failed Assistant的tail，重估最终budget。 | 原source变动、另branch/session、删原记录、篡改retained_ids/summary拒；合法新记录继续保留，坏新parent/result拒；tail failed Assistant不投影。恢复追加后checkpoint元数据仍属于生成时快照，不能误称unresolved列表实时刷新；tail真实记录保留新结果。 |
| 660–676 SemanticSummary、SUMMARY_INSTRUCTIONS | 九个必需数组：六语义字符串组、read_files、modified_files、unresolved_tools；严格未知字段拒绝。指令要求总结数据、不继续其任务、不把unknown写成完成，但只是模型提示。 | 缺任一组/未知键/结构非JSON应拒；合法结构不能证明事实忠实或防止所有模型误述。历史fixture只验证已知约束传递，非外部模型质量测评。 |
| 678–725 summary_request_data | 重建plan精确匹配；previous存在时用MAX预算restore作完整性校验，并要求旧end严格小于新end。发送previous_summary字符串和新覆盖records，后者含id/parent/role/content/metadata且过滤failed Assistant；附当前plan文件/未完成对象，不发HTTP、不改journal。 | 首轮previous=null；下一轮仅新增覆盖片段；旧end>=新end、跨branch/stale previous应拒。历史迭代HTTP样例相关；MAX用于检查不能当真实请求预算批准，实际请求还含system/prompt等开销。 |
| 727–807 validate_summary_completion | usage必需，input/output>0，output<=limit，input+output checked不溢出、total>=sum；拒任何Some refusal、tool calls、空/超64KiB、annotations truncated或length/max_tokens/error/aborted/cancelled/incomplete；deferred及其它未知状态不在黑名单。严格九段JSON，六语义组不能全空，八字符串组每组<=64、每条非空<=4096B无NUL；read/modified/unresolved须与plan逐项且顺序相同；规范JSON输出并返usage。 | 同合法payload仅换length应拒、deferred当前可过；改文件排序/漏未完成对象/输出超limit/usage和溢出/额外字段应拒。历史completion probe及invalid-summary套件有真实样例；校验不证明供应商计费或摘要语义。本层没有请求input上限参数，需core另查。 |

上述所有函数只读输入并计算返回值。错误不在本文件写journal、结算成本、重试网络或切换会话。取消只在已列位置发生；restore、request-data、strict validator都无cancel参数。大JSON分配/哈希、整ancestry扫描及多cut重复计算没有逐记录取消或固定时间上限；本轮未测性能，不签署当前TUI响应性。legacy路径的计数摘要与semantic version2并存，不能删除或误标历史marker以“消除”差异。

### 与 pi 源合同的精确差异

本轮源上下文是 `packages/agent/src/harness/compaction/compaction.ts` hash `6e7aec0d27cb566f8f85f7dd13850eda98f5ddf7e78f9a919fb3dd03c3ea3a8a`及utils.ts的1–65行；只复核列明片段，不接受012、utils或目录。前缀“对照源”应按以下限定理解：

* **估算和预算来源不同。** pi estimateContextTokens在有末次assistant usage时，用其usage加后续heuristic；usage总量可包含cacheRead/cacheWrite。无usage则按不同message内容估算，图片每块估4800字符，thinking/toolCall/自定义/工具结果/bash/分支摘要各有分支，字符计数除4。zenpi当前函数从所有Turn UTF-8字节+固定16+metadata JSON估算，没有供应商usage作为历史锚点，也无独立图片估算。pi设置enabled/reserve16384/keepRecent20000，shouldCompact检查开关及window-reserve；zenpi本文件的默认128000/8192和keep_recent下限不等同这些控制，当前core决定是否生成和输入/输出预算。
* **切分能力不同。** pi允许user、assistant及若干用户可见entry作为有效切点，排除toolResult；非User切点可回溯turnStart并标isSplitTurn，prepare生成history、turnPrefix和retainedTail；compact可分别生成历史/turn-prefix摘要再合并。zenpi只在whole_turn_start所允许的User边界切，且额外校验完整call/result/unknown配对。它没有source的split-turn二段生成模式；更保守切点意味着某些大单turn无法在本层压缩，不能声称全面复刻源分段能力。
* **增量保留载体不同。** pi从上一compaction.retainedTail构造虚拟entry，追加之后的path entries，携带previousSummary；zenpi始终绑定完整原ancestry和source hash，previous summary作为独立字符串，传新覆盖原records，tail由原journal恢复。双方有迭代摘要概念，不能交换持久schema。
* **文件列表含义不同，不能从名称推等价。** pi utils.extractFileOpsFromMessage读取Assistant的read/write/edit **toolCall** path，并不在该函数核对成功toolResult；computeFileLists将written+edited合并为modified，再从read排除modified。zenpi读取匹配工具结果、仅明确succeeded才计prefix文件，且read/modified独立，可重叠。前缀关于“从真实工具结果提取”描述的是zenpi当前约束，不能扩大为这两个pi函数的契约。
* **生成与校验层不同。** pi生成函数通过注入request执行请求，输出上限为0.8×reserve并受model.maxTokens约束，可加入customInstructions/thinking，选更新或初次提示；对aborted/error返回typed错误，成功提取文本+usage，再格式化文件列表。zenpi context.rs不调用request；要求九段严格JSON与更强source/usage/集合一致性，source文本summary不能直接视为合格zenpi Completion。两者均不能凭格式校验保证自然语言摘要事实正确。

这些是对实际片段的静态比较，不是源测试运行，也不把源片段结构提取算成整源文件understand。

### 当前宿主接线：新增静态观察

当前core hash `52311b129c0bb467abac36de216f5bc97bf3c4c42d03dcd6170a717339c2a869`，session hash `8fb3ff2c387b13d34d8bbe4533bb2b0a81b5e546f5e03216b74b5cf2c61c9a2b`。protocol128B ID常量、backend Usage/Completion和core Turn的定义另有hash片段。完整hash/行范围见context-index.json，均只用于本073映射。

core1749–1808先对当前provider投影估算，fit直接返回；超限时取selected_history、session/branch及previous checkpoint，keep_tokens取可用输入的一半，经InputPump准备plan，再生成request data和模型描述，summary output_limit是实际request reserve与4096的较小值。context只负责其中的纯函数，不把InputPump/预算账本/网络归成本文件能力。

core1962–2025在返回后再次检查cancel和实际input usage+output_limit是否超过request max，依次 **validate_summary_completion→finalize(重新selected_history)→append_semantic_checkpoint_for_operation→restore**。这次是当前hash的可见调用顺序，补充前文仅历史host观察；它不是新runtime通过，也不声称搜索已排除所有其它入口。core4894–4922只在存在semantic checkpoint时恢复provider投影，否则用完整selected history，不把legacy count/digest当语义替代。

session1225–1290公共append可不带operation；带operation时须有未完成Compaction marker。append先cancel，再取selected_tree_turns/branch，要求当前source.records完全等于selected长度、branch匹配，调用restore；相同完整event返回false，否则再cancel后append_event。对比restore允许追加记录，**提交时source必须仍是精确当前长度**，两者职责不同。低层append仍不调用strict Completion validator，因此plain summary/零usage的历史例证不能改写为“所有session写入都强校验模型响应”。session1343–1387片段按checkpoint tip查tree ancestry、确认深度并restore，再筛选所选branch和tip可见性；最终按当前turns/budget恢复。真实持久化/重启/operation恢复不由本073接受。

### 历史实际、本轮实际与门禁

历史3.1.16运行是4 context+8 checkpoint+12 semantic+5 review probe=**29个顶层通过、0失败**，另2个ignored子进程helper不增加分母；历史HTTP/独立进程/取消/kill场景的限度详见原包assertion-review.md及原日志。本轮读了其断言索引并完整保全归档、嵌套manifest和原输入；context同hash仅支持本文件身份，不证明当前完整依赖闭包相同。当前新增Cargo/Node/PTY/HTTP/网络/产品运行数均为0，未重放历史脚本。

本轮实际仅为连续完整阅读、旧包/源/前缀/归档/上下文hash核验、报告补丁的私有正向应用和反向恢复。`verify.py`不启动旧replay脚本，只用Python标准库读取证据和Git在临时私有目录检查两个互斥报告补丁；结构通过不是G-FILE语义通过，也不是G-STAGE --item ZS1-073执行。主控仍独立审查完整报告，绑定实际snapshot/集成revision并运行规定门禁，不生成伪造worker/master接受回执。

唯一交付路径仍为 `Docs/learn/stage1_pi_mono/targets/zenpi/files/src/context.rs_learn.md`。工作区当前是27,482字节完整旧报告，使用append-report.patch；主库捕获时仍是3,036字节原基线报告、hash `08f9dc2204499b1431e049bb6e42c5677a24eb4934f4c3672cf3f17063b5219b`，使用report-from-main.patch。两补丁得到同一新全文，原主库3,036字节已经完整保存在旧报告前缀的“主控原基线报告逐字节保留副本”中，并另存receiver-base.md；不能把任意其它接收状态当作该精确基底强行覆盖。所有旧ready保持不变；本轮完成一次交付后停止等待。
