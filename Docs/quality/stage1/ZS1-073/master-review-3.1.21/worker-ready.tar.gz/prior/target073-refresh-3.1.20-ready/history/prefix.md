# ZS1-073 — src/context.rs 完整 owner 复核

状态：[_] 当前hash阅读/行为候选，主控未接受。Authority3.1.16；requirement digest `c0262492bc6e3b4d5f56b35bedc7c1d1658854df11c4a975eb612a514cceef8f`。

Subject为主控只读快照，807行/30013字节/SHA256 `256d9ac1657e272ba61ebfbc242ece2970ed0607f3ebb1583b1711f18b7bf229`。全文按1–290、291–570、571–807逐行读取，完整字节并集[0,30013)，见read-coverage.json。本次没有产品修改。

已有主控073报告仅对应246行/8199字节/hash `bc4ce7999a0f4d162effece8c6f839aca3a230e97675a1d7908fca5d6a7fe909`，已在旧input-host-before快照找到完全一致文件并冻结。另核验冻结ZS1-104候选的context.rs原字节与当前subject完全相同；只复用该历史身份/设计背景，仍重新完整读807行并执行当前上下文测试。旧包authority3.1.6保持不变，不回写成当前版本。

## 职责与来源关系

context是纯准备/校验/投影层：估算上下文、构造legacy digest checkpoint、选择semantic完整turn切点、验证source/summary、组装摘要请求与恢复后的provider输入。它本身没有网络、journal写入、费用结算、provider重试、模型选择或operation recovery owner。生成summary、持久化与取消/预算生命周期在core/session/backend/governance。

对照冻结pi compaction源项012：增量请求携带previous_summary与新覆盖records；保留新近完整turn，不把未完成或unknown工具结果压成成功；从真实工具结果提取文件操作信息。Zenpi另加入source session/branch/hash、usage与严格JSON sections等本地owner约束。旧digest只保存数量和hash，不保存语义；生产core的context_source_for_provider明确在没有semantic checkpoint时返回完整selected history，不用旧digest替代事实。这是本次实际定位的调用路径，不能把legacy helper的弱约束当成当前provider自动压缩的全部实现。

## 全部类型、函数及分支

| 行 | 职责与分支 | owner/限制 |
|---|---|---|
| 1–47 | 默认budget128000/reserved8192；ContextBudget、TokenEstimate、legacy CompactionCheckpoint、PreparedContext | legacy checkpoint无schema/session/branch；估算一律approximate |
| 49–63 | estimate_tokens | 每turn content UTF-8字节+16+序列化metadata字节，saturating累加后ceil/4；metadata编码失败按MAX保守估算；不单独计ID/parent/timestamp/外部attachment实体 |
| 65–88 | has_opaque_provider_state、whole_turn_start | 识别顶层signature/thinking_signature或annotations native_history/signature；presence即保护（并非递归任意key扫描）。完整turn起点是无parent User，或metadata steer.strategy=cancel_reissue的User |
| 90–112 | prepare_context入口 | max<=reserve InvalidBudget；已fit直接clone返回，无checkpoint且不调用cancel；只有需压缩才检查一次cancel |
| 113–143 | legacy保留选择 | 所有System单独保留；逆扫非System，目标3/4 available，至少尝试最新一条；按首个保留ID找原位置；kept_start0报预算不足；不验证ID唯一、完整turn或工具配对 |
| 144–196 | legacy摘要/预算 | JSON hash覆盖prefix；数四种role生成固定count+SHA文本；summary ID取digest前16位，时间取prefix最后turn；protected system+summary+suffix再估算，超budget失败，否则返回六字段marker |
| 198–262 | restore_checkpoint | source_start须0、end非0且<=turns.len；prefix hash和固定summary文本必须相同；重组所有System+summary+非System suffix；不验证估算字段、不含restore budget/cancel参数 |
| 264–276 | ContextError | InvalidBudget/Cancelled/BudgetExceeded/Encoding/InvalidCheckpoint，纯typed错误无session副作用 |
| 278–325 | semantic version2、64KiB上限、CheckpointSource、UnresolvedContextCall、SemanticCheckpoint、Plan | source完整session/branch/tip/records/hash；covered hash、retained IDs、文件集、未完成call、summary hash/provider/model/usage；Plan字段私有不可外部随意构造 |
| 327–363 | context_digest、valid_context_id、failed_context_assistant | 整turn JSON含metadata/时间等；ID非空<=128B无control，但允许首尾非全空白；失败assistant识别顶层三种stop键及annotations.finish_reason的error/aborted/deferred/cancelled |
| 365–385 | checkpoint_skeleton切点前置 | session/branch合法；end在1..len且对应whole-turn User；覆盖prefix不得有opaque state，并须含非System记录 |
| 386–435 | ancestry/assistant calls扫描 | ID合法唯一；parent若有须在更早ID集合；Tool无metadata拒绝；tool_calls只能在非failed Assistant，需parent、数组、合法call/name、object arguments；(parent,call_id)唯一；抓取arguments.path字符串 |
| 437–467 | tool结果配对与路径集合 | Tool需parent/call ID并能匹配更早call；重复result或显式tool_name不匹配拒绝；记录result索引与unknown_outcome；仅prefix succeeded的read_file/list_directory/search_text路径计read，write_file/edit_file计modified；两个BTreeSet独立、排序去重、不canonicalize文件系统 |
| 469–503 | cut安全与skeleton输出 | prefix call若无结果、结果跨cut、或unknown则拒绝；tail未解决/unknown列入unresolved；source hash绑定完整原输入，covered hash绑定prefix，tail IDs按源顺序保存；summary字段初始空 |
| 505–531 | prepare_semantic_compaction | 入口cancel、每个候选cut前cancel；从最近User起点逆向找尾部estimate>=keep_recent_tokens且skeleton合法的第一个cut；无可用cut统一InvalidCheckpoint；没有可压prefix时不制造假summary |
| 533–585 | Plan accessors/finalize | 暴露source/end只读；先cancel、重建skeleton并要求全结构相同以拒stale；设置summary/hash/provider/model/usage后调用restore验证预算与source，最后再cancel；不调用严格completion JSON校验 |
| 587–625 | restore_semantic_checkpoint基本验证 | budget有效、version2、真实session/branch匹配、source.records不超过当前len；summary非空<=64KiB、provider/model ID合法、summary hash相同；按原records重建全部skeleton后与持久checkpoint逐字段相等 |
| 626–658 | 增量恢复/投影预算 | 全当前ancestry再skeleton校验，允许合法追加记录；保留覆盖prefix的System，插入summary System，append保留尾部但过滤failed assistant；summary ID用hash前24位，时间prefix末尾；重新估算超budget拒绝 |
| 660–676 | SemanticSummary及SUMMARY_INSTRUCTIONS | 9个必需数组，deny_unknown_fields；instructions要求只总结数据、保留要求/未完成工作/文件、不得把unknown写成完成；这是模型指令，不是语义真实性证明 |
| 678–725 | summary_request_data | 当前skeleton必须仍等于plan；previous有值先恢复验证，要求previous.end严格早于新cut；只发送新覆盖区间且过滤failed assistants；previous summary作为字符串字段，真实文件集/未解决对象由plan提供；无previous从0起 |
| 727–767 | validate_summary_completion外层 | usage必需且输入/输出>0，output<=limit，sum不可溢出且total>=sum；拒refusal、tool calls、空/超长内容；annotations truncated或指定失败/length状态拒绝 |
| 768–807 | completion结构校验与规范序列化 | 严格解析全部sections；六种语义section不能全空；八种字符串数组每个<=64条、每条非空<=4096B且无NUL；read/modified/unresolved必须逐项精确等于plan；最终重新serde编码并返回实际usage |

## 算法、边界和数据可信度

semantic切点保证至少保留新近User整个suffix，且不能把assistant call与result拆到两边；unknown或未返回的prefix call禁止覆盖。call ID按(parent turn ID,call ID)关联，允许不同turn复用同call ID。prefix System不被摘要替换，opaque原生签名状态不能进入被覆盖prefix。恢复先验证旧source原字节，再校验追加记录，因此不是仅凭summary文本或客户端retained_ids信任裁剪。

当前skeleton只检查parent ID存在，没有检查该parent的role一定User，也不访问session tree的真实branch选择；后者来自调用者传入完整selected ancestry和session owner。文件列表只从成功tool结果与call arguments提取，既不读真实文件，也不能从模型自由文本判断副作用完成。read和modified可以同时包含同一路径，不能误写成后者自动从前者去除。

finalize/restore是version2 checkpoint的数据完整性层；validate_summary_completion是生产生成结果的更严格层。core当前先调用严格validator，再finalize，再append_semantic_checkpoint_for_operation；session的低层append只调用restore校验而非completion validator。保留103公共低层API意味着通过finalize或session写入并不能反推summary曾有合法结构/真实provider usage。usage本身仍是调用方/adapter给的数据，校验不能证明供应商实际计费。合法section结构也不保证摘要事实正确；HTTP fixtures只验证已知测试约束确实保留。

Cancellation的检查点是有限的：legacy fit零次、legacy需压缩入口一次；semantic规划入口及候选cut之间、finalize开始/结束。大skeleton循环与哈希内部没有逐记录cancel；prepare在多次候选失败时重复扫描/估算与hash，也没有固定常数耗时保证。没有将此静态事实冒称实际性能基准或取消延迟故障。

## 本次实际证据

未修改product的快照执行：context4 + stage1_context_checkpoint8 + stage1_semantic_compaction12 + 新probe5 =29个顶层通过、0失败；2个独立进程helper在各自顶层listing标ignored，父测试启动输出不重复计数。semantic套件用真实loopback HTTP、临时journal、取消、被终止的独立进程与重开；没有外部模型调用或真实模型质量评估。全部源/既有测试输入hash与只读快照一致，仅新增独立review probe。

五个新观察：

1. 已fit的legacy context即使传入总返回true的cancel函数也成功，实际调用次数0；4000字节metadata使估算增加至少1000 token单位，证明当前已修正旧基线“完全不计metadata”的缺口。
2. legacy预算500的实际样例cut=1，只覆盖u1，但返回的assistant/tool仍parent=u1，而u1本体已被count摘要替换；它不保证完整turn ancestry。改checkpoint两项estimated计数为0仍可restore；再追加10万字节User，restore仍成功且超过原预算。源码和实测一致，不能给legacy restore添加不存在的预算保证。
3. 低层plan.finalize接受非JSON普通summary和Usage::default()；真实SessionStore.append_semantic_checkpoint写入后，重开仍得到该summary且usage.total=0。相同Completion::text直接过严格validator会失败。该探针证明层次差异，不宣称生产Agent绕过了validator。
4. Assistant与Tool共同指向更早的System ID，call/result其余字段有效时，skeleton接受并报告read_files。parent存在与“是User turn”不是同一约束；真实core正常生成的parent路径不能替代这项静态/实测边界。
5. 内容、sections和usage均有效的Completion，annotations.finish_reason=deferred能过严格validator；改为length则拒绝。failed_context_assistant把deferred列为失败，但summary completion黑名单没有它。探针只通过自建Completion证明本层行为，没有证明任何外部provider能产生同样完整成功payload。

现有8个checkpoint测试另证明multi-call完整配对、source/cut/tail/summary/branch篡改拒绝、未解决call保留tail、failed write不计modified、unknown prefix不可压缩、cancel/budget/stale/duplicate result拒绝、独立进程durable checkpoint及legacy兼容。12个semantic测试另覆盖真实HTTP结构化summary、迭代restart、截断/坏summary不替换旧checkpoint、额度/价格/源上限在HTTP前拒绝、取消不自动重试、native state计入并保留、分支绑定、late steer准备边界、headless手动compact响应取消、被kill后未知operation恢复。

## 后续定位与交付边界

当前生产core有严格validator顺序证据，legacy弱约束与低层finalize宽松性均按兼容API记录，不在阅读任务中擅自升级/改写历史checkpoint。deferred黑名单不一致与parent role约束缺口具备最小实际样例，可由主控结合backend/session契约决定是否修复；本次未修改产品、ledger、接受状态或104等旧包。073全文已覆盖，不把core/session/backend依赖定位充当其对应文件的完整接受。


---

## 3.1.20 单文件复核补充（旧报告原字节保留）

本节为 ZS1-073 worker 候选，authority `3.1.20`，requirement digest `8d525b351d066ce9b0487a485337647d47233275782e4f4d154423a623fe1645`。前 12667 字节完全保留，SHA-256 `cc48dfbf84a5f4da7e8b894d9a82b8c4abd3ea466a7cd9f39b0564470871d57b`；前文“本次实际证据”“新 probe”“core 当前”等措辞均属于原 3.1.16 历史记录，不代表本轮重新运行或重新检查当前宿主。旧 authority、原结论和旧日志没有改写。

本轮只完整学习 `src/context.rs`，未改产品、未跑 Cargo/PTY/HTTP。基线完整顺读 1–246 行，8199 字节，SHA-256 `bc4ce7999a0f4d162effece8c6f839aca3a230e97675a1d7908fca5d6a7fe909`。当前完整顺读 1–290、291–570、571–807 行，30013 字节，SHA-256 `256d9ac1657e272ba61ebfbc242ece2970ed0607f3ebb1583b1711f18b7bf229`；与旧实测对象逐字节相同。新 read-coverage.json 记录每段字节范围与 hash，两个文件均无遗漏。冻结基线身份没有被扩展后的当前文件替代。

### 基线与当前的完整关系

| 基线范围 | 当前范围 | 本轮确认的行为与变化 |
|---|---|---|
| 1–47 | 1–47 | 四种公开数据结构与默认 128000/8192 预算一致；TokenEstimate 明示 approximate，legacy marker 保存覆盖范围、digest、count 文本和前后估算 |
| 49–58 | 49–63 | 原估算只将 content.len()+16 用 usize 求和再 ceil/4；当前增加 JSON metadata 字节并以 u64 saturating_add 累加，编码失败取 MAX。仍不是供应商 tokenizer，ID/parent/time 和外部实体没有单独计入 |
| 无 | 65–88 | 新增 opaque-state 检测与 whole-turn User 判定，供 semantic 路径使用；legacy 路径没有获得这些保护 |
| 60–174 | 90–196 | legacy 核心算法仍为 System 全保留、非 System 逆扫后缀、3/4 可用预算、计数摘要、最终预算；当前只因 estimate 变化而改变实际切点/是否 fit |
| 175–232 | 198–262 | legacy restore 验 prefix digest 和固定摘要后投影；无预算、cancel、session/branch、parent/tool 配对验证；estimated 字段没有成为约束 |
| 234–246 | 264–276 | 五种 ContextError 不变 |
| 无 | 278–807 | 新增 semantic version2 的身份绑定、完整 turn 切点、call/result 检查、文件集合、prepare/finalize/restore、增量请求及严格 Completion 校验；前文全函数表逐段重新核对，无遗漏 |

基线和当前源文件都没有 `#[test]`、`#[cfg(test)]` 或内联测试模块，实际内联测试数均为 **0**。不能将外部 integration tests 或 review probes 写成该文件内联断言。为交代已有实测，另对历史包中的四个外部测试源查看真实断言，逐项列于 assertion-review.md；这些读取只服务于 073 的证据解释，不构成第二文件学习或接受。

### 当前完整运行路径、预算与取消

`prepare_context` 先拒 max<=reserve；fit 时直接返回所有 turns、None checkpoint，即使 cancel 为 true 也不调用它。需要压缩才查一次 cancel。所有 System 保留；倒序尝试非 System 的最新后缀，至少尝试一条，超过 suffix 目标且多于一条则撤回最后加入的较旧条目。首个保留 ID 的首次原位置成为 cut，重复 ID 不被此层拒绝；cut=0 报 BudgetExceeded。prefix JSON hash 与角色数生成固定文本，摘要 turn ID 为 digest 前16字符、timestamp 为 prefix 最后记录；最终按当前 metadata 估算再做预算。该计数文本不能保存旧事实，也不保证完整 User/Assistant/Tool 组。

`restore_checkpoint` 要求 start=0、0<end<=len，只验证覆盖 prefix 的 JSON hash 与固定 count 文本，返回所有当前 System、摘要、剩余非 System。没有“原预算仍满足”的承诺，合法追加也未被计入 checkpoint 的原估算字段验证。它接收只读 slices，不写 journal，失败也不修改输入。

semantic prepare 的 `keep_recent_tokens` 是保留尾部的最低估算目标，不是输入上限；从最近完整 User 起点向前找第一个 tail estimate>=目标且 skeleton 合法的 cut。User 无 parent，或 User 带 `steer.strategy=cancel_reissue`，才是起点；metadata 值本身不构成已授权 steer 的证明。无切点统一 InvalidCheckpoint。prepare 没有 ContextBudget 参数，真正的 provider 输入上限在 finalize 调用 restore 以及后续 restore 中检查。

prepare 入口和各候选之间查 cancel；finalize 开始与完成验证后查 cancel。估算、JSON 编码、哈希、全 ancestry skeleton 内部没有逐记录取消，restore/request-data/Completion validator 没有 cancel 参数。多个候选可重复全量扫描；本轮没有测耗时、内存或取消延迟，也不能承诺主控真实 TUI 不会阻塞。

### 当前输入、call/result 与 checkpoint 边界

CheckpointSource 绑定 session/branch/tip/records/完整输入 JSON SHA；covered_sha256 单独绑定 prefix，retained_ids 保留原顺序；所有 Turn ID 必须非全空白、字节不超协议上限、无 control、唯一，parent 若有必须早于当前。session/branch 必须同样合法；这不自行选择真实 session tree 分支。工具 call 需非失败 Assistant、有 parent、数组中合法 ID/name 和 object arguments，按 (parent, call_id) 唯一。Tool 需 metadata、parent 和匹配更早 call，拒第二 result、显式不匹配 tool_name。省略/非字符串 tool_name 并未被强制拒绝；非 unknown 的任意 outcome 不会被当作 unknown，只有明确 succeeded 才计文件成功集合。parent 存在并不保证该 parent 的角色为 User。

prefix 含 opaque metadata 时不可覆盖：顶层 signature/thinking_signature 的存在，或 annotations 中 native_history/signature 的存在即触发；不是递归扫描所有可能供应商字段。prefix 必须含非 System 且 cut 对应完整 User；prefix 中 call 缺 result、result 跨 cut 或 unknown 均拒绝。tail 的无结果或 unknown 进入 unresolved_calls；该集合按 BTreeMap 键顺序生成。成功 prefix 的 read_file/list_directory/search_text 计 read，write_file/edit_file 计 modified，路径来自 arguments.path 字符串并分别排序去重；不读写文件、不 canonicalize、不校验真实副作用，同一路径可同时在两表中。

finalize 从只读 plan 重建 skeleton，要求完整相等，拒绝任何 source 变化后设置摘要、hash、provider/model、usage，并以 restore 校验 budget。restore 先用原 source.records 重建并逐字段对齐，再校验含新增记录的当前 ancestry；匹配的追加记录得以保留。投影为覆盖 prefix 的 System、semantic 摘要 System、tail（过滤失败 Assistant）；摘要 ID 取 SHA 前24字符，timestamp 为覆盖末记录。failed Assistant 识别顶层 stop_reason/stopReason/finish_reason，或 annotations.finish_reason 的 error/aborted/deferred/cancelled；带 tool_calls 的失败 Assistant 会先在 skeleton 被拒，不能仅凭过滤承诺任意坏历史都能恢复。

### 摘要请求与可信度

summary_request_data 必须对应未变化的 plan；若有 previous checkpoint，先恢复验证身份与完整性，再要求旧 end 严格小于新 end。请求以字符串 previous_summary 加仅新覆盖 records（含 id/parent/role/content/metadata，过滤 failed Assistant），并附 plan 的 read/modified/unresolved 事实。不是把原 journal 改写成摘要，也不在此函数发 HTTP。previous restore 使用 MAX budget 仅为完整性检查，不代表真实请求预算已批准。

严格 Completion validator 拒 refusal、tool calls、空或超过64KiB内容；必须有 usage，input/output 正数、output<=limit、加法无溢出且 total>=input+output；annotations truncated=true 或 length/max_tokens/error/aborted/cancelled/incomplete 被拒。**deferred 不在该名单**，与 failed Assistant 过滤规则不同；未知其它状态也不是默认拒绝。随后严格解析九个必需数组、拒未知键；六种语义内容不能全空，八种字符串列表各<=64条、每条非空、<=4096字节且无NUL，三个文件/未解决集合必须精确等于 plan，最终规范 JSON 编码。它不能证明摘要语义忠实、usage 为供应商实际计费，SUMMARY_INSTRUCTIONS 也仅是生成约束。

低层 finalize/restore 不调用严格 validator，非空非 JSON 文本与零 usage 可以通过低层并在旧 SessionStore 实测中持久化。前文记录的 core 先 validate→finalize→append 顺序属于旧闭包；本轮未重读或测试当前 core/session/backend/TUI，不据此替当前宿主签署“无法绕过”结论。

### 历史证据归属与本轮结果

旧 `.ops/target073-ready/manifest.json` SHA-256 为 `5b0224277186c3b550dfad642a404407f68c1f517e25d1b883f1fa15ecac8337`。完整归档保留 manifest 及18项 payload，包括嵌套 reuse/104-manifest.json；旧 104 authority 和旧报告均原样保留。内部 replay-inputs.tar.gz 的139个输入逐项核验，包含138个原快照输入及1个 probe；其测试对象 context.rs 与当前相同，但这不证明其余当前产品闭包相同。

旧命令返回0；4 context +8 checkpoint +12 semantic +5 probe =29项顶层通过、0失败，另2个 helper 标 ignored，由父测试启动且不加总。负向样例所期望的 Err/取消/拒绝属于通过断言，不是被隐藏的失败。旧日志中的 HTTP、临时 journal、子进程 kill/reopen 都是历史真实执行；没有外部模型质量实验。本轮仅离线 hash/归档/read coverage/文档补丁校验，**新增行为运行数0**。工具链和命令保存在原包，未重新执行，也没有把本轮静态检查改名为新的行为通过。

### 主控真实 TUI / 新会话任务的最小待验判据

以下是建议主控用其已授权宿主工作检验的边界，不是本轮新增通过或额外执行要求：

1. 同时改变历史或切换新会话/分支后，让旧摘要返回；主控应确认 finalize/提交拒绝 stale 身份，旧 checkpoint 不被替换，摘要不落入新会话。仅 context hash 相同不足以证明当前 owner 接线正确。
2. provider 摘要期间取消应保持原有效 checkpoint；待真实工作释放前不得用界面 Closed 或运行器 deadline 当作副作用已停。context 只提供有限检查点；需要当前 owner 生命周期证据。
3. 若主控决定摘要 `deferred` 必须失败，最小判据是相同合法 JSON/usage 仅改变 deferred/正常 finish 状态，分别拒绝/接受且失败不替换 checkpoint。旧探针现在断言 deferred 成功，不能在改修后原样计为新要求的通过。
4. 若契约要求 call parent 必须 User，最小判据是同组 call/result 指向更早 System 拒绝，改指合法 User 接受；当前本层实际接受 System，须由主控决定契约与修复，阅读任务不擅自改产品。
5. 真实宿主必须完成严格 validator 后才发布摘要 checkpoint；普通文本/零 usage 的低层 API 接受不能作为宿主成功证据。旧 history 与当前 context 同 hash 仅支持本文件行为归属，不替代当前调用链检查。

本补包的职责是使 073 的基线、当前完整实现、旧实测和待验边界可复核。G-FILE/G-STAGE、master receipt 与清单接受状态均由主控决定，本文不签署接受。


---

## 主控原基线报告逐字节保留副本

以下3036字节为主控接收基底原文，SHA-256 `08f9dc2204499b1431e049bb6e42c5677a24eb4934f4c3672cf3f17063b5219b`；与旧包 prior-report.md 完全一致。另以 receiver-base-report.md 单独保留，逆向应用必须恢复该原文。其“Current”语句属于原基线报告的历史语境。

# ZS1-073 — zenpi src/context.rs baseline

Frozen target: `src/context.rs`, 8199 bytes, SHA256 `bc4ce7999a0f4d162effece8c6f839aca3a230e97675a1d7908fca5d6a7fe909`.
Controller read all 246 baseline lines before editing the file for ZS1-103. New implementation is a separate candidate and does not replace this baseline identity.

`ContextBudget` exposes max and reserved output tokens with 128000/8192 defaults. `TokenEstimate` marks all estimates approximate. `CompactionCheckpoint` is an unversioned six-field digest record; `PreparedContext` returns turns, optional checkpoint and estimate. `estimate_tokens` counts content bytes plus 16 bytes per turn, divides by four and rounds up; it omits tool metadata and attachments, a budget gap for ZS1-104/107.

`prepare_context` rejects max <= reserve, returns unchanged turns when within budget, and checks cancellation only when compaction is needed. It preserves all system records, walks backward through non-system messages using three quarters of the available input budget, and finds the retained start by first matching ID. It does not validate duplicate IDs, complete user turns or tool call/result pairs. The discarded prefix is JSON-hashed and represented by role counts and SHA, not semantic information. The system summary timestamp is the prefix's last timestamp and its metadata identifies the covered range. It re-estimates assembled system+summary+suffix and refuses if still over budget. Source input is not mutated and no backend or journal is called.

`restore_checkpoint` checks a zero-based nonempty range within current turns, recomputes the prefix digest and exact count-summary string, then rebuilds protected systems, deterministic summary and non-system suffix. It rejects changed prefix bytes, but has no session/branch ID, retained IDs, summary version, provider usage, unresolved tool state or restore-time budget check. All errors are typed as invalid budget, cancelled, budget exceeded, encoding or invalid checkpoint.

All baseline branches are in this file's scope. `tests/context.rs` covers approximate estimates, deterministic suffix retention, cancellation and changed-source rejection. Current core explicit/automatic compaction and restart restoration consume this API, so removing or relabeling legacy records would break compatibility. ZS1-103 therefore adds a distinct v2 semantic schema and validated journal APIs; ZS1-104 must replace production generation/context selection with actual semantic summaries. Existing digest output must never be presented as preserved user constraints.

Source relationships: SRC-0121 provides preparation, generation and iterative-summary behavior; SRC-0156 provides latest-compaction/tail projection. The new `stage1_context_checkpoint` tests validate actual journal persistence and fresh-process restore, plus complete tool pairs, stale plans, source/branch mismatches and cancellation. Full production selection and semantic quality remain unaccepted. No directory acceptance is implied by this file report.
