#!/usr/bin/env python3
"""Offline source/report integrity checks; archived runtime scripts are never run."""
from pathlib import Path
import argparse, gzip, hashlib, io, json, re, subprocess, tarfile, tempfile

root=Path(__file__).resolve().parent
sha=lambda data:hashlib.sha256(data).hexdigest()
def js(path): return json.loads(path.read_text())
def checked(data,row):
    assert len(data)==row['bytes'],row
    assert sha(data)==row['sha256'],row
def verify(skip_manifest=False):
    manifest_verified=False
    if not skip_manifest:
        m=js(root/'manifest.json');names=[]
        for row in m['files']:
            p=root/row['path'];assert p.resolve().is_relative_to(root)
            checked(p.read_bytes(),row);names.append(row['path'])
        assert len(names)==len(set(names))
        assert set(names)=={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name!='manifest.json'}
        manifest_verified=True
    binding=js(root/'report-binding.json');canonical=binding['canonical']
    assert canonical=='Docs/learn/stage1_pi_mono/targets/zenpi/files/src/context.rs_learn.md'
    prefix=(root/'history/prefix.md').read_bytes();appendix=(root/'appendix.md').read_bytes();report=(root/binding['report']).read_bytes();receiver=(root/'receiver-base.md').read_bytes()
    for label,data in [('prefix',prefix),('appendix',appendix),('report',report),('receiver_base',receiver)]:
        assert len(data)==binding[label+'_bytes'] and sha(data)==binding[label+'_sha256']
    assert report==prefix+appendix and prefix.endswith(receiver)
    assert len(prefix)==27482 and sha(prefix)=='80e0eed1be1be173bfef61d666e1125694d91180bf183e60af7550b069fef071'
    assert len(receiver)==3036 and sha(receiver)=='08f9dc2204499b1431e049bb6e42c5677a24eb4934f4c3672cf3f17063b5219b'
    current=(root/'source/current-context.rs').read_bytes();baseline=(root/'source/baseline-context.rs').read_bytes()
    assert sha(current)=='256d9ac1657e272ba61ebfbc242ece2970ed0607f3ebb1583b1711f18b7bf229'
    assert sha(baseline)=='bc4ce7999a0f4d162effece8c6f839aca3a230e97675a1d7908fca5d6a7fe909'
    evidence='Docs/quality/stage1/ZS1-073/worker-target-review-3.1.20/'
    with tarfile.open(root/'history/prior-ready.tar.gz','r:gz') as prior:
        raw=prior.extractfile('prior-ready/manifest.json').read();assert sha(raw)==binding['prior_manifest_sha256']
        old=json.loads(raw)
        for row in old['files']:checked(prior.extractfile('prior-ready/files/'+row['path']).read(),row)
        checked(prior.extractfile('prior-ready/'+old['patch']['path']).read(),old['patch'])
        assert len(old['files'])==13
        assert prior.extractfile('prior-ready/files/'+canonical).read()==prefix
        assert prior.extractfile('prior-ready/files/'+evidence+'current-context.rs').read()==current
        nested=prior.extractfile('prior-ready/files/'+evidence+'historical-target073-ready.tar.gz').read()
        test_index=json.loads(prior.extractfile('prior-ready/files/'+evidence+'historical-test-index.json').read())
        with tarfile.open(fileobj=io.BytesIO(nested),mode='r:gz') as history:
            raw=history.extractfile('manifest.json').read()
            assert sha(raw)==old['old_manifest_sha256']
            historical=json.loads(raw)
            for row in historical['files']:checked(history.extractfile(row['path']).read(),row)
            assert len(historical['files'])==18
            assert gzip.decompress(history.extractfile('context.rs.gz').read())==current
            assert gzip.decompress(history.extractfile('baseline-context.rs.gz').read())==baseline
            inventory=json.loads(history.extractfile('replay-input-inventory.json').read())
            with tarfile.open(fileobj=io.BytesIO(history.extractfile('replay-inputs.tar.gz').read()),mode='r:gz') as inputs:
                for row in inventory:checked(inputs.extractfile(row['path']).read(),row)
                assert len(inventory)==139 and inputs.extractfile('src/context.rs').read()==current
                for row in test_index['tests']:
                    data=inputs.extractfile(row['path']).read();checked(data,row)
                    for title in row['titles']:assert ('fn '+title+'(').encode() in data
    assert test_index['distinct_top_level']==29 and test_index['ignored_helpers']==2
    declarations=0
    for record in js(root/'read-coverage.json')['inputs']:
        data=(root/record['path']).read_bytes();checked(data,record);lines=data.splitlines(keepends=True);cursor=0;next_line=1
        for chunk in record['chunks']:
            a,b=chunk['byte_range'];assert a==cursor and 0<b-a<=256*1024
            assert chunk['start_line']==next_line
            raw=b''.join(lines[chunk['start_line']-1:chunk['end_line']]);assert raw==data[a:b];checked(raw,chunk)
            cursor=b;next_line=chunk['end_line']+1
        assert cursor==len(data) and next_line==len(lines)+1
        assert record['read_ranges']==[c['byte_range'] for c in record['chunks']]
        text=data.decode();inventory=[{'line':text[:m.start()].count('\n')+1,'kind':m[1],'name':m[2]} for m in re.finditer(r'^[ \t]*(?:pub )?(const|struct|enum|fn)\s+(\w+)',text,re.M)]
        assert inventory==record['inventory'];declarations+=len(inventory)
        assert not re.search(r'#\[(?:test|cfg\(test\))\]',text) and record['inline_tests']==0
    fragments=0
    for record in js(root/'context-index.json')['files']:
        for fragment in record['fragments']:
            data=(root/fragment['path']).read_bytes();checked(data,fragment)
            assert len(data.splitlines())==fragment['end_line']-fragment['start_line']+1
            fragments+=1
    results=[]
    for name,old in [('report-from-main.patch',receiver),('append-report.patch',prefix)]:
        patch=root/name
        headers=[line for line in patch.read_text().splitlines() if line.startswith(('--- ','+++ '))]
        assert headers==['--- a/'+canonical,'+++ b/'+canonical]
        assert patch.stat().st_size<256*1024
        with tempfile.TemporaryDirectory(prefix='target073-verify-',dir=root.parent) as temporary:
            directory=Path(temporary)
            def git(*args):
                result=subprocess.run(['git',*args],cwd=directory,capture_output=True,text=True)
                assert result.returncode==0,{'argv':args,'stdout':result.stdout,'stderr':result.stderr}
            git('init','--quiet');target=directory/canonical;target.parent.mkdir(parents=True);target.write_bytes(old)
            git('apply','--check',str(patch));git('apply',str(patch));assert target.read_bytes()==report
            assert {p.relative_to(directory).as_posix() for p in (directory/'Docs').rglob('*') if p.is_file()}=={canonical}
            git('apply','--reverse','--check',str(patch));git('apply','--reverse',str(patch));assert target.read_bytes()==old
        results.append({'patch':name,'sha256':sha(patch.read_bytes()),'bytes':patch.stat().st_size,'exact_apply_reverse':'passed','only_path':canonical})
    return {'ok':True,'kind':'offline static integrity and private report patch checks only','manifest_verified':manifest_verified,
            'prior_payloads_verified':14,'nested_historical_payloads_verified':18,'historical_replay_inputs_verified':139,
            'historical_top_level_tests':29,'historical_ignored_helpers':2,'new_behavior_runs':0,'inline_tests':0,
            'source_bytes':{'baseline':len(baseline),'current':len(current)},'source_current_equal_prior_and_historical':True,
            'exact_prefix_preserved':True,'receiver_base_preserved_verbatim':True,'context_fragments_verified':fragments,
            'report_sha256':sha(report),'patch_checks':results,'G_STAGE_executed':False,'semantic_gate':'pending independent master review'}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--without-manifest',action='store_true');args=parser.parse_args()
    print(json.dumps(verify(args.without_manifest),indent=2))
