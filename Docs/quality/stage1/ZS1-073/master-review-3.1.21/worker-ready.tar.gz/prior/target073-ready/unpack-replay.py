from pathlib import Path
import sys,json,tarfile,hashlib
base=Path(__file__).resolve().parent
out=Path(sys.argv[1]).resolve()
if out.exists():raise SystemExit('destination must not exist')
expected={r['path']:r for r in json.loads((base/'replay-input-inventory.json').read_text())}
payload={}
with tarfile.open(base/'replay-inputs.tar.gz','r:gz') as archive:
 for member in archive.getmembers():
  p=Path(member.name)
  if not member.isfile() or p.is_absolute() or '..' in p.parts or member.name not in expected or member.name in payload:raise SystemExit('invalid member')
  b=archive.extractfile(member).read();r=expected[member.name]
  if len(b)!=r['bytes'] or hashlib.sha256(b).hexdigest()!=r['sha256']:raise SystemExit('hash mismatch')
  payload[member.name]=(b,member.mode)
if set(payload)!=set(expected):raise SystemExit('incomplete archive')
out.mkdir(parents=True)
for name,(b,mode) in payload.items():
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);p.chmod(mode&0o777)
print(json.dumps({'files':len(payload),'destination':str(out)}))
