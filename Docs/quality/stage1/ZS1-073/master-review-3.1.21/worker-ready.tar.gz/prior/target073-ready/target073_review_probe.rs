use serde_json::json;
use zenpi::{
    backend::{Completion, Usage},
    context::*,
    core::{Turn, TurnRole},
    session::SessionStore,
};
#[test]
fn fitting_legacy_context_does_not_consult_cancellation_and_metadata_is_counted() {
    let mut turns = vec![Turn::new("u", TurnRole::User, "small")];
    let old = estimate_tokens(&turns).input_tokens;
    turns[0].metadata = Some(json!({"large":"x".repeat(4000)}));
    assert!(estimate_tokens(&turns).input_tokens >= old + 1000);
    let polls = std::cell::Cell::new(0);
    let output = prepare_context(&turns, ContextBudget::default(), &|| {
        polls.set(polls.get() + 1);
        true
    })
    .unwrap();
    assert_eq!(polls.get(), 0);
    assert_eq!(output.turns, turns);
    println!(
        "OBS fit fast path returns despite cancelled predicate; polls=0; metadata contributes to byte estimate"
    );
}
#[test]
fn legacy_cut_can_split_parent_context_and_restore_has_no_budget_gate() {
    let source = vec![
        Turn::new("u1", TurnRole::User, "x".repeat(4000)),
        Turn::with_parent("a1", "u1", TurnRole::Assistant, "y".repeat(600)),
        Turn::with_parent("t1", "u1", TurnRole::Tool, "z".repeat(600)),
        Turn::new("u2", TurnRole::User, "next"),
    ];
    let output = prepare_context(
        &source,
        ContextBudget {
            max_tokens: 500,
            reserved_output_tokens: 0,
        },
        &|| false,
    )
    .unwrap();
    let mut cp = output.checkpoint.unwrap();
    assert_eq!(cp.source_end, 1);
    assert!(
        output
            .turns
            .iter()
            .any(|t| t.parent_id.as_deref() == Some("u1"))
    );
    assert!(!output.turns.iter().any(|t| t.id == "u1"));
    cp.estimated_tokens_before = 0;
    cp.estimated_tokens_after = 0;
    let mut extended = source;
    extended.push(Turn::new("u3", TurnRole::User, "q".repeat(100_000)));
    let restored = restore_checkpoint(&extended, &cp).unwrap();
    assert!(estimate_tokens(&restored).input_tokens > 500);
    println!(
        "OBS legacy cut=1 retains dangling parent u1; forged estimate counters accepted; appended context restore exceeds original500 budget"
    );
}
#[test]
fn low_level_finalize_can_persist_plain_summary_without_completion_validation() {
    let root = tempfile::tempdir().unwrap();
    let path = root.path().join("journal");
    let mut session = SessionStore::open(&path).unwrap();
    let turns = vec![
        Turn::new("u1", TurnRole::User, "earlier constraint"),
        Turn::new("u2", TurnRole::User, "retain"),
    ];
    for t in &turns {
        session.append_turn(t.clone()).unwrap();
    }
    let plan =
        prepare_semantic_compaction(&turns, session.session_id(), "linear", 0, &|| false).unwrap();
    let cp = plan
        .finalize(
            &turns,
            "plain non-JSON summary".into(),
            "fixture".into(),
            "model".into(),
            Usage::default(),
            ContextBudget::default(),
            &|| false,
        )
        .unwrap();
    assert!(
        plan.validate_summary_completion(&Completion::text("plain non-JSON summary"), 100)
            .is_err()
    );
    session
        .append_semantic_checkpoint(&cp, ContextBudget::default(), &|| false)
        .unwrap();
    drop(session);
    let session = SessionStore::open(&path).unwrap();
    let restored = session
        .latest_semantic_checkpoint(ContextBudget::default())
        .unwrap()
        .unwrap();
    assert_eq!(restored.summary, "plain non-JSON summary");
    assert_eq!(restored.summary_usage.total_tokens, 0);
    println!(
        "OBS low-level finalize/session checkpoint persists plain summary+zero usage; production completion validator is a separate required boundary"
    );
}
#[test]
fn context_call_parent_must_exist_but_is_not_required_to_have_user_role() {
    let mut calls = Turn::with_parent("a", "s", TurnRole::Assistant, "");
    calls.metadata = Some(
        json!({"tool_calls":[{"id":"c","name":"read_file","arguments":{"path":"owned.txt"}}]}),
    );
    let mut result = Turn::with_parent("r", "s", TurnRole::Tool, "ok");
    result.metadata =
        Some(json!({"tool_call_id":"c","tool_name":"read_file","outcome":"succeeded"}));
    let turns = vec![
        Turn::new("s", TurnRole::System, "system"),
        Turn::new("u1", TurnRole::User, "old"),
        calls,
        result,
        Turn::new("u2", TurnRole::User, "new"),
    ];
    let plan = prepare_semantic_compaction(&turns, "session", "linear", 0, &|| false).unwrap();
    let cp = plan
        .finalize(
            &turns,
            "summary".into(),
            "fixture".into(),
            "model".into(),
            Usage::default(),
            ContextBudget::default(),
            &|| false,
        )
        .unwrap();
    assert_eq!(cp.read_files, vec!["owned.txt"]);
    println!(
        "OBS assistant/tool pair keyed to existing System parent is accepted by context skeleton"
    );
}
#[test]
fn summary_completion_validation_accepts_deferred_annotation_but_rejects_length() {
    let turns = vec![
        Turn::new("u1", TurnRole::User, "old"),
        Turn::new("u2", TurnRole::User, "new"),
    ];
    let plan = prepare_semantic_compaction(&turns, "session", "linear", 0, &|| false).unwrap();
    let mut completion=Completion::text(json!({"goals":["retain task"],"constraints":[],"decisions":[],"progress":[],"pending_tasks":[],"critical_facts":[],"read_files":[],"modified_files":[],"unresolved_tools":[]}).to_string());
    completion.usage = Some(Usage {
        input_tokens: 10,
        output_tokens: 20,
        total_tokens: 30,
    });
    completion.annotations = vec![json!({"finish_reason":"deferred"})];
    assert!(plan.validate_summary_completion(&completion, 100).is_ok());
    completion.annotations = vec![json!({"finish_reason":"length"})];
    assert!(plan.validate_summary_completion(&completion, 100).is_err());
    println!(
        "OBS complete valid JSON with deferred annotation accepted; same completion with length rejected"
    );
}
