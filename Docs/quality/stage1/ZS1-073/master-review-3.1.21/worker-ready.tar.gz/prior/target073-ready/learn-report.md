# ZS1-073 — src/context.rs 完整 owner 复核

状态：[_] 当前hash阅读/行为候选，主控未接受。Authority3.1.16；requirement digest `c0262492bc6e3b4d5f56b35bedc7c1d1658854df11c4a975eb612a514cceef8f`。

Subject为主控只读快照，807行/30013字节/SHA256 `256d9ac1657e272ba61ebfbc242ece2970ed0607f3ebb1583b1711f18b7bf229`。全文按1–290、291–570、571–807逐行读取，完整字节并集[0,30013)，见read-coverage.json。本次没有产品修改。

已有主控073报告仅对应246行/8199字节/hash `bc4ce7999a0f4d162effece8c6f839aca3a230e97675a1d7908fca5d6a7fe909`，已在旧input-host-before快照找到完全一致文件并冻结。另核验冻结ZS1-104候选的context.rs原字节与当前subject完全相同；只复用该历史身份/设计背景，仍重新完整读807行并执行当前上下文测试。旧包authority3.1.6保持不变，不回写成当前版本。

## 职责与来源关系

context是纯准备/校验/投影层：估算上下文、构造legacy digest checkpoint、选择semantic完整turn切点、验证source/summary、组装摘要请求与恢复后的provider输入。它本身没有网络、journal写入、费用结算、provider重试、模型选择或operation recovery owner。生成summary、持久化与取消/预算生命周期在core/session/backend/governance。

对照冻结pi compaction源项012：增量请求携带previous_summary与新覆盖records；保留新近完整turn，不把未完成或unknown工具结果压成成功；从真实工具结果提取文件操作信息。Zenpi另加入source session/branch/hash、usage与严格JSON sections等本地owner约束。旧digest只保存数量和hash，不保存语义；生产core的context_source_for_provider明确在没有semantic checkpoint时返回完整selected history，不用旧digest替代事实。这是本次实际定位的调用路径，不能把legacy helper的弱约束当成当前provider自动压缩的全部实现。

## 全部类型、函数及分支

| 行 | 职责与分支 | owner/限制 |
|---|---|---|
| 1–47 | 默认budget128000/reserved8192；ContextBudget、TokenEstimate、legacy CompactionCheckpoint、PreparedContext | legacy checkpoint无schema/session/branch；估算一律approximate |
| 49–63 | estimate_tokens | 每turn content UTF-8字节+16+序列化metadata字节，saturating累加后ceil/4；metadata编码失败按MAX保守估算；不单独计ID/parent/timestamp/外部attachment实体 |
| 65–88 | has_opaque_provider_state、whole_turn_start | 识别顶层signature/thinking_signature或annotations native_history/signature；presence即保护（并非递归任意key扫描）。完整turn起点是无parent User，或metadata steer.strategy=cancel_reissue的User |
| 90–112 | prepare_context入口 | max<=reserve InvalidBudget；已fit直接clone返回，无checkpoint且不调用cancel；只有需压缩才检查一次cancel |
| 113–143 | legacy保留选择 | 所有System单独保留；逆扫非System，目标3/4 available，至少尝试最新一条；按首个保留ID找原位置；kept_start0报预算不足；不验证ID唯一、完整turn或工具配对 |
| 144–196 | legacy摘要/预算 | JSON hash覆盖prefix；数四种role生成固定count+SHA文本；summary ID取digest前16位，时间取prefix最后turn；protected system+summary+suffix再估算，超budget失败，否则返回六字段marker |
| 198–262 | restore_checkpoint | source_start须0、end非0且<=turns.len；prefix hash和固定summary文本必须相同；重组所有System+summary+非System suffix；不验证估算字段、不含restore budget/cancel参数 |
| 264–276 | ContextError | InvalidBudget/Cancelled/BudgetExceeded/Encoding/InvalidCheckpoint，纯typed错误无session副作用 |
| 278–325 | semantic version2、64KiB上限、CheckpointSource、UnresolvedContextCall、SemanticCheckpoint、Plan | source完整session/branch/tip/records/hash；covered hash、retained IDs、文件集、未完成call、summary hash/provider/model/usage；Plan字段私有不可外部随意构造 |
| 327–363 | context_digest、valid_context_id、failed_context_assistant | 整turn JSON含metadata/时间等；ID非空<=128B无control，但允许首尾非全空白；失败assistant识别顶层三种stop键及annotations.finish_reason的error/aborted/deferred/cancelled |
| 365–385 | checkpoint_skeleton切点前置 | session/branch合法；end在1..len且对应whole-turn User；覆盖prefix不得有opaque state，并须含非System记录 |
| 386–435 | ancestry/assistant calls扫描 | ID合法唯一；parent若有须在更早ID集合；Tool无metadata拒绝；tool_calls只能在非failed Assistant，需parent、数组、合法call/name、object arguments；(parent,call_id)唯一；抓取arguments.path字符串 |
| 437–467 | tool结果配对与路径集合 | Tool需parent/call ID并能匹配更早call；重复result或显式tool_name不匹配拒绝；记录result索引与unknown_outcome；仅prefix succeeded的read_file/list_directory/search_text路径计read，write_file/edit_file计modified；两个BTreeSet独立、排序去重、不canonicalize文件系统 |
| 469–503 | cut安全与skeleton输出 | prefix call若无结果、结果跨cut、或unknown则拒绝；tail未解决/unknown列入unresolved；source hash绑定完整原输入，covered hash绑定prefix，tail IDs按源顺序保存；summary字段初始空 |
| 505–531 | prepare_semantic_compaction | 入口cancel、每个候选cut前cancel；从最近User起点逆向找尾部estimate>=keep_recent_tokens且skeleton合法的第一个cut；无可用cut统一InvalidCheckpoint；没有可压prefix时不制造假summary |
| 533–585 | Plan accessors/finalize | 暴露source/end只读；先cancel、重建skeleton并要求全结构相同以拒stale；设置summary/hash/provider/model/usage后调用restore验证预算与source，最后再cancel；不调用严格completion JSON校验 |
| 587–625 | restore_semantic_checkpoint基本验证 | budget有效、version2、真实session/branch匹配、source.records不超过当前len；summary非空<=64KiB、provider/model ID合法、summary hash相同；按原records重建全部skeleton后与持久checkpoint逐字段相等 |
| 626–658 | 增量恢复/投影预算 | 全当前ancestry再skeleton校验，允许合法追加记录；保留覆盖prefix的System，插入summary System，append保留尾部但过滤failed assistant；summary ID用hash前24位，时间prefix末尾；重新估算超budget拒绝 |
| 660–676 | SemanticSummary及SUMMARY_INSTRUCTIONS | 9个必需数组，deny_unknown_fields；instructions要求只总结数据、保留要求/未完成工作/文件、不得把unknown写成完成；这是模型指令，不是语义真实性证明 |
| 678–725 | summary_request_data | 当前skeleton必须仍等于plan；previous有值先恢复验证，要求previous.end严格早于新cut；只发送新覆盖区间且过滤failed assistants；previous summary作为字符串字段，真实文件集/未解决对象由plan提供；无previous从0起 |
| 727–767 | validate_summary_completion外层 | usage必需且输入/输出>0，output<=limit，sum不可溢出且total>=sum；拒refusal、tool calls、空/超长内容；annotations truncated或指定失败/length状态拒绝 |
| 768–807 | completion结构校验与规范序列化 | 严格解析全部sections；六种语义section不能全空；八种字符串数组每个<=64条、每条非空<=4096B且无NUL；read/modified/unresolved必须逐项精确等于plan；最终重新serde编码并返回实际usage |

## 算法、边界和数据可信度

semantic切点保证至少保留新近User整个suffix，且不能把assistant call与result拆到两边；unknown或未返回的prefix call禁止覆盖。call ID按(parent turn ID,call ID)关联，允许不同turn复用同call ID。prefix System不被摘要替换，opaque原生签名状态不能进入被覆盖prefix。恢复先验证旧source原字节，再校验追加记录，因此不是仅凭summary文本或客户端retained_ids信任裁剪。

当前skeleton只检查parent ID存在，没有检查该parent的role一定User，也不访问session tree的真实branch选择；后者来自调用者传入完整selected ancestry和session owner。文件列表只从成功tool结果与call arguments提取，既不读真实文件，也不能从模型自由文本判断副作用完成。read和modified可以同时包含同一路径，不能误写成后者自动从前者去除。

finalize/restore是version2 checkpoint的数据完整性层；validate_summary_completion是生产生成结果的更严格层。core当前先调用严格validator，再finalize，再append_semantic_checkpoint_for_operation；session的低层append只调用restore校验而非completion validator。保留103公共低层API意味着通过finalize或session写入并不能反推summary曾有合法结构/真实provider usage。usage本身仍是调用方/adapter给的数据，校验不能证明供应商实际计费。合法section结构也不保证摘要事实正确；HTTP fixtures只验证已知测试约束确实保留。

Cancellation的检查点是有限的：legacy fit零次、legacy需压缩入口一次；semantic规划入口及候选cut之间、finalize开始/结束。大skeleton循环与哈希内部没有逐记录cancel；prepare在多次候选失败时重复扫描/估算与hash，也没有固定常数耗时保证。没有将此静态事实冒称实际性能基准或取消延迟故障。

## 本次实际证据

未修改product的快照执行：context4 + stage1_context_checkpoint8 + stage1_semantic_compaction12 + 新probe5 =29个顶层通过、0失败；2个独立进程helper在各自顶层listing标ignored，父测试启动输出不重复计数。semantic套件用真实loopback HTTP、临时journal、取消、被终止的独立进程与重开；没有外部模型调用或真实模型质量评估。全部源/既有测试输入hash与只读快照一致，仅新增独立review probe。

五个新观察：

1. 已fit的legacy context即使传入总返回true的cancel函数也成功，实际调用次数0；4000字节metadata使估算增加至少1000 token单位，证明当前已修正旧基线“完全不计metadata”的缺口。
2. legacy预算500的实际样例cut=1，只覆盖u1，但返回的assistant/tool仍parent=u1，而u1本体已被count摘要替换；它不保证完整turn ancestry。改checkpoint两项estimated计数为0仍可restore；再追加10万字节User，restore仍成功且超过原预算。源码和实测一致，不能给legacy restore添加不存在的预算保证。
3. 低层plan.finalize接受非JSON普通summary和Usage::default()；真实SessionStore.append_semantic_checkpoint写入后，重开仍得到该summary且usage.total=0。相同Completion::text直接过严格validator会失败。该探针证明层次差异，不宣称生产Agent绕过了validator。
4. Assistant与Tool共同指向更早的System ID，call/result其余字段有效时，skeleton接受并报告read_files。parent存在与“是User turn”不是同一约束；真实core正常生成的parent路径不能替代这项静态/实测边界。
5. 内容、sections和usage均有效的Completion，annotations.finish_reason=deferred能过严格validator；改为length则拒绝。failed_context_assistant把deferred列为失败，但summary completion黑名单没有它。探针只通过自建Completion证明本层行为，没有证明任何外部provider能产生同样完整成功payload。

现有8个checkpoint测试另证明multi-call完整配对、source/cut/tail/summary/branch篡改拒绝、未解决call保留tail、failed write不计modified、unknown prefix不可压缩、cancel/budget/stale/duplicate result拒绝、独立进程durable checkpoint及legacy兼容。12个semantic测试另覆盖真实HTTP结构化summary、迭代restart、截断/坏summary不替换旧checkpoint、额度/价格/源上限在HTTP前拒绝、取消不自动重试、native state计入并保留、分支绑定、late steer准备边界、headless手动compact响应取消、被kill后未知operation恢复。

## 后续定位与交付边界

当前生产core有严格validator顺序证据，legacy弱约束与低层finalize宽松性均按兼容API记录，不在阅读任务中擅自升级/改写历史checkpoint。deferred黑名单不一致与parent role约束缺口具备最小实际样例，可由主控结合backend/session契约决定是否修复；本次未修改产品、ledger、接受状态或104等旧包。073全文已覆盖，不把core/session/backend依赖定位充当其对应文件的完整接受。
