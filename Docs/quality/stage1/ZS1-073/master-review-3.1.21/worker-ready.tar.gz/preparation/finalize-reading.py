from pathlib import Path
import json,hashlib,csv,re,difflib
O=Path('.ops/target073-full-3.1.21-20260913-ready')
def ident(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
p=O/'learn-report.md';p.write_text(p.read_text().replace('session/context.ts1–69','session/context.ts1–64'))
chunks=json.loads((O/'chunk-plan.json').read_text())
for i,c in enumerate(chunks,1):c.update(read=True,order=i)
es=json.loads((O/'context-plan.json').read_text())
for i,e in enumerate(es,1):e.update(read=True,order=i,semantic_scope='whole test source' if e['original'].split('/')[-2]=='tests' else 'bounded consumer/source comparison; no adjacent acceptance')
oldpaths=['prior/target073-ready/README.md','prior/target073-ready/prior-report.md','prior/target073-ready/learn-report.md','prior/target073-ready/tests.stdout.log','prior/target073-ready/tests.stderr.log','prior/target073-ready/target073_review_probe.rs','prior/target073-review-3.1.20-ready/files/Docs/learn/stage1_pi_mono/targets/zenpi/files/src/context.rs_learn.md','prior/target073-review-3.1.20-ready/files/Docs/quality/stage1/ZS1-073/worker-target-review-3.1.20/assertion-review.md','prior/target073-review-3.1.20-ready/files/Docs/quality/stage1/ZS1-073/worker-target-review-3.1.20/README.md','prior/target073-refresh-3.1.20-ready/appendix.md','prior/target073-refresh-3.1.20-ready/README.md','prior/target073-refresh-3.1.20-ready/verification-preseal.json','prior-external-logs/verification-sealed.run.json','prior-external-logs/verification-sealed.stdout.json']
docs=[{'path':p,**ident(O/p),'lines':len((O/p).read_bytes().splitlines()),'read':True,'kind':'historical document/log read this task, not execution'} for p in oldpaths]
idx=[]
for p in sorted((O/'context/full/tests').iterdir()):
 text=p.read_text();names=re.findall(r'#\[test\]\s*(?:#\[[^\n]+\]\s*)*fn\s+(\w+)',text);ignored=text.count('#[ignore =');idx.append({'path':p.relative_to(O).as_posix(),**ident(p),'lines':len(text.splitlines()),'test_declarations':names,'ignored_helpers':ignored,'new_executions':0})
(O/'test-source-index.json').write_text(json.dumps(idx,indent=2)+'\n')
(O/'reading-ledger.json').write_text(json.dumps({'source_full_read_complete':True,'embedded_test_count':0,'new_product_executions':0,'source_read_method':'continuous untruncated cat 1-300,301-600,601-807; completed before external test/context reads','chunks':chunks,'context_reads':es,'historical_documents':docs,'historical_assembled_report':{'path':'prior/target073-refresh-3.1.20-ready/files/Docs/learn/stage1_pi_mono/targets/zenpi/files/src/context.rs_learn.md','read':True,'method':'complete review report prefix plus complete appendix read; exact concatenation verified in sole audit'},'baseline_full_read_this_task':False,'tui_read_this_task':False},indent=2)+'\n')
with (O/'chunk_manifest.tsv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=['order','path','line_start','line_end','byte_start','byte_end','bytes','sha256','read'],delimiter='\t');w.writeheader();w.writerows([{k:c[k] for k in w.fieldnames} for c in chunks])
old=O/'prior/target073-review-3.1.20-ready/files/Docs/quality/stage1/ZS1-073/worker-target-review-3.1.20/current-context.rs';cur=O/'target/src/context.rs'
(O/'current-versus-prior.diff').write_text(''.join(difflib.unified_diff(old.read_text().splitlines(True),cur.read_text().splitlines(True),fromfile='prior/current-context.rs',tofile='current/src/context.rs')))
(O/'README.md').write_text('''# ZS1-073 frozen worker candidate

Only owned report: Docs/learn/stage1_pi_mono/targets/zenpi/files/src/context.rs_learn.md.
Current 30013 B / 807 lines fully read anew; three complete external test files and bounded consumers are in the reading ledger. Product runs: 0. No patch applied. Historical packages, scripts and logs are archival only and must not be run as part of this research task.

forward.patch replaces the exact captured 3036-byte receiver-base.md; reverse.patch restores those same bytes. Both affect one report only. Master owns acceptance and integration. All prior 073 packages remain intact under prior; preserved 070 defects remain unmodified.

The new audit-offline.py is read-only Python standard library. After its full static review, run at most once through the external work-directory run-once.py; all result/log/guard files stay outside this frozen ready. It verifies structural identity and patch construction, not product behavior or semantic acceptance. Do not rerun if it fails. Manifest excludes only itself.
''')
print(json.dumps({'chunks':len(chunks),'context_reads':len(es),'historical_documents':len(docs),'test_declarations':sum(len(i['test_declarations']) for i in idx),'ignored':sum(i['ignored_helpers'] for i in idx),'report':ident(O/'learn-report.md')}))
