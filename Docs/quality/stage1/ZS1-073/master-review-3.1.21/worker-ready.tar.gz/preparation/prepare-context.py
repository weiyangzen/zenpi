from pathlib import Path
import json,hashlib,shutil,difflib
R=Path('/Users/wangweiyang/.codex/worktrees/38de/zenpi');M=Path('/Users/wangweiyang/GitHub/zenpi');O=R/'.ops/target073-full-3.1.21-20260913-ready'
def ident(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def cp(p,rel):
 q=O/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q);return q
entries=[]
def part(p,a,z,label):
 lines=p.read_bytes().splitlines(keepends=True);z=min(z,len(lines));rel=f'context/{label}.L{a:04d}-{z:04d}.txt';q=O/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b''.join(lines[a-1:z]));entries.append({'original':str(p),'whole_identity':ident(p),'line_start':a,'line_end':z,'path':rel,**ident(q),'read':False})
for rel in ['tests/context.rs','tests/stage1_context_checkpoint.rs','tests/stage1_semantic_compaction.rs']:
 p=cp(M/rel,'context/full/'+rel)
 for a in range(1,len(p.read_bytes().splitlines())+1,300):part(M/rel,a,a+299,rel.replace('/','_'))
for rel,rs in {'src/core.rs':[(128,170),(1739,1900),(1901,2104),(4894,4922)],'src/session.rs':[(1225,1387)],'src/backend.rs':[(1,116),(170,238),(290,350),(1844,1853)],'src/protocol.rs':[(26,37)]}.items():
 for a,z in rs:part(M/rel,a,z,rel.replace('/','_'))
old=O/'prior/target073-refresh-3.1.20-ready'
for f in sorted((old/'context').glob('*.ts.*.txt')):
 cp(f,'context/upstream-prior/'+f.name)
entries_path=O/'context-plan.json';entries_path.write_text(json.dumps(entries,indent=2)+'\n')
owned=json.loads((O/'capture.json').read_text())['owned_path'];cp(M/owned,'receiver-base.md')
for p in sorted((R/'.ops/stage1-worker/target073-refresh-3.1.20').glob('verification-*')):cp(p,'prior-external-logs/'+p.name)
for p in sorted((R/'.ops/stage1-worker/target073').glob('tests.*.log')):cp(p,'prior-external-logs/original-'+p.name)
# Preserve the complete 070 manifest and its defect report by identity; its existing frozen package stays immutable.
for name in ['manifest.json','learn-report.md']:cp(R/'.ops/target070-full-3.1.21-20260913-ready'/name,'protected070/'+name)
b=old/'source/baseline-context.rs';c=O/'target/src/context.rs';cp(b,'target/baseline-context.rs')
(O/'baseline-to-current.diff').write_text(''.join(difflib.unified_diff(b.read_text().splitlines(True),c.read_text().splitlines(True),fromfile='baseline/src/context.rs',tofile='current/src/context.rs')))
(O/'assignment.json').write_text(json.dumps({'item':'ZS1-073','accepted_at_assignment':'50/121','snapshot':'aa9412fe226f42c2dc6898b09cf94ba34e76ee26f268abd4d43d13fad57e7dc1','master_tui_announced_sha256':'6459360343a260c6dfe7b403a81cd22a8fcac0bb3e10fcabed2bd3c0b8567254','tui_observed_identity':ident(M/'src/tui.rs'),'tui_semantic_read_this_task':False,'master_143_checks':'master reported historical for 073, not worker execution','new_product_executions':0},indent=2)+'\n')
print(json.dumps({'context_segments':len(entries),'receiver':ident(M/owned),'tests':[{ 'path':str(p.relative_to(O)),**ident(p)} for p in (O/'context/full/tests').iterdir()]}))
