from pathlib import Path
import datetime, hashlib, json, subprocess, sys, time
W=Path(__file__).resolve().parent; R=W.parents[2]; O=R/'.ops/target073-full-3.1.21-20260913-ready'
def identity(p):
    b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
started=datetime.datetime.now(datetime.timezone.utc).isoformat(); before=identity(O/'manifest.json'); command=[sys.executable,str(O/'audit-offline.py')]
guard={'item_id':'ZS1-073','allowed_invocations':1,'started_at':started,'command':command,'manifest_before':before,'static_review':'Entire frozen auditor and this wrapper read before sole invocation'}
with (W/'invocation-guard.json').open('x') as f:
    json.dump(guard,f,indent=2);f.write('\n')
begin=time.monotonic()
with (W/'offline.stdout.json').open('xb') as out,(W/'offline.stderr.log').open('xb') as err:
    result=subprocess.run(command,stdout=out,stderr=err,check=False)
receipt={'started_at':started,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'duration_seconds':time.monotonic()-begin,'exit_code':result.returncode,'manifest_before':before,'manifest_after':identity(O/'manifest.json'),'stdout':identity(W/'offline.stdout.json'),'stderr':identity(W/'offline.stderr.log'),'new_product_executions':0}
with (W/'offline.result.json').open('x') as f:
    json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps(receipt,indent=2));sys.exit(result.returncode)
