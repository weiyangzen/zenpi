from pathlib import Path
import datetime, hashlib, json, shutil, subprocess
R=Path('/Users/wangweiyang/.codex/worktrees/38de/zenpi'); M=Path('/Users/wangweiyang/GitHub/zenpi'); O=R/'.ops/target073-full-3.1.21-20260913-ready'
O.mkdir()
def identity(p):
    b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(rel,obj):
    p=O/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def copy(p,rel):
    q=O/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q);return q
old_packages=[]
for name in ['target073-ready','target073-review-3.1.20-ready','target073-refresh-3.1.20-ready']:
    p=R/'.ops'/name;shutil.copytree(p,O/'prior'/name)
    old_packages.append({'original':str(p),'copy':'prior/'+name,'manifest':identity(p/'manifest.json'),'files':[{'path':q.relative_to(p).as_posix(),**identity(q)} for q in sorted(p.rglob('*')) if q.is_file()]})
save('prior-identities.json',old_packages)
source=copy(M/'src/context.rs','target/src/context.rs');b=source.read_bytes();lines=b.splitlines(keepends=True);chunks=[];offset=0
for lo in range(1,len(lines)+1,300):
    hi=min(lo+299,len(lines));data=b''.join(lines[lo-1:hi]);rel=f'chunks/context.L{lo:04d}-{hi:04d}.rs';q=O/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(data)
    chunks.append({'path':rel,'line_start':lo,'line_end':hi,'byte_start':offset,'byte_end':offset+len(data),**identity(q),'read':False});offset+=len(data)
save('chunk-plan.json',chunks)
for rel in ['Docs/execution/active_requirement.json','Docs/stage_1_v3_pi_mono_blueprint.md','Docs/learn/stage1_pi_mono/targets/zenpi/source_manifest.tsv','Docs/learn/stage1_pi_mono/targets/zenpi/file_learn_index.tsv']:
    copy(M/rel,'authority/'+rel)
owned='Docs/learn/stage1_pi_mono/targets/zenpi/files/src/context.rs_learn.md'
status=subprocess.check_output(['git','status','--short','--untracked-files=all'],cwd=R,text=True).splitlines();status=[x for x in status if not x[3:].startswith('.ops/')]
save('capture.json',{'captured_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'subject':'src/context.rs',**identity(source),'lines':len(lines),'source_read_complete':False,'owned_path':owned,'canonical_exists':(M/owned).exists(),'worker_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'worker_status':status,'worker_files':[{'path':str(R/x[3:]),**identity(R/x[3:])} for x in status if (R/x[3:]).is_file()],'new_product_executions':0})
protected=[]
for name in ['target072-full-3.1.21-20260913-ready','target070-full-3.1.21-20260913-ready','source059-directory-3.1.21-corrected-ready','source060-directory-3.1.21-20260913-ready','source061-directory-3.1.21-corrected-ready','source062-directory-3.1.21-ready','target117-single-markers-3.1.21-ready','target117-cold-start-diagnosis-3.1.21-ready']:
    p=R/'.ops'/name/'manifest.json';protected.append({'path':str(p),**identity(p)})
for name in ['session-0.jsonl','session-0.jsonl.reconnect']:
    p=Path('/var/folders/zh/sdgyp1m967jc7703v5f9pzw40000gn/T/zenpi-bench-j54aa9yq')/name;protected.append({'path':str(p),**identity(p)})
save('protected-identities.json',protected)
print(json.dumps({'source':identity(source),'lines':len(lines),'chunks':len(chunks),'old_packages':[{k:v for k,v in x.items() if k!='files'} for x in old_packages],'worker_status_rows':len(status)}))
