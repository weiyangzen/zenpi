# ZS1-070 — 当前 src/core.rs 完整目标文件理解，3.1.21

Worker A 候选，等待 master 逐文件语义审核；本报告不自行签署 G-FILE 或 G-STAGE，不更改任何接受状态。唯一 owned path 为 `Docs/learn/stage1_pi_mono/targets/zenpi/files/src/core.rs_learn.md`。所有产品代码、主仓与上游均只读；本轮仅在私有 `.ops` 构造报告、证据和未应用的正反向补丁。

## 对象与证据层级

当前主仓对象 `/Users/wangweiyang/GitHub/zenpi/src/core.rs`：278,737 bytes、6,869 行、SHA-256 `52311b129c0bb467abac36de216f5bc97bf3c4c42d03dcd6170a717339c2a869`。2026-09-13T00:39:49Z 先复制字节，再按连续 350 行完整读取 20 块，最后一块为 6651–6869，包括全部内嵌测试。每块远小于 256 KiB；`reading-ledger.json` 和 `chunk_manifest.tsv` 给出行范围、半开 byte 范围、hash 与实际阅读顺序，union 为 `[0,278737)`。初始 `capture.json`、`chunk-manifest.json` 中的 false 是阅读前计划，原样保留；实际完成状态仅在后续 reading-ledger 中记录。hash 和区间验证不能代替这次正文阅读。

authority 3.1.21，requirement digest `3456abcbbebbc4e0ab383c319851b0a6e71b19ee9b3c060a6e212f61a89c9d9d`；接受状态快照 `c392c1835d4749d4a6248a799b4317f165351cb6467d5f1527c10a88b7e1c25d`，捕获时 48/121。070 的正式 Depends 只有001，仍未接受且 canonical 未存在。010/011/012/013 是已接受的比较材料，不替代070，也不把待审018/028变成前置接受。状态数量只是捕获时间事实，非本报告功能完成率。

清单冻结基线是另一版本：157,476 bytes / `8e93d360ae897ce5f1d9c9f52ccdef89d1ad25369ac6b187dab252f3dc36a016`。旧070审阅对象也不同：241,312 bytes、5,928行 / `9f133ddefa374698002a59f65998843f9c52c41b3d923eb54888004625a78577`，authority 3.1.16。旧 `.ops/target070-ready` 全部文件原样复制至 `prior070/`，原 manifest 为 6,063 bytes / `7f36a6fcf373de3ea462c85b938c67f97192d87527271e000aa414d2d7022525`；旧 build snapshot 原址保留。本轮在完成当前正文之后完整阅读旧 README 和201行报告，不运行其中 Cargo、probe、unpack 或任何旧 runner。旧压缩源码、测试原始日志、失败观察、计数、工具链和 tar 均保留为历史，不以它们证明当前字节运行通过，也不声称本轮重读两份旧源码。

本轮新证据是完整静态语义阅读和有限上下文阅读，另至多一次冻结后的纯 Python 离线结构审计。没有执行 Rust/Node/Bun/SDK/PTY/HTTP/build/release、预算、117/131、FIFO/DTrace 或预热。下文行为判据是可实施的验证设计，全部标为未在本轮运行；内嵌测试也只阅读。离线审计不等同产品测试或接受决定。

## 1–350：数据合同、错误与状态的基本含义

WorkerExecutionBinding 是 workspace/blueprint/item/lease/policy 的相关性结构，验证四个 ID 非空、trim、长度及控制字符，两个 digest 为64位小写hex，expiry 比较真实 `unix_time_ms()`；它不是能力授予令牌。UnknownToolOutcome 保留 operation/turn/call/tool/policy/binding，工具结果另外区分 Succeeded、Failed、Denied、Cancelled、UnknownOutcome，不能用一个 `success=false` 覆盖这些恢复差别。

Turn::new/with_parent 构造时间戳与父关系；validate 检查 ID、parent 和 content byte 上限，不深验任意 metadata，也不单独禁止空 content。TurnInputRequest 默认 StartOrSteer，另携 expected ID 与 attachment refs。Started/Steered 才 accepted；NotSubmitted 有明确原因，和一般 Err 不同。文件头的“拒绝不进入 backend、不写 turn”只可用于未接受该输入的合同，不能推出所有错误无文件副作用。

AgentPhase 只有 Idle/Running/Closed，没有单独审批状态。AgentEvent 有输入接受/拒绝、assistant、handoff、tool call/progress/result、provider、error；它不是 RuntimeEvent::Completed。ToolCall 事件也不是 handler 已执行的证明。CompactionReport 同时保留旧摘要标记相关字段和语义压缩统计，不代表每次 compact 都请求模型或生成 checkpoint。

## 351–700：共享 owner、构造和输入服务

Agent 集中持有 SessionStore、backend、活动 turn、事件、工具 registry/context/policy/approval、资源 Arc/展开内容、附件、普通/worker ledger 和 live owner registry。`session_mut` 是受信任 Rust host 的可变入口；不能将这里的封装描述成对恶意 embedder 的安全隔离。AgentError 给出稳定 code，BackendError 委托 backend code，Debug 只显示有限状态。

emit_tool_event 在 live sink 和内部 Vec 二选一；publish_output_progress 总会排空有界进度队列，无 sink 时丢弃进度，不累积无限历史。with_live_tool_events 的 Drop guard 在正常返回、Err 和 unwind 恢复之前的 sink；它不捕获 sink panic。无 sink 的普通事件 Vec 没有在本文件统一设置容量，故不能把 output progress 的边界外推为所有嵌入 API 事件都严格有界。

Agent::new 建立 Idle 与 session-scoped InputPort，将恢复出的中断 operation 变成内存 Error；不会自动重试，也不在构造函数里确认恢复。acknowledge_recovery 才写恢复记录。input_queue_request 只拒 Closed，再 recover/execute；receipt 不等于模型已消费。input_boundary 先 service，再取消 gate 或获取边界、apply、repair projections；preparation/工具整批边界由其它方法配合控制。repair 错误与队列解析错误分别向 Recovery/InvalidTurn 传播。

prepare_project 从 canonical cwd 建 ToolContext、解析配置（echo也解析）、新 backend/session、恢复 model/resources、注册工具/扩展、默认只读审批，返回独立候选 Agent。旧 Agent 不被提前覆盖，但候选 session 打开、扩展进程准备及资源读取可有实际 IO，不能称准备失败全文件系统无变化。CLI/profile overrides 随候选传递；真正项目 tab/pool 发布由 host 负责。

## 701–1050：mailbox、选中分支和输出清理事务

live register/heartbeat/unregister 维护租期；claim、finish、finish-with-reply 委托当前 SessionStore，不执行 worker、provider 或 scheduler，也无统一 phase guard。history 是物理 turn 列表，selected_history 是选中 leaf ancestry。tree_request 验证协议/session/Closed/cancel；List 可在 Running，其余要求 Idle，且无 pending queue、unknown tool、generic recovery、staged attachments。Select 先检查 ancestry、backend model history、候选 checkpoint，再 durable select；Fork 返回新 journal 的身份与快照，不把当前 Agent 切换到 fork。后续 page/snapshot 序列化失败不会撤销已经完成的选择或 fork。

output_control 分发 read/cleanup，cleanup 需要显式 confirm。read 仅 Idle，访问由本 session 的可信 capture 引用推导。cleanup 也要求 Idle 且无 generic recovery；指定 call 必须有本 journal capture。当前实现先复用或创建一个 session 级 cleanup intent，冻结完整 artifact 身份、上限和作用域，再执行删除/retirement，写 receipted 及完成记录。pending intent 禁止换作用域；新的 capture 也会被拒。缺 store 只有空 plan 可完成，有待恢复内容时按 Interrupted 处理。

删除发生后 receipt 仍可能失败；当前新增 durable intent 与 retirement 让同一作用域重试可解释并避免重复计数，不能称出错即文件保留或回滚成功。完成之后的 retirement acknowledgement/GC 失败被有意忽略，留下可恢复元数据和保守配额。旧070的“无 intent 的删除后 receipt 错误”探针属于旧hash；不能拿旧通过数证明新恢复链。当前文件末尾提供的新恢复测试设计见下文。

## 1051–1400：model/persona、工具与附件公共 API

set_model 拒 Closed/Running，先验证 model 和选中历史；有 descriptor 时写 model_selected 后赋值，无 descriptor 的 backend 可只改内存。set_reasoning_effort 要 Idle 且 registry 存在，校验能力后 journal 再 commit backend effort。恢复取全 journal 最新 model_selected（并非按 leaf 过滤），saved descriptor digest 必须与当前精确匹配，effort/history 必须有效；无记录用当前 factory model，无 registry 保留当前选择。restore_model_selection 自身无 phase guard，是低层 host 合同。

model_status 展示 registry、capabilities、有效预算等；descriptor 读取错误在 context_budget 中退为 unknown-model 保守 cap，不是无限预算。persona 取全 journal 最后合法值，默认 INTJ；setter 只允许 Idle、验证后落盘。snapshot/take_events 是内存视图/移出队列，不能代替持久化 checkpoint。

set_tools_with_resources 要 Idle，局部注册成功后才调用 set_tools。直接 set_tools 无 phase guard，先关闭旧扩展并记错误，再换 registry/context/policy、有效 remember 策略及新 coordinator，清 worker binding 并恢复默认非强制串行。set_attachment_workspace 同样无 phase guard；没有工具时创建空只读 registry。set_approval_policy 也没有 Idle guard，保存 configured 与重放 session remember 后的 effective 策略。

stage_attachment 仅拒 Closed，校验数量/引用并读取本地文件证明当下边界，随后只保存 refs；准入会重新 materialize/hash。它可在 Running 被 host 调用，pending getter/clear 为低层入口。URL/file ID 此处不联网；文件字节只放 RequestAttachment 内存，journal 保存引用/hash/size。worker binding setter 要 Idle，拒已有 extension hooks，校验 expiry 与 gate 绑定；有 gate 时不可简单清 binding，绑定字段一致也不代表该工具已获执行授权。

## 1401–1750：worker admission、恢复和审批持久化边界

admit_blueprint_worker 要 Idle 和已配置 worker ledger，校验 policy/lease 相关性，编译 capability gate、临时换 context/binding，然后 validate evidence。失败恢复内存旧值。成功 open lease 后 reserve admission，再写 worker_admitted(execution_started=false)。reserve/admitted event 失败会尝试 durable revoke 和内存恢复，但 revoke 错误被 `let _` 忽略；这里不是跨所有 append 的绝对原子事务，也没有真正启动 worker。

unknown_tool_outcomes 顺序折叠 started/unknown、finished 和 recovery_decided；只有非 unknown finished 或显式 decision 能去掉该 pending。generic operation recovery 是另一屏障。resolve_tool_outcome 要 Idle；缺 durable result 时先补诚实的 unknown failure turn，再写 decision，最后 generic finish Interrupted；user_shell 补 User，模型工具补 Tool。每次 append 可单独失败，部分进度不自动回滚。Retry/Abandon 是恢复决策，函数不会重放旧 handler。

respond_to_approval(1654) 实际仅 coordinator reveal/respond；虽然注释提到 durable，这个 `&self` 方法不写 journal。真正执行 owner 在 prepare_tool 或 user-shell 中等待 accepted，调用 persist_accepted 后才 dispatch。调用方收到 respond Ok，只能说明协调器接受，不能宣称 approval_resolved/consumed 已 durable。

set_context_budget 无 phase guard；set_summary_cost_limit 要 Idle，以 restore 候选 ledger→设置→persist→赋值避免发布未持久化配置。ensure_summary_ledger 懒恢复；若在 Running 中创建，则补占 turn 并发 slot。摘要报价是保守估计，未提供价格不等于零账单。

## 1751–2100：语义 checkpoint 的完整提交链

prepare_semantic_provider_context 先取消/容量检查，从选中 ancestry 与适用的语义 checkpoint 构造 provider context；预算内直接返回，不伪造摘要。超窗才创建 source/session/branch 相关 plan，按半个 input capacity 保留 tail，在 InputPump 下求安全切点。plan 错误转换与 pump.finish 都能终止流程；具体算法由 context owner 实现，不在070重签073。

summary_request_data、descriptor/model、固定 summary instructions 与源大小估算都在网络前准备；输出上限为 reserved 与4096的较小值，零输出/无法容纳源会拒绝。input 估算含 bytes/4 近似，不是 tokenizer 实测。报价按允许 input window 的 ceiling；先持久化旧 ledger，再 restore 候选，预留 input/output/network/cost 并 persist 后发布。取消可发生在 reservation 之后，保守占用不自动退款。

begin Compaction operation→semantic_summary_requested→backend complete_with_control，摘要请求不携工具/附件；TextDelta 超 MAX_SUMMARY_BYTES 即拒，摘要流不作为普通 assistant 流。requested 写失败会使已开始 operation 留给恢复。后端返回先处理 pump，再记录 raw response：UTF-8 有界前缀、完整hash/bytes/truncated，annotations 超界则省略并记hash。reported usage 用于增量补 charge，低于 reservation 不退款，价格估计不能冒充账单。

raw receipt 后再检查 cancel、实际输入预算、validate_summary_completion，finalize 对当前 selected source 重新验证，append_semantic_checkpoint_for_operation 提交，最后 restore checkpoint 得到 context。严格输出检查和 source/branch freshness 的算法边界来自 context/session，已接受012报告提供比较依据；这里可直接确认实际调用顺序。checkpoint append 成功之后 restore 或 finish_operation 仍可能失败，返回 Err 不证明 checkpoint 未提交。Compaction 终态区分 Succeeded、Cancelled、provider传输/HTTP/InvalidResponse的 Interrupted、其它 Failed；finish 的 `?` 可替代原始错误。

manual compact 要 Idle、无 generic recovery，设置临时 input scope/preparation，调用同一链后清理普通 Result 路径；没有覆盖所有 panic 的独立 scope guard。比较前后 checkpoint，预算内可记 skipped；最后统计 marker 写失败仍可能已有新 checkpoint。source_turns 是物理数量，prepared_turns/tokens 是当前选中 context，不能互换。

## 2101–2450：扩展生命周期、资源代际和低层 ledger

当前新增 prepare_extensions：Idle、已配置 tools、禁止 worker binding/origin；准备候选 runtime、clone registry、移除旧扩展工具并注册候选，未发布前可失败。configure_extensions 取消复查、extensions_selected 落盘后 publish；publish 关闭旧扩展、换 registry/runtime，再发新 session start，close/start 错误转 Error 事件，不回滚已发布状态。notify_extensions 对 worker 跳过，记录有界/脱敏策略由具体 error helper 处理，不是所有错误都阻止主循环。

configure_resources 本身只拒 Closed；带 extension paths 时准备扩展又要求 Idle，因此不能笼统声称“所有 reload 均可忙时成功”。候选 reload/取消/扩展准备/取消/资源 provenance append 都成功才换当前 skills/loader、清 stale、发布扩展。活动 turn 的 Arc 仍固定旧代际。restore_resources 要 Idle，fresh reload 真实文件并对历史 skill hash 标 stale；reload 复用配置路径；status 展示各类前16和总数，不把截断视为完整清单。

prepare_resource_input 识别 resource slash，先拒 host 控制命令；显式 /skill:name 检查 stale、load_body，args/provenance 用 JSON 和字面文本拼装，超 MAX_TEXT_BYTES 拒绝；模板需存在、非空、展开有界。检测候选的 trim 与真正 skill strip_prefix 并不完全同一规则，不能承诺任意前导空白等价。active text/skill body 留内存，journal 只记录 provenance。set_skills 无 phase guard，清 loader 但不清 stale map；所有 setter 并不共享用户命令的完整门禁。

set_resource_limits、set_worker_budget_limits 无统一 phase guard，恢复 ledger，后者可写恢复记录。settle/renew/cancel/expire 将实际 usage、取消 directive 和 lease 委托 worker owner；host 声称的实际进程统计并非本文件独立测量，cancel directive 不是 child 已回收证明。

## 2451–2800：外部证据入口与显式用户 shell

external_evidence_control 要 Idle、无 generic recovery、workspace 可用；必要时恢复 worker ledger，再将 session、output owner、预算和取消交给 domain_execution 的准备/执行接口。当前接线确实存在，旧070“116尚无接线”不再描述当前文件；但调用接口不等于外部 artifact、validator 或完整产品116已验收。该 owner 的 hash/signature/执行实现不在本轮全读范围。

run_user_shell_with_cancel 要 route_input 的单 `!`、非 Closed/Running；空命令返回帮助，unknown/generic recovery 阻止新副作用。clone ToolContext 改 UserShell origin 但保留 worker gate，计算 policy digest；先记脱敏 user_shell_input，再做 worker-origin拒绝、gate、SideEffectPolicy、approval。因而被策略拒绝也可能已有输入审计事件。审批等待合并 cancellation epoch，persist accepted 后 remember；否决不会进入 handler。随后再次取消/gate，预留 process，begin Tool operation、写 execution_started，再建立 capture 并调用 RunCommand。

execution_started 是保守 dispatch intent，不是已经产生 OS 副作用的证据；capture 初始化都位于它之后。progress 在取消 poll 中投递，返回后排空并先持久化 capture。RunCommand 子进程监督/回收属于 tools owner，本文件只调用，不自行 kill。返回内容 redaction 后分别截 stdout/stderr 至12KiB安全边界，附 command/input/operation/policy，作为明确不可信的 User turn 进入模型上下文，非 Tool role。

## 2801–3150：shell 终态、准入与 steer/reissue

shell exit0 且非 timeout/cancel 才 success，先结果 turn、execution_finished、generic finish，再 ToolResult。错误分支写 user_shell_error 并产生 AgentError；错误记录写失败可能替代原 error，且不统一 finish 所有已开始 operation，恢复线索可能保留。该方法本身不把 phase 改 Running，依赖持有 Agent 的串行 host 工作闭包；不要据此宣称它可与其它 &mut Agent 操作安全并发。

submit_with_cancel 优先拒已取消的 resource candidate，再 Closed、Idle recovery屏障、空白 NotSubmitted、大小/`!`/附件/expected ID。StartOrSteer 有 active 直接 steer，并不走显式 Steer 的 active_steerable 检查；该字段在本文件都设置 true，没有可公开设置 false 的路径。StartIfIdle、Steer 的其它拒绝原因明确。accepted 才清 pending attachments。

普通文本没有统一 pre-cancel admission 检查，可能先 durable user turn，再执行阶段观察 cancel；resource 候选有更早检查。NotSubmitted 不写该新turn，某些前置 repair 却可能写此前已接受队列的投影，所以不能把任意最终 Err 解释成“session字节没变”。start_new 修复队列、准备资源/附件、validate 并 append 后，才发布 active Arc/inputs/attachments/id/scope/Running 与 accepted event。

steer_existing 用活动代际，检查活动附件数量及累计 resource 文本 bytes，把新 User turn parent 指同 active ID，落盘后更新内存。附件 bytes 的总量限额按单次 materialize 计算，不能从这里推出跨所有 steer 的累计 bytes 也等于该上限。start_reissued 是 host 已 cancel/join 后的新 attempt：只做自己的 Idle/message/parent 等检查，不重复 submit 的 unknown/generic recovery 或 `!` 门禁。其公开 facade 不自行执行 cancel/join；前置合同不能由方法名称证明。

## 3151–3500：附件和活动 turn 错误收束

reissue 暂取 pending refs，materialize/validate/append 失败恢复 refs；新 turn 指向 superseded ID，metadata 标 cancel_reissue，成功建立新 scope，返回 Steered(newID)。materialize 先校验 model image/file 能力（descriptor存在时）、每个 reference，再用固定 workspace ToolContext 读取本地文件，限制单文件和本次总量，计算 hash/size/basename；该方法无外部取消参数，不能宣称每个文件读都有此处的外部 cancellation check。

run_active_turn_cancelable 包装先保存 turn ID，收集 ProviderEvent，主运行结束后才追加关联事件，因此内部 Vec 的跨类型顺序不代表完整实时顺序。带 sink 的主实现合并 host cancel 与 approval epoch。当前把 governance ensure、charge concurrency/persist、begin provider operation 放在专门 admission closure 中；失败会清 active/scope/资源/附件、Idle/Error，并仅在曾预留时 release，不伪造 finish marker。旧070“这两个早期错误卡 Running”已不适用于当前字节；本轮没有重跑旧探针确认修复。

AgentStart hook 后 complete_with_tools，再 AgentEnd hook；End reason 由循环结果决定，时间在最终取消复查、assistant 验证和持久化之前，故扩展 End 不是 durable assistant terminal。循环 Err 将 cancel/steer 分为 Cancelled，provider传输/HTTP/InvalidResponse 为 UnknownOutcome，其它 Failed；清内存状态、Error、finish，再 release。末端取消、空回复、assistant validate 也各自清理并写对应终态。

## 3501–3850：assistant 提交、provider 循环和 durable 输入

assistant append 失败走 Failed；成功路径 append assistant→清 active/Idle→finish Succeeded→release concurrency→AssistantMessage→返回。多处 finish_operation 使用 `?`，失败可能跳过 release；即使 assistant 已 durable，也可能没有 AssistantMessage/成功返回。release 的 persist 错误只记录 last_error/Error，返回仍可为成功。没有一个 finally 使所有异常都自动关闭 journal marker 或释放持久化额度。

complete_with_tools 禁止 worker extension hooks，冻结 model skill scope，处理 input hook/修复 queue。最多8工具轮，另有 input continuation 上限，避免输入轮冒充工具轮。每轮 boundary 服务输入/取消/预算；advertised tools 取 model 能力和 skill policy 交集，不等于 registry 中全工具已获准。instructions 合并 persona、skills、活动资源等，bytes/4估算先从模型输入预算扣除，不足则拒。

preparation gate/guard→semantic context→替换活动模板与 extension input→重新估算→finish_prepare；只有初始空且尚未提交的边界会因为新输入重做准备，不能在已提交非空边界重复消费。input/network 预 charge 并持久化后调用 backend，Request 携当前 model、selected context、工具定义、instructions、attachments 和 output cap。InputPump 覆盖调用，pump.finish 先于接受 backend response；reported output 再记账、检查 cancel。

refusal 清 tool_calls，必要时以 refusal 填 content，直接返回，不在该分支消费后续队列。无 tool calls 时 service/recover queue；没有 pending 才最终返回，否则在 continuation cap 内先 append 中间 assistant，换 gate，再在 would-stop boundary apply/repair 后继续。后续取消/失败不撤销该中间记录。上限耗尽保留尚 received 输入，不靠静默驱逐获得完成。

## 3851–4200：串行/并发工具批次与不可回滚效果

整批 validate_provider_calls 在 assistant call turn 之前；之后 evidence、assistant call metadata、tool batch gate。任一非 parallel 工具、强制串行或 BeforeTool/AfterTool hook 使全批串行；否则由调用数、MAX_BATCH_CALLS、ledger可用 concurrency 决定，当前 turn 已占的一槽计入可用执行数。

串行每 call 先 ToolCall，再 begin Tool operation；已 stop/cancel 的剩余 call 生成取消结果而不执行，逐个 persist 保持 call/result 配对。普通 Failed/Denied 可反馈模型；Cancelled/Unknown 终止本 turn。成功整批后才 tool_completed 并进入下一输入边界。已经完成的 handler 副作用不因后面失败回滚。

重要静态缺口：3931附近对 invoke_tool 的任意 Err 都按“pre-dispatch”包装为 Failed/Internal 并 stop；但 invoke_tool 在 execute_tool_batch 返回之后仍有 capture receipt、pump.finish、batch转换可失败(4664–4677)。若该后处理失败而后续 persist 恢复，包装可写非unknown finished 并清除 dispatch pending。持续存储故障常使后续持久化也失败并保留恢复线索，但这不是所有执行后错误都保持 UnknownOutcome 的保证。本轮只确认可达代码顺序，未注入瞬时磁盘故障，不宣称已观测具体丢失。

并发路径先预留 extra concurrency，在 closure 内 persist、开始各 operation、调用 execute_tool_batch；prepare callback 仍串行通过 core policy/approval/marker，失败记录 fallback并 halt。cancel poll 尝试借 owner service InputPort，输入错误保存并停止。batch 错误可在结果持久化前返回，已开始 operation 交恢复。成功返回后按 provider 原顺序 zip/persist 所有结果，最后释放 extra 并持久化，`result.and(released)` 同时失败时保留原执行错误。join 约束是底层 executor 合同，不在本轮独立全读/实测；core 的 result 事件是 join 后源顺序，不是 pi010 的完成顺序。

evidence digest 覆盖 workspace/policy/approval/skill过滤工具定义；worker origin 由 binding/context 判断，policy digest 优先 gate、binding、再 snapshot。prohibition_gate_enforced 起初 false，只有匹配的实际 preflight 才 true；相关性字段不冒充权限执行。

## 4201–4550：批准、预算和 dispatch 前后的 hook

prepare_tool 检查注册、skill allow、binding有效、gate与binding一致、SideEffectPolicy、ApprovalPolicy。否决返回 Denied；preview失败为 Failed；询问用 session/turn/call/policy 的稳定 hash request ID，InputPump 覆盖等待。accepted 必须 persist_accepted，再 remember，再 approval_consumed；因此 consumed append 失败时 remember 内存可已更新，不能称所有批准记录是一笔事务。Deny不执行，worker preflight 自动允许也有来源事件。等待后再次检查 cancel/binding expiry。

process预算对 command预留1、search预留其完整扫描预算；workspace write 只识别 write.content / edit.new 大小，不支持的 writer 在有ledger时拒绝。额度保守保留，不按失败自动退款。execution_started 最后写在实际 handler 前，也在 capture初始化前；ExecuteApproved 携已审 preview 交 executor 继续约束。

invoke_tool 的 BeforeTool 路径先验证原始技能/策略与 call，再运行扩展并验证改写后的 call；改写 args 记脱敏事件。取消和否决分别归类。改写合法性的深层规则委托 extension_runtime.validate_hook_call，本文不将未独立读取的同ID/name约束实现当新证据。普通全批有 Before/After hook 时已经在并发选择处强制串行，worker hooks 被更上层拒绝。

## 4551–4900：capture、结果分类与 durable tool receipt

准备获准后，read_tool_output 禁止 worker 借用 host artifact 权限，解析请求并取可信引用；run_command 的非worker调用建立 capture并升级 decision。output_read context失败可返回 Denied，capture准备失败可 Err；前面 started marker 已可能存在。随后 InputPump→真实 execute_tool_batch→保存 pump result→排空progress→持久化 capture→检查 pump/batch→finish_tool_result，这个顺序是前述 post-dispatch 缺口的依据。

成功结果可经 AfterTool 改写并再 compact，扩展/compact失败只记 extension Error，保留原成功结果，不撤销效果；是否随后终止取决于后续取消边界。finish_tool_result 的 compact失败明确为 UnknownOutcome；非只读 Io/Internal/Timeout/Cancelled 也 Unknown，Readonly Cancelled 为 Cancelled，PolicyDenied 为 Denied，其它 Failed；结果 ID/name 归一为原 provider call。

persist_tool_invocation 序列化 result/capture 和 outcome/evidence，`implementation_complete:false` 不允许工具结果自我宣布产品完成。成功 load_skill 还取实际 metadata，读取失败可在 handler之后、turn之前返回。append tool turn失败尽力写 unknown marker；成功后依次 execution_finished→ToolResult事件→generic operation finish→worker admission settle/clear。ToolResult 不代表后面的 generic terminal/预算结算已经成功。worker settle 此处使用固定 processes:1/concurrency:0，非真实所有进程的动态统计。Unknown 用 Interrupted 保留人工决定语义。

context_source_for_provider 只接受所选 ancestry 上有效 semantic checkpoint，否则完整 selected history；旧 digest checkpoint 没有语义摘要，不能当压缩后的模型上下文。

## 4901–5250：facade、handoff、新建/恢复 session 与 close

process facade 只对 accepted submission 执行 turn；process_with_cancel 默认 provider sink 是 no-op，不等同 run_active_turn_cancelable 的事件收集包装。reissue facade 依赖前述 host 已停止旧请求前置合同。handoff/record/runtime intent 只拒 Closed，验证后 append，handoff再发事件；runtime intent 是惰性记录，不启动调度或外部执行，属于本文件需解释但不直接对应 pi主循环的历史host能力。

new_session_with_commit 要 Idle、无 pending queue/unknown/generic recovery/staged附件；取消检查后在同workspace创建 fresh候选 journal，写 model/persona、准备 replacement、host commit，再 retain文件。失败先候选cleanup、刷新旧扩展 audit tail；清理失败可返回 CandidateRetained，刷新失败也可能替代原 error。候选文件/扩展初始化已经发生，不是失败时全 IO 撤销。

resume 只做 Closed/Running与workspace门禁：先 readonly inspect header.cwd，canonical 比较当前 journal workspace，再 writable open。它没有 fresh/new 的所有 pending/recovery/attachment拒绝，可能经成功替换丢弃旧暂存内存。replace 准备普通governance、resources、model/effort、extensions，检查cancel后调用host commit；成功才撤销旧InputPort scope、建立新session port/output owner、切store/approval/model/resources并清活动内存，最后publishextensions。publish后的生命周期错误记录为事件，无回滚Result。

replacement 没有重建或清除 worker_budget、worker_admission、worker binding/context、live owners；跨session生命周期仍需受信任host约束，不能声称所有权限与租期已自动重新授权。try_close 先closeextensions并记录错误，再逐个static skill session_close输出append；中间失败可能已有部分记录、extension已close但phase未Closed。全部成功才丢output内存handle、Closed、清scope。close包装在try失败也强制Closed并记Error。这里没有任意线程强杀、child join或所有operation finish；磁盘未过期artifact保留。

## 5251–5600：辅助标识与完整 CLI 参数分发前半

close余部、ProcessResult和时钟/ID helper都已阅读。next_id 是毫秒+进程内原子counter，不承诺跨进程UUID唯一；tool op hash用turn+NUL+call，approval ID用JSON tuple hash避免字段拼接歧义，provider idempotency取turn hash。附件journal metadata含reference/hash/size，省略raw bytes；worker gate helper逐项比对，不能跳过真实工具gate。

RunMode 仅 Tui/Headless，默认TUI/defaultsession/openai，没有按tty自动引入第三模式。parse_args先识别 config/pair/session/extension命令组，action枚举、--json/--yes使用位置、source/destination/GC上限都有各自检查。组分支 --profile 写 command_value，和普通模式严格profile字符检查不是同一规则；不要为所有CLI参数虚构统一验证。session gc需要retain、age和yes；fork/export/import需要两路径，未知action/参数错误直接返回。

## 5601–5950：CLI 参数、backend factory 与管理命令

普通参数支持inline等号；tui/headless拒带值，mode仅两值，session非空，backend非空无control，model<=256无control，profile<=128且ASCII字母数字_-；help只设true，不对inline值作同样限制，重复参数按顺序覆盖。具体backend名单在factory检查。

make_backend的echo仅显式dev-fixtures，生产backend从workspace config解析；backend_from_effective检查URL、必要key、model，约束Anthropic/Google native wire，读取registry overrides，设置默认timeout120/retry2。core只构造统一backend与调用接口，不实现 HTTP/SSE/strict JSON、原生signature或重试算法，不能由factory接线接受075或108–110。

run先parse/help，再管理子命令早返；config/pair/status/doctor/list/use/import/revoke、session管理和extension catalog均委托各自owner。状态打印credential存在与否，不打印key。管理命令不进入Agent loop；它们属于完整文件范围，却不是pi agent-loop等价项。本文评估参数、分发、副作用委托和错误传播，未扩展成重新验收配置安装全产品。

## 5951–6300：CLI boot、capture与provider整批验证

session list可fallback legacy，inspect可输出turn；fork/export使用SessionStore::open，不能仅凭“导出”称源文件打开绝对不写；import/GC/catalog写操作的原子性由callee实现。普通启动先backend/session/Agent、project overrides、ack恢复，再工具context和resources/extensions；Headless ApprovalPolicy::Always，TUI ReadOnly，随后选/恢复model，分派 run_stdio_owned 或 run_async_with_profile。此处注册完成所以setpolicy的Option可用，但API普遍返回None的可能仍存在。

tool_failure保持call身份，将message UTF-8截至4096；没有在该helper显式脱敏所有error。pending_output_cleanup反向折叠当前session的最新started/finished。begin_output_capture拒未完成cleanup，预留双流最大disk并persist，取得store后做过期维护再newcapture；capture失败可能已有预算占用/维护副作用。persist_output_capture只是append receipt。

validate_provider_calls最多32，扫描同parent历史call IDs防复用，逐call验证ID/name长度控制字符、args object、单call bytes与总256KiB（含数组边界/分隔）。它不是每种工具schema验证，也不处理原始JSON重复key；后者归backend。所有call整批验证在assistant工具调用记录前发生，已写其它旧queue projection并不在“该批无写入”的承诺内。

## 6301–6650：资源恢复、可信引用和扩展恢复测试前半

打印helper、ResourceError转换、default_resource_paths完整阅读：user与cwd/.zenpi skills/prompts、extra paths/text为空。resource_selection_event只记paths/generation/skill hashes。restore_resource_state取全journal最新paths fresh reload，再顺序折叠resources_selected及使用skill metadata；当前仍存在且hash变化的skill标stale，消失skill由后续lookup拒绝，不自动恢复历史body，template不套用相同stale机制。

trusted_output_reference只从真实capture events取artifact，要求同session/call/version，并有更早同operation/turn/call的 run_command 或 user_shell execution_started；重复artifact冲突拒绝。expiry、finalized、stored<=observed、创建/过期顺序、TTL<=7天、最大文件bytes、小写SHA、complete对应无failure/truncated且stored=observed、offset上界逐项验证。finalized但incomplete可读已保存前缀；实际文件hash/inode边界仍委托ToolOutputStore。模型复制的一段Ref文本不授予权限，但可信journal writer前提也不是对任意session_mut的恶意host防护。

extension_agent_error将Cancelled映射backend取消，其它为InvalidTurn。cfg(test) extension_resume_commit_tests 内 Python扩展fixture只作为测试源码读取：候选初始化允许已运行；host checkpoint失败须保留旧session sequence/lease/registry可用，之后旧工具仍能执行；重试成功才close旧/start新，旧registry失效。这是具体可运行判据，070未启动Python扩展或测试二进制。

## 6651–6869：全部内嵌恢复测试尾部

完整读完扩展测试结尾及 output_cleanup_recovery_tests。captured_agent的测试配方使用实际 user_shell产物，fail_receipt把journal路径临时替换为目录，在raw删除且retirement存在后制造receipt错误；本轮并未执行该配方。第一测试要求同Agent重试同scope，禁止新capture/不同scope，最终计数不重复，再次cleanup为0；第二用current_exe子进程helper重开恢复；helper标ignored并由父case指定调用；最后以三种tampered/missing/replaced retirement变化要求fail closed。

本文件共5个 `#[test]`：扩展1、输出恢复3个父测试及1个ignored子进程helper；本轮执行数为0，不能报“5通过”或把helper当新的独立生产场景。测试会触发shell、Python扩展、文件删除、journal故障和独立进程，正因如此只读源码，没有违反本轮禁止产品运行的边界。

## 已接受源行为的反向映射

本轮完整读010/011/012/013 canonical报告及各3.1.21 rebind；`context-receipts.json` 保存5项（含001）master receipt与197个引用artifact的字节副本。其余历史artifact只保全身份，不宣称重新逐一语义阅读。源文件正文/源测试这轮未再执行；下列源语义来自已接受报告，不用本轮target hash伪装新的上游全读。

| 源 | 已接受行为 | 当前core对应及有意差异/缺口 |
|---|---|---|
| 010 agent-loop.ts，803行，1e16404a… | context与continue的引用边界；初始空prepare poll、steer内循环/follow-up外循环；全批sequential或parallel，before/after hooks、输入顺序准备、完成顺序end事件、源顺序结果；异常可能逃逸callback链，取消协作式。 | complete_with_tools、InputPump/gate、8工具轮+独立输入上限、按journal持久化消费。core并发结果在batch返回后源顺序发布；有hook全批串行。新增预算/approval/unknown recovery是本地责任，源无durable队列与重启保证，不能复制其弱边界。 |
| 011 agent.ts，592行，25b52fda… | 浅层数组复制、嵌套引用共享；两条无界内存队列，one/all、steer优先；activeRun/finally清理、waitForIdle不以运行错误reject；listener抛异常可中断事件，abort不等于reap。 | Agent同步owner和host锁、bounded ticket owner、journal接收/投影、phase与operation分离。当前early-admission清理已经存在，但finish `?` 仍可跳过release；不要从source finally推导Rust全异常保证。 |
| 012 harness compaction.ts，865行，6e7aec0d… | 启发式token、安全切点有限；允许split user turn，未一般验证call/result；请求history后prefix、信号由callee协作；空/length/toolUse等输出可成功，语义保真由模型/host承担。 | selected semantic source→保守预算→raw response→严格validate/finalize→durable checkpoint。context/session实施whole-turn/source/branch/usage规则；结构校验仍不证明模型prose完全保真，receipt后的Err不自动回滚checkpoint。 |
| 013 session/context.ts，64行，409078e3… | 取path最新compaction及retained tail，过滤error/aborted/deferred assistant；branch/custom projection顺序执行；调用者负责ancestry，函数本身无journal事务/预算。 | selected_history与context_source_for_provider只采用适用语义checkpoint，再构建模型上下文。013旧target说明中“104还需选择checkpoint”的未来式不代表当前缺失；本轮已直接读到core选择分支。物理history仍供审计而非默认provider input。 |

018 session-manager / 028 agent-session 在捕获时未接受，不拿它们证明上游全会话持久化合同。资源/extension/search/mailbox、项目、CLI这些分支已在本文件完整解释，但未因与010–013无一对一等价而省略，也未顺带接受其相邻文件/目录或产品项。

## TUI/headless 的有限调用上下文与终态顺序

只读这些明确范围：runtime 1–195、630–782；headless 3880–4042、4260–4505、4808–5085；TUI 11330–11395、11600–11795、12240–12475、13933–14075。完整相邻文件没有读完，不能用这些范围接受071/084/085。`context/segments` 按真实行/byte保存所读文本及整文件身份。

TUI请求闭包持有指定Agent锁，在with_live_tool_events中把工具事件写入请求buffer，provider sink同样入buffer，再调用process/user_shell/resource。core成功返回后token.mark_completed，防晚到cancel把已成功结果重新标Cancelled。drain_tui_provider_events明确跳过ProviderEvent::Completed的终态意义，一个core turn可能有多次provider请求；RuntimeEvent::Completed才排空末尾buffer、清approval/busy、以最终assistant替换临时流。非当前job的过期buffer丢弃；失败/取消/panic丢临时流并更新工具状态。buffer丢事件会有可见warning，最终ProcessResult仍为答复依据。

headless在请求闭包里检查expected_session，保存submission turn_id并在持Agent锁时移出accept事件，实时tool/provider各入请求buffer；结果或错误后先复制剩余Agent events，成功才mark_completed。NewSession CandidateRetained另标completion，以避免取消覆盖该需恢复的具体错误。普通drain保证admission先于该请求provider展示，但provider/live分开排空，不承诺所有类型严格原始交错顺序。慢stdout编码/写入在释放mailbox锁之后执行。

headless Runtime Completed保留steer correlation，移除job/请求映射，按admission、provider、余下Agent及drop说明排空，再write_cached_response成功/错误/cancel/panic。若输出/replay IO失败，不能证明客户端已收到终态。core durable assistant、runtime内存completed标志、wire缓存/响应是不同提交边界，三者不是一个原子事务。

runtime CancellationToken用两个atomic，mark_completed使late cancel失效；classify_execution在未completed且cancel时优先Cancelled，否则映射Result/Panicked。start_job以catch_unwind保护运行器进程，finish_active通过bounded channel发送Completed，Closed属于整个runner。模块合同允许非合作任务在shutdown grace后detach，取消不能撤销副作用，Completed不是任意Rust线程已被强杀。本文读取了合同与分类/发布函数，不声称审核了整个shutdown循环或全部并发race。

## 可运行行为判据与本轮证据限制

以下是对上述各功能的具体复核设计，不是新增执行记录；执行均应在独立受控scratch、真实产品owner及必要本地HTTP/OS边界进行，由master另行决定。不能用Echo、只compile、hash或结构assert替代业务行为。

| 功能组 | 输入/故障与必须观察的判据（本轮未运行） |
|---|---|
| Turn/模式/expected/phase | 调用submit空白、超字节、wrong expected、StartIfIdle/Steer组合；对比submission、active/scope、前后journal，验证NotSubmitted不出现该新turn；另以pre-cancel普通/resource输入比较durable差异。 |
| queue与prepare/工具boundary | 请求期间用真实InputPort提交one/all/steer/follow-up及edit/cancel；阻塞provider/approval，核对receipt→消费marker→User投影次序、整批后消费和continuation cap；重开验证repair不重复注入。 |
| model/persona/attachment | 切model/effort时注入append失败，比较内存与journal；更换descriptor digest恢复应拒；本地附件在stage后改bytes验证admission重读，越workspace/超量拒绝、journal不含raw。 |
| tree/history/checkpoint | 构造A-B/A-C两个leaf，List忙时可用、Select忙/pending/recovery拒；用实际backend请求记录确认只含selected ancestry，取消/坏history/坏checkpoint不发布候选；fork不切当前owner。 |
| compaction/预算/取消 | 用真实本地HTTP summary请求记录检查instructions/无tools/输出cap；返回空、length、refusal、toolcall、坏usage/metadata、失效source，验证raw receipt与checkpoint分离；在reservation、appendcheckpoint、finish各阶段注入故障，比较旧新checkpoint与额度，不以Err推断全无写入。 |
| active终态/并发slot | max_concurrency=0及begin写失败应Idle/无active且User保留、backend未dispatch；assistant append成功后使finish失败，分别检查已有assistant、operation恢复、缺AssistantMessage和slot；release persist失败检查Error与成功返回可并存。 |
| sequential/parallel工具 | 实际registered工具记录start/end且带受控barrier，验证任一Sequential/hook令全批串行、全Parallel上限、结果source顺序、停止后剩余call结果配对；非只读timeout/cancel应unknown；执行后仅capture/pump瞬时失败再允许journal写入，检查前述Failed包装缺口，不把成功复现当修复。 |
| approval/workergate | coordinator.respond Ok时先检查journal尚未accepted，再释放执行owner验证persist-before-handler；deny/cancel/lease等待过期及gate撤销都不进入handler；consumed/revoke写失败对比内存remember、lease及恢复marker，拒绝“所有补偿必成功”。 |
| output/user-shell | 真实本地命令产生双流并取消/timeout，检查User角色、脱敏截断、capture哈希、未知marker；伪造artifact文本、异session、过期/不finalized/冲突refs拒读；执行当前内嵌cleanup3父case与其指定helper验证retirement恢复，不复跑旧recipe冒充新链。 |
| resources/extensions | 活动turn阻塞时reload无extension资源，比较active Arc与next generation；有extension配置忙时拒；失效skill hash拒显式load；Before/After和input/context hook取消/改写/失败各看journal与原result。运行本文件extension resume测试验证host commit失败旧lease仍可执行，成功才换owner。 |
| new/resume/close | 同workspace fresh候选/host checkpoint失败、cleanup失败、成功切换分别看candidate保留说明/旧port失效/approval重放；resume的staged和worker字段按实际合同检查；skill close第N次append失败应观察部分记录而非假设全无。 |
| mailbox/handoff/worker预算/external证据 | 注册lease并claim/finish/reopen，确认没有隐式provider/worker启动；handoff与runtime intent append后只见记录；预算reserve失败检查补偿可能失败；external_evidence入口用真实domain owner验证返回/产物/validator，core静态接线本身不算116通过。 |
| CLI/host事件 | parse所有管理/普通参数分支并确认错误未进入backend/session boot；在独立ZENPI_HOME运行真实CLI管理owner验证实际IO。TUI/headless用生产host接本地流式HTTP，多工具请求应只有runtime终态提交最终展示，末尾delta/approval/latecancel及stdout故障都核对journal与wire，不以Provider Completed早结束。 |

旧070报告记录的190顶层通过/6ignored及其fixture、原始日志原样存在，只属于旧hash，且有些“通过”是复现缺口；本报告不重新汇总或继承。当前内嵌测试5项只读，受控产品执行0次。accepted源报告原来的Node/Vitest执行同样不是070新增运行。

## 交付与接受边界

全文件20块逐行语义覆盖、源报告对照、host范围、当前静态缺口及可运行判据已成一份目标报告。主仓产品与owned canonical未写，070维持候选，正式G-STAGE未运行。正向patch仅创建唯一报告，反向patch仅删除完全相同报告；应用/回滚前需核对目标身份，不能撤销之后用户另行编辑的报告。

冻结 manifest列出全部payload，离线audit在完整静态读脚本后至多执行一次，只检查字节/范围/receipt/patch/保护身份；原始stdout/stderr/result及单次guard留ready外，防自改manifest。它无网络、无产品子进程、不导入产品、不执行旧脚本。G-FILE要求master亲读本文与其证据，不能由audit PASS代替；其它target、目录、103/104/115/116、整体产品、117预算及131中断状态均未被本报告接受或重测。
