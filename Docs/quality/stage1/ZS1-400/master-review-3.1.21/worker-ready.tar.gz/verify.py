"""Offline read-only directory/report verification. Never execute old programs."""
from pathlib import Path
import json,hashlib,csv,io
R=Path(__file__).resolve().parent
def read(p):return (R/p).read_bytes()
def js(p):return json.loads(read(p))
def sha(b):return hashlib.sha256(b).hexdigest()
def check(p,x):
 b=read(p);assert len(b)==x['bytes'] and sha(b)==x['sha256'],p
m=js('manifest.json');expected={x['path'] for x in m['files']};assert expected=={p.relative_to(R).as_posix() for p in R.rglob('*') if p.is_file()}-{'manifest.json'}
for x in m['files']:check(x['path'],x)
scope=js('scope.json');cap=js('capture.json');assert scope['item']=='ZS1-400' and not scope['accepted'] and scope['in_scope_files']==['ZS1-099'] and scope['direct_child_directories']==[]
assert scope['new_product_executions']==scope['old_scripts_executed']==0
inv=js('physical-inventory.json');assert [x['name'] for x in inv]==['mio.rs','tty.rs']
for x in inv:assert x['kind']=='file' and not x['symlink'];check('physical/'+x['name'],x)
assert sha(read('physical/mio.rs'))=='41321e242e21fa85533dbae42314bcf80ab916e1d55e065d5ce98076002ac93f'
contexts=js('context-read.json');assert len(contexts)==15
for x in contexts:
 check('context/'+x['path'],x);assert x['start']==0 and x['end']==x['bytes'] and x['line_start']==1 and x['line_end']==len(read('context/'+x['path']).splitlines())
prior=js('prior099/manifest.json');assert sha(read('prior099/manifest.json'))=='6821362d624841bf22b4670072cb7218ca3e6059df64d829516f10345248bb24'
for x in prior['files']:check('prior099/'+x['path'],x)
assert read('physical/mio.rs')==read('prior099/sources/current-mio.rs')
end=0
for x in js('prior099/current-read-chain.json'):
 b=read('physical/mio.rs')[x['start']:x['end']];assert x['start']==end and sha(b)==x['sha256']
 if 'old_path' in x:assert read('prior099/'+x['old_path'])[x['old_start']:x['old_end']]==b
 end=x['end']
assert end==25801
receipt=js('accepted099/'+cap['child_receipt_path']);check('accepted099/'+cap['child_receipt_path'],cap['child_receipt_meta']);assert receipt['item_id']=='ZS1-099' and receipt['complete'] and receipt['manual_review']['decision']=='accepted'
assert receipt['source_hash']=='57f4a90b828444fcc6dd7199a73907bbbccf2df4b7808f9e8a0a4b0771e12e39'
for x in receipt['artifacts']:check('accepted099/'+x['path'],x)
worker=read('prior099/'+cap['child_report']);review=read('accepted099/'+receipt['manual_review']['evidence']['path']);assert read('accepted099/'+cap['child_report'])==worker+b'\n\n'+review
for p,x in cap['authority'].items():check('authority/'+p,x)
selector=js('authority/Docs/execution/active_requirement.json');assert selector['requirement_digest']==scope['requirement_digest']==receipt['requirement_digest']
assert selector['baseline_snapshot_sha256']==scope['baseline_snapshot_sha256']==receipt['baseline_snapshot_sha256']
b=read('authority/Docs/stage_1_v3_pi_mono_blueprint.md');assert b'- [x] **ZS1-099**' in b and b'- [ ] **ZS1-400**' in b
file_rows=list(csv.DictReader(io.StringIO(read('authority/Docs/learn/stage1_pi_mono/targets/zenpi/file_learn_index.tsv').decode()),delimiter='\t'))
row=next(x for x in file_rows if x['item_id']=='ZS1-099');assert row['status']=='[x]' and row['source_path']==scope['folder']+'/mio.rs'
assert [x['item_id'] for x in file_rows if Path(x['source_path']).parent.as_posix()==scope['folder']]==['ZS1-099']
assert js('initial-authority.json')['files'][cap['child_receipt_path']]['exists'] is False
for p,x in js('master-product/manifest.json')['artifacts'].items():check('master-product/'+p,x)
v=js('master-product/master-verification.json');assert v['top_level_rust_tests']==144 and v['vendor_default']==8 and v['vendor_libc_event_stream']==9 and not v['production_release_rebuilt'] and not v['budget_rerun']
formal=scope['owned_paths'][0];report=read(formal);lines=report.splitlines(keepends=True);patch=f'diff --git a/{formal} b/{formal}\nnew file mode 100644\n--- /dev/null\n+++ b/{formal}\n@@ -0,0 +1,{len(lines)} @@\n'.encode()+b''.join(b'+'+l for l in lines);assert read('report.patch')==patch and len(patch)<262144
print(json.dumps(dict(ok=True,item='ZS1-400',payloads=len(expected),physical_files=2,direct_child_directories=0,in_scope_files=1,complete_context_files=15,dependency099_accepted=True,report_only_patch=True,new_product_executions=0,old_scripts_executed=0,G_STAGE_executed=False,semantic_acceptance=False)))
