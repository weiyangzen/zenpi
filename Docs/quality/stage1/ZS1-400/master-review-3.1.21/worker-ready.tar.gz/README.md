# ZS1-400 冻结目录子集理解

唯一报告Docs/learn/stage1_pi_mono/targets/zenpi/vendor/crossterm/src/event/source/unix/current_folder_learn.md。物理只有mio.rs与tty.rs、无子目录；冻结子集只有已独立接受的099/mio，tty及15份完整新读上下文均不随目录接受。

报告解释feature配对、fd/Parser/readiness/reader所有权、错误与wake/stream取消、持久化排除及use-dev-tty语义差异。保留开始099未接受与封包前正式接受的两个时点；当前41321e全读链精确复用，主控144/8/9检查仅作历史行为辅助，不替代目录语义。原PTY反证/平台和未测限制保留。

report.patch仅新增本目录报告。python3 -B verify.py为新只读离线验证器，不执行旧脚本/产品/runtime/PTY/budget。manifest不含自身，外置回执在相邻stage1-worker目录。400及401–405/129/131未自行接受。
