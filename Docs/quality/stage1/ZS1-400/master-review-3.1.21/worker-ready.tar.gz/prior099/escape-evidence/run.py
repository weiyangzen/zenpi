from pathlib import Path
import sys,subprocess,os,signal,json,datetime,hashlib
D=Path(__file__).resolve().parent;name=sys.argv[1];argv=sys.argv[2:]
def sha(b):return hashlib.sha256(b).hexdigest()
owners={f:sha((D/'candidate'/f).read_bytes()) for f in ['vendor/crossterm/src/event/source/unix/mio.rs','src/headless.rs','src/tui.rs','Cargo.toml','Cargo.lock','vendor/crossterm/Cargo.lock']}
started=datetime.datetime.now(datetime.timezone.utc).isoformat();timed=False
with (D/(name+'.log')).open('wb') as log:
 p=subprocess.Popen(argv,cwd=D/'candidate',stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:code=p.wait(timeout=180)
 except subprocess.TimeoutExpired:
  timed=True;os.killpg(p.pid,signal.SIGTERM)
  try:code=p.wait(timeout=3)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait(timeout=3)
b=(D/(name+'.log')).read_bytes()
r=dict(argv=argv,cwd=str(D/'candidate'),started_at=started,ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=code,timed_out=timed,reaped=True,log_bytes=len(b),log_sha256=sha(b),owners=owners)
(D/(name+'.run.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));print(b.decode(errors='replace')[-4500:])
