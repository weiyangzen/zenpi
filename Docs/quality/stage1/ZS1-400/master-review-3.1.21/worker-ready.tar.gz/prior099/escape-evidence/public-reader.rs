use std::{io::{self, Write}, time::{Duration, Instant}};
use crossterm::{event::{self, Event, KeyCode}, terminal};
fn main() -> io::Result<()> {
    terminal::enable_raw_mode()?;
    let _ = event::poll(Duration::ZERO)?;
    println!("READY"); io::stdout().flush()?;
    let start=Instant::now(); let mut ascii=0; let mut esc=false; let mut other=0;
    while start.elapsed() < Duration::from_millis(200) {
        if event::poll(Duration::from_millis(10))? {
            match event::read()? {
                Event::Key(k) if k.code==KeyCode::Char('x') => ascii+=1,
                Event::Key(k) if k.code==KeyCode::Esc => {esc=true;break},
                _ => other+=1,
            }
        }
    }
    terminal::disable_raw_mode()?;
    println!("RESULT ascii={ascii} esc={esc} other={other} elapsed_us={}",start.elapsed().as_micros());
    if ascii!=1023 || !esc || other!=0 {std::process::exit(1)}
    Ok(())
}
