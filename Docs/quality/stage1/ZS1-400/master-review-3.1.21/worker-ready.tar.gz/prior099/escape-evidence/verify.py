"""Integrity + temporary git patch roundtrip. Never execute archived programs."""
from pathlib import Path
import json,hashlib,tarfile,re,subprocess,tempfile
R=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def read(f):return (R/f).read_bytes()
def js(f):return json.loads(read(f))
def meta(f,x):
 b=read(f);assert len(b)==x['bytes'] and sha(b)==x['sha256'],f
m=js('manifest.json');expected={x['path'] for x in m['files']}
assert expected=={p.relative_to(R).as_posix() for p in R.rglob('*') if p.is_file()}-{'manifest.json'}
for x in m['files']:meta(x['path'],x)
before=read('before-mio.rs');after=read('after-mio.rs');negative=read('negative-mio.rs')
assert sha(before)=='1afaaa245a132ea4670bd212d1c1c42a078b1fd4b950636147112485589753ef'
assert sha(after)=='41321e242e21fa85533dbae42314bcf80ab916e1d55e065d5ce98076002ac93f'
assert negative.startswith(before)
new_module=b'\r\n#[cfg(test)]\r\nmod zenpi_escape_boundary_tests'
def rustfmt_equivalent(b):
 return re.sub(rb'\s+',b'',re.sub(rb',\s*([)\]])',rb'\1',b))
assert rustfmt_equivalent(negative[len(before):])==rustfmt_equivalent(after[after.index(new_module):])
cap=js('capture.json');inventory={x['path']:x for x in cap['files']}
with tarfile.open(R/'build-inputs-before.tar.gz') as t:
 members={x.name:x for x in t.getmembers() if x.isfile()};assert set(members)==set(inventory)
 for name,x in inventory.items():
  b=t.extractfile(members[name]).read();assert len(b)==x['bytes'] and sha(b)==x['sha256'],name
 assert t.extractfile(members['vendor/crossterm/src/event/source/unix/mio.rs']).read()==before
prior=js('prior099/manifest.json');assert sha(read('prior099/manifest.json'))=='2befdcaf00424f8310c0092441d172af786bbc995281c13830c2e3b594b62a07'
pm={x['path']:x for x in prior['files']}
for p in (R/'prior099').rglob('*'):
 if p.is_file() and p.name!='manifest.json':meta(p.relative_to(R).as_posix(),pm[p.relative_to(R/'prior099').as_posix()])
for version in ['original','final']:
 rows=[x for x in js('prior099/read-blocks.json') if x['version']==version];end=0
 b=read('prior099/'+rows[0]['path'])
 for x in rows:
  assert x['start']==end and sha(b[x['start']:x['end']])==x['sha256'];end=x['end']
 assert end==len(b)
assert read('prior099/sources/after-mio.rs')==before
delta=js('read-delta.json');base=after[:after.index(new_module)]
# Remove exactly the two reviewed production insertions, leaving byte-identical base.
for x in sorted([x for x in delta if x['kind']=='production'],key=lambda x:x['start'],reverse=True):
 assert sha(after[x['start']:x['end']])==x['sha256'];base=base[:x['start']]+base[x['end']:]
assert base==before
for x in delta:assert sha(after[x['start']:x['end']])==x['sha256']
runs=[]
source_hashes={sha(read(f)) for f in ['before-mio.rs','negative-mio.rs','fixed-beforefmt.rs','after-mio.rs']}
for p in R.glob('*.run.json'):
 x=json.loads(p.read_bytes());name=p.name[:-9];meta(name+'.log',{'bytes':x['log_bytes'],'sha256':x['log_sha256']});assert x['reaped'] and not x['timed_out'];runs.append(name)
 assert x['owners']['vendor/crossterm/src/event/source/unix/mio.rs'] in source_hashes
assert js('negative-socket.run.json')['exit_code']==101
assert b'left: None' in read('negative-socket.log') and b'2 passed; 1 failed' in read('negative-socket.log')
for name,count in [('fixed-default',8),('fixed-libc-stream',9)]:
 assert js(name+'.run.json')['exit_code']==0 and f'{count} passed; 0 failed'.encode() in read(name+'.log')
for name in ['before','after']:
 x=js(name+'-public-pty-result.json');assert x['exit_code']==0 and x['writes']==1 and x['input_bytes']==1024 and not x['extra_input'] and x['termios_restored'] and x['reaped']
 assert 'ascii=1023 esc=true other=0' in x['stdout']
 assert sha(read('public-reader-'+name))==x['binary_sha256']
with tempfile.TemporaryDirectory(prefix='escape-patch-') as tmp:
 tmp=Path(tmp);f=tmp/'vendor/crossterm/src/event/source/unix/mio.rs';f.parent.mkdir(parents=True);f.write_bytes(before)
 for reverse in [False,True]:
  args=['git','apply']+(['--reverse'] if reverse else [])+[str(R/'candidate.patch')]
  subprocess.run(args,cwd=tmp,check=True,capture_output=True)
  assert f.read_bytes()==(before if reverse else after)
print(json.dumps(dict(ok=True,payloads=len(expected),frozen_inputs=len(inventory),source_changes=1,run_log_bindings=len(runs),negative_socket_reproduced=True,public_PTY_before_reproduced=False,public_PTY_both_passed=True,patch_roundtrip=True,product_execution_by_verifier=False,semantic_acceptance=False)))
