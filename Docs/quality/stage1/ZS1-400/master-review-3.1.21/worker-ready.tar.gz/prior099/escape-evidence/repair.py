from pathlib import Path
D=Path(__file__).resolve().parent;p=D/'candidate/vendor/crossterm/src/event/source/unix/mio.rs'
b=p.read_bytes();s=b.decode().replace('\r\n','\n')
old='''                        }
                    }
                    SIGNAL_TOKEN => {'''
new='''                        }
                        // A full read can leave a lone Esc undecided. Only
                        // resolve it once this TTY readiness has been drained;
                        // a queued suffix must still be parsed as its sequence.
                        if let Some(event) = self.parser.finish_pending_escape() {
                            return Ok(Some(event));
                        }
                    }
                    SIGNAL_TOKEN => {'''
assert s.count(old)==1;s=s.replace(old,new)
old='''impl Parser {
    fn advance(&mut self, buffer: &[u8], more: bool) {'''
new='''impl Parser {
    fn finish_pending_escape(&mut self) -> Option<InternalEvent> {
        if self.buffer.as_slice() != b"\\x1b" {
            return None;
        }
        let event = parse_event(&self.buffer, false).ok().flatten()?;
        self.buffer.clear();
        Some(event)
    }

    fn advance(&mut self, buffer: &[u8], more: bool) {'''
assert s.count(old)==1;s=s.replace(old,new);p.write_bytes(s.replace('\n','\r\n').encode())
