# ZS1-129/131 满读取边界的孤立 ESC 修复候选

已实际证实当前 mio1afaaa 的一个有限输入缺陷：真实 UnixStream 一次写入1023个x加ESC，交付1023个字符后，20ms的try_read返回None，ESC留在Parser。候选仅在TTY已排空时，用现有parse_event(false)把单独ESC完成为键事件；同一socket夹具由失败转通过。公共event::poll/read的真实PTY对照原版与候选均通过，不能将这组PTY写成修复前失败。

本轮只写新私有目录，不修改主库、共享TUI、harness、B测试、旧129/099ready或接受状态。当前活动蓝图3.1.21，requirement digest `3456abcbbebbc4e0ab383c319851b0a6e71b19ee9b3c060a6e212f61a89c9d9d`，baseline snapshot `92b06c4b1dcdca7614d226ce5f41205646a9e63967789d2b6ed4ee272d240884`。这是099指出具体边界后的新产品候选，不改099原报告去伪称当时已修复。

## 输入冻结和来源

唯一候选路径：`vendor/crossterm/src/event/source/unix/mio.rs`。before18871B/477行/SHA `1afaaa245a132ea4670bd212d1c1c42a078b1fd4b950636147112485589753ef`；after25801B/655行/SHA `41321e242e21fa85533dbae42314bcf80ab916e1d55e065d5ce98076002ac93f`。candidate.patch7735B/SHA `97e7fb3b0649a8bd553e5b0f60d04a39c5bd667cf35e77d8aca6dab15eecc227`，仅178行新增：15行生产实现/说明和163行内置测试（含空行、cfg与辅助函数）。原始CRLF保留；该patch相对1afa，不重复57f4→1afa的旧129改动。

任务起始只读检查得到headless0ece91。首次拷贝前主控已合入944049，准备assert在任何编译前拦截；第二次按精确manifest校验又拦截gantt漂移，均是准备失败，没有执行产品。preparation-drift.json保留当时三条变化：headless0ece91→944049、tests/headless_project_workspace6e87→8375、gantt545fd→61124。为遵守指定冻结base，使用主控readiness-identity-3.1.21的inputs-after224项哈希；headless从其worker-C/files取回0ece91，后两项从其before取6e87/545fd，其余主库内容逐项校验相同。该恢复仅作用于新私有candidate，不回退主库。capture.json与build-inputs-before.tar.gz完整保存224项冻结输入，最终223项不变，只有mio变化。

本轮headless固定 `0ece91f883f335e677cf853af7f754d013ba8d00b834018c9044fce69e3f74e4`；TUI固定 `994215c7ca6cc471bb35247a04460d6c5ef52192999e4b5585ea1c818a429578`。测试/公共探针编译的是vendor独立Cargo.lock（SHAc05ea83405bfb2e4238460213ccd3e8a4c793b1bdaec3405fbcff894093e9243），mio1.0.3/rustix1.0.5。rootlock7311d113仍冻结但未在此轮构建完整Zenpi，不能把这些结果描述成主控最新944049组合的生产release或budget验证。

## 阅读链与最小语义差异

1afa完整文件阅读复用本任务刚完成并冻结的099：原57f4连续1–229与最终1afa连续1–250、251–477，所有连续字节hash和完整字段/构造/Drop/状态机/全部原有测试分析保存在prior099引用。099 manifest `2befdcaf00424f8310c0092441d172af786bbc995281c13830c2e3b594b62a07`，report SHA61ff3b41324aaf5b403f25eeccba2e02bbac46c1ddb18ab1497485d9d46cfb61；未对旧包做写入。本轮完整阅读新candidate.patch的每个新增/上下文块，源final行173–178、258–265和493–655的准确byte ranges另记read-delta.json。不是把差异阅读称作又全读655行；未变化字节由1afa阅读链绑定。

原机制read_count==1024会让最后一个字节的more=true，parse_event([ESC],true)返回None。后续调用优先排完1023个已解码x；TTY token保持至FIONREAD查询为零后退队。原来此处不再处理Parser中的ESC；新poll没有字节可读，故20ms None。剩余完整事件应及时交付的合同在这里被破坏；短于1024的read原本就会以more=false把孤立ESC即时解析，因此修复没有新增等待窗口或改变现有短读取的歧义策略。

最终173–178在TTY内层循环结束之后调用finish_pending_escape。能走到这里的是FIONREAD=0或WouldBlock两个正常排空break；此前均已pop当前TTY、清tty_read_started。读取到正字节但有队列后缀时仍继续read/parse，不能先把ESC提早完成；read/EOF/ioctl错误仍按原路径直接返回，不绕过错误也不清空partial。SIGWINCH与WAKE剩余token仍保留；新Esc返回一次后，下次调用继续处理剩余token。已解码Parser事件仍在函数入口优先返回，无优先级变化。

最终258–265的私有Parser::finish_pending_escape只接受buffer恰好等于单字节ESC。其它UTF8/CSI/paste/Alt部分输入直接返回None且一个字节也不改。对ESC调用原parse_event(&buffer,false)，只有得到Some(event)才消费该已完成序列；.ok().flatten()?使意外解析None/Err也不清buffer。正常成功clear是消费一个已确认的完整事件，不是reset或清空所有输入状态，也不触碰internal_events。没有新public API、新owner、新syscall、增加buffer、设置fd flags/termios或额外wakeup。

歧义界限明确：若ESC的Alt后缀已经在同批/内核里，FIONREAD>0会让它继续成为Alt事件；若后缀未来才到且目前确实排空，孤立ESC可被交付，不承诺任意时间间隔的两个write总会被重组为Alt。这与既有短read的input_available=false选择一致，不引入额外计时启发式。重复EINTR、无限未闭合paste、任意竞争消费者与terminal::size fallback耗时仍保持099静态限制，本轮无无限压力实验或全面有界承诺。

## 新内置测试全部分支

新module仅cfg(test)，pair(blocking)创建真实UnixStream、按参数切换nonblocking，分别用rustix Owned或libc IntoRawFd/close_on_drop，把真实fd传给正常from_file_descriptor注册readiness。辅助key创建NONE modifier事件，drain_x逐项确认确实交付全部前缀而非只看数量。

| 新测试 | 同一固定输入与判据 | 边界说明 |
|---|---|---|
| one_write_full_buffer_trailing_escape_is_delivered_without_another_event | 一次1024B写入，1023x后20ms读Esc；取Esc耗时<1s；末尾ZERO None；drop writer再读UnexpectedEof；修复后同时跑nonblocking/blocking两支 | 原版在第一个nonblocking分支失败，故原版同一test后面的blocking支未执行，不能虚报两个negative分支都失败 |
| full_buffer_escape_uses_already_pending_alt_suffix | 一次1025B：1023x、ESC、a；需得到Alt+a且无多余Esc；before与after都通过 | 证明已有内核后缀不被idle判定拆开，不是任意跨时间输入的Alt承诺 |
| full_buffer_partial_utf8_csi_and_paste_survive_idle | 三组精确1024B前缀：UTF8首字节、ESC[、ESC[200~；排完x后20ms None，直接确认Parser字节完整等于prefix，再写剩余“界”/Left/组合字ZWJ闭合paste；需得到完整原事件 | 后续write仅用于完成合法partial，不是给孤立ESC救援。无额外resize/reset。三组为有限输入，不测试无限paste |
| escape_idle_completion_retains_real_wake_in_both_batch_orders（event-stream） | 真实write1024B并真实wake，poll确认TTY和WAKE确实存在，再明确排序为两种顺序；逐个交付1023x/Esc/Interrupted，ZERO None结束 | 内核readiness真实，但排序是确定性测试安排。覆盖新idle Esc返回不丢wake；不把它当全部自然三token排列或SIGWINCH实测 |

原module zenpi_ready_tests保持逐字不变，继续验证2065字节单edge、多read UTF8/CSI/paste、blocking普通timeout/EOF、partial后续写入、event-stream parser优先与双排序。默认过滤zenpi_还选中既有event.rs reset锁测试一项，故8/8=原mio4+新3+reset1；libc/event-stream为9/9=原mio5+新4，不含reset。两配置重叠，不合计成17个独立用例。不宣称普通测试逐次命中所有WouldBlock、FIONREAD错误、其它read错误或continuousEINTR；这些分支的代码保持不变且入口位置经静态复核。

## 实际反例、候选结果与公共PTY

全部命令由新run.py在私有candidate执行，native工具链stable-aarch64-apple-darwin，Cargo offline/locked/jobs2；每次有argv/cwd、UTC起止、实际子命令exit_code、超时/reap、owner hash和完整log。wrapper正常归档后退出0不等于被测命令通过，必须看run.json的exit_code与原日志。

negative-mio.rs为1afa精确前缀加相同新测试：24209B、SHA98ef991ba195fae668f9b44a62d9825272ab8871fe2647c9248a7803a84edf2e。最终测试经rustfmt只有排版变化，离线按去空白及rustfmt可选尾逗号校验与negative新增测试相同；没有根据结果更改输入、时限或断言。

| 运行 | UTC时间2026-09-12 | 实际结果和日志 |
|---|---|---|
| negative-socket | 16:40:55.084564–16:41:11.349908 | exit101；3项中2通过、孤立ESC失败，left None/right Esc；4693B，SHA99d4a1cb2145fca97225e265f125db2557c04e2e359465693472d7a9e14c779b |
| fixed-default | 16:42:22.359402–16:42:23.343200 | exit0，8/8；2078B，SHAd0b6ae9dad505ddfaafa9b22973ec9241e2c59919d361210ca771a4c10b89a2a |
| fixed-libc-stream | 16:42:37.809473–16:42:39.407404 | exit0，9/9；2271B，SHA09a4e0622714979fb42a02ed86958dfa94108a55367af9b003b38a3cfc124c29 |
| before-public-pty | 16:41:48.587494–16:41:49.022832 | exit0；1023x+Esc、other0，probe elapsed812µs；527B，SHA71e4cb4ad73c4fd07a89c1050c8cc39d8abd83aca2ffc331a1f4f77392dac720 |
| after-public-pty | 16:43:09.626840–16:43:10.610349 | exit0；同输入1023x+Esc、other0，probe elapsed637µs；526B，SHAf6cf4359d93036b17b5957ef9f1e817706ce9f8773d3d7199227cd6ade1aebb1 |
| format-check | 16:43:10.679921–16:43:10.726228 | exit0，CRLF格式检查；原dependency unused_parens warning另保留，不虚称整个vendor零告警 |

公共探针public-reader.rs不进入产品patch；单独rustc链接已构建的vendor默认库，before/after源码完全相同SHA0eea4a385bbaabbe0e92ed7a42cc1298ce740446db54a4eb2be82e63c571b04d。before-mio上的追加测试cfg(test)在该库构建关闭，实际生产部分仍为1afa。before binary1440424B SHA76a7782666c7e5b18f16f807f3b49cac37e10847ebf206c9271bdd78d411c3e8，after1443136B SHA261562a5dc51f31c2d9a9479a0198bee0d1654337d9c6bcd496e371ba826f1c3；它们是公共reader探针，不是Zenpi release。

同一个public-reader-pty.py SHAfbcc361085b8523ba49aa17818c1f34d99c83f2dc2afc308c6988174fb1e6a3c用pty.openpty，将slave作为真实stdin，stdout/stderr独立pipe。探针enable_raw_mode后poll ZERO初始化reader并打印READY；父等待READY后只os.write一次1024B，input SHA808b153a414fe681a205a0f961c52059e074f3637560b1a0f43c1f6cd3dc6829。探针200ms固定总窗口内每次poll10ms/read，不发第二键、不resize/reset；成功后disable_raw_mode。外层3s只保护启动/收尾，before/after相同；两次均记录termios恢复、exit/reap，关闭PTY descriptors，无磁盘FIFO。未设置网络代理或启动HTTP，也未改HOME/CODEX_HOME。

PTY本次没有重现，保留其成功原样。没有记录每次系统read的长度，因此“PTY驱动可能拆成短read”只能是可解释差异的推断，不能写成已观察事实；本次不能据此称真实生产PTY此前一定受此具体ESC缺陷影响。可靠反例是注册真实UnixStream的满read边界，公共PTY是既有行为保留的入口检查。不得重跑PTY直至得到想要的negative，也没有通过追加按键救援来造绿色。

旧主控93f348组合的原完整kill-yank29checks/4HTTP/3TUI通过、固定3样本预算和JSONL证据作为prior-master引用复用，不在本轮重跑整个matrix或正式budget；它们编译的是旧mio1afa，不能当作after41321全组合验收。当前候选没有新Zenpi release、rootlock产品构建、全局Clippy或跨平台证据，交由主控按集成需要验证。macOS arm64当前底层配置已测，Linux/其它Unix、use-dev-tty及Windows未测；后两者本文件并非实际owner。

## 完整性、回滚与交接边界

新离线verify.py检查manifest、224输入归档与唯一变化、连续旧阅读引用、新增完整delta、相同测试/夹具、所有run/log/binary hash、预期negative与positive，并在新临时Git目录验证candidate.patch正向与反向字节恢复；不自动运行Cargo、公共探针、PTY、旧脚本或产品。实际封包检查receipt独立放stage1-worker，语义/manual接受仍false。回滚只撤销1afa→41321这一份mio差异，恢复完整1afa字节，不撤销旧129修复，不改任何headless组合或持久会话。

所有新进程已退出并reap，public-reader进程检查为空。worker HEAD4dbd330d及94条非.ops dirty保持；旧129/099ready最终manifest与payload应再次校验保持。本包不接受099/祖先、129或131，不增加新任务/subagent，不扩展EINTR或无限paste压力范围。送审后停止，主控需先核对其mio仍等于1afa再应用候选，并将它独立纳入最新组合；主库随后产生的其它路径漂移只报告，不悄悄加入候选。
