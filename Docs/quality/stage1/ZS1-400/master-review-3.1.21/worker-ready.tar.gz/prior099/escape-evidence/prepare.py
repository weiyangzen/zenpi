from pathlib import Path
import json,hashlib,datetime,subprocess,tarfile
D=Path(__file__).resolve().parent;W=D.parents[2];M=Path('/Users/wangweiyang/GitHub/zenpi')
def sha(b):return hashlib.sha256(b).hexdigest()
inventory=json.loads((M/'.ops/stage1_execution/readiness-identity-3.1.21/inputs-after.json').read_text())
rows=[]
for f in inventory:
 source=M/f
 if f=='src/headless.rs':source=M/'.ops/stage1_execution/readiness-identity-3.1.21/worker-C/files/src/headless.rs'
 if f in ['tools/generate_stage1_gantt.py','tests/headless_project_workspace.rs']:source=M/'.ops/stage1_execution/readiness-identity-3.1.21/before'/f
 b=source.read_bytes();assert sha(b)==inventory[f]['sha256'],f
 p=D/'candidate'/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 rows.append(dict(path=f,bytes=len(b),sha256=sha(b)))
assert sha((D/'candidate/src/headless.rs').read_bytes())=='0ece91f883f335e677cf853af7f754d013ba8d00b834018c9044fce69e3f74e4'
source=D/'candidate/vendor/crossterm/src/event/source/unix/mio.rs'
assert sha(source.read_bytes())=='1afaaa245a132ea4670bd212d1c1c42a078b1fd4b950636147112485589753ef'
(D/'before-mio.rs').write_bytes(source.read_bytes())
for f in ['Docs/stage_1_v3_pi_mono_blueprint.md','Docs/execution/active_requirement.json']:
 p=D/'authority'/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((M/f).read_bytes())
with tarfile.open(D/'build-inputs-before.tar.gz','w:gz') as t:
 for x in rows:t.add(D/'candidate'/x['path'],arcname=x['path'],recursive=False)
status=subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=W,text=True).splitlines();status=[s for s in status if not s[3:].startswith('.ops/')]
(D/'capture.json').write_text(json.dumps(dict(captured_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),main=str(M),worker_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),non_ops_status=status,files=rows),indent=2)+'\n')
print('frozen',len(rows),'files; headless0ece91; mio1afa;',len(status),'non-ops rows')
