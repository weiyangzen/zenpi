# 孤立ESC满读取边界修复候选

candidate.patch仅修改vendor/crossterm/src/event/source/unix/mio.rs，从1afa到41321，不重复旧129补丁。真实single-write socket反例已证实；同一新测试修复后通过。默认8/8、libc/event-stream9/9；真实公共event reader PTY前后均通过，原PTY未复现这一边界，不伪造负例。

read-review.md给出完整增量理解、同一fixture、原始失败与平台/错误覆盖限制。before/after/negative源、原始run/log、真实探针二进制及224输入归档均冻结。headless固定0ece91；主控944049等漂移记录但未混入。旧129/099不变。

python3 -B verify.py只校验静态证据与临时git补丁往返，不运行Cargo、探针、PTY、旧脚本或产品。完整kill-yank/正式budget复用先前主控证据，未声称41321最新组合已验收。独立接受状态false。
