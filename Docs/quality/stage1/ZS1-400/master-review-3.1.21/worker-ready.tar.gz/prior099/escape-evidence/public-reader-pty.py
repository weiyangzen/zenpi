import os,pty,subprocess,sys,select,time,json,hashlib,termios
from pathlib import Path
binary=Path(sys.argv[1]).resolve();dest=Path(sys.argv[2]).resolve();master,slave=pty.openpty();before=termios.tcgetattr(slave)
p=subprocess.Popen([str(binary)],stdin=slave,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
raw=b'';deadline=time.monotonic()+3
try:
 while b'READY\n' not in raw:
  if time.monotonic()>deadline:raise TimeoutError('reader readiness deadline')
  if select.select([p.stdout],[],[],0.05)[0]:
   part=os.read(p.stdout.fileno(),4096)
   if not part:raise RuntimeError('reader exited before READY')
   raw+=part
 payload=b'x'*1023+b'\x1b';sent=os.write(master,payload);assert sent==len(payload)
 out,err=p.communicate(timeout=3);raw+=out
 result=dict(binary=str(binary),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),writes=1,input_bytes=sent,input_sha256=hashlib.sha256(payload).hexdigest(),stdout=raw.decode(),stderr=err.decode(),exit_code=p.returncode,reaped=True,termios_restored=termios.tcgetattr(slave)==before,extra_input=False)
 dest.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));sys.exit(p.returncode)
finally:
 if p.poll() is None:p.kill();p.wait(timeout=3)
 os.close(master);os.close(slave)
