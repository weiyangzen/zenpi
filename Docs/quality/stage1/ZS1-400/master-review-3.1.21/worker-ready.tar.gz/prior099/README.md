# ZS1-099 当前ESC增量理解补充

report.patch只新增/更新唯一报告Docs/learn/stage1_pi_mono/targets/zenpi/files/vendor/crossterm/src/event/source/unix/mio.rs_learn.md，旧099原文28350B精确保留，本轮补充全部1afa→41321e新增行及其语义。655行通过精确未变片段复用与178行新读完整闭合；源冻结基线仍为57f4。

新的socket negative与修复通过属于先前独立ESC产品轮；公共PTY before/after均通过，明确保留原PTY未复现。当前main已被主控应用41321e，主控组合回归仍在运行，本包不声称已通过。本轮零产品/旧脚本/正式budget执行。

两个旧包全部复制并hash核验，历史candidate.patch只作证据，不是本次送审产品差异。python3 -B verify.py仅离线hash/范围/报告patch检查。manifest不含自身；实际离线回执在相邻stage1-worker目录，不执行被归档脚本。099、目录及129/131不自行接受。
