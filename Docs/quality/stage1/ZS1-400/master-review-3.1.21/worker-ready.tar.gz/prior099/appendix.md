
## 099 增量补充：满缓冲孤立 ESC 候选 41321e

本节是旧099报告封存之后的独立补充，前文28350B保持精确原文前缀（SHA `61ff3b41324aaf5b403f25eeccba2e02bbac46c1ddb18ab1497485d9d46cfb61`）。前文“静态疑点尚未执行”“最终1afa”“当前主库”等说法均保留其当时捕获时点；本节说明后来发生的试验和候选变化，不倒改原始报告为“当时已经实测”。仍只有同一个正式文件报告，不把099主题拆成第二个正式产物。

补充开始时主库mio是18871B/477行/1afaaa，主控正在审阅新候选；headless已经944049，跟新ESC试验冻结的0ece91不同。本报告不把候选41321e说成主库已集成，也不拿0ece91上的独立vendor运行冒称最新主库全产品验收。末尾记录封包前最后一次只读身份核对，以该时点为准。

### 三个源版本与阅读方法

| 版本 | 字节/行数/SHA256 | 阅读与证据角色 |
|---|---|---|
| 冻结原始 | 9026B /229行 /`57f4a90b828444fcc6dd7199a73907bbbccf2df4b7808f9e8a0a4b0771e12e39` | 保留旧099连续全读，仍是蓝图冻结source hash，不改为候选hash |
| 先前最终 | 18871B /477行 /`1afaaa245a132ea4670bd212d1c1c42a078b1fd4b950636147112485589753ef` | 保留旧099全读链与字段/接口/构造/Drop/状态机/五项原测试；该版本是此次产品增量唯一base |
| 本次补充目标候选 | 25801B /655行 /`41321e242e21fa85533dbae42314bcf80ab916e1d55e065d5ce98076002ac93f` | 178行新增：生产/说明15行，测试/辅助/cfg/空行163行；无删除，无原函数或原五项测试被偷换 |

旧099 ready manifest `2befdcaf00424f8310c0092441d172af786bbc995281c13830c2e3b594b62a07`；新ESC产品候选 ready manifest `ee4b7c7f491a9c57312f23e5a754f706259b766fff22738e2a19938fe3d37cd0`。本轮先离线核对两旧包全部payload，再直接读取新source diff的全部新增行及上下文；没有执行任何旧verify、runtime、Cargo、PTY或budget。两个旧包均作为不可变历史复制/引用。

655行理解使用“精确未变字节复用＋全部新行重新逐行复核”：新1–172映射旧1–172，新179–257映射旧173–251，新267–492映射旧252–477；新173–178、258–266、493–655全部本轮新读。后附六段半开字节覆盖表无重叠/遗漏，既绑定复用片段的旧hash，也绑定新增片段hash。这不是声称又从头重新读了未变477行，也不以range自动证明语义；新增分支的理解如下。

### 生产变化逐行解释与跨分支约束

173–175的三行注释指明：满1024 read可能使末字节ESC保持未定，只有TTY readiness真正排空才解析。176–178新增一次私有helper调用：Some立即返回这个内部事件，None继续原SIGNAL/WAKE等batch处理。位置在TTY内层read循环退出之后，正常能到这里的是FIONREAD=0和WouldBlock两个break；它们之前已经pop TTY并重置tty_read_started，因此新Esc返回不会让空TTY被反复处理。

258行定义Parser::finish_pending_escape，返回Option<InternalEvent>而非新的public API。259–261严格比较buffer只含单字节0x1b，否则返回None；UTF8首字节、CSI ESC[、paste ESC[200~等均不匹配，内存一个字节不改。262将该孤立ESC交给原parse_event(buffer,false)，.ok().flatten()?只取已有解析器产出的完整事件；意外Err/None退出且不清buffer。263仅在已得到完整事件时消费该序列，264返回该事件，265结束helper，266为空行。这里clear是正常消费一个已确认事件，与reset全reader或清空partial/已解码队列不同；internal_events从未被该helper清空。

不变量是“真正排空后才把尚未交付的单Esc完成”。若下一read的Alt字符已在内核等待，FIONREAD>0仍进入原read/advance，让ESC与后缀形成Alt；不能先触发helper。若afterread已有多个解码事件，try_read入口仍优先逐个pop，helper只在Parser队列耗尽、TTY正常排空后触达。新return仍保留同批未消费的SIGNAL/WAKE，不改变已建立的pending顺序。SIGWINCH处理、size查询、waker Interrupted、构造失败、unknown-token panic、EOF、其它read/ioctl错误及Drop全部沿用1afa；这些错误直接return的路径不会绕到idle helper，因此错误不被掩成正常Esc。

这一策略不引入歧义计时器：如果Alt后缀未来才写，而当前已经排空，则孤立ESC可立即交付。它与旧短于1024的read传more=false时的行为一致，不承诺任意时间间隔的两次write都会重组Alt。既有256/128容量仅预分配，连续EINTR/持续未闭合paste/竞争读者/size fallback的限制仍保留，绝不从20ms有限测试泛化为无限压力下全面有界。fd的blocking/termios设置、1024缓冲尺寸与OS事件注册均不变。

### 新163行测试及辅助函数完整复核

493空行、494 cfg(test)、495模块到655闭括号均完整阅读。导入沿用真实UnixInternalEventSource/KeyEvent/Write/UnixStream；pair(blocking)创建socket pair，input.set_nonblocking(!blocking)，libc支把IntoRawFd转换为close_on_drop=true的FileDesc，rustix支Owned转换；真实from_file_descriptor注册内核readiness，output由测试持有。没有伪EventSource、FIFO或额外应用线程。key产生NONE modifier事件；drain_x在每一次20ms读取中断言字符和索引，不能跳过prefix消费只读最后Esc。

| 新测试 | 全部输入、分支与断言 | 实测和覆盖限制 |
|---|---|---|
| one_write_full_buffer_trailing_escape_is_delivered_without_another_event | 遍历nonblocking、blocking；一次write1023x+ESC，逐个消费x；20ms读Esc且操作<1s，ZERO读None；drop writer后20ms返回UnexpectedEof | 原版在第一nonblocking分支失败，后面blocking分支未执行，不能说它也实测失败。候选两分支均通过；不等于每种tty canonical/竞争模式都验证 |
| full_buffer_escape_uses_already_pending_alt_suffix | 一次write1023x+ESC+a，共1025B；取完x后要求Alt+a，不允许单Esc或重复事件，末尾ZERO None | 原版、候选均通过，验证已有内核后缀不被新idle完成拆开；未来才到的后缀不在该断言内 |
| full_buffer_partial_utf8_csi_and_paste_survive_idle | 三组prefix使第一次write精确1024B：e7、ESC[、ESC[200~；取完x后20ms None，直接断言Parser.buffer==prefix；再写95/8c、D或组合字ZWJ加paste terminator；要求完整界、Left、原Paste，末尾ZERO None | 原版与候选均通过。合法partial后的第二write是完成输入，并非给孤立Esc追加救援键。无无限paste试验，无非法UTF8保真承诺 |
| escape_idle_completion_retains_real_wake_in_both_batch_orders（event-stream） | 一次1024B加真实waker；poll后断言TTY/WAKE存在，显式排序wake_first true/false；分别在x/Esc之前或之后取Interrupted，取满1023x并ZERO得到Esc，最后ZERO None | 候选两顺序通过。readiness来自真实内核，顺序由测试排序；不冒称自然观察到所有排列或三token含SIGWINCH全部排列 |

这四项新测试外，原五项zenpi_ready_tests逐字保留，仍覆盖2065字节无追加write、多read UTF8/CSI/paste、blocking普通timeout/EOF、跨write partial、已有Parser事件优先和双wake顺序。默认运行名过滤zenpi_同时选中既有event.rs的reset锁测试：8/8是旧mio4＋新3＋reset1；libc/event-stream9/9是旧mio5＋新4，reset不在该cfg。两配置互相重叠，不得合计成17个独立场景，也不能据此接受所有event reader或目录。

### 静态疑点之后才发生的实际证据

旧099只根据代码推导满buffer末尾ESC滞留；随后新产品轮才执行下面这些试验。本报告补充轮只读取其原始文件，不运行它们。所有时间为2026-09-12 UTC。新socket negative源码98ef991…为1afa原文加相同测试；最终41321e经过rustfmt，新增测试仅空白及可选尾逗号排版变化，fixture/阈值/断言未变。run.json记录的是实际子命令exit_code；外层归档脚本正常结束不意味着negative通过。

| 历史试验 | 明确结果 | 绑定 |
|---|---|---|
| negative-socket，16:40:55.084564–16:41:11.349908 | 3项：2通过、孤立ESC失败，left None/right Esc，exit101 | 4693B log SHA99d4a1cb2145fca97225e265f125db2557c04e2e359465693472d7a9e14c779b；source98ef991ba195fae668f9b44a62d9825272ab8871fe2647c9248a7803a84edf2e |
| fixed-default，16:42:22.359402–16:42:23.343200 | 8/8，exit0，原readiness回归保留 | 2078B log SHAd0b6ae9dad505ddfaafa9b22973ec9241e2c59919d361210ca771a4c10b89a2a；source41321e |
| fixed-libc-stream，16:42:37.809473–16:42:39.407404 | 9/9，exit0，含新Esc/wake双顺序 | 2271B log SHA09a4e0622714979fb42a02ed86958dfa94108a55367af9b003b38a3cfc124c29；source41321e |
| before公共PTY，16:41:48.587494–16:41:49.022832 | 原版也通过：1023x、Esc、other0，812µs，exit0 | 探针binary76a7782666c7e5b18f16f807f3b49cac37e10847ebf206c9271bdd78d411c3e8 |
| after公共PTY，16:43:09.626840–16:43:10.610349 | 同一fixture通过：1023x、Esc、other0，637µs，exit0 | 探针binary261562a5dc51f31c2d9a9479a0198bee0d1654337d9c6bcd496e371ba826f1c3 |

公共reader使用同一个21行Rust探针，enable_raw_mode、poll ZERO初始化、打印READY后在200ms固定总窗口以10ms poll/read消费；Python建立真实PTY，slave作为stdin，stdout/stderr为pipe，等READY后只write一次1024B，payload SHA808b153a414fe681a205a0f961c52059e074f3637560b1a0f43c1f6cd3dc6829。两次均无额外输入/resize/reset，恢复原termios且process reaped。探针源码SHA0eea4a385bbaabbe0e92ed7a42cc1298ce740446db54a4eb2be82e63c571b04d；Python fixture SHAfbcc361085b8523ba49aa17818c1f34d99c83f2dc2afc308c6988174fb1e6a3c。它们是独立公共event reader探针，不是Zenpi release或BentoBox交互测试。

必须保留的反证：公共PTY原版已经通过，本次没有记录每次read的实际长度，所以“PTY可能分成短read”只是推断，不能写成已观察事实；不能把socket可靠失败改称真实生产PTY先失败后通过。没有重跑直到得到想要的negative，也没有用附加键/增加buffer/放宽超时取绿。当前可以主张的结果是：真实socket精确满read边界的有限缺陷已复现，候选同夹具修复；公共PTY给出该次入口行为保留证据。

这些试验用独立vendor锁文件mio1.0.3/rustix1.0.5，在macOS arm64执行；冻结headless0ece91仅是构建上下文，非被测TUI/HTTP链。主控后来headless944049不进入这次试验。旧主控93f348组合的原29项kill-yank、budget、JSONL记录仍只证明编译时的mio1afa；本补充不据此宣布41321e最新组合通过。Linux/其它Unix/所有feature组合、错误逐项注入、任意连续EINTR及未闭合paste有界性依旧未验证。

### 本轮报告门禁与范围

G-FILE的增量语义由上面的逐行分析与实测边界支持，未变部分由精确全读链覆盖；本轮新离线verifier只验证报告原文前缀、三源hash、六段连续范围、两旧manifest及复制证据、run/log绑定和唯一报告patch，不执行旧脚本或产品。G-STAGE指定脚本本轮未运行，master review receipt未伪造，接受仍false。hash/范围/测试计数不能替代主控独立语义审阅。

候选只新增或更新099唯一正式报告，产品source.patch仅在历史证据目录内，绝不能作为此报告任务的送审patch应用。原229行基线、旧477行分析、静态疑点当时的状态均不删除；主控可在审阅后为655行版本生成独立接受证据。400–405目录链、root091、129/131以及其它文件均不随此补充接受。回滚只撤回本次报告增量，保留旧报告历史与所有产品字节，不修改主库、authority、旧ready、共享TUI或主控headless。


### 封包前主库身份与连续范围

最后只读核对时点为2026-09-12T16:55:38.971072+00:00：主库mio 25801B / SHA `41321e242e21fa85533dbae42314bcf80ab916e1d55e065d5ce98076002ac93f`，已与本报告655行目标相同；headless 366788B / SHA `9440492db142157995e0b479c2d31b80d9158ae624ca29d08f4d93db34e81509`。这与补充开始时mio1afa不同，是主控独立应用所致，本worker没有写主库。主控已明确组合回归正在执行，本轮不读取/宣称其结果通过，也不将旧93f348或独立vendor测试改绑成最新组合验收。正式099报告此时尚不存在，report.patch为该报告新文件。

|655行目标范围|字节范围|方法|SHA256|
|---|---|---|---|
|1–172|[0,7395)|复用1afa行1–172|`8bd510b2ed2a529c4bc23126105bd0c32cad14ae749729c6ecd69569c2d6d335`|
|173–178|[7395,7799)|新读全部新增行|`118e8f55382068f4f99b6716ba90ae4c22c3d00d7d1451a3844298ea3cc4fc92`|
|179–257|[7799,11118)|复用1afa行173–251|`108054d1c280fd62c9a9b1b53ed42d38f0e05eb5eb60d1509e98b498039d8271`|
|258–266|[11118,11402)|新读全部新增行|`a666af627453ccbff8a3dc358d58fe357f336051c47520fa2ce09695f1f21770`|
|267–492|[11402,19559)|复用1afa行252–477|`be4308a827e19f840ba1cdec99b255a943ecf8d8671ef687da85c546a20b3350`|
|493–655|[19559,25801)|新读全部新增行|`dc760582662a2dffdf9006e3d80c7076438279ff5f2b15d9311cd8385f7bc588`|

所有新运行仅为本包离线完整性检查，其外置receipt记录argv/cwd、开始结束、退出码和log/hash；未执行旧脚本、runtime、正式budget或任何产品测试。worker HEAD与94条非.ops dirty保持，两个旧包全部payload未变。独立主控语义接受仍待完成。
