"""Read-only portable integrity checks; no subprocess/network or product runs."""
from pathlib import Path
import json,hashlib,difflib
R=Path(__file__).resolve().parent
def read(p):return (R/p).read_bytes()
def js(p):return json.loads(read(p))
def sha(b):return hashlib.sha256(b).hexdigest()
def check(p,x):
 b=read(p);assert len(b)==x['bytes'] and sha(b)==x['sha256'],p
m=js('manifest.json');expected={x['path'] for x in m['files']}
assert expected=={p.relative_to(R).as_posix() for p in R.rglob('*') if p.is_file()}-{'manifest.json'}
for x in m['files']:check(x['path'],x)
cap=js('capture.json');scope=js('scope.json');assert not scope['accepted'] and scope['new_product_executions']==0 and scope['old_scripts_executed']==0
for old in cap['old_roots']:
 prefix=old['copy'];assert sha(read(prefix+'/manifest.json'))==old['manifest_sha256']
 for x in js(prefix+'/manifest.json')['files']:check(prefix+'/'+x['path'],x)
selector=js('authority/Docs/execution/active_requirement.json');assert selector['requirement_digest']==scope['requirement_digest']=='3456abcbbebbc4e0ab383c319851b0a6e71b19ee9b3c060a6e212f61a89c9d9d'
for p,x in cap['authority'].items():check('authority/'+p,x)
for version in ['original','final']:
 rows=[x for x in js('prior099/read-blocks.json') if x['version']==version];b=read('prior099/'+rows[0]['path']);end=0
 for x in rows:assert x['start']==end and sha(b[x['start']:x['end']])==x['sha256'];end=x['end']
 assert end==len(b)
after=read('sources/current-mio.rs');assert after==read('escape-evidence/after-mio.rs')
assert sha(after)=='41321e242e21fa85533dbae42314bcf80ab916e1d55e065d5ce98076002ac93f'
end=0;line=1;new_count=0
for x in js('current-read-chain.json'):
 assert x['start']==end and x['line_start']==line
 b=after[x['start']:x['end']];assert sha(b)==x['sha256'] and len(b)==x['bytes']
 assert len(b.splitlines())==x['line_end']-x['line_start']+1
 if 'old_path' in x:assert read(x['old_path'])[x['old_start']:x['old_end']]==b
 else:new_count+=len(b.splitlines())
 end=x['end'];line=x['line_end']+1
assert end==25801 and line==656 and new_count==178
formal=scope['owned_paths'][0];report=read(formal);old=read('prior099/'+formal);assert len(old)==28350 and sha(old)==scope['report_history_prefix_sha256']
assert report==old+read('appendix.md')
base=read('before-report.md')
if base:
 expected_patch=''.join(difflib.unified_diff(base.decode().splitlines(keepends=True),report.decode().splitlines(keepends=True),fromfile='a/'+formal,tofile='b/'+formal)).encode()
else:
 ls=report.splitlines(keepends=True);expected_patch=f'diff --git a/{formal} b/{formal}\nnew file mode 100644\n--- /dev/null\n+++ b/{formal}\n@@ -0,0 +1,{len(ls)} @@\n'.encode()+b''.join(b'+'+l for l in ls)
assert read('report.patch')==expected_patch and len(expected_patch)<262144
runs=0
for p in (R/'escape-evidence').glob('*.run.json'):
 x=json.loads(p.read_bytes());name=p.name[:-9];check('escape-evidence/'+name+'.log',{'bytes':x['log_bytes'],'sha256':x['log_sha256']});runs+=1
assert js('escape-evidence/negative-socket.run.json')['exit_code']==101
assert b'left: None' in read('escape-evidence/negative-socket.log')
for name,count in [('fixed-default',8),('fixed-libc-stream',9)]:assert f'{count} passed; 0 failed'.encode() in read('escape-evidence/'+name+'.log')
for name in ['before','after']:
 x=js('escape-evidence/'+name+'-public-pty-result.json');assert x['exit_code']==0 and x['writes']==1 and x['termios_restored'] and 'ascii=1023 esc=true' in x['stdout']
 assert sha(read('escape-evidence/public-reader-'+name))==x['binary_sha256']
assert not cap['combined_runtime_results_claimed'] and cap['final_read_main_source']['sha256']==sha(after)
print(json.dumps(dict(ok=True,item='ZS1-099',payloads=len(expected),unchanged_history_prefix_bytes=len(old),current_source_lines=655,new_lines_read=178,current_contiguous_ranges=6,historical_run_log_bindings=runs,report_only_patch=True,new_product_executions=0,old_scripts_executed=0,G_STAGE_executed=False,semantic_acceptance=False)))
