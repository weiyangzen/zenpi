import subprocess,sys,os,signal,json,time,datetime,hashlib
from pathlib import Path
w=Path(__file__).resolve().parent
name=sys.argv[1];argv=sys.argv[2:];start=datetime.datetime.now(datetime.timezone.utc).isoformat()
log=w/(name+'.log');out=log.open('wb');p=subprocess.Popen(argv,cwd=w/'candidate',stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
timed=False
try: code=p.wait(timeout=240)
except subprocess.TimeoutExpired:
 timed=True;os.killpg(p.pid,signal.SIGTERM)
 try:code=p.wait(timeout=5)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait(timeout=5)
out.close();b=log.read_bytes();receipt={'argv':argv,'cwd':str(w/'candidate'),'started_at':start,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':code,'timed_out':timed,'log_bytes':len(b),'log_sha256':hashlib.sha256(b).hexdigest(),'owners':{x:hashlib.sha256((w/'candidate'/x).read_bytes()).hexdigest() for x in ['src/tui.rs','tests/tui_composer.rs','tools/tui_composer_smoke.py','vendor/crossterm/src/event/source/unix/mio.rs']}}
(w/(name+'.run.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2));print(b.decode(errors='replace')[-2000:])
