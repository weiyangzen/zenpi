"""099 portable integrity checks only. No subprocess, product, network or writes."""
from pathlib import Path
import json, hashlib, difflib
R=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return (R/p).read_bytes()
def js(p):return json.loads(read(p))
def check_meta(p,x):
 b=read(p);assert len(b)==x['bytes'] and sha(b)==x['sha256'],str(p)
manifest=js('manifest.json');assert manifest['item']=='ZS1-099' and manifest['accepted'] is False
expected={x['path'] for x in manifest['files']}
actual={p.relative_to(R).as_posix() for p in R.rglob('*') if p.is_file()}-{'manifest.json'}
assert expected==actual,(expected-actual,actual-expected)
for x in manifest['files']:check_meta(x['path'],x)
s=js('scope.json');assert s['new_product_executions']==0 and not s['accepted'] and not s['master_review_receipt']
selector=js('authority/Docs/execution/active_requirement.json')
assert selector['requirement_digest']==s['requirement_digest']=='3456abcbbebbc4e0ab383c319851b0a6e71b19ee9b3c060a6e212f61a89c9d9d'
assert selector['blueprint_version']==s['blueprint_version']=='3.1.21'
assert selector['baseline_snapshot_sha256']==s['baseline_snapshot_sha256']
cap=js('capture.json')
for p,x in cap['authority'].items():check_meta('authority/'+p,x)
blocks=js('read-blocks.json')
for v,f,size,h in [('original','before-mio.rs',9026,'57f4a90b828444fcc6dd7199a73907bbbccf2df4b7808f9e8a0a4b0771e12e39'),('final','after-mio.rs',18871,'1afaaa245a132ea4670bd212d1c1c42a078b1fd4b950636147112485589753ef')]:
 b=read('sources/'+f);assert len(b)==size and sha(b)==h
 end=0;next_line=1;ls=b.splitlines(keepends=True)
 for x in [x for x in blocks if x['version']==v]:
  assert x['start']==end and x['line_start']==next_line
  assert x['start']==sum(map(len,ls[:x['line_start']-1]))
  assert x['end']==sum(map(len,ls[:x['line_end']]))
  block=b[x['start']:x['end']];assert len(block)==x['bytes'] and sha(block)==x['sha256']
  end=x['end'];next_line=x['line_end']+1
 assert end==size and next_line==len(ls)+1
before=read('sources/before-mio.rs');after=read('sources/after-mio.rs')
assert before[before.index(b'//\r\n// Following'):]==after[after.index(b'//\r\n// Following'):after.index(b'\r\n#[cfg(test)]')]
source_diff=b''.join(difflib.diff_bytes(difflib.unified_diff,before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile=b'a/vendor/crossterm/src/event/source/unix/mio.rs',tofile=b'b/vendor/crossterm/src/event/source/unix/mio.rs'))
assert read('source-only.diff')==source_diff
formal=s['owned_paths'][0];report=read(formal)
assert b'57f4a90b828444fcc6dd7199a73907bbbccf2df4b7808f9e8a0a4b0771e12e39' in report
assert b'G-FILE' in report and b'G-STAGE' in report
lines=report.splitlines(keepends=True)
expected_patch=(f'diff --git a/{formal} b/{formal}\nnew file mode 100644\n--- /dev/null\n+++ b/{formal}\n@@ -0,0 +1,{len(lines)} @@\n'.encode()+b''.join(b'+'+line for line in lines))
assert read('report.patch')==expected_patch and len(expected_patch)<256*1024
assert b''.join(line[1:] for line in expected_patch.splitlines(keepends=True)[5:])==report
old=js('prior129/manifest.json');assert sha(read('prior129/manifest.json'))==cap['old_ready_manifest_sha256']
oldmap={x['path']:x for x in old['files']};copied=0
for p in (R/'prior129').rglob('*'):
 if p.is_file() and p.name!='manifest.json':
  rel=p.relative_to(R/'prior129').as_posix();check_meta('prior129/'+rel,oldmap[rel]);copied+=1
run_count=0
for p in (R/'prior129').glob('*.run.json'):
 x=json.loads(p.read_bytes());log=p.name.replace('.run.json','.log')
 if 'log_sha256' in x:
  check_meta('prior129/'+log,dict(bytes=x['log_bytes'],sha256=x['log_sha256']));run_count+=1
for prefix,passed,count in [('baseline-clean-loopback-pty',False,11),('fixed-clean-loopback-pty',True,29),('fixed-original-pty',False,12)]:
 x=js('prior129/'+prefix+'-result.json');assert x['passed']==passed and len(x['checks'])==count and all(x['checks'].values())
for p,x in [(x['path'],x) for x in js('master-evidence-index.json')['files']]:check_meta('master-current/'+p,x)
for p in (R/'master-current').rglob('*.run.json'):
 x=json.loads(p.read_bytes())
 if isinstance(x.get('log'),dict):check_meta(p.relative_to(R).as_posix().replace('.run.json','.log'),x['log'])
newbin=js('master-current/binary.json')['sha256']
x=js('master-current/hosts/pty-after.json');assert x['passed'] and len(x['checks'])==29 and all(x['checks'].values()) and x['binary_sha256']==newbin
assert x['request_count']==4 and x['tui_processes']==3
x=js('master-current/hosts/pty-before.json');assert not x['passed'] and len(x['checks'])==11
x=js('master-current/hosts/jsonl-after/result.json');assert x['status']=='passed' and len(x['checks'])==35 and all(x['checks'].values()) and x['binary_sha256']==newbin
x=js('master-current/hosts/budget.json');assert x['ok'] and len(x['gates'])==8 and all(x['gates'].values()) and x['cold_start']['binary_sha256']==newbin
assert x['cold_start']['elapsed_ms']['samples']==[460.119959,36.881584,37.090333]
print(json.dumps(dict(ok=True,item='ZS1-099',payloads=len(expected),continuous_blocks=len(blocks),old_copied_payloads=copied,old_run_log_bindings=run_count,report_only_patch=True,product_executions=0,old_scripts_executed=0,G_STAGE_executed=False,semantic_acceptance=False),ensure_ascii=False))
