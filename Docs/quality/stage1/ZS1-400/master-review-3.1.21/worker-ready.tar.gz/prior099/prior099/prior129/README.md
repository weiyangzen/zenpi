# ZS1-129 Ctrl-U / resize 输入就绪修复候选

修复 Unix mio 读取器提前返回后遗漏本批就绪通知，导致原 Ctrl-U 留在终端缓冲，直到下一键才被读到的问题。candidate.patch 仅改 vendor/crossterm/src/event/source/unix/mio.rs 与 tests/tui_composer.rs；主控已明确授权 vendor 及内置测试范围。TUI 994215…、harness35899…及BentoBox保持逐字不变。vendor CRLF保持。

在同一去代理隔离环境中，原 release e9ba9476… 在原第11项后 Ctrl-U 断言失败；候选 release7be42aa…完整29checks、4次loopbackHTTP、3次TUI进程通过。Unicode/fold、1×1→140×40、12秒门限、所有按键/断言原样；通过场景无追加唤醒键或reset。两底层自然single-edge测试原0/2→修复2/2；扩展默认4项、libc+event-stream5项；composer46、Clippy及格式检查通过。只声明当前macOS aarch64实际执行结果。

read-review.md 为完整根因、逐文件理解与证据边界；build-inputs-before.tar.gz归档224项冻结输入，配合可逆patch重建after。binaries.tar.gz含原/新release与两版临时诊断binary，仅供hash比对，不自动执行。所有原始失败、代理环境下的HTTP Peer disconnected、临时trace与准备失败均保留。清洁运行使用clean-loopback.py，只去除实际存在的6个代理环境变量；HOME/CODEX_HOME不变，ZENPI_HOME隔离、假凭据、仅loopback。

verify.py只做离线完整性、输入/binary哈希、报告事实和正反补丁核验，不运行产品、Cargo、PTY、HTTP或任何归档脚本。运行 python3 -B verify.py 即可复核。

主控期间另行合入新的headless：冻结958837ad…，当前主库2f0835f3…；tools/generate_stage1_gantt.py也有主控漂移，详见boundary-after.json。没有把新headless混入任何旧运行，也没有把它回退到主库。本包不是当前主库最终组合验证；主控仍需独立整合与验收、处理owned paths绑定。未写主库/authority/claims/status/旧ready，未自行接受129。worker HEAD4dbd330d…与94条非.ops dirty未变，候选进程和夹具已回收。
