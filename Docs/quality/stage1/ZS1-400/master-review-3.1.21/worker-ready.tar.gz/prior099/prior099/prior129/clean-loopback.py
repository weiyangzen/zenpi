import os,sys
removed=[k for k in os.environ if k.lower() in {"http_proxy","https_proxy","all_proxy","no_proxy"}]
env={k:v for k,v in os.environ.items() if k not in removed}
print("Isolated loopback: removed proxy variable names "+repr(sorted(removed)),flush=True)
os.execvpe(sys.argv[1],sys.argv[1:],env)
