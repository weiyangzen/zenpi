# Fresh diagnostic with original assertions; only adds failing checkpoint capture.
from pathlib import Path
import sys,json,hashlib,threading
from tempfile import TemporaryDirectory
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
sys.path.insert(0,'/Users/wangweiyang/GitHub/zenpi/tools')
from tui_project_workspace_smoke import Terminal,screen_text
def kill_yank_smoke(binary, evidence):
    """Real modified keys, canonical drafts, owner receipts and exact HTTP bytes."""
    import fcntl, struct, termios
    from tui_user_shell_smoke import drain
    requests=[]; terminals=[]; gates={name:(threading.Event(),threading.Event()) for name in ('YANK_GATE','YANK_FAIL')}
    result={'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'checks':{},'snapshots':[]}
    def user_text(body):
        content=next(item['content'] for item in reversed(body['input']) if item.get('role')=='user')
        return content if isinstance(content,str) else ''.join(item.get('text','') for item in content)
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def do_POST(self):
            body=json.loads(self.rfile.read(int(self.headers['Content-Length'])));requests.append(body);number=len(requests);text=user_text(body)
            if text=='YANK_FAIL':
                gates[text][0].set();gates[text][1].wait(30)
                self.send_response(503);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(b'{"error":{"message":"YANK_EXPECTED_FAILURE"}}');return
            self.send_response(200);self.send_header('Content-Type','text/event-stream');self.end_headers()
            def emit(kind,**value):self.wfile.write(('data: '+json.dumps(dict(type=kind,**value))+'\n\n').encode());self.wfile.flush()
            try:
                emit('response.created',response={'id':f'yank-{number}','model':'gpt-4.1'})
                if text=='YANK_GATE':
                    gates[text][0].set()
                    while not gates[text][1].wait(.05):emit('response.output_text.delta',delta='')
                emit('response.output_text.delta',delta=f'YANK_REPLY_{number}')
                emit('response.completed',response={'id':f'yank-{number}','model':'gpt-4.1','status':'completed'})
            except (BrokenPipeError,ConnectionResetError):pass
    server=ThreadingHTTPServer(('127.0.0.1',0),Handler);threading.Thread(target=server.serve_forever,daemon=True).start()
    try:
        with TemporaryDirectory(prefix='kill-yank-pty-',dir=Path('.ops').resolve()) as raw:
            root=Path(raw);config=root/'fixture'
            for d in [root/'initial',root/'sessions',config]:d.mkdir(parents=True)
            (config/'config.toml').write_text(f'backend="openai"\nmodel="gpt-4.1"\nbase_url="http://127.0.0.1:{server.server_port}/v1"\nwire_api="responses"\nrequires_openai_auth=false\nmax_retries=0\n')
            (config/'auth.json').write_text(json.dumps({'OPENAI_API_KEY':'kill-yank-fixture-fake'}));(config/'auth.json').chmod(0o600)
            env={k:v for k,v in os.environ.items() if not k.startswith(('ZENPI_','OPENAI_'))};env.update(ZENPI_HOME=str(config),TERM='xterm-256color')
            t=Terminal(binary,root,env);terminals.append(t);checkpoint=config/'project-tabs.json';journal=root/'sessions/initial.jsonl';expected_http=0
            def saved():return json.loads(checkpoint.read_text())
            def draft():
                value=saved();return next(row['draft'] for row in value['project_state'] if row['name']==value['projects'][value['active']])
            def wait_text(text):
                try:t.wait(lambda:draft()['input']==text)
                except Exception:
                    result['failed_wait']={'expected':text,'draft':draft(),'checkpoint':saved(),'http_count':len(requests),'screen':screen_text(bytes(t.output)).decode()}
                    raise
            def paste(text):t.write(b'\x1b[200~'+text.encode()+b'\x1b[201~')
            def check(name,text):
                wait_text(text);drain(t.fd,t.output,.08);assert len(requests)==expected_http
                assert b'\x1b]52;' not in t.output
                result['checks'][name]=True;result['snapshots'].append({'check':name,'draft':draft(),'http_count':len(requests),'screen':screen_text(bytes(t.output)).decode()})
            def send_exact(text):
                nonlocal expected_http
                t.deliberate_enter();expected_http+=1;t.wait(lambda:len(requests)==expected_http)
                t.expect(f'YANK_REPLY_{expected_http}'.encode());t.wait(lambda:' Ready |' in screen_text(bytes(t.output)).decode().splitlines()[1]);wait_text('')
                assert user_text(requests[-1])==text
                result.setdefault('sent_payloads',[]).append({'text':text,'bytes':len(text.encode()),'sha256':hashlib.sha256(text.encode()).hexdigest()})
            paste('first\nbeta');wait_text('first\nbeta');t.write(b'\x01\x1b[C\x15');check('logical_line_ctrl_u_keeps_previous_line','first\neta')
            t.write(b'\x19');check('ctrl_y_restores_at_cursor','first\nbeta');t.write(b'\x01\x15');check('bol_ctrl_u_removes_only_previous_lf','firstbeta')
            t.write(b'\x19\x1b[1;5H\x15\x05\x0b');check('first_bol_noop_and_eol_ctrl_k_lf','firstbeta');t.write(b'\x19');wait_text('first\nbeta');t.clear_input()
            paste('head\n');wait_text('head\n');hidden='hidden\n'*200;paste(hidden);wait_text('head\n'+hidden);t.write(b'\x15');check('ctrl_u_fold_projection_ignores_hidden_newlines','head\n');t.write(b'\x19');check('hidden_multiline_payload_yanked_as_plain_text','head\n'+hidden);assert not draft()['paste_folds'];t.clear_input()
            paste('alpha beta');wait_text('alpha beta');t.write(b'\x17\x19\x19');check('single_buffer_repeat_yank','alpha betabeta');t.clear_input()
            paste('word');wait_text('word');t.write(b'\x15\x15');paste('x');wait_text('x');t.write(b'\x7f\x1b[3~\x19');check('empty_kill_and_plain_deletes_preserve_last_kill','word');t.clear_input()
            paste('left right');wait_text('left right');t.write(b'\x1b[1;5H\x1b[3;5~\x19');check('forward_word_kill_and_yank','left right');t.clear_input()
            literal='[Pasted Content 1001 chars] #1 ';payload='界e\u0301👨\u200d👩\u200d👧\u200d👦'*150
            paste(literal);wait_text(literal);paste(payload);wait_text(literal+payload);old_id=draft()['paste_folds'][0]['id'];t.write(b'\x17');wait_text(literal)
            paste('z'*1001);wait_text(literal+'z'*1001);t.write(b'\x1b[D\x19');check('fold_canonical_unicode_yank_plain_next_fold_shifted',literal+payload+'z'*1001)
            assert len(draft()['paste_folds'])==1 and draft()['paste_folds'][0]['id']>old_id and draft()['paste_folds'][0]['start_byte']==len((literal+payload).encode())
            before=draft();fcntl.ioctl(t.fd,termios.TIOCSWINSZ,struct.pack('HHHH',1,1,0,0));drain(t.fd,t.output,.1);fcntl.ioctl(t.fd,termios.TIOCSWINSZ,struct.pack('HHHH',40,140,0,0));check('one_column_resize_preserves_yanked_payload',before['input']);assert draft()==before
            t.write(b'\x15');wait_text('z'*1001);t.write(b'\x19');check('ctrl_u_uses_logical_line_after_soft_wrap',before['input']);assert draft()==before
            t.write(b'\x17\x19');wait_text(before['input']);send_exact(before['input']);t.write(b'\x19');check('successful_submit_preserves_kill',payload);t.clear_input()
            paste('slash-survivor');wait_text('slash-survivor');t.write(b'\x15');wait_text('');t.command('/status');wait_text('');t.write(b'\x19');check('local_slash_preserves_kill','slash-survivor')
            t.write(b'\x12\x19');t.cancel_picker();wait_text('slash-survivor');t.write(b'\x19');check('history_search_focus_and_escape_preserve_kill','slash-survivorslash-survivor');t.clear_input()
            paste('A-kill');wait_text('A-kill');t.write(b'\x15');wait_text('');other=root/'other';other.mkdir();t.folder(other,mouse=False);t.wait(lambda:saved()['active']==1);t.write(b'\x19');check('new_project_empty_kill_buffer','')
            paste('B-kill');wait_text('B-kill');t.write(b'\x15\x19');check('project_b_own_kill','B-kill');t.folder(root/'initial',mouse=False);t.wait(lambda:saved()['active']==0);t.write(b'\x19');check('project_a_retains_independent_kill','A-kill')
            t.write(b'\x14');t.expect(b'Open project folder');t.write(b'\x19');t.cancel_picker();check('folder_picker_ctrl_y_does_not_edit_composer','A-kill');t.clear_input()
            paste('held-kill');wait_text('held-kill');t.write(b'\x15');wait_text('');t.write(b'A\x19');check('ordinary_held_ascii_flush_before_yank','Aheld-kill');send_exact('Aheld-kill')
            t.command('YANK_GATE');expected_http+=1;t.wait(gates['YANK_GATE'][0].is_set);wait_text('')
            def records():
                rows=[json.loads(line) for line in journal.read_text().splitlines()];result['journal_records']=rows;return rows
            def changes(action):return [r['event']['change'] for r in records() if r.get('kind')=='event' and r['event'].get('type')=='input_queue' and r['event']['change']['action']==action]
            t.command('queued original');t.wait(lambda:changes('enqueued'));wait_text('');input_id=changes('enqueued')[-1]['input']['id']
            t.command(f'/input edit {input_id} 0 queued edited');t.wait(lambda:changes('edited'));wait_text('');assert changes('edited')[-1]['text']=='queued edited'
            t.command(f'/input cancel {input_id}');t.wait(lambda:changes('cancelled'));wait_text('');t.write(b'\x19');check('busy_input_owner_edit_cancel_do_not_change_kill','held-kill')
            gates['YANK_GATE'][1].set();t.expect(f'YANK_REPLY_{expected_http}'.encode());t.wait(lambda:' Ready |' in screen_text(bytes(t.output)).decode().splitlines()[1]);check('background_success_keeps_current_yanked_draft','held-kill');result['input_events']=[r['event'] for r in records() if r.get('event',{}).get('type')=='input_queue'];t.clear_input()
            t.command('YANK_FAIL');expected_http+=1;t.wait(gates['YANK_FAIL'][0].is_set);wait_text('');paste('new-kill');wait_text('new-kill');t.write(b'\x15');wait_text('');paste('new-draft');wait_text('new-draft')
            gates['YANK_FAIL'][1].set();t.expect(b'Request failed');wait_text('new-draft');t.write(b'\x19');check('async_failure_does_not_roll_back_newer_kill_or_draft','new-draftnew-kill');t.clear_input()
            unknown=[r['event']['operation_id'] for r in records() if r.get('event',{}).get('type')=='operation_finished' and r['event'].get('outcome')=='unknown_outcome']
            assert unknown;t.command('/recovery abandon '+unknown[-1]+' --yes');wait_text('')
            # Approval is a real local subprocess boundary, denied before side effect.
            t.command('!touch yank-approval-must-not-run');t.expect(b'Enter confirm');t.write(b'\x19');drain(t.fd,t.output,.1);assert not (root/'initial/yank-approval-must-not-run').exists() and draft()['input']=='';t.write(b'n\r');t.expect(b'Request failed');wait_text('!touch yank-approval-must-not-run');t.clear_input();result['checks']['approval_ctrl_y_neither_yanks_nor_confirms']=True
            paste('persisted-yank');wait_text('persisted-yank');t.write(b'\x15\x19');wait_text('persisted-yank');t.close(preserve_draft=True);t=Terminal(binary,root,env);terminals.append(t);wait_text('persisted-yank');t.write(b'\x19');check('restart_retains_yanked_draft_but_clears_ephemeral_buffer','persisted-yank');t.clear_input()
            full='M'*(256*1024);paste(full);wait_text(full);t.write(b'\x15');wait_text('');paste('keep');wait_text('keep');before=draft();t.write(b'\x19');t.expect(b'Yank exceeds 256 KiB');check('yank_256k_rejection_atomic','keep');assert draft()==before
            t.write(b'\x7f'*4+b'\x19');check('rejected_yank_keeps_complete_buffer_for_retry',full);t.clear_input();t.close(preserve_draft=True)
            value=saved()
            for row in value['project_state']:row['messages']=[];row['draft'].update(input='',cursor=0,paste_folds=[],history=[])
            row=next(row for row in value['project_state'] if row['name']==value['projects'][value['active']]);row['messages']=[{'role':'System','text':'m'*(256*1024),'blocks':[]} for _ in range(15)]+[{'role':'System','text':'n'*(64*1024),'blocks':[]}]
            encoded=json.dumps(value,ensure_ascii=False,indent=2).encode();assert len(encoded)<4*1024*1024;checkpoint.write_bytes(encoded)
            t=Terminal(binary,root,env);terminals.append(t);wait_text('');paste('K'*150000);wait_text('K'*150000);t.write(b'\x15');wait_text('');paste('p'*75000);wait_text('p'*75000);before=draft();t.write(b'\x19');t.expect(b'Yank exceeds 4 MiB');check('pretty_checkpoint_yank_rejection_atomic','p'*75000);assert draft()==before
            t.write(b'\x7f\x19');check('checkpoint_rejection_preserves_buffer_retry_after_plain_fold_delete','K'*150000)
            result['journal_records']=records();t.close(preserve_draft=True);result.update(passed=True,request_count=len(requests),tui_processes=len(terminals))
    except Exception as error:result.update(passed=False,error=str(error));raise
    finally:
        for _,release in gates.values():release.set()
        for t in terminals:t.cleanup()
        server.shutdown();server.server_close();evidence.parent.mkdir(parents=True,exist_ok=True)
        evidence.with_suffix('.pty.log').write_bytes(b'\nPROCESS\n'.join(bytes(t.output) for t in terminals));evidence.with_suffix('.http.json').write_text(json.dumps(requests,ensure_ascii=False,indent=2)+'\n');evidence.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    return result


if __name__=='__main__':
    kill_yank_smoke(Path(sys.argv[1]).resolve(),Path(sys.argv[2]).resolve())
