from pathlib import Path
import hashlib,json,re,difflib
W=Path(__file__).resolve().parent;data=(W/'capture/zenpi/src/render.rs').read_bytes();lines=data.splitlines(keepends=True)
def identity(blob):return {'bytes':len(blob),'lines':len(blob.splitlines()),'sha256':hashlib.sha256(blob).hexdigest()}
def save(name,value):(W/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
base=W/'history/target096-review320-ready/files/Docs/quality/stage1/ZS1-096/worker-review320/baseline-render.rs';baseline=base.read_bytes();assert hashlib.sha256(baseline).hexdigest()=='6eaaa712745659ae48f429217c5eb8961dd12e71789f8a2bc70867ee71ba25a7'
diff=''.join(difflib.unified_diff(baseline.decode().splitlines(True),data.decode().splitlines(True),fromfile='baseline/src/render.rs',tofile='current/src/render.rs'));(W/'baseline-to-current.diff').write_text(diff)
save('baseline-comparison.json',{'baseline_path':str(base.relative_to(W)),'baseline':identity(baseline),'current':identity(data),'net_bytes':len(data)-len(baseline),'net_lines':len(lines)-len(baseline.splitlines()),'diff':identity(diff.encode()),'baseline_new_full_read':False,'inherited_report_equals_old_final':(W/'history/inherited-worker-report.md').read_bytes()==(W/'history/target096-review320-ready/files/Docs/learn/stage1_pi_mono/targets/zenpi/files/src/render.rs_learn.md').read_bytes(),'old_working_report_is_exact_prefix':(W/'history/inherited-worker-report.md').read_bytes().startswith((W/'history/old-working-report.md').read_bytes())})
spans=[(1,29,'M10'),(30,56,'M01'),(57,62,'M01'),(63,138,'M01'),(139,149,'M02'),(150,191,'M02'),(192,240,'M02'),(241,264,'M03'),(265,292,'M03'),(293,303,'M12'),(304,384,'M03'),(385,401,'M04'),(402,412,'M03'),(413,437,'M05'),(438,486,'M05'),(487,533,'M06'),(534,568,'M06'),(569,658,'M06'),(659,678,'M05'),(679,754,'M07'),(755,762,'M01'),(763,784,'M08'),(785,832,'M08'),(833,860,'M08'),(861,866,'M09'),(867,883,'M07'),(884,919,'M07'),(920,967,'M07'),(968,1053,'M09'),(1054,1067,'M09'),(1068,1108,'M09'),(1109,1148,'M02'),(1149,1174,'M02'),(1175,1189,'M07'),(1190,1206,'M10'),(1207,1246,'M04'),(1247,1260,'M02'),(1261,1273,'M11')]
fn_rows=[]
for n,line in enumerate(lines,1):
 match=re.match(rb'^\s*(?:pub\s+)?fn\s+(\w+)',line)
 if match is None:continue
 indent=line[:len(line)-len(line.lstrip())];end=next(k for k in range(n+1,len(lines)+1) if lines[k-1].rstrip()==indent+b'}');chunk=b''.join(lines[n-1:end]);kind='source-test' if n>=1274 else 'test-helper' if n in [294,1266] else 'production';fn_rows.append({'name':match.group(1).decode(),'kind':kind,'lines':[n,end],'bytes':len(chunk),'sha256':hashlib.sha256(chunk).hexdigest()})
test_rows=[row for row in fn_rows if row['kind']=='source-test']
for index,row in enumerate(test_rows):
 start=row['lines'][0];end=test_rows[index+1]['lines'][0]-1 if index+1<len(test_rows) else len(lines);spans.append((start,end,'M11' if start<1387 else 'M12'))
units=[]
for index,(lo,hi,mapping) in enumerate(spans,1):
 chunk=b''.join(lines[lo-1:hi]);start=sum(map(len,lines[:lo-1]));units.append({'id':'U%02d'%index,'lines':[lo,hi],'byte_range':[start,start+len(chunk)],'bytes':len(chunk),'sha256':hashlib.sha256(chunk).hexdigest(),'map':mapping})
for row in fn_rows:
 unit=next(u for u in units if u['lines'][0]<=row['lines'][0]<=u['lines'][1]);row['unit']=unit['id'];row['map']=unit['map']
tests=[]
for row in fn_rows:
 if row['kind']!='source-test':continue
 lo,hi=row['lines'];chunk=b''.join(lines[lo-1:hi]);tests.append({**row,'id':'T%02d'%(len(tests)+1),'ordinary_assert_sites':len(re.findall(rb'\bassert(?:_eq|_ne)?!',chunk)),'snapshot_sites':0,'executed':False})
save('semantic-units.json',units);save('function-bindings.json',fn_rows);save('source-tests.json',tests)
reuse=[]
for item,pkg,filename in [('ZS1-308','reference308-keys321-ready','key_hint.rs'),('ZS1-309','reference309-status321-ready','status_indicator_widget.rs')]:
 old=W/'history'/pkg;rel='capture/codex/codex-rs/tui/src/'+filename;prior=old/'evidence'/rel;new=W/rel;assert prior.read_bytes()==new.read_bytes();ledger=json.loads((old/'evidence/read-binding.json').read_text());selected=[r for r in ledger if r.get('source','').endswith(filename) or r.get('file','').endswith(filename)]
 reuse.append({'item':item,'package':str(old.relative_to(W)),'source_path':rel,'source':identity(new.read_bytes()),'manifest':identity((old/'manifest.json').read_bytes()),'formal096_credit':False,'prior_read_ledger':str((old/'evidence/read-binding.json').relative_to(W)),'prior_ledger_rows':len(ledger),'new_runtime_executions':0})
save('reference-reuse.json',reuse)
print(json.dumps({'source':identity(data),'units':len(units),'functions':len(fn_rows),'production':sum(r['kind']=='production' for r in fn_rows),'helpers':sum(r['kind']=='test-helper' for r in fn_rows),'tests':len(tests),'asserts':sum(r['ordinary_assert_sites'] for r in tests),'reads':len(json.loads((W/'read-binding.json').read_text())),'baseline_delta':[len(data)-len(baseline),len(lines)-len(baseline.splitlines())],'test_counts':[(r['id'],r['name'],r['ordinary_assert_sites']) for r in tests]},indent=2))
