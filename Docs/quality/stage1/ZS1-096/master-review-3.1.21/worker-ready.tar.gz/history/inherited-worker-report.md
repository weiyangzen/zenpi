# ZS1-096 · src/render.rs 完整文件复核

候选状态 `[_]`。本轮完成冻结基线和当前文件的连续全文阅读，输出静态理解及待验证差距；真实行为运行0，未修改产品、运行Cargo/PTY/HTTP或改变主库/蓝图状态。

## 正式范围、版本与阅读事实

先核对主库3.1.20蓝图：ZS1-096路径`src/render.rs`，L1依赖ZS1-001，owned report仅`Docs/learn/stage1_pi_mono/targets/zenpi/files/src/render.rs_learn.md`，G-FILE/G-STAGE逐项校验；ZS1-090目录和ZS1-125交互实现均独立。requirement digest `8d525b351d066ce9b0487a485337647d47233275782e4f4d154423a623fe1645`。

基线与当前均30217B、901行、SHA256 `6eaaa712745659ae48f429217c5eb8961dd12e71789f8a2bc70867ee71ba25a7`。基线来自原worktree保留的anthropic-mainimport/previous；current从只读主库捕获。没有因为字节相同就跳过current全文：先读基线1–300、301–600、601–901，再读current1–450、451–901，所有函数及测试正文完整输出并阅读。证据块事后按相同冻结字节分为1–300、301–600、601–900、901，校验无遗漏尾部；这类覆盖校验不是独立语义验收。

共有39个函数声明，分为27个生产函数、1个测试helper和11个inline tests；不是39个测试。两个额外测试文件分别71行/4tests、60行/4tests，均全文读完，均未运行。baseline/current相同不意味着依赖和caller没变化。必要TUI只捕获一次，SHA256 `10884fa44e143e0127f5f571c6b2f0e0bdd9675f9434664190d9bcde8d752da8`、586657B；这是主控队列/会话刷新修复后的新版本片段，不是085旧d2a的延续证明。各caller时间/hash见caller-references.json。

主库和本地此前都无本报告，接收基线absent。本项仅报告+worker-review320新证据；66份旧ready manifest完整保留，working render.rs不改。不接收其它owner、不开任务/subagent。

## 公开职责、数据模型和限额

此模块是纯内存Markdown子集解析和Ratatui Line/Span投影，没有文件、网络、子进程、持久化或终端write。lib.rs公开导出render；它产生的Span由caller选择如何渲染。因此“控制字符未进入本模块返回span”与“终端实际写入/注入”是两个证据层级，不能混说。

MarkdownBlock拥有Paragraph、Heading(level/text)、Code(language/text)、Quote、ListItem(ordered/marker/text)、Rule。输入先按UTF8边界截至256KiB，再清理正文，tab扩展后的输出也不超过256KiB。默认render_markdown返回至多8192行；width钳制1–65535。MAX_MARKDOWN_CELLS为4Mi近似cells，用于按width限制保留行数，不是总堆内存/CPU/全会话预算。显式with_limit接受调用者请求，requested=0仍至少1行；它的上限不是无条件固定8192，不能把默认API文档套用所有显式参数。

解析是刻意有限子集：未知语法保留普通文字；没有CommonMark合规、HTML解释、图片加载、链接打开、语法高亮或嵌套Markdown执行。链接变为有样式的label并隐藏target，这是当前设计和测试明确要求；不提供可点击URI。控制字符被替换，但不对所有Unicode格式/双向控制字符作可视化；若要求抵抗视觉混淆，需要另定显示策略，不能声称当前是所有Unicode显示的安全规范化。

## 所有生产函数的连续理解

| 行 | 函数 | 具体行为与边界 |
| --- | --- | --- |
|54|parse_markdown|先truncate/sanitize；以行扫描并维护paragraph和可选code状态。代码中同marker、长度不少于开fence且无language才关闭，否则原文加入。EOF未闭合fence仍输出Code。普通状态依次fence、blank、heading、quote、list、rule、paragraph；不隐藏未识别行。|
|132|render_markdown|调用with_limit，传默认8192。|
|143|render_markdown_prefixed|width钳制，prefix按cell截到width-1，预留至少1cell正文，先生成body再逐行加首行prefix或同宽空格；body预算未包含新增prefix，且prefix没有正文sanitize。|
|185|render_plain_prefixed|正文只sanitize和换行，不解释#、---、fence；完整wrap后take行预算，再附prefix；外部prefix约束与Markdown版本相同。|
|227|render_markdown_with_limit|先计算行上限、完整parse所有blocks，再按block输出。block间加空行；paragraph/heading inline，code专门投影，quote/list加标记，rule铺width横线。达到保留行上限后停止外层；空结果补一空行。|
|303|flush_paragraph|空则无动作，否则以newline join成单Paragraph并clear临时vector。|
|311|heading_info|trim_start，1–6个ASCII#且后跟whitespace才是heading；text trim；超过6或#直接接字保留普通段落。|
|327|quote_info|trim_start后单个>，再至多移除一个空格；不是递归blockquote。|
|333|list_info|-/\*/+后有whitespace才识别无序；ASCII数字串+点+whitespace识别有序，不解析整数防溢出；marker字符串本身可很长。无序输出统一-，有序保留数字marker。|
|366|is_rule|trim后byte len至少3，首字符为-/\*/_且其余同字符或whitespace。处于list识别之后，部分带空格组合先成为ListItem；不宣称CommonMark规则一致。|
|377|starts_with_whitespace|检查首个char.is_whitespace。|
|381|fence_info|trim_start，至少3个反引号或波浪号；余文首个whitespace分隔token为language。不是完整info-string语言解析；关闭fence不能带language。|
|415|render_inline_text|完整inline_segments、完整wrap_segments后逐行push，到max_lines停；保留限额不限制前两步已做工作。|
|432|render_prefixed_inline|供quote/list使用，首行marker bold、续行同宽空格、至少1cell body；外层max_lines按完整width传入，与公开prefixed路径不同。|
|468|render_code|可选[language]一行，浅黄code；完整split code行，然后每行wrap_plain，首视觉行|标记、续行空格。达到max_lines后返回；无syntax lexer。|
|516|inline_segments|逐UTF8字符推进；词内underscore按前方非underscore字符判定保留；尝试code/bold/italic/link，成功flush plain并记录style，失败保留当前字面字符继续。不递归解析已取出的content。|
|598|parse_delimited|查找首个closing delimiter，空content不识别，成功返回content拷贝及消费长度；_marker参数不参与逻辑。失败后caller逐字符再试，某些输入存在重复扫描。|
|612|parse_link|caller仅在[开头调用；寻找第一个]，必须接(，再找第一个)，target非空；返回label和消费长度，丢target；不处理嵌套括号或escaped bracket。|
|625|wrap_segments|逐char算UnicodeWidthChar，newline结束当前行；单char宽于viewport变?；新char会溢出则另起行；同style span合并。返回完整vector，无max_lines参数。|
|665|wrap_plain|code行按char宽度拆String，无max_lines参数；宽字符过窄变?；调用者已按newline拆行。|
|691|heading_style|1浅青、2青、其它浅蓝，统一bold。|
|700|push_line|仅在output.len<max_lines才push；传入Line在进入函数前已构造，不能阻止临时分配。|
|706|bounded_line_limit|requested至少1，再取4Mi/width至少1的最小值；是估算行数，不做累积byte/span预算。|
|712|truncate_bytes|小于限额返回原切片；否则向前退到UTF8 char boundary，不是grapheme boundary，且不返回truncated标记。|
|728|sanitize_text|将固定256KiB上限传给下面helper。|
|732|sanitize_text_with_limit|CRLF只保留LF，lone CR也转newline，tab变4空格，其它char.is_control变?，普通字符按encoded UTF8长度预检查；扩展后超限立即停。|
|763|truncate_to_width|逐char宽度累积，达到viewport前停；不做byte cap、sanitize或grapheme分组。零宽字符不消耗cell预算，外部prefix会走这个入口。|

完整function-index另列27函数以及测试区域的精确声明，避免将测试helper混入生产职责。以上不省略函数，也没有用目录概览替代文件阅读。

## 必要caller与输出进入产品的位置

冻结TUI片段显示Assistant/System通过render_markdown_prefixed，User/Tool/Error/Reasoning通过render_plain_prefixed；prefix固定`● `或`◇ Reasoning: `。审批预览及transcript inspector使用空prefix的plain路径。故外部任意prefix的公共API缺口不等于当前provider能控制生产prefix。主控后续修改TUI不改变本次render主体快照；旧085的idle刷新问题不在此重复认定。

TUI inspector另用parse_markdown挑出Code块，持有有限entries；正文转换/截断发生在检查器看到code前，raw text entry与code entry不是完全相同的字节对象。view_model.rs片段from_markdown将枚举转换并validate，from_markdown_text先parse后检查MAX_VIEW_BLOCKS；这约束返回canonical block数量，但不能避免parse阶段先建立全部blocks。正常消息渲染的line/cell预算和canonical view模型的block限制是不同阶段。

## 静态差距、适用范围及建议验证

1. **P2：正文inline失败路径可重复扫描整个后缀。** inline_segments L516–595在失败时仅前进一个字符；parse_link L612对当前后缀查找']'。一个包含大量未闭合左方括号的普通paragraph会对每个位置再次扫描剩余文本，最坏工作量为平方级。256KiB输入上限只限制n，不证明最坏处理时间足够小；max_lines在parse/inline之后起作用，无法救这个路径。生产Assistant/System可进入该解析流程。建议避免失败位置重复搜索，使用单次扫描/缓存结束位置或明确工作量上限。需要主控在有限隔离测试中比较规模增长，保存实际耗时；本轮没有运行此输入或报告实测卡顿。

2. **P2，公共API契约：prefix绕过正文sanitize和byte限制。** 两个public prefixed函数对prefix直接UnicodeWidthStr::width和truncate_to_width；控制字符宽度无值时按0保留，换行或ESC可留在返回span，零宽Unicode串也没有256KiB byte cap。当前已读生产caller是固定短/空prefix，所以不声称已证实provider终端注入或执行能力。建议将prefix明确标注为受信任固定文本，或者与正文同样约束为单行、有限byte/cell、去控制字符，再由终端层验证输出。现有control测试只把控制序列放在body，没覆盖prefix。

3. **P2，公共API预算：prefix复制不计入4Mi cells预算。** 公开prefixed路径按body_width求行数，然后对每行复制prefix/continuation。极宽viewport配几乎占满宽度的外部prefix，会留下body_width=1并允许8192行，续行空格总量可达约512MiB，远超注释意图。该数值是参数公式推导，不是分配实验；生产固定短prefix缓和此特定放大，但公共API宣称outside-terminal width防护不能涵盖这一路径。建议预算按最终完整行宽和真实保留byte计算，prefix也做独立byte上限；以小规模预算测试验证而非制造巨大分配。

4. **P2：返回行上限晚于临时分配。** render_plain_prefixed先wrap全部输入再.take；render_inline_text/prefixed_inline同样先生成全部lines；render_code先collect所有code_lines再对长行完整wrap。正文最多256KiB仍可在一cell或大量newline条件下建立远多于8192条临时Line/String。parse也先建完整blocks。建议将remaining lines/cells传入wrap/parser，逐步生成并及时停止；测试区分返回len和峰值分配/扫描工作。现有宽viewport测试只断言保留行数，不能证明临时内存达标。

5. **P2：截断缺少结构化可见提示。** 输入字节或行上限截断后只返回Vec；调用者无法从结果明确知道“全部内容”还是“前缀”。TUI审批/inspector用同一plain返回列表计算可滚动范围，render层丢弃的末尾内容不能靠滚动恢复。审批owner可能另有preview.truncated提示，但不等于renderer这一层达到byte/line预算时一定告知。建议返回truncated及保留原文读取路径，或保留有界提示行，并明确哪些内容适合有限preview。未运行超限approval，也未据此声称审批越权。

6. **显示保真边界：按char而非grapheme换行/截断。** UTF8合法不代表组合字符、emoji ZWJ、variation selector等整簇保留；过窄viewport把单宽字符变?是有意降级，可能丢失原字。新TUI编辑器按grapheme处理不能自动修复此renderer。建议如产品要求按可见字符复制/对齐，增加组合/ZWJ跨style与边界用例并保持原始文本可访问。这里没有把所有Unicode输入断言成宽度错误，更不以“safe”注释推断视觉完整性。

文档API的requested=0返回至少1、显式with_limit可请求超过默认8192、链接隐藏target等是可读到的约定/现状，未自动列为安全漏洞。该模块不负责transcript整体oldest-prefix窗口选择；这个TUI问题属于独立owner，不能把其修复作为本文件通过条件。

## 全部测试源码及证据强度

inline helper line_text(L782)只是拼接span文本。11个inline tests完整阅读：

| test属性行 | 用例 | 实际断言范围 |
| --- | --- | --- |
|789|parses_blocks_without_swallowing_unknown_text|八个block变体/位置、语言token、未知语法回Paragraph。|
|812|renders_inline_styles_and_hides_link_target|bold/italic style、label存在、target不显示。|
|829|output_is_bounded_for_narrow_unicode_viewports|一cell时所有拼接行宽<=1，不等于原文保真。|
|840|unclosed_fence_is_visible_as_code|EOF未闭合code保留语言和文本。|
|848|line_limit_is_hard|四段输入max_lines=2时返回两行。|
|854|terminal_control_sequences_are_rendered_as_text|body ESC去除并显示?、tab扩4空格；未测试prefix。|
|862|crlf_input_does_not_leak_carriage_returns|CRLF空行分隔两段，无CR残留。|
|869|prefixed_rendering_keeps_role_and_body_inside_width|普通ASCII短prefix、width8、续行缩进；未测长/零宽prefix。|
|881|plain_prefixed_rendering_does_not_interpret_markers|#和---保持字面。|
|889|sanitization_bound_applies_after_tab_expansion|大量tab扩展后byte上限。|
|895|cell_budget_limits_wide_viewport_allocations|宽65535、128规则输入，返回行数有限；无峰值内存、prefix或复杂inline时序断言。|

tests/render_markdown.rs全文71行包含4tests：标识符underscore保持且独立emphasis仍去marker；block解析保code；一cell行宽；显式行limit保首行。tests/tui_markdown.rs全文60行包含4tests：TestBackend完整小Markdown片段显示；1x1绘制无panic（不检查输出保真）；user/tool原样marker；set_input控制字符清理。最后一项是TUI输入路径，不能冒充render prefix净化测试。两文件各有一个输出拼接helper及imports，均读完。

本轮共读19个不同测试定义，0个实际执行；baseline/current相同11inline不计成22个不同测试。没有Rust test exit0、运行时benchmark、真实终端安全或hostedCI证据。此前主控release预算/其它owner测试不移植为本096独立通过。仅完整性checker的实际退出码可计作本轮文档证据验证。

## 封包与接收边界

证据包括完整基线/current、连续字节块、function/test索引、两份完整外部测试、三份caller身份及必要片段、原working文件hash、66份旧ready摘要、独立verifier与实际G-STAGE输出。live验证检查权威/主库owner/source和接收absent；frozen模式校验所有冻结对象和报告，允许在包内files根独立执行；caller后续漂移作为观察记录，不改写捕获证据。

候选补丁只在临时目录做正向apply/check、每文件hash和逆向check/还原，不向主库写任何字节。G-STAGE若因缺ZS1-096.master.json失败，保留实际非零和structural结果，不以checker替代主控语义验收。完成report/ready后停止，回退仅本项新增报告和证据，既有源码/候选/蓝图不变。


## 两版逐函数声明索引

两版相同，以下列出共同精确声明；baseline/current独立JSON索引和完整源码另保留。

| 行 | 分类 | 声明 |
| --- | --- | --- |
| 54 | production | `pub fn parse_markdown(input: &str) -> Vec<MarkdownBlock> {` |
| 132 | production | `pub fn render_markdown(input: &str, width: usize) -> Vec<Line<'static>> {` |
| 143 | production | `pub fn render_markdown_prefixed(` |
| 185 | production | `pub fn render_plain_prefixed(` |
| 227 | production | `pub fn render_markdown_with_limit(` |
| 303 | production | `fn flush_paragraph(blocks: &mut Vec<MarkdownBlock>, paragraph: &mut Vec<String>) {` |
| 311 | production | `fn heading_info(line: &str) -> Option<(u8, String)> {` |
| 327 | production | `fn quote_info(line: &str) -> Option<String> {` |
| 333 | production | `fn list_info(line: &str) -> Option<(bool, String, String)> {` |
| 366 | production | `fn is_rule(line: &str) -> bool {` |
| 377 | production | `fn starts_with_whitespace(text: &str) -> bool {` |
| 381 | production | `fn fence_info(line: &str) -> Option<(char, usize, Option<String>)> {` |
| 415 | production | `fn render_inline_text(` |
| 432 | production | `fn render_prefixed_inline(` |
| 468 | production | `fn render_code(` |
| 516 | production | `fn inline_segments(text: &str, base_style: Style) -> Vec<StyledSegment> {` |
| 598 | production | `fn parse_delimited(rest: &str, _marker: char, delimiter: &str) -> Option<(String, usize)> {` |
| 612 | production | `fn parse_link(rest: &str) -> Option<(String, usize)> {` |
| 625 | production | `fn wrap_segments(segments: &[StyledSegment], width: usize) -> Vec<Line<'static>> {` |
| 665 | production | `fn wrap_plain(text: &str, width: usize) -> Vec<String> {` |
| 691 | production | `fn heading_style(level: u8) -> Style {` |
| 700 | production | `fn push_line(output: &mut Vec<Line<'static>>, line: Line<'static>, max_lines: usize) {` |
| 706 | production | `fn bounded_line_limit(width: usize, requested: usize) -> usize {` |
| 712 | production | `fn truncate_bytes(text: &str, max_bytes: usize) -> &str {` |
| 728 | production | `fn sanitize_text(text: &str) -> String {` |
| 732 | production | `fn sanitize_text_with_limit(text: &str, max_bytes: usize) -> String {` |
| 763 | production | `fn truncate_to_width(text: &str, width: usize) -> String {` |
| 782 | test_helper | `fn line_text(line: &Line<'_>) -> String {` |
| 790 | inline_test | `fn parses_blocks_without_swallowing_unknown_text() {` |
| 813 | inline_test | `fn renders_inline_styles_and_hides_link_target() {` |
| 830 | inline_test | `fn output_is_bounded_for_narrow_unicode_viewports() {` |
| 841 | inline_test | `fn unclosed_fence_is_visible_as_code() {` |
| 849 | inline_test | `fn line_limit_is_hard() {` |
| 855 | inline_test | `fn terminal_control_sequences_are_rendered_as_text() {` |
| 863 | inline_test | `fn crlf_input_does_not_leak_carriage_returns() {` |
| 870 | inline_test | `fn prefixed_rendering_keeps_role_and_body_inside_width() {` |
| 882 | inline_test | `fn plain_prefixed_rendering_does_not_interpret_markers() {` |
| 890 | inline_test | `fn sanitization_bound_applies_after_tab_expansion() {` |
| 896 | inline_test | `fn cell_budget_limits_wide_viewport_allocations() {` |
