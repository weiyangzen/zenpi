"""Offline evidence structure and hashes only; no product execution."""
from pathlib import Path
import hashlib,json,re,base64
E=Path(__file__).resolve().parent;root=E.parents[4]
def read(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def bound(p,r):
 b=p.read_bytes();assert len(b)==r['bytes'] and sha(b)==r['sha256'],str(p)
s=(E/'source/status_indicator_widget.rs').read_bytes();assert len(s)==15810 and len(s.splitlines())==440 and sha(s)=='e35e3efbd18784b55343366b2001bda08dfc1543f7e4a88700a715562d519cc5'
rl=read(E/'read-log.json');assert rl['formal_byte_chunks']==[[0,15810]] and rl['sequential_reads'][0]['sha256']==sha(s) and rl['sequential_reads'][0]['lines']==[1,440]
inputs=read(E/'inputs.json');assert inputs['formal_files']==1 and len(inputs['files'])==67
for r in inputs['files']:bound(root/r['snapshot'],r)
cs=read(E/'context-capture.json');assert len(cs)==8 and sum(len(c['excerpts']) for c in cs)==32
assert len(cs[0]['excerpts'])==16 and cs[0]['full_bytes']==579524 and cs[0]['full_sha256']=='d2a98934d4931a5aa202e542acd556bdda5667f0e60df11a68731dacf00eccf1'
report=(root/'Docs/learn/stage1_pi_mono/references/codex/files/codex-rs/tui/src/status_indicator_widget.rs_learn.md').read_text()
assert not re.search(r'^\s*[-*]\s+\[[xX]\]',report,re.M)
funcs=[(i,m[1]) for i,l in enumerate(s.decode().splitlines(),1) if (m:=re.search(r'\bfn (\w+)\(',l))]
inv=read(E/'function-inventory.json');assert len(inv)==27 and [(r['source_line'],r['name']) for r in inv]==funcs
assert all(r['read'] and r['name'] in report for r in inv)
assert sum(r['kind']=='implementation' for r in inv)==17 and sum(r['kind']=='test-only accessor' for r in inv)==3
st=read(E/'source-tests.json');assert len(st)==7 and len(re.findall(r'#\[test\]',s.decode()))==7
lines=s.decode().splitlines()
for t in st:
 a,z=t['source_lines'];body='\n'.join(lines[a-1:z]);assert lines[a-1].strip()==f"fn {t['name']}() {{" and lines[z-1]=='    }'
 assert t['read'] and not t['executed']
 for key,pattern in [('assert_eq',r'\bassert_eq!'),('assert_plain',r'\bassert!'),('snapshot_calls',r'insta::assert_snapshot!')]:assert t[key]==len(re.findall(pattern,body))
assert sum(t['assert_eq']+t['assert_plain'] for t in st)==18 and sum(t['snapshot_calls'] for t in st)==3
snaps=list((E/'source-snapshots').glob('*.snap'));assert len(snaps)==3
for p in snaps:assert p.stem in [t['name'] for t in st] and 'expression: terminal.backend()' in p.read_text()
assert 'esc…' in (E/'source-snapshots/renders_truncated.snap').read_text()
mat=read(E/'capability-matrix.json');assert len(mat)==13 and all(not r['executed_in_309'] and r['source_fact'] in report for r in mat)
ct=read(E/'context-tests.json');assert ct['context_only'] and ct['executed']==0 and len(ct['tests'])==2
cl=(E/ct['snapshot']).read_text().splitlines()
for t in ct['tests']:
 assert cl[t['source_line']-193].strip()==f"fn {t['name']}() {{" and cl[t['source_end']-193]=='}'
 body='\n'.join(cl[t['source_line']-193:t['source_end']-192]);assert len(re.findall(r'\bassert(?:_eq)?!',body))==t['assertions'] and t['name'] in report
for token in ['源测试实际执行0','Approval','saturating_duration_since','32ms','test_dummy','1044.823959','1208.732708','P13','d2a989','complete=false']:assert token in report,token
legacy=E/'history/old-transcript';lm=read(legacy/'manifest.json');ld=read(legacy/'ux125-pty-result.json');lp=read(legacy/'ux125-project-regression.json')
assert lm['blueprint_version']=='3.1.3' and lm['validation']['tests']==87 and lm['validation']['targets']==8
assert ld['binary_sha256']==lp['binary_sha256']==lm['validation']['binary_sha256']=='cf36592e955af48ae52a01f3bdc46e5510d13aee1838340b2e49ad873f912a2f'
assert len(ld['checks'])==11 and all(v is True for v in ld['checks'].values()) and ld['passed'] is True and ld['request_count']==3
assert len(lp['assertions'])==12 and lp['status']=='passed'
assert read(legacy/'ux125-pty-run.log')==ld
counts=[int(n) for n in re.findall(r'test result: ok\. (\d+) passed; 0 failed;', (legacy/'ux125-tests.txt').read_text())];assert counts==[7,15,22,10,4,6,14,9] and sum(counts)==87
helper=next(c for c in cs if c['label']=='historical-helper');record=next(r for r in lm['files'] if r['path']=='tools/tui_transcript_ux_smoke.py');assert helper['full_sha256']==record['candidate_sha256'] and helper['full_bytes']==record['candidate_bytes']
h=E/'history/release';m=read(h/'manifest.json');assert sha((h/'manifest.json').read_bytes())=='4a3e21c0fb5738b18abbda180fea89282c69932cbf7d916aa9aa87bd800ece7f';assert len(m['artifacts'])==126 and m['complete'] is False
selected=[]
for p in h.iterdir():
 if p.name in m['artifacts']:bound(p,m['artifacts'][p.name]);selected.append(p.name)
assert read(h/'master-verification.json')['sha256']==sha((h/'manifest.json').read_bytes())
assert read(h/'build-inputs.json')['src/tui.rs']['sha256']==cs[0]['full_sha256']
binary=read(h/'binary.json');assert binary==dict(sha256='1d7b2e61ecc9096ad0f5e6cd3f3c03c6820cafe8371d9201de3497bb6b4e8f58',bytes=6033168)
summ=[]
for name,count in [('background',4),('approval',14),('bentobox',11),('picker',12),('new',8),('policy',9),('recovery',3)]:
 d=read(h/(name+'.json'));run=read(h/(name+'.run.json'));assert d['binary_sha256']==binary['sha256'] and run['exit_code']==0
 assert d.get('status')=='passed' or d.get('passed') is True
 checks=d.get('checks',d.get('assertions'));assert len(checks)==count
 if name not in ['bentobox','picker']:assert all(v is True for v in checks.values())
 elif name=='bentobox':assert sum(v is True for v in checks.values())==9 and isinstance(checks['plus_to_valid_project'],dict) and isinstance(checks['responsive_resize_preserves_unicode_draft_and_layout'],list)
 else:assert isinstance(checks,list) and all(isinstance(v,str) for v in checks)
 summ.append(dict(name=name,entries=count,run_exit=0,scope='historical only'))
b=read(h/'budget.json');assert len(b['gates'])==8 and all(v is True for v in b['gates'].values()) and b['ok'] is True
assert b['cold_start']['elapsed_ms']['samples']==[751.967292,44.427125,45.611625,45.128208,38.709]
streams=0
for obs in b['cold_start']['observations']:
 assert obs['binary_sha256']==binary['sha256'] and obs['returncode']==0 and obs['timed_out'] is False
 for name in ['stdout','stderr']:
  rec=obs[name];raw=base64.b64decode(rec['prefix_base64'],validate=True);assert not rec['truncated'] and len(raw)==rec['bytes'] and sha(raw)==rec['sha256'];streams+=1
assert streams==10 and read(h/'budget.run.json')['exit_code']==0
print(json.dumps(dict(passed=True,kind='offline evidence structure; semantic G-FILE pending',source_bytes=15810,source_lines=440,source_functions=27,implementation_functions=17,test_accessors=3,source_tests_read=7,source_tests_executed=0,source_assertions=18,source_snapshot_calls=3,referenced_snapshots_read=3,context_tests_read=2,context_tests_executed=0,capability_groups=13,input_snapshots_checked=67,all_context_excerpts=32,target_context_excerpts=18,historical_manifest_members_checked=len(selected),historical_results=summ,legacy_transcript=dict(tests=87,targets=8,pty_checks=11,project_assertions=12,run_exit_unavailable=True,scope='historical only; not worker execution'),raw_stream_hashes_checked=streams,cargo_runs=0,pty_runs=0,http_runs=0),ensure_ascii=False,indent=2))
