from pathlib import Path
import hashlib,json,re,shutil,stat,subprocess,tempfile
R=Path(__file__).resolve().parent;E=R/'evidence';checks=[]
def ok(name,condition):
 assert condition,name
 checks.append(name)
def info(p):
 b=p.read_bytes();return {'bytes':len(b),'lines':len(b.splitlines()),'sha256':hashlib.sha256(b).hexdigest()}
def inv(p):return {str(f.relative_to(p)):info(f) for f in sorted(p.rglob('*')) if f.is_file() and not f.is_symlink()}
m=json.loads((R/'manifest.json').read_text());a=inv(R);a.pop('manifest.json');ok('exact payload inventory',a==m['files']);ok('read only regular files',all(stat.S_ISREG((R/p).lstat().st_mode) and not ((R/p).stat().st_mode & 0o222) for p in a))
cap=json.loads((E/'capture.json').read_text());report=cap['report'];ok('single report owned',set(inv(R/'files'))=={report})
for x in cap['files']:ok('capture '+x['path'],info(E/x['path'])=={k:x[k] for k in ['bytes','lines','sha256']})
subject='capture/codex/codex-rs/tui/src/status_indicator_widget.rs';source=(E/subject).read_bytes();ok('formal frozen identity',len(source)==15810 and hashlib.sha256(source).hexdigest()=='e35e3efbd18784b55343366b2001bda08dfc1543f7e4a88700a715562d519cc5')
ledger=json.loads((E/'read-binding.json').read_text());coverage=[]
for row in ledger:
 p=E/row['source'];b=p.read_bytes();lo,hi=row['lines'];lines=b.splitlines(keepends=True);start=sum(map(len,lines[:lo-1]));end=sum(map(len,lines[:hi]));chunk=(E/row['path']).read_bytes();ok('read '+row['path'],[start,end]==row['byte_range'] and b[start:end]==chunk and len(b)==row['source_bytes'] and hashlib.sha256(b).hexdigest()==row['source_sha256'] and len(chunk)==row['bytes'] and hashlib.sha256(chunk).hexdigest()==row['sha256'])
 if row['source']==subject:coverage.append([start,end])
ok('three complete ordered source reads',len(coverage)==3 and coverage[0][0]==0 and coverage[-1][1]==15810 and all(coverage[i][1]==coverage[i+1][0] for i in range(2)))
units=json.loads((E/'source-units.json').read_text());cursor=0
for u in units:
 start,end=u['byte_range'];ok('unit '+u['name'],start==cursor and hashlib.sha256(source[start:end]).hexdigest()==u['sha256'] and end-start==u['bytes']);cursor=end
ok('30 complete semantic units',len(units)==30 and cursor==len(source))
functions=json.loads((E/'function-inventory.json').read_text());found=[]
for i,line in enumerate(source.decode().splitlines(),1):
 match=re.match(r'\s*(?:pub(?:\([^)]*\))?\s+)?fn\s+(\w+)\s*\(',line)
 if match:found.append((match.group(1),i))
ok('27 functions exact',found==[(x['name'],x['lines'][0]) for x in functions] and len(found)==27)
tests=json.loads((E/'source-tests.json').read_text());ok('7 source tests unexecuted',len(tests)==7 and all(not t['executed'] for t in tests));ok('test identity',[(x['name'],x['lines'][0]) for x in functions if x['kind']=='source-test']==[(x['name'],x['lines'][0]) for x in tests]);ok('14 operation mappings',len(json.loads((E/'capability-matrix.json').read_text()))==14)
for x in json.loads((E/'external-preservation-before.json').read_text()):ok('historical full copy '+x['path'],inv(E/x['path'])==x['files'])
h=json.loads((E/'history-comparison.json').read_text());ok('old subject equals new subject',h['formal_source_equal'] and source==(E/'history/zs1-309-ready/Docs/quality/stage1/ZS1-309/worker-status-indicator-review-3.1.20/source/status_indicator_widget.rs').read_bytes())
bind=json.loads((E/'report-binding.json').read_text());ok('report identity',info(R/'files'/report)=={k:bind[k] for k in ['bytes','lines','sha256']})
with tempfile.TemporaryDirectory(prefix='zs1-309-report-') as tmp:
 root=Path(tmp);sentinel=root/'sentinel.txt';sentinel.write_bytes(b'untouched\n')
 for patch in ['candidate.patch','rollback.patch']:
  r=subprocess.run(['git','apply','--no-index','--check',str(R/patch)],cwd=root,capture_output=True);ok(patch+' check',r.returncode==0)
  r=subprocess.run(['git','apply','--no-index',str(R/patch)],cwd=root,capture_output=True);ok(patch+' apply',r.returncode==0)
  ok(patch+' result',(root/report).read_bytes()==(R/'files'/report).read_bytes() if patch=='candidate.patch' else not (root/report).exists());ok(patch+' sentinel',sentinel.read_bytes()==b'untouched\n')
ok('historical preservation audit',json.loads((E/'preservation-after.json').read_text())['issues']==[])
print(json.dumps({'checks':len(checks),'failed':0,'checks_passed':checks},ensure_ascii=False,indent=2))
