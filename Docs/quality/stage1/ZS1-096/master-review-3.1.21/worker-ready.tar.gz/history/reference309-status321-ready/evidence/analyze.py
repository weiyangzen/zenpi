# -*- coding: utf-8 -*-
from pathlib import Path
import hashlib,json,re
W=Path(__file__).resolve().parent
S=W/'capture/codex/codex-rs/tui/src/status_indicator_widget.rs';b=S.read_bytes();lines=b.splitlines(keepends=True)
def info(p):
 x=p.read_bytes();return {'bytes':len(x),'lines':len(x.splitlines()),'sha256':hashlib.sha256(x).hexdigest()}
def dump(name,x):(W/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
units=[(1,33,'模块与依赖','显示组件无任务/project身份；imports连接外部动画、事件、换行和帧请求。'),
(34,59,'类型与常量','默认详情3行；CapitalizeFirst/Preserve；持有显示字段、运行累计与暂停bool、两个发送句柄和动画开关。'),
(60,76,'fmt_elapsed_compact','秒→分钟→小时；无24小时回绕；纯u64格式化不计时。'),
(77,98,'new','Working、空details/inline、hint开启、计时起点now、未暂停；构造不调frame。'),
(99,102,'interrupt','仅发送Op::Interrupt，不看hint/暂停/焦点，不提供ack。'),
(103,107,'update_header','原样替换String，不trim/比较/重绘。'),
(108,126,'update_details','max至少1；原串非空才trim_start并按策略转首字符；空白串可能Some空串。'),
(127,137,'update_inline_message','先trim再判空；不折叠内部换行。'),
(138,142,'header','仅cfg(test)借用访问器。'),
(143,147,'details','仅cfg(test)访问器。'),
(148,151,'set_interrupt_hint_visible','仅改bool，不关闭动作或请求重绘。'),
(152,156,'interrupt_hint_visible','仅cfg(test)访问器。'),
(157,160,'pause_timer','now委托_at。'),
(161,164,'resume_timer','now委托_at。'),
(165,172,'pause_timer_at','重复pause无变化，否则累加饱和delta并置paused；不调frame。'),
(173,181,'resume_timer_at','仅paused→running更新起点并请求一次frame；无嵌套计数。'),
(182,189,'elapsed_duration_at','暂停时累计，运行时加当前段；Duration普通加法。'),
(190,193,'elapsed_seconds_at','as_secs向下取整。'),
(194,197,'elapsed_seconds','now读取实时运行秒数。'),
(198,230,'wrapped_details_lines','空/width0返回；全量word_wrap_lines后按max截断，再修改末span按chars取数附省略号；不是字节/内存上界。'),
(231,235,'desired_height','1+转换成u16的详情行数，转换失败按0；width0仍1；极大行数与+1边界不验证。'),
(236,290,'render','空area返回；动画开则每次请求32ms即便paused；拼接header/elapsed/hint/inline后列宽截断；详情受配置行数和area剩余行双重限制。'),
(291,304,'测试模块依赖','TestBackend和dummy requester不是实际终端或帧调度证明。'),
(305,317,'fmt_elapsed_compact_formats_seconds_minutes_hours','10个格式边界断言。'),
(318,331,'renders_with_working_header','80x2默认状态snapshot。'),
(332,345,'renders_truncated','20x2 snapshot显示中断说明被截断。'),
(346,370,'renders_wrapped_details_panama_two_lines','30x3；无动画/hint；直接冻结私有计时字段；两行ASCII详情。'),
(371,392,'timer_pauses_when_requested','受控Instant5→暂停仍5→恢复8，不是真实等待。'),
(393,412,'details_overflow_adds_ellipsis','width6/max3，行数及固定末span省略号。'),
(413,440,'details_args_can_disable_capitalization_and_limit_lines','Preserve/max1/width24，原命令大小写和一行省略号。')]
rows=[];next_line=1
for lo,hi,name,meaning in units:
 assert lo==next_line;start=sum(map(len,lines[:lo-1]));end=sum(map(len,lines[:hi]));chunk=b[start:end];rows.append({'name':name,'lines':[lo,hi],'byte_range':[start,end],'bytes':len(chunk),'sha256':hashlib.sha256(chunk).hexdigest(),'meaning':meaning});next_line=hi+1
assert next_line==441;dump('source-units.json',rows)
ends=[76,98,102,107,126,137,142,147,151,156,160,164,172,181,189,193,197,229,235,289,317,331,345,370,392,412,439]
func=[]
for i,line in enumerate(b.decode().splitlines(),1):
 m=re.match(r'\s*(?:pub(?:\([^)]*\))?\s+)?fn\s+(\w+)\s*\(',line)
 if m:func.append({'name':m.group(1),'lines':[i,ends[len(func)]],'kind':'source-test' if i>=306 else ('test-accessor' if i in [140,145,154] else 'production')})
assert len(func)==27;dump('function-inventory.json',func)
tests=[('fmt_elapsed_compact_formats_seconds_minutes_hours',306,317,'10 assert_eq；0/1/59/60/61/185/3599/3600/3661/90123','无Instant、极值或实际时钟'),
('renders_with_working_header',320,331,'80×2，animations=true，1 snapshot','dummy frame，无真实终端/帧率/inline'),
('renders_truncated',334,345,'20×2，1 snapshot，esc…','不保证窄屏完整提示'),
('renders_wrapped_details_panama_two_lines',348,370,'30×3，1 snapshot，关动画/hint，直接改paused/elapsed','未实际调用暂停，ASCII'),
('timer_pauses_when_requested',373,392,'3 assert_eq，注入5→5→8秒','无重复/嵌套/逆序/真实调度'),
('details_overflow_adds_ellipsis',395,412,'2断言，width6/max3/末span…','无Unicode整行列宽断言'),
('details_args_can_disable_capitalization_and_limit_lines',415,439,'3断言，Preserve/max1/width24','无max0/空白/超大行数')]
dump('source-tests.json',[{'name':n,'lines':[lo,hi],'evidence':e,'limits':l,'executed':False} for n,lo,hi,e,l in tests])
h=W/'history/zs1-309-ready/Docs/quality/stage1/ZS1-309/worker-status-indicator-review-3.1.20';history={'formal_source_equal':(h/'source/status_indicator_widget.rs').read_bytes()==b,'source':info(h/'source/status_indicator_widget.rs'),'old_report':info(W/'history/zs1-309-ready/Docs/learn/stage1_pi_mono/references/codex/files/codex-rs/tui/src/status_indicator_widget.rs_learn.md'),'original_report':info(h/'history/original-worker-report.md'),'old_manifest':info(W/'history/zs1-309-ready/manifest.json'),'old_read_log':info(h/'read-log.json'),'context_comparison':[]}
mapping={'codex-bottom-pane':'capture/codex/codex-rs/tui/src/bottom_pane/mod.rs','codex-chatwidget':'capture/codex/codex-rs/tui/src/chatwidget.rs','codex-frame-requester':'capture/codex/codex-rs/tui/src/tui/frame_requester.rs','codex-shimmer':'capture/codex/codex-rs/tui/src/shimmer.rs','codex-spinner':'capture/codex/codex-rs/tui/src/exec_cell/render.rs','target-tui':'capture/zenpi/src/tui.rs','target-tests':'capture/zenpi/tests/tui_transcript_ux.rs'}
for p in sorted((h/'context').glob('*.txt')):
 prefix=p.name.split('.L')[0]
 if prefix not in mapping:continue
 raw=p.read_bytes();target=W/mapping[prefix];at=target.read_bytes().find(raw);history['context_comparison'].append({'old_path':str(p.relative_to(W)),**info(p),'new_capture':mapping[prefix],'byte_identical_substring_offset':at if at>=0 else None,'interpretation':'Identity comparison only; actual new reads are ledger-bound.'})
dump('history-comparison.json',history)
issues=json.loads((W/'preparation-issues.json').read_text());issues.extend([{'operation':'read app_event_sender 1–95','result':'Bounds assert rejected: actual28lines; read1–28 subsequently. No source mutation.'},{'operation':'batched authority display output truncation','result':'Full source subject read unaffected; exact G-FILE139 and item425 independently reread. Authority other item rows not claimed complete.'}]);dump('preparation-issues.json',issues)
print(json.dumps({'units':len(rows),'functions':len(func),'tests':len(tests),'reads':len(json.loads((W/'read-binding.json').read_text())),'old_context_rows':len(history['context_comparison']),'exact_old_context':sum(x['byte_identical_substring_offset'] is not None for x in history['context_comparison']),'history_identity':{k:v for k,v in history.items() if k!='context_comparison'}},indent=2))
