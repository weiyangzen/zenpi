# -*- coding: utf-8 -*-
from pathlib import Path
import datetime,difflib,hashlib,json,shutil
W=Path(__file__).resolve().parent;R=W.with_name(W.name+'-ready');assert not R.exists()
def info(p):
 b=p.read_bytes();return {'bytes':len(b),'lines':len(b.splitlines()),'sha256':hashlib.sha256(b).hexdigest()}
def inv(p):return {str(f.relative_to(p)):info(f) for f in sorted(p.rglob('*')) if f.is_file() and not f.is_symlink()}
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
cap=json.loads((W/'capture.json').read_text());old=json.loads((W/'preservation-before.json').read_text());issues=[]
for path,expected in old['ready'].items():
 if inv(Path(path))!=expected:issues.append({'ready':path})
for path,expected in old['tracked'].items():
 if not Path(path).is_file() or info(Path(path))!=expected:issues.append({'tracked':path})
for x in json.loads((W/'external-preservation-before.json').read_text()):
 if inv(Path(x['origin']))!=x['files'] or inv(W/x['path'])!=x['files']:issues.append({'external':x['origin']})
assert not issues,issues
dump(W/'preservation-after.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'old_ready':len(old['ready']),'old_regular':sum(len(x) for x in old['ready'].values()),'tracked':len(old['tracked']),'external_regular':105,'issues':issues})
state=[]
for x in cap['files']:
 p=Path(x['origin']);now=info(p) if p.is_file() else None;before={k:x[k] for k in ['bytes','lines','sha256']};r={'path':x['path'],'origin':x['origin'],'captured':before,'now':now,'changed':before!=now}
 if r['changed'] and p.is_file():
  dst=W/'freeze-capture'/x['path'];dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst);r['new_copy']=str(dst.relative_to(W))
 state.append(r)
main_report=Path('/Users/wangweiyang/GitHub/zenpi')/cap['report'];assert not main_report.exists(),'main report appeared; avoid duplicate new patch'
reads=json.loads((W/'read-binding.json').read_text());target=[];current=Path('/Users/wangweiyang/GitHub/zenpi/src/tui.rs').read_bytes()
for row in reads:
 if row['source']=='capture/zenpi/src/tui.rs':
  raw=(W/row['path']).read_bytes();at=current.find(raw);target.append({'read':row['path'],'capture_lines':row['lines'],'exact_current_byte_offset':at if at>=0 else None})
dump(W/'freeze-input-state.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inputs':state,'target_read_identity':target,'main_report_absent':True,'meaning':'Changed captures remain immutable; final copies are drift evidence, not additional complete reading.'})
report=W/'candidate'/cap['report'];tui=next(x for x in state if x['path']=='capture/zenpi/src/tui.rs');changes=[x for x in state if x['changed']]
text=report.read_text();text+='\n## 冻结时主库漂移核对\n\n'
text+=f"29份捕获输入中{len(changes)}份发生变化；完整身份见[freeze-input-state]({R}/evidence/freeze-input-state.json)。原捕获、旧ready及全部失败均未重写。主控已通知122修复合入；实际main TUI现为 {tui['now']['bytes']} B / {tui['now']['lines']}行 / `{tui['now']['sha256']}`，本报告行号仍绑定旧捕获638305 B/15607行。{len(target)}段已读目标TUI中{sum(x['exact_current_byte_offset'] is not None for x in target)}段在冻结时main精确找到同字节；这是片段身份复用，不是重新运行测试或完整阅读新TUI。\n\n"
for x in changes:text+=f"- `{x['path']}`：`{x['captured']['sha256']}` → `{x['now']['sha256'] if x['now'] else 'absent'}`。\n"
text+=f"\n冻结前{len(old['ready'])}个既有ready/{sum(len(x) for x in old['ready'].values())}个regular、145个tracked及105个外部历史文件全部原身份保留。唯一标准报告在main仍absent，新增补丁基底未变。\n"
report.write_text(text);bind=json.loads((W/'report-binding.json').read_text());bind.update(info(report));dump(W/'report-binding.json',bind)
body=report.read_text().splitlines(True);patch=''.join(difflib.unified_diff([],body,fromfile='/dev/null',tofile='b/'+cap['report']));rollback=''.join(difflib.unified_diff(body,[],fromfile='a/'+cap['report'],tofile='/dev/null'));(W/'candidate.patch').write_text(patch);(W/'rollback.patch').write_text(rollback)
R.mkdir();shutil.copytree(W/'candidate',R/'files');(R/'evidence').mkdir()
for name in ['capture','history','reads','freeze-capture']:
 if (W/name).exists():shutil.copytree(W/name,R/'evidence'/name)
for name in ['capture.json','read-binding.json','source-units.json','function-inventory.json','source-tests.json','capability-matrix.json','history-comparison.json','report-binding.json','preservation-before.json','preservation-after.json','external-preservation-before.json','freeze-input-state.json','preparation-issues.json','capture.py','capture_resume.py','capture_resume2.py','read.py','analyze-initial.py','analyze.py','report.py','freeze.py','run_frozen_verify.py']:
 shutil.copyfile(W/name,R/'evidence'/name)
for name in ['candidate.patch','rollback.patch','verify.py']:shutil.copyfile(W/name,R/name)
payload=inv(R);dump(R/'manifest.json',{'item':'ZS1-309','version':'3.1.21','report':cap['report'],'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':payload})
for p in R.rglob('*'):
 if p.is_file():p.chmod(0o444)
for p in sorted([p for p in R.rglob('*') if p.is_dir()],key=lambda p:len(p.parts),reverse=True):p.chmod(0o555)
R.chmod(0o555)
print(json.dumps({'ready':str(R),'payload':len(payload),'manifest':info(R/'manifest.json'),'report':info(R/'files'/cap['report']),'patch':info(R/'candidate.patch'),'rollback':info(R/'rollback.patch'),'drift_paths':[x['path'] for x in changes],'target_reads':len(target),'target_reads_same':sum(x['exact_current_byte_offset'] is not None for x in target)},indent=2))
