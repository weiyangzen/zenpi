# ZS1-309 independent offline candidate

Formal source: codex-rs/tui/src/status_indicator_widget.rs, 15810B, 440 lines, SHA256 e35e3efbd18784b55343366b2001bda08dfc1543f7e4a88700a715562d519cc5.
Only standard report: Docs/learn/stage1_pi_mono/references/codex/files/codex-rs/tui/src/status_indicator_widget.rs_learn.md.

Offline verification from any directory:

    python3 <ready>/Docs/quality/stage1/ZS1-309/worker-status-indicator-review-3.1.20/verify_package.py

Verifies all ready manifest members, 67 inputs, 32 context excerpts, 27 source function definitions, 7 source tests and 3 referenced snapshots, historical evidence hashes/formats, and both report patches in isolated temporary Git repositories. Source tests read/executed 7/0; context tests 2/0. All 13 proposed product experiments are unexecuted. No Cargo, PTY, HTTP or product execution.

master.patch adds this report to the individually checked absent master path. worker.patch updates the exact original worker report preserved under history. Recheck receiving baseline; do not force over a later different file. Roll back only this report patch. No global reset/clean, no master/product/blueprint/index writes.

Current TUI d2a98934 is a frozen snapshot. Headless is outside this review and was not read; its ongoing cross-project/new fix must be verified by its owner. Historical cf36592e transcript and 1d7b2e61 release results are not new runs or complete item acceptance. Old cold-start failures remain unresolved. Candidate awaits master semantic G-FILE; stop at 309.
