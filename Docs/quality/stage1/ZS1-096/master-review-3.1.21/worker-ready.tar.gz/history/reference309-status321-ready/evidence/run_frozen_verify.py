from pathlib import Path
import datetime,hashlib,json,os,subprocess
W=Path(__file__).resolve().parent;R=W.with_name(W.name+'-ready');log=W/'frozen-verification.log';receipt=W/'frozen-verification.json';assert not log.exists() and not receipt.exists();argv=['python3','-B',str(R/'verify.py')];env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1';start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with log.open('wb') as f:r=subprocess.run(argv,cwd=W,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=60)
b=log.read_bytes();x={'argv':argv,'cwd':str(W),'started_at':start,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':r.returncode,'log':{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()},'scope':'Only new frozen verifier, once, offline/read-only; temporary patch application only.'};receipt.write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x,indent=2));print(b.decode()[:450]);raise SystemExit(r.returncode)
