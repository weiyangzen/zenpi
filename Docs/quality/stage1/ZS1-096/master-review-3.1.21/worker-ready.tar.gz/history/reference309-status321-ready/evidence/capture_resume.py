from pathlib import Path
import datetime,hashlib,json,os,shutil,stat,subprocess
W=Path(__file__).resolve().parent;ROOT=W.parent.parent;M=Path('/Users/wangweiyang/GitHub/zenpi');C=Path('/Users/wangweiyang/GitHub/codex');REPORT='Docs/learn/stage1_pi_mono/references/codex/files/codex-rs/tui/src/status_indicator_widget.rs_learn.md'
def info(p):
 assert stat.S_ISREG(p.lstat().st_mode),str(p)
 b=p.read_bytes();return {'bytes':len(b),'lines':len(b.splitlines()),'sha256':hashlib.sha256(b).hexdigest()}
def inv(p):
 return {str(f.relative_to(p)):info(f) for f in sorted(p.rglob('*')) if f.is_file() and not f.is_symlink()}
def dump(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
before=json.loads((W/'preservation-before.json').read_text());roots=list(before['ready']);tracked=before['tracked']
selected={'codex':['AGENTS.md']+['codex-rs/tui/src/'+p for p in ['status_indicator_widget.rs','bottom_pane/mod.rs','chatwidget.rs','tui/frame_requester.rs','app_event_sender.rs','exec_cell/mod.rs','shimmer.rs','text_formatting.rs','wrapping.rs','line_truncation.rs','key_hint.rs','tui.rs']], 'zenpi':['src/tui.rs','src/render.rs','src/view_model.rs','tests/tui_transcript_ux.rs','tests/tui_approval_focus.rs','tests/tui_bentobox.rs','Docs/stage_1_v3_pi_mono_blueprint.md','Docs/execution/active_requirement.json','Docs/learn/stage1_pi_mono/references/codex/source_manifest.tsv','Docs/learn/stage1_pi_mono/references/codex/file_learn_index.tsv',REPORT]}
selected['codex']+= [str(p.relative_to(C)) for p in sorted((C/'codex-rs/tui/src/snapshots').glob('*status_indicator_widget*'))]
files=[]
for tag,paths in selected.items():
 for rel in paths:
  src={'codex':C,'zenpi':M}[tag]/rel;dst=W/'capture'/tag/rel;dst.parent.mkdir(parents=True,exist_ok=True);
  if not dst.exists():shutil.copyfile(src,dst)
  assert info(src)==info(dst); files.append({'path':str(dst.relative_to(W)),'origin':str(src),'role':'subject-full' if rel.endswith('/status_indicator_widget.rs') else 'context-only',**info(dst)})
external=[]
for name in ['zs1-309-ready','codex-reference-ready']:
 src=Path('/Users/wangweiyang/.codex/worktrees/2267/zenpi/.ops')/name;dst=W/'history'/name;shutil.copytree(src,dst);x=inv(src);assert inv(dst)==x;external.append({'origin':str(src),'path':str(dst.relative_to(W)),'files':x})
dump(W/'external-preservation-before.json',external)
subject=next(x for x in files if x['role']=='subject-full');assert subject['bytes']==15810 and subject['sha256']=='e35e3efbd18784b55343366b2001bda08dfc1543f7e4a88700a715562d519cc5'
dump(W/'capture.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'item':'ZS1-309','version':'3.1.21','report':REPORT,'codex_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=C,text=True).strip(),'files':files,'old_ready':len(roots),'old_ready_regular':sum(map(len,before['ready'].values())),'tracked':len(tracked),'read_claim':'Whole-file captures are hash inputs, not complete-read claims for context files. Main is captured independently; stage122 candidate is not the target baseline.'})
dump(W/'preparation-issues.json',[{'operation':'Initial locator tried prior308 prepare.py and review.md','result':'Those paths absent; used actual capture.py and canonical report. First new capture halted at nonexistent exec_cell.rs, resumed without overwriting prior capture or preservation using actual exec_cell/mod.rs. No old script execution.'}]);print(json.dumps({'captures':len(files),'source':subject,'old_ready':len(roots),'old_regular':sum(map(len,before['ready'].values())),'tracked':len(tracked),'historical_files':[len(x['files']) for x in external]},indent=2))
