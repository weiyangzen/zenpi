from pathlib import Path
import hashlib,json,sys
W=Path(__file__).resolve().parent;p=W/sys.argv[1];lo,hi=map(int,sys.argv[2:4]);b=p.read_bytes();lines=b.splitlines(keepends=True);assert 1<=lo<=hi<=len(lines);start=sum(map(len,lines[:lo-1]));end=sum(map(len,lines[:hi]));chunk=b[start:end];assert len(chunk)<=256*1024
index=W/'read-binding.json';rows=json.loads(index.read_text()) if index.exists() else [];(W/'reads').mkdir(exist_ok=True);out=W/'reads'/('%03d.txt'%(len(rows)+1));assert not out.exists();out.write_bytes(chunk);rows.append({'source':str(p.relative_to(W)),'source_bytes':len(b),'source_sha256':hashlib.sha256(b).hexdigest(),'lines':[lo,hi],'byte_range':[start,end],'path':str(out.relative_to(W)),'bytes':len(chunk),'sha256':hashlib.sha256(chunk).hexdigest()});index.write_text(json.dumps(rows,indent=2)+'\n')
for n,line in enumerate(chunk.decode().splitlines(),lo):print('%d: %s'%(n,line))
