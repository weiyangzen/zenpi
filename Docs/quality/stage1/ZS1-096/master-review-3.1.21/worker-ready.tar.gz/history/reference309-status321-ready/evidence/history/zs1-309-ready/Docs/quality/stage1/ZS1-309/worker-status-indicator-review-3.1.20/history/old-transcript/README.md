# ZS1-125 worker candidate

Status: [_] master acceptance pending. Source snapshot frozen; no more writes after handoff.

Apply scoped.patch against frozen121 tui SHA e33a3b2d978ea5dacaa2b40e9e9dca5242fbe766ea18f110b0ea22f421a6e5bf. Only src/tui.rs, new tests/tui_transcript_ux.rs and new tools/tui_transcript_ux_smoke.py change. src/render.rs is unchanged. Owner imports are listed in ../ux125-imports/manifest.json; do not copy this worker's old core/config/session over C's owner snapshot. The smoke imports frozen121 tools/tui_project_workspace_smoke.py and existing tools/tui_user_shell_smoke.py.

87 tests in8 targets pass. Both release PTYs pass with the same binary hash in manifest.json. Run the smoke with --binary target/release/zenpi; preserve HOME. It isolates config/auth through ZENPI_HOME with a fake fixture credential and binds its HTTP server only to loopback.

Alt-R reasoning, Alt-C answer copy, Alt-B block inspector; PgUp/PgDn read, Enter copy, Esc close, Ctrl-C interrupt. Clipboard sends bounded OSC52 (64KiB); OS acceptance depends on terminal support. Error inspection shows the complete owner-provided normalized text. The header labels history as estimated and shows the last actual model when it differs from the selected model.

Reports: Docs/quality/stage1/ux-reference.md; Docs/learn/stage1_pi_mono/targets/zenpi/files/src/tui.rs_learn.md, src/render.rs_learn.md, tests/tui_transcript_ux.rs_learn.md and tools/tui_transcript_ux_smoke.py_learn.md. Supporting tests are outside the frozen56-source acceptance inventory.
