# ZS1-309 — codex-rs/tui/src/status_indicator_widget.rs 逐文件复核

状态：worker candidate；master语义G-FILE待独立接收。本轮只拥有这一份标准报告及独立证据，不修改产品、蓝图、目录索引或完成标记。

## 冻结身份和连续阅读

先核对冻结蓝图3.1.20第399、412行，ZS1-309确切路径是`codex-rs/tui/src/status_indicator_widget.rs`，15810B，SHA256 `e35e3efbd18784b55343366b2001bda08dfc1543f7e4a88700a715562d519cc5`，不是凭任务名称猜测文件。蓝图requirement digest `8d525b351d066ce9b0487a485337647d47233275782e4f4d154423a623fe1645`；Codex HEAD `b3b3d262787f4902a7449f17d793241a34d311ad`。

正式阅读为完整440行、连续字节[0,15810)，一次cat全文后又按1–440行顺序编号复读，包含全部7个内联测试，没有按功能区抽样或跳过测试。该文件低于256KiB，一块hash即全文件hash。共27个函数定义：17个生产实现、3个cfg(test)访问器、7个测试。源测试阅读7、源测试实际执行0；18个普通断言调用（assert_eq/ assert）及3个insta外部snapshot调用。3份被当前测试引用的snapshot已完整读取、原样封存；没有运行快照更新。目录内另有queued_messages旧snapshot文件，当前正式源没有对应测试引用，未把它们计为309测试或阅读证明。

必要上下文32片段来自8文件：目标TUI16段、目标测试2段、Codex调用和动画/调度helper13段、旧历史smoke1段。目标测试上下文完整读2测试、4断言及3helper，执行0；这些只是上下文，不算正式源阅读数。inputs.json冻结67输入，每份有原绝对路径、快照路径、bytes/hash；context-capture.json记录各源全文件身份与本次片段捕获时间。主库始终只读；未读取正在改动的headless文件，也不把TUI片段当作headless跨项目/new队列owner完整证据。

ZS1-353依赖306/307/308/309与354的独立完成；ZS1-125还承担滚动复制、上下文可见、终端恢复真实入口。309只说明status widget及其映射，不代验目录或125。旧worker报告原件、原ready manifest和全部既有ready保留。

## 类型、初始化和全部方法

L34–59：默认details最多3行，前缀`  └ `按终端列宽计算。StatusDetailsCapitalization有CapitalizeFirst与Preserve；widget持有header/details/max_lines/inline_message/show_interrupt_hint、elapsed_running/last_resume_at/is_paused、AppEventSender/FrameRequester和animations_enabled。它存显示状态及运行段计时，不存任务ID、project/session、取消ack、provider用量或持久化时间戳。

L63–76 `fmt_elapsed_compact(u64)`是纯格式化：<60用Ns，<3600用Nm SSs，否则Nh MMm SSs。25小时仍显示25h，没有日期单位或24小时回绕。秒来自Duration.as_secs取整，亚秒不会四舍五入。该方法不读时钟，不决定暂停，不是墙上时钟或成本计费。

L79–98 `new`默认Working、details/inline为None、max3、hint=true、elapsed零、last_resume_at=Instant::now、paused=false，保存动画开关及发送器。构造本身没有调度重绘；header/details字段没有长度上限。widget重建获得新的计时起点，不能当成跨重启连续耗时。

L100–102 `interrupt`只发送`AppEvent::CodexOp(Op::Interrupt)`，不检查hint、paused、running、焦点或任务身份，不改变header或timer，也不等返回结果。没有“成功取消”的本地状态。按键是否能触达该函数及Op对应哪个实际owner由外部决定，调用这一方法不能充当provider已停止证据。

L105–107 `update_header`原样替换String，不trim、不资本化、不比较是否相等、不请求redraw。空header仍可渲染spinner和elapsed，嵌入换行或任意输入并未在该函数清理。

L110–126 `update_details`先把max_lines钳至至少1；再对原始字符串排除空串，然后trim_start，再选择capitalize_first或Preserve。状态字段归一化差异需保留：全空白的非空原串会变为Some(空字符串)，并非None；Preserve保留大小写但不保留前导空白，末尾空白不在此trim。None/原始空串清除details，max_lines仍更新。capitalize_first为外部函数，本轮未将其完整Unicode处理纳入309所有权。

L133–137 `update_inline_message`先trim两端、再排除空串，故None/空白都成为None；内部换行不在此删除。它不是进程登记或进程数量计算，调用者要提供已带上下文的简短plain text。L140–146 `header`、`details`及L154–156 `interrupt_hint_visible`是仅测试访问器，不是生产外部查询API。

L149–151 `set_interrupt_hint_visible`只写bool，不触发重绘，不撤销interrupt函数，也不屏蔽Esc。显示和动作是两条契约。

L158–164 `pause_timer`、`resume_timer`只是以Instant::now调用对应_at方法。L166–172 `pause_timer_at`若已paused立即返回，否则累加now.saturating_duration_since(last_resume_at)，再置paused=true。它不改变last_resume_at、header、hint、动画开关，不调度frame。L174–181 `resume_timer_at`仅当原先paused时更新last_resume_at=now并置false，随后schedule_frame一次；已经running则不改时间也不调度。重复调用在同一状态幂等，但这是一个bool，没有嵌套暂停计数或“是谁暂停”的owner标签。

L183–197 `elapsed_duration_at`从累计Duration开始，仅running时添加当前运行段；`elapsed_seconds_at`调用as_secs；`elapsed_seconds`读Instant::now。暂停恢复只累计运行段。saturating_duration_since让早于基线的now贡献0，但不会验证测试传入Instant顺序正确，也不使所有时间序列自动满足单调性。累计用Duration普通加法，未设置持久化、最大运行时限或重启恢复协议。

L200–229 `wrapped_details_lines`：无details或width0返回空Vec。以UnicodeWidthStr算prefix宽，RtOptions设置首行`  └ `、续行相同列数空格，break_words=true；将details.lines逐行dim后全量word_wrap_lines。结果超过details_max_lines才truncate，并对最后一行的最后一个span取chars().take(max_base_len)再附`…`。content_width是width-prefix_width饱和减、至少1，max_base_len再减1。

这里显示行数不是资源上限：先wrap全部输入再截行，没有按max_lines短路，也无details字节上限；desired_height和render可分别再wrap一次。省略号代码只处理最后span，用Unicode scalar数量而非显示列宽或grapheme簇；它也不减去最后行其它内容span的总宽。不能从前缀使用UnicodeWidthStr就宣称整个截断对中日韩宽字符、emoji/组合字符安全。窄于4列前缀、最后span为空、长单词、多行与多span都需最小实验；本轮没有执行并因此不将潜在越界或视觉残缺宣称为已复现。

L233–235 `desired_height`为1+wrapped_details.len转u16，转换失败unwrap_or(0)。width0仍返回1，而render空area不绘制；max_lines只有下限没有上限，极大行数触发转换fallback，恰u16::MAX行时后续+1也有整数边界。默认3行避免常用路径触及这些巨大输入，但不是类型层面的资源保证。

L237–289 `render`先拒绝空area。非空且animations_enabled时请求32ms后的frame，不看is_paused；随后取now计算elapsed并格式化。顺序为spinner、空格、shimmer header或普通header、空格、elapsed和可选esc to interrupt、可选` · inline_message`；主行统一truncate_line_with_ellipsis_if_overflow。hint=false仍显示elapsed括号。inline放在hint之后只保留优先顺序，不能保证窄屏或超长header时完整保留hint。

area.height>1才取wrapped details，最多取height-1行，再Paragraph渲染。配置max_lines截断时会加省略号；area高度不足的第二次take不会再补一个“还有内容”指示。所以本文件不是严格单行高度：header一行加0至max_lines详情，默认最多4行；文件开头“one line”说的是spinner/header/inline组合，并不否定wrapped details。

## 时间、动画与实际frame调度

| 状态 | elapsed读取 | 本widget触发的frame | 动画事实 |
| --- | --- | --- | --- |
| running、动画开、非空area | 累计+now-last_resume_at | 每次render请求32ms后 | spinner/header可动画 |
| paused、动画开、非空area | 固定累计值 | 仍请求32ms后 | 暂停计时并不关闭动画 |
| running、动画关、非空area | 外部再次draw时继续增长 | render不发周期请求 | spinner静态，header普通span |
| paused、动画关 | 固定累计值 | render无周期请求；真实resume请求立即frame | 无本widget周期驱动 |
| 空area | 不进入本次elapsed/render流程 | 不调度 | 返回 |

必要helper片段`exec_cell/render.rs` L182–196：动画关返回dim的•；开时真彩色走shimmer_spans，非真彩色依据传入last_resume_at的elapsed每600ms交替•/◦。`shimmer.rs` L14–38按进程级OnceLock Instant的2秒周期扫过header。因而计时暂停与动画分离，resume更新last_resume_at可重置非真彩色spinner相位，但不重置进程级shimmer相位。源码里没有“暂停provider时冻结spinner”的保证。

`FrameRequester` L23–67把当前/未来Instant发送到unbounded channel，忽略send结果；注释说明由FrameScheduler合并。test_dummy丢弃receiver，是no-op调度器。309的32ms是请求延迟，不是实测帧率、30/31fps保证或每32ms真实draw；本轮未读完整scheduler实现、更未测CPU。动画关闭后本widget没有按秒独立tick，计时显示是否持续刷新依赖宿主其它frame来源。

## 必要调用者：状态生命周期、暂停与取消

`bottom_pane/mod.rs` L628–651 `update_status`只在status存在时调用update_header/update_details，然后request_redraw；不存在时不创建。L717–767 `set_task_running`维护独立running与composer状态：从非running进入时若status缺失才new，显示hint并同步inline；running=false隐藏status；`hide_status_indicator`移除widget但刻意不改running；`ensure_status_indicator`缺失才重建并同步、redraw。隐藏后重建会重新计时，不能在widget层保证连续累计。

L838–859统一exec进程列表由外部footer模型管理；变化后把summary_text传给update_inline_message。L1110–1158当active_view存在只渲染view，否则把status放入flex；status不存在且unified_exec_footer非空才显示独立footer，避免重复摘要。渲染隐藏意味着该widget不一定持续请求frame；不能拿render内部代码推出模态期间一定持续动画。

L902–950新建审批或用户输入modal前pause timer；被已有view消费的请求直接redraw返回。L1000–1047的tool suggestion/MCP modal也pause，on_active_view_complete则resume并启用composer。L407–452显示CtrlC完成会pop一个view后调用complete，即使栈中还可能有next_view；widget本身没有暂停引用计数，因此多modal/nested来源需要由调用层验证。这里不把“每个modal都暂停/恢复正确”扩成已完成结论。

同一L407–452的非view分支允许Esc Press或Repeat、running、非/agent命令、无composer popup且status存在时调用interrupt；没有检查show_interrupt_hint，也没限定修饰位。popup优先dismiss。由此取消提示与操作分离：hint隐藏不保证Esc不被路由，反之status不存在也可使该专用分支不适用。

`chatwidget.rs` L2964–2980 undo开始会ensure status、隐藏interrupt hint、设置header，结束hide。L1727–1758与3113–3133从status_widget.elapsed_seconds读取耗时供FinalMessageSeparator，且再经worked_elapsed_from；本轮只读这些调用点，没把分隔符或完整turn完成owner算作已学习。它们说明运行时间不只用于屏幕动画，但仍不能推导原始elapsed与最终用户看到的worked时间完全相同。

## 7个源测试的逐项证据

| 测试及行号 | 实际断言/fixture | 未覆盖边界 |
| --- | --- | --- |
| fmt_elapsed_compact_formats_seconds_minutes_hours L306–317 | 10个assert_eq覆盖0/1/59/60/61/185/3599/3600/3661/90123秒 | 不测Instant、pause、帧或u64极值 |
| renders_with_working_header L320–331 | TestBackend 80×2，animations=true，snapshot一次 | dummy frame、无真实终端/暂停/inline/重绘频率 |
| renders_truncated L334–345 | TestBackend 20×2，snapshot一次 | 仅默认短Working；不是“提示总可见”证明 |
| renders_wrapped_details_panama_two_lines L348–370 | 30×3、关闭动画/hint、手动paused/elapsed=0，snapshot一次 | fixture直接写私有字段，没有实际调用pause/resume；ASCII短文本 |
| timer_pauses_when_requested L373–392 | 3个assert_eq；baseline+5读5、+5pause后+10仍5、+10resume后+13读8 | 注入Instant、不sleep；未测重复调用/嵌套/逆序/实际frame/真实等待 |
| details_overflow_adds_ellipsis L395–412 | width6、默认3行；assert_eq行数3，assert最后spans[1]以…结尾 | ASCII、固定span索引；未断言完整每行显示列宽或高度 |
| details_args_can_disable_capitalization_and_limit_lines L415–439 | Preserve命令、max1、width24；2 assert_eq+1 assert某最后span含… | 不测空白None区别、max0/巨大值、Unicode截断 |

源snapshot原文已阅读：80列可见`• Working (0s • esc to interrupt)`；20列显示`• Working (0s • esc…`，实际中断说明被截掉；30×3显示Working(0s)加`  └ A man a plan a canal`和续行panama。这些是冻结预期文本，不是本轮产生的终端截图，也不编码全部颜色、DIM或frame调度事实。

没有源测试断言interrupt发送的AppEvent、hint false时动作、update_inline_message、空/空白字段、animations×paused矩阵、零area或巨量details。没有据7个测试名字推断这些都通过。所有源测试本轮执行0；结构检查只核验原文本、数量、行段、hash和包，不运行Rust测试或等价行为模型。

## 当前Zenpi逐操作映射

目标TUI仅一次捕获：2026-09-12T11:05:59.255968+00:00，579524B，SHA256 `d2a98934d4931a5aa202e542acd556bdda5667f0e60df11a68731dacf00eccf1`；与封存release build-inputs的src/tui.rs项一致。旧报告声称无elapsed、context/token/model和后台状态已过时，本轮原件保留并在此纠正。主控正在另项修改headless队列terminal项目标记；本轮没有沿用其当前状态或为它提供验收结论。

| 源能力/真实操作 | 当前目标片段与行为 | 差异、风险与最小验证方向 |
| --- | --- | --- |
| 累计运行时间 | L735–782 TranscriptUx保存Duration elapsed及Option<Instant> started；pause take一次started后累加，seconds用elapsed+当前段as_secs | 已实现时间；无注入_at接口；结构与源bool不同，重启持久化需另证 |
| busy起止 | L3198–3232 set_busy仅值变化时处理；true清零并开Instant，false pause；只有原status恰Working才转Ready | 不等价于new/hide widget；连续true不会重置，true/false/new session顺序要绑定实际owner |
| 暂停和恢复 | set_status在字符串变化时，contains("Approval")暂停，否则busy且started None恢复 | 目标Approval字符串门控为大小写敏感substring，没有typed waiting状态；同串不触发。先设Approval再busy true会重启计时，需序列验证 |
| 审批resolve链 | L3605–3642 Required设Approval required；Resolved只push message。L1232–1252响应coordinator后retire/push decision，没显式resume；L3550–3566 ToolStarted设Running… | resume依赖之后status变化，不是resolved自动保证。真实没有ToolStarted或错误/同名status顺序可能不同；仅列待测风险，不宣称实际停表故障 |
| 目标spinner | L3227–3232 busy时wrapping_add tick并dirty；L6055–6155按tick%4显示| / - \，busy Yellow，idle DarkGray | 目标无源shimmer/32ms请求，不能把源样式机械移植；timer暂停未改变busy/tick条件 |
| 帧驱动 | L11568–11600事件循环按poll_interval在busy时tick、scheduler.request，dirty也request；due才draw和rendered | 请求合并仍由目标scheduler负责。此片段不是实测帧率，也不证明所有失败路径都恢复 |
| elapsed和中断可见 | header busy时显示`(Ns · Ctrl-C)`，idle不显示耗时 | 已有取消提示；目标没有m/h compact，不能把长时秒数认作未计时；CtrlC语义保留目标合同 |
| 状态/metadata可见 | header按顺序status、5秒copy_notice、model及不同last model、actual in/out或tokens —、history ~used/budget、后台busy数量、cwd | 当前已存在；长status/窄屏可能挤掉后项。目标header未显式调用源ellipsis helper，Paragraph裁剪不可当完整可见 |
| actual usage来源 | L3490–3506只匹配current streaming_job_id才接受Usage；L3691–3730从snapshot取selected model，idle历史metadata取response/usage | 实际usage与估算分开；history用estimate_tokens并标~，不是provider actual tokens。旧job和新session还需owner范围验证 |
| project状态 | L1915–1960存ux/busy/status到ProjectDraft，L1985–2010恢复 | 同进程保存Instant，切到后台本身没有pause，可能继续累计；不证明跨进程延续，也不处理headless待修queue归属 |
| 取消命令 | L5184–5202 empty+busy CtrlC Interrupt、empty CtrlC/D Quit、非空CtrlC Interrupt；L5478–5497 Esc保留草稿或中断/返回历史 | 使用目标CtrlC/D/Esc contract，不能把源Esc提示直接替换所有路由 |
| 取消状态与恢复 | L12252–12291先尝试new session取消；错误项目提示切回；runner.try_cancel QueueFull时不清审批，但随后也可显示Interrupt requested；L12308–12338 guard.leave在shutdown/join前 | “requested”不是完成ack；queue full及后台owner必须真实入口观察。先restore terminal的代码顺序不代替host失败恢复实验 |

目标上下文测试`actual_usage_is_visible_and_stale_usage_does_not_replace_current_job` L194–222注入job8 usage123/45，再job7 999，TestBackend断言真实数可见且999不出现；`error_details_are_readable_in_scrollable_inspector_and_interrupt_still_works` L224–244用80行错误、20次PgDown后检查079，再busy CtrlC得到TuiAction::Interrupt。两个测试通过helper直接handle_key/apply_view_event_for_job，未走PTY provider或取消ack。这里只读未运行，不能把它们计为源7测试或当前产品新增测试。

这些事实支持后续用明确运行/等待状态驱动时间和提示，但本轮不提出或实施TUI重构。source中的header/details/inline不是答复内容；状态摘要不能代替或混入Reasoning/Assistant持久化。BentoBox现有布局不在本报告修改范围。

## 历史通过、历史失败和本轮检查分账

本轮新产品实验0，Cargo0、PTY0、HTTP0。只读历史原件、离线解析和hash检查；不会重建binary、跑timer、创建HTTP或改主库。

旧`.ops/transcript-ui-ready`属于蓝图3.1.3及其旧digest，binary `cf36592e955af48ae52a01f3bdc46e5510d13aee1838340b2e49ad873f912a2f`，不是当前release。原manifest记录87 tests/8 targets；ux125-tests.txt原文8组7+15+22+10+4+6+14+9通过，0 failed。旧PTY结果11布尔checks true、passed=true、3HTTP；项目回归12条assertions/status passed，同binary。当前309只封存这些结果和README/manifest/log，未重跑。

旧smoke L70–79中interrupt_from_inspector是slow-case出现SLOW_后AltB、CtrlC等待Interrupted并置true；没有计时暂停/恢复区间断言。其helper全hash与旧manifest candidate_sha256绑定。本次没有把旧snapshot源或87测试全部正式阅读；日志也没有逐命令run.json，旧manifest本身不列结果JSON的hash。这里结果文件由309 inputs新封存身份保证不再变化，不能宣称已有完整当时run→结果hash闭环，或者给旧日志补造exit_code。旧预期clipboard还依赖终端接受OSC52，不证明任意系统剪贴板权限都成功。

从已冻结308 ready复用release历史原件，public manifest SHA256 `4a3e21c0fb5738b18abbda180fea89282c69932cbf7d916aa9aa87bd800ece7f`。其126 artifacts、complete=false和master-verification的226 input checks是历史记录；本worker仅核验选入原文件及TUI条目，不声称本轮复核全部产品输入。binary.json记录6033168B、`1d7b2e61ecc9096ad0f5e6cd3f3c03c6820cafe8371d9201de3497bb6b4e8f58`；二进制本体本轮不读取/运行。

该release的7套UX结果各run exit0，background4、approval14、new8、policy9、recovery3为布尔checks；bentobox11条由9布尔+1resize列表+1加号操作对象组成；picker12为assertions字符串。background验证来源badge/footer、当前草稿布局不变，切回AltA/y/Enter后只来源cwd写入，结束提示消失；approval full_diff只80行/stale once有限；bentobox三步加号依赖单直接子目录；/new三套20组的强杀/CAS/授权scope仍不能泛化为完整所有时序。它们未断言本报告timer真暂停/真恢复或动画功耗。

历史budget记录8 gates=true、ok=true，5次冷启动751.967292/44.427125/45.611625/45.128208/38.709ms，max751.967292ms；峰RSS5111808B、依赖15、queue1593.783µs、render662.788µs、layout1.07245µs、10000 dirty合并1帧。离线检查budget中5组stdout/stderr共10个完整流bytes/hash只是完整性核验，不是重新跑预算。

旧1044.823959ms及1208.732708ms冷启动失败仍由原release review指向，未删除或拿当前通过覆盖；本包保留该review而非旧失败全部原始目录，不声称已修复根因。time包装器PID3781不是已辨认zenpi child，构建进程树1.95GB不是产品RSS。run.json sha256绑定output log，不是result JSON；结果以public manifest条目绑定。历史4个Python仪器fixture与此前52 Rust/Clippy也不得累加成本轮产品执行。

## 最小实验矩阵（13组，全部未执行）

后续实验须由各产品owner在授权范围内完成，并保存binary/source/OS/terminal、真实输入、预期/实测、耗时和恢复状态。建议受控Instant单元验证与真实PTY长时等待各自保留，单元注入时间不能替代timer实际行为。

### P01 — 秒分时格式边界

最小输入：0、59、60、61、3599、3600、25h和u64高值。

判据：准确s/m/h；分钟秒两位；不把格式化器当作计时或时区功能。状态：未执行，只由完整源阅读和必要调用片段提出。

### P02 — 暂停恢复只累计运行段

最小输入：受控Instant：运行5秒、暂停5秒、恢复3秒，重复pause/resume及逆序Instant。

判据：5→5→8秒；重复操作幂等，saturating防负delta；暂停不调frame，真实resume调一次。状态：未执行，只由完整源阅读和必要调用片段提出。

### P03 — 计时暂停与动画分离

最小输入：paused/running × animations开关 × 空/非空area；隔时渲染。

判据：paused累计值不变，enabled仍可调32ms frame与动画；disabled无本widget周期frame，elapsed仍可在外部draw增长。状态：未执行，只由完整源阅读和必要调用片段提出。

### P04 — 状态字段归一化差异

最小输入：None、空串、全空白、首尾空白、嵌入换行；CapitalizeFirst/Preserve；max_lines0。

判据：details先判空再trim_start，inline先trim再判空；Preserve仍去前导空白；max_lines最小1。状态：未执行，只由完整源阅读和必要调用片段提出。

### P05 — details换行与双层裁剪

最小输入：width0/1/3/4/6/24，max_lines1/3，大段中日韩/emoji/组合字符，多span及area.height1/2。

判据：区分配置截断与可用高度截断；检查最后span按char截断的显示宽和grapheme边界，不许仅凭ASCII测试保证Unicode。状态：未执行，只由完整源阅读和必要调用片段提出。

### P06 — 显示行数不是资源上限

最小输入：长details和巨大max_lines，desired_height与render连续调用。

判据：记录全量wrap成本及u16转换/加法边界；未测内存CPU不得宣称bounded input；预算失败留档。状态：未执行，只由完整源阅读和必要调用片段提出。

### P07 — 取消提示与操作分离

最小输入：hint false/true、长header、20列、inline长串、模态/popup、Esc带mods和Repeat。

判据：visible flag仅文字；窄屏可截断esc；实际event按owner路由且记录Interrupt确认，不能用显示代替取消。状态：未执行，只由完整源阅读和必要调用片段提出。

### P08 — 源status生命周期与模态

最小输入：set_task_running开关、hide后ensure、审批/问题/MCP模态叠层和逐层完成。

判据：status重建计时重置；隐藏与running分离；确认resume时无其它应继续暂停的modal。状态：未执行，只由完整源阅读和必要调用片段提出。

### P09 — 目标Approval字符串门控

最小输入：busy/idle、Approval大小写、相同status重复、先Approval后set_busy(true)、resolve无ToolStarted及随后ToolStarted。

判据：确认pause/resume顺序；相同status不触发；新busy重置计时；不从substring推导真实审批状态。状态：未执行，只由完整源阅读和必要调用片段提出。

### P10 — 目标项目与新会话隔离

最小输入：运行时切项目/切回、后台审批、完成/取消、新会话/独立重启。

判据：同一进程项目保存ux；明确时间继续或暂停合同；Instant不能当持久化时钟；只验证所属owner，headless另项。状态：未执行，只由完整源阅读和必要调用片段提出。

### P11 — 真实model usage与估算标签

最小输入：实际Usage后注入旧job Usage、不同response model、无usage、历史估算、窄屏。

判据：实际in/out不被旧job覆盖；无数据tokens —；history ~为估算；status截断不冒充完整可见。状态：未执行，只由完整源阅读和必要调用片段提出。

### P12 — 目标取消接受与terminal恢复

最小输入：CtrlC各种草稿/忙碌状态、错误项目、cancel queue full、卡住provider及render I/O失败。

判据：Interrupt requested不是完成；错误项目不取消他人；先恢复terminal再join的路径需真实宿主确认。状态：未执行，只由完整源阅读和必要调用片段提出。

### P13 — 历史证据与实际timer缺口

最小输入：区分旧cf3659 transcript、1d7b2 release、当前TUI与正在漂移headless。

判据：只迁用绑定范围；7源测试/历史87 tests/历史UX不累加本轮执行，补真实长时pause/resume前不得通过。状态：未执行，只由完整源阅读和必要调用片段提出。

## 证据与精确接收/回退

证据目录`Docs/quality/stage1/ZS1-309/worker-status-indicator-review-3.1.20`保存正式source、3份引用snapshot、原worker report/原ready manifest/蓝图、67输入与32片段身份、27函数清单、7源测试逐段断言清单、2上下文测试、13实验矩阵、连续read-log和主库标准文件基底检查。

本次主库标准报告只读检查为absent；master.patch新增唯一标准report，worker.patch从本轮保存的原报告精确替换。每份patch在独立临时Git仓库先git init，再forward check/apply、reverse check/apply，比较新旧字节及无关sentinel，共8操作。不会在主库或worker根目录尝试apply。若主库接收时标准路径已不同，先重新读取精确基底、另造补丁，禁止force覆盖。回退仅反向本报告patch，不改其它报告、产品、会话、蓝图或完成标记。

check_static.py校验冻结输入、测试/函数清单、历史证据格式和hash；verify_package.py核对ready全部成员并独立重放两补丁。它们不编译source、不运行单元测试、不模拟产品或提供语义G-FILE接受。原308 ready和其它所有既有ready按原身份保留。本文件冻结后停在309，待master独立接收；不自动开始目录整合、125产品修复或headless跨项目/new修复。
