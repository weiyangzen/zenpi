            crate::security::redact_json(&r.arguments, &[])
        );
        if let Some(preview) = &r.preview {
            if let crate::tools::ToolPreview::Diff {
                truncated: true, ..
            } = preview
            {
                text.push_str("\nPreview truncated by owner; inspect source before allowing.\n");
            }
            text.push_str("\nProposed change:\n");
            text.push_str(preview.display_text());
        }
        let lines = crate::render::render_plain_prefixed(
            "",
            &text,
            usize::from(inner.width),
            Style::default(),
        );
        let height = inner.height.saturating_sub(2);
        view.scroll = view.scroll.min(
            lines
                .len()
                .saturating_sub(usize::from(height))
                .min(u16::MAX as usize) as u16,
        );
        frame.render_widget(
