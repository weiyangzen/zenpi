from pathlib import Path
import hashlib,json,re,runpy,sys
E=Path(__file__).resolve().parent;R=E.parents[4];M=Path('/Users/wangweiyang/GitHub/zenpi');H=lambda b:hashlib.sha256(b).hexdigest();frozen='--frozen' in sys.argv
def read(p):return json.loads((E/p).read_text())
m=read('input-manifest.json');assert m['authority']=='3.1.20' and m['requirement_digest']=='8d525b351d066ce9b0487a485337647d47233275782e4f4d154423a623fe1645' and m['frozen']['path']=='src/render.rs'
functions=read('function-index.json');tests=read('inline-tests.json');ranges={};sources={}
for n in ['baseline','current']:
 row=m[n];b=(R/row['artifact']).read_bytes();assert H(b)==row['sha256']==m['frozen']['sha256'] and len(b)==row['bytes']==m['frozen']['bytes']==30217 and len(b.splitlines())==row['lines']==901;offset=0;line=1;parts=[];rr=[];ls=b.splitlines(keepends=True)
 for c in row['read_chunks']:
  d=(R/c['artifact']).read_bytes();assert c['byte_start']==offset and c['line_start']==line and d==b[offset:c['byte_end']] and d==b''.join(ls[line-1:c['line_end']]) and H(d)==c['sha256'];parts.append(d);rr.append([offset,c['byte_end']]);offset=c['byte_end'];line=c['line_end']+1
 assert offset==len(b) and line==902 and b''.join(parts)==b;ranges[n]=rr;sources[n]=b
 s=b.decode();actual=[{'line':i,'signature':v.strip(),'kind':'production' if i<778 else 'inline_test' if i>789 else 'test_helper'} for i,v in enumerate(s.splitlines(),1) if re.match(r'\s*(?:pub\s+)?fn ',v)];ts=[{'line':s[:v.start()].count('\n')+1,'name':v.group(1)} for v in re.finditer(r'#\[test\]\s*fn\s+(\w+)',s)];assert actual==functions[n] and len(actual)==39 and sum(v['kind']=='production' for v in actual)==27 and ts==tests[n] and len(ts)==11
 if not frozen:assert Path(row['path']).read_bytes()==b
assert sources['baseline']==sources['current'] and (E/'baseline-to-current.diff').read_bytes()==b''
refs=read('caller-references.json');assert len(refs)==3;observations={}
assert refs[0]['relative_path']=='src/tui.rs' and refs[0]['sha256']=='10884fa44e143e0127f5f571c6b2f0e0bdd9675f9434664190d9bcde8d752da8'
for row in refs:
 b=Path(row['path']).read_bytes() if not frozen else None;matches=b is not None and H(b)==row['sha256']
 if b is not None:observations[row['relative_path']]={'matches_capture':matches,'capture_sha256':row['sha256'],'current_sha256':H(b)}
 for c in row['excerpts']:
  d=(R/c['artifact']).read_bytes();assert H(d)==c['sha256'] and len(d.splitlines())==c['line_end']-c['line_start']+1
  if matches:assert d==b''.join(b.splitlines(keepends=True)[c['line_start']-1:c['line_end']])
testinputs=read('test-inputs.json');assert len(testinputs)==2
for row,nlines in zip(testinputs,[71,60]):
 b=(R/row['artifact']).read_bytes();assert H(b)==row['sha256'] and len(b)==row['bytes'] and len(b.splitlines())==row['lines']==nlines;s=b.decode();ts=[{'line':s[:v.start()].count('\n')+1,'name':v.group(1)} for v in re.finditer(r'#\[test\]\s*fn\s+(\w+)',s)];assert ts==row['tests'] and len(ts)==4
 if not frozen:assert Path(row['path']).read_bytes()==b
inv=read('report-inventory.json');final=read('report-final.json');b=(R/inv['owned_path']).read_bytes();assert len(b)==final['bytes'] and H(b)==final['sha256'] and not inv['local_report_existed'] and not inv['main_report_existed'];preserved=read('preserved-ready-manifests.json');assert len(preserved)==66
gate=read('gstage-main.log');receipt=read('gstage-main.json');assert receipt['exit_code']==1 and gate['structural']['ok'] and not gate['ok'] and any('ZS1-096.master.json' in v for v in gate['errors']) and receipt['sha256']==H((E/'gstage-main.log').read_bytes())
if not frozen:
 s=json.loads((M/'Docs/execution/active_requirement.json').read_text());assert s['blueprint_version']==m['authority'] and s['requirement_digest']==m['requirement_digest'] and s['baseline_files']['ZS1-096']==m['frozen'];assert not (M/inv['owned_path']).exists()
 local=read('local-working-source.json');d=Path(local['path']).read_bytes();assert len(d)==local['bytes'] and H(d)==local['sha256']
 for name,digest in preserved.items():assert H((R/'.ops'/name/'manifest.json').read_bytes())==digest,name
 sys.path.insert(0,str(M/'tools'));g=runpy.run_path(str(M/'tools/validate_stage1_blueprint.py'));bp=g['parse']((M/'Docs/stage_1_v3_pi_mono_blueprint.md').read_text());f=bp.files['ZS1-096'];assert f.path==m['frozen']['path'] and f.sha256==m['baseline']['sha256'] and bp.requirement==m['requirement_digest']
 for n in ranges:g['check_ranges'](ranges[n],m[n]['bytes'])
 g['artifact'](R,{'path':inv['owned_path'],'bytes':len(b),'sha256':H(b)})
print(json.dumps({'ok':True,'item':'ZS1-096','mode':'frozen-offline' if frozen else 'live-readonly','source_sha256':m['current']['sha256'],'baseline_equals_current':True,'complete_lines_each':901,'complete_ranges':ranges,'function_declarations_each':39,'production_functions_each':27,'inline_tests_each':11,'inline_helper_each':1,'external_full_test_files':2,'external_tests':8,'distinct_test_definitions_read':19,'new_behavior_runs':0,'report_bytes':len(b),'report_sha256':H(b),'caller_live_observations':observations,'preserved_ready_manifests':66,'gstage_exit':1,'master_receipt_missing':True,'limits':'Pure evidence integrity and full source reading; no new Rust/product/terminal/HTTP execution, no old085 TUI identity substitution, no semantic/sibling/directory acceptance'},indent=2))
