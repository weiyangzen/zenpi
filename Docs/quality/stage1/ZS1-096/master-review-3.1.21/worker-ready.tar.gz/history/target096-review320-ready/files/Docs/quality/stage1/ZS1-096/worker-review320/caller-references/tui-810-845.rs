                text: message.text.clone(),
            });
            for (i, block) in message.blocks.iter().enumerate().take(32) {
                let text = view_block_text(block);
                if retained.saturating_add(text.len()) > MAX_TUI_PROVIDER_BYTES {
                    break;
                }
                retained += text.len();
                entries.push(CopyEntry {
                    label: format!("{} block {}", message.role.label(), i + 1),
                    text,
                });
            }
            if message.role == MessageRole::Assistant {
                for block in crate::render::parse_markdown(&message.text) {
                    if let crate::render::MarkdownBlock::Code { language, text } = block {
                        if retained.saturating_add(text.len()) > MAX_TUI_PROVIDER_BYTES {
                            break;
                        }
                        retained += text.len();
                        entries.push(CopyEntry {
                            label: format!("code · {}", language.unwrap_or_default()),
                            text,
                        });
                    }
                    if entries.len() >= 128 {
                        break;
                    }
                }
            }
            if entries.len() >= 128 {
                entries.truncate(128);
                break;
            }
        }
        Self {
