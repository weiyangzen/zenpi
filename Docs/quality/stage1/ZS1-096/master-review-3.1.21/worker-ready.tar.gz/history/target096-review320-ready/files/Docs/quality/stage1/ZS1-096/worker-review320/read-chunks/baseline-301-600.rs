}

fn flush_paragraph(blocks: &mut Vec<MarkdownBlock>, paragraph: &mut Vec<String>) {
    if paragraph.is_empty() {
        return;
    }
    blocks.push(MarkdownBlock::Paragraph(paragraph.join("\n")));
    paragraph.clear();
}

fn heading_info(line: &str) -> Option<(u8, String)> {
    let trimmed = line.trim_start();
    let level = trimmed
        .chars()
        .take_while(|character| *character == '#')
        .count();
    if !(1..=6).contains(&level) {
        return None;
    }
    let rest = &trimmed[level..];
    if !starts_with_whitespace(rest) {
        return None;
    }
    Some((level as u8, rest.trim().to_owned()))
}

fn quote_info(line: &str) -> Option<String> {
    let trimmed = line.trim_start();
    let rest = trimmed.strip_prefix('>')?;
    Some(rest.strip_prefix(' ').unwrap_or(rest).to_owned())
}

fn list_info(line: &str) -> Option<(bool, String, String)> {
    let trimmed = line.trim_start();
    let mut chars = trimmed.char_indices();
    let first = chars.next()?.1;
    if matches!(first, '-' | '*' | '+') {
        let marker_end = first.len_utf8();
        let rest = &trimmed[marker_end..];
        if starts_with_whitespace(rest) {
            return Some((false, first.to_string(), rest.trim().to_owned()));
        }
    }

    let digits_end = trimmed
        .char_indices()
        .take_while(|(_, character)| character.is_ascii_digit())
        .map(|(index, character)| index + character.len_utf8())
        .last()
        .unwrap_or(0);
    if digits_end > 0 {
        let rest = &trimmed[digits_end..];
        if let Some(rest) = rest.strip_prefix('.')
            && starts_with_whitespace(rest)
        {
            return Some((
                true,
                format!("{}.", &trimmed[..digits_end]),
                rest.trim().to_owned(),
            ));
        }
    }
    None
}

fn is_rule(line: &str) -> bool {
    let trimmed = line.trim();
    if trimmed.len() < 3 {
        return false;
    }
    let mut chars = trimmed.chars();
    let first = chars.next().unwrap_or_default();
    matches!(first, '-' | '*' | '_')
        && chars.all(|character| character == first || character.is_whitespace())
}

fn starts_with_whitespace(text: &str) -> bool {
    text.chars().next().is_some_and(char::is_whitespace)
}

fn fence_info(line: &str) -> Option<(char, usize, Option<String>)> {
    let trimmed = line.trim_start();
    let marker = trimmed.chars().next()?;
    if marker != '`' && marker != '~' {
        return None;
    }
    let count = trimmed
        .chars()
        .take_while(|character| *character == marker)
        .count();
    if count < 3 {
        return None;
    }
    let remainder = trimmed
        .char_indices()
        .nth(count)
        .map_or("", |(index, _)| &trimmed[index..]);
    let remainder = remainder.trim();
    let language = (!remainder.is_empty()).then(|| {
        remainder
            .split_whitespace()
            .next()
            .unwrap_or_default()
            .to_owned()
    });
    Some((marker, count, language))
}

#[derive(Debug, Clone)]
struct StyledSegment {
    text: String,
    style: Style,
}

fn render_inline_text(
    text: &str,
    base_style: Style,
    width: usize,
    output: &mut Vec<Line<'static>>,
    max_lines: usize,
) {
    let segments = inline_segments(text, base_style);
    let lines = wrap_segments(&segments, width);
    for line in lines {
        push_line(output, line, max_lines);
        if output.len() >= max_lines {
            break;
        }
    }
}

fn render_prefixed_inline(
    prefix: &str,
    text: &str,
    base_style: Style,
    width: usize,
    output: &mut Vec<Line<'static>>,
    max_lines: usize,
) {
    let prefix_width = UnicodeWidthStr::width(prefix).min(width.saturating_sub(1));
    let prefix = truncate_to_width(prefix, width.saturating_sub(1));
    let body_width = width.saturating_sub(prefix_width).max(1);
    let segments = inline_segments(text, base_style);
    let lines = wrap_segments(&segments, body_width);
    for (index, line) in lines.into_iter().enumerate() {
        let mut spans = Vec::with_capacity(line.spans.len() + 1);
        let marker_style = if index == 0 {
            base_style.add_modifier(Modifier::BOLD)
        } else {
            base_style
        };
        spans.push(Span::styled(
            if index == 0 {
                prefix.clone()
            } else {
                " ".repeat(prefix_width)
            },
            marker_style,
        ));
        spans.extend(line.spans);
        push_line(output, Line::from(spans), max_lines);
        if output.len() >= max_lines {
            break;
        }
    }
}

fn render_code(
    language: Option<&str>,
    text: &str,
    width: usize,
    output: &mut Vec<Line<'static>>,
    max_lines: usize,
) {
    let style = Style::default().fg(Color::LightYellow);
    if let Some(language) = language {
        let label = truncate_to_width(&format!("[{language}]"), width);
        push_line(
            output,
            Line::from(Span::styled(label, style.add_modifier(Modifier::BOLD))),
            max_lines,
        );
    }
    let code_lines = if text.is_empty() {
        vec![String::new()]
    } else {
        text.split('\n').map(str::to_owned).collect()
    };
    for code_line in code_lines {
        let mut prefix = "| ".to_owned();
        let prefix_width = UnicodeWidthStr::width(prefix.as_str()).min(width.saturating_sub(1));
        prefix = truncate_to_width(&prefix, width.saturating_sub(1));
        let body_width = width.saturating_sub(prefix_width).max(1);
        let chunks = wrap_plain(&code_line, body_width);
        for (index, chunk) in chunks.into_iter().enumerate() {
            let marker = if index == 0 {
                prefix.clone()
            } else {
                " ".repeat(prefix_width)
            };
            push_line(
                output,
                Line::from(vec![
                    Span::styled(marker, style),
                    Span::styled(chunk, style),
                ]),
                max_lines,
            );
            if output.len() >= max_lines {
                return;
            }
        }
    }
}

fn inline_segments(text: &str, base_style: Style) -> Vec<StyledSegment> {
    let mut segments = Vec::new();
    let mut plain = String::new();
    let mut index = 0usize;
    while index < text.len() {
        let rest = &text[index..];
        let special = rest.as_bytes().first().copied().unwrap_or_default();
        let intraword_underscore = special == b'_'
            && text[..index]
                .trim_end_matches('_')
                .chars()
                .next_back()
                .is_some_and(char::is_alphanumeric);
        let parsed = if intraword_underscore {
            None
        } else if special == b'`' {
            parse_delimited(rest, '`', "`")
                .map(|(content, consumed)| (content, consumed, base_style.fg(Color::LightYellow)))
        } else if rest.starts_with("**") {
            parse_delimited(rest, '*', "**").map(|(content, consumed)| {
                (content, consumed, base_style.add_modifier(Modifier::BOLD))
            })
        } else if rest.starts_with("__") {
            parse_delimited(rest, '_', "__").map(|(content, consumed)| {
                (content, consumed, base_style.add_modifier(Modifier::BOLD))
            })
        } else if special == b'*' {
            parse_delimited(rest, '*', "*").map(|(content, consumed)| {
                (content, consumed, base_style.add_modifier(Modifier::ITALIC))
            })
        } else if special == b'_' {
            parse_delimited(rest, '_', "_").map(|(content, consumed)| {
                (content, consumed, base_style.add_modifier(Modifier::ITALIC))
            })
        } else if special == b'[' {
            parse_link(rest).map(|(content, consumed)| {
                (
                    content,
                    consumed,
                    base_style
                        .fg(Color::LightBlue)
                        .add_modifier(Modifier::UNDERLINED),
                )
            })
        } else {
            None
        };

        if let Some((content, consumed, style)) = parsed {
            if !plain.is_empty() {
                segments.push(StyledSegment {
                    text: std::mem::take(&mut plain),
                    style: base_style,
                });
            }
            segments.push(StyledSegment {
                text: content,
                style,
            });
            index += consumed;
            continue;
        }

        let character = rest.chars().next().unwrap_or_default();
        plain.push(character);
        index += character.len_utf8();
    }
    if !plain.is_empty() {
        segments.push(StyledSegment {
            text: plain,
            style: base_style,
        });
    }
    if segments.is_empty() {
        segments.push(StyledSegment {
            text: String::new(),
            style: base_style,
        });
    }
    segments
}

fn parse_delimited(rest: &str, _marker: char, delimiter: &str) -> Option<(String, usize)> {
    if !rest.starts_with(delimiter) {
        return None;
