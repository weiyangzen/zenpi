        frame.render_widget(
            Paragraph::new("[Prev] [Next] [Copy] [Close] · Up/Down select · PgUp/PgDn read"),
            Rect::new(inner.x, inner.y + 1, inner.width, 1),
        );
        let text = self
            .entries
            .get(self.selected)
            .map(|e| e.text.as_str())
            .unwrap_or_default();
        let lines = crate::render::render_plain_prefixed(
            "",
            text,
            usize::from(inner.width),
            Style::default(),
        );
        self.scroll = self.scroll.min(
            lines
                .len()
                .saturating_sub(usize::from(inner.height - 2))
                .min(u16::MAX as usize) as u16,
        );
        frame.render_widget(
            Paragraph::new(lines).scroll((self.scroll, 0)),
            Rect::new(inner.x, inner.y + 2, inner.width, inner.height - 2),
        );
    }
}
