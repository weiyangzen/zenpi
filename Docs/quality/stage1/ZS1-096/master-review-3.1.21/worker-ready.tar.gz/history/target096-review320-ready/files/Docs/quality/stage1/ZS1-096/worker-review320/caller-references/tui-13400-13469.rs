        lines.push(line);
    }
    if lines.is_empty() {
        lines.push(String::new());
    }
    lines
}

fn transcript_lines(
    messages: &VecDeque<TuiMessage>,
    width: usize,
    persona: &str,
) -> Vec<Line<'static>> {
    let width = width.max(1);
    let mut result = Vec::new();
    for message in messages {
        let prefix = if message.role == MessageRole::Reasoning {
            "◇ Reasoning: "
        } else {
            "● "
        };
        let style = if message.role == MessageRole::Assistant {
            Style::default().fg(crate::persona::color(persona))
        } else {
            message.role.style()
        };
        // Provider prose gets the small Markdown renderer; user prompts,
        // tool output, and errors stay literal so metadata or diff markers do
        // not acquire surprising presentation semantics.
        // Live output text is already the complete literal projection of its
        // canonical block; retain that block for inspection without printing
        // the same snapshot twice in the conversation pane.
        let block_text = if message.blocks.is_empty() || message.block_id.is_some() {
            None
        } else {
            Some(
                message
                    .blocks
                    .iter()
                    .map(view_block_text)
                    .collect::<Vec<_>>()
                    .join("\n"),
            )
        };
        let display_text = block_text
            .as_deref()
            .map(|blocks| format!("{}\n{}", message.text, blocks))
            .unwrap_or_else(|| message.text.clone());
        let rendered = match message.role {
            MessageRole::Assistant | MessageRole::System => {
                crate::render::render_markdown_prefixed(prefix, &display_text, width, style)
            }
            MessageRole::User | MessageRole::Tool | MessageRole::Error | MessageRole::Reasoning => {
                crate::render::render_plain_prefixed(prefix, &display_text, width, style)
            }
        };
        for line in rendered {
            result.push(line);
            if result.len() >= MAX_RENDER_LINES.saturating_mul(2) {
                return result;
            }
        }
    }
    result
}

fn view_block_text(block: &crate::view_model::ViewBlock) -> String {
    match block {
        crate::view_model::ViewBlock::Diff { path, patch } => {
            format!(
