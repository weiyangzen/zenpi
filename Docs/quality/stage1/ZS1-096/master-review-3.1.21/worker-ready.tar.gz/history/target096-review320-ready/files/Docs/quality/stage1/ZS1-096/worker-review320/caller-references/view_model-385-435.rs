            Self::Error { .. } => ViewBlockKind::Error,
            Self::Rule => ViewBlockKind::Rule,
        }
    }

    /// Convert one parsed Markdown block without introducing a parser into
    /// either transport.
    pub fn from_markdown(block: &MarkdownBlock) -> Result<Self, ViewModelError> {
        let result = match block {
            MarkdownBlock::Paragraph(text) => Self::Paragraph { text: text.clone() },
            MarkdownBlock::Heading { level, text } => Self::Heading {
                level: *level,
                text: text.clone(),
            },
            MarkdownBlock::Code { language, text } => Self::Code {
                language: language.clone(),
                text: text.clone(),
            },
            MarkdownBlock::Quote(text) => Self::Quote { text: text.clone() },
            MarkdownBlock::ListItem { ordered, text, .. } => Self::List {
                ordered: *ordered,
                items: vec![text.clone()],
            },
            MarkdownBlock::Rule => Self::Rule,
        };
        result.validate()?;
        Ok(result)
    }

    /// Parse and normalize the bounded Markdown subset used by the TUI.
    pub fn from_markdown_text(text: &str) -> Result<Vec<Self>, ViewModelError> {
        let blocks = crate::render::parse_markdown(text);
        if blocks.len() > MAX_VIEW_BLOCKS {
            return Err(ViewModelError::TooLarge {
                field: "message blocks",
                max: MAX_VIEW_BLOCKS,
            });
        }
        blocks.iter().map(Self::from_markdown).collect()
    }
}

/// Stable discriminant for block consumers that do not need to match fields.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ViewBlockKind {
    PlainText,
    Paragraph,
    Heading,
    List,
    Quote,
