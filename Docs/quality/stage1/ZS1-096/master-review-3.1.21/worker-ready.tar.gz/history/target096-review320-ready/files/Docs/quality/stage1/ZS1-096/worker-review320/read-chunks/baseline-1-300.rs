//! Lightweight rendering for assistant text.
//!
//! The interactive TUI deliberately does not pull in a full Markdown parser or
//! syntax-highlighting stack.  This module covers the small, predictable
//! subset that is useful in a terminal conversation while keeping the output
//! bounded and safe for a narrow terminal.  Unsupported Markdown is rendered
//! as ordinary text rather than dropped or interpreted as terminal control
//! sequences.

use ratatui::style::{Color, Modifier, Style};
use ratatui::text::{Line, Span};
use unicode_width::{UnicodeWidthChar, UnicodeWidthStr};

/// Maximum input copied into the renderer.
pub const MAX_MARKDOWN_BYTES: usize = 256 * 1024;
/// Maximum number of output lines retained by [`render_markdown`].
pub const MAX_MARKDOWN_LINES: usize = 8_192;
/// Maximum approximate terminal cells retained for one rendered message. The
/// line cap alone would permit a pathological 65k-column test viewport to
/// allocate hundreds of megabytes of separators.
pub const MAX_MARKDOWN_CELLS: usize = 4 * 1024 * 1024;
/// Maximum viewport width accepted by the renderer. Ratatui terminal areas are
/// `u16` wide in practice; this extra bound prevents an accidental huge
/// allocation when the API is called outside a terminal.
pub const MAX_MARKDOWN_WIDTH: usize = u16::MAX as usize;

/// A deliberately small block-level Markdown model.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum MarkdownBlock {
    Paragraph(String),
    Heading {
        level: u8,
        text: String,
    },
    Code {
        language: Option<String>,
        text: String,
    },
    Quote(String),
    ListItem {
        ordered: bool,
        marker: String,
        text: String,
    },
    Rule,
}

/// Parse the supported block subset.
///
/// The parser is intentionally loss-tolerant: an unclosed fence becomes a
/// code block at EOF, and unknown syntax remains paragraph text.  This is a
/// better failure mode for a conversation renderer than returning an error or
/// silently hiding a provider response.
pub fn parse_markdown(input: &str) -> Vec<MarkdownBlock> {
    let sanitized = sanitize_text(truncate_bytes(input, MAX_MARKDOWN_BYTES));
    let bounded = truncate_bytes(&sanitized, MAX_MARKDOWN_BYTES);
    let mut blocks = Vec::new();
    let mut paragraph = Vec::new();
    let mut code: Option<(char, usize, Option<String>, Vec<String>)> = None;

    for raw_line in bounded.lines() {
        let line = raw_line.strip_suffix('\r').unwrap_or(raw_line);
        if let Some((fence, fence_len, language, mut lines)) = code.take() {
            if let Some((close_fence, close_len, close_language)) = fence_info(line)
                && close_fence == fence
                && close_len >= fence_len
                && close_language.is_none()
            {
                blocks.push(MarkdownBlock::Code {
                    language,
                    text: lines.join("\n"),
                });
            } else {
                lines.push(line.to_owned());
                code = Some((fence, fence_len, language, lines));
            }
            continue;
        }

        if let Some((fence, fence_len, language)) = fence_info(line) {
            flush_paragraph(&mut blocks, &mut paragraph);
            code = Some((fence, fence_len, language, Vec::new()));
            continue;
        }

        if line.trim().is_empty() {
            flush_paragraph(&mut blocks, &mut paragraph);
            continue;
        }
        if let Some((level, text)) = heading_info(line) {
            flush_paragraph(&mut blocks, &mut paragraph);
            blocks.push(MarkdownBlock::Heading { level, text });
            continue;
        }
        if let Some(text) = quote_info(line) {
            flush_paragraph(&mut blocks, &mut paragraph);
            blocks.push(MarkdownBlock::Quote(text));
            continue;
        }
        if let Some((ordered, marker, text)) = list_info(line) {
            flush_paragraph(&mut blocks, &mut paragraph);
            blocks.push(MarkdownBlock::ListItem {
                ordered,
                marker,
                text,
            });
            continue;
        }
        if is_rule(line) {
            flush_paragraph(&mut blocks, &mut paragraph);
            blocks.push(MarkdownBlock::Rule);
            continue;
        }
        paragraph.push(line.to_owned());
    }

    if let Some((_fence, _fence_len, language, lines)) = code {
        blocks.push(MarkdownBlock::Code {
            language,
            text: lines.join("\n"),
        });
    }
    flush_paragraph(&mut blocks, &mut paragraph);
    blocks
}

/// Render supported Markdown to Ratatui lines constrained to `width` cells.
///
/// This function returns owned lines so callers can cache them between frames.
/// Every line is bounded by `width` (including a one-cell viewport), and the
/// result is capped at [`MAX_MARKDOWN_LINES`].
pub fn render_markdown(input: &str, width: usize) -> Vec<Line<'static>> {
    render_markdown_with_limit(input, width, MAX_MARKDOWN_LINES)
}

/// Render a message body with a fixed-width role/metadata prefix.
///
/// Conversation UIs commonly put `you: ` or `tool: ` on the first visual row
/// and indent wrapped rows beneath it.  Keeping that operation here avoids a
/// second, subtly different wrapping implementation in the TUI.  `prefix`
/// is cell-truncated when the viewport is narrow; at least one cell remains
/// available for body text.
pub fn render_markdown_prefixed(
    prefix: &str,
    input: &str,
    width: usize,
    prefix_style: Style,
) -> Vec<Line<'static>> {
    let width = width.clamp(1, MAX_MARKDOWN_WIDTH);
    let prefix_width = UnicodeWidthStr::width(prefix).min(width.saturating_sub(1));
    let prefix = truncate_to_width(prefix, width.saturating_sub(1));
    let continuation = " ".repeat(prefix_width);
    let body = render_markdown_with_limit(
        input,
        width.saturating_sub(prefix_width).max(1),
        bounded_line_limit(
            width.saturating_sub(prefix_width).max(1),
            MAX_MARKDOWN_LINES,
        ),
    );
    body.into_iter()
        .enumerate()
        .map(|(index, line)| {
            let mut spans = Vec::with_capacity(line.spans.len() + 1);
            spans.push(Span::styled(
                if index == 0 {
                    prefix.clone()
                } else {
                    continuation.clone()
                },
                prefix_style,
            ));
            spans.extend(line.spans);
            Line::from(spans)
        })
        .collect()
}

/// Render a message with a role prefix without interpreting Markdown syntax.
///
/// User-entered prompts, tool output, and error text are intentionally kept in
/// this path.  They still receive control-byte sanitization and cell-aware
/// wrapping, but a line beginning with `---` or `#` cannot unexpectedly change
/// its visual meaning.
pub fn render_plain_prefixed(
    prefix: &str,
    input: &str,
    width: usize,
    prefix_style: Style,
) -> Vec<Line<'static>> {
    let width = width.clamp(1, MAX_MARKDOWN_WIDTH);
    let prefix_width = UnicodeWidthStr::width(prefix).min(width.saturating_sub(1));
    let prefix = truncate_to_width(prefix, width.saturating_sub(1));
    let continuation = " ".repeat(prefix_width);
    let bounded = truncate_bytes(input, MAX_MARKDOWN_BYTES);
    let sanitized = sanitize_text(bounded);
    let body = wrap_segments(
        &[StyledSegment {
            text: sanitized,
            style: Style::default(),
        }],
        width.saturating_sub(prefix_width).max(1),
    );
    body.into_iter()
        .take(bounded_line_limit(
            width.saturating_sub(prefix_width).max(1),
            MAX_MARKDOWN_LINES,
        ))
        .enumerate()
        .map(|(index, line)| {
            let mut spans = Vec::with_capacity(line.spans.len() + 1);
            spans.push(Span::styled(
                if index == 0 {
                    prefix.clone()
                } else {
                    continuation.clone()
                },
                prefix_style,
            ));
            spans.extend(line.spans);
            Line::from(spans)
        })
        .collect()
}

/// Variant of [`render_markdown`] with an explicit output-line limit.
pub fn render_markdown_with_limit(
    input: &str,
    width: usize,
    max_lines: usize,
) -> Vec<Line<'static>> {
    let width = width.clamp(1, MAX_MARKDOWN_WIDTH);
    let max_lines = bounded_line_limit(width, max_lines);
    let blocks = parse_markdown(input);
    let mut output = Vec::new();

    for (index, block) in blocks.iter().enumerate() {
        if index > 0 {
            push_line(&mut output, Line::default(), max_lines);
        }
        match block {
            MarkdownBlock::Paragraph(text) => {
                render_inline_text(text, Style::default(), width, &mut output, max_lines);
            }
            MarkdownBlock::Heading { level, text } => {
                let style = heading_style(*level);
                render_inline_text(text, style, width, &mut output, max_lines);
            }
            MarkdownBlock::Code { language, text } => {
                render_code(language.as_deref(), text, width, &mut output, max_lines);
            }
            MarkdownBlock::Quote(text) => {
                render_prefixed_inline(
                    "| ",
                    text,
                    Style::default().fg(Color::DarkGray),
                    width,
                    &mut output,
                    max_lines,
                );
            }
            MarkdownBlock::ListItem {
                ordered,
                marker,
                text,
            } => {
                let prefix = if *ordered {
                    format!("{marker} ")
                } else {
                    "- ".to_owned()
                };
                render_prefixed_inline(
                    &prefix,
                    text,
                    Style::default(),
                    width,
                    &mut output,
                    max_lines,
                );
            }
            MarkdownBlock::Rule => {
                push_line(
                    &mut output,
                    Line::from(Span::styled(
                        "-".repeat(width),
                        Style::default().fg(Color::DarkGray),
                    )),
                    max_lines,
                );
            }
        }
        if output.len() >= max_lines {
            break;
        }
    }

    if output.is_empty() {
        output.push(Line::default());
    }
    output
