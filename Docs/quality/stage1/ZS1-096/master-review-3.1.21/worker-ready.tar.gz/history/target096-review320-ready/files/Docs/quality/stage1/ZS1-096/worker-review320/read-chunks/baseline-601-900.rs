    }
    let content_start = delimiter.len();
    let close = rest[content_start..].find(delimiter)?;
    if close == 0 {
        return None;
    }
    let content_end = content_start + close;
    let consumed = content_end + delimiter.len();
    Some((rest[content_start..content_end].to_owned(), consumed))
}

fn parse_link(rest: &str) -> Option<(String, usize)> {
    let label_end = rest[1..].find(']')? + 1;
    if !rest[label_end..].starts_with("](") {
        return None;
    }
    let target_start = label_end + 2;
    let target_end = rest[target_start..].find(')')? + target_start;
    if target_end == target_start {
        return None;
    }
    Some((rest[1..label_end].to_owned(), target_end + 1))
}

fn wrap_segments(segments: &[StyledSegment], width: usize) -> Vec<Line<'static>> {
    let width = width.max(1);
    let mut lines = Vec::new();
    let mut spans: Vec<Span<'static>> = Vec::new();
    let mut used = 0usize;

    for segment in segments {
        for character in segment.text.chars() {
            if character == '\n' {
                lines.push(Line::from(std::mem::take(&mut spans)));
                used = 0;
                continue;
            }
            let character_width = UnicodeWidthChar::width(character).unwrap_or(0);
            let (character, character_width) = if character_width > width {
                ('?', 1)
            } else {
                (character, character_width)
            };
            if character_width > 0 && used > 0 && used.saturating_add(character_width) > width {
                lines.push(Line::from(std::mem::take(&mut spans)));
                used = 0;
            }
            if let Some(last) = spans.last_mut()
                && last.style == segment.style
            {
                last.content.to_mut().push(character);
            } else {
                spans.push(Span::styled(character.to_string(), segment.style));
            }
            used = used.saturating_add(character_width);
        }
    }
    lines.push(Line::from(spans));
    if lines.is_empty() {
        lines.push(Line::default());
    }
    lines
}

fn wrap_plain(text: &str, width: usize) -> Vec<String> {
    let width = width.max(1);
    let mut lines = Vec::new();
    let mut line = String::new();
    let mut used = 0usize;
    for character in text.chars() {
        let character_width = UnicodeWidthChar::width(character).unwrap_or(0);
        if character_width > width {
            if !line.is_empty() {
                lines.push(std::mem::take(&mut line));
            }
            line.push('?');
            used = 1;
            continue;
        }
        if character_width > 0 && used > 0 && used.saturating_add(character_width) > width {
            lines.push(std::mem::take(&mut line));
            used = 0;
        }
        line.push(character);
        used = used.saturating_add(character_width);
    }
    lines.push(line);
    lines
}

fn heading_style(level: u8) -> Style {
    let color = match level {
        1 => Color::LightCyan,
        2 => Color::Cyan,
        _ => Color::LightBlue,
    };
    Style::default().fg(color).add_modifier(Modifier::BOLD)
}

fn push_line(output: &mut Vec<Line<'static>>, line: Line<'static>, max_lines: usize) {
    if output.len() < max_lines {
        output.push(line);
    }
}

fn bounded_line_limit(width: usize, requested: usize) -> usize {
    requested
        .max(1)
        .min(MAX_MARKDOWN_CELLS.saturating_div(width.max(1)).max(1))
}

fn truncate_bytes(text: &str, max_bytes: usize) -> &str {
    if text.len() <= max_bytes {
        return text;
    }
    let mut end = max_bytes;
    while end > 0 && !text.is_char_boundary(end) {
        end -= 1;
    }
    &text[..end]
}

/// Replace terminal control bytes before text reaches a Ratatui span.  A
/// provider response is untrusted input; allowing an ESC sequence through a
/// renderer would let it reprogram the user's terminal.  Newlines are kept as
/// structural Markdown separators and tabs become spaces for deterministic
/// cell-width accounting.
fn sanitize_text(text: &str) -> String {
    sanitize_text_with_limit(text, MAX_MARKDOWN_BYTES)
}

fn sanitize_text_with_limit(text: &str, max_bytes: usize) -> String {
    let mut result = String::with_capacity(text.len().min(max_bytes));
    let mut characters = text.chars().peekable();
    while let Some(character) = characters.next() {
        // Normalize both CRLF and lone CR before block parsing.  For CRLF the
        // following LF is retained, so exactly one structural newline occurs.
        if character == '\r' && characters.peek() == Some(&'\n') {
            continue;
        }
        let replacement = match character {
            '\n' | '\r' => "\n",
            '\t' => "    ",
            character if character.is_control() => "?",
            character => {
                let mut buffer = [0_u8; 4];
                let encoded = character.encode_utf8(&mut buffer);
                if result.len().saturating_add(encoded.len()) > max_bytes {
                    break;
                }
                result.push_str(encoded);
                continue;
            }
        };
        if result.len().saturating_add(replacement.len()) > max_bytes {
            break;
        }
        result.push_str(replacement);
    }
    result
}

fn truncate_to_width(text: &str, width: usize) -> String {
    let mut result = String::new();
    let mut used = 0usize;
    for character in text.chars() {
        let character_width = UnicodeWidthChar::width(character).unwrap_or(0);
        if used.saturating_add(character_width) > width {
            break;
        }
        result.push(character);
        used = used.saturating_add(character_width);
    }
    result
}

#[cfg(test)]
mod tests {
    use super::*;
    use ratatui::style::Modifier;

    fn line_text(line: &Line<'_>) -> String {
        line.spans
            .iter()
            .map(|span| span.content.as_ref())
            .collect()
    }

    #[test]
    fn parses_blocks_without_swallowing_unknown_text() {
        let blocks = parse_markdown(
            "# Title\n\nplain **bold**\n\n```rust\nlet x = 1;\n```\n\n> quote\n\n- item\n\n1. first\n\n---\nunknown *syntax",
        );
        assert!(matches!(blocks[0], MarkdownBlock::Heading { level: 1, .. }));
        assert!(matches!(blocks[1], MarkdownBlock::Paragraph(_)));
        assert!(
            matches!(blocks[2], MarkdownBlock::Code { ref language, .. } if language.as_deref() == Some("rust"))
        );
        assert!(matches!(blocks[3], MarkdownBlock::Quote(_)));
        assert!(matches!(
            blocks[4],
            MarkdownBlock::ListItem { ordered: false, .. }
        ));
        assert!(matches!(
            blocks[5],
            MarkdownBlock::ListItem { ordered: true, .. }
        ));
        assert!(matches!(blocks[6], MarkdownBlock::Rule));
        assert!(matches!(blocks[7], MarkdownBlock::Paragraph(_)));
    }

    #[test]
    fn renders_inline_styles_and_hides_link_target() {
        let lines = render_markdown(
            "**bold** *italic* `code` [label](https://example.test)",
            120,
        );
        let spans = &lines[0].spans;
        assert!(spans.iter().any(|span| {
            span.content == "bold" && span.style.add_modifier(Modifier::BOLD) == span.style
        }));
        assert!(spans.iter().any(|span| {
            span.content == "italic" && span.style.add_modifier(Modifier::ITALIC) == span.style
        }));
        assert!(spans.iter().any(|span| span.content == "label"));
        assert!(!line_text(&lines[0]).contains("https://"));
    }

    #[test]
    fn output_is_bounded_for_narrow_unicode_viewports() {
        let lines = render_markdown("世界 wide text", 1);
        assert!(!lines.is_empty());
        assert!(
            lines
                .iter()
                .all(|line| UnicodeWidthStr::width(line_text(line).as_str()) <= 1)
        );
    }

    #[test]
    fn unclosed_fence_is_visible_as_code() {
        let blocks = parse_markdown("```text\nnot hidden");
        assert!(
            matches!(blocks.as_slice(), [MarkdownBlock::Code { language: Some(language), text }] if language == "text" && text == "not hidden")
        );
    }

    #[test]
    fn line_limit_is_hard() {
        let lines = render_markdown_with_limit("a\n\n b\n\n c\n\n d", 80, 2);
        assert_eq!(lines.len(), 2);
    }

    #[test]
    fn terminal_control_sequences_are_rendered_as_text() {
        let lines = render_markdown("before\u{1b}[2Jafter\tend", 80);
        let text = lines.iter().map(line_text).collect::<Vec<_>>().join("\n");
        assert!(!text.contains('\u{1b}'));
        assert!(text.contains("before?[2Jafter    end"));
    }

    #[test]
    fn crlf_input_does_not_leak_carriage_returns() {
        let blocks = parse_markdown("first\r\n\r\nsecond");
        assert!(matches!(&blocks[0], MarkdownBlock::Paragraph(text) if text == "first"));
        assert!(matches!(&blocks[1], MarkdownBlock::Paragraph(text) if text == "second"));
    }

    #[test]
    fn prefixed_rendering_keeps_role_and_body_inside_width() {
        let lines = render_markdown_prefixed("you: ", "a long **message**", 8, Style::default());
        assert!(
            lines
                .iter()
                .all(|line| { UnicodeWidthStr::width(line_text(line).as_str()) <= 8 })
        );
        assert!(line_text(&lines[0]).starts_with("you: "));
        assert!(line_text(&lines[1]).starts_with("     "));
    }

    #[test]
    fn plain_prefixed_rendering_does_not_interpret_markers() {
        let lines = render_plain_prefixed("user: ", "# heading\n---", 80, Style::default());
        let text = lines.iter().map(line_text).collect::<Vec<_>>().join("\n");
        assert!(text.contains("# heading"));
        assert!(text.contains("---"));
    }

    #[test]
    fn sanitization_bound_applies_after_tab_expansion() {
        let input = "\t".repeat(MAX_MARKDOWN_BYTES);
        assert!(sanitize_text(&input).len() <= MAX_MARKDOWN_BYTES);
    }

    #[test]
    fn cell_budget_limits_wide_viewport_allocations() {
        let input = "---\n".repeat(128);
        let lines = render_markdown_with_limit(&input, u16::MAX as usize, MAX_MARKDOWN_LINES);
        assert!(lines.len() <= MAX_MARKDOWN_CELLS / u16::MAX as usize + 1);
    }
