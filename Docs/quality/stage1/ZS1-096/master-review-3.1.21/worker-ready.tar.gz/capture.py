from pathlib import Path
import json,hashlib,shutil,subprocess,datetime
W=Path(__file__).resolve().parent;ROOT=W.parent.parent;MAIN=Path('/Users/wangweiyang/GitHub/zenpi');CODEX=Path('/Users/wangweiyang/GitHub/codex');REPORT='Docs/learn/stage1_pi_mono/targets/zenpi/files/src/render.rs_learn.md'
def identity(path):
 data=path.read_bytes();return {'bytes':len(data),'lines':len(data.splitlines()),'sha256':hashlib.sha256(data).hexdigest()}
def inventory(root):return {str(p.relative_to(root)):identity(p) for p in sorted(root.rglob('*')) if p.is_file() and not p.is_symlink()}
def save(name,data):(W/name).write_text(json.dumps(data,indent=2)+'\n')
ready=sorted(p for p in (ROOT/'.ops').glob('*-ready') if p.is_dir())+[ROOT/'.ops/stage125-render-review320/ready',ROOT/'.ops/stage126-independent320/ready',ROOT/'.ops/stage126-independent320/ready-final']
tracked={str(ROOT/p.decode()):identity(ROOT/p.decode()) for p in subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).split(b'\0') if p and (ROOT/p.decode()).is_file()}
before={'ready':{str(p):inventory(p) for p in ready},'tracked':tracked};save('preservation-before.json',before)
selection={'zenpi':['src/render.rs','src/tui.rs','src/view_model.rs','src/lib.rs','tests/render_markdown.rs','tests/tui_markdown.rs','tests/tui_transcript_ux.rs','Docs/stage_1_v3_pi_mono_blueprint.md','Docs/execution/active_requirement.json','Docs/learn/stage1_pi_mono/targets/zenpi/source_manifest.tsv','Docs/learn/stage1_pi_mono/targets/zenpi/file_learn_index.tsv','Docs/quality/stage1/ZS1-125/master-approval-timer-3.1.21/review.md'],'codex':['codex-rs/tui/src/key_hint.rs','codex-rs/tui/src/status_indicator_widget.rs']}
files=[]
for tag,paths in selection.items():
 for rel in paths:
  src={'zenpi':MAIN,'codex':CODEX}[tag]/rel;dst=W/'capture'/tag/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);assert identity(src)==identity(dst);files.append({'path':str(dst.relative_to(W)),'origin':str(src),'role':'subject-full' if tag=='zenpi' and rel=='src/render.rs' else 'context-only',**identity(dst)})
history=[]
for src in [ROOT/'.ops/target096-review320-ready',ROOT/'.ops/target096-postfreeze320',ROOT/'.ops/reference308-keys321-ready',ROOT/'.ops/reference309-status321-ready']:
 dst=W/'history'/src.name;shutil.copytree(src,dst);original=inventory(src);assert inventory(dst)==original;history.append({'origin':str(src),'path':str(dst.relative_to(W)),'files':original})
for src,name in [(ROOT/REPORT,'inherited-worker-report.md'),(ROOT/'.ops/target096-review320-report.md','old-working-report.md')]:
 dst=W/'history'/name;shutil.copyfile(src,dst);files.append({'path':str(dst.relative_to(W)),'origin':str(src),'role':'history-identity',**identity(dst)})
save('external-preservation-before.json',history)
save('preparation-issues.json',[{'operation':'Locator external2267 glob096','result':'No matching path, ls exit1; local096 found; no reading credit.'},{'operation':'Locator previous309 capture.json','result':'Absent because previous package keeps capture under evidence; no reading credit. Read actual manifest and package structure afterwards.'},{'operation':'Pre-capture source preview','result':'Source1-220 preview only; full formal read begins on immutable captured bytes and ledger below.'}])
save('capture.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'item':'ZS1-096','version':'3.1.21','report':REPORT,'report_original_exists':(MAIN/REPORT).exists(),'files':files,'old_ready':len(ready),'old_regular':sum(map(len,before['ready'].values())),'tracked':len(tracked)})
print(json.dumps({'subject':files[0],'captures':len(files),'old_ready':len(ready),'old_regular':sum(map(len,before['ready'].values())),'tracked':len(tracked),'history_counts':[len(r['files']) for r in history],'main_report_exists':(MAIN/REPORT).exists()},indent=2))
