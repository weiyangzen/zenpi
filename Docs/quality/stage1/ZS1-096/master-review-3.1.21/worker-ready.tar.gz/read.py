from pathlib import Path
import sys,json,hashlib
W=Path(__file__).resolve().parent;p=W/sys.argv[1];lo,hi=map(int,sys.argv[2:4]);data=p.read_bytes();lines=data.splitlines(keepends=True);assert 1<=lo<=hi<=len(lines)
start=sum(map(len,lines[:lo-1]));end=sum(map(len,lines[:hi]));chunk=data[start:end];assert len(chunk)<=256*1024
ledger=W/'read-binding.json';rows=json.loads(ledger.read_text()) if ledger.exists() else [];(W/'reads').mkdir(exist_ok=True);out=W/'reads'/('%03d.txt'%(len(rows)+1));assert not out.exists();out.write_bytes(chunk)
rows.append({'source':str(p.relative_to(W)),'source_bytes':len(data),'source_sha256':hashlib.sha256(data).hexdigest(),'lines':[lo,hi],'byte_range':[start,end],'path':str(out.relative_to(W)),'bytes':len(chunk),'sha256':hashlib.sha256(chunk).hexdigest()});ledger.write_text(json.dumps(rows,indent=2)+'\n')
for n,line in enumerate(chunk.decode().splitlines(),lo):print('%d: %s'%(n,line))
