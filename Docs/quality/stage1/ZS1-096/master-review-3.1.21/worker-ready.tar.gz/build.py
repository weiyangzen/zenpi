from pathlib import Path
import json,hashlib,difflib,re
W=Path(__file__).resolve().parent
capture=json.loads((W/'capture.json').read_text());report_name=capture['report']
def identity(data):return {'bytes':len(data),'lines':len(data.splitlines()),'sha256':hashlib.sha256(data).hexdigest()}
def save(name,data):(W/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
body=(W/'report-body.md').read_text();body='\n'.join(line.replace('`| `','`\\| `') if line.startswith('|') else line for line in body.splitlines())+'\n'
maps=[]
for line in body.splitlines():
 if re.match(r'\| M\d\d ',line):
  cols=[col.strip() for col in line.strip('|').split('|')];assert len(cols)==3;maps.append({'id':cols[0].split()[0],'topic':cols[0][4:],'source':cols[1],'target':cols[1],'owners':cols[1].split('；')[-1],'criterion':cols[2]})
assert len(maps)==18
save('operation-maps.json',maps)
fns=json.loads((W/'function-bindings.json').read_text());tests=json.loads((W/'source-tests.json').read_text());units=json.loads((W/'semantic-units.json').read_text())
body+='\n## 完整函数声明索引\n\n下列67个fn按当前源码位置列出，同名方法依行号区分；42生产、2测试helper、23源测试。索引包括每个函数体hash绑定的unit与语义映射，具体输入、状态、边界和测试判据见正文，不以符号清单代替学习。\n\n| 函数 | 行区间 | 分类 | unit / map |\n|---|---|---|---|\n'
for row in fns:body+='| `%s` | %d–%d | %s | %s / %s |\n'%(row['name'],*row['lines'],row['kind'],row['unit'],row['map'])
p=W/'candidate'/report_name;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_text(body);body_lines=body.splitlines(True)
(W/'report.patch').write_text(''.join(difflib.unified_diff([],body_lines,fromfile='/dev/null',tofile='b/'+report_name)))
(W/'rollback.patch').write_text(''.join(difflib.unified_diff(body_lines,[],fromfile='a/'+report_name,tofile='/dev/null')))
source=(W/'capture/zenpi/src/render.rs').read_bytes();reads=json.loads((W/'read-binding.json').read_text())
save('analysis-summary.json',{'item':'ZS1-096','subject':identity(source),'formal_reads':7,'all_read_records':len(reads),'semantic_units':len(units),'functions':len(fns),'production_functions':42,'test_helpers':2,'source_tests':len(tests),'ordinary_assert_sites':sum(r['ordinary_assert_sites'] for r in tests),'snapshot_sites':0,'operation_maps':len(maps),'runtime_executions':0,'report':identity(p.read_bytes()),'patch':identity((W/'report.patch').read_bytes()),'rollback':identity((W/'rollback.patch').read_bytes()),'scope':'one owned report creation; no main product, authority, receipts or claims changes'})
save('authority-selection.json',{'item':'ZS1-096','formal_source':'current main render.rs explicitly assigned','baseline_identity_unchanged':json.loads((W/'baseline-comparison.json').read_text())['baseline'],'blueprint_capture':next(r for r in capture['files'] if r['path'].endswith('stage_1_v3_pi_mono_blueprint.md')),'active_requirement_captured':json.loads((W/'capture/zenpi/Docs/execution/active_requirement.json').read_text()),'owned_paths':[report_name],'semantic_acceptance':'master required; structural audit is not G-FILE or G-STAGE acceptance'})
print((W/'analysis-summary.json').read_text())
