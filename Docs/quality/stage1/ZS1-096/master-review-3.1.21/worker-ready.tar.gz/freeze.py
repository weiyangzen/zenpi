from pathlib import Path
import json,hashlib,datetime,shutil
W=Path(__file__).resolve().parent;PACKAGE=W.with_name(W.name+'-ready')
def identity(path):
 data=path.read_bytes();return {'bytes':len(data),'lines':len(data.splitlines()),'sha256':hashlib.sha256(data).hexdigest()}
def inventory(root):return {str(p.relative_to(root)):identity(p) for p in sorted(root.rglob('*')) if p.is_file() and not p.is_symlink()}
def save(name,data):(W/name).write_text(json.dumps(data,indent=2)+'\n')
assert not PACKAGE.exists()
before=json.loads((W/'preservation-before.json').read_text());differences=[]
for origin,old in before['ready'].items():
 current=inventory(Path(origin))
 if current!=old:differences.append({'ready':origin,'missing':sorted(set(old)-set(current)),'added':sorted(set(current)-set(old)),'changed':[p for p in old.keys()&current.keys() if old[p]!=current[p]]})
for name,old in before['tracked'].items():
 if not Path(name).is_file() or identity(Path(name))!=old:differences.append({'tracked':name})
history=json.loads((W/'external-preservation-before.json').read_text())
for row in history:
 if inventory(Path(row['origin']))!=row['files']:differences.append({'external':row['origin']})
save('preservation-after.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'old_ready_count':len(before['ready']),'old_regular_count':sum(map(len,before['ready'].values())),'tracked_count':len(before['tracked']),'external_regular_count':sum(len(r['files']) for r in history),'differences':differences});assert not differences,differences
capture=json.loads((W/'capture.json').read_text());origins=[]
for row in capture['files']:
 path=Path(row['origin']);current=identity(path) if path.is_file() else None;old={k:row[k] for k in ['bytes','lines','sha256']};origins.append({'capture':row['path'],'origin':row['origin'],'captured':old,'at_freeze':current,'unchanged':old==current})
formal=next(r for r in origins if r['capture']=='capture/zenpi/src/render.rs');assert formal['unchanged'];assert not(Path('/Users/wangweiyang/GitHub/zenpi')/capture['report']).exists()
save('freeze-origin-identities.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'formal_source_unchanged':formal['unchanged'],'files':origins,'drift':[r['capture'] for r in origins if not r['unchanged']]})
shutil.copytree(W,PACKAGE);(PACKAGE/'candidate').rename(PACKAGE/'files');manifest={'schema':'zs1-096-render321/v1','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'owned_paths':[capture['report']],'files':inventory(PACKAGE)};(PACKAGE/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for path in PACKAGE.rglob('*'):
 assert not path.is_symlink();path.chmod(0o555 if path.is_dir() else 0o444)
PACKAGE.chmod(0o555)
print(json.dumps({'package':str(PACKAGE),'payload_regular':len(manifest['files']),'manifest':identity(PACKAGE/'manifest.json'),'preservation':json.loads((W/'preservation-after.json').read_text()),'origin_drift':[r['capture'] for r in origins if not r['unchanged']]},indent=2))
