# ZS1-059 independent directory candidate

Only candidate: report/Docs/learn/stage1_pi_mono/packages/ai/src/current_folder_learn.md. report.patch creates exactly that one path from an absent base; no source, receipts, status or checker writes.

Review the Chinese report before relying on integrity results. Important distinctions: Models versus compat; auth and model publication ownership; synchronous/async failure boundaries; image no-auth Promise rejection hole (static, unexecuted); historical055 probe scope. Formal children015/055 already have independent accepted receipts;059/062 remain pending at capture.

Evidence: 19 files +5 directories,38 exact source copies,37 newly read context files/4663lines,015 complete-reading reuse,88 receipt artifacts,055 original1028-payload archive and selected unchanged historical probe/log. Remaining context identities and target snapshots do not imply complete reading or product acceptance. Prior failures remain in their original artifacts/archive.

Portable read-only audit: python3 /absolute/path/to/copied-ready/verify.py, preferably with cwd outside the copied directory. Redirect stdout/stderr outside ready. Python standard library only; does not use original machine paths, execute historical code, import SDKs, run products/builds/tests/network or modify the packet. Manifest excludes itself and external run logs. Integrity checks do not prove behavioral correctness. Actual worker run records are in the separate source059-directory-3.1.21 work directory.

frozen117-observation.json records readonly protection of both old117 packages and retained fixture; verify.py checks captured observations only, while final-observation.json records the actual final live check. No117/131/FIFO/DTrace or runtime gate work occurred in059.

The first167-payload packet is preserved unchanged in source059-directory-3.1.21-ready. Its audit failed because a first split selected an interface signature; this independent corrected packet uses the last match. initial-audit retains the first manifest, changed original files and exact failed logs, allowing the verifier to reconstruct every first-packet payload identity without machine paths. No source/runtime changes.
