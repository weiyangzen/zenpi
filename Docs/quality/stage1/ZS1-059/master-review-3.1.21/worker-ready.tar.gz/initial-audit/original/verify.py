#!/usr/bin/env python3
"""Portable read-only059 evidence audit; does not execute any captured program."""
from pathlib import Path,PurePosixPath
import hashlib,json,tarfile,io,csv,difflib,re
R=Path(__file__).resolve().parent
checks=[]
def check(name,value):
 if not value:raise AssertionError(name)
 checks.append(name)
def raw(rel):
 p=PurePosixPath(rel)
 if p.is_absolute() or '..' in p.parts:raise AssertionError('unsafe relative path')
 f=R.joinpath(*p.parts)
 if any(x.is_symlink() for x in [f,*f.parents]):raise AssertionError('symlink input')
 return f.read_bytes()
def js(p):return json.loads(raw(p))
def txt(p):return raw(p).decode()
def ident(b,r):return len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256']
mf=js('manifest.json');rows=mf['files'];cap=js('capture.json')
check('outer unique payloads',len(rows)==len({r['path'] for r in rows}))
check('outer every payload identity',all(ident(raw(r['path']),r) for r in rows))
check('outer exact file set',{str(p.relative_to(R)) for p in R.rglob('*') if p.is_file()}=={r['path'] for r in rows}|{'manifest.json'})
owned='Docs/learn/stage1_pi_mono/packages/ai/src/current_folder_learn.md'
check('059 sole candidate zero runtime',mf['candidate_paths']==[owned] and mf['runtime_executions_this_round']==0 and cap['runtime_executions_this_round']==0)
check('initial059 absent',not cap['current059receipt_present'] and not cap['current059report_present'])
for d in cap['accepted_dependencies']:
 p='accepted/'+d['receipt'];a=js(p)
 check(d['item']+' receipt identity',ident(raw(p),d))
 check(d['item']+' current accepted binding',a['complete'] and a['manual_review']['decision']=='accepted' and all(a[k]==mf[k] for k in ['requirement_digest','baseline_snapshot_sha256','run_id']))
 check(d['item']+' exact artifact chain',len(a['artifacts'])==d['artifact_count'] and all(ident(raw('accepted/'+x['path']),x) for x in a['artifacts']))
check('88 direct dependency artifacts',sum(x['artifact_count'] for x in cap['accepted_dependencies'])==88)
p15='accepted/Docs/quality/stage1/ZS1-015/master-review-3.1.20/worker-package/'
m15=js(p15+'manifest.json')
check('015 historical payload copies',len(m15['files'])==30 and all(ident(raw(p15+'files/'+x['path']),x) for x in m15['files']))
check('015 historical candidate patch hash',hashlib.sha256(raw(p15+'candidate.patch')).hexdigest()==m15['patch_sha256'])
check('015 historical per-file patches',all(hashlib.sha256(raw(p15+x['patch_file'])).hexdigest()==x['patch_sha256'] for x in m15['files']))
t15=p15+'files/Docs/quality/stage1/ZS1-015/worker-types319/'
source=raw('source/packages/ai/src/types.ts');r15=js('accepted/Docs/learn/stage1_pi_mono/receipts/ZS1-015.master.json')
check('015 exact accepted current source',raw(t15+'types.ts')==source and hashlib.sha256(source).hexdigest()==r15['source_hash'])
ranges=r15['read_ranges']
check('015 contiguous full881-line read reuse',ranges==[[0,8064],[8064,15965],[15965,28201],[28201,37411]] and len(source.splitlines())==881)
names=['read-0001-0220.txt','read-0221-0440.txt','read-0441-0660.txt','read-0661-0881.txt']
check('015 four byte exact full reading slices',all(raw(t15+n)==source[a:b] for n,(a,b) in zip(names,ranges)))
p55='accepted/Docs/quality/stage1/ZS1-055/master-review-3.1.21/'
with tarfile.open(fileobj=io.BytesIO(raw(p55+'worker-ready.tar.gz')),mode='r:gz') as t:
 members=t.getmembers();names=[x.name for x in members]
 check('055 archive safe unique regular members',len(names)==len(set(names)) and all(x.isfile() and not PurePosixPath(x.name).is_absolute() and '..' not in PurePosixPath(x.name).parts for x in members))
 blobs={x.name:t.extractfile(x).read() for x in members};am=json.loads(blobs['manifest.json'])
 check('055 original manifest byte identity',blobs['manifest.json']==raw(p55+'worker-manifest.json'))
 check('0551028 exact payloads',len(am['files'])==1028 and set(names)=={x['path'] for x in am['files']}|{'manifest.json'} and all(ident(blobs[x['path']],x) for x in am['files']))
 for n in ['direct-inventory.json','input-inventory.json','old-current-drift.json','capture.json']:
  check('055 copied observation '+n,raw('accepted055-observations/'+n)==blobs[n])
 hp='historical055/files/Docs/quality/stage1/ZS1-055/worker-directory-review/'
 check('055 old probe command log exact',all(raw('historical055-selected/'+n)==blobs[hp+n] for n in ['probe.ts','lazy-native.json','lazy-native.log']))
 check('055 historical029 pending capture preserved',json.loads(blobs['capture.json'])['dependencies']['029']['receipt_exists'] is False)
 for n in ['016','017','029']:
  a=js(p55+'current-child-receipts/ZS1-'+n+'.master.json')
  check('055 current accepted child'+n,a['complete'] and a['manual_review']['decision']=='accepted' and a['requirement_digest']==mf['requirement_digest'])
 invold=json.loads(blobs['input-inventory.json']);drift=js('accepted055-current-drift.json')
 check('055 current identity comparison exact47',len(invold)==len(drift)==47 and all(x['path']==d['archive_member'] and x['origin']==d['origin'] and all(x[k]==d['old'][k] for k in ['bytes','sha256']) and d['unchanged']==(d['old']==d['current']) for x,d in zip(invold,drift)))
 check('055 only already qualified headless drift',[x['archive_member'] for x in drift if not x['unchanged']]==['target/src/headless.rs'])
 check('055 preserved current target identities',all(ident(raw('current-target-identities/'+x['archive_member'][7:]),x['current']) for x in drift if x['archive_member'].startswith('target/')))
check('055 canonical preserves worker prefix',raw('accepted/Docs/learn/stage1_pi_mono/packages/ai/src/api/current_folder_learn.md').startswith(raw(p55+'worker-report.md')))
src=js('source-identities.json');reads=js('read-ranges.json')
check('38 exact source copies',len(src)==38 and all(ident(raw(x['evidence_path']),x) and len(raw(x['evidence_path']).splitlines())==x['lines'] for x in src))
check('37 complete new reads4663lines',len(reads)==37 and sum(x['lines'] for x in reads)==4663 and all(x['read_ranges']==[[0,x['bytes']]] and x['line_ranges']==[[1,x['lines']]] and not x['formal_acceptance'] and x['path']!='packages/ai/src/types.ts' for x in reads))
check('new read identities match copies',all(any(all(s[k]==x[k] for k in ['path','bytes','sha256','lines','evidence_path']) for s in src) for x in reads))
inv=js('direct-inventory.json')
check('physical19files5dirs',len(inv)==24 and sum(x['kind']=='file' for x in inv)==19 and sum(x['kind']=='directory' for x in inv)==5)
check('exact formal015055',{x['name']:x['formal_item'] for x in inv if x['formal_item']}=={'types.ts':'ZS1-015','api':'ZS1-055'})
check('all direct file copies match',all(ident(raw('source/'+x['path']),x) for x in inv if x['kind']=='file'))
api=next(x for x in inv if x['name']=='api')['direct_children'];oldapi=js('accepted055-observations/direct-inventory.json')
check('055 actual32-entry identity reuse',len(api)==len(oldapi)==32 and all(all(x[k]==y[k] for k in ['name','path','kind','bytes','sha256','lines']) for x,y in zip(api,oldapi)))
check('next-layer directory census',{x['name']:(sum(y['kind']=='file' for y in x['direct_children']),sum(y['kind']=='directory' for y in x['direct_children'])) for x in inv if x['kind']=='directory'}=={'api':(32,0),'auth':(5,1),'compat':(1,0),'providers':(87,1),'utils':(23,0)})
fi=list(csv.DictReader(io.StringIO(txt('authority/Docs/learn/stage1_pi_mono/file_learn_index.tsv')),delimiter='\t'))
di=list(csv.DictReader(io.StringIO(txt('authority/Docs/learn/stage1_pi_mono/folder_learn_index.tsv')),delimiter='\t'))
check('formal file scope from authority',{x['item_id'] for x in fi if str(PurePosixPath(x['source_path']).parent)=='packages/ai/src'}=={'ZS1-015'})
check('formal folder scope from authority',{x['item_id'] for x in di if str(PurePosixPath(x['folder_path']).parent)=='packages/ai/src'}=={'ZS1-055'})
d59=next(x for x in di if x['item_id']=='ZS1-059')
check('059 scope dependency status',d59['depends']=='ZS1-015,ZS1-055' and d59['folder_artifact']==owned and d59['status']=='[ ]')
check('062 pending separate owner',next(x for x in di if x['item_id']=='ZS1-062')['status']=='[ ]')
sel=js('authority/Docs/execution/active_requirement.json')
check('selector frozen authority keys',sel['blueprint_version']=='3.1.21' and all(sel[k]==mf[k] for k in ['requirement_digest','baseline_snapshot_sha256','run_id']) and sel['baseline_files']['ZS1-015']['sha256']==r15['source_hash'])
check('initial authority full copied identities',all(ident(raw('authority/'+x['path']),x) for x in cap['authority']))
final=js('final-observation.json')
check('final source identities unchanged',final['source_copies_unchanged'] and final['direct_inventory_unchanged'] and final['accepted_dependencies_unchanged'])
check('final local scope unchanged',final['relevant_authority_rows_unchanged'] and final['authority_keys_unchanged'] and final['worker_status_unchanged'] and final['worker_status_rows']==94)
check('frozen117 and fixture preserved',final['frozen117_unchanged'] and len(js('frozen117-observation.json'))==3)
check('final authority identity copies',all(ident(raw('authority-final/'+x['path']),x) for x in final['authority']))
s='source/packages/ai/src/';models=txt(s+'models.ts');images=txt(s+'images-models.ts');compat=txt(s+'compat.ts')
check('models cached phase and generation anchors',all(x in models for x in ['new InMemoryCredentialStore()','new InMemoryModelsStore()','private refreshGenerations','private publicationChains','this.runProviderRefreshPhase(provider, storedCredential, false','publication.update?.()']))
check('models getAvailable direct provider call', 'const models = provider.getModels();' in models.split('getAvailable(providerId?:')[1])
check('text header and auth transform anchors',all(x in models for x in ['name.toLowerCase()','existingName.toLowerCase()','providerOrModel.headers','transformHeaders','resolveProviderAuth']))
check('image await asymmetry actual source', 'if (!auth) {\n\t\t\t\treturn provider.generateImages(model, context, options);\n\t\t\t}' in images and 'return await provider.generateImages(requestModel' in images and 'Never rejects' in images)
check('image refresh allSettled and plain headers', 'Promise.allSettled' in images and '{ ...auth.headers, ...options?.headers }' in images)
check('compat instance comparison and registration',all(x in compat for x in ['if (!getApiProvider(api))','builtinApiProviderInstances.set(api, getApiProvider(api))','getApiProvider(model.api) !== builtinApiProviderInstances.get(model.api)','const compatModels = builtinModels();']))
check('actual OpenAI Responses default','api: openAIResponsesApi()' in txt(s+'providers/openai.ts'))
check('actual OpenRouter API map',all(x in txt(s+'providers/openrouter.ts') for x in ['"anthropic-messages": anthropicMessagesApi()','"openai-completions": openAICompletionsApi()']))
check('cost and thinking limited predicates',all(x in models for x in ['inputTokens > tier.inputTokensAbove','usage.cacheWrite - longWrite','rates.input * 2 * longWrite','level === "xhigh" || level === "max"','return a.id === b.id && a.provider === b.provider']))
check('image catalog negative sentinel retained','-1000000' in txt(s+'image-models.generated.ts'))
check('credential versus model store clone difference','structuredClone' not in txt(s+'auth/credential-store.ts') and 'structuredClone' in txt(s+'models-store.ts'))
check('cleanup synchronous aggregate errors','AggregateError' in txt(s+'session-resources.ts') and 'await ' not in txt(s+'session-resources.ts'))
pkg=js('source/packages/ai/package.json')
check('package entry distinctions',pkg['version']=='0.85.1' and pkg['exports']['.']['import']=='./dist/index.js' and pkg['exports']['./compat']['import']=='./dist/compat.js' and pkg['bin']['pi-ai']=='dist/cli.js' and len(pkg['sideEffects'])==3)
log=raw('historical055-selected/lazy-native.log');run=js('historical055-selected/lazy-native.json');events=[json.loads(x) for x in log.splitlines()]
check('old055 actual log receipt hash',ident(log,run) and run['exit_code']==0 and run['started_at'].startswith('2026-09-10T23:25:58'))
check('old055 nine scenarios three HTTP',len(events)==10 and events[-1]['cases']==9 and events[-1]['httpRequests']==3 and sum(x['httpRequests'] for x in events[:-1])==3 and all(x['status']=='pass' for x in events))
check('old055 probe assertion scope','assert.equal(api.cancelDeferred, undefined)' in txt('historical055-selected/probe.ts') and 'api.fetchDeferred' not in txt('historical055-selected/probe.ts'))
report=txt('report/'+owned)
check('single exact forward reverse report patch',txt('report.patch')==''.join(difflib.unified_diff([],report.splitlines(True),fromfile='/dev/null',tofile='b/'+owned)))
added=''.join(x[1:] for x in txt('report.patch').splitlines(True)[3:])
check('new report patch byte reconstruction and empty base',added==report and ''.join([])=='')
check('report non-runtime qualifications',all(x in report for x in ['尚未运行复现','本轮运行行为测试数为0','062仍需自己的目录整合审阅','4663行','Never rejects']))
print(json.dumps(dict(ok=True,checks=len(checks),payloads=len(rows),accepted_artifacts=88,accepted055_archive_payloads=1028,new_full_source_reads=37,new_full_source_lines=4663,runtime_executions_this_round=0,checks_performed=checks),ensure_ascii=False,indent=2))
