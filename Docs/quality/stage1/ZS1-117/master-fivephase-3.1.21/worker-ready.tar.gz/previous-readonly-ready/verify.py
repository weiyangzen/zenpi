"""Offline artifact integrity/arithmetic only; no product/system-diagnostic execution."""
from pathlib import Path
import hashlib,json,base64
R=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((R/'manifest.json').read_text())
assert not m['root_cause_proven'] and not m['product_changes'] and not m['master_accepted'] and m['new_product_executions']==0
actual={str(p.relative_to(R)) for p in R.rglob('*') if p.is_file() and p.name!='manifest.json'}
assert actual==set(m['artifacts'])
for name,r in m['artifacts'].items():
 p=Path(name);assert not p.is_absolute() and '..' not in p.parts;b=(R/p).read_bytes();assert len(b)==r['bytes'] and sha(b)==r['sha256']
E=R/'evidence';d=json.loads((E/'original/summary.json').read_text());run=json.loads((E/'original/budget.run.json').read_text());log=(E/'original/budget.log').read_bytes()
assert run['exit_code']==1 and sha(log)==run['log_sha256'] and json.loads(log[log.index(b'{\n'):])==d
assert d['budgets']['cold_start_max_ms_max']==1000 and not d['ok'] and not d['gates']['cold_start'] and sum(d['gates'].values())==7
assert d['cold_start']['elapsed_ms']['samples']==[1109.425125,42.552459,42.5525]
assert sha((E/'original/zenpi').read_bytes())==m['measured_binary_sha256']==d['cold_start']['binary_sha256']
for i in range(3):
 s=json.loads((E/f'original/startup/sample-{i:02}.json').read_text());assert s==d['cold_start']['observations'][i]
 for name in ['stdout','stderr']:
  b=base64.b64decode(s[name]['prefix_base64']);assert not s[name]['truncated'] and len(b)==s[name]['bytes'] and sha(b)==s[name]['sha256'];assert b==(E/f'original/startup/sample-{i:02}.{name}.log').read_bytes()
reads=json.loads((E/'reading-coverage.json').read_text())
for r in reads['full_read']:
 b=(E/r['copy']).read_bytes();assert sha(b)==r['sha256'] and len(b)==r['bytes'];cursor=0
 for z in r['reads']:assert z['start_byte']==cursor and z['end_byte']>cursor and sha(b[cursor:z['end_byte']])==z['sha256'];cursor=z['end_byte']
 assert cursor==len(b)
for r in reads['bounded']:
 b=(E/r['copy']).read_bytes();assert len(b)==r['bytes'] and sha(b)==r['sha256']
receipts=list((E/'commands').glob('*.json'));assert len(receipts)==10
for p in receipts:
 r=json.loads(p.read_text());assert r['exit_code']==0 and not r['timed_out']
 for key in ['stdout','stderr']:
  t=r[key];b=(E/t['path']).read_bytes();assert len(b)==t['bytes'] and sha(b)==t['sha256']
t=json.loads((E/'mach-timebase.json').read_text());a=json.loads((E/'analysis.json').read_text());assert t['return_code']==0 and t['numer']==125 and t['denom']==3
raw=[]
for name in ['startup-policy-window','startup-exact-path-token']:raw+=json.loads((E/f'commands/{name}.stdout.log').read_text())
raw=sorted({(e['machTimestamp'],e['eventMessage']):e for e in raw}.values(),key=lambda e:e['machTimestamp']);assert len(raw)==6
assert [(e['machTimestamp'],e['eventMessage']) for e in raw]==[(e['machTimestamp'],e['eventMessage']) for e in a['system_events']]
start=next(e for e in raw if e['eventMessage'].startswith('GK performScan:'));end=next(e for e in raw if e['eventMessage'].startswith('GK evaluateScanResult:'))
ms=(end['machTimestamp']-start['machTimestamp'])*t['numer']/t['denom']/1e6;assert ms==1044.2375==a['scan_to_evaluate_ms']
assert all(e['bootUUID']=='FED0AF13-2278-4483-A836-B2FAD5427DA6' for e in raw)
print(json.dumps({'passed':True,'manifest_sha256':sha((R/'manifest.json').read_bytes()),'artifacts':len(actual),'diagnosis_sha256':sha((R/'diagnosis.md').read_bytes()),'plan_sha256':sha((R/'experiment-plan.md').read_bytes()),'original_budget_exit':1,'original_cold_gate_still_failed':True,'full_read_files':len(reads['full_read']),'bounded_excerpts':len(reads['bounded']),'read_only_system_command_receipts':len(receipts),'scan_to_result_ms':ms,'root_cause_proven':False,'new_product_executions':0},indent=2))
