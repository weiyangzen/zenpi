from pathlib import Path
import json,hashlib
W=Path(__file__).resolve().parent;M=Path('/Users/wangweiyang/GitHub/zenpi');sha=lambda b:hashlib.sha256(b).hexdigest()
full=[]
for rel,spans in [('src/main.rs',[(1,11)]),('tools/bench_runtime.py',[(1,240),(241,338)]),('tools/runtime_budget_probe.rs',[(1,104)]),('tools/test_bench_runtime.py',[(1,90)]),('Cargo.toml',[(1,51)])]:
 p=W/'source'/rel;b=p.read_bytes();ls=b.splitlines(keepends=True)
 if rel=='Cargo.toml':spans=[(1,len(ls))]
 assert b==(M/rel).read_bytes()
 row={'path':rel,'copy':str(p.relative_to(W)),'sha256':sha(b),'bytes':len(b),'lines':len(ls),'scope':'full actual read this turn; no owner acceptance or execution','reads':[]}
 for lo,hi in spans:
  a=sum(map(len,ls[:lo-1]));z=sum(map(len,ls[:hi]));row['reads'].append({'start_line':lo,'end_line':hi,'start_byte':a,'end_byte':z,'sha256':sha(b[a:z])})
 assert row['reads'][0]['start_byte']==0 and row['reads'][-1]['end_byte']==len(b)
 full.append(row)
specs=[('core',5850,5867),('core',6073,6129),('core',5422,5498),('core',5598,5681),('core',5710,5849),('core',2151,2188),('core',2271,2318),('core',6347,6376),('core',6390,6424),('config',148,201),('config',713,749),('config',777,827),('config',1619,1653),('session',407,450),('session',511,597),('headless',774,842),('headless',4272,4366),('headless',4715,4753),('headless',5007,5031),('headless',6220,6245)]
refs=[]
for i,(owner,lo,hi) in enumerate(specs,1):
 p=M/'src'/f'{owner}.rs';b=p.read_bytes();ls=b.splitlines(keepends=True);a=sum(map(len,ls[:lo-1]));z=sum(map(len,ls[:hi]));q=W/'context'/f'C{i:02}-{owner}-{lo}-{hi}.txt';q.parent.mkdir(exist_ok=True);q.write_bytes(b[a:z]);refs.append({'id':f'C{i:02}','source':str(p),'source_bytes':len(b),'source_sha256':sha(b),'start_line':lo,'end_line':hi,'start_byte':a,'end_byte':z,'copy':str(q.relative_to(W)),'bytes':z-a,'sha256':sha(b[a:z]),'scope':'actual bounded reading only; not entire dependency owner'})
(W/'reading-coverage.json').write_text(json.dumps({'full_read':full,'bounded':refs,'note':'source printed by read-only shell commands; raw chunks frozen with exact byte hashes; no product/test run'},indent=2)+'\n')
print('Full files',len(full),'bounded context',len(refs))
