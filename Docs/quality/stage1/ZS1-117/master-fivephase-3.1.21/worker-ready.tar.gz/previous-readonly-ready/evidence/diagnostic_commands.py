from pathlib import Path
import json,subprocess,datetime,hashlib
W=Path(__file__).resolve().parent
D=W/'commands';D.mkdir(exist_ok=True)
def run(label,argv,timeout=45):
 assert not (D/(label+'.json')).exists()
 now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();start=now()
 try:
  p=subprocess.run(argv,capture_output=True,timeout=timeout);rc=p.returncode;out=p.stdout;err=p.stderr;timedout=False
 except subprocess.TimeoutExpired as e:rc=None;out=e.stdout or b'';err=e.stderr or b'';timedout=True
 r={'argv':argv,'cwd':str(Path.cwd()),'started_at':start,'ended_at':now(),'exit_code':rc,'timed_out':timedout,'scope':'read-only diagnosis; no zenpi/build/benchmark execution'}
 for name,b in [('stdout',out),('stderr',err)]:
  q=D/(label+'.'+name+'.log');q.write_bytes(b);r[name]={'path':str(q.relative_to(W)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 (D/(label+'.json')).write_text(json.dumps(r,indent=2)+'\n')
 print(label,'exit',rc,'stdout',out.decode(errors='replace')[:8000],'stderr',err.decode(errors='replace')[:4000])
if __name__=='__main__':
 binary='/Users/wangweiyang/GitHub/zenpi/target/release/zenpi'
 frozen='/Users/wangweiyang/GitHub/zenpi/.ops/stage1_execution/release-diff-20260912/zenpi'
 run('platform',['/usr/bin/sw_vers'])
 run('binary-file',['/usr/bin/file',binary,frozen])
 run('signature-display',['/usr/bin/codesign','--display','--verbose=4',binary])
 run('frozen-signature-display',['/usr/bin/codesign','--display','--verbose=4',frozen])
 run('xattr-names',['/usr/bin/xattr',binary])
 run('frozen-xattr-names',['/usr/bin/xattr',frozen])
 run('linked-libraries',['/usr/bin/otool','-L',binary])
