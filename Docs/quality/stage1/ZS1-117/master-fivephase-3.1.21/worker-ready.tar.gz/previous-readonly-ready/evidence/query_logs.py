from diagnostic_commands import run
# A four-second historical window around the three recorded launches; only exact product-name/CodeDirectory events.
run('startup-policy-window',['/usr/bin/log','show','--style','json','--start','2026-09-12 23:09:49','--end','2026-09-12 23:09:53','--info','--debug','--predicate','eventMessage CONTAINS[c] "zenpi" OR eventMessage CONTAINS[c] "f64dff4ca0096b87915790873ff0ec43715612d6"'],45)
