from diagnostic_commands import run
run('startup-exact-path-token',['/usr/bin/log','show','--style','json','--start','2026-09-12 23:09:49','--end','2026-09-12 23:09:53','--info','--debug','--predicate','eventMessage CONTAINS[c] "ba2be7534db6fb27"'],45)
run('boot-identity',['/usr/sbin/sysctl','kern.bootsessionuuid'])
