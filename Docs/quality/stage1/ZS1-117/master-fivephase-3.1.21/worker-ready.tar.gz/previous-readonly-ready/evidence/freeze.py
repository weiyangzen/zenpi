from pathlib import Path
import json,hashlib,datetime,base64
W=Path(__file__).resolve().parent;M=Path('/Users/wangweiyang/GitHub/zenpi');A=M/'.ops/stage1_execution/release-diff-20260912';sha=lambda b:hashlib.sha256(b).hexdigest();records={}
def copy(p,d):
 b=p.read_bytes();q=W/d;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);records[str(p)]={'copy':str(d),'bytes':len(b),'sha256':sha(b)}
for p in [A/'summary.json',A/'budget.run.json',A/'budget.log',A/'inputs-before.json',*sorted((A/'startup').glob('*.json')),A/'zenpi']:copy(p,Path('original')/p.relative_to(A))
for p in [A/'host-processes-before.log',A/'host-processes-after.log']:
 b=p.read_bytes();records[str(p)]={'bytes':len(b),'sha256':sha(b),'scope':'hash only; full unrelated process command lines not copied or read'}
 # Limit content to the exact benchmark script/root and named wrapper PIDs; not broad host process disclosure.
 lines=[x for x in b.decode().splitlines() if 'tools/bench_runtime.py --samples 3' in x or any((' '+str(pid)+' ') in x for pid in [87568,87572,87574]) or '/Users/wangweiyang/GitHub/zenpi/target/release/zenpi ' in x]
 q=W/'original'/p.name;q.write_text('\n'.join(lines)+'\n');records[str(p)]['selected_copy']=str(q.relative_to(W))
for rel in ['src/main.rs','tools/bench_runtime.py','tools/runtime_budget_probe.rs','tools/test_bench_runtime.py','Cargo.toml','.cargo/config.toml']:
 p=M/rel
 if p.is_file():copy(p,Path('source')/rel)
for rel in ['Docs/quality/stage1/ZS1-117/master-startup-diagnosis-3.1.20/review.md','.ops/stage1_execution/controller_checkpoint-20260912-source023-unborn-diff.md','.ops/stage1_execution/controller_checkpoint-20260912-editor130-binary112.md','.ops/stage1_execution/controller_checkpoint-20260912-release-background.md']:
 copy(M/rel,Path('history')/Path(rel).name)
inputs=json.loads((A/'inputs-before.json').read_text());checks=[]
for r in inputs:
 p=M/r['path'];b=p.read_bytes() if p.is_file() else None
 checks.append({'path':r['path'],'frozen':r,'current_bytes':len(b) if b is not None else None,'current_sha256':sha(b) if b is not None else None,'exact':b is not None and len(b)==r['bytes'] and sha(b)==r['sha256']})
(W/'build-input-check.json').write_text(json.dumps(checks,indent=2)+'\n')
for p in [A/'zenpi',M/'target/release/zenpi']:
 b=p.read_bytes();s=p.stat();records[str(p)]={**records.get(str(p),{}),'bytes':len(b),'sha256':sha(b),'mode':oct(s.st_mode),'inode':s.st_ino,'device':s.st_dev,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,'birthtime':getattr(s,'st_birthtime',None)}
assert records[str(A/'zenpi')]['sha256']=='e9ba9476f7699d715ad3b0b5fe4a07aeee9f280508d3cb495d59cfa94fff6449'
(W/'inputs.json').write_text(json.dumps({'captured_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'records':records},indent=2)+'\n')
old={str(p.relative_to(W.parent.parent)):{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for root in sorted(W.parent.glob('*ready')) if root.is_dir() for p in sorted(root.rglob('*')) if p.is_file()}
(W/'old-ready-inventory.json').write_text(json.dumps(old,indent=2)+'\n')
for p in sorted((W/'original/startup').glob('*.json')):
 d=json.loads(p.read_text())
 for name in ['stdout','stderr']:
  b=base64.b64decode(d[name]['prefix_base64']);assert not d[name]['truncated'] and sha(b)==d[name]['sha256'] and len(b)==d[name]['bytes'];(p.parent/(p.stem+'.'+name+'.log')).write_bytes(b)
print(json.dumps({'frozen':len(records),'build_inputs':len(checks),'input_drift':[r['path'] for r in checks if not r['exact']],'old_ready_files':len(old),'binary_identities':{str(p):records[str(p)] for p in [A/'zenpi',M/'target/release/zenpi']}},indent=2))
