from pathlib import Path
import json,hashlib,base64,datetime,ctypes
W=Path(__file__).resolve().parent;M=Path('/Users/wangweiyang/GitHub/zenpi');sha=lambda b:hashlib.sha256(b).hexdigest()
class Timebase(ctypes.Structure):_fields_=[('numer',ctypes.c_uint32),('denom',ctypes.c_uint32)]
t=Timebase();lib=ctypes.CDLL('/usr/lib/libSystem.B.dylib');f=lib.mach_timebase_info;f.argtypes=[ctypes.POINTER(Timebase)];f.restype=ctypes.c_int;rc=f(ctypes.byref(t));assert rc==0 and t.denom
(W/'mach-timebase.json').write_text(json.dumps({'read_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'api':'libSystem mach_timebase_info','return_code':rc,'numer':t.numer,'denom':t.denom,'scope':'read-only clock scaling; no target execution'},indent=2)+'\n')
report=json.loads((W/'original/summary.json').read_text());run=json.loads((W/'original/budget.run.json').read_text());log=(W/'original/budget.log').read_bytes();assert sha(log)==run['log_sha256'];assert json.loads(log[log.index(b'{\n'):])==report
rows=[]
for i in range(3):
 s=json.loads((W/f'original/startup/sample-{i:02}.json').read_text());assert s==report['cold_start']['observations'][i]
 out=base64.b64decode(s['stdout']['prefix_base64']);assert json.loads(out)['data']=={'closing':True,'drained':True}
 rows.append({k:s[k] for k in ['index','started_at','ended_at','wrapper_pid','elapsed_ms','popen_return_ms','communicate_ms','process_observed_ms','peak_rss_bytes','returncode','timed_out']});rows[-1]['outer_extra_ms']=s['elapsed_ms']-s['process_observed_ms'];rows[-1]['time_output']=base64.b64decode(s['stderr']['prefix_base64']).decode()
e1=json.loads((W/'commands/startup-policy-window.stdout.log').read_text());e2=json.loads((W/'commands/startup-exact-path-token.stdout.log').read_text());events=sorted({(e['machTimestamp'],e['eventMessage']):e for e in e1+e2}.values(),key=lambda e:e['machTimestamp'])
boot=(W/'commands/boot-identity.stdout.log').read_text().split(': ',1)[1].strip();assert all(e['bootUUID']==boot for e in events)
scan=next(e for e in events if e['eventMessage'].startswith('GK performScan:'))
end=next(e for e in events if e['eventMessage'].startswith('GK evaluateScanResult:'))
wake=next(e for e in events if e['eventMessage'].startswith('scan finished,'))
result={'sample_rows':rows,'gate_unchanged':report['budgets']['cold_start_max_ms_max']==1000 and report['cold_start']['elapsed_ms']['sample_count']==3,'actual_gate_exit':run['exit_code'],'all_raw_sample_receipts_equal_summary':True,'log_hash_and_embedded_summary_exact':True,'system_events':[{'timestamp':e['timestamp'],'machTimestamp':e['machTimestamp'],'processID':e['processID'],'threadID':e['threadID'],'eventMessage':e['eventMessage'],'bootUUID':e['bootUUID']} for e in events],'scan_to_evaluate_ms':(end['machTimestamp']-scan['machTimestamp'])*t.numer/t.denom/1000000,'scan_to_wake_ms':(wake['machTimestamp']-scan['machTimestamp'])*t.numer/t.denom/1000000,'cross_clock_qualification':'System interval is same-boot mach-tick arithmetic. Placement within parent UTC window is wall-clock correlation only; no parent mach epoch recorded. No subtraction from budget; no target PID or Rust main attribution.'}
(W/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
ps=[]
for label in ['before','after']:
 p=M/f'.ops/stage1_execution/release-diff-20260912/host-processes-{label}.log';ls=p.read_text().splitlines();selected=[]
 for n,line in enumerate(ls[1:],2):
  cols=line.split(None,3)
  if len(cols)==4 and Path(cols[3]).name.lower() in ['python','python3','cargo','rustc','zenpi','time']:
   selected.append({'source_line':n,'pid':cols[0],'ppid':cols[1],'cpu_percent_snapshot':cols[2],'executable_basename':Path(cols[3]).name})
 ps.append({'source':str(p),'source_sha256':sha(p.read_bytes()),'header':ls[0],'selected':selected,'scope':'Selected process names only at before/after snapshots; not target-child identity or interval scheduling trace'})
(W/'process-snapshot-summary.json').write_text(json.dumps(ps,indent=2)+'\n')
print(json.dumps({'timebase':[t.numer,t.denom],'scan_to_evaluate_ms':result['scan_to_evaluate_ms'],'scan_to_wake_ms':result['scan_to_wake_ms'],'sample_outer_extra_ms':[r['outer_extra_ms'] for r in rows],'events':len(events),'process_snapshots':ps},indent=2))
