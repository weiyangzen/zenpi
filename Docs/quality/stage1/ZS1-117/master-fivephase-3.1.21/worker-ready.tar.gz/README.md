# ZS1-117 五阶段诊断交付

一次私有构建、一次新产物首启；main 前 935.707583 ms，main 至返回前 40.391917 ms，诊断外层 977.101334 ms。不是正式门禁通过或修复。

先读 diagnosis.md。evidence 保留冻结源码、原始三流、fixture/journal、五阶段时钟、有限清理结果、精确窗口系统日志、并发主机快照、离线失败和主库漂移；previous-readonly-ready 是此前只读诊断的逐字节副本，含原 1109 ms 失败证据。

只允许离线校验：python3 -B verify_offline.py。不要执行 evidence 中的 build_once.py、observe_once.py、run_observer_once.py、prepare.py、system_after.py、system_token_after.py 或二进制；它们是已执行实验的留档，不是重试指令。target 构建缓存不进入包。

verify 输出保存在包外工作根 offline-verification.json。manifest.json 列出所有其余文件的字节数与 SHA-256，自身 hash 在交付消息中提供。主任务尚未接收，root cause 未完全证明，原正式 release 与门禁结果不变。
