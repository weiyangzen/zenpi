"""Package existing evidence and compare files; no builds or product executions."""
from pathlib import Path
import datetime, difflib, hashlib, json, shutil
W = Path(__file__).resolve().parent
ROOT = W.parent.parent
M = Path('/Users/wangweiyang/GitHub/zenpi')
R = W.parent / 'zs1-117-fivephase-ready'
def meta(p):
    b = p.read_bytes()
    return {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}
def write(p, value):
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('x') as f:
        json.dump(value, f, indent=2, ensure_ascii=False); f.write('\n')
assert not R.exists()
before = json.loads((W / 'inputs-before.json').read_text())['files']
after = json.loads((W / 'inputs-diagnostic.json').read_text())['files']
old = json.loads((W / 'old-ready-inventory.json').read_text())
drift = []
for rel, expected in before.items():
    p = M / rel
    actual = meta(p) if p.is_file() else None
    if actual != expected:
        base = W / 'source' / rel
        if rel in ['src/main.rs', 'src/core.rs', 'src/headless.rs']:
            base = W / 'before' / Path(rel).name
        patch = ''.join(difflib.unified_diff(base.read_text().splitlines(True), p.read_text().splitlines(True) if p.is_file() else [], fromfile='frozen/' + rel, tofile='master-current/' + rel))
        q = W / 'master-drift' / (rel + '.patch'); q.parent.mkdir(parents=True, exist_ok=True); q.write_text(patch)
        drift.append({'path': rel, 'frozen': expected, 'current': actual, 'patch': str(q.relative_to(W))})
integrity = {'checked_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'private_input_count': len(after), 'private_inputs_exact': all(meta(W / 'source' / rel) == v for rel, v in after.items()),
    'old_ready_count': len(old), 'old_ready_all_exact': all((ROOT / rel).is_file() and meta(ROOT / rel) == v for rel, v in old.items()),
    'binary_exact': meta(W / 'target/release/zenpi') == meta(W / 'binary/zenpi'),
    'master_drift': drift,
    'qualification': 'Master explicitly reported concurrent headless busy/diff integration and Gantt update. Frozen diagnostic inputs remain untouched. No current-master identity claim or repeated target execution.'}
write(W / 'final-input-integrity.json', integrity)
assert integrity['private_inputs_exact'] and integrity['old_ready_all_exact'] and integrity['binary_exact']
reads = {'scope': 'Full main/emitter/observer/diagnostic diff; bounded core/headless only, no full owner acceptance', 'full': [], 'bounded': []}
for rel in ['before/main.rs', 'source/src/main.rs', 'source/src/startup_phase.rs', 'observe_once.py', 'diagnostic.patch', 'support.py', 'build_once.py', 'run_observer_once.py', 'prepare.py']:
    reads['full'].append({'path': rel, **meta(W / rel), 'lines': len((W / rel).read_text().splitlines()), 'read_in_tool_output': True})
for rel, ranges in [('before/core.rs', [(6073, 6129)]), ('before/headless.rs', [(3750, 3802), (4482, 4520), (5000, 5029), (8770, 8822)])]:
    lines = (W / rel).read_text().splitlines()
    for start, end in ranges:
        q = W / 'read-evidence' / (Path(rel).stem + '-' + str(start) + '-' + str(end) + '.txt')
        q.parent.mkdir(parents=True, exist_ok=True)
        q.write_text(''.join(f'{i}: {lines[i - 1]}\n' for i in range(start, end + 1)))
        reads['bounded'].append({'path': rel, 'file': meta(W / rel), 'start': start, 'end': end, 'snippet': str(q.relative_to(W)), 'snippet_meta': meta(q), 'claim': 'bounded context only'})
write(W / 'read-evidence' / 'reading-scope.json', reads)
R.mkdir()
for p in sorted(W.iterdir()):
    if p.name in ['target', '__pycache__']:
        continue
    q = R / 'evidence' / p.name
    q.parent.mkdir(parents=True, exist_ok=True)
    if p.is_dir():
        shutil.copytree(p, q, ignore=shutil.ignore_patterns('__pycache__'))
    else:
        shutil.copyfile(p, q)
shutil.copytree(W.parent / 'zs1-117-release-cold-diagnosis-ready', R / 'previous-readonly-ready')
shutil.copyfile(W / 'diagnosis.md', R / 'diagnosis.md')
shutil.copyfile(W / 'verify_offline.py', R / 'verify_offline.py')
(R / 'README.md').write_text('''# ZS1-117 五阶段诊断交付

一次私有构建、一次新产物首启；main 前 935.707583 ms，main 至返回前 40.391917 ms，诊断外层 977.101334 ms。不是正式门禁通过或修复。

先读 diagnosis.md。evidence 保留冻结源码、原始三流、fixture/journal、五阶段时钟、有限清理结果、精确窗口系统日志、并发主机快照、离线失败和主库漂移；previous-readonly-ready 是此前只读诊断的逐字节副本，含原 1109 ms 失败证据。

只允许离线校验：python3 -B verify_offline.py。不要执行 evidence 中的 build_once.py、observe_once.py、run_observer_once.py、prepare.py、system_after.py、system_token_after.py 或二进制；它们是已执行实验的留档，不是重试指令。target 构建缓存不进入包。

verify 输出保存在包外工作根 offline-verification.json。manifest.json 列出所有其余文件的字节数与 SHA-256，自身 hash 在交付消息中提供。主任务尚未接收，root cause 未完全证明，原正式 release 与门禁结果不变。
''')
artifacts = {str(p.relative_to(R)): meta(p) for p in sorted(R.rglob('*')) if p.is_file()}
write(R / 'manifest.json', {'item': 'ZS1-117', 'kind': 'private-five-phase-single-first-launch-diagnostic', 'master_accepted': False, 'root_cause_proven': False, 'official_gate_passed': False, 'new_builds': 1, 'new_target_launches': 1, 'product_changes': False, 'artifacts': artifacts})
print(json.dumps({'ready': str(R), 'artifacts': len(artifacts), 'manifest': meta(R / 'manifest.json'), 'diagnosis': meta(R / 'diagnosis.md'), 'master_drift': drift}, indent=2))
