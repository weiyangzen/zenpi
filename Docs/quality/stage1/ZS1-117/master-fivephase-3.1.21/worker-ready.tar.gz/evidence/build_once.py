from pathlib import Path
import json,os,subprocess
from support import W,sha,now,command,host_snapshot
argv=['cargo','+stable-aarch64-apple-darwin','build','--release','--locked','--offline','--bin','zenpi']
changes={'CARGO_TARGET_DIR':str(W/'target'),'CARGO_NET_OFFLINE':'true','CARGO_BUILD_JOBS':'2'}
env=os.environ.copy();env.update(changes)
with (W/'build-started.json').open('x') as f:json.dump({'argv':argv,'cwd':str(W/'source'),'env_diff':changes,'started_at':now(),'single_compile_attempt':True},f,indent=2)
host_snapshot('build-before')
for label,args in [('rustc-version',['rustc','+stable-aarch64-apple-darwin','-vV']),('cargo-version',['cargo','+stable-aarch64-apple-darwin','--version'])]:
 r,_,_=command(label,args,env=env);assert r['exit_code']==0
start=now()
with (W/'build.stdout.log').open('xb') as out,(W/'build.stderr.log').open('xb') as err:
 p=subprocess.run(argv,cwd=W/'source',env=env,stdout=out,stderr=err)
r={'argv':argv,'cwd':str(W/'source'),'env_diff':changes,'started_at':start,'ended_at':now(),'exit_code':p.returncode,'binary_executed':False}
for key in ['stdout','stderr']:
 q=W/('build.'+key+'.log');b=q.read_bytes();r[key]={'path':q.name,'bytes':len(b),'sha256':sha(b)}
if p.returncode==0:
 q=W/'target/release/zenpi';s=q.stat();r['binary']={'path':str(q),'bytes':s.st_size,'sha256':sha(q.read_bytes()),'inode':s.st_ino,'device':s.st_dev,'mtime_ns':s.st_mtime_ns,'mode':oct(s.st_mode)}
(W/'build-result.json').write_text(json.dumps(r,indent=2)+'\n');host_snapshot('build-after');print(json.dumps(r,indent=2));raise SystemExit(p.returncode)
