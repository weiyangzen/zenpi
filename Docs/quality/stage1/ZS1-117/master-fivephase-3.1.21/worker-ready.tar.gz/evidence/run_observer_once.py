from support import W,now,sha
import subprocess,json
assert not (W/'observer.run.json').exists() and not (W/'launch-claim.json').exists()
argv=['python3','-B',str(W/'observe_once.py')];start=now()
with (W/'observer.stdout.log').open('xb') as out,(W/'observer.stderr.log').open('xb') as err:
 p=subprocess.run(argv,cwd=W,stdout=out,stderr=err)
r={'argv':argv,'cwd':str(W),'started_at':start,'ended_at':now(),'exit_code':p.returncode,'single_observer_attempt':True}
for n in ['stdout','stderr']:
 q=W/('observer.'+n+'.log');b=q.read_bytes();r[n]={'path':q.name,'bytes':len(b),'sha256':sha(b)}
(W/'observer.run.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
print((W/'observer.stdout.log').read_text());print((W/'observer.stderr.log').read_text());raise SystemExit(p.returncode)
