"""Read-only verification of this sealed evidence package. Never run any product."""
from pathlib import Path
import ast, difflib, hashlib, json, math
R = Path(__file__).resolve().parent
E = R / 'evidence'
def read(p): return json.loads(p.read_text())
def meta(p):
    b = p.read_bytes()
    return {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}
checks = {}
manifest = read(R / 'manifest.json')
actual_paths = {str(p.relative_to(R)) for p in R.rglob('*') if p.is_file() and p != R / 'manifest.json'}
checks['manifest_exact_file_set'] = actual_paths == set(manifest['artifacts'])
checks['all_manifest_hashes'] = all(meta(R / rel) == v for rel, v in manifest['artifacts'].items())
prior = R / 'previous-readonly-ready'
checks['prior_manifest_identity'] = meta(prior / 'manifest.json')['sha256'] == '24edf0ea9aab3adf2e7b87b5ff6a8e98be9e865c64872f8e5940c40f0e8bb34a'
checks['prior_artifacts_exact'] = all(meta(prior / rel) == v for rel, v in read(prior / 'manifest.json')['artifacts'].items())
before = read(E / 'inputs-before.json')['files']; after = read(E / 'inputs-diagnostic.json')['files']
checks['frozen_input_counts'] = len(before) == 155 and len(after) == 156
checks['frozen_diagnostic_hashes'] = all(meta(E / 'source' / rel) == v for rel, v in after.items())
checks['only_authorized_private_changes'] = sorted(rel for rel in before if before[rel] != after.get(rel)) == ['src/core.rs', 'src/headless.rs', 'src/main.rs'] and set(after) - set(before) == {'src/startup_phase.rs'} and not set(before) - set(after)
checks['three_before_source_hashes'] = all(meta(E / 'before' / (n + '.rs')) == before['src/' + n + '.rs'] for n in ['main', 'core', 'headless'])
patch = ''
for name in ['main', 'core', 'headless']:
    patch += ''.join(difflib.unified_diff((E / 'before' / (name + '.rs')).read_text().splitlines(True), (E / 'source/src' / (name + '.rs')).read_text().splitlines(True), fromfile='a/src/' + name + '.rs', tofile='b/src/' + name + '.rs'))
patch += ''.join(difflib.unified_diff([], (E / 'source/src/startup_phase.rs').read_text().splitlines(True), fromfile='/dev/null', tofile='b/src/startup_phase.rs'))
checks['full_diagnostic_patch_exact'] = patch == (E / 'diagnostic.patch').read_text()
obs = read(E / 'observation.json'); build = read(E / 'build-result.json'); run = read(E / 'observer.run.json')
checks['single_launch_recorded'] = obs['launch_attempts'] == 1 and read(E / 'launch-claim.json')['intended_launches'] == 1 and manifest['new_builds'] == manifest['new_target_launches'] == 1
checks['build_and_observer_success'] = build['exit_code'] == run['exit_code'] == obs['returncode'] == 0
checks['bounded_capture_completed'] = not obs['timed_out'] and not obs['errors'] and obs['wrapper_reaped'] and obs['group_absent_after_wait'] and all(n + '_eof' in obs['marks'] for n in ['stdout', 'stderr', 'trace'])
checks['binary_identity'] = meta(E / 'binary/zenpi') == {k: obs['binary'][k] for k in ['bytes', 'sha256']} and obs['binary'] == build['binary'] and obs['binary']['sha256'] == '19d5887b424ef1bc53f8ed3793c0c7982c4fea57a80ac3c758ef50f4edf7a9ad'
checks['all_command_stream_hashes'] = all(meta(E / rec[n]['path']) == {k: rec[n][k] for k in ['bytes', 'sha256']} for rec in [obs, build, run] + [read(p) for p in (E / 'commands').glob('*.json')] for n in (['stdout', 'stderr', 'trace'] if rec is obs else ['stdout', 'stderr']))
raw = (E / 'trace.bin').read_bytes()
records = [{'magic': b[:8].decode(), 'phase': chr(b[8]), 'pid': int.from_bytes(b[12:16], 'little'), 'ppid': int.from_bytes(b[16:20], 'little'), 'mach_ticks': int.from_bytes(b[20:28], 'little'), 'reserved_zero': b[9:12] == bytes(3) and b[28:32] == bytes(4)} for b in [raw[i:i + 32] for i in range(0, len(raw), 32)]]
checks['trace_raw_matches_validation'] = len(raw) == 160 and records == read(E / 'phase-validation.json')['phases']
checks['five_markers_single_process'] = ''.join(r['phase'] for r in records) == 'MHRAX' and {r['pid'] for r in records} == {97022} and {r['ppid'] for r in records} == {obs['wrapper_pid']} and all(r['magic'] == 'Z117PH01' and r['reserved_zero'] for r in records)
ticks = {r['phase']: r['mach_ticks'] for r in records}; marks = obs['marks']
expected = {'parent_launch_to_M': (marks['before_popen']['mach_ticks'], ticks['M']), 'M_H': (ticks['M'], ticks['H']), 'H_R': (ticks['H'], ticks['R']), 'R_A': (ticks['R'], ticks['A']), 'A_X': (ticks['A'], ticks['X']), 'M_X': (ticks['M'], ticks['X']), 'X_parent_capture_end': (ticks['X'], marks['capture_end']['mach_ticks']), 'Popen': (marks['before_popen']['mach_ticks'], marks['popen_return']['mach_ticks']), 'A_first_stdout_observed': (ticks['A'], marks['stdout_first_line_observed']['mach_ticks'])}
intervals = read(E / 'phase-intervals.json'); factor = obs['timebase']['numer'] / obs['timebase']['denom'] / 1e6
checks['same_clock_interval_arithmetic'] = set(expected) == set(intervals) and all(intervals[k]['start_ticks'] == a and intervals[k]['end_ticks'] == b and b >= a and math.isclose(intervals[k]['elapsed_ms'], (b - a) * factor, abs_tol=1e-9) for k, (a, b) in expected.items())
checks['payload_matches_record'] = (E / 'payload.bin').read_bytes() == bytes.fromhex(obs['payload_hex']) == b'{"type":"shutdown","id":"bench-stop"}\n'
wire = (E / 'stdout.bin').read_bytes(); lines = wire.splitlines(); reply = json.loads(lines[0])
checks['one_matching_shutdown_reply'] = len(lines) == 1 and reply['id'] == 'bench-stop' and reply['success'] is True and reply['data'] == {'closing': True, 'drained': True}
fixture = read(E / 'fixture-files.json')['files']
checks['fixture_hashes'] = len(fixture) == 2 and all(meta(E / 'fixture' / r['relative']) == {k: r[k] for k in ['bytes', 'sha256']} for r in fixture)
journal = [json.loads(line) for line in (E / 'fixture/session-0.jsonl.reconnect').read_text().splitlines()]
checks['journal_terminal_matches_wire'] = [r['event']['line'].encode() for r in journal if r['event']['type'] == 'terminal'] == [wire]
system = read(E / 'system-analysis.json')
scan = next(r for r in system['events'] if 'GK performScan:' in r['eventMessage']); end = next(r for r in system['events'] if 'GK evaluateScanResult:' in r['eventMessage'])
checks['system_separate_interval'] = len(system['events']) == 13 and system['scan_to_evaluate_ticks'] == end['machTimestamp'] - scan['machTimestamp'] == 22172066 and math.isclose(system['scan_to_evaluate_ms_with_recorded_timebase'], 923.8360833333334, abs_tol=1e-9) and system['displayed_scan_start_minus_parent_launch_wall_ms'] == -18.285 and system['cross_clock_subtraction_performed'] is False
checks['contrary_system_qualification_preserved'] = any('Skipping up front XProtect scan' in r['eventMessage'] for r in system['events'])
checks['offline_failure_preserved'] = read(E / 'analysis-attempt1.json')['exit_code'] == 1 and 'ValueError' in read(E / 'analysis-attempt1.json')['stderr']
integrity = read(E / 'final-input-integrity.json')
checks['frozen_and_old_ready_integrity_receipt'] = integrity['private_inputs_exact'] and integrity['old_ready_all_exact'] and integrity['old_ready_count'] == 3278 and integrity['binary_exact']
checks['master_drift_explicit'] = all('patch' in r and (E / r['patch']).is_file() for r in integrity['master_drift'])
for p in E.glob('*.py'): ast.parse(p.read_text(), filename=str(p))
checks['python_evidence_syntax'] = True
checks['no_gate_or_owner_acceptance_claim'] = manifest['official_gate_passed'] is False and manifest['master_accepted'] is False and manifest['root_cause_proven'] is False
print(json.dumps({'passed': all(checks.values()), 'scope': 'Offline artifact verification only; no product execution, official gate, root-cause proof or owner acceptance', 'artifacts': len(manifest['artifacts']), 'checks': checks, 'manifest': meta(R / 'manifest.json'), 'report': meta(R / 'diagnosis.md')}, indent=2))
raise SystemExit(0 if all(checks.values()) else 1)
