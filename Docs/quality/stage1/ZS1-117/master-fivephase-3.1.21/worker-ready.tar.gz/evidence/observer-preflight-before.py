"""One first launch of the new private diagnostic binary; never retry this artifact."""
from pathlib import Path
import os,json,subprocess,tempfile,selectors,signal,time,ctypes,errno,traceback
from support import W,sha,now,command,host_snapshot
M=Path('/Users/wangweiyang/GitHub/zenpi');binary=W/'target/release/zenpi'
PAYLOAD=b'{"type":"shutdown","id":"bench-stop"}\n';TRACE_FD=198
MAX_STREAM_BYTES=8*1024*1024
class Timebase(ctypes.Structure):
    _fields_=[('numer',ctypes.c_uint32),('denom',ctypes.c_uint32)]
lib=ctypes.CDLL('/usr/lib/libSystem.B.dylib')
mach=lib.mach_absolute_time;mach.argtypes=[];mach.restype=ctypes.c_uint64
tb_fn=lib.mach_timebase_info;tb_fn.argtypes=[ctypes.POINTER(Timebase)];tb_fn.restype=ctypes.c_int
def stamp():return {'mach_ticks':mach(),'perf_counter_ns':time.perf_counter_ns(),'utc':now()}
def main():
    build=json.loads((W/'build-result.json').read_text());assert build['exit_code']==0
    data=binary.read_bytes();assert sha(data)==build['binary']['sha256']
    # This exclusive claim survives every error. Never rerun to get a greener first launch.
    with (W/'launch-claim.json').open('x') as f:
        json.dump({'claimed_at':now(),'binary_sha256':sha(data),'intended_launches':1},f,indent=2)
    host_snapshot('launch-before')
    boot,rawboot,_=command('launch-boot',['/usr/sbin/sysctl','kern.bootsessionuuid'])
    assert boot['exit_code']==0
    tb=Timebase();assert tb_fn(ctypes.byref(tb))==0 and tb.denom
    fixture=Path(tempfile.mkdtemp(prefix='zenpi-bench-'))
    session=fixture/'session-0.jsonl'
    env=os.environ.copy();overrides={'ZENPI_HOME':str(fixture/'zenpi'),'ZENPI_BACKEND':'openai',
        'ZENPI_BASE_URL':'http://127.0.0.1:1','ZENPI_MODEL':'benchmark-no-network','ZENPI_API_KEY':'benchmark-placeholder'}
    env.update(overrides)
    # Match the original explicitly scoped build environment at process launch, without exposing other values.
    env.update({'CARGO_NET_OFFLINE':'true','CARGO_BUILD_JOBS':'2'})
    argv=['/usr/bin/time','-l',str(binary),'--mode','headless','--session',str(session)]
    rec={'argv':argv,'cwd':str(M),'env_overrides':overrides,'other_explicit_env':{'CARGO_NET_OFFLINE':'true','CARGO_BUILD_JOBS':'2'},
         'binary':build['binary'],'fixture':str(fixture),'boot_uuid':rawboot.decode().strip().split(': ',1)[1],
         'timebase':{'numer':tb.numer,'denom':tb.denom},'timeout_after_popen_seconds':5,'reap_bound_seconds':1,
         'trace_fd':TRACE_FD,'trace_pipe_nonblocking':True,'observer':'selectors over stdout/stderr/trace; differs from official communicate, diagnostic only',
         'payload_hex':PAYLOAD.hex(),'marks':{},'errors':[],'timed_out':False,'launch_attempts':0}
    streams={k:bytearray() for k in ['stdout','stderr','trace']};child=None;sel=selectors.DefaultSelector();pipe_r=None;parent_trace_open=False
    cleanup_deadline=None;forced=False;exit_seen=False
    def terminate_group(reason):
        nonlocal forced,cleanup_deadline
        if forced:return
        forced=True;cleanup_deadline=time.monotonic()+1
        rec['cleanup_reason']=reason;rec['kill_requested_at']=stamp()
        if child is not None:
            try:os.killpg(child.pid,signal.SIGKILL);rec['killpg']='sent'
            except ProcessLookupError:rec['killpg']='group already absent'
            except OSError as e:rec['errors'].append({'where':'killpg','error':repr(e)})
    try:
        try:os.fstat(TRACE_FD)
        except OSError as e:
            if e.errno!=errno.EBADF:raise
        else:raise RuntimeError('reserved trace FD is already in use; no launch')
        pipe_r,pipe_w=os.pipe();os.set_blocking(pipe_w,False)
        os.dup2(pipe_w,TRACE_FD,inheritable=True);parent_trace_open=True
        if pipe_w!=TRACE_FD:os.close(pipe_w)
        os.set_blocking(pipe_r,False)
        (W/'payload.bin').write_bytes(PAYLOAD)
        rec['marks']['before_popen']=stamp();outer_start=time.perf_counter_ns()
        rec['launch_attempts']=1
        child=subprocess.Popen(argv,cwd=M,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE,start_new_session=True,pass_fds=(TRACE_FD,))
        rec['marks']['popen_return']=stamp();rec['wrapper_pid']=child.pid
        deadline=time.monotonic()+5
        os.close(TRACE_FD);parent_trace_open=False
        for name,fd in [('stdout',child.stdout.fileno()),('stderr',child.stderr.fileno()),('trace',pipe_r)]:
            os.set_blocking(fd,False);sel.register(fd,selectors.EVENT_READ,name)
        sent=os.write(child.stdin.fileno(),PAYLOAD);rec['payload_bytes_written']=sent
        child.stdin.close();assert sent==len(PAYLOAD)
        rec['marks']['payload_sent']=stamp()
        while True:
            if child.poll() is not None and not exit_seen:
                rec['marks']['wrapper_exit_observed']=stamp();exit_seen=True
            if not sel.get_map() and exit_seen:break
            remaining=(cleanup_deadline if forced else deadline)-time.monotonic()
            if remaining<=0:
                if forced:
                    rec['errors'].append({'where':'drain','error':'EOF not complete within bounded cleanup'});break
                rec['timed_out']=True;terminate_group('5 second deadline');continue
            for key,_ in sel.select(min(0.01,remaining)):
                try:chunk=os.read(key.fd,65536)
                except BlockingIOError:continue
                mark=stamp();name=key.data
                if not chunk:
                    rec['marks'][name+'_eof']=mark;sel.unregister(key.fd);continue
                streams[name].extend(chunk)
                if name=='stdout' and 'stdout_first_line_observed' not in rec['marks'] and b'\n' in streams[name]:
                    rec['marks']['stdout_first_line_observed']=mark
                if len(streams[name])>MAX_STREAM_BYTES:
                    rec['errors'].append({'where':name,'error':'8 MiB observer safety limit; retained bytes are partial'})
                    terminate_group('stream limit')
        rec['outer_elapsed_ms']=(time.perf_counter_ns()-outer_start)/1e6
        rec['marks']['capture_end']=stamp()
        try:rec['returncode']=child.wait(timeout=1);rec['wrapper_reaped']=True
        except subprocess.TimeoutExpired:
            terminate_group('wrapper reap timeout');rec['wrapper_reaped']=False
            rec['errors'].append({'where':'wait','error':'wrapper did not reap in one second'})
    except BaseException as e:
        rec['errors'].append({'where':'observer','error':repr(e),'traceback':traceback.format_exc()})
        if child is not None:
            terminate_group('observer error')
            try:rec['returncode']=child.wait(timeout=1);rec['wrapper_reaped']=True
            except subprocess.TimeoutExpired:rec['wrapper_reaped']=False
    finally:
        if parent_trace_open:os.close(TRACE_FD)
        sel.close()
        if pipe_r is not None:os.close(pipe_r)
        if child is not None:
            for stream in [child.stdin,child.stdout,child.stderr]:
                if stream is not None and not stream.closed:stream.close()
            try:os.killpg(child.pid,0);rec['group_absent_after_wait']=False
            except ProcessLookupError:rec['group_absent_after_wait']=True
            except OSError as e:rec['group_absent_after_wait']=None;rec['errors'].append({'where':'group-check','error':repr(e)})
        rec['finished_at']=now()
        for name,raw in streams.items():
            p=W/(name+'.bin');p.write_bytes(raw);rec[name]={'path':p.name,'bytes':len(raw),'sha256':sha(raw)}
        (W/'observation.json').write_text(json.dumps(rec,indent=2)+'\n')
        # Preserve every diagnostic fixture file, including journals/replay records, even if observation failed.
        files=[]
        for p in sorted(fixture.rglob('*')):
            if p.is_file():
                b=p.read_bytes();q=W/'fixture'/p.relative_to(fixture);q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
                files.append({'relative':str(p.relative_to(fixture)),'bytes':len(b),'sha256':sha(b)})
        (W/'fixture-files.json').write_text(json.dumps({'original_path':str(fixture),'retained_in_place':True,'files':files},indent=2)+'\n')
        host_snapshot('launch-after')
    # Strict phase validation after complete raw persistence. Failure never triggers a second execution.
    records=[];raw=bytes(streams['trace'])
    for i in range(0,len(raw)//32*32,32):
        b=raw[i:i+32];records.append({'magic':b[:8].decode(errors='replace'),'phase':chr(b[8]),
            'pid':int.from_bytes(b[12:16],'little'),'ppid':int.from_bytes(b[16:20],'little'),
            'mach_ticks':int.from_bytes(b[20:28],'little'),'reserved_zero':b[9:12]==b'\0'*3 and b[28:]==b'\0'*4})
    checks={'trace_exact_160_bytes':len(raw)==160,'phases':''.join(r['phase'] for r in records)=='MHRAX',
            'format':all(r['magic']=='Z117PH01' and r['reserved_zero'] for r in records),
            'same_target_pid':len({r['pid'] for r in records})==1,'parent_is_wrapper':all(r['ppid']==rec.get('wrapper_pid') for r in records),
            'ordered':all(a['mach_ticks']<=b['mach_ticks'] for a,b in zip(records,records[1:])),
            'exit_zero':rec.get('returncode')==0,'wrapper_reaped':rec.get('wrapper_reaped',False),
            'no_timeout':not rec['timed_out'],'no_observer_errors':not rec['errors'],
            'all_stream_eof':all(n+'_eof' in rec['marks'] for n in streams)}
    try:
        lines=bytes(streams['stdout']).splitlines();v=json.loads(lines[0]);checks['shutdown_response']=len(lines)==1 and v['id']=='bench-stop' and v['success'] is True and v['data']=={'closing':True,'drained':True}
    except Exception:checks['shutdown_response']=False
    result={'checks':checks,'passed':all(checks.values()),'phases':records,'root_cause_proven':False,'diagnostic_only':True}
    (W/'phase-validation.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'passed':result['passed'],'checks':checks,'outer_elapsed_ms':rec.get('outer_elapsed_ms'),'phases':records,'errors':rec['errors']},indent=2))
    return 0 if result['passed'] else 1
if __name__=='__main__':raise SystemExit(main())
