from support import W,command,now
import json,ctypes
old=json.loads((W/'commands/single-launch-system-window.json').read_text())['argv'];argv=old.copy();argv[-1]='eventMessage CONTAINS "c4e8a5e276eb24ff"'
r,out,err=command('single-launch-path-token',argv,timeout=45);print(r['exit_code'],out.decode(),err.decode())
# Read-only clock-origin investigation after launch; never retroactively assert the offsets held at launch.
lib=ctypes.CDLL('/usr/lib/libSystem.B.dylib');absolute=lib.mach_absolute_time;continuous=lib.mach_continuous_time
for f in [absolute,continuous]:f.argtypes=[];f.restype=ctypes.c_uint64
pairs=[]
for _ in range(3):
 a=absolute();c=continuous();z=absolute();pairs.append({'absolute_before':a,'continuous':c,'absolute_after':z,'continuous_minus_absolute_bracket':[c-z,c-a],'utc_after':now()})
(W/'clock-origin-after.json').write_text(json.dumps({'scope':'post-launch read-only ABI observations; not a launch-time mapping for unified log timestamps','pairs':pairs},indent=2)+'\n');print(json.dumps(pairs,indent=2))
