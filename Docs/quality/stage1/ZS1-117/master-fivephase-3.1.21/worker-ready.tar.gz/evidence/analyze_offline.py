"""Parse existing evidence only. Never invoke the product or any system command."""
from pathlib import Path
import datetime, json
W = Path(__file__).resolve().parent
events = {}
for label in ['single-launch-system-window', 'single-launch-path-token']:
    for row in json.loads((W / 'commands' / (label + '.stdout.log')).read_text()):
        key = (row['machTimestamp'], row['processID'], row['eventMessage'])
        if key not in events:
            events[key] = {k: row[k] for k in ['timestamp', 'machTimestamp', 'bootUUID', 'processID', 'threadID', 'processImagePath', 'eventMessage']}
            events[key]['source_receipts'] = []
        events[key]['source_receipts'].append(label)
rows = sorted(events.values(), key=lambda r: r['machTimestamp'])
scan = next(r for r in rows if 'GK performScan:' in r['eventMessage'])
evaluate = next(r for r in rows if 'GK evaluateScanResult:' in r['eventMessage'])
obs = json.loads((W / 'observation.json').read_text())
log_wall = datetime.datetime.strptime(scan['timestamp'], '%Y-%m-%d %H:%M:%S.%f%z')
parent_wall = datetime.datetime.fromisoformat(obs['marks']['before_popen']['utc'])
result = {
    'source': 'Existing raw log files only; no new target execution or system query',
    'unique_events': len(rows),
    'all_log_boots_match_observer': all(r['bootUUID'] == obs['boot_uuid'] for r in rows),
    'scan_to_evaluate_ticks': evaluate['machTimestamp'] - scan['machTimestamp'],
    'scan_to_evaluate_ms_with_recorded_timebase': (evaluate['machTimestamp'] - scan['machTimestamp']) * obs['timebase']['numer'] / obs['timebase']['denom'] / 1e6,
    'displayed_scan_start_minus_parent_launch_wall_ms': (log_wall - parent_wall).total_seconds() * 1000,
    'cross_clock_subtraction_performed': False,
    'qualification': 'Unified-log machTimestamp and observer/target mach_absolute_time have different origins despite the same boot. Post-launch continuous/absolute samples are not a launch-time mapping. Displayed wall scan starts before parent launch; no strict containment, exact phase overlay, or causal attribution is claimed. The scan interval is a system-log interval, not proven XProtect execution duration.',
    'events': rows,
}
with (W / 'system-analysis.json').open('x') as f:
    json.dump(result, f, indent=2); f.write('\n')
print(json.dumps({k: v for k, v in result.items() if k != 'events'}, indent=2))
