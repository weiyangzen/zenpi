from pathlib import Path
import shutil,json,hashlib,difflib,datetime
W=Path(__file__).resolve().parent;M=Path('/Users/wangweiyang/GitHub/zenpi');B=W/'source';assert not B.exists();B.mkdir();sha=lambda b:hashlib.sha256(b).hexdigest();inputs={}
for name in ['src','vendor','tools']:
 shutil.copytree(M/name,B/name,ignore=shutil.ignore_patterns('__pycache__','target','.git'))
for name in ['Cargo.toml','Cargo.lock','README.md','rust-toolchain.toml','rust-toolchain','build.rs']:
 if (M/name).is_file():shutil.copyfile(M/name,B/name)
if (M/'.cargo').is_dir():shutil.copytree(M/'.cargo',B/'.cargo')
for p in sorted(B.rglob('*')):
 if p.is_file():
  rel=str(p.relative_to(B));data=p.read_bytes();assert data==(M/rel).read_bytes();inputs[rel]={'bytes':len(data),'sha256':sha(data)}
(W/'inputs-before.json').write_text(json.dumps({'captured_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'root':str(M),'files':inputs},indent=2)+'\n')
for name in ['main','core','headless']:
 p=B/'src'/f'{name}.rs';q=W/'before'/f'{name}.rs';q.parent.mkdir(exist_ok=True);q.write_bytes(p.read_bytes())
emitter='''//! Private five-phase experiment only. No environment/config/logging access.
//! FD 198 is a nonblocking anonymous pipe inherited from the private observer.
//! One 32-byte write per phase; missing/short writes remain diagnostic failure.

#[inline(never)]
pub fn emit(phase: u8) {
    unsafe extern "C" {
        fn mach_absolute_time() -> u64;
    }
    let ticks = unsafe { mach_absolute_time() };
    let mut record = [0u8; 32];
    record[..8].copy_from_slice(b"Z117PH01");
    record[8] = phase;
    record[12..16].copy_from_slice(&(unsafe { libc::getpid() } as u32).to_le_bytes());
    record[16..20].copy_from_slice(&(unsafe { libc::getppid() } as u32).to_le_bytes());
    record[20..28].copy_from_slice(&ticks.to_le_bytes());
    // The observer keeps the read end open and drains independently. No retry.
    let _ = unsafe { libc::write(198, record.as_ptr().cast(), record.len()) };
}
'''
(B/'src/startup_phase.rs').write_text(emitter)
p=B/'src/main.rs';p.write_text('''use std::process::ExitCode;

#[path = "startup_phase.rs"]
mod startup_phase;

fn main() -> ExitCode {
    startup_phase::emit(b'M');
    let outcome = match zenpi::core::run() {
        Ok(()) => ExitCode::SUCCESS,
        Err(error) => {
            eprintln!("zenpi: {error}");
            ExitCode::FAILURE
        }
    };
    startup_phase::emit(b'X');
    outcome
}
''')
p=B/'src/core.rs';s=p.read_text();anchor='pub fn run() -> Result<(), ZenpiError> {';assert s.count(anchor)==1
# Module declaration is adjacent to run; no lib.rs or Cargo manifest edit.
s=s.replace(anchor,'#[path = "startup_phase.rs"]\npub(crate) mod startup_phase;\n\n'+anchor)
a='''        RunMode::Headless => crate::headless::run_stdio_owned(agent)
            .map_err(|error| ZenpiError::Message(error.to_string())),'''
b='''        RunMode::Headless => {
            startup_phase::emit(b'H');
            crate::headless::run_stdio_owned(agent)
                .map_err(|error| ZenpiError::Message(error.to_string()))
        },'''
assert s.count(a)==1;s=s.replace(a,b);p.write_text(s)
p=B/'src/headless.rs';s=p.read_text();a='''    let mut pending_shutdown: Option<(Option<String>, String, u16)> = None;
    let loop_result =''';b='''    let mut pending_shutdown: Option<(Option<String>, String, u16)> = None;
    crate::core::startup_phase::emit(b'R');
    let loop_result =''';assert s.count(a)==1;s=s.replace(a,b)
a='''                    Some(json!({"closing": true, "drained": true})),
                    ),'''
# Narrow exact existing RuntimeEvent::Closed branch, after successful response writer.
start=s.index('        RuntimeEvent::Closed => {');end=s.index('\nfn queue_slash_command',start);part=s[start:end]
a='''                    replay,
                )?;
            }
            Ok(stopping && shutdown_sent && jobs.is_empty())''';b='''                    replay,
                )?;
                crate::core::startup_phase::emit(b'A');
            }
            Ok(stopping && shutdown_sent && jobs.is_empty())''';assert part.count(a)==1;s=s[:start]+part.replace(a,b)+s[end:];p.write_text(s)
patch=''
for name in ['main','core','headless']:
 a=(W/'before'/f'{name}.rs').read_text();b=(B/'src'/f'{name}.rs').read_text();patch+=''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/src/'+name+'.rs',tofile='b/src/'+name+'.rs'))
patch+=''.join(difflib.unified_diff([],emitter.splitlines(True),fromfile='/dev/null',tofile='b/src/startup_phase.rs'));(W/'diagnostic.patch').write_text(patch)
after={str(p.relative_to(B)):{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(B.rglob('*')) if p.is_file()};changed=[p for p in inputs if inputs[p]!=after[p]];assert changed==['src/core.rs','src/headless.rs','src/main.rs'];assert set(after)-set(inputs)=={'src/startup_phase.rs'}
(W/'inputs-diagnostic.json').write_text(json.dumps({'files':after,'changed':changed,'added':['src/startup_phase.rs'],'scope':'private diagnostic only; core/headless bounded context plus complete patch, no claim of full owner reading'},indent=2)+'\n')
old={str(p.relative_to(W.parent.parent)):{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for root in sorted(W.parent.glob('*ready')) if root.is_dir() for p in sorted(root.rglob('*')) if p.is_file()};(W/'old-ready-inventory.json').write_text(json.dumps(old,indent=2)+'\n')
print(json.dumps({'source_files':len(inputs),'diagnostic_files':len(after),'changes':changed,'old_ready_files':len(old),'identities':{n:inputs['src/'+n+'.rs'] for n in ['main','core','headless']}},indent=2))
