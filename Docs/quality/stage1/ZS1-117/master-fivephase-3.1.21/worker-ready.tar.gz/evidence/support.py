from pathlib import Path
import subprocess,json,hashlib,datetime,os
W=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def command(label,argv,cwd=None,env=None,timeout=45):
 D=W/'commands';D.mkdir(exist_ok=True);p=D/(label+'.json');assert not p.exists();start=now()
 try:
  c=subprocess.run(argv,cwd=cwd,capture_output=True,env=env,timeout=timeout);rc=c.returncode;out=c.stdout;err=c.stderr;expired=False
 except subprocess.TimeoutExpired as e:rc=None;out=e.stdout or b'';err=e.stderr or b'';expired=True
 r={'argv':argv,'cwd':str(cwd or Path.cwd()),'started_at':start,'ended_at':now(),'exit_code':rc,'timed_out':expired}
 for name,b in [('stdout',out),('stderr',err)]:
  q=D/(label+'.'+name+'.log');q.write_bytes(b);r[name]={'path':str(q.relative_to(W)),'bytes':len(b),'sha256':sha(b)}
 p.write_text(json.dumps(r,indent=2)+'\n');return r,out,err

def host_snapshot(label):
 D=W/'host';D.mkdir(exist_ok=True);dest=D/(label+'.json');assert not dest.exists()
 start=now();argv=['/bin/ps','-axo','pid,ppid,%cpu,comm'];p=subprocess.run(argv,capture_output=True,timeout=10)
 selected=[]
 for line in p.stdout.decode(errors='replace').splitlines()[1:]:
  x=line.split(None,3)
  if len(x)==4 and Path(x[3]).name.lower() in ['cargo','rustc','zenpi','python','python3','time','clang','cc','ld','rust-lld']:
   selected.append({'pid':int(x[0]),'ppid':int(x[1]),'cpu_percent':x[2],'comm':x[3]})
 # Cwd only for compilation processes, to identify A/C worktrees without broad argv/env inspection.
 ids=[str(x['pid']) for x in selected if Path(x['comm']).name.lower() in ['cargo','rustc','clang','cc','ld','rust-lld']]
 extra=None
 if ids:
  r,out,err=command('cwd-'+label,['/usr/sbin/lsof','-a','-p',','.join(ids),'-d','cwd','-Fn'],timeout=10);extra=r
 dest.write_text(json.dumps({'argv':argv,'started_at':start,'ended_at':now(),'exit_code':p.returncode,'raw_stdout_bytes':len(p.stdout),'raw_stdout_sha256':sha(p.stdout),'stderr':p.stderr.decode(errors='replace'),'selected':selected,'compiler_cwd_receipt':extra,'qualification':'Before/during/after host snapshots, not CPU exclusivity or complete scheduling trace; unrelated processes not retained'},indent=2)+'\n')
 return selected
