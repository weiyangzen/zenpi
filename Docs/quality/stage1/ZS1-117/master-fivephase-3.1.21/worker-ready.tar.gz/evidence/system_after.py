from support import command,W
import json,datetime
r=json.loads((W/'observation.json').read_text());a=datetime.datetime.fromisoformat(r['marks']['before_popen']['utc']);b=datetime.datetime.fromisoformat(r['finished_at'])
local=datetime.timezone(datetime.timedelta(hours=8));lo=(a-datetime.timedelta(seconds=1)).astimezone(local).strftime('%Y-%m-%d %H:%M:%S');hi=(b+datetime.timedelta(seconds=2)).astimezone(local).strftime('%Y-%m-%d %H:%M:%S')
binary=r['binary']['path'];pred='eventMessage CONTAINS "'+binary+'" OR eventMessage CONTAINS "'+str(W)+'"'
x,out,err=command('single-launch-system-window',['/usr/bin/log','show','--style','json','--start',lo,'--end',hi,'--info','--debug','--predicate',pred],timeout=45)
print('log',x['exit_code'],out.decode(),err.decode())
x,out,err=command('signature-display-after',['/usr/bin/codesign','--display','--verbose=4',binary]);print('signature',x['exit_code'],err.decode())
