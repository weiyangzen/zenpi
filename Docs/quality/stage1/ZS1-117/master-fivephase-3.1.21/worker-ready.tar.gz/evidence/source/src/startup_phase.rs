//! Private five-phase experiment only. No environment/config/logging access.
//! FD 198 is a nonblocking anonymous pipe inherited from the private observer.
//! One 32-byte write per phase; missing/short writes remain diagnostic failure.

#[inline(never)]
pub fn emit(phase: u8) {
    unsafe extern "C" {
        fn mach_absolute_time() -> u64;
    }
    let ticks = unsafe { mach_absolute_time() };
    let mut record = [0u8; 32];
    record[..8].copy_from_slice(b"Z117PH01");
    record[8] = phase;
    record[12..16].copy_from_slice(&(unsafe { libc::getpid() } as u32).to_le_bytes());
    record[16..20].copy_from_slice(&(unsafe { libc::getppid() } as u32).to_le_bytes());
    record[20..28].copy_from_slice(&ticks.to_le_bytes());
    // The observer keeps the read end open and drains independently. No retry.
    let _ = unsafe { libc::write(198, record.as_ptr().cast(), record.len()) };
}
