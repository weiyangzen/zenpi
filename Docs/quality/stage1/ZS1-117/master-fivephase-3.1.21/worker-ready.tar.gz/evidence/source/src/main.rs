use std::process::ExitCode;

#[path = "startup_phase.rs"]
mod startup_phase;

fn main() -> ExitCode {
    startup_phase::emit(b'M');
    let outcome = match zenpi::core::run() {
        Ok(()) => ExitCode::SUCCESS,
        Err(error) => {
            eprintln!("zenpi: {error}");
            ExitCode::FAILURE
        }
    };
    startup_phase::emit(b'X');
    outcome
}
