#!/usr/bin/env python3
"""Finite offline evidence validation only. No subprocesses, network or writes."""
from pathlib import Path,PurePosixPath
import json,hashlib,difflib,base64,ast
ROOT=Path(__file__).resolve().parent
checks=[]
def check(name,value):
    if not value:raise AssertionError(name)
    checks.append(name)
def raw(rel):
    q=PurePosixPath(rel)
    if q.is_absolute() or '..' in q.parts:raise AssertionError('unsafe path')
    p=ROOT.joinpath(*q.parts)
    if p.is_symlink():raise AssertionError('symlink')
    return p.read_bytes()
def txt(rel):return raw(rel).decode()
def js(rel):return json.loads(raw(rel))
def ident(b,r):return len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256']
def inventory(prefix):return {str(p.relative_to(ROOT/prefix)):p.read_bytes() for p in (ROOT/prefix).rglob('*') if p.is_file()}
m=js('manifest.json');rows=m['files']
check('all payload hashes',all(ident(raw(r['path']),r) for r in rows))
check('exact payload set',{str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()}=={r['path'] for r in rows}|{'manifest.json'})
check('diagnostic-only scope',m['target_launches']==1 and m['production_launches']==0 and m['production_budget_accepted'] is False)
before=inventory('source-before');after=inventory('source-diagnostic');initial=js('evidence/inputs-before.json');final=js('evidence/inputs-diagnostic.json')
check('all226 current base copies',len(initial)==226 and {r['path'] for r in initial}==set(before) and all(ident(before[r['path']],r) for r in initial))
check('all227 instrumented copies',len(final)==227 and {r['path'] for r in final}==set(after) and all(ident(after[r['path']],r) for r in final))
changed=sorted(k for k in set(before)|set(after) if before.get(k)!=after.get(k))
check('only five instrumentation paths',changed==js('evidence/changed-paths.json')==['src/core.rs','src/headless.rs','src/lib.rs','src/main.rs','src/startup_diag.rs'])
patch=''.join(''.join(difflib.unified_diff(before.get(k,b'').decode().splitlines(True),after[k].decode().splitlines(True),fromfile='a/'+k if k in before else '/dev/null',tofile='b/'+k)) for k in changed)
check('full patch exact',patch==txt('evidence/diagnostic.patch'))
prod=js('evidence/production-inputs.json');drift=[k for k,r in prod.items() if not ident(before[k],r)]
check('224 matching production inputs plus recorded Gantt change',len(prod)==225 and drift==['tools/generate_stage1_gantt.py'] and [r['path'] for r in js('evidence/capture.json')['current_vs_production_changes']]==drift)
check('Cargo and vendor unchanged',all(before[k]==after[k] for k in before if k.startswith('vendor/') or k in ('Cargo.toml','Cargo.lock')))
first=js('evidence/build-01/build.run.json');second=js('evidence/build-02/build.run.json')
for label,record in [('build-01',first),('build-02',second)]:
    check(label+' original logs',ident(raw('evidence/'+label+'/build.stdout.jsonl'),record['stdout']) and ident(raw('evidence/'+label+'/build.stderr.log'),record['stderr']))
    check(label+' locked offline release bin command',record['argv']==['cargo','+stable-aarch64-apple-darwin','build','--release','--locked','--offline','--bin','zenpi','--message-format=json-render-diagnostics'])
check('failed compile before launch retained',first['exit_code']==101 and 'E0308' in txt('evidence/build-01/build.stderr.log') and second['exit_code']==0)
check('single compiler correction',txt('evidence/build-01/source/src/startup_diag.rs').replace('libc::pthread_threadid_np(std::ptr::null_mut(), &mut tid)','libc::pthread_threadid_np(libc::pthread_self(), &mut tid)')==after['src/startup_diag.rs'].decode())
check('other failed source files unchanged',all(raw('evidence/build-01/source/'+k)==after[k] for k in changed if k!='src/startup_diag.rs'))
check('corrected executable identity',ident(raw('diagnostic-zenpi'),second['diagnostic_binary']))
for label,expected in [('build-01',False),('build-02',True)]:
    cargo=[json.loads(line) for line in txt('evidence/'+label+'/build.stdout.jsonl').splitlines()]
    check(label+' cargo terminal record',cargo[-1]['reason']=='build-finished' and cargo[-1]['success']==expected)
    check(label+' actual libc dependency artifact',any(x.get('target',{}).get('name')=='libc' and 'libc@0.2.189' in x.get('package_id','') for x in cargo))
record=js('evidence/launch.run.json');parent=record['anchors'];analysis=js('evidence/stage-analysis.json')
check('one successful finite recorded launch',record['launch_index']==0 and record['launch_limit']==1 and record['returncode']==0 and record['reaped'] and not record['timed_out'] and record['watchdog_seconds']==5 and 'parent_error' not in record)
check('diagnostic identity before after launch',record['binary']==record['diagnostic_binary_after']==second['diagnostic_binary'])
check('production distinct and preserved',ident(raw('evidence/production-zenpi-release'),js('evidence/production-binary.json')) and record['binary']['sha256']!=js('evidence/production-binary.json')['sha256'])
check('unchanged single shutdown input',raw('evidence/stdin.bin')==b'{"type":"shutdown","id":"bench-stop"}\n')
check('original wrapper cwd and fresh-session shape',record['argv'][:2]==['/usr/bin/time','-l'] and record['argv'][3:6]==['--mode','headless','--session'] and record['cwd']=='/Users/wangweiyang/GitHub/zenpi' and record['fresh_session'])
check('original5 env overrides home intact',set(record['environment_overrides'])=={'ZENPI_HOME','ZENPI_BACKEND','ZENPI_BASE_URL','ZENPI_MODEL','ZENPI_API_KEY'} and record['HOME_preserved'] and record['CODEX_HOME_preserved'] and record['inherited_zenpi_key_names_only']==[])
check('exclusive launch guard archived','Do not rerun' in txt('evidence/launch-attempt.lock') and txt('workflow-source/launch-once.py').count('subprocess.Popen(')==1)
check('exact full output streams',ident(raw('evidence/stdout.bin'),record['stdout']) and ident(raw('evidence/stderr.bin'),record['stderr']) and all(x in parent for x in ('stdout_eof_ns','stderr_eof_ns','wrapper_exit_observed_ns','wait_return_ns')))
response=json.loads(raw('evidence/stdout.bin'))
check('single actual terminal acknowledgement',len(raw('evidence/stdout.bin').splitlines())==1 and response['id']=='bench-stop' and response['command']=='shutdown' and response['success'] and response['data']=={'closing':True,'drained':True})
lines=txt('evidence/markers.tsv').splitlines();header=lines[0].split('\t');meta={header[i]:int(header[i+1]) for i in range(0,len(header),2)};marks={}
for line in lines[1:]:
    name,ns,tid,count=line.split('\t');marks[name]={'ns':int(ns),'tid':int(tid),'count':int(count)}
check('raw marker file bound',ident(raw('evidence/markers.tsv'),record['markers']))
check('clock error-free same domain',meta['clock_id']==record['clock_id']==js('evidence/clock-contract.json')['python_CLOCK_MONOTONIC']==6 and meta['clock_errors']==meta['thread_errors']==0)
check('target child identity linked to wrapper',meta['ppid']==record['wrapper_pid'] and meta['pid']!=record['wrapper_pid'] and meta['ppid']!=record['parent_pid'])
check('nine fixed unique ordered markers',list(marks)==['M'+str(i) for i in range(9)] and all(r['count']==1 and r['ns']>0 for r in marks.values()) and all(marks['M'+str(i)]['ns']<marks['M'+str(i+1)]['ns'] for i in range(8)))
check('all markers on recorded main thread',len({r['tid'] for r in marks.values()})==1 and marks['M0']['tid']!=0)
check('child values inside parent clock interval',parent['popen_before_ns']<marks['M0']['ns']<marks['M8']['ns']<parent['wait_return_ns'])
check('analysis raw metadata equal',analysis['metadata']==meta and analysis['markers']==marks)
points=[parent['popen_before_ns']]+[marks['M'+str(i)]['ns'] for i in range(9)]+[parent['wait_return_ns']]
check('all10 phase durations recomputed',len(analysis['stages'])==10 and all(row['start_ns']==points[i] and row['end_ns']==points[i+1] and row['duration_ns']==points[i+1]-points[i] and row['duration_ms']==(points[i+1]-points[i])/1e6 for i,row in enumerate(analysis['stages'])))
check('exact telescoping parent interval',sum(r['duration_ns'] for r in analysis['stages'])==parent['wait_return_ns']-parent['popen_before_ns'] and analysis['total_parent_ms']==(points[-1]-points[0])/1e6)
check('main interval recomputed',analysis['main_M0_M8_ms']==(marks['M8']['ns']-marks['M0']['ns'])/1e6)
check('largest interval before main',max(analysis['stages'],key=lambda r:r['duration_ns'])['stage']==analysis['largest_stage']=='parent launch → M0')
check('clock static source declarations','_CLOCK_MONOTONIC __CLOCK_AVAILABILITY = 6' in txt('evidence/sdk-time.h') and 'pub const CLOCK_MONOTONIC: crate::clockid_t = 6;' in txt('evidence/libc-apple.rs'))
diag=after['src/startup_diag.rs'].decode();main=after['src/main.rs'].decode();head=after['src/headless.rs'].decode()
check('first main source work samples clock',main.split('fn main() -> ExitCode {\n',1)[1].splitlines()[0].strip()=='let m0_ns = zenpi::startup_diag::clock_ns();')
check('fixed record capacity and no IO before dump','[AtomicU64; 9]' in diag and 'libc::clock_gettime(libc::CLOCK_MONOTONIC' in diag and 'tv_sec as u64) * 1_000_000_000' in diag and 'OpenOptions' not in diag.split('pub fn dump()')[0])
check('diagnostic dump after M8',main.index('startup_diag::mark(8)')<main.index('startup_diag::dump()'))
check('M6 actual cached response helper after flush',head.index('crate::startup_diag::mark(6);')>head.index('RuntimeEvent::Closed => {',head.index('fn run_async_stdio')) and 'output.write_all(line.as_bytes())?;\n    output.flush()?;\n    Ok(())' in head)
check('M7 after runtime join and close closure',head.index('let join_result = runner.shutdown_and_join();')<head.index('let close_result =')<head.index('crate::startup_diag::mark(7);'))
check('marker source locations exact',all(after[r['path']].decode().splitlines()[r['line']-1].strip()==r['text'] for r in js('evidence/marker-locations.json')))
check('read blocks byte identities',all(hashlib.sha256(before[r['path']][b['bytes'][0]:b['bytes'][1]]).hexdigest()==b['sha256'] for r in js('evidence/read-ranges.json') for b in r['read_blocks']))
check('fresh empty fixture',js('evidence/fixture-before.json')=={'exists':True,'entries':[]})
check('project state unchanged absent',js('evidence/project-before.json')==js('evidence/project-after.json')=={'exists':False,'entries':[]})
check('fixture result bounded identities',[r['path'] for r in js('evidence/fixture-after.json')['entries']]==['session-0.jsonl','session-0.jsonl.reconnect'])
budget=js('evidence/production-budget.json');cold=budget['cold_start'];prod_run=js('evidence/production-budget.run.json')
check('original FAIL samples retained',cold['elapsed_ms']['samples']==[1039.683291,38.870666,42.970375] and max(cold['elapsed_ms']['samples'])>budget['budgets']['cold_start_max_ms_max']==1000 and prod_run['exit_code']==1)
check('diagnostic stdout same as production samples',all(base64.b64decode(o['stdout']['prefix_base64'])==raw('evidence/stdout.bin') and not o['stdout']['truncated'] for o in cold['observations']))
state=js('evidence/final-source-check.json')
check('final unchanged source and frozen prior snapshots',state['current_main_input_drift']==[] and state['main_product_Cargo_vendor_unchanged'] and state['production_binary_unchanged'] and state['private_diagnostic_sources_unchanged_through_build_and_launch'] and state['worker_status_unchanged'] and state['worker_status_rows']==94 and state['old117_manifest']['sha256']=='667f117b7246c3117d171fbbdc5a4a0a0cdeaa8ff81b0b62915c6e52979ebd2e')
check('no production acceptance',analysis['production_budget_replaced'] is False and analysis['additional_launches']==0)
print(json.dumps({'ok':True,'checks':len(checks),'payloads':len(rows),'target_launches':1,'build_attempts':2,'production_launches':0,'clock_contract_valid':True,'largest_stage_ms':analysis['stages'][0]['duration_ms'],'main_M0_M8_ms':analysis['main_M0_M8_ms'],'total_parent_ms':analysis['total_parent_ms'],'production_budget':'FAIL retained','checks_performed':checks},ensure_ascii=False,indent=2))
