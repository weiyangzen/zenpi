//! Private one-launch diagnostic. No protocol IO or allocation at marker sites.
use std::fmt::Write as FmtWrite;
use std::io::Write as IoWrite;
use std::sync::atomic::{AtomicU32, AtomicU64, Ordering};
static TIMES: [AtomicU64; 9] = [const { AtomicU64::new(0) }; 9];
static THREADS: [AtomicU64; 9] = [const { AtomicU64::new(0) }; 9];
static COUNTS: [AtomicU32; 9] = [const { AtomicU32::new(0) }; 9];
static CLOCK_ERRORS: AtomicU32 = AtomicU32::new(0);
static THREAD_ERRORS: AtomicU32 = AtomicU32::new(0);
pub fn clock_ns() -> u64 {
    let mut value = libc::timespec { tv_sec: 0, tv_nsec: 0 };
    let rc = unsafe { libc::clock_gettime(libc::CLOCK_MONOTONIC, &mut value) };
    if rc != 0 || value.tv_sec < 0 || value.tv_nsec < 0 || value.tv_nsec >= 1_000_000_000 {
        CLOCK_ERRORS.fetch_add(1, Ordering::Relaxed);
        return 0;
    }
    (value.tv_sec as u64) * 1_000_000_000 + value.tv_nsec as u64
}
pub fn record_at(stage: usize, ns: u64) {
    let mut tid = 0_u64;
    if unsafe { libc::pthread_threadid_np(libc::pthread_self(), &mut tid) } != 0 {
        THREAD_ERRORS.fetch_add(1, Ordering::Relaxed);
    }
    COUNTS[stage].fetch_add(1, Ordering::Relaxed);
    THREADS[stage].store(tid, Ordering::Relaxed);
    TIMES[stage].store(ns, Ordering::Release);
}
pub fn mark(stage: usize) { let ns = clock_ns(); record_at(stage, ns); }
pub fn dump() -> std::io::Result<()> {
    let mut text = String::with_capacity(2048);
    let _ = writeln!(text, "clock_id\t{}\tpid\t{}\tppid\t{}\tclock_errors\t{}\tthread_errors\t{}",
        libc::CLOCK_MONOTONIC, unsafe { libc::getpid() }, unsafe { libc::getppid() },
        CLOCK_ERRORS.load(Ordering::Relaxed), THREAD_ERRORS.load(Ordering::Relaxed));
    for stage in 0..9 {
        let _ = writeln!(text, "M{}\t{}\t{}\t{}",stage,TIMES[stage].load(Ordering::Acquire),
            THREADS[stage].load(Ordering::Relaxed),COUNTS[stage].load(Ordering::Relaxed));
    }
    let mut file = std::fs::OpenOptions::new().write(true).create_new(true).open(DIAGNOSTIC_PATH)?;
    file.write_all(text.as_bytes())?;
    file.flush()
}
const DIAGNOSTIC_PATH: &str = "/Users/wangweiyang/.codex/worktrees/38de/zenpi/.ops/stage1-worker/target117-single-markers-3.1.21/evidence/markers.tsv";
