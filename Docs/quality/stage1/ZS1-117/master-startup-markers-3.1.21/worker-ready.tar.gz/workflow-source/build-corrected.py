from pathlib import Path
import subprocess,datetime,json,hashlib,sys,os
w=Path(__file__).resolve().parent;ev=w/'evidence'/'build-02';ev.mkdir();src=w/'source-diagnostic'
with (ev/'build-attempt.lock').open('x') as f:f.write('Only one diagnostic build invocation planned; no target launches here.\n')
versions={}
for key,cmd in [('rustc',['rustc','+stable-aarch64-apple-darwin','-vV']),('cargo',['cargo','+stable-aarch64-apple-darwin','--version'])]:
 r=subprocess.run(cmd,cwd=src,capture_output=True);(ev/(key+'.stdout')).write_bytes(r.stdout);(ev/(key+'.stderr')).write_bytes(r.stderr);versions[key]={'argv':cmd,'exit_code':r.returncode};assert r.returncode==0
cmd=['cargo','+stable-aarch64-apple-darwin','build','--release','--locked','--offline','--bin','zenpi','--message-format=json-render-diagnostics']
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (ev/'build.stdout.jsonl').open('xb') as out,(ev/'build.stderr.log').open('xb') as err:
 r=subprocess.run(cmd,cwd=src,stdout=out,stderr=err,timeout=600)
end=datetime.datetime.now(datetime.timezone.utc).isoformat()
def ident(p):b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
rec={'argv':cmd,'cwd':str(src),'started_at':start,'ended_at':end,'exit_code':r.returncode,'stdout':ident(ev/'build.stdout.jsonl'),'stderr':ident(ev/'build.stderr.log'),'toolchain_commands':versions,'environment_modified':False,'build_environment_presence':{k:k in os.environ for k in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','CARGO_TARGET_DIR','SDKROOT','MACOSX_DEPLOYMENT_TARGET')}}
if r.returncode==0:rec['diagnostic_binary']=ident(src/'target/release/zenpi')
(ev/'build.run.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec));sys.exit(r.returncode)
