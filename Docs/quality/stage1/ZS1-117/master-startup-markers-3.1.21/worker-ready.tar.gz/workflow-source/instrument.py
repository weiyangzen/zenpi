from pathlib import Path
import json,difflib,hashlib
w=Path(__file__).resolve().parent;b=w/'source-diagnostic';base=w/'source-before';ev=w/'evidence'
def edit(rel,old,new):
 p=b/rel;s=p.read_text();assert s.count(old)==1,(rel,old,s.count(old));p.write_text(s.replace(old,new))
edit('src/main.rs','    match zenpi::core::run() {','    let m0_ns = zenpi::startup_diag::clock_ns();\n    zenpi::startup_diag::record_at(0, m0_ns);\n    let outcome = match zenpi::core::run() {')
edit('src/main.rs','    }\n}\n','    };\n    zenpi::startup_diag::mark(8);\n    if let Err(error) = zenpi::startup_diag::dump() {\n        eprintln!("zenpi startup diagnostic output failed: {error}");\n    }\n    outcome\n}\n')
edit('src/lib.rs','pub mod core;','pub mod core;\n#[doc(hidden)]\npub mod startup_diag;')
edit('src/core.rs','    let backend = make_backend(&options)?;','    let backend = make_backend(&options)?;\n    crate::startup_diag::mark(1);')
edit('src/core.rs','    let _ = agent.acknowledge_recovery()?;\n    // Advertise','    let _ = agent.acknowledge_recovery()?;\n    crate::startup_diag::mark(2);\n    // Advertise')
edit('src/core.rs','        RunMode::Headless => crate::headless::run_stdio_owned(agent)\n            .map_err(|error| ZenpiError::Message(error.to_string())),','        RunMode::Headless => {\n            crate::startup_diag::mark(3);\n            crate::headless::run_stdio_owned(agent)\n                .map_err(|error| ZenpiError::Message(error.to_string()))\n        },')
edit('src/headless.rs','    let loop_result = (|| -> Result<(), HeadlessError> {','    // M4 means spawn calls returned, not background-thread readiness.\n    crate::startup_diag::mark(4);\n    let loop_result = (|| -> Result<(), HeadlessError> {')
edit('src/headless.rs','            pending_shutdown.replace((id, name, request_version));\n            *stopping = true;','            pending_shutdown.replace((id, name, request_version));\n            *stopping = true;\n            crate::startup_diag::mark(5);')
edit('src/headless.rs','                    version,\n                    replay,\n                )?;\n            }\n            Ok(stopping && shutdown_sent && jobs.is_empty())','                    version,\n                    replay,\n                )?;\n                // write_cached_response completed write_all and flush.\n                crate::startup_diag::mark(6);\n            }\n            Ok(stopping && shutdown_sent && jobs.is_empty())')
edit('src/headless.rs','    match loop_result {\n        Err(error) => {','    // Both shutdown_and_join and the close_result closure have returned.\n    crate::startup_diag::mark(7);\n    match loop_result {\n        Err(error) => {')
code=r'''//! Private one-launch diagnostic. No protocol IO or allocation at marker sites.
use std::fmt::Write as FmtWrite;
use std::io::Write as IoWrite;
use std::sync::atomic::{AtomicU32, AtomicU64, Ordering};
static TIMES: [AtomicU64; 9] = [const { AtomicU64::new(0) }; 9];
static THREADS: [AtomicU64; 9] = [const { AtomicU64::new(0) }; 9];
static COUNTS: [AtomicU32; 9] = [const { AtomicU32::new(0) }; 9];
static CLOCK_ERRORS: AtomicU32 = AtomicU32::new(0);
static THREAD_ERRORS: AtomicU32 = AtomicU32::new(0);
pub fn clock_ns() -> u64 {
    let mut value = libc::timespec { tv_sec: 0, tv_nsec: 0 };
    let rc = unsafe { libc::clock_gettime(libc::CLOCK_MONOTONIC, &mut value) };
    if rc != 0 || value.tv_sec < 0 || value.tv_nsec < 0 || value.tv_nsec >= 1_000_000_000 {
        CLOCK_ERRORS.fetch_add(1, Ordering::Relaxed);
        return 0;
    }
    (value.tv_sec as u64) * 1_000_000_000 + value.tv_nsec as u64
}
pub fn record_at(stage: usize, ns: u64) {
    let mut tid = 0_u64;
    if unsafe { libc::pthread_threadid_np(std::ptr::null_mut(), &mut tid) } != 0 {
        THREAD_ERRORS.fetch_add(1, Ordering::Relaxed);
    }
    COUNTS[stage].fetch_add(1, Ordering::Relaxed);
    THREADS[stage].store(tid, Ordering::Relaxed);
    TIMES[stage].store(ns, Ordering::Release);
}
pub fn mark(stage: usize) { let ns = clock_ns(); record_at(stage, ns); }
pub fn dump() -> std::io::Result<()> {
    let mut text = String::with_capacity(2048);
    let _ = writeln!(text, "clock_id\t{}\tpid\t{}\tppid\t{}\tclock_errors\t{}\tthread_errors\t{}",
        libc::CLOCK_MONOTONIC, unsafe { libc::getpid() }, unsafe { libc::getppid() },
        CLOCK_ERRORS.load(Ordering::Relaxed), THREAD_ERRORS.load(Ordering::Relaxed));
    for stage in 0..9 {
        let _ = writeln!(text, "M{}\t{}\t{}\t{}",stage,TIMES[stage].load(Ordering::Acquire),
            THREADS[stage].load(Ordering::Relaxed),COUNTS[stage].load(Ordering::Relaxed));
    }
    let mut file = std::fs::OpenOptions::new().write(true).create_new(true).open(DIAGNOSTIC_PATH)?;
    file.write_all(text.as_bytes())?;
    file.flush()
}
const DIAGNOSTIC_PATH: &str = __PATH__;
'''.replace('__PATH__',json.dumps(str(ev/'markers.tsv')))
(b/'src/startup_diag.rs').write_text(code)
diffs=[];changed=[]
for f in sorted(b.rglob('*')):
 if not f.is_file():continue
 rel=str(f.relative_to(b));old=(base/rel).read_bytes() if (base/rel).exists() else b'';new=f.read_bytes()
 if old!=new:
  changed.append(rel);diffs.append(''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+rel if old else '/dev/null',tofile='b/'+rel)))
(ev/'diagnostic.patch').write_text(''.join(diffs));(ev/'changed-paths.json').write_text(json.dumps(changed,indent=2)+'\n');print(changed)
