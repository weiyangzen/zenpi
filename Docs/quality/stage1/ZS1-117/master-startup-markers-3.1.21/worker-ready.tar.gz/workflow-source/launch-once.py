from pathlib import Path
import os,sys,time,json,hashlib,subprocess,signal,selectors,tempfile,datetime,platform
W=Path(__file__).resolve().parent;E=W/'evidence';SRC=W/'source-diagnostic';MAIN=Path('/Users/wangweiyang/GitHub/zenpi')
def now():return time.clock_gettime_ns(time.CLOCK_MONOTONIC)
def ident(p):b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def dump(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def inventory(root):
 if not root.exists():return {'exists':False,'entries':[]}
 out=[]
 for p in sorted(root.rglob('*')):
  rel=str(p.relative_to(root));st=p.lstat()
  if p.is_symlink():out.append({'path':rel,'kind':'symlink','followed':False});continue
  if not p.is_file():out.append({'path':rel,'kind':'directory'});continue
  # Record identity only; never copy user config content or journal payloads.
  row={'path':rel,'kind':'file',**ident(p)}
  if p.suffix=='.jsonl' and root!=MAIN/'.zenpi':
   rows=[]
   for line in p.read_bytes().splitlines():
    try:
     obj=json.loads(line);rows.append({'json_type':type(obj).__name__,'keys':sorted(obj) if isinstance(obj,dict) else []})
    except (ValueError,UnicodeDecodeError):rows.append({'invalid_json':True})
   row['jsonl_structures']=rows
  out.append(row)
 return {'exists':True,'entries':out}
assert platform.system()=='Darwin' and platform.machine()=='arm64' and time.CLOCK_MONOTONIC==6
build=json.loads((E/'build-02'/'build.run.json').read_text());assert build['exit_code']==0
binary=SRC/'target/release/zenpi';assert ident(binary)==build['diagnostic_binary']
assert ident(MAIN/'target/release/zenpi')['sha256']=='5f1e513355f4e9aa228ada8ef6213e0255ec2247bd414e13668b44cdaa948588'
assert not (E/'markers.tsv').exists()
# Single-use exclusive guard before preparing any executable launch.
with (E/'launch-attempt.lock').open('x') as f:f.write('One diagnostic launch authorized. Do not rerun even on failure or non-reproduction.\n')
fixture=Path(tempfile.mkdtemp(prefix='zenpi-bench-'))
session=fixture/'session-0.jsonl';assert not session.exists() and not (fixture/'zenpi').exists()
env=os.environ.copy();before_home={k:env.get(k) for k in ('HOME','CODEX_HOME')}
overrides={'ZENPI_HOME':str(fixture/'zenpi'),'ZENPI_BACKEND':'openai','ZENPI_BASE_URL':'http://127.0.0.1:1','ZENPI_MODEL':'benchmark-no-network','ZENPI_API_KEY':'benchmark-placeholder'}
env.update(overrides);assert all(env.get(k)==v for k,v in before_home.items())
fixture_before=inventory(fixture);project_before=inventory(MAIN/'.zenpi');dump(E/'fixture-before.json',fixture_before);dump(E/'project-before.json',project_before)
payload=b'{"type":"shutdown","id":"bench-stop"}\n';(E/'stdin.bin').write_bytes(payload)
cmd=['/usr/bin/time','-l',str(binary),'--mode','headless','--session',str(session)]
rec={'launch_index':0,'launch_limit':1,'argv':cmd,'cwd':str(MAIN),'fixture_root':str(fixture),'session':str(session),'fresh_session':True,'binary':ident(binary),'parent_pid':os.getpid(),'parent_ppid':os.getppid(),'clock_id':time.CLOCK_MONOTONIC,'clock_domain':'CLOCK_MONOTONIC nanoseconds; Python explicit clock_gettime_ns; Rust libc explicit clock_gettime','python':sys.version,'environment_overrides':{k:('fixture placeholder present; value omitted' if 'KEY' in k else v) for k,v in overrides.items()},'inherited_zenpi_key_names_only':sorted(k for k in os.environ if k.startswith('ZENPI_')),'HOME_preserved':True,'CODEX_HOME_preserved':True,'watchdog_seconds':5,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'anchors':{},'timed_out':False,'reaped':False,'parent_io_note':'Same one-shot bytes and EOF, no handshake; selector observes output arrival instead of communicate; instrumentation is not a budget replay.'}
anchors=rec['anchors'];streams={'stdout':bytearray(),'stderr':bytearray()};sel=selectors.DefaultSelector();child=None
try:
 anchors['popen_before_ns']=now()
 child=subprocess.Popen(cmd,cwd=MAIN,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
 anchors['popen_return_ns']=now();rec['wrapper_pid']=child.pid
 anchors['stdin_write_before_ns']=now();child.stdin.write(payload);child.stdin.flush();child.stdin.close();child.stdin=None;anchors['stdin_closed_ns']=now()
 for name,pipe in [('stdout',child.stdout),('stderr',child.stderr)]:os.set_blocking(pipe.fileno(),False);sel.register(pipe,selectors.EVENT_READ,name)
 deadline=anchors['popen_before_ns']+5_000_000_000
 while sel.get_map() or child.poll() is None:
  if child.poll() is not None and 'wrapper_exit_observed_ns' not in anchors:anchors['wrapper_exit_observed_ns']=now()
  if now()>deadline:
   rec['timed_out']=True;anchors['watchdog_ns']=now()
   try:os.killpg(child.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   break
  for key,_ in sel.select(min(0.02,max(0,(deadline-now())/1e9))):
   data=os.read(key.fileobj.fileno(),65536);stamp=now();name=key.data
   if data:
    anchors.setdefault(name+'_first_read_ns',stamp);anchors[name+'_last_read_ns']=stamp;streams[name].extend(data)
   else:anchors[name+'_eof_ns']=stamp;sel.unregister(key.fileobj);key.fileobj.close()
 child.wait(timeout=2);rec['reaped']=True;anchors.setdefault('wrapper_exit_observed_ns',now());anchors['wait_return_ns']=now();rec['returncode']=child.returncode
except BaseException as error:
 rec['parent_error']={'type':type(error).__name__,'message':str(error)}
 if child is not None and child.poll() is None:
  try:os.killpg(child.pid,signal.SIGKILL)
  except ProcessLookupError:pass
  try:child.wait(timeout=2);rec['reaped']=True
  except subprocess.TimeoutExpired:rec['reaped']=False
finally:
 sel.close();rec['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();rec['anchors']['parent_capture_end_ns']=now()
 for name,blob in streams.items():
  f=E/(name+'.bin');f.write_bytes(blob);rec[name]=ident(f)
 rec['markers_present']=(E/'markers.tsv').exists()
 if rec['markers_present']:rec['markers']=ident(E/'markers.tsv')
 rec['diagnostic_binary_after']=ident(binary);dump(E/'launch.run.json',rec)
 dump(E/'fixture-after.json',inventory(fixture));dump(E/'project-after.json',inventory(MAIN/'.zenpi'))
 dump(E/'fixture-preservation.json',{'root':str(fixture),'retained':True,'raw_contents_not_copied_to_packet':True,'inventory_contains_only_identity_and_json_key_structure':True})
print(json.dumps(rec,ensure_ascii=False));print('UNIQUE DIAGNOSTIC LAUNCH FINISHED; NEVER RETRY')
