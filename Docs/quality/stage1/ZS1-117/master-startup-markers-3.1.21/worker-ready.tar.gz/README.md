# 117 single-launch diagnostic evidence

Read diagnosis.md and evidence/stage-analysis.json. This packet contains the original failing production records/binary, exact current source-before, private source-diagnostic, complete instrumentation patch, failed build-01 and successful build-02 logs/source difference, one diagnostic binary, one guarded launch receipt and raw markers/stdout/stderr, and before/after non-secret fixture identities.

Only `python3 -B verify.py` is an offline check. It can run from any cwd, reads only this packet and prints JSON; no network, subprocesses, writes, builds or binary launches. Everything under workflow-source is archived for review, not instructions to run. Runtime experiments have ended. Original production budget FAIL remains; no117 acceptance follows.

The fixed instrumented binary embeds its original private diagnostic file path and must not be rerun. There was one target launch; failed compilation was corrected before that launch and is preserved. Parent uses the same CLOCK_MONOTONIC domain explicitly and records observed output/exit anchors without protocol changes. The long segment is before Rust main, not an identified OS/signature root cause.
