use std::process::ExitCode;

fn main() -> ExitCode {
    let m0_ns = zenpi::startup_diag::clock_ns();
    zenpi::startup_diag::record_at(0, m0_ns);
    let outcome = match zenpi::core::run() {
        Ok(()) => ExitCode::SUCCESS,
        Err(error) => {
            eprintln!("zenpi: {error}");
            ExitCode::FAILURE
        }
    };
    zenpi::startup_diag::mark(8);
    if let Err(error) = zenpi::startup_diag::dump() {
        eprintln!("zenpi startup diagnostic output failed: {error}");
    }
    outcome
}
