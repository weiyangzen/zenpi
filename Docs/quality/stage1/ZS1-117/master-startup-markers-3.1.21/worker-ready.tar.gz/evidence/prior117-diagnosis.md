# ZS1-117 · d0ccf6f5 冷启动失败只读诊断

结论：原 cold_start 门禁仍失败，精确根因尚未定位。已有证据把主要时间放在父进程等待所包围的生命周期内，尚不能分开目标加载、Rust初始化、读取shutdown、落盘与退出。没有依据把它归咎于macOS签名、调度、DNS、某个产品函数或本次29行headless改动。本包是诊断说明与下一步设计，不是性能修复或117验收。

## 1. 当前原始证据

唯一当前被测release为6073504 B，SHA256 `d0ccf6f5d13dc0e04abe489335bc66be7cee3d0014501b4eb42bc9514dc3c05f`；原二进制仅复制、读取哈希，从未在本轮执行。headless为370207 B / `bf252fec95a859b26f9aea402c918e9efbf6c2c55d3e24b403831f86d80ec06e`。原始位置分别是主库 `.ops/stage1_execution/input-shutdown-release-3.1.21` 与正式 `Docs/quality/stage1/ZS1-132/master-input-closure-3.1.21`。每个保存对象的原路径、字节数、SHA和阅读方式见 `origins.json`/`evidence-index.md`，不依赖文件名推断身份。

预算原命令固定 `--samples 3`、没有 `--no-fail`、没有 `--near-cap`；2026-09-12T18:17:32.983752至18:19:03.275522 UTC，实际exit1。完整12454 B log SHA `e3228007878a92ed3ade664ad3a7006eaf7e0342a1aa02f3eda4fbb38b0f44ef` 保留；前缀是构建输出，其余与完整budget.json逐字节相同。原log显示release构建50.66秒，该构建时间没有计入下表单次启动时间。

| 原样本index | 门禁elapsed ms | Popen返回 ms | communicate ms | process_observed ms | 外层余量 ms | 退出/响应 |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| 0 | 1066.501958 | 2.282500 | 1063.848167 | 1066.130667 | 0.371291 | exit0，唯一bench-stop成功closing/drained |
| 1 | 46.088916 | 2.753417 | 43.098125 | 45.851542 | 0.237374 | 同上 |
| 2 | 47.311125 | 2.675167 | 44.480333 | 47.155500 | 0.155625 | 同上 |

原cap=1000ms，按max判定，首样本超66.501958ms；中位数47.311125ms不能替代max。其它7项门禁为true；首样本RSS5259264 B，所有样本无timeout。3个startup JSON与budget中的3个observation逐项相同；它们保存的base64 stdout/stderr均未截断，解码后的完整字节及哈希已核对并另存。三个stdout都是相同144字节的单条shutdown确认。它们证明最后完成响应，不提供首字节、内部flush或目标退出时间。

主控另有95 Rust通过、23真实项目/BentoBox检查通过的功能证据。本轮引用其review/master-verification作为背景，没有复跑或重新审阅全部功能轨迹，也不把这些功能检查等同于失败的性能门禁通过。

## 2. 实际计时边界与可证明的缩小范围

`tools/bench_runtime.py` 当前338行完整阅读，15327 B / `ef6701f52659c78f58fb3f31adf87343c31b34229145f57acba2be05b1a9a52c`，与当前225输入清单及历史92f95的224输入清单完全相同。完整读取发布执行脚本的53行，确认先原预算后复制release、再运行项目/BentoBox检查的顺序；这些历史脚本本轮不执行。

调用顺序是依赖metadata/tree检查→release构建→读取二进制SHA→创建一个临时fixture根→3个计时样本→runtime_probe→门禁判定/输出。因此构建、二进制哈希、runtime_probe、最终JSON输出不计入单次elapsed，不能把总命令90秒解释为冷启动。

每个计时样本从调用 `timed_process` 前的perf_counter开始，到该函数返回后停止；函数内部使用 `/usr/bin/time -l <binary> --mode headless --session <fresh path>`，Popen创建独立session/进程组并连stdin/stdout/stderr管道，然后 `communicate` 写入单条shutdown并关闭stdin，等待管道及包装进程完成。RSS解析、stdout/stderr解码和部分包装准备仍在外层elapsed中；原始流的哈希/base64和证据写入在外层计时结束之后。

父进程两段相加等于process_observed；elapsed减去它得到表中外层余量。首样本0.371291ms余量和2.2825ms Popen返回不能解释66.501958ms超额，绝大部分时间确实位于communicate区间。这只定位到父进程观察区间：它可能包含time包装器调度/启动目标、加载与pre-main、产品初始化、输入读取、shutdown处理、WAL/owner关闭、线程/进程退出以及父进程再获调度。`Popen` 返回不等于zenpi已exec或已进入main，记录的45114等PID是time包装器/进程组leader，不是目标子PID。

原始time stderr首样本1.06 real、0.00 user、0.00 sys，后两次0.04 real，附页回收/上下文切换/指令计数。CPU显示有舍入和统计范围限制，外部策略进程的工作也不会等价归入产品CPU；低CPU既不能证明签名等待，也不能排除IO、锁、线程调度或启动服务等待。0 page faults、0 block IO同样不是“没有文件系统访问”的证据。本轮不从门禁值扣除任何系统开销。

## 3. 启动路径的静态证据与限制

7个源码/计时文件共25个明确范围、2391行，见 `read-map.json`/`read-blocks.json`。只有main.rs11行与bench338行为全文；core、headless、runtime、config、session均仅必要范围。保存其全文用于身份复核不表示全部阅读。所有这7个文件的原始字节身份均匹配被测release保存的inputs.json；未用后来不同版本源码解释此二进制。

`main` 调 `core::run`。已完整读到run函数，普通headless路径在进入 `run_stdio_owned` 前先处理CLI、配置/backend构造、SessionStore::open、Agent/恢复、内建工具与工作目录、资源/扩展和模型选择。这些调用全部属于当前门禁生命周期，缺乏逐阶段时间，因此不能直接将约1秒放到“程序已经ready之后”。make_backend以及default_resource_paths/restore_resource_state的必要源码也已读取；未穷尽其所有深层函数或平台调用。

一个具体的混杂因素来自实际benchmark代码：三次各有新session文件名，但共享同一个临时 `ZENPI_HOME=<fixture>/zenpi`。新session不等于每个样本拥有重新创建的整个home；首轮可能与后续home文件状态不同。ROOT cwd仍是真实仓库。ConfigPaths::discover优先ZENPI_HOME，但resolve_workspace仍会加载cwd下的 `.zenpi/config.toml`；default_resource_paths还指向cwd的`.zenpi/skills`与`.zenpi/prompts`。原环境继承并只覆盖5个ZENPI字段，未记录全部非秘密选择器的实际取值，也没有保留该次临时home/session/WAL快照。本轮不读取用户凭据，不以当前目录/环境代替当时状态。这是明确缺失的诊断维度，不是已证实的首样本根因。

`SessionStore::open`进入writable open_with_options；已读范围有父目录创建、路径校验、读取已有字节/缺失分支及解析准备。该范围不足以量化所有后续journal写入。本轮不据此断言fsync占用1秒，也不替换原fresh session负载。

`run_stdio_owned`进入真实异步stdio，初始化owner pool/checkpoint/replay、登记live owner、创建stdin线程和BackgroundRunner，然后读shutdown。已读循环初始化jobs/pending_inputs为空，shutdown分支保存pending确认并停止；RuntimeEvent::Closed先close_input_responses再写closing/drained。输出写出并flush前有cached terminal持久化；循环后还会shutdown_and_join、replay.close及close_async_owners。因此ack与全部退出是不同的测量点，原communicate把它们包在一起。

不能把接近1秒直接认作 `DEFAULT_SHUTDOWN_GRACE=1s` 命中。runtime的空闲Shutdown分支直接发Closed并返回；1秒是活动任务的宽限边界。headless250ms条件也在jobs/pending_steers为空时无需等满。当前负载只有shutdown，没有创建provider turn或input ticket的请求；新close_input_responses对空集合不逐项工作。该静态路径不支持“所有新进程固定睡1秒”的解释，但没有线程/阶段时间戳，不能排除某一次实际调度或等待异常。没有新增网络请求观测，不能宣称做过网络零调用证明。

## 4. 历史对照保持各自身份

| 记录 | release身份来源 | 全部原样本 ms | 原结果 |
| --- | --- | --- | --- |
| 旧外部编辑器集成 | 6000768 B；7a374a3b…由原主控诊断review记录，原budget无binary_sha字段 | 1208.732708 /35.488291 /33.633667 /37.030875 /35.111416 | FAIL |
| 旧release-current | 6032944 B；180ec9f7…由原review记录，原budget无binary_sha字段 | 1044.823959 /42.234125 /44.452083 /42.458084 /45.956333 | FAIL |
| diff release | 6072608 B；e9ba9476…原budget直接记录 | 1109.425125 /42.552459 /42.552500 | FAIL |
| explicit-version | 6073392 B；92f95fbe…原二进制与receipt精确核对 | 981.791500 /46.348417 /37.688417 | PASS |
| 当前input-closure | 6073504 B；d0ccf6f5…原二进制与receipt精确核对 | 1066.501958 /46.088916 /47.311125 | FAIL |

所有cap均为1000ms；5样本与3样本是各自历史实际命令，不合并为同组统计。92f95首样本距cap仅18.2085ms，communicate980.185833ms、Popen1.30175ms。当前首样本相对它增加84.710458ms，但两个新二进制、不同时间及可能不同外部状态不构成受控因果实验。两份输入清单差异是headless521c→bf252、新增test文件，以及Gantt工具文案；计时工具/Cargo输入一致并不能锁定新headless代码为原因，也不能因旧记录同样慢就证明新代码没有任何影响。

历史主控诊断review记录5次后来启动约36–50ms，并记录某两个系统策略事件按路径关联得到436.613667ms。该review同时明确：无法绑定原样本目标PID/SHA，事件thread不同，不能证明同步阻塞或解释全部1208ms。本轮完整读了该review，未重读/重算底层策略日志、未查询系统日志、未执行旧observer或被拒DTrace。这个旧关联只能作为已有假设的来源，不能迁移到d0ccf6f5，更不能从当前1066.501958ms中减去436.613667ms。

可以确认“多个独立历史记录表现为第一样本更慢”；不能据此确认所有首样本共享同一根因，也不能用后续短样本宣布已修复。

## 5. 缺失证据与下一步

目前缺少目标PID/exec与main锚点、同一时钟的内部阶段时间、shutdown实际读取/确认flush/cleanup返回时间、目标退出与time包装器回收分离、样本间临时home/journal状态、当时有效的非秘密环境和项目资源身份。历史policy关联也缺少当前目标的身份和同步等待联系。

最小可区分方案详见 `diagnostic-design.md`：先用单个、明确不同身份的诊断构建，以固定少量内部marker把pre-entry包围区间、产品初始化、输入等待、shutdown与cleanup分开；必要时再针对已定位的大段设计下一步。该方案本轮只写成文档，没有加入产品代码、构建、执行、签名修改或权限申请。若独立诊断未复现长段，应记录“不复现/未定位”并停止，不反复运行求慢或求绿。原release及其三样本FAIL永远保留。

## 6. 本轮交付边界

全新私有报告、设计、逐项原始证据身份及静态verify；没有产品patch。main、claims、权威、历史ready及131中断材料保持原样。新verify只读包内JSON/字节与源码文本，不调用产品、Cargo、旧runner、旧verify或网络，不生成性能样本。其结果只是封包完整性与数值一致性检查，不是性能验证、根因证明或G-STAGE。执行回执外置；冻结后停止。
