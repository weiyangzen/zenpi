import os,time

def phase(name):
 with open('phases.log','a') as f:f.write(f'{time.monotonic():.9f} pid={os.getpid()} {name}\n')
def pidfile(name):
 with open(name,'w') as f:f.write(str(os.getpid()))
phase('interpreter-parent-entry');pidfile('parent.pid')
if os.fork()==0:
 os.setsid();os.close(0);phase('holder-entry');pidfile('escaped.pid');phase('escaped-ready');time.sleep(10);os._exit(0)
while not os.path.exists('escaped.pid'):time.sleep(.001)
os._exit(0)
