
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

static void phase(const char *name) {
    struct timespec now;
    if (clock_gettime(CLOCK_MONOTONIC, &now) != 0) _exit(70);
    FILE *out = fopen("phases.log", "a");
    if (!out) _exit(71);
    fprintf(out, "%lld.%09ld pid=%ld %s\n", (long long)now.tv_sec,
            now.tv_nsec, (long)getpid(), name);
    if (fclose(out) != 0) _exit(72);
}
static void pid_file(const char *name) {
    FILE *out = fopen(name, "w");
    if (!out) _exit(73);
    fprintf(out, "%ld", (long)getpid());
    if (fclose(out) != 0) _exit(74);
}
int main(void) {
    phase("native-parent-entry");
    char mode[16] = {0};
    FILE *in = fopen("pipe-mode", "r");
    if (!in || !fgets(mode, sizeof(mode), in)) return 75;
    fclose(in);
    pid_file("parent.pid");
    phase("fork-start");
    pid_t child = fork();
    if (child < 0) return 76;
    if (child == 0) {
        if (setsid() < 0) _exit(77);
        if (strcmp(mode, "stdin") == 0) close(STDOUT_FILENO);
        else if (strcmp(mode, "stdout") == 0) close(STDIN_FILENO);
        else _exit(78);
        phase("native-holder-entry");
        pid_file("escaped.pid");
        phase("escaped-ready");
        unsigned remaining = 10;
        while (remaining) remaining = sleep(remaining);
        _exit(0);
    }
    phase("fork-return");
    while (access("escaped.pid", F_OK) != 0) usleep(1000);
    _exit(0);
}
