use strict; use warnings; use POSIX qw(setsid); use Time::HiRes qw(clock_gettime CLOCK_MONOTONIC sleep);
sub phase { open my $f, '>>', 'phases.log' or die $!; printf $f "%.9f pid=%d %s\n", clock_gettime(CLOCK_MONOTONIC), $$, $_[0]; close $f or die $!; }
sub pidfile {open my $f, '>', $_[0] or die $!; print $f $$;close $f or die $!;}
phase('interpreter-parent-entry');pidfile('parent.pid');my $pid=fork();defined $pid or die $!;
if ($pid==0) {setsid()>=0 or die $!;close STDIN;phase('holder-entry');pidfile('escaped.pid');phase('escaped-ready');sleep(10);POSIX::_exit(0);}
while (!-e 'escaped.pid') {sleep(.001);}POSIX::_exit(0);
