from pathlib import Path
import datetime, difflib, hashlib, json, os, shutil, stat

W = Path(__file__).resolve().parent
P = W / 'ready-final'
M = Path('/Users/wangweiyang/GitHub/zenpi')
A = Path('/Users/wangweiyang/.codex/worktrees/38de/zenpi/.ops/target126-session-browser-3.1.20-ready')

def info(p):
    b = p.read_bytes()
    return {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def inventory(root):
    result = {}
    for directory, dirs, files in os.walk(root, followlinks=False):
        dirs[:] = [n for n in dirs if not Path(directory, n).is_symlink()]
        for name in files:
            p = Path(directory, name)
            if stat.S_ISREG(p.lstat().st_mode):
                result[str(p.relative_to(root))] = info(p)
    return result

def dump(p, obj):
    p.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')

def copytree(src, dst):
    for rel in inventory(src):
        target = dst / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src / rel, target)

assert not P.exists()
before = json.loads((W / 'preservation-before.json').read_text())
for root, files in before['ready'].items():
    assert inventory(Path(root)) == files, root
for path, expected in before['tracked'].items():
    assert info(Path(path)) == expected, path
assert inventory(A) == before['A_package']
assert info(M / 'src/tui.rs') == info(W / 'before-tui.rs')
context = json.loads((W / 'context-manifest.json').read_text())
binding = json.loads((W / 'build-binding.json').read_text())
for rel, expected in context['files'].items():
    assert info(W / 'context' / rel) == (binding['compiled_tui'] if rel == 'src/tui.rs' else expected), rel
assert (W / 'context/src/tui.rs').read_bytes() == (W / 'before-tui.rs').read_bytes() + binding['test_only_append'].encode()
dump(W / 'preservation-after.json', {
    'checked_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'old_ready_packages': len(before['ready']),
    'old_ready_regular_files': sum(len(v) for v in before['ready'].values()),
    'tracked_regular_files': len(before['tracked']),
    'A_package_regular_files': len(before['A_package']),
    'all_byte_identical': True, 'main_tui_byte_identical': True,
    'main_tui': info(M / 'src/tui.rs'),
    'compile_inputs': len(context['files']), 'unchanged_non_tui_inputs': len(context['files']) - 1,
    'product_patch': None,
})

ranges = {
    'before-tui.rs': [(1380,1395),(1530,1895),(2150,2195),(2230,2415),(2420,2462),(4210,4320),(7030,7198),(8315,8405),(11163,11235),(11345,11485),(11475,11590),(11950,12070),(12475,12565),(12775,12860),(14837,15190)],
    'context/src/session.rs': [(2266,2370)],
    'context/src/headless.rs': [(1490,1528),(1611,1730)],
}
reads = []
for rel, spans in ranges.items():
    lines = (W / rel).read_bytes().splitlines(keepends=True)
    for start, end in spans:
        chunk = b''.join(lines[start-1:end])
        reads.append({'path': rel, 'source': info(W / rel), 'start': start, 'end': end, 'bytes': len(chunk), 'sha256': hashlib.sha256(chunk).hexdigest()})
dump(W / 'read-bindings.json', {'scope': 'Selected same-file functions and call/error/close paths, plus exact dependencies; not whole TUI or whole target acceptance. Ranges include surrounding context.', 'reads': reads})

run_bindings = []
for name, source in [('independent-tests-01','commands/independent-tests-01.rs'),('independent-tests-final','context/independent/session_browser_review.rs')]:
    receipt = json.loads((W / 'commands' / (name + '.json')).read_text())
    log = W / 'commands' / (name + '.log')
    assert receipt['exit_code'] == 0
    assert info(log) == {k: receipt[k] for k in ['bytes','sha256']}
    assert 'test result: ok. 8 passed; 0 failed; 0 ignored;' in log.read_text()
    run_bindings.append({'name': name, 'test_source': source, 'test_source_identity': info(W/source), 'compiled_tui': binding['compiled_tui'], 'log': info(log), 'receipt': info(W/'commands'/(name+'.json')), 'environment': {'TMPDIR':str(W/'tmp'),'CARGO_TARGET_DIR':str(W/'target'),'PYTHONDONTWRITEBYTECODE':'1'}, 'new_cases':8})
dump(W/'run-source-bindings.json', {'runs':run_bindings, 'first_to_final_change':'rustfmt layout and test identifier old_A to old_a only; product source unchanged', 'unique_new_cases':8, 'historical_A_runs_reexecuted':False})

P.mkdir()
for name in ['manifest.json','read-bindings.json']:
    target = P/'failed-first-package'/name
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(W/'ready'/name,target)
for folder in ['context','input-A','commands']:
    copytree(W/folder, P/folder)
for name in ['before-tui.rs','build-binding.json','context-manifest.json','A-inventory.json','A-to-integrated.diff','preservation-before.json','preservation-after.json','read-bindings.json','run-source-bindings.json','prepare.py','package.py','review.md','verify.py']:
    shutil.copyfile(W/name,P/name)
shutil.copyfile(W.parents[1]/'.ops/run_candidate_probe.py',P/'run_candidate_probe.py')
dump(P/'manifest.json', {'task':'ZS1-126','owner':'C','version':'3.1.20','scope':'independent frozen-source async session browser review and 8 new tests; no product patch','source':info(P/'before-tui.rs'),'files':[{'path':k,**v} for k,v in sorted(inventory(P).items())]})
print(json.dumps({'ready':str(P),'manifest':info(P/'manifest.json'),'report':info(P/'review.md'),'files':len(inventory(P))},ensure_ascii=False))
