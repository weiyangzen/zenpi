from pathlib import Path
import hashlib,json,os,shutil,stat,subprocess,datetime
W=Path(__file__).resolve().parent;R=W.parents[1];M=Path('/Users/wangweiyang/GitHub/zenpi');A=Path('/Users/wangweiyang/.codex/worktrees/38de/zenpi/.ops/target126-session-browser-3.1.20-ready')
def info(p):
 b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def inventory(root):
 out={}
 for directory,dirs,files in os.walk(root,followlinks=False):
  dirs[:]=[n for n in dirs if not Path(directory,n).is_symlink()]
  for n in files:
   p=Path(directory,n)
   if stat.S_ISREG(p.lstat().st_mode):out[str(p.relative_to(root))]=info(p)
 return out
def dump(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def copy(root,dest,files):
 for rel in files:
  p=dest/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/rel,p)
assert info(M/'src/tui.rs')['sha256']=='994215c7ca6cc471bb35247a04460d6c5ef52192999e4b5585ea1c818a429578'
assert info(A/'manifest.json')['sha256']=='6519e3b93606376da3e259b54e8c46ffff67d19f373a973a28fc60575a2727ce'
for row in json.loads((A/'manifest.json').read_text())['files']:assert info(A/row['path'])=={k:row[k] for k in ['bytes','sha256']}
afiles=inventory(A);copy(A,W/'input-A',afiles);dump(W/'A-inventory.json',afiles)
old={str(p):inventory(p) for p in (R/'.ops').iterdir() if p.is_dir() and p.name.endswith('-ready')}
p=R/'.ops/stage125-render-review320/ready';old[str(p)]=inventory(p)
tracked={}
for raw in subprocess.check_output(['git','ls-files','-z'],cwd=R).split(b'\0'):
 if raw:
  p=R/os.fsdecode(raw)
  if p.exists() and stat.S_ISREG(p.lstat().st_mode):tracked[str(p)]=info(p)
dump(W/'preservation-before.json',dict(ready=old,tracked=tracked,A_package=afiles))
files={rel:info(M/rel) for rel in ['Cargo.toml','Cargo.lock']}
for folder in ['src','vendor']:
 for rel,v in inventory(M/folder).items():files[folder+'/'+rel]=v
copy(M,W/'context',files);dump(W/'context-manifest.json',dict(source=str(M),captured_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),files=files,scope='full library compile context snapshot; only selected TUI functions semantically reviewed'))
shutil.copyfile(M/'src/tui.rs',W/'before-tui.rs')
for folder in ['commands','tmp','context/independent']: (W/folder).mkdir()
marker='\n#[cfg(test)]\n#[path = "../independent/session_browser_review.rs"]\nmod independent_session_browser_review;\n'
with (W/'context/src/tui.rs').open('a') as f:f.write(marker)
dump(W/'build-binding.json',dict(before=info(W/'before-tui.rs'),test_only_append=marker,compiled_tui=info(W/'context/src/tui.rs'),product_changed=False))
print(json.dumps(dict(context_files=len(files),A_files=len(afiles),preserved_ready=len(old),before=info(W/'before-tui.rs')),indent=2))
