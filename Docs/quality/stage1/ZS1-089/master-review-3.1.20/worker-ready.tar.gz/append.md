

---

# 3.1.20 当前 CI 差量复核：113 行预算证据保留版本

本节更新当前结论。此前完整 24526 字节报告作为精确前缀保留，SHA-256 `33e353712730db9dcb9335e8c16c8d9caa83c2488a0d7b851d3042a33dfa670f`；其中 77 行与 94 行的“当前”描述分别属于历史时点。特别是上一节第 1 条“预算失败后的诊断留存未闭合”已由主控整合的当前代码改变，不能再作为当前未修复缺陷。此刷新候选仍为 `[_]`，未修改状态、产品或目录报告。

## 范围、输入和完整阅读

当前蓝图 ZS1-089 的 L1 owner 仅 `.github/workflows/ci.yml`，依赖 ZS1-001；唯一 Owned path 是 `Docs/learn/stage1_pi_mono/targets/zenpi/files/.github/workflows/ci.yml_learn.md`。G-FILE 要求完整语义与分支复核，结构 checker 不能替代主控语义验收；G-STAGE 的 `--item ZS1-089` 另行检查。ZS1-092→093 依赖和目录闭包仍独立，不在此报告接受。

本轮连续全文读取冻结基线 77 行、上一候选 94 行和主库当前 113 行，完整覆盖空行、注释、字段、16 个有序步骤及 shell 分支；没有用 diff 代替全文。输入的单连续字节范围、捕获 UTC、原路径和摘要见 `Docs/quality/stage1/ZS1-089/worker-current-ci320/input-manifest.json`。

| 版本 | 字节 / 行 | SHA-256 |
|---|---:|---|
| 蓝图冻结基线 | 2480 / 77 | `5d7173fa20a0de949e53525018dad07718a9e4a9d24a5fcd137b056af31792d6` |
| 上轮完整理解候选 | 3104 / 94 | `b9e70ba448d157341e0069fcd9ad19eae8f0412aaf0b9e03bbd97b4f2ef59dbd` |
| 当前主库 | 3973 / 113 | `44c1d0964cd0c3504f028f3fa2dbcac89c8063ca895d039eba729dd64bc263c9` |

requirement digest 保持 `8d525b351d066ce9b0487a485337647d47233275782e4f4d154423a623fe1645`。新证据目录的 `reused/` 保存上轮完整 089 ready、预算变更 worker ready、主控 `master-ci-budget-evidence-3.1.20` 全部常规文件；包括原 manifest、失败结果、日志及回放源码，不改其历史 authority 或执行时间。继承报告的 master 接收基线仍不存在；本轮同时提供从 absent 主库接收的完整标准报告补丁，以及从旧候选精确前缀追加的补丁。

## 当前全文件接线与逐步骤复核

L1–19 保持原样：push/pull_request 无过滤，contents:read，workflow/ref 并发组和 cancel-in-progress，一个 Ubuntu latest verify job、15 分钟超时。新增 shell:bash 只作用于预算步骤；原报告“无 shell override”不能继续概括当前整个文件。权限声明没有变宽，也没有新增部署、消息发送或发布步骤。contents:read 是工作流声明，不是远程 artifact 服务调用成功的证据；实际令牌、action 内部实现和运行器权限不在本轮验证内。

| 当前行 | 实际入口与分支范围 |
|---|---|
|20–21|checkout@v4，无输入覆盖。|
|23–26|rust-toolchain@stable 请求 rustfmt、clippy，无 MSRV 矩阵。|
|28–29|rust-cache@v2，缓存不构成行为验收。|
|31–32|cargo fmt --all -- --check，只检查。|
|34–35|Clippy all-targets/all-features，-D warnings，无显式 --locked。|
|37–41|测试 all-targets/all-features/locked，libtest threads=1；保留解释 loopback 争用的注释。|
|43–44|validate_blueprint.py，命令未变；此前检查的旧蓝图入口身份属于历史上下文。|
|46–47|validate_blueprint_v2.py，命令未变；没有增加当前 Stage 1 checker。|
|49–50|check_rust_loc.py，无新增 --max-lines 参数。|
|52–70|runtime_budget 显式 Bash、独立证据目录、samples=3，捕获两个管道成员退出码后显式返回。完整分支见下。|
|72–78|always 与 budget outcome 条件，upload-artifact@v4 上传目录，名称带 run/attempt，缺文件为 error。|
|80–81|check_modes.py，命令与上轮相同。|
|83–84|fixture debug build 成功后通过 && 执行指定 ZENPI_BIN 的 headless_smoke。|
|86–87|dev-fixtures 环境参数调用 user_smoke.py；本轮不扩展到脚本内部 helper 验收。|
|89–90|fixture release build 成功后运行指定二进制的 --release headless smoke。|
|92–113|生产打包、校验 sidecar、临时清单、逐归档显式检查 tar 成功、拒绝禁止名称及 grep 异常。|

94→113 的差量精确局限于第 10、11 步（零基下标 9、10）；前 9 步与后 5 步的原始文本均逐字节保持。归档检查仅移动了行号：当前 L94–95 为 release/校验和，L96–97 临时文件与 EXIT 清理，L98–102 listing 失败直接退出 1，L103–105 禁止名称匹配退出 1，L106–111 仅 grep=1 视为普通未匹配，其余非零保留错误码，L112–113 闭合。旧 malformed archive 误通过的修复仍在，不能重新提为当前 bug。其历史有效/禁止名称/损坏归档证据保持原样；本轮没有增加归档行为案例。

## 预算 shell 的完整失败、持久化和取消边界

1. L53 的 id 供随后 `steps.runtime_budget.outcome` 使用。L54 明确选 Bash；本地历史夹具实际用 `bash --noprofile --norc -e -o pipefail` 执行抽出的 run 块。平台默认 shell 的依据沿用历史官方引用，本轮无网络查阅或远程运行。
2. L56 通过 env 传入 runner.temp 下由 run_id/run_attempt 组成的目录；不是在 run 字符串中插入 PR 标题、分支正文等用户输入。所有 shell 路径展开均带双引号。L58 使用普通 mkdir，位于 set +e 之前，创建失败会使步骤失败；不加 -p 是拒绝重用已有目录的控制流。该目录身份按 workflow run/attempt 区分，不是跨任意未来 matrix/job 的通用唯一标识；当前只有单个 verify job。
3. L59 暂停 errexit，但不撤销 pipefail，使预算或 tee 非零后仍能执行状态保存。L60–63 固定 samples=3，向 summary.json 与尚未创建的 startup 子目录传参；没有 --no-fail、--near-cap、阈值修改或重试。`2>&1` 合并预算 stdout/stderr，再由 tee 写 budget.log 和步骤输出；预算脚本自身的异常文本也可进入此管道。
4. L64 紧接管道，以数组展开复制 PIPESTATUS，索引 0 为 Python、1 为 tee；没有先执行其它命令破坏该管道状态。L65 再恢复 errexit。L66 的 exit-code.txt **只记录预算进程退出码**，不是最终步骤退出码，也没有单独持久化 tee 的退出码文件。预算=0、tee=23 时文件内容为 `0\n`，步骤仍失败。
5. L67–69 预算非零优先原码退出；只有预算为零才走 L70 返回 tee 状态。因此两个成员同时失败时预算码优先；logger 失败不会将步骤变绿。这个保证适用于执行确实到达这些分支的情况：exit-code.txt 的重定向或 printf 在恢复 -e 后失败，会提前结束步骤，不能绝对承诺任何 I/O 故障下都保留预算原码。
6. `tools/bench_runtime.py` 当前整文件摘要仍为 `ef6701f52659c78f58fb3f31adf87343c31b34229145f57acba2be05b1a9a52c`。本轮仅复核带 hash 的 L1–58、L142–201、L276–338 上下文：CLI 拒绝已有 startup 目录后创建；startup 成功和捕获异常路径写 sample-NN.json，单样本以 x 模式拒绝覆盖；summary 经临时文件与 os.replace 写入后再返回 gate 结果。dependency/build 等早期异常可能发生在样本或汇总生成前，不能承诺总有 3 个样本或 summary。
7. startup 观察记录将原始子进程流转为全流 bytes/hash 与最多 65536 字节 base64 前缀，另有 truncated 标记。因此“保留启动诊断”表示保留已有诊断格式，不能误写为所有子进程完整原始流都会独立上传。budget.log 保存的是本次 Python 命令向其 stdout/stderr 实际发出的合并字节。
8. 超时、并发取消或 runner 被终止可能打断状态写入、样本写入及上传。工作流没有为预算步骤增加自动恢复、重新测量或会话恢复合同；run_attempt 区分重跑目录，不意味着预算脚本会恢复未完成采样。本轮不把 workflow 取消声明替代产品子进程取消/reap 验收。

## 上传条件、失败传播及适用限制

L73 含状态函数 always()，并排除 outcome=`skipped`。预算步骤成功、失败，以及平台仍能继续调度的取消路径都可能进入上传；因较早普通步骤失败而预算被标为 skipped 时不会上传。该表达式使失败证据上传可达，但无法保证已丢失的 runner、作业强制超时或无法继续调度时仍能完成 action。

L76 名称和 L77 路径均包含同一 run_id/run_attempt；上传范围改为整个证据目录，可能包含 summary.json、budget.log、exit-code.txt、startup/*.json，具体取决于生成进度。L78 的 if-no-files-found:error 在没有可上传文件时要求 action 报错，不代表只有 summary 缺失就应报错；早期失败留下的日志和部分诊断仍有保留价值。没有 continue-on-error：若预算本来成功而上传失败，后续普通成功条件步骤会被阻断；若预算已失败，上传成功也不会把原失败改为成功。这里解释配置/已有文档语义，未证明任何实际远程上传已经成功或失败。

普通 mkdir 拒绝旧目录可避免预算覆盖它，但上传步骤没有额外检查“此次 mkdir 成功”的输出。如果人为复用同一 run/attempt 路径造成 mkdir 失败，配置仍可能尝试上传该已存在目录；本地重复目录夹具只证明拒绝覆盖和不再次调用预算，未执行上传。正常唯一 run/attempt 命名和“任何失败时 artifact 都一定属于本次执行”是不同强度的保证，报告不将后者补造为已证事实。

contents:read 及其他 14 步未改；本轮没有对 action 服务端授权、artifact 保留期、容量限制、不可用/断网重试、Ubuntu 文件系统错误进行运行验证。action 版本标签与 ubuntu-latest/stable 的浮动身份限制仍适用。

## 五种历史本地 shell 证据与本轮运行数

新证据目录内 worker 历史 `local-fixtures.json/.log` 绑定 2026-09-12T11:59:00Z 执行，wrapper exit 0，log SHA-256 `39a9062ef01e8415b2ed21f85852c6a5738c287828da820eb9542a3524b117ca`。主控历史 `shell-cases.run.json/.log` 绑定 2026-09-12T12:22:12Z 独立复跑，wrapper exit 0，log SHA-256 `51e6a914276eec1210cc17d4298328b8fd60b2f25aee13987551d02c4b6a4281`。两者为同一五种场景的不同执行，不计作十种场景，也不是本轮新运行。

| 场景 | 预算 / tee / shell 实际码 | 字节与生成预期 |
|---|---|---|
|success|0 / 0 / 0|合并 CRLF 日志、summary、startup 样本及 exit-code=0|
|budget-failed|1 / 0 / 1|失败 summary、日志、样本及 exit-code=1|
|early-failed|17 / 0 / 17|日志、部分样本及 exit-code=17；没有伪造 summary|
|logger-failed|0 / 23 / 23|exit-code=0 但 shell=23，明确区分两个身份|
|both-failed|17 / 23 / 17|预算原码优先，保留部分样本和日志|

两次历史验证均逐例断言中文/空格路径、stdout/stderr 合并后的 CRLF 精确字节、startup 初始不存在、samples=3、同目录再次执行时 mkdir 拒绝、fixture 调用总数仍为 1、旧证据与无关 sentinel 不变。logger=23 是包装系统 tee 写完后主动返回 23，证明退出码传播，不是磁盘满、断管或真实文件权限错误注入；其日志完整不能推广到所有真实 tee 故障。历史 verifier 还进行了单 CI 文件正逆 apply/check；本轮保留源码和全部原结果，但不执行它。

本轮新增行为运行数 **0**；Cargo、PTY、HTTP、网络、生产 budget、Actions 和实际 artifact 上传均为 **0**。本轮实际运行的是只读 G-STAGE 与新包离线完整性/标准报告补丁校验，不能计入上述五种 shell 场景。未复用其它项的通过数量或主控 125/TUI 验收作为 089 的行为证明。

## 仍开放的范围与交付门禁

预算失败上传路径的具体修复已落到当前 owner；远程 Actions/真实上传仍缺运行证据。上一报告的当前 Stage 1 checker 接线、归档坏输入持续回归入口、浮动依赖身份和验证矩阵限制，没有被本次两步骤差量解决；本轮只确认当前 YAML 命令未新增这些入口，不宣称其他自动化没有覆盖。旧报告对 user_smoke 等兄弟脚本的 helper 解释保持历史时点，未借本轮 hash 重新验收那些文件。

本轮实际只读 G-STAGE 返回 1：structural.ok=true，semantic_manual.verified_by_checker=false，缺失主库 `Docs/learn/stage1_pi_mono/receipts/ZS1-089.master.json`。原始命令与日志保存于 commands/gstage-current-main，日志 SHA-256 `fd4e98ca2d279a3a8f6df7fe7ca1b6f6e56a655d5976318aee2f2d673e90638f`。这是未具备主控验收 receipt，不能隐藏非零、补造 receipt 或把离线结构校验当作 G-FILE 接受。

新 ready 的 manifest 逐文件记录完整 payload 大小与摘要；离线 verifier 校验旧报告精确前缀、77/94/113 行完整范围、16 步顺序、两步骤差量、历史 manifest/原始日志/base64 和标准报告两个基线的正逆补丁。补丁只写唯一标准报告，历史证据在独立目录随包保留；回退只撤回该报告候选和本轮新证据，不覆盖 CI 产品、主库状态或 092/093 报告。主控应在精确输入仍匹配时独立验收，再推进目录项。
