from pathlib import Path
import difflib, hashlib, json, os, shutil, stat
W=Path(__file__).resolve().parent;R=W.parents[1];E=W/'files/Docs/quality/stage1/ZS1-089/worker-current-ci320'
REPORT='Docs/learn/stage1_pi_mono/targets/zenpi/files/.github/workflows/ci.yml_learn.md'
def info(p):
    b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def inventory(root):
    out={}
    for directory,dirs,files in os.walk(root,followlinks=False):
        dirs[:]=[n for n in dirs if not Path(directory,n).is_symlink()]
        for n in files:
            p=Path(directory,n)
            if stat.S_ISREG(p.lstat().st_mode):out[str(p.relative_to(root))]=info(p)
    return out
def dump(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
baseline=json.loads((W/'preservation-before.json').read_text())
for name,expected in baseline['ready'].items():assert inventory(Path(name))==expected,name
for name,expected in baseline['tracked'].items():assert info(Path(name))==expected,name
inputs=json.loads((E/'input-manifest.json').read_text());assert info(Path(inputs['sources'][-1]['source']))=={k:inputs['sources'][-1][k] for k in ['bytes','sha256']}
for row in json.loads((E/'reused-packages.json').read_text()):assert inventory(Path(row['source']))==inventory(E/row['artifact'])
assert not (Path('/Users/wangweiyang/GitHub/zenpi')/REPORT).exists()
shutil.copyfile(W/'preservation-before.json',E/'preservation-before.json')
dump(E/'preservation-result.json',dict(passed=True,ready_packages=len(baseline['ready']),ready_regular_files=sum(map(len,baseline['ready'].values())),tracked_regular_files=len(baseline['tracked']),method='regular-file set and SHA-256 equality; no FIFO opened',main_CI_unchanged=True,old_report_unchanged=True,main_report_still_absent=True))
ready=R/'.ops/target089-current-ci320-ready';ready.mkdir()
for rel in inventory(W/'files'):
    p=ready/'files'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(W/'files'/rel,p)
for name in ['verify.py','prepare.py','freeze.py','append.md']:shutil.copyfile(W/name,ready/name)
shutil.copyfile(R/'.ops/run_candidate_probe.py',ready/'run_candidate_probe.py')
prior=(E/'prior-report.md').read_bytes();after=(W/'files'/REPORT).read_bytes();assert after.startswith(prior)
for name,before in [('candidate.patch',b''),('append-existing-report.patch',prior)]:
    patch=''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+REPORT if before else '/dev/null',tofile='b/'+REPORT)).encode()
    assert len(patch)<256*1024;(ready/name).write_bytes(patch)
files=[dict(path=rel,**record) for rel,record in inventory(ready/'files').items()]
manifest=dict(item='ZS1-089',status='[_]',authority_version='3.1.20',authority_digest=inputs['authority_digest'],product_paths=[],owned_report=REPORT,main_base_exists=False,report_prefix=inputs['report_prefix'],current_ci=inputs['sources'][-1],new_behavior_runs=0,historical_distinct_shell_cases=5,remote_Actions_runs=0,artifact_upload_runs=0,semantic_acceptance=False,gstage_exit_code=1,files=files,artifacts=inventory(ready))
dump(ready/'manifest.json',manifest)
print(json.dumps(dict(ready=str(ready),manifest=info(ready/'manifest.json'),report=info(ready/'files'/REPORT),report_patch=info(ready/'candidate.patch'),append_patch=info(ready/'append-existing-report.patch'),files=len(files),artifacts=len(manifest['artifacts'])),indent=2))
