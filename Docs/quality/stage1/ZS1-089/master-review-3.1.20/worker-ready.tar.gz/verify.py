"""Offline integrity/patch verification only. Never runs stored command strings or behavioral fixtures."""
from pathlib import Path
import argparse, base64, hashlib, json, os, stat, subprocess
P=argparse.ArgumentParser();P.add_argument('--scratch',type=Path,required=True);a=P.parse_args()
root=Path(__file__).resolve().parent
REPORT='Docs/learn/stage1_pi_mono/targets/zenpi/files/.github/workflows/ci.yml_learn.md'
EV='Docs/quality/stage1/ZS1-089/worker-current-ci320';E=root/'files'/EV
def info(p):
    b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def inventory(p):
    out={}
    for directory,dirs,files in os.walk(p,followlinks=False):
        dirs[:]=[n for n in dirs if not Path(directory,n).is_symlink()]
        for n in files:
            q=Path(directory,n)
            if stat.S_ISREG(q.lstat().st_mode):out[str(q.relative_to(p))]=info(q)
    return out
m=json.loads((root/'manifest.json').read_text())
assert m['item']=='ZS1-089' and m['status']=='[_]' and m['new_behavior_runs']==0 and m['product_paths']==[]
actual=inventory(root);actual.pop('manifest.json');assert actual==m['artifacts']
for row in m['files']:assert info(root/'files'/row['path'])=={k:row[k] for k in ['bytes','sha256']}
source=json.loads((E/'input-manifest.json').read_text())
assert source['owned_report']==REPORT and not source['main_report_exists']
prior=(E/'prior-report.md').read_bytes();report=(root/'files'/REPORT).read_bytes()
assert info(E/'prior-report.md')==source['report_prefix'] and len(prior)==24526 and report.startswith(prior) and len(report)>len(prior)
for entry in source['sources']:
    path=E/entry['artifact'];assert info(path)=={k:entry[k] for k in ['bytes','sha256']}
    assert len(path.read_bytes().splitlines())==entry['lines']
    assert entry['full_read_byte_ranges']==[[0,entry['bytes']]] and entry['full_read_line_ranges']==[[1,entry['lines']]]
before=(E/'previous-ci.yml').read_bytes();after=(E/'current-ci.yml').read_bytes()
assert hashlib.sha256(after).hexdigest()=='44c1d0964cd0c3504f028f3fa2dbcac89c8063ca895d039eba729dd64bc263c9'
start=b'      - name: Run runtime and size budget gate\n';end=b'      - name: Check two-mode boundary\n'
assert before.split(start)[0]==after.split(start)[0] and before.split(end)[1]==after.split(end)[1]
assert len([x for x in after.splitlines() if x.startswith(b'      - name: ')])==16
for token in [b'id: runtime_budget',b'shell: bash',b'budget_status=("${PIPESTATUS[@]}")',b'if: ${{ always() && steps.runtime_budget.outcome != \'skipped\' }}',b'if-no-files-found: error']:assert token in after
preserved=json.loads((E/'preservation-before.json').read_text())
for row in json.loads((E/'reused-packages.json').read_text()):
    copied=E/row['artifact'];manifest=json.loads((copied/'manifest.json').read_text())
    assert info(copied/'manifest.json')['sha256']==row['manifest_sha256']
    assert len(inventory(copied))==row['regular_files']
    if row['source'] in preserved['ready']: assert inventory(copied)==preserved['ready'][row['source']]
    for old in manifest['files']:
        p=copied/('files' if 'manifest_payloads' in row else '')/old['path']
        assert info(p)=={k:old[k] for k in ['bytes','sha256']}
worker=E/'reused/stage117-ci-evidence320-ready/files/Docs/quality/stage1/ZS1-117/worker-ci-evidence320'
master=E/'reused/master-ci-budget-evidence-3.1.20'
wc=json.loads((worker/'local-fixtures.json').read_text());mc=json.loads((master/'shell-cases.run.json').read_text())
assert wc['exit_code']==mc['exit_code']==0
assert info(worker/'local-fixtures.log')==dict(bytes=wc['bytes'],sha256=wc['sha256'])
assert info(master/'shell-cases.log')==dict(bytes=mc['log_bytes'],sha256=mc['log_sha256'])
w=json.loads((worker/'fixture-results.json').read_text());v=json.loads((master/'shell-cases.log').read_text())
assert w['cases']==v['cases'] and len(w['cases'])==5
assert [c['shell_exit_code'] for c in w['cases']]==[0,1,17,23,17]
for c in w['cases']:
    artifacts={k:base64.b64decode(val,validate=True) for k,val in c['artifacts_base64'].items()}
    assert artifacts['budget.log']==base64.b64decode(c['stdout_base64'])==b'fixture stdout\r\nfixture stderr\r\n'
    assert artifacts['exit-code.txt']==f"{c['benchmark_exit_code']}\n".encode()
    assert ('summary.json' in artifacts)==(c['benchmark_exit_code']!=17)
    assert c['repeated_directory_exit_code']!=0 and c['invocations']==1 and c['sentinel_unchanged']
g=json.loads((E/'commands/gstage-current-main.json').read_text());gl=E/'commands/gstage-current-main.log'
assert g['exit_code']==1 and info(gl)==dict(bytes=g['bytes'],sha256=g['sha256'])
gate=json.loads(gl.read_text());assert gate['structural']['ok'] and not gate['ok'] and any('ZS1-089.master.json' in x for x in gate['errors'])
assert json.loads((E/'preservation-result.json').read_text())['passed']
scratch=a.scratch.resolve();assert not scratch.exists() and not scratch.is_relative_to(root);scratch.mkdir(parents=True)
operations=[]
for label,patch,base in [('main-absent','candidate.patch',None),('previous-report','append-existing-report.patch',prior)]:
    work=scratch/label;work.mkdir();p=work/REPORT;p.parent.mkdir(parents=True)
    if base is not None:p.write_bytes(base)
    sentinel=work/'unrelated-sentinel';sentinel.write_bytes(b'preserve\x00\r\n')
    subprocess.run(['git','init','--quiet'],cwd=work,check=True,capture_output=True)
    stats=subprocess.run(['git','apply','--numstat',str(root/patch)],cwd=work,check=True,capture_output=True,text=True).stdout.splitlines()
    assert len(stats)==1 and stats[0].split('\t')[2]==REPORT
    for label2,flags in [('forward-check',['--check']),('forward',[]),('reverse-check',['--reverse','--check']),('reverse',['--reverse'])]:
        if label2=='reverse-check':assert p.read_bytes()==report
        result=subprocess.run(['git','apply',*flags,str(root/patch)],cwd=work,capture_output=True)
        assert result.returncode==0,result.stderr
        operations.append(dict(baseline=label,phase=label2,exit_code=result.returncode))
        assert sentinel.read_bytes()==b'preserve\x00\r\n'
    assert (not p.exists()) if base is None else p.read_bytes()==base
print(json.dumps(dict(passed=True,item='ZS1-089',manifest_sha256=info(root/'manifest.json')['sha256'],artifacts=len(m['artifacts']),report=info(root/'files'/REPORT),report_prefix=source['report_prefix'],patch_operations=operations,historical_shell_cases=5,new_behavior_runs=0,gstage_exit_code_preserved=1,semantic_acceptance=False),indent=2))
