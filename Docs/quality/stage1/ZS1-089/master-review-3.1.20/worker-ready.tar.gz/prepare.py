from pathlib import Path
import datetime, difflib, hashlib, json, os, shutil, stat, subprocess
R=Path(__file__).resolve().parents[2]; W=Path(__file__).resolve().parent; M=Path('/Users/wangweiyang/GitHub/zenpi')
REPORT='Docs/learn/stage1_pi_mono/targets/zenpi/files/.github/workflows/ci.yml_learn.md'
EV='Docs/quality/stage1/ZS1-089/worker-current-ci320'
E=W/'files'/EV; E.mkdir(parents=True)
def info(p):
    b=p.read_bytes(); return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def dump(p,x): p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def inventory(root):
    out={}
    for directory,dirs,files in os.walk(root,followlinks=False):
        dirs[:]=[n for n in dirs if not Path(directory,n).is_symlink()]
        for n in files:
            p=Path(directory,n)
            if stat.S_ISREG(p.lstat().st_mode): out[str(p.relative_to(root))]=info(p)
    return out
def copytree(source,dest):
    rows=inventory(source)
    for rel in rows:
        p=dest/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source/rel,p)
    assert inventory(dest)==rows
    return rows
old={}
for p in (R/'.ops').iterdir():
    if p.is_dir() and p.name.endswith('-ready'): old[str(p)]=inventory(p)
old[str(R/'.ops/stage125-render-review320/ready')]=inventory(R/'.ops/stage125-render-review320/ready')
tracked={}
for rel in subprocess.check_output(['git','ls-files','-z'],cwd=R).split(b'\0'):
    if rel:
        p=R/os.fsdecode(rel)
        if p.exists() and stat.S_ISREG(p.lstat().st_mode): tracked[str(p)]=info(p)
protected=dict(ready=old,tracked=tracked)
dump(W/'preservation-before.json',protected)
reused=[]
for name,expected in [('target089-review320-ready','d82de0618e7c6aa00062a0df039ad4016473dcd5c9eba5cf798962245235674c'),('stage117-ci-evidence320-ready','aa68dc426601b6daeabfbb23b37c042a906f69ad28040c2c220a92988bc06909')]:
    source=R/'.ops'/name;assert info(source/'manifest.json')['sha256']==expected
    manifest=json.loads((source/'manifest.json').read_text())
    for row in manifest['files']: assert info(source/'files'/row['path'])=={k:row[k] for k in ['bytes','sha256']}
    rows=copytree(source,E/'reused'/name)
    reused.append(dict(source=str(source),artifact='reused/'+name,manifest_sha256=expected,regular_files=len(rows),manifest_payloads=len(manifest['files'])))
master=M/'Docs/quality/stage1/ZS1-117/master-ci-budget-evidence-3.1.20'
for row in json.loads((master/'manifest.json').read_text())['files']: assert info(master/row['path'])=={k:row[k] for k in ['bytes','sha256']}
master_files=copytree(master,E/'reused/master-ci-budget-evidence-3.1.20')
reused.append(dict(source=str(master),artifact='reused/master-ci-budget-evidence-3.1.20',manifest_sha256=info(master/'manifest.json')['sha256'],regular_files=len(master_files),scope='historical independent five-case shell run only; not item acceptance'))
dump(E/'reused-packages.json',reused)
prior=R/'.ops/target089-review320-ready/files'/REPORT
assert prior.read_bytes()==(R/REPORT).read_bytes()
assert info(prior)['sha256']=='33e353712730db9dcb9335e8c16c8d9caa83c2488a0d7b851d3042a33dfa670f'
shutil.copyfile(prior,E/'prior-report.md')
assert not (M/REPORT).exists()
selector=json.loads((M/'Docs/execution/active_requirement.json').read_text())
assert selector['blueprint_version']=='3.1.20' and selector['requirement_digest']=='8d525b351d066ce9b0487a485337647d47233275782e4f4d154423a623fe1645'
dump(E/'active-requirement.json',selector)
sources=[]
for name,source,sha in [
    ('frozen-baseline-ci.yml',R/'.ops/target089-review320-ready/files/Docs/quality/stage1/ZS1-089/worker-review320/baseline-ci.yml','5d7173fa20a0de949e53525018dad07718a9e4a9d24a5fcd137b056af31792d6'),
    ('previous-ci.yml',R/'.ops/target089-review320-ready/files/Docs/quality/stage1/ZS1-089/worker-review320/current-ci.yml','b9e70ba448d157341e0069fcd9ad19eae8f0412aaf0b9e03bbd97b4f2ef59dbd'),
    ('current-ci.yml',M/'.github/workflows/ci.yml','44c1d0964cd0c3504f028f3fa2dbcac89c8063ca895d039eba729dd64bc263c9')]:
    assert info(source)['sha256']==sha;shutil.copyfile(source,E/name);b=source.read_bytes()
    sources.append(dict(source=str(source),artifact=name,**info(source),lines=len(b.splitlines()),full_read_line_ranges=[[1,len(b.splitlines())]],full_read_byte_ranges=[[0,len(b)]],captured_at=datetime.datetime.now(datetime.timezone.utc).isoformat()))
    assert len([l for l in b.splitlines() if l.startswith(b'      - name: ')])==16
before=(E/'previous-ci.yml').read_bytes();after=(E/'current-ci.yml').read_bytes()
start=b'      - name: Run runtime and size budget gate\n';end=b'      - name: Check two-mode boundary\n'
assert before.split(start)[0]==after.split(start)[0] and before.split(end)[1]==after.split(end)[1]
(E/'previous-to-current.diff').write_text(''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='previous/.github/workflows/ci.yml',tofile='current/.github/workflows/ci.yml')))
dump(E/'input-manifest.json',dict(item='ZS1-089',owned_report=REPORT,report_prefix=info(prior),main_report_exists=False,sources=sources,new_behavior_runs=0,authority_digest=selector['requirement_digest']))
refs=[]
for rel,ranges in [('tools/bench_runtime.py',[(1,58),(142,201),(276,338)]),('Docs/stage_1_v3_pi_mono_blueprint.md',[(121,154),(206,206)]),('tools/validate_stage1_blueprint.py',[(1,45),(762,798)])]:
    p=M/rel;b=p.read_bytes();lines=b.splitlines(keepends=True);row=dict(source=str(p),**info(p),captured_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='context only; no sibling acceptance',excerpts=[])
    for a,z in ranges:
        z=min(z,len(lines));dest=E/'context'/f'{p.stem}-{a}-{z}.txt';dest.parent.mkdir(exist_ok=True);dest.write_bytes(b''.join(lines[a-1:z]));row['excerpts'].append(dict(artifact=str(dest.relative_to(E)),lines=[a,z],**info(dest)))
    refs.append(row)
dump(E/'context-references.json',refs)
dump(E/'step-index.json',[dict(line=n,name=line.decode().split('- name: ',1)[1]) for n,line in enumerate(after.splitlines(),1) if line.startswith(b'      - name: ')])
(W/'commands').mkdir()
print(json.dumps(dict(work=str(W),sources=sources,prefix=info(prior),reused=reused,preserved_ready=len(old)),ensure_ascii=False))
